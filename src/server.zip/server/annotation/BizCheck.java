package com.jiduauto.sps.server.annotation;
import com.jiduauto.sps.server.component.BizVaildate;
import com.jiduauto.sps.server.consts.DictEnum;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author tao.wang
 * @date 2022/8/2
 * @description
 */
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {BizVaildate.class})
@Target(value = { ElementType.FIELD, ElementType.PARAMETER})
public @interface BizCheck {
    DictEnum biz ();

    String  message() default "业务类型校验失败";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
