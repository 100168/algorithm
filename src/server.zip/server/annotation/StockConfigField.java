package com.jiduauto.sps.server.annotation;

import java.lang.annotation.*;

/**
 * @author tao.wang
 * @date 2023/1/3
 * @description
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
public @interface StockConfigField {

    String fieldName();

    String desc();

    int sort() default 1;
}
