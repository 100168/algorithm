package com.jiduauto.sps.server.annotation;



import com.jiduauto.sps.server.component.IntegerRangeValidate;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 *
 * @author jian.pan
 * @date 5/22/23 1:41 PM
 */
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {IntegerRangeValidate.class})
@Target(value = { ElementType.FIELD, ElementType.PARAMETER})
public @interface IntegerRange {

    String  message() default "参数校验失败";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String[] value();

}
