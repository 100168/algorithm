package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.sdk.client.req.ApplyOrderToEsReq;
import com.jiduauto.sps.server.pojo.po.ApplyOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.ApplyOrderEditReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ApplyOrderConvertor {

    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "receiverProvince", ignore = true)
    @Mapping(target = "receiverDistrict", ignore = true)
    @Mapping(target = "receiverContact", ignore = true)
    @Mapping(target = "receiverCity", ignore = true)
    @Mapping(target = "receiverAddress", ignore = true)
    @Mapping(target = "receiver", ignore = true)
    @Mapping(target = "outStockReq", ignore = true)
    @Mapping(target = "orderType", ignore = true)
    @Mapping(target = "logisticNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "applyer", ignore = true)
    @Mapping(target = "applyType", ignore = true)
    @Mapping(target = "applySum", ignore = true)
    @Mapping(target = "applyRealSum", ignore = true)
    @Mapping(target = "applyOrderNo", ignore = true)
    @Mapping(target = "applyDate", ignore = true)
    @Mapping(target = "applyContact", ignore = true)
    ApplyOrderPo toPo(ApplyOrderEditReq req);


    @Mapping(target = "itemReqList", ignore = true)
    @Mapping(target = "workOrderNo", source = "applyOrderNo")
    ApplyOrderToEsReq toEs(ApplyOrderPo po);
}
