package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderPo;
import com.jiduauto.sps.sdk.pojo.req.StockCheckOrderAddReq;
import com.jiduauto.sps.sdk.pojo.req.StockCheckOrderEditReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface StockCheckOrderConvertor {

    @Mapping(target = "isDhl", ignore = true)
    @Mapping(target = "checkDate", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "orderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    StockCheckOrderPo toPo(StockCheckOrderAddReq req);

    @Mapping(target = "isDhl", ignore = true)
    @Mapping(target = "checkDate", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "orderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    StockCheckOrderPo toPo(StockCheckOrderEditReq req);
}
