package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.param.UpdateStockParam;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @ClassName InAndOutStockParamConvertor
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/12/22 14:38
 */
@Mapper(componentModel = "spring")
public interface UpdateStockParamConvertor {


    @Mapping(target = "planQuantity", ignore = true)
    @Mapping(target = "columnNo", ignore = true)
    @Mapping(target = "bizConfigKey", ignore = true)
    @Mapping(target = "addDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getAddDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    @Mapping(target = "productDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getProductDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    @Mapping(target = "expireDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getExpireDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    UpdateStockParam toParam(StockItemPo po);

    List<UpdateStockParam> toParam(List<StockItemPo> po);
}
