package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PendingReceiveListDetailDto;
import com.jiduauto.sps.server.pojo.dto.ReceiveOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.ReceiveOrderDetailPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ReceiveOrderDetailPoConvertor {

    @Mapping(target = "stageName", ignore = true)
    @Mapping(target = "projectName", ignore = true)
    @Mapping(target = "count", ignore = true)
    @Mapping(target = "supplierName", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    ReceiveOrderDetailDto toDto(ReceiveOrderDetailPo po);


    @Mapping(target = "workbinCode", ignore = true)
    @Mapping(target = "wbsCode", ignore = true)
    @Mapping(target = "warehouseCode", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "stockStatus", ignore = true)
    @Mapping(target = "sequenceNo", ignore = true)
    @Mapping(target = "samplePartStatus", ignore = true)
    @Mapping(target = "receiveOrderNo", ignore = true)
    @Mapping(target = "pssType", ignore = true)
    @Mapping(target = "productDate", ignore = true)
    @Mapping(target = "palletCode", ignore = true)
    @Mapping(target = "materialStatus", ignore = true)
    @Mapping(target = "materialSort", ignore = true)
    @Mapping(target = "locationCode", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "expireDate", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "carCode", ignore = true)
    @Mapping(target = "batchNo", ignore = true)
    @Mapping(target = "areaCode", ignore = true)
    ReceiveOrderDetailPo toPo(PendingReceiveListDetailDto pendingReceiveListDto);
}
