package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.stock.StockAllDto;
import com.jiduauto.sps.server.pojo.po.StockPo;
import com.jiduauto.sps.server.pojo.vo.resp.stock.InternalStockResp;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface StockConvert {

    /**
     * to resp
     * @param stockAllDto stockAllDto
     * @return InternalStockSearchResp
     */
    @Mapping(target = "materialCode", source = "materialNumber")
    InternalStockResp toResp(StockAllDto stockAllDto);
    /**
     * to resp
     * @param stockAllDtoList stockAllDtoList
     * @return list
     */
    List<InternalStockResp> toRespList(List<StockAllDto> stockAllDtoList);


    /**
     * to dto
     * @param stockPo stockPo
     * @return StockAllDto
     */
    @Mapping(target = "warehouseName", ignore = true)
    @Mapping(target = "locationName", ignore = true)
    @Mapping(target = "areaName", ignore = true)
    @Mapping(target = "supplierName", ignore = true)
    @Mapping(target = "pmux", ignore = true)
    @Mapping(target = "partTypeName", ignore = true)
    @Mapping(target = "partTypeCode", ignore = true)
    @Mapping(target = "measurementUnit", ignore = true)
    @Mapping(target = "materialType", ignore = true)
    @Mapping(target = "materialStandard", ignore = true)
    @Mapping(target = "materialNumber", source = "materialCode")
    @Mapping(target = "materialName", ignore = true)
    @Mapping(target = "materialAttribute", ignore = true)
    StockAllDto toDto(StockPo stockPo);
    /**
     * to dto
     * @param stockPos stockPos
     * @return List
     */
    List<StockAllDto> toDtoList(List<StockPo> stockPos);

}
