package com.jiduauto.sps.server.convertor;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.Enum.KitOrderStatusEnum;
import com.jiduauto.sps.server.Enum.KitOrderTypeEnum;
import com.jiduauto.sps.server.Enum.PRTypeEnum;
import com.jiduauto.sps.server.client.req.AsnAddSyncReq;
import com.jiduauto.sps.server.client.req.AsnAddSyncReq.DeliverInfo;
import com.jiduauto.sps.server.handler.warehousedistributeorder.WarehouseDistributeOrderAllPo;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderItemPo;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderPo;
import com.jiduauto.sps.server.service.*;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.jiduauto.sps.server.Enum.StockOperationType.*;

/**
 * @author panjian
 */
@Component
public class InboundReqConvertor {

    @Resource
    private IPurchaseApplyOrderDetailService purchaseApplyOrderDetailService;

    @Resource
    private IMaterialService materialService;

    @Resource
    private IKitOrderItemService kitOrderItemService;

    @Resource
    private ISupplierSrmService supplierSrmService;

    @Resource
    private ISupplierService supplierService;

    public AsnAddSyncReq toInBoundReq(PurchaseApplyOrderPo purchaseApplyOrderPo) {
        SupplierSrmPo supplierSrm = supplierSrmService.getOne(Wrappers.<SupplierSrmPo>lambdaQuery().eq(SupplierSrmPo::getSapCode, purchaseApplyOrderPo.getSupplierCode()));

        AsnAddSyncReq asnAddSyncReq = new AsnAddSyncReq();
        asnAddSyncReq.setAsnCode(purchaseApplyOrderPo.getOrderNo());
        asnAddSyncReq.setBizType(purchaseApplyOrderPo.getBizType());
        asnAddSyncReq.setDeliveryTime(DateUtil.formatLocalDateTime(purchaseApplyOrderPo.getCreateTime()));
        PRTypeEnum prTypeEnum = PRTypeEnum.getByCode(purchaseApplyOrderPo.getOrderType());
        switch (prTypeEnum) {
            case FREE: {
                asnAddSyncReq.setInboundType(purchaseApplyOrderPo.getBizType() + "13");
                break;
            }
            case OUT_PLAN: {
                asnAddSyncReq.setInboundType(SP_OUT_PLAN_PUT_IN.getOperationType());
                break;
            }
            default:
                break;
        }

        asnAddSyncReq.setReceiveWarehouseCode(purchaseApplyOrderPo.getWarehouseCode());
        List<PurchaseApplyOrderDetailPo> detailPos = purchaseApplyOrderDetailService.list(
                Wrappers.<PurchaseApplyOrderDetailPo>lambdaQuery()
                        .eq(PurchaseApplyOrderDetailPo::getOrderId, purchaseApplyOrderPo.getId()));
        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(purchaseApplyOrderPo.getBizType(),
                detailPos.stream().map(PurchaseApplyOrderDetailPo::getSalePartNum).collect(
                        Collectors.toList()));

        List<DeliverInfo> deliverInfos = detailPos.stream().map(e -> {
            DeliverInfo deliverInfo = new DeliverInfo();
            deliverInfo.setAsnLineNo(String.valueOf(e.getLineNo()));
            deliverInfo.setDeliveryQty(e.getQty());
            deliverInfo.setSalePartNum(e.getSalePartNum());
            MaterialPo materialPo = materialPoMap.getOrDefault(e.getSalePartNum(), new MaterialPo());
            deliverInfo.setUnit(materialPo.getOrderUnit());
            if (StrUtil.isEmpty(materialPo.getOrderUnit())) {
                deliverInfo.setUnit(materialPo.getMeasurementUnit());
            }
            deliverInfo.setSupplierName(Objects.isNull(supplierSrm) ? null : supplierSrm.getSupplierName());
            deliverInfo.setSupplierSapCode(purchaseApplyOrderPo.getSupplierCode());
            deliverInfo.setSupplierAddress(Objects.isNull(supplierSrm) ? null : supplierSrm.getRegistryDetailedAddress());
            return deliverInfo;
        }).collect(Collectors.toList());
        asnAddSyncReq.setDeliverInfos(deliverInfos);
        return asnAddSyncReq;
    }

    public AsnAddSyncReq toInBoundReq(KitOrderPo orderPo) {
        AsnAddSyncReq asnAddSyncReq = new AsnAddSyncReq();
        asnAddSyncReq.setAsnCode(orderPo.getKitOrderNo());
        asnAddSyncReq.setBizType(orderPo.getBizType());
        asnAddSyncReq.setOperationType("ADD");
        if (orderPo.getOrderStatus().equals(KitOrderStatusEnum.CANCELED.getCode())) {
            asnAddSyncReq.setOperationType("CANCEL");
        }
        asnAddSyncReq.setDeliveryTime(DateUtil.formatLocalDateTime(orderPo.getUpdateTime()));
        if(BizTypeEnum.SP.getBizType().equals(orderPo.getBizType())){
            asnAddSyncReq.setInboundType(SP_15.getOperationType());
        }else if(BizTypeEnum.JC.getBizType().equals(orderPo.getBizType())){
            asnAddSyncReq.setInboundType(JC15.getOperationType());
        }
        asnAddSyncReq.setReceiveWarehouseCode(orderPo.getWarehouseCode());
        List<KitOrderItemPo> detailPos = kitOrderItemService.list(Wrappers.<KitOrderItemPo>lambdaQuery().eq(KitOrderItemPo::getKitOrderNo, orderPo.getKitOrderNo()));
        List<String> salePartNums = detailPos.stream().map(KitOrderItemPo::getMaterialNumber).collect(
                Collectors.toList());
        salePartNums.add(orderPo.getMaterialNumber());
        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(salePartNums);
        List<DeliverInfo> deliverInfos = new ArrayList<>();
        KitOrderTypeEnum orderTypeEnum = KitOrderTypeEnum.getByCode(orderPo.getOrderType());
        switch (orderTypeEnum) {
            case ASSEMBLE: {
                //组装入库 KIT总成件入库
                DeliverInfo deliverInfo = new DeliverInfo();
                deliverInfo.setAsnLineNo("01");
                deliverInfo.setDeliveryQty(orderPo.getQty());
                deliverInfo.setSalePartNum(orderPo.getMaterialNumber());
                MaterialPo materialPo = materialPoMap.getOrDefault(orderPo.getBizType() + orderPo.getMaterialNumber(), new MaterialPo());
                deliverInfo.setUnit(StrUtil.isEmpty(materialPo.getOrderUnit()) ? materialPo.getMeasurementUnit() : materialPo.getOrderUnit());
                deliverInfo.setSupplierAddress("极越零件中心");
                deliverInfo.setSupplierName("极越");
                deliverInfo.setSupplierSapCode("JIYUE");
                deliverInfos.add(deliverInfo);
                break;
            }
            case DISASSEMBLE: {
                //拆解入库  KIT子件 入库
                deliverInfos = detailPos.stream().map(e -> {
                    DeliverInfo deliverInfo = new DeliverInfo();
                    deliverInfo.setAsnLineNo(String.valueOf(e.getLineNo()));
                    deliverInfo.setDeliveryQty(e.getQty());
                    deliverInfo.setSalePartNum(e.getMaterialNumber());
                    MaterialPo materialPo = materialPoMap.getOrDefault(e.getBizType() + e.getMaterialNumber(), new MaterialPo());
                    deliverInfo.setUnit(StrUtil.isEmpty(materialPo.getOrderUnit()) ? materialPo.getMeasurementUnit() : materialPo.getOrderUnit());
                    deliverInfo.setSupplierAddress("极越零件中心");
                    deliverInfo.setSupplierName("极越");
                    deliverInfo.setSupplierSapCode("JIYUE");
                    return deliverInfo;
                }).collect(Collectors.toList());
                break;
            }
            default:
        }
        asnAddSyncReq.setDeliverInfos(deliverInfos);
        return asnAddSyncReq;
    }


    public AsnAddSyncReq toInBoundReq(WarehouseDistributeOrderAllPo allPo) {
        WarehouseDistributeOrderPo warehouseDistributeOrderPo = allPo.getWarehouseDistributeOrderPo();
        WarehouseDistributeLogisticPo warehouseDistributeLogisticPo = allPo.getWarehouseDistributeLogisticPo();
        List<WarehouseDistributeItemAttachPo> itemAttaches = allPo.getItemAttaches();
        List<WarehouseDistributeItemPackagePo> itemPackages = allPo.getItemPackages();
        Map<String, WarehouseDistributeItemAttachPo> attachPoMap = itemAttaches.stream()
                .collect(Collectors.toMap(WarehouseDistributeItemAttachPo::getMaterialLineNo, Function.identity()));
        Map<String, List<WarehouseDistributeItemPackagePo>> packMap = itemPackages.stream()
                .collect(Collectors.groupingBy(WarehouseDistributeItemPackagePo::getPackingCode));
        Map<String, WarehouseDistributeItemPo> itemPoMap = allPo.getItems().stream().collect(Collectors.toMap(e -> e.getMaterialCode() + e.getBatchNo(), Function.identity(), (e1, e2) -> {
            e1.setQty(e1.getQty().add(e2.getQty()));
            return e1;
        }));
        List<WarehouseDistributeItemPo> itemPos = new ArrayList<>(itemPoMap.values());
        AsnAddSyncReq asnAddSyncReq = new AsnAddSyncReq();
        asnAddSyncReq.setAsnCode(warehouseDistributeOrderPo.getBusinessBillNo());
        asnAddSyncReq.setBizType(warehouseDistributeOrderPo.getBizType());
        asnAddSyncReq.setDeliveryTime(DateUtil.formatLocalDateTime(LocalDateTime.now()));
        asnAddSyncReq.setInboundType(warehouseDistributeOrderPo.getOrderType());
        asnAddSyncReq.setReceiveWarehouseCode(warehouseDistributeLogisticPo.getReceiveWarehouseCode());
        asnAddSyncReq.setLogisticsNo(warehouseDistributeOrderPo.getLogisticNo());
        SupplierPo supplier = supplierService.getOne(Wrappers.<SupplierPo>lambdaQuery().eq(SupplierPo::getSapCode, itemPos.get(0).getSupplierCode()).eq(SupplierPo::getBizType, warehouseDistributeOrderPo.getBizType()));
        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(warehouseDistributeOrderPo.getBizType(),
                itemPos.stream().map(WarehouseDistributeItemPo::getMaterialCode).collect(
                        Collectors.toList()));
        List<DeliverInfo> deliverInfos = itemPos.stream().map(e -> {
            DeliverInfo deliverInfo = new DeliverInfo();
            deliverInfo.setAsnLineNo(e.getMaterialLineNo());
            deliverInfo.setDeliveryQty(e.getQty());
            deliverInfo.setSalePartNum(e.getMaterialCode());
            deliverInfo.setSupplierSapCode(e.getSupplierCode());
            MaterialPo materialPo = materialPoMap.getOrDefault(e.getMaterialCode(), new MaterialPo());
            deliverInfo.setUnit(materialPo.getOrderUnit());
            deliverInfo.setBatchNo(e.getBatchNo());
            deliverInfo.setSupplierName(Objects.isNull(supplier) ? null : supplier.getSupplierName());
            deliverInfo.setSupplierAddress(Objects.isNull(supplier) ? null : supplier.getAddress());
            if (StrUtil.isEmpty(materialPo.getOrderUnit())) {
                deliverInfo.setUnit(materialPo.getMeasurementUnit());
            }
            WarehouseDistributeItemAttachPo attachPo = attachPoMap.getOrDefault(e.getMaterialLineNo(), new WarehouseDistributeItemAttachPo());
            deliverInfo.setResponsibleParty(attachPo.getResponsibleParty());
            deliverInfo.setReturnReason(attachPo.getRemark());
            List<WarehouseDistributeItemPackagePo> itemPackagePos = packMap.get(e.getPackingCode());
            List<AsnAddSyncReq.PackageInfo> packageInfos = itemPackagePos.stream().map(v -> {
                AsnAddSyncReq.PackageInfo packageInfo = new AsnAddSyncReq.PackageInfo();
                packageInfo.setPackNo(v.getPackingCode());
                packageInfo.setActualPackQty(BigDecimal.ONE);
                return packageInfo;
            }).collect(Collectors.toList());
            deliverInfo.setPackageInfos(packageInfos);
            return deliverInfo;
        }).collect(Collectors.toList());
        asnAddSyncReq.setDeliverInfos(deliverInfos);
        return asnAddSyncReq;
    }

}
