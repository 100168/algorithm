package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PickingApplyDetailDto;
import com.jiduauto.sps.server.pojo.po.PickingApplyDetailPo;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PickingApplyDetailConvertor {

    /**
     * to dto
     * @param pickingApplyDetailPo pickingApplyDetailPo
     * @return PickingApplyDetailDto
     */
    PickingApplyDetailDto toDto(PickingApplyDetailPo pickingApplyDetailPo);

    /**
     * to dto
     * @param pickingApplyDetailPos pickingApplyDetailPos
     * @return PickingApplyDetailDto
     */
    List<PickingApplyDetailDto> toDto(List<PickingApplyDetailPo> pickingApplyDetailPos);

}
