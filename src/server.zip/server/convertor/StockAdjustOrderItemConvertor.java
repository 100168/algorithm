package com.jiduauto.sps.server.convertor;

import com.jiduauto.spare.parts.api.physical.count.command.PhysicalAdjustSubOrderCmd;
import com.jiduauto.sps.sdk.pojo.po.StockAdjustOrderItemPo;
import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderItemPo;
import com.jiduauto.sps.server.pojo.vo.req.StockAdjustOrderReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @ClassName StockAdjustOrderConvertor
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/12/1 16:25
 */
@Mapper(componentModel = "spring")
public interface StockAdjustOrderItemConvertor {


    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "wbsCode", ignore = true)
    @Mapping(target = "supplierCode", ignore = true)
    @Mapping(target = "stageCode", ignore = true)
    @Mapping(target = "sequenceNo", ignore = true)
    @Mapping(target = "samplePartStatus", ignore = true)
    @Mapping(target = "purchaseOrderNo", ignore = true)
    @Mapping(target = "projectCode", ignore = true)
    @Mapping(target = "productDate", ignore = true)
    @Mapping(target = "palletNo", ignore = true)
    @Mapping(target = "materialSort", ignore = true)
    @Mapping(target = "materialBarCode", ignore = true)
    @Mapping(target = "expireDate", ignore = true)
    @Mapping(target = "columnProjectNo", ignore = true)
    @Mapping(target = "caseNo", ignore = true)
    @Mapping(target = "carCode", ignore = true)
    @Mapping(target = "batchNo", ignore = true)
    @Mapping(target = "adjustQty", source = "diffQty")
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "stockAdjustOrderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    @Mapping(target = "addDate", ignore = true)
    StockAdjustOrderItemPo toPo(StockAdjustOrderReq.StockAdjustOrderItem req);

    List<StockAdjustOrderItemPo> toPo(List<StockAdjustOrderReq.StockAdjustOrderItem> req);

    @Mapping(target = "subOrderCode", source = "po.lineNo")
    @Mapping(target = "skuName", ignore = true)
    @Mapping(target = "skuCode", source = "po.materialCode")
    @Mapping(target = "realCount", source = "po.adjustQty")
    PhysicalAdjustSubOrderCmd toCmd(StockAdjustOrderItemPo po);

    List<PhysicalAdjustSubOrderCmd> toCmd(List<StockAdjustOrderItemPo> poList);

    @Mapping(target = "stockAdjustOrderNo", ignore = true)
    @Mapping(target = "lineNo", ignore = true)
    @Mapping(target = "adjustQty", source = "diffQty")
    StockAdjustOrderItemPo checkItemToPo(StockCheckOrderItemPo stockCheckOrderItemPo);

    List<StockAdjustOrderItemPo> checkItemToPo(List<StockCheckOrderItemPo> stockCheckOrderItemPos);


}
