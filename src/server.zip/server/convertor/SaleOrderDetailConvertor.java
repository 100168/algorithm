package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.InternalSoDetailDto;
import com.jiduauto.sps.server.pojo.dto.SaleOrderDetailDto;
import java.util.List;

import com.jiduauto.sps.server.pojo.po.SaleOrderDetailPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface SaleOrderDetailConvertor {

    /**po转dto
     * @param saleOrderDetailPo po
     * @return dto*/
    @Mapping(target = "salePartName", ignore = true)
    @Mapping(target = "partSaleField", ignore = true)
    @Mapping(target = "minPackage", ignore = true)
    SaleOrderDetailDto toDetailDto(SaleOrderDetailPo saleOrderDetailPo);


}
