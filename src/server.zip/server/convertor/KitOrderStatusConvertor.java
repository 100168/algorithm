package com.jiduauto.sps.server.convertor;


import com.jiduauto.sps.server.pojo.dto.kit.KitOrderStatusLogDto;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderStatusLogPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;


@Mapper(componentModel = "spring")
public interface KitOrderStatusConvertor {

    /**
     * to dto
     */
    KitOrderStatusLogDto toDto(KitOrderStatusLogPo po);


    List<KitOrderStatusLogDto> toDtoList(List<KitOrderStatusLogPo> poList);
}