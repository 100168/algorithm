package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.vo.req.BackOrderPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.InternalBoSearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface BackOrderConvertor {

    /**外部req转系统req
     * @param internalSoSearchReq req
     * @return dto*/
    @Mapping(target = "backOrderNos", ignore = true)
    @Mapping(target = "salePartNumLike", ignore = true)
    @Mapping(target = "saleOrderNo", ignore = true)
    @Mapping(target = "createTimeStart", ignore = true)
    @Mapping(target = "createTimeEnd", ignore = true)
    BackOrderPageSearchReq toReq(InternalBoSearchReq internalSoSearchReq);
}
