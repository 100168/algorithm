package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.sdk.client.req.ApplyOrderToEsReq;
import com.jiduauto.sps.server.pojo.po.ApplyOrderItemPo;
import com.jiduauto.sps.server.pojo.vo.req.ApplyOrderEditReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ApplyOrderItemConvertor {


    @Mapping(target = "warehouseCode", ignore = true)
    @Mapping(target = "version", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "stageCode", ignore = true)
    @Mapping(target = "lineNo", ignore = true)
    @Mapping(target = "sapOutOrder", ignore = true)
    @Mapping(target = "samplePartStatus", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "projectCode", ignore = true)
    @Mapping(target = "materialStatus", ignore = true)
    @Mapping(target = "materialSort", ignore = true)
    @Mapping(target = "materialCode", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "isApply", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    @Mapping(target = "applySum", ignore = true)
    @Mapping(target = "applyRealSum", ignore = true)
    @Mapping(target = "applyOrderNo", ignore = true)
    ApplyOrderItemPo toPo(ApplyOrderEditReq.ItemEditReq req);

    List<ApplyOrderItemPo> toPo(List<ApplyOrderEditReq.ItemEditReq> req);

    @Mapping(target = "columnNo", source = "lineNo")
    @Mapping(target = "traceStatus", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    @Mapping(target = "isApply", expression = "java(applyOrderItemPo.getIsApply()?String.valueOf(1):String.valueOf(0))")
    ApplyOrderToEsReq.ApplyOrderToEsReqItem toReq(ApplyOrderItemPo applyOrderItemPo);

    List<ApplyOrderToEsReq.ApplyOrderToEsReqItem> toReq(List<ApplyOrderItemPo> applyOrderItemPo);
}
