package com.jiduauto.sps.server.convertor;

import cn.hutool.core.date.DateUtil;
import com.jiduauto.sps.sdk.pojo.po.StockAdjustOrderItemPo;
import com.jiduauto.sps.sdk.pojo.po.StockAdjustOrderPo;
import com.jiduauto.sps.server.client.req.UpdateStockSyncReq;
import com.jiduauto.sps.server.service.IStockConfigService;
import com.jiduauto.sps.server.service.IStockItemService;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class UpdateStockSyncReqConvertor {

    @Resource
    private IStockItemService stockItemService;

    @Resource
    private IStockConfigService stockConfigService;

    /**
     * 转换req
     */
    public UpdateStockSyncReq toReq(StockAdjustOrderPo po, List<StockAdjustOrderItemPo> detail) {
        UpdateStockSyncReq updateStockSyncReq = new UpdateStockSyncReq();
        updateStockSyncReq.setBizType(po.getBizType());
        updateStockSyncReq.setBusinessType(po.getOrderType());
        updateStockSyncReq.setBusinessBillNo(po.getOrderNo());
        updateStockSyncReq.setOperateUser(UserUtil.getUserName());
        updateStockSyncReq.setOperateTime(DateUtil.formatLocalDateTime(LocalDateTime.now()));

        ArrayList<UpdateStockSyncReq.UpdateStockSyncInfo> infos = new ArrayList<>();
        for (StockAdjustOrderItemPo itemPo : detail) {
            UpdateStockSyncReq.UpdateStockSyncInfo info = getStockSyncInfo(itemPo);
            info.setSourceSumQuantity(BigDecimal.ZERO);
            //下发时需要传输源库存数量、目标库存数量，源库存数量=0，
            // 目标数量=调整数量
            info.setTargetSumQuantity(itemPo.getAdjustQty());
            infos.add(info);
        }
        updateStockSyncReq.setUpdateStockSyncInfos(infos);
        return updateStockSyncReq;
    }

    private static UpdateStockSyncReq.UpdateStockSyncInfo getStockSyncInfo(StockAdjustOrderItemPo itemPo) {
        UpdateStockSyncReq.UpdateStockSyncInfo info = new UpdateStockSyncReq.UpdateStockSyncInfo();
        info.setLineNo(itemPo.getLineNo());
        info.setWarehouseCode(itemPo.getWarehouseCode());
        info.setSupplierCode(itemPo.getSupplierCode());
        info.setMaterialCode(itemPo.getMaterialCode());
        info.setBatchNo(itemPo.getBatchNo());
        info.setMaterialStatus(String.valueOf(itemPo.getMaterialStatus()));
        info.setTargetMaterialStatus(String.valueOf(itemPo.getMaterialStatus()));
        info.setSourceStockStatus(String.valueOf(itemPo.getStockStatus()));
        info.setTargetStockStatus(String.valueOf(itemPo.getStockStatus()));
        info.setRemark(itemPo.getRemark());
        return info;
    }
}
