package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.po.kit.KitOrderItemPo;
import com.jiduauto.sps.server.pojo.po.kit.KitItemPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface KitOrderItemConvertor {

    /**
     * to po
     * @param kitItemPo kitItemPo
     * @return KitOrderItemPo
     */
    @Mapping(target = "realQty", ignore = true)
    @Mapping(target = "materialNumber", source = "materialCode")
    @Mapping(target = "kitOrderNo", ignore = true)
    KitOrderItemPo toPo(KitItemPo kitItemPo);
    /**
     * to po
     * @param kitItemPos kitItemPo
     * @return KitOrderItemPo
     */
    List<KitOrderItemPo> toPo(List<KitItemPo> kitItemPos);

}
