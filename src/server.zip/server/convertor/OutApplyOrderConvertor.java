package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.OutboundApplyOrderDto;
import com.jiduauto.sps.server.pojo.po.ApplyOrderPo;
import com.jiduauto.sps.server.pojo.po.OutboundApplyOrderPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface OutApplyOrderConvertor {

    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "expectQty", source = "applySum")
    @Mapping(target = "applyUser", source = "applyer")
    @Mapping(target = "actualQty", ignore = true)
    OutboundApplyOrderPo toPo(ApplyOrderPo applyOrderPo);


    @Mapping(target = "orderTypeName", ignore = true)
    @Mapping(target = "orderStatusName", ignore = true)
    @Mapping(target = "items", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "applyer", source = "applyUser")
    @Mapping(target = "applySum", source = "expectQty")
    @Mapping(target = "applyRealSum", source= "actualQty")
    OutboundApplyOrderDto toDto(OutboundApplyOrderPo po);


}
