package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PurchaseOrderOperateLogDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderOperateLogDto;
import com.jiduauto.sps.server.pojo.po.PurchaseOrderOperateLogPo;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderOperateLogPo;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface PurchaseReturnOrderOperateLogConvertor {

      /**
       * toDto
      @param purchaseReturnOrderOperateLogPo po
     * @return dto*/
    @Mapping(target = "newValue", expression = "java(com.jiduauto.sps.server.Enum.ROStatusEnum.getName(purchaseReturnOrderOperateLogPo.getNewValue()))")
    PurchaseReturnOrderOperateLogDto toDto(PurchaseReturnOrderOperateLogPo purchaseReturnOrderOperateLogPo);
    /**
     * toDto
     * @param purchaseReturnOrderOperateLogPoList poList
     * @return dto*/
    List<PurchaseReturnOrderOperateLogDto> toDtoList(List<PurchaseReturnOrderOperateLogPo> purchaseReturnOrderOperateLogPoList);


}
