package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderStatusLogDto;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderStatusLogPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface PurchaseApplyOrderStatusLogConvertor {

      /**
       * toDto
      @param po po
     * @return dto*/
      @Mapping(target = "newValue", expression = "java(com.jiduauto.sps.server.Enum.PRStatusEnum.getName(po.getNewValue()))")
      PurchaseApplyOrderStatusLogDto toDto(PurchaseApplyOrderStatusLogPo po);
    /**
     * toDto
     * @param poList poList
     * @return dtoList*/
    List<PurchaseApplyOrderStatusLogDto> toDtoList(List<PurchaseApplyOrderStatusLogPo> poList);


}
