package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.client.req.IndirectAsnSyncSrmReq;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import org.springframework.stereotype.Component;

@Component
public class IndirectAsnReqConvertor {

    //todo
    public IndirectAsnSyncSrmReq toReq(InAndOutStockRequest request) {
        IndirectAsnSyncSrmReq req = IndirectAsnSyncSrmReq.newInstance();
        req.setReq(request);
        return req;
    }
}
