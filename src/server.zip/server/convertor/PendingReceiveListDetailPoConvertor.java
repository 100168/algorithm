package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PendingReceiveListDetailDto;
import com.jiduauto.sps.server.pojo.dto.stock.StockOutOrderItemAllDto;
import com.jiduauto.sps.server.pojo.po.PendingReceiveListDetailPo;
import com.jiduauto.sps.server.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.server.pojo.vo.req.PendingReceiveListReceiveReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PendingReceiveListDetailPoConvertor {

    /**
     * po to dto
     *
     * @param po po
     * @return dto
     */
    @Mapping(target = "stageName", ignore = true)
    @Mapping(target = "projectName", ignore = true)
    @Mapping(target = "qty", ignore = true)
    @Mapping(target = "supplierName", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    PendingReceiveListDetailDto toDto(PendingReceiveListDetailPo po);


    /**
     * dto to po
     *
     * @param dto dto
     * @return po
     */
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    PendingReceiveListDetailPo toPo(PendingReceiveListDetailDto dto);

    /**
     * dto to po
     *
     * @param dto dto
     * @return po
     */
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    List<PendingReceiveListDetailPo> toPo(List<PendingReceiveListDetailDto> dto);


    @Mapping(target = "supplierName", ignore = true)
    @Mapping(target = "stageName", ignore = true)
    @Mapping(target = "projectName", ignore = true)
    @Mapping(target = "outOrderNo", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    @Mapping(target = "lineNo", source = "po.materialLineNo")
    @Mapping(target = "expectQty", source = "po.qty")
    @Mapping(target = "businessBillNo", source = "po.purchaseOrderNo")
    @Mapping(target = "actualQty", ignore = true)
    @Mapping(target = "id", ignore = true)
    PendingReceiveListDetailDto toDto(WarehouseDistributeItemPo po);

    @Mapping(target = "stageName", ignore = true)
    @Mapping(target = "qty", source = "outQuantity")
    @Mapping(target = "projectName", ignore = true)
    @Mapping(target = "outOrderNo", source = "orderNumber")
    @Mapping(target = "materialCode", source = "materialNumber")
    @Mapping(target = "lineNo", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "detailRemark", ignore = true)
    @Mapping(target = "businessBillNo", ignore = true)
    @Mapping(target = "bizType", expression = "java(com.jiduauto.sps.server.Enum.BizTypeEnum.JADT.getBizType())")
    @Mapping(target = "actualQty", ignore = true)
    @Mapping(target = "columnProjectNo", ignore = true)
    @Mapping(target = "supplierCode", ignore = true)
    @Mapping(target = "materialBarCode", ignore = true)
    PendingReceiveListDetailDto outToDto(StockOutOrderItemAllDto po);

    List<PendingReceiveListDetailDto> outToDto(List<StockOutOrderItemAllDto> po);

    @Mapping(target = "qty", source = "expectQty")
    PendingReceiveListReceiveReq.Detail toReq(PendingReceiveListDetailPo po);

    List<PendingReceiveListReceiveReq.Detail> toReq(List<PendingReceiveListDetailPo> po);

}
