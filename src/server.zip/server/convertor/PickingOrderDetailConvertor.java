package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PickingOrderDetailUpdateDto;
import com.jiduauto.sps.server.pojo.dto.PickingOrderDetailUpdateReq;
import com.jiduauto.sps.server.pojo.po.PickingOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface PickingOrderDetailConvertor {
    /**
     * stockItemPo to PickingOrderDetailPo
     * @param stockItemPo stockItemPo
     * @return PickingOrderDetailPo;
     */
    @Mapping(target = "outApplyOrderNo", ignore = true)
    @Mapping(target = "refItemId", ignore = true)
    @Mapping(target = "pickingOrderNo", ignore = true)
    @Mapping(target = "expectQty", ignore = true)
    @Mapping(target = "actualQty", ignore = true)
    PickingOrderDetailPo toPo(StockItemPo stockItemPo);

    /**
     * stockItemPo to PickingOrderDetailPo
     * @param po stockItemPo
     * @return PickingOrderDetailUpdateDto;
     */
    @Mapping(target = "outApplyOrderNo", ignore = true)
    @Mapping(target = "refItemId", ignore = true)
    @Mapping(target = "subtractQty", ignore = true)
    @Mapping(target = "addQty", ignore = true)
    PickingOrderDetailUpdateDto toDto(PickingOrderDetailPo po);

    /**
     * stockItemPo to PickingOrderDetailPo
     * @param po stockItemPo
     * @return PickingOrderDetailUpdateDto;
     */
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "pickingOrderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "expectQty", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "outApplyOrderNo", ignore = true)
    @Mapping(target = "refItemId", ignore = true)
    PickingOrderDetailPo toPo(PickingOrderDetailUpdateReq po);

}
