package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PurchaseApplyOrderDetailConvertor {

    /**
     * poToDto
     * @param po po
     * @return PurchaseApplyOrderDetailDto
     */
    @Mapping(target = "lingkeSaleOrderSumQty", ignore = true)
    @Mapping(target = "lingkeBackOrderSumQty", ignore = true)
    @Mapping(target = "dbFlag", ignore = true)
    @Mapping(target = "warehouseName", ignore = true)
    @Mapping(target = "warehouseCode", ignore = true)
    @Mapping(target = "supplierName", ignore = true)
    @Mapping(target = "supplierCode", ignore = true)
    @Mapping(target = "sapOrderNo", ignore = true)
    @Mapping(target = "orderTypeDesc", ignore = true)
    @Mapping(target = "orderType", ignore = true)
    @Mapping(target = "orderStatusDesc", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "orderNo", ignore = true)
    @Mapping(target = "moq", ignore = true)
    @Mapping(target = "companyCode", ignore = true)
    @Mapping(target = "auditOpinion", ignore = true)
    @Mapping(target = "actualArrivalTime", ignore = true)
    @Mapping(target = "salePartName", ignore = true)
    @Mapping(target = "orderUnit", ignore = true)
    PurchaseApplyOrderDetailDto toDto(PurchaseApplyOrderDetailPo po);

    /**
     * reqToPo
     * @param req req
     * @return PurchaseApplyOrderDetailPo
     */
    @Mapping(target = "ledgerCode", source = "req.contractNo")
    @Mapping(target = "spsStatus", ignore = true)
    @Mapping(target = "lingkeReason", ignore = true)
    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "saleOrderNo", ignore = true)
    @Mapping(target = "purchaseOrderNo", ignore = true)
    @Mapping(target = "lineNo", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "receiveQty", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "deliverQty", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "contractNo", ignore = true)
    PurchaseApplyOrderDetailPo toPo(PurchaseApplyOrderDetailAddReq req);

    /**
     * reqToPo
     * @param item item
     * @return PurchaseApplyOrderDetailPo
     */
    @Mapping(target = "spsStatus", ignore = true)
    @Mapping(target = "lingkeReason", ignore = true)
    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "saleOrderNo", ignore = true)
    @Mapping(target = "purchaseOrderNo", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "receiveQty", ignore = true)
    @Mapping(target = "orderId", ignore = true)
    @Mapping(target = "lineNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "deliverQty", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "contractNo", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    PurchaseApplyOrderDetailPo importReqToPo(PurchaseApplyOrderDetailImportReq item);

    @Mapping(target = "spsStatus", ignore = true)
    @Mapping(target = "lingkeReason", ignore = true)
    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "saleOrderNo", ignore = true)
    @Mapping(target = "purchaseOrderNo", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "receiveQty", ignore = true)
    @Mapping(target = "orderId", ignore = true)
    @Mapping(target = "lineNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "deliverQty", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    @Mapping(target = "estArrivalTime", expression = "java(cn.hutool.core.date.DateUtil.parse(item.getEstArrivalTime(), com.jiduauto.sps.server.utils.DateUtils.SHORT_DATE_FORMAT).toDateStr())")
    PurchaseApplyOrderDetailPo importReqToPo(PurchaseApplyOrderImportReq item);

    @Mapping(target = "spsStatus", ignore = true)
    @Mapping(target = "lingkeReason", ignore = true)
    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "salePartNum", ignore = true)
    @Mapping(target = "saleOrderNo", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "receiveQty", ignore = true)
    @Mapping(target = "purchaseOrderNo", ignore = true)
    @Mapping(target = "orderUnit", ignore = true)
    @Mapping(target = "orderId", ignore = true)
    @Mapping(target = "lineNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "deliverQty", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "contractNo", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    PurchaseApplyOrderDetailPo editToPo(PurchaseApplyOrderDetailAuditEditReq.Detail detail);

    List<PurchaseApplyOrderDetailPo> editToPo(List<PurchaseApplyOrderDetailAuditEditReq.Detail> detail);

    @Mapping(target = "poType", expression = "java(com.jiduauto.sps.server.Enum.PRTypeEnum.getByCode(po.getOrderType()).getLingkeCode())")
    @Mapping(target = "partNo", source = "detailPo.salePartNum")
    @Mapping(target = "dealerCode", ignore = true)
    @Mapping(target = "brandName", ignore = true)
    @Mapping(target = "POCode", source = "po.sapOrderNo")
    @Mapping(target = "DDItemNo", source = "detailPo.lineNo")
    PRDetailCancelReq toCancelReq(PurchaseApplyOrderPo po, PurchaseApplyOrderDetailPo detailPo);
}
