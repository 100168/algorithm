package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.InternalSoDto;
import com.jiduauto.sps.server.pojo.dto.SaleOrderDto;
import com.jiduauto.sps.server.pojo.po.SaleOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.InternalBoSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.InternalSoSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.SaleOrderPageSearchReq;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface SaleOrderConvertor {

    /**转外部
     * @param internalSoSearchReq
     * @return */
    @Mapping(target = "saleOrderNos", ignore = true)
    @Mapping(target = "transferAdvice", ignore = true)
    @Mapping(target = "storeCode", ignore = true)
    @Mapping(target = "salePartNumLike", ignore = true)
    @Mapping(target = "salePartNum", ignore = true)
    @Mapping(target = "saleOrderType", ignore = true)
    @Mapping(target = "saleOrderStatus", ignore = true)
    @Mapping(target = "saleOrderNo", ignore = true)
    @Mapping(target = "receiveWarehouseCode", ignore = true)
    @Mapping(target = "isDfs", ignore = true)
    @Mapping(target = "dfsStatus", ignore = true)
    @Mapping(target = "deliverWarehouseCode", ignore = true)
    @Mapping(target = "createTimeStart", ignore = true)
    @Mapping(target = "createTimeEnd", ignore = true)
    SaleOrderPageSearchReq toReq(InternalSoSearchReq internalSoSearchReq);

}
