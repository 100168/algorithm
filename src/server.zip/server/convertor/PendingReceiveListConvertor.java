package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.server.pojo.dto.PendingReceiveListDto;
import com.jiduauto.sps.server.pojo.po.PendingReceiveListPo;
import com.jiduauto.sps.server.pojo.po.StockOutOrderPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PendingReceiveListConvertor {

    /**
     * po to dto
     *
     * @param po dto
     * @return dto
     */
    @Mapping(target = "orderStatus", expression = "java(com.jiduauto.sps.server.Enum.PendingReceiveListStatus.getDesc(po.getOrderStatus()))")
    @Mapping(target = "orderStatusCode", source = "po.orderStatus")
    PendingReceiveListDto toDto(PendingReceiveListPo po);

    /**
     * dto to po
     *
     * @param dto dto
     * @return po
     */
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    PendingReceiveListPo toPo(PendingReceiveListDto dto);


    @Mapping(target = "orderStatusCode", ignore = true)
    @Mapping(target = "warehouseCode", ignore = true)
    @Mapping(target = "outOrderNo", source = "po.businessBillNo")
    @Mapping(target = "materialQty", ignore = true)
    @Mapping(target = "expectQty", ignore = true)
    @Mapping(target = "estArrivalTime", ignore = true)
    @Mapping(target = "actualQty", ignore = true)
    @Mapping(target = "id", ignore = true)
    PendingReceiveListDto toDto(WarehouseDistributeOrderPo po);


    @Mapping(target = "warehouseCode", ignore = true)
    @Mapping(target = "shipperContact", ignore = true)
    @Mapping(target = "shipper", ignore = true)
    @Mapping(target = "receiveType", ignore = true)
    @Mapping(target = "outOrderNo", source = "orderNumber")
    @Mapping(target = "orderType", expression = "java(com.jiduauto.sps.server.Enum.PendingReceiveListTypeEnum.CGRK.getCode())")
    @Mapping(target = "orderStatusCode", ignore = true)
    @Mapping(target = "orderStatus", expression = "java(com.jiduauto.sps.server.Enum.PendingReceiveListStatus.PUT.getCode())")
    @Mapping(target = "materialQty", ignore = true)
    @Mapping(target = "expectQty", ignore = true)
    @Mapping(target = "estArrivalTime", ignore = true)
    @Mapping(target = "actualQty", ignore = true)
    @Mapping(target = "bizType", expression = "java(com.jiduauto.sps.server.Enum.BizTypeEnum.JADT.getBizType())")
    PendingReceiveListDto toDto(StockOutOrderPo po);
}
