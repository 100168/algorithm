package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.stock.StockInOrderItemDto;
import com.jiduauto.sps.server.pojo.po.StockInOrderItemPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface StockInOrderDetailPoConvertor {

    @Mapping(target = "warehouseName", ignore = true)
    @Mapping(target = "supplierContactName", ignore = true)
    @Mapping(target = "supplierContactMobile", ignore = true)
    @Mapping(target = "pmuxName", ignore = true)
    @Mapping(target = "pmux", ignore = true)
    @Mapping(target = "partTypeName", ignore = true)
    @Mapping(target = "partTypeCode", ignore = true)
    @Mapping(target = "measurementUnitName", ignore = true)
    @Mapping(target = "measurementUnit", ignore = true)
    @Mapping(target = "materialTypeName", ignore = true)
    @Mapping(target = "materialType", ignore = true)
    @Mapping(target = "materialStatusName", ignore = true)
    @Mapping(target = "materialStandardName", ignore = true)
    @Mapping(target = "materialStandard", ignore = true)
    @Mapping(target = "materialSortName", ignore = true)
    @Mapping(target = "materialAttributeName", ignore = true)
    @Mapping(target = "materialAttribute", ignore = true)
    @Mapping(target = "locationName", ignore = true)
    @Mapping(target = "carCodeName", ignore = true)
    @Mapping(target = "areaName", ignore = true)
    @Mapping(target = "stageName", ignore = true)
    @Mapping(target = "projectName", ignore = true)
    @Mapping(target = "count", ignore = true)
    @Mapping(target = "supplierName", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    StockInOrderItemDto toDto(StockInOrderItemPo po);
}
