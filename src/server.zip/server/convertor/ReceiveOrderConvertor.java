package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.ReceiveOrderDto;
import com.jiduauto.sps.server.pojo.po.PendingReceiveListPo;
import com.jiduauto.sps.server.pojo.po.ReceiveOrderPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ReceiveOrderConvertor {

    @Mapping(target = "orderType", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    ReceiveOrderDto toDto(ReceiveOrderPo po);


    @Mapping(target = "stockSource", expression = "java(com.jiduauto.sps.server.consts.StockSource.SYS.getCode())")
    @Mapping(target = "receiveDate", ignore = true)
    @Mapping(target = "qty", ignore = true)
    @Mapping(target = "outBusinessBillNo", ignore = true)
    @Mapping(target = "orderNo", ignore = true)
    ReceiveOrderPo toPo(PendingReceiveListPo po);

}
