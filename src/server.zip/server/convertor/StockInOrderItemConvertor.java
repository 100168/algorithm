package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.ReceiveOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.ReceiveOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.StockInOrderItemPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface StockInOrderItemConvertor {


    /**
     * receiveOrderDetailDto to StockInOrderItemPo
     *
     * @param receiveOrderDetailDto receiveOrderDetailDto
     * @return po
     */
    @Mapping(target = "recommendLocationCode", ignore = true)
    @Mapping(target = "rackStockKey", ignore = true)
    @Mapping(target = "workbinCode", ignore = true)
    @Mapping(target = "wbsCode", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "sequenceNo", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "purchaseOrderNo", source = "businessBillNo")
    @Mapping(target = "pssType", ignore = true)
    @Mapping(target = "productDate", ignore = true)
    @Mapping(target = "planInQuantity", source = "qty")
    @Mapping(target = "palletCode", ignore = true)
    @Mapping(target = "orderNumber", ignore = true)
    @Mapping(target = "materialNumber", source = "materialCode")
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "inQuantity", source = "qty")
    @Mapping(target = "expireDate", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "delRight", expression = "java(0)")
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "carCode", ignore = true)
    @Mapping(target = "batchNo", ignore = true)
    @Mapping(target = "id", ignore = true)
    StockInOrderItemPo toStockInOrderPo(ReceiveOrderDetailDto receiveOrderDetailDto);

    /**
     * receiveOrderDetailDto to StockInOrderItemPo
     *
     * @param receiveOrderDetailDtoList receiveOrderDetailDto
     * @return po
     */
    List<StockInOrderItemPo> toStockInOrderPo(List<ReceiveOrderDetailDto> receiveOrderDetailDtoList);

    /**
     * receiveOrderDetailDto to StockInOrderItemPo
     *
     * @param ReceiveOrderDetailPo receiveOrderDetailDto
     * @return po
     */

    @Mapping(target = "delRight", ignore = true)
    @Mapping(target = "rackStockKey", ignore = true)
    @Mapping(target = "recommendLocationCode", ignore = true)
    @Mapping(target = "purchaseOrderNo", source = "businessBillNo")
    @Mapping(target = "planInQuantity", source = "qty")
    @Mapping(target = "orderNumber", ignore = true)
    @Mapping(target = "materialNumber", source = "materialCode")
    @Mapping(target = "inQuantity", source = "qty")
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "expireDate", ignore = true)
    @Mapping(target = "productDate", ignore = true)
    StockInOrderItemPo toStockInOrderPo(ReceiveOrderDetailPo po);

}
