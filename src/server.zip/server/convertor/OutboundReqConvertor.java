package com.jiduauto.sps.server.convertor;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.server.Enum.*;
import com.jiduauto.sps.server.caches.DictItemCache;
import com.jiduauto.sps.server.caches.WarehouseCache;
import com.jiduauto.sps.server.client.req.DHLOutboundReq;
import com.jiduauto.sps.server.client.req.DHLOutboundReq.Detail;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.BaseConstants.OperateType;
import com.jiduauto.sps.server.consts.BaseConstants.StockStatus;
import com.jiduauto.sps.server.consts.DhlOutboundOrderType;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderItemPo;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderPo;
import com.jiduauto.sps.server.service.IKitOrderItemService;
import com.jiduauto.sps.server.service.IMaterialService;
import com.jiduauto.sps.server.service.IPurchaseReturnOrderDetailService;
import com.jiduauto.sps.server.service.IWarehouseService;
import com.jiduauto.sps.server.utils.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.jiduauto.sps.server.Enum.StockOperationType.JC24;
import static com.jiduauto.sps.server.Enum.StockOperationType.SP_24;

/**
 * @author panjian
 */
@Component
public class OutboundReqConvertor {

    @Resource
    private DictItemCache dictItemCache;
    @Resource
    private IPurchaseReturnOrderDetailService purchaseReturnOrderDetailService;

    @Resource
    private IKitOrderItemService kitOrderItemService;

    @Resource
    private IWarehouseService warehouseService;

    @Resource
    private IMaterialService materialService;

    @Resource
    private WarehouseCache warehouseCache;

    public DHLOutboundReq toDhlOutBoundReq(PurchaseReturnOrderPo purchaseReturnOrderPo) {
        List<PurchaseReturnOrderDetailPo> detailPos = purchaseReturnOrderDetailService.listByOrderNo(
                purchaseReturnOrderPo.getOrderNo(), purchaseReturnOrderPo.getBizType());
        Map<String, String> mapLocationMap = dictItemCache.getCodeAndNameMap(
                DictEnum.MapLocationDistrict.getDictCode());
        DHLOutboundReq req = new DHLOutboundReq();
        req.setBizType(purchaseReturnOrderPo.getBizType());
        req.setOrderTime(purchaseReturnOrderPo.getAuditTime());
        req.setOutboundBillNo(purchaseReturnOrderPo.getOrderNo());
        req.setOutboundType(RoOutboundTypeEnum.getOutType(purchaseReturnOrderPo.getBizType()));
        req.setOperateType(OperateType.ADD);
        req.setOrderType(DhlOutboundOrderType.NT.getOrderType());
        req.setTransferAdvice(ShippingMethodEnum.SPK.getCode());
        req.setDeliverWarehouseCode(purchaseReturnOrderPo.getWarehouseCode());
        req.setReceiver(purchaseReturnOrderPo.getContact());
        req.setReceiverProvince(mapLocationMap.get(purchaseReturnOrderPo.getProvinceCode()));
        req.setReceiverCity(mapLocationMap.get(purchaseReturnOrderPo.getCityCode()));
        req.setReceiverDistrict(mapLocationMap.get(purchaseReturnOrderPo.getDistrictCode()));
        req.setReceiverAddress(purchaseReturnOrderPo.getAddress());
        req.setReceiverPhone(purchaseReturnOrderPo.getTelephone());
        List<Detail> details = detailPos.stream().map(item -> {
            Detail detail = new Detail();
            detail.setLineNo(String.valueOf(item.getLineNo()));
            detail.setSalePartNum(item.getSalePartNum());
            detail.setQuantity(item.getQty());
            detail.setMaterialStatus(MaterialStatusEnum.NORMAL.getValue());
            detail.setStockStatus(StockStatus.FROZEN);
            return detail;
        }).collect(Collectors.toList());
        req.setDetailList(details);
        return req;
    }

    public DHLOutboundReq toDhlOutBoundReq(KitOrderPo orderPo) {
        List<KitOrderItemPo> itemPos = kitOrderItemService.list(Wrappers.<KitOrderItemPo>lambdaQuery().eq(KitOrderItemPo::getKitOrderNo, orderPo.getKitOrderNo()));

        WarehousePo warehousePo = warehouseService.getByBizAndCode(orderPo.getBizType(), orderPo.getWarehouseCode());
        DHLOutboundReq req = new DHLOutboundReq();
        req.setBizType(orderPo.getBizType());
        req.setOrderTime(orderPo.getUpdateTime());
        req.setOutboundBillNo(orderPo.getKitOrderNo());
        if(BizTypeEnum.SP.getBizType().equals(orderPo.getBizType())){
            req.setOutboundType(SP_24.getOperationType());
        }else if(BizTypeEnum.JC.getBizType().equals(orderPo.getBizType())){
            req.setOutboundType(JC24.getOperationType());
        }
        req.setOperateType(OperateType.ADD);
        if (orderPo.getOrderStatus().equals(KitOrderStatusEnum.CANCELED.getCode())) {
            req.setOperateType(OperateType.CANCEL);
        }
        req.setOrderType(DhlOutboundOrderType.KIT.getOrderType());
        req.setTransferAdvice(ShippingMethodEnum.NT.getCode());
        req.setDeliverWarehouseCode(orderPo.getWarehouseCode());
        req.setReceiver(warehousePo.getContact());
        req.setReceiveWarehouseName(warehousePo.getName());
        req.setReceiverAddress(warehousePo.getAddress());
        req.setReceiverPhone(warehousePo.getPhoneNumber());
        List<Detail> details = new ArrayList<>();
        KitOrderTypeEnum typeEnum = KitOrderTypeEnum.getByCode(orderPo.getOrderType());
        switch (typeEnum) {
            //KIT拆解  KIT总成件出库
            case DISASSEMBLE: {
                Detail detail = new Detail();
                detail.setBizType(orderPo.getBizType());
                detail.setLineNo("01");
                detail.setSalePartNum(orderPo.getMaterialNumber());
                detail.setQuantity(orderPo.getQty());
                detail.setMaterialStatus(MaterialStatusEnum.NORMAL.getValue());
                detail.setStockStatus(StockStatus.NORMAL);
                details.add(detail);
                break;
            }
            //kit组装  KIT子件出库
            case ASSEMBLE: {
                details = itemPos.stream().map(item -> {
                    Detail detail = new Detail();
                    detail.setBizType(item.getBizType());
                    detail.setLineNo(String.valueOf(item.getLineNo()));
                    detail.setSalePartNum(item.getMaterialNumber());
                    detail.setQuantity(item.getQty());
                    detail.setMaterialStatus(MaterialStatusEnum.NORMAL.getValue());
                    detail.setStockStatus(StockStatus.NORMAL);
                    return detail;
                }).collect(Collectors.toList());
                break;
            }
            default:

        }
        req.setDetailList(details);
        return req;
    }

    public DHLOutboundReq toDhlOutBoundReq(WarehouseDistributeOrderPo distributeOrderPo,
                                           List<WarehouseDistributeItemPo> detailPos,
                                           WarehouseDistributeLogisticPo logisticPo,
                                           String operateType) {
        Map<String, String> mapLocationMap = dictItemCache.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());
        DHLOutboundReq req = new DHLOutboundReq();
        req.setBizType(distributeOrderPo.getBizType());
        req.setOrderTime(distributeOrderPo.getOrderTime());
        req.setOrderType("TOC");
        req.setOutboundBillNo(distributeOrderPo.getOrderNo());
        req.setOutboundType(StockOperationType.SM20.getOperationType());
        req.setOperateType(operateType);
        req.setTransferAdvice(logisticPo.getShippingMethod());
        req.setDeliverWarehouseCode(logisticPo.getDeliverWarehouseCode());
        req.setReceiver(logisticPo.getReceiver());
        req.setReceiverProvince(logisticPo.getReceiveProvinceName());
        req.setReceiverCity(logisticPo.getReceiveCityName());
        req.setReceiverDistrict(logisticPo.getReceiveDistrictName());
        req.setReceiverAddress(logisticPo.getReceiveAddress());
        req.setReceiverPhone(logisticPo.getReceiverContact());
        if (StrUtil.isEmpty(req.getReceiverCity())){
            req.setReceiverCity(mapLocationMap.get(logisticPo.getReceiveCityCode()));
        }
        if (StrUtil.isEmpty(req.getReceiverProvince())){
            req.setReceiverProvince(mapLocationMap.get(logisticPo.getReceiveProvinceCode()));
        }
        if (StrUtil.isEmpty(req.getReceiverDistrict())){
            req.setReceiverDistrict(mapLocationMap.get(logisticPo.getReceiveDistrictCode()));
        }
        List<Detail> details = detailPos.stream().map(item -> {
            Detail detail = new Detail();
            detail.setLineNo(item.getMaterialLineNo());
            detail.setSalePartNum(item.getMaterialCode());
            detail.setQuantity(item.getQty());
            detail.setMaterialStatus(String.valueOf(item.getMaterialStatus()));
            detail.setStockStatus(String.valueOf(item.getStockStatus()));
            return detail;
        }).collect(Collectors.toList());
        req.setDetailList(details);
        return req;
    }

    public DHLOutboundReq toDhlOutBoundReq(ApplyOrderPo applyOrderPo, List<ApplyOrderItemPo> detailPos, String operateType) {
        Map<String, String> mapLocationMap = dictItemCache.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());
        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(applyOrderPo.getBizType(), detailPos.stream().map(ApplyOrderItemPo::getMaterialCode).distinct().collect(Collectors.toList()));
        String orderNo = applyOrderPo.getApplyOrderNo();
        ApplyOrderItemPo dto = detailPos.get(0);
        DHLOutboundReq req = new DHLOutboundReq();
        req.setBizType(applyOrderPo.getBizType());
        req.setOutboundBillNo(orderNo);
        //21 内部领料出库 ：SP21、JC21
        req.setOutboundType(applyOrderPo.getBizType().concat(applyOrderPo.getOrderType()));
        req.setOrderType(DhlOutboundOrderType.RO.getOrderType());
        req.setOrderTime(dto.getCreateTime());
        req.setOperateType(operateType);
        req.setDeliverWarehouseCode(dto.getWarehouseCode());
        req.setTransferAdvice(applyOrderPo.getApplyType());
        req.setReceiver(applyOrderPo.getReceiver());
        req.setReceiverProvince(mapLocationMap.get(applyOrderPo.getReceiverProvince()));
        req.setReceiverCity(mapLocationMap.get(applyOrderPo.getReceiverCity()));
        req.setReceiverDistrict(mapLocationMap.get(applyOrderPo.getReceiverDistrict()));
        req.setReceiverPhone(applyOrderPo.getReceiverContact());
        req.setReceiverAddress(applyOrderPo.getReceiverAddress());
        if (applyOrderPo.getApplyType().equals(ApplyTypeEnum.SPK.getCode()) && StringUtils.isNotBlank(dto.getWarehouseCode())) {
            //自提的时候 收货地址 默认选择 仓库的地址
            req.setReceiverAddress(warehouseCache.getByBizAndCode(applyOrderPo.getBizType(), dto.getWarehouseCode()).getAddress());
        }
        List<DHLOutboundReq.Detail> details = new ArrayList<>();
        for (ApplyOrderItemPo item : detailPos) {
            Detail detail = getDhlDetail(materialPoMap, String.valueOf(item.getLineNo()), item.getMaterialCode());
            detail.setQuantity(item.getApplySum());
            detail.setMaterialStatus(MaterialStatusEnum.NORMAL.getValue());
            detail.setStockStatus(BaseConstants.StockStatus.NORMAL);
            details.add(detail);
        }
        req.setDetailList(details);
        return req;
    }

    public static Detail getDhlDetail(Map<String, MaterialPo> materialPoMap, String s, String materialCode) {
        Detail detail = new Detail();
        detail.setLineNo(s);
        detail.setSalePartNum(materialCode);
        MaterialPo materialPo = materialPoMap.get(materialCode);
        if (Objects.nonNull(materialPo)) {
            PartSaleFieldEnum partSaleFieldEnum = PartSaleFieldEnum.getByName(materialPo.getPartSaleField());
            if (Objects.nonNull(partSaleFieldEnum)) {
                detail.setPartSaleField(partSaleFieldEnum.getCode());
            }
        }
        return detail;

    }

}
