package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderDetailDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderExportDto;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseApplyOrderAddReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseApplyOrderEditReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseApplyOrderImportReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PurchaseApplyOrderConvertor {

    /**
     * po to dto
     * @param purchaseApplyOrderPo purchaseApplyOrderPo
     * @return PurchaseApplyOrderDto
     */
    @Mapping(target = "orderTypeDesc", ignore = true)
    @Mapping(target = "orderStatusDesc", ignore = true)
    @Mapping(target = "warehouseName", ignore = true)
    @Mapping(target = "supplierName", ignore = true)
    PurchaseApplyOrderDto toDto(PurchaseApplyOrderPo purchaseApplyOrderPo);

    /**
     * req to po
     * @param orderAddReq orderAddReq
     * @return PurchaseApplyOrderPo
     */
    @Mapping(target = "sapOrderNo", ignore = true)
    @Mapping(target = "associateOrderNo", ignore = true)
    @Mapping(target = "actualArrivalTime", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "orderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "auditOpinion", ignore = true)
    PurchaseApplyOrderPo toPo(PurchaseApplyOrderAddReq orderAddReq);

    /**
     * req to po
     * @param orderEditReq orderEditReq
     * @return PurchaseApplyOrderPo
     */
    @Mapping(target = "sapOrderNo", ignore = true)
    @Mapping(target = "associateOrderNo", ignore = true)
    @Mapping(target = "actualArrivalTime", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "orderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "auditOpinion", ignore = true)
    PurchaseApplyOrderPo toPo(PurchaseApplyOrderEditReq orderEditReq);

    /**
     * to PurchaseApplyOrderExportDto
     *
     * @param purchaseApplyOrderDetailDto purchaseApplyOrderDetailDto
     * @return PurchaseApplyOrderExportDto
     */
    @Mapping(target = "dbFlag", expression = "java(com.jiduauto.sps.server.utils.BooleanUtil.toChinese(purchaseApplyOrderDetailDto.getDbFlag()))")
    @Mapping(target = "createTime", expression = "java(cn.hutool.core.date.DateUtil.formatLocalDateTime(purchaseApplyOrderDetailDto.getCreateTime()))")
    @Mapping(target = "updateTime", expression = "java(cn.hutool.core.date.DateUtil.formatLocalDateTime(purchaseApplyOrderDetailDto.getUpdateTime()))")
    PurchaseApplyOrderExportDto toExportDto(PurchaseApplyOrderDetailDto purchaseApplyOrderDetailDto);

    /**
     * to PurchaseApplyOrderExportDto
     *
     * @param list list
     * @return PurchaseApplyOrderExportDto
     */
    List<PurchaseApplyOrderExportDto> toExportDto(List<PurchaseApplyOrderDetailDto> list);


    /**
     * req to po
     *
     * @param importReq importReq
     * @return PurchaseApplyOrderPo
     */
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "sapOrderNo", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "orderStatus", expression = "java(com.jiduauto.sps.server.Enum.PRStatusEnum.WAIT_COMMIT.getItemCode())")
    @Mapping(target = "orderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    @Mapping(target = "auditOpinion", ignore = true)
    @Mapping(target = "associateOrderNo", ignore = true)
    @Mapping(target = "actualArrivalTime", ignore = true)
    PurchaseApplyOrderPo toPo(PurchaseApplyOrderImportReq importReq);
}
