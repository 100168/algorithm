package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.stock.StockAllDto;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import com.jiduauto.sps.server.pojo.vo.resp.stock.InternalStockItemResp;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface StockItemConvert {

    /**
     * to resp
     * @param stockAllDto stockPo
     * @return InternalStockDetailSearchResp
     */
    @Mapping(target = "materialCode", source = "materialNumber")
    InternalStockItemResp toResp(StockAllDto stockAllDto);

    /**
     * to resp
     * @param stockAllDtoList stockAllDtoList
     * @return list
     */
    List<InternalStockItemResp> toRespList(List<StockAllDto> stockAllDtoList);

    /**
     * to dto
     * @param stockItemPo stockItemPo
     * @return StockAllDto
     */
    @Mapping(target = "occupyQuantity", ignore = true)
    @Mapping(target = "supplierName", ignore = true)
    @Mapping(target = "pmux", ignore = true)
    @Mapping(target = "partTypeName", ignore = true)
    @Mapping(target = "partTypeCode", ignore = true)
    @Mapping(target = "measurementUnit", ignore = true)
    @Mapping(target = "materialType", ignore = true)
    @Mapping(target = "materialStandard", ignore = true)
    @Mapping(target = "materialNumber", source = "materialCode")
    @Mapping(target = "materialName", ignore = true)
    @Mapping(target = "materialAttribute", ignore = true)
    StockAllDto toDto(StockItemPo stockItemPo);
    /**
     * to dto
     * @param stockItemPos stockPos
     * @return List
     */
    List<StockAllDto> toDtoList(List<StockItemPo> stockItemPos);

}
