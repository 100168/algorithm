package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.baseData.LocationInfo;
import com.jiduauto.sps.server.pojo.po.LocationsPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface LocationConvertor {

    @Mapping(target = "locationName", source = "po.name")
    @Mapping(target = "locationCode", source = "po.code")
    LocationInfo toInfo(LocationsPo po);

    List<LocationInfo> toInfo(List<LocationsPo> po);

}
