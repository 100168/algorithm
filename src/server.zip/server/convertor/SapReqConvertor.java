package com.jiduauto.sps.server.convertor;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.Enum.PRTypeEnum;
import com.jiduauto.sps.server.caches.DictItemCache;
import com.jiduauto.sps.server.client.req.DelOrderPlanSyncForModeFReq;
import com.jiduauto.sps.server.client.req.DfsOrderPlanSyncReq;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.service.impl.SpsOrderDataQuery;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author panjian
 */
@Component
public class SapReqConvertor {
    @Resource
    private IPurchaseApplyOrderDetailService purchaseApplyOrderDetailService;
    @Resource
    private IPurchaseApplyOrderService purchaseApplyOrderService;
    @Resource
    private IWarehouseService warehouseService;
    @Resource
    private IMaterialService materialService;

    @Resource
    private IStoreService storeService;

    @Resource
    private SpsOrderDataQuery spsOrderDataQuery;

    @Resource
    private IDbService dbService;

    @Resource
    private DictItemCache dictItemCache;

    public DfsOrderPlanSyncReq toDfsOrderPlanSyncReq(PurchaseApplyOrderPo po) {

        List<PurchaseApplyOrderDetailPo> detailPos = purchaseApplyOrderDetailService.listByOrderId(po.getId());
        List<String> materialCodes = detailPos.stream().map(PurchaseApplyOrderDetailPo::getSalePartNum).collect(Collectors.toList());
        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(po.getBizType(), materialCodes);
        WarehousePo warehousePo = warehouseService.getByBizAndCode(po.getBizType(), po.getWarehouseCode());
        DfsOrderPlanSyncReq roSyncSrmReq = DfsOrderPlanSyncReq.newInstance();


        if (PRTypeEnum.isCoOrDfs(po.getOrderType())) {
            PurchaseOrderPo one = spsOrderDataQuery.selectPO(detailPos.get(0).getPurchaseOrderNo());
            // 获取门店名称
            StorePo storePo = storeService.getOne(Wrappers.<StorePo>lambdaQuery().eq(StorePo::getBizType, po.getBizType())
                    .eq(StorePo::getStoreCode, one.getStoreCode()));
            if (PRTypeEnum.DFS.getCode().equals(po.getOrderType())) {
                //dfs 收货仓库信息是 门店仓库
                Map<String, String> mapLocationMap = dictItemCache.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());

                String provinceName = mapLocationMap.getOrDefault(one.getReceiverProvince(), "");
                String cityName = mapLocationMap.getOrDefault(one.getReceiverCity(), "");
                String districtName = mapLocationMap.getOrDefault(one.getReceiverDistrict(), "");
                one.setReceiverAddress(provinceName+cityName+districtName+one.getReceiverAddress());
                WarehousePo dfsPo = warehouseService.getByBizAndCode(BizTypeEnum.getNewBizType(po.getBizType()), po.getWarehouseCode());
                roSyncSrmReq.setPurchaseApplyOrderCoAndDfs(po, detailPos, materialPoMap, one, dfsPo, storePo);

            } else {
                roSyncSrmReq.setPurchaseApplyOrderCoAndDfs(po, detailPos, materialPoMap, one, warehousePo, storePo);
            }
            return roSyncSrmReq;
        }

        roSyncSrmReq.setPurchaseApplyOrder(po, detailPos, materialPoMap);
        roSyncSrmReq.setPrWarehouse(warehousePo);
        if (PRTypeEnum.DB.getCode().equals(po.getOrderType())) {
            List<PurchaseApplyOrderPo> dbSub = purchaseApplyOrderService.list(Wrappers.<PurchaseApplyOrderPo>lambdaQuery()
                    .eq(PurchaseApplyOrderPo::getAssociateOrderNo, po.getOrderNo()));
            for (PurchaseApplyOrderPo purchaseApplyOrderPo : dbSub) {
                List<PurchaseApplyOrderDetailPo> dbSubItems = purchaseApplyOrderDetailService.listByOrderId(purchaseApplyOrderPo.getId());
                roSyncSrmReq.setSubItem(purchaseApplyOrderPo, dbSubItems);
            }
        }
        return roSyncSrmReq;
    }

    public DelOrderPlanSyncForModeFReq toDelOrderPlanSyncForModeFReq(PurchaseApplyOrderPo po, List<PurchaseApplyOrderDetailPo> detailPos) {
        List<String> materialCodes = detailPos.stream().map(PurchaseApplyOrderDetailPo::getSalePartNum).collect(Collectors.toList());
        WarehousePo warehousePo = warehouseService.getByBizAndCode(po.getBizType(), po.getWarehouseCode());
        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(po.getBizType(), materialCodes);
        DelOrderPlanSyncForModeFReq delOrderPlanSyncForModeFReq = DelOrderPlanSyncForModeFReq.newInstance();
        if (PRTypeEnum.DFS.getCode().equals(po.getOrderType())) {
            PurchaseOrderPo one = spsOrderDataQuery.selectPO(detailPos.get(0).getPurchaseOrderNo());
            Map<String, String> mapLocationMap = dictItemCache.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());

            String provinceName = mapLocationMap.getOrDefault(one.getReceiverProvince(), "");
            String cityName = mapLocationMap.getOrDefault(one.getReceiverCity(), "");
            String districtName = mapLocationMap.getOrDefault(one.getReceiverDistrict(), "");
            one.setReceiverAddress(provinceName+cityName+districtName+one.getReceiverAddress());

            delOrderPlanSyncForModeFReq.setPurchaseApplyOrderDfs(po, detailPos, materialPoMap, one);
            delOrderPlanSyncForModeFReq.setPRWarehouseDfs(warehousePo);
            return delOrderPlanSyncForModeFReq;
        }
        delOrderPlanSyncForModeFReq.setPurchaseApplyOrder(po, detailPos, materialPoMap);
        delOrderPlanSyncForModeFReq.setPRWarehouse(warehousePo);
        //db 变更也要传子件信息,db子成件只有一个明细
        if (PRTypeEnum.DB.getCode().equals(po.getOrderType())) {
            for (PurchaseApplyOrderDetailPo detailPo : detailPos) {
                List<DbPo> dbItemPos = dbService.getByMaterialCode(detailPo.getBizType(), detailPo.getSalePartNum());
                List<PurchaseApplyOrderPo> orderPos = new ArrayList<>();
                List<Integer> lineNo = new ArrayList<>();
                for (DbPo dbItemPo : dbItemPos) {
                    PurchaseApplyOrderPo child = purchaseApplyOrderService.getChild(po.getOrderNo(), dbItemPo.getMaterialCode());
                    PurchaseApplyOrderDetailPo orderDetailPo = purchaseApplyOrderDetailService.getOne(Wrappers.<PurchaseApplyOrderDetailPo>lambdaQuery().eq(PurchaseApplyOrderDetailPo::getOrderId, child.getId()).eq(PurchaseApplyOrderDetailPo::getSalePartNum, dbItemPo.getMaterialCode()));
                    orderPos.add(child);
                    lineNo.add(orderDetailPo.getLineNo());
                }
                delOrderPlanSyncForModeFReq.setSubItem(orderPos, lineNo, dbItemPos, detailPo);
            }

        }
        return delOrderPlanSyncForModeFReq;
    }
}
