package com.jiduauto.sps.server.convertor;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.server.client.req.StockPutOutSyncReq;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderPo;
import com.jiduauto.sps.server.pojo.po.WarehousePo;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.service.IMaterialService;
import com.jiduauto.sps.server.service.IPurchaseReturnOrderDetailService;
import com.jiduauto.sps.server.service.IPurchaseReturnOrderService;
import com.jiduauto.sps.server.service.IWarehouseService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author panjian
 */
@Component
public class RoSyncReqConvertor {

    @Resource
    private IPurchaseReturnOrderService purchaseReturnOrderService;

    @Resource
    private IWarehouseService warehouseService;

    @Resource
    private IMaterialService materialService;
    @Resource
    private IPurchaseReturnOrderDetailService purchaseReturnOrderDetailService;

    @Resource
    private InAndOutStockParamConvertor inAndOutStockParamConvertor;


    public StockPutOutSyncReq toRoSyncSapReq(InAndOutStockRequest request) {

        PurchaseReturnOrderPo returnOrderPo = purchaseReturnOrderService.getOne(Wrappers.<PurchaseReturnOrderPo>lambdaQuery()
                .eq(PurchaseReturnOrderPo::getBizType, request.getBizType())
                .eq(PurchaseReturnOrderPo::getOrderNo, request.getTradeNo())
        );
        if (Objects.isNull(returnOrderPo)) {
            throw new BizException("采购退货不存在");
        }
        Map<Integer, PurchaseReturnOrderDetailPo> detailPoMap = purchaseReturnOrderDetailService.listByOrderNo(request.getTradeNo(), request.getBizType())
                .stream().collect(Collectors.toMap(PurchaseReturnOrderDetailPo::getLineNo, Function.identity()));
        StockPutOutSyncReq stockPutOutSyncReq = StockPutOutSyncReq.newInstance();
        stockPutOutSyncReq.setBodyHead(returnOrderPo);
        List<InAndOutStockParam> params = inAndOutStockParamConvertor.toParams(request.getParams());
        Map<String, InAndOutStockParam> paramMap = params.stream().collect(Collectors.toMap(InAndOutStockParam::getColumnNo, Function.identity(), (o, n) -> {
            o.setSumQuantity(o.getSumQuantity().add(n.getSumQuantity()));
            return o;
        }));
        stockPutOutSyncReq.setBodyItem(paramMap, detailPoMap, returnOrderPo);
        WarehousePo warehousePo = warehouseService.getByBizAndCode(request.getBizType(), returnOrderPo.getWarehouseCode());
        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(request.getBizType(),
                detailPoMap.values().stream().map(PurchaseReturnOrderDetailPo::getSalePartNum).collect(Collectors.toList()));
        stockPutOutSyncReq.setBodyItem(warehousePo, materialPoMap);

        return stockPutOutSyncReq;

    }
}
