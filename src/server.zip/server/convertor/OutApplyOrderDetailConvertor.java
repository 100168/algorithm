package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.OutboundApplyOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.ApplyOrderItemPo;
import com.jiduauto.sps.server.pojo.po.OutboundApplyOrderDetailPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface OutApplyOrderDetailConvertor {

    @Mapping(target = "stockStatus", ignore = true)
    @Mapping(target = "applyQty", ignore = true)
    @Mapping(target = "refItemId", source = "id")
    @Mapping(target = "orderNo", source = "applyOrderNo")
    @Mapping(target = "expectQty", source = "applySum")
    @Mapping(target = "actualQty", ignore = true)
    OutboundApplyOrderDetailPo toPo(ApplyOrderItemPo po);

    List<OutboundApplyOrderDetailPo> toPo(List<ApplyOrderItemPo> pos);


    @Mapping(target = "warehouseName", ignore = true)
    @Mapping(target = "stageCodeName", ignore = true)
    @Mapping(target = "restApplyQty", expression = "java(po.getExpectQty().subtract(po.getApplyQty()))")
    @Mapping(target = "projectCodeName", ignore = true)
    @Mapping(target = "partTypeName", ignore = true)
    @Mapping(target = "orderUnitName", ignore = true)
    @Mapping(target = "orderUnit", ignore = true)
    @Mapping(target = "measurementUnitName", ignore = true)
    @Mapping(target = "measurementUnit", ignore = true)
    @Mapping(target = "materialStatusName", ignore = true)
    @Mapping(target = "materialStandardName", ignore = true)
    @Mapping(target = "materialStandard", ignore = true)
    @Mapping(target = "materialSortName", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    OutboundApplyOrderDetailDto toDto(OutboundApplyOrderDetailPo po);

    List<OutboundApplyOrderDetailDto> toDto(List<OutboundApplyOrderDetailPo> pos);




}
