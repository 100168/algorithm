package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.sdk.pojo.po.StockAdjustOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.StockAdjustOrderReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @ClassName StockAdjustOrderConvertor
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/12/1 16:25
 */
@Mapper(componentModel = "spring")
public interface StockAdjustOrderConvertor {

    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    StockAdjustOrderPo toPo(StockAdjustOrderReq req);

}
