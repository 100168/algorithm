package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderDetailPo;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderDetailSaveReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderDetailEditReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderDetailImportReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface PurchaseReturnOrderDetailConvertor {

    /**
     * detailPo to po
     * @param purchaseReturnOrderDetailPo req
     * @return po*/
    @Mapping(target = "orderUnit", ignore = true)
    @Mapping(target = "measurementUnit", ignore = true)
    @Mapping(target = "salePartName", ignore = true)
    PurchaseReturnOrderDetailDto poToDto(PurchaseReturnOrderDetailPo purchaseReturnOrderDetailPo);

    /**
     * req to po
     * @param addReq req
     * @return po*/
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    PurchaseReturnOrderDetailPo reqToPo(PurchaseReturnOrderDetailSaveReq addReq);

    /**
     * req to po
     * @param editReq req
     * @return po*/
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "salePartNum", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    PurchaseReturnOrderDetailPo editReqToPo(PurchaseReturnOrderDetailEditReq editReq);

    /**
     * importReq to po
     * @param importReq req
     * @return po*/
    @Mapping(target = "orderNo", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "priceTime", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    PurchaseReturnOrderDetailPo importReqToPo(PurchaseReturnOrderDetailImportReq importReq);
}
