package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.sdk.pojo.req.StockCheckOrderImportReq;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.po.ReceiveOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.StockInOrderItemPo;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import com.jiduauto.sps.server.pojo.po.StockPo;
import org.apache.ibatis.annotations.Param;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @ClassName InAndOutStockParamConvertor
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/12/22 14:38
 */
@Mapper(componentModel = "spring")
public interface InAndOutStockParamConvertor {

    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "underTakeCompany", ignore = true)
    @Mapping(target = "sumQuantity", ignore = true)
    @Mapping(target = "smSoNo", ignore = true)
    @Mapping(target = "settlementType", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "planQuantity", ignore = true)
    @Mapping(target = "occupyQuantity", ignore = true)
    @Mapping(target = "incorrectQuantity", ignore = true)
    @Mapping(target = "equityOrderStatus", ignore = true)
    @Mapping(target = "costCenter", ignore = true)
    @Mapping(target = "companyCode", ignore = true)
    @Mapping(target = "columnNo", ignore = true)
    @Mapping(target = "carSoNo", ignore = true)
    @Mapping(target = "brokenQuantity", ignore = true)
    @Mapping(target = "asset", ignore = true)
    @Mapping(target = "materialStatus", source = "req.materialStatusCode")
    @Mapping(target = "stockStatus", source = "req.stockStatusCode")
    @Mapping(target = "materialSort", source = "req.materialSortCode")
    InAndOutStockParam toParam(@Param("req") StockCheckOrderImportReq req, String bizType);


    InAndOutStockParam toParam(InAndOutStockParam inAndOutStockParam);

    List<InAndOutStockParam> toParams(List<InAndOutStockParam> inAndOutStockParams);

    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "underTakeCompany", ignore = true)
    @Mapping(target = "sourceStockKeyMap", ignore = true)
    @Mapping(target = "sourceStockKey", ignore = true)
    @Mapping(target = "sourceStockItemKeyMap", ignore = true)
    @Mapping(target = "sourceStockItemKey", ignore = true)
    @Mapping(target = "smSoNo", ignore = true)
    @Mapping(target = "settlementType", ignore = true)
    @Mapping(target = "planQuantity", ignore = true)
    @Mapping(target = "occupyQuantity", ignore = true)
    @Mapping(target = "incorrectQuantity", ignore = true)
    @Mapping(target = "equityOrderStatus", ignore = true)
    @Mapping(target = "costCenter", ignore = true)
    @Mapping(target = "companyCode", ignore = true)
    @Mapping(target = "columnNo", ignore = true)
    @Mapping(target = "carSoNo", ignore = true)
    @Mapping(target = "brokenQuantity", ignore = true)
    @Mapping(target = "asset", ignore = true)
    @Mapping(target = "addDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getAddDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    @Mapping(target = "productDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getProductDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    @Mapping(target = "expireDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getExpireDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    InAndOutStockParam toParam(StockItemPo po);


    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "underTakeCompany", ignore = true)
    @Mapping(target = "sourceStockKeyMap", ignore = true)
    @Mapping(target = "sourceStockKey", ignore = true)
    @Mapping(target = "sourceStockItemKeyMap", ignore = true)
    @Mapping(target = "sourceStockItemKey", ignore = true)
    @Mapping(target = "smSoNo", ignore = true)
    @Mapping(target = "settlementType", ignore = true)
    @Mapping(target = "planQuantity", ignore = true)
    @Mapping(target = "incorrectQuantity", ignore = true)
    @Mapping(target = "equityOrderStatus", ignore = true)
    @Mapping(target = "costCenter", ignore = true)
    @Mapping(target = "companyCode", ignore = true)
    @Mapping(target = "columnNo", ignore = true)
    @Mapping(target = "carSoNo", ignore = true)
    @Mapping(target = "brokenQuantity", ignore = true)
    @Mapping(target = "bizConfigKey", ignore = true)
    @Mapping(target = "asset", ignore = true)
    @Mapping(target = "addDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getAddDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    @Mapping(target = "productDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getProductDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    @Mapping(target = "expireDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getExpireDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    InAndOutStockParam toParam(StockPo po);

    List<InAndOutStockParam> toParam(List<StockItemPo> po);

    @Mapping(target = "channelCode", ignore = true)
    @Mapping(target = "bizConfigKey", ignore = true)
    @Mapping(target = "addDate", ignore = true)
    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "underTakeCompany", ignore = true)
    @Mapping(target = "sumQuantity", source = "qty")
    @Mapping(target = "sourceStockKeyMap", ignore = true)
    @Mapping(target = "sourceStockKey", ignore = true)
    @Mapping(target = "sourceStockItemKeyMap", ignore = true)
    @Mapping(target = "sourceStockItemKey", ignore = true)
    @Mapping(target = "smSoNo", ignore = true)
    @Mapping(target = "settlementType", ignore = true)
    @Mapping(target = "purchaseOrderNo", source = "businessBillNo")
    @Mapping(target = "planQuantity", ignore = true)
    @Mapping(target = "palletNo", ignore = true)
    @Mapping(target = "occupyQuantity", ignore = true)
    @Mapping(target = "incorrectQuantity", ignore = true)
    @Mapping(target = "equityOrderStatus", ignore = true)
    @Mapping(target = "costCenter", ignore = true)
    @Mapping(target = "companyCode", ignore = true)
    @Mapping(target = "columnNo", ignore = true)
    @Mapping(target = "caseNo", ignore = true)
    @Mapping(target = "carSoNo", ignore = true)
    @Mapping(target = "brokenQuantity", ignore = true)
    @Mapping(target = "asset", ignore = true)
    InAndOutStockParam receiveToParam(ReceiveOrderDetailPo po);

    @Mapping(target = "addDate", ignore = true)
    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "underTakeCompany", ignore = true)
    @Mapping(target = "sumQuantity", source = "inQuantity")
    @Mapping(target = "sourceStockKeyMap", ignore = true)
    @Mapping(target = "sourceStockKey", ignore = true)
    @Mapping(target = "sourceStockItemKeyMap", ignore = true)
    @Mapping(target = "sourceStockItemKey", ignore = true)
    @Mapping(target = "smSoNo", ignore = true)
    @Mapping(target = "settlementType", ignore = true)
    @Mapping(target = "planQuantity", ignore = true)
    @Mapping(target = "palletNo", ignore = true)
    @Mapping(target = "occupyQuantity", ignore = true)
    @Mapping(target = "materialCode", source = "materialNumber")
    @Mapping(target = "incorrectQuantity", ignore = true)
    @Mapping(target = "equityOrderStatus", ignore = true)
    @Mapping(target = "costCenter", ignore = true)
    @Mapping(target = "companyCode", ignore = true)
    @Mapping(target = "columnNo", ignore = true)
    @Mapping(target = "caseNo", ignore = true)
    @Mapping(target = "carSoNo", ignore = true)
    @Mapping(target = "brokenQuantity", ignore = true)
    @Mapping(target = "asset", ignore = true)
    @Mapping(target = "productDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getProductDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    @Mapping(target = "expireDate", expression = "java(cn.hutool.core.date.DateUtil.format(po.getExpireDate(),cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    InAndOutStockParam toParam(StockInOrderItemPo po);


}
