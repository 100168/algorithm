package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.po.PickingOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.StockOutOrderItemPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface StockOutOrderItemConvertor {

    /**
     * to po
     *
     * @param pickingOrderDetailPo pickingOrderDetailPo
     * @return StockOutOrderItemPo
     */
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "workbinCode", ignore = true)
    @Mapping(target = "pssType", ignore = true)
    @Mapping(target = "palletCode", ignore = true)
    @Mapping(target = "outQuantity", ignore = true)
    @Mapping(target = "orderNumber", ignore = true)
    @Mapping(target = "materialNumber", ignore = true)
    @Mapping(target = "addDate", ignore = true)
    @Mapping(target = "productDate", ignore = true)
    @Mapping(target = "expireDate", ignore = true)
    StockOutOrderItemPo toPo(PickingOrderDetailPo pickingOrderDetailPo);
}
