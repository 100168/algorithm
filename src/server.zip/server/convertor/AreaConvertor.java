package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.baseData.AreaInfo;
import com.jiduauto.sps.server.pojo.po.AreasPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AreaConvertor {

    @Mapping(target = "locations", ignore = true)
    @Mapping(target = "areaName", source = "po.name")
    @Mapping(target = "areaCode", source = "po.code")
    AreaInfo toInfo(AreasPo po);


    List<AreaInfo> toInfo(List<AreasPo> po);
}
