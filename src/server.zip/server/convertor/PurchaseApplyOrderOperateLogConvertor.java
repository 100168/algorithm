package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderOperateLogDto;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderOperateLogPo;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface PurchaseApplyOrderOperateLogConvertor {

    /**
     * toDto
     * @param po po
     * @return dto
     */
    PurchaseApplyOrderOperateLogDto toDto (PurchaseApplyOrderOperateLogPo po);

    /**
     * toDtoList
     * @param poList poList
     * @return dtoList
     */
    List<PurchaseApplyOrderOperateLogDto> toDtoList (List<PurchaseApplyOrderOperateLogPo> poList);

}
