package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.OutboundApplyOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.ApplyOrderItemPo;
import com.jiduauto.sps.server.pojo.po.OutboundApplyOrderDetailPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface OutboundOrderDetailConvertor {

    @Mapping(target = "refItemId", source = "id")
    @Mapping(target = "orderNo", source = "applyOrderNo")
    @Mapping(target = "expectQty", source = "applySum")
    @Mapping(target = "actualQty", source = "applyRealSum")
    @Mapping(target = "id", ignore = true)
    OutboundApplyOrderDetailPo toPo(ApplyOrderItemPo applyOrderItemPo);
    List<OutboundApplyOrderDetailPo> toPo(List<ApplyOrderItemPo> applyOrderItemPo);


    @Mapping(target = "restApplyQty", ignore = true)
    @Mapping(target = "warehouseName", ignore = true)
    @Mapping(target = "stageCodeName", ignore = true)
    @Mapping(target = "projectCodeName", ignore = true)
    @Mapping(target = "partTypeName", ignore = true)
    @Mapping(target = "orderUnitName", ignore = true)
    @Mapping(target = "orderUnit", ignore = true)
    @Mapping(target = "measurementUnitName", ignore = true)
    @Mapping(target = "measurementUnit", ignore = true)
    @Mapping(target = "materialStatusName", ignore = true)
    @Mapping(target = "materialStandardName", ignore = true)
    @Mapping(target = "materialStandard", ignore = true)
    @Mapping(target = "materialSortName", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    OutboundApplyOrderDetailDto toDto(OutboundApplyOrderDetailPo po);
    List<OutboundApplyOrderDetailDto> toDto(List<OutboundApplyOrderDetailPo> pos);

}
