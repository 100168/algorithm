package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.client.req.RoSyncSrmReq;
import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderDetailDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderDto;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderPo;
import com.jiduauto.sps.server.pojo.po.WarehousePo;
import com.jiduauto.sps.server.service.IMaterialService;
import com.jiduauto.sps.server.service.IPurchaseReturnOrderDetailService;
import com.jiduauto.sps.server.service.IWarehouseService;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.springframework.stereotype.Component;

/**
 * @author panjian
 */
@Component
public class RoSrmReqConvertor {
    @Resource
    private IPurchaseReturnOrderDetailService purchaseReturnOrderDetailService;
    @Resource
    private PurchaseReturnOrderDetailConvertor purchaseReturnOrderDetailConvertor;
    @Resource
    private PurchaseReturnOrderConvertor purchaseReturnOrderConvertor;
    @Resource
    private IWarehouseService warehouseService;
    @Resource
    private IMaterialService materialService;


    public RoSyncSrmReq toSrmReq(PurchaseReturnOrderPo po){

        List<PurchaseReturnOrderDetailPo> detailPos = purchaseReturnOrderDetailService.listByOrderNo(
                po.getOrderNo(), po.getBizType());
        RoSyncSrmReq roSyncSrmReq = RoSyncSrmReq.newInstance();
        PurchaseReturnOrderDto orderDto = purchaseReturnOrderConvertor.poToDto(po);
        WarehousePo warehousePo = warehouseService.getByBizAndCode(po.getBizType(), po.getWarehouseCode());
        roSyncSrmReq.setPurchaseReturnOrder(orderDto);
        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(po.getBizType(),
                detailPos.stream().map(PurchaseReturnOrderDetailPo::getSalePartNum).collect(
                        Collectors.toList()));
        List<PurchaseReturnOrderDetailDto> orderDetailDtoList = detailPos.stream().map(e -> {
            PurchaseReturnOrderDetailDto detailDto = purchaseReturnOrderDetailConvertor.poToDto(e);
            MaterialPo materialPo = materialPoMap.getOrDefault(e.getSalePartNum(), new MaterialPo());
            detailDto.setSalePartName(materialPo.getMaterialName());
            detailDto.setMeasurementUnit(materialPo.getMeasurementUnit());
            detailDto.setOrderUnit(materialPo.getOrderUnit());
            return detailDto;
        }).collect(Collectors.toList());
        roSyncSrmReq.setDetail(warehousePo,orderDto,orderDetailDtoList);
        return roSyncSrmReq;
    }
}
