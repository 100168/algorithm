package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.baseData.WarehouseAllDto;
import com.jiduauto.sps.server.pojo.po.WarehousePo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface WarehouseConvertor {

    @Mapping(target = "province", ignore = true)
    @Mapping(target = "district", ignore = true)
    @Mapping(target = "city", ignore = true)
    @Mapping(target = "areaInfos", ignore = true)
    WarehouseAllDto toAllDto(WarehousePo po);

    List<WarehouseAllDto> toAllDto(List<WarehousePo> po);

}
