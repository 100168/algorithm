package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.po.kit.KitOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.kit.KitOrderAddAndEditReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface KitOrderPoConvertor {

    /**
     * to po
     * @param req req
     * @return po
     */
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "sapRequestNo", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "materialNumber", source = "materialCode")
    @Mapping(target = "kitOrderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    KitOrderPo toPo(KitOrderAddAndEditReq req);
}
