package com.jiduauto.sps.server.convertor;

import cn.hutool.core.util.IdUtil;
import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderItemPo;
import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderPo;
import com.jiduauto.sps.server.Enum.StockOperationType;
import com.jiduauto.sps.server.Enum.StockStatusEnum;
import com.jiduauto.sps.server.consts.StockSource;
import com.jiduauto.sps.server.pojo.dto.PickingOrderDetailUpdateDto;
import com.jiduauto.sps.server.pojo.dto.param.UpdateStockParam;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.pojo.vo.req.UpdateStockRequest;
import com.jiduauto.sps.server.service.IStockConfigService;
import com.jiduauto.sps.server.utils.BeanCopierUtil;
import com.jiduauto.sps.server.utils.DateUtils;
import com.jiduauto.sps.server.utils.JsonUtil;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author panjian
 */
@Component
@Slf4j
public class UpdateStockRequestConvertor {

    @Resource
    private StockConvertor stockConvertor;

    @Resource
    private IStockConfigService stockConfigService;


    public UpdateStockRequest releaseStockRequest(String bizType, String moveNumber,
            List<PickingOrderDetailUpdateDto> pickDetails) {
        UpdateStockRequest request = buildHead(moveNumber, StockOperationType.SPS45.getOperationType(), bizType);
        List<UpdateStockParam> addParams = new ArrayList<>();
        List<UpdateStockParam> cancelParams = new ArrayList<>();
        for (PickingOrderDetailUpdateDto po : pickDetails) {
            buildItem(po, addParams, cancelParams, StockStatusEnum.NORMAL, StockStatusEnum.PICKING_OCCUPY);
        }
        request.setAddParams(addParams);
        request.setCancelParams(cancelParams);
        log.info("UpdateStockRequestConvertor # toUpdateStockRequest # param : {}", JsonUtil.toJsonString(request));
        return request;

    }


    public UpdateStockRequest occupyStockRequest(String bizType, String moveNumber,
            List<PickingOrderDetailUpdateDto> pickDetails) {
        UpdateStockRequest request = buildHead(moveNumber, StockOperationType.SPS45.getOperationType(), bizType);
        List<UpdateStockParam> addParams = new ArrayList<>();
        List<UpdateStockParam> cancelParams = new ArrayList<>();
        for (PickingOrderDetailUpdateDto po : pickDetails) {
            buildItem(po, addParams, cancelParams, StockStatusEnum.PICKING_OCCUPY, StockStatusEnum.NORMAL);
        }
        request.setAddParams(addParams);
        request.setCancelParams(cancelParams);
        log.info("UpdateStockRequestConvertor # toUpdateStockRequest # param : {}", JsonUtil.toJsonString(request));
        return request;

    }

    private UpdateStockRequest buildHead(String moveNumber, String businessType, String bizType) {
        UpdateStockRequest request = new UpdateStockRequest();
        request.setBusinessBillNo(moveNumber);
        request.setBusinessType(businessType);
        request.setOperateTime(LocalDateTime.now());
        request.setOperateUser(UserUtil.getUserName());
        request.setIdempotentNo(moveNumber);
        request.setStockSource(StockSource.SYS);
        request.setBizType(bizType);
        return request;
    }

    public UpdateStockRequest toReleaseStockRequest(String bizType, String moveNumber,
            PickingOrderDetailUpdateDto po) {
        UpdateStockRequest request = buildHead(moveNumber, StockOperationType.SPS45.getOperationType(), bizType);
        List<UpdateStockParam> addParams = new ArrayList<>();
        List<UpdateStockParam> cancelParams = new ArrayList<>();
        buildItem(po, addParams, cancelParams, StockStatusEnum.NORMAL, StockStatusEnum.PICKING_OCCUPY);
        request.setAddParams(addParams);
        request.setCancelParams(cancelParams);
        log.info("UpdateStockRequestConvertor # toUpdateStockRequest # param : {}", JsonUtil.toJsonString(request));
        return request;
    }

    public UpdateStockRequest toOccupyStockRequest(String bizType, String moveNumber,
            PickingOrderDetailUpdateDto po) {
        UpdateStockRequest request = buildHead(moveNumber, StockOperationType.SPS45.getOperationType(), bizType);
        List<UpdateStockParam> addParams = new ArrayList<>();
        List<UpdateStockParam> cancelParams = new ArrayList<>();
        buildItem(po, addParams, cancelParams, StockStatusEnum.PICKING_OCCUPY, StockStatusEnum.NORMAL);
        request.setAddParams(addParams);
        request.setCancelParams(cancelParams);
        log.info("UpdateStockRequestConvertor # toUpdateStockRequest # param : {}", JsonUtil.toJsonString(request));
        return request;
    }

    private void buildItem(PickingOrderDetailUpdateDto po, List<UpdateStockParam> addParams,
            List<UpdateStockParam> cancelParams, StockStatusEnum addStatus, StockStatusEnum cancelStatus) {
        UpdateStockParam param = stockConvertor.toUpdateStockParam(po);
        param.setAddDate(DateUtils.parseFormat(po.getAddDate(), DateUtils.STANDARD_DATE_FORMAT));
        param.setProductDate(
                DateUtils.parseFormat(po.getProductDate(), DateUtils.STANDARD_DATE_FORMAT));
        param.setExpireDate(
                DateUtils.parseFormat(po.getExpireDate(), DateUtils.STANDARD_DATE_FORMAT));
        param.setSumQuantity(po.getAddQty());
        param.setStockStatus(addStatus.getValue());
        addParams.add(param);
        UpdateStockParam cancelTemp = stockConvertor.toUpdateStockParam(po);
        cancelTemp.setAddDate(DateUtils.parseFormat(po.getAddDate(), DateUtils.STANDARD_DATE_FORMAT));
        cancelTemp.setProductDate(
                DateUtils.parseFormat(po.getProductDate(), DateUtils.STANDARD_DATE_FORMAT));
        cancelTemp.setExpireDate(
                DateUtils.parseFormat(po.getExpireDate(), DateUtils.STANDARD_DATE_FORMAT));
        cancelTemp.setSumQuantity(po.getSubtractQty());
        cancelTemp.setStockStatus(cancelStatus.getValue());
        cancelParams.add(cancelTemp);
    }

    public UpdateStockRequest toUpdateStockRequest(StockCheckOrderPo order, StockCheckOrderItemPo item) {
        UpdateStockRequest request = new UpdateStockRequest();
        request.setBusinessBillNo(order.getOrderNo());
        request.setBusinessType(StockOperationType.SPS44.getOperationType());
        request.setOperateTime(LocalDateTime.now());
        request.setOperateUser(UserUtil.getUserName());
        request.setIdempotentNo(IdUtil.getSnowflake().nextIdStr());
        request.setStockSource(StockSource.SYS);
        request.setBizType(order.getBizType());
        List<UpdateStockParam> addParams = new ArrayList<>();
        List<UpdateStockParam> cancelParams = new ArrayList<>();
        UpdateStockParam addParam = stockConvertor.toUpdateStockParam(item);
        UpdateStockParam cancelParam = stockConvertor.toUpdateStockParam(item);
        addParam.setStockStatus(StockStatusEnum.FROZEN.getValue());
        addParams.add(addParam);
        cancelParams.add(cancelParam);
        request.setAddParams(addParams);
        request.setCancelParams(cancelParams);
        return request;
    }

    public UpdateStockRequest toUpdateStockRequestByList(StockCheckOrderPo order, List<StockCheckOrderItemPo> items) {
        UpdateStockRequest request = new UpdateStockRequest();
        request.setBusinessBillNo(order.getOrderNo()+System.currentTimeMillis());
        request.setTradeNo(order.getOrderNo());
        request.setBusinessType(StockOperationType.SPS44.getOperationType());
        request.setOperateTime(LocalDateTime.now());
        request.setOperateUser(UserUtil.getUserName());
        request.setIdempotentNo(order.getOrderNo()+System.currentTimeMillis());
        request.setStockSource(StockSource.SYS);
        request.setBizType(order.getBizType());
        request.setStockSource(StockSource.SYS);
        List<UpdateStockParam> addParams = stockConvertor.toUpdateStockParam(items);
        List<UpdateStockParam> cancelParams = stockConvertor.toUpdateStockParam(items);
        for (UpdateStockParam addParam : addParams) {
            addParam.setStockStatus(StockStatusEnum.FROZEN.getValue());
        }
        request.setAddParams(addParams);
        request.setCancelParams(cancelParams);
        return request;
    }

    public UpdateStockRequest toUpdateStockRequest(InAndOutStockRequest req) {
        UpdateStockRequest request = BeanCopierUtil.copy(req, UpdateStockRequest.class);
        request.setOperateTime(LocalDateTime.now());
        request.setIdempotentNo(req.getTradeNo() + "r");
        List<UpdateStockParam> addParams = stockConvertor.toUpdateStockParamList(req.getParams());
        List<UpdateStockParam> cancelParams = stockConvertor.toUpdateStockParamList(req.getParams());
        for (UpdateStockParam cancelParam : cancelParams) {
            cancelParam.setStockStatus(StockStatusEnum.IN_TRANSIT.getValue());
            if (req.getBusinessType().equals(StockOperationType.ES201.getOperationType())) {
                cancelParam.setStockStatus(StockStatusEnum.ES_IN_TRANSIT.getValue());
            }
            cancelParam.setPurchaseOrderNo(req.getTradeNo());
        }
        request.setAddParams(addParams);
        request.setCancelParams(cancelParams);
        return request;
    }


}
