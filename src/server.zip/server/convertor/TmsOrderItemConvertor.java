package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.tms.api.pojo.req.SpsOrderGoodsItemReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface TmsOrderItemConvertor {
    @Mapping(target = "vin", ignore = true)
    @Mapping(target = "unit", ignore = true)
    @Mapping(target = "sapCode", ignore = true)
    @Mapping(target = "quantity", source = "qty")
    @Mapping(target = "packageCode", source = "packingCode")
    @Mapping(target = "netWeight", source = "weight")
    @Mapping(target = "goodsName", ignore = true)
    @Mapping(target = "goodsDesc", ignore = true)
    @Mapping(target = "goodsCode", source = "materialCode")
    SpsOrderGoodsItemReq toReq(WarehouseDistributeItemPo itemPo);
}
