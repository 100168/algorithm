package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderItemPo;
import com.jiduauto.sps.server.pojo.dto.PickingOrderDetailUpdateDto;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.dto.param.UpdateStockParam;
import com.jiduauto.sps.server.pojo.dto.stock.StockMoveOrderItemDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface StockConvertor {

    /**
     * UpdateStockParam
     *
     * @param stockMoveOrderItemDto stockMoveOrderItemDto
     * @return UpdateStockParam
     */
    @Mapping(target = "columnNo", ignore = true)
    UpdateStockParam toUpdateStockParam(StockMoveOrderItemDto stockMoveOrderItemDto);

    /**
     * UpdateStockParam
     *
     * @param pickingOrderDetailPo stockMoveOrderItemDto
     * @return UpdateStockParam
     */
    @Mapping(target = "sumQuantity", ignore = true)
    @Mapping(target = "stockStatus", ignore = true)
    @Mapping(target = "columnNo", ignore = true)
    UpdateStockParam toUpdateStockParam(PickingOrderDetailUpdateDto pickingOrderDetailPo);

    @Mapping(target = "sumQuantity", source = "diffQty")
    @Mapping(target = "planQuantity", ignore = true)
    @Mapping(target = "bizConfigKey", ignore = true)
    UpdateStockParam toUpdateStockParam(StockCheckOrderItemPo stockCheckOrderItemPo);
    List<UpdateStockParam> toUpdateStockParam(List<StockCheckOrderItemPo> itemPos);

    @Mapping(target = "bizConfigKey", ignore = true)
    UpdateStockParam toUpdateStockParam(InAndOutStockParam inAndOutStockParam);

    List<UpdateStockParam> toUpdateStockParamList(List<InAndOutStockParam> inAndOutStockParam);

}
