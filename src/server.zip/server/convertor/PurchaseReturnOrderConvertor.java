package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderDetailDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderDto;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderAddReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderEditReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface PurchaseReturnOrderConvertor {

    /**
     * addReq to po
     * @param purchaseReturnOrderAddReq req
     * @return po*/
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "auditOpinion", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "orderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "auditTime", ignore = true)
    PurchaseReturnOrderPo addReqToPo(PurchaseReturnOrderAddReq purchaseReturnOrderAddReq);

    /**
     * editReq to po
     * @param purchaseReturnOrderEditReq req
     * @return po*/
    @Mapping(target = "auditOpinion", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "orderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "description", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "auditTime", ignore = true)
    PurchaseReturnOrderPo editReqToPo(PurchaseReturnOrderEditReq purchaseReturnOrderEditReq);
    /**
     * po to dto
     * @param purchaseReturnOrderPo po
     * @return dto*/
    @Mapping(target = "provinceName", ignore = true)
    @Mapping(target = "districtName", ignore = true)
    @Mapping(target = "cityName", ignore = true)
    @Mapping(target = "companyCode", ignore = true)
    @Mapping(target = "warehouseName", ignore = true)
    @Mapping(target = "supplierSapName", ignore = true)
    PurchaseReturnOrderDto poToDto(PurchaseReturnOrderPo purchaseReturnOrderPo);
}
