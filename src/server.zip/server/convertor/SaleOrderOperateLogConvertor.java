package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.SaleOrderOperateLogDto;
import com.jiduauto.sps.server.pojo.po.SaleOrderOperateLogPo;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface SaleOrderOperateLogConvertor {

    /**
     * toDto
     * @param saleOrderOperateLogPo
     * @return dto*/
    @Mapping(target = "newValue", expression = "java(com.jiduauto.sps.server.Enum.SaleOrderOperateLogStatusEnum.getDesc(saleOrderOperateLogPo.getNewValue()))")
    SaleOrderOperateLogDto toDto(SaleOrderOperateLogPo saleOrderOperateLogPo);
    /**
     * toDto
     * @param saleOrderOperateLogPoList
     * @return dto*/
    List<SaleOrderOperateLogDto> toDtoList(List<SaleOrderOperateLogPo> saleOrderOperateLogPoList);



}
