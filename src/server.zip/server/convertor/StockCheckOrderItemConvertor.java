package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderItemPo;
import com.jiduauto.sps.sdk.pojo.req.StockCheckOrderItemAddReq;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface StockCheckOrderItemConvertor {

    @Mapping(target = "diffQty", ignore = true)
    @Mapping(target = "checkStatus", ignore = true)
    @Mapping(target = "secondQty", ignore = true)
    @Mapping(target = "firstQty", ignore = true)
    @Mapping(target = "finalQty", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizConfigField", ignore = true)
    @Mapping(target = "qty",ignore = true)
    StockCheckOrderItemPo toPo(StockCheckOrderItemAddReq req);

    @Mapping(target = "firstQty", ignore = true)
    @Mapping(target = "stockCheckOrderNo", ignore = true)
    @Mapping(target = "secondQty", ignore = true)
    @Mapping(target = "qty", source = "stockItemPo.sumQuantity")
    @Mapping(target = "finalQty", ignore = true)
    @Mapping(target = "diffQty", ignore = true)
    @Mapping(target = "checkStatus", ignore = true)
    @Mapping(target = "addDate", expression = "java(cn.hutool.core.date.DateUtil.format(stockItemPo.getAddDate(), cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    @Mapping(target = "productDate", expression = "java(cn.hutool.core.date.DateUtil.format(stockItemPo.getProductDate(), cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    @Mapping(target = "expireDate", expression = "java(cn.hutool.core.date.DateUtil.format(stockItemPo.getExpireDate(), cn.hutool.core.date.DatePattern.NORM_DATE_PATTERN))")
    StockCheckOrderItemPo toPo(StockItemPo stockItemPo);

    List<StockCheckOrderItemPo> toPo(List<StockItemPo> stockItemPo);


}
