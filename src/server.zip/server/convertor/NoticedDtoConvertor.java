package com.jiduauto.sps.server.convertor;

import cn.hutool.json.JSONUtil;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.server.pojo.dto.BackOrderBatchCancelResp;
import com.jiduauto.sps.server.pojo.dto.NoticedDto;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author panjian
 */
@Component
public class NoticedDtoConvertor {

    @Value("${spring.profiles.active}")
    private String env;

    public NoticedDto buildNoticedDto(AsnBasicPo asnBasicPo, String msg,String title) {
        return NoticedDto
                .builder()
                .bizType(asnBasicPo.getBizType())
                .key(asnBasicPo.getAsnCode())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(PurchaseReturnOrderPo purchaseReturnOrderPo, String msg,String title) {
        return NoticedDto
                .builder()
                .bizType(purchaseReturnOrderPo.getBizType())
                .key(purchaseReturnOrderPo.getOrderNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }
    public NoticedDto buildNoticedDto(PurchaseApplyOrderPo orderPo, String msg,String title) {
        return NoticedDto
                .builder()
                .bizType(orderPo.getBizType())
                .key(orderPo.getOrderNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(BackOrderBatchCancelResp resp,String taskId,String title) {
        return NoticedDto
                .builder()
                .bizType(resp.getBizType())
                .key(taskId)
                .env(env)
                .title(title)
                .result(JSONUtil.toJsonStr(resp.getRespInfos()))
                .build();
    }
    public NoticedDto buildNoticedDto(SaleOrderPo saleOrderPo, String msg,String title) {
        return NoticedDto
                .builder()
                .bizType(saleOrderPo.getBizType())
                .key(saleOrderPo.getSaleOrderNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(PurchaseOrderPo po, String msg,String title) {
        return NoticedDto
                .builder()
                .bizType(po.getBizType())
                .key(po.getPurchaseOrderNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(KitOrderPo kitOrderPo, String msg, String title) {
        return NoticedDto
                .builder()
                .bizType(kitOrderPo.getBizType())
                .key(kitOrderPo.getKitOrderNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(WarehouseDistributeOrderPo po, String msg, String title) {
        return NoticedDto
                .builder()
                .bizType(po.getBizType())
                .key(po.getOrderNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(InAndOutStockRequest request, String msg, String title) {
        return NoticedDto
                .builder()
                .bizType(request.getBizType())
                .key(request.getTradeNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(String bizType, String orderNo, String msg, String title) {
        return NoticedDto
                .builder()
                .bizType(bizType)
                .key(orderNo)
                .result(msg)
                .env(env)
                .title(title)
                .build();
    }
}
