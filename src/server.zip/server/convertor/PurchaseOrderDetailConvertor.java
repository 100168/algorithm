package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.InternalPoDetailDto;
import com.jiduauto.sps.server.pojo.dto.InternalPoDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseOrderDetailDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseOrderDto;
import com.jiduauto.sps.server.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.server.pojo.vo.req.InternalPurchaseOrderAddReq.Item;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface PurchaseOrderDetailConvertor {
    /**
     * req转po
     * @param req
     * @return */
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "purchaseOrderNo", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    PurchaseOrderDetailPo reqToPo(Item req);


    /**
     * po转dto
     * @param po po
     * @return dto */
    @Mapping(target = "salePartName", ignore = true)
    @Mapping(target = "minPackage", ignore = true)
    PurchaseOrderDetailDto poToDto(PurchaseOrderDetailPo po);

}
