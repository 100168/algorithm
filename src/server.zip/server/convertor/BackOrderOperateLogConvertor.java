package com.jiduauto.sps.server.convertor;

import com.jiduauto.sps.server.pojo.dto.BackOrderOperateLogDto;
import com.jiduauto.sps.server.pojo.po.BackOrderOperateLogPo;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface BackOrderOperateLogConvertor {

    /**
     * toDto
     * @param boOperateLogPo
     * @return dto*/
    @Mapping(target = "newValue", expression = "java(com.jiduauto.sps.server.Enum.BackOrderStatusEnum.getDesc(boOperateLogPo.getNewValue()))")
    BackOrderOperateLogDto toDto(BackOrderOperateLogPo boOperateLogPo);
    /**
     * toDto
     * @param boOperateLogPoList
     * @return dto*/
    List<BackOrderOperateLogDto> toDtoList(List<BackOrderOperateLogPo> boOperateLogPoList);

}
