package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.StockInMapBusinessDto;
import com.jiduauto.sps.server.pojo.fileexport.StockInMapBusinessExportResp;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.StockInMapBusinessPageSearchReq;
import com.jiduauto.sps.server.service.IStockInMapBusinessService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 入库订单 前端控制器
 */
@RestController
@RequestMapping("/stockInMapBusiness")
public class StockInMapBusinessController {

    @Resource
    private IStockInMapBusinessService stockInMapBusinessService;

    /**
     * 入库单列表查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StockInMapBusinessDto>> pageSearch(@RequestBody @Valid BasePageParam<StockInMapBusinessPageSearchReq> pageParam) {
        return BaseResult.OK(stockInMapBusinessService.pageSearch(pageParam));
    }

    /**
     * 入库订单 导出
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response, @RequestBody @Valid BasePageParam<StockInMapBusinessPageSearchReq> pageParam) {
        try {
            ExcelUtils.exportXlsxResponse(response, "入库订单导出");
            EasyExcel.write(response.getOutputStream(), StockInMapBusinessExportResp.class)
                    .sheet("入库订单")
                    .doWrite(stockInMapBusinessService.export(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }
}
