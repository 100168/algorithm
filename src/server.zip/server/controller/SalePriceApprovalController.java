package com.jiduauto.sps.server.controller;

import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.SalePriceApprovalDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.SpsBaseReq;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.SalePriceApprovalPageSearchReq;
import com.jiduauto.sps.server.service.ISalePriceApprovalService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;


/**
 * 销售价格审批 前端控制器
 */
@RestController
@RequestMapping("/salePriceApproval")
public class SalePriceApprovalController {

    @Resource
    private ISalePriceApprovalService salePriceApprovalService;

    /**
     * 创建临时记录
     * @param request
     * @return
     */
    @PostMapping("/createTempRecord")
    public BaseResult createTempRecord(@RequestBody @Valid SpsBaseReq request) {
        return BaseResult.OK(salePriceApprovalService.createTempRecord(request));
    }

    /**
     * 启用临时记录
     * @param request
     * @return
     */
    @PostMapping("/enableTempRecord")
    public BaseResult enableTempRecord(@RequestBody @Valid IdReq request) {
        salePriceApprovalService.enableTempRecord(request);
        return BaseResult.OK();
    }

    /**
     * 删除
     * @param request
     * @return
     */
    @PostMapping("/delete")
    public BaseResult delete(@RequestBody @Valid IdReq request) {
        salePriceApprovalService.delete(request);
        return BaseResult.OK();
    }

    /**
     * 提交
     * @param request
     * @return
     */
    @PostMapping("/commit")
    public BaseResult commit(@RequestBody @Valid IdReq request) {
        salePriceApprovalService.commit(request);
        return BaseResult.OK();
    }

    /**
     * 条件查询
     * @param pageParam
     * @return
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<SalePriceApprovalDto>> pageSearch(@RequestBody @Valid BasePageParam<SalePriceApprovalPageSearchReq> pageParam) {
        return BaseResult.OK(salePriceApprovalService.pageSearch(pageParam));
    }
}
