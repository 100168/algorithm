package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.sdk.pojo.dto.CommonLogDto;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.OrderProcessConfigDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.BatchIdReq;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderProcessAddDetailReq;
import com.jiduauto.sps.server.service.IOrderProcessConfigService;
import lombok.AllArgsConstructor;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 业务流程配置表 前端控制器
 */
@RestController
@RequestMapping("/orderProcessConfig")
@AllArgsConstructor
public class OrderProcessConfigController {

    private final IOrderProcessConfigService orderProcessConfigService;
    @Resource
    private RedissonClient redissonClient;

    /**
     * 业务流程配置表查询
     */
    @PostMapping("/search")
    public BaseResult<List<OrderProcessConfigDto>> search(@RequestHeader("bizType") String bizType) {
        return BaseResult.OK(orderProcessConfigService.search(bizType));
    }

    /**
     * 删除配置 传入要删除的 item 里的 detail id
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid BatchIdReq req) {
        RLock lock = redissonClient.getLock(String.format(BaseConstants.RedisKey.SPS_SYS_ORDER_PROCESS_CONFIG_KEY, req.getBizType()));
        try {
            lock.lock();
            orderProcessConfigService.delete(req);
        } finally {
            if (lock.isHeldByCurrentThread()) {
                lock.unlock();
            }
        }
        return BaseResult.OK();
    }

    /**
     * 配置哪个流程为默认
     */
    @PostMapping("/defaultCode")
    public BaseResult<String> defaultCode(@RequestBody @Valid BatchIdReq req) {
        RLock lock = redissonClient.getLock(String.format(BaseConstants.RedisKey.SPS_SYS_ORDER_PROCESS_CONFIG_KEY, req.getBizType()));
        try {
            lock.lock();
            orderProcessConfigService.defaultCode(req);
        } finally {
            if (lock.isHeldByCurrentThread()) {
                lock.unlock();
            }
        }
        return BaseResult.OK();
    }

    /**
     * 新增业务场景 & 仓库配置
     */
    @PostMapping("/detail/add")
    public BaseResult<String> addDetail(@RequestBody @Valid OrderProcessAddDetailReq req) {
        RLock lock = redissonClient.getLock(String.format(BaseConstants.RedisKey.SPS_SYS_ORDER_PROCESS_CONFIG_KEY, req.getBizType()));
        try {
            lock.lock();
            orderProcessConfigService.addDetail(req);
        } finally {
            if (lock.isHeldByCurrentThread()) {
                lock.unlock();
            }
        }
        return BaseResult.OK();
    }

    /**
     * 操作日志分页查询
     */
    @PostMapping("/log/pageSearch")
    public BaseResult<BasePageData<CommonLogDto>> logPageSearch(@RequestBody @Valid BasePageParam<IdReq> req) {
        return BaseResult.OK(orderProcessConfigService.logPageSearch(req));
    }
}
