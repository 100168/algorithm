package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.excel.ExtendExportDto;
import com.jiduauto.sps.server.excel.OrderPlanImportHandler;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.OrderPlanDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.fileexport.OrderPlanExportDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.service.IOrderPlanService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.groups.Default;

/**
 * 要货计划 前端控制器
 */
@Slf4j
@RestController
@RequestMapping("/orderPlan")
public class OrderPlanController {

    @Resource
    private IOrderPlanService orderPlanService;

    @Resource
    private OrderPlanImportHandler orderPlanImportHandler;

    /**
     * 新增
     * @param request
     * @return
     */
    @PostMapping("/add")
    @LoginCheck
    public BaseResult add(@RequestBody @Valid OrderPlanAddReq request) {
        return orderPlanService.add(request);
    }

    /**
     * 编辑
     * @param request
     * @return
     */
    @PostMapping("/edit")
    @LoginCheck
    public BaseResult edit(@RequestBody @Valid OrderPlanEditReq request) {
        return orderPlanService.edit(request);
    }

    /**
     * 删除
     * @param request
     * @return
     */
    @PostMapping("/delete")
    @LoginCheck
    public BaseResult delete(@RequestBody @Valid IdReq request) {
        return orderPlanService.delete(request);
    }

    /**
     * 提交
     * @param request
     * @return
     */
    @PostMapping("/commit")
    @LoginCheck
    public BaseResult commit(@RequestBody @Valid OrderPlanBatchIdReq request) {
        return orderPlanService.commit(request);
    }

    /**
     * 审核
     * @param request
     * @return
     */
    @PostMapping("/audit")
    @LoginCheck
    public BaseResult audit(@RequestBody @Validated({Default.class, OrderPlanBatchIdReq.Audit.class}) OrderPlanBatchIdReq request) {
        return orderPlanService.audit(request);
    }

    /**
     * 手动推送
     * @param request
     * @return
     */
    @PostMapping("/manual/push")
    @LoginCheck
    public BaseResult manualPush(@RequestBody @Valid OrderPlanBatchIdReq request) {
        return orderPlanService.manualPush(request);
    }

    /**
     * 导入
     * @param bizType
     * @param file
     * @return
     */
    @PostMapping("/import")
    @LoginCheck
    public BaseResult<ImportResultResp> importOrderPlan(@RequestHeader("bizType") String bizType, @RequestPart("file") MultipartFile file) {
        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        ImportReturnDataInfo<ExtendExportDto<OrderPlanImportReq>> resp = orderPlanImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return BaseResult.OK(resultResp);
    }

    /**
     * 导出
     * @param pageParam
     * @param response
     */
    @PostMapping("/export")
    @LoginCheck
    public void exportOrderPlan(@RequestBody @Valid BasePageParam<OrderPlanPageSearchReq> pageParam, HttpServletResponse response) {
        try {
            pageParam.setPage(BaseConstants.ImportExport.PAGE_START_AT); // 导出最大返回前1000条
            pageParam.setSize(BaseConstants.ImportExport.MAX_SIZE_10000);
            ExcelUtils.exportXlsxResponse(response, "要货计划");
            EasyExcel.write(response.getOutputStream(), OrderPlanExportDto.class).sheet("要货计划").doWrite(orderPlanService.getExportDtoList(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

    /**
     * 条件查询
     * @param pageParam
     * @return
     */
    @PostMapping("/pageSearch")
    @LoginCheck
    public BaseResult<BasePageData<OrderPlanDto>> pageSearch(@RequestBody @Valid BasePageParam<OrderPlanPageSearchReq> pageParam) {
        return BaseResult.OK(orderPlanService.pageSearch(pageParam));
    }
}
