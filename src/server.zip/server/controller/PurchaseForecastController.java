package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.Enum.GlobalCodeEnum;
import com.jiduauto.sps.server.Enum.SpsResponseCodeEnum;
import com.jiduauto.sps.server.annotation.InvokeLog;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.MaterialDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseForecastDto;
import com.jiduauto.sps.server.pojo.dto.param.MaterialSearchParam;
import com.jiduauto.sps.server.pojo.dto.param.PurchaseForecastParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.po.PurchaseForecastPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.BatchIdReq;
import com.jiduauto.sps.server.service.IPurchaseForecastService;
import com.jiduauto.sps.server.utils.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 采购预测 前端控制器
 *
 * @author generate
 * @since 2023-02-09
 */
@RestController
@RequestMapping("/purchaseForecast")
public class PurchaseForecastController {

    @Resource
    private IPurchaseForecastService purchaseForecastService;

    /**
     * 分页查询
     * @param params
     * @return
     */
    @RequestMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<PurchaseForecastDto>> pageList(@RequestBody @Valid BasePageParam<PurchaseForecastParam> params){
        return BaseResult.OK(purchaseForecastService.pageSearch(params));
    }

    /**
     * 导入
     * @param bizType
     * @param file
     * @return
     */
    @RequestMapping("/import")
    @InvokeLog
    public BaseResult<ImportResultResp> importPlanMaterial(@RequestHeader("bizType") String bizType,
                                                           @RequestPart("file") MultipartFile file){
        if(StringUtils.isBlank(bizType)){
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9998);
        }
        ImportResultResp resp = purchaseForecastService.importFile(bizType, file);
        return BaseResult.OK(resp);
    }

    /**
     * 删除
     * @param id
     * @return
     */
    @RequestMapping("/delete/{id}")
    @InvokeLog
    public BaseResult<String> delete(@PathVariable Long id){
        return purchaseForecastService.deleteById(id);
    }

    /**
     * 批量 删除
     * @param ids
     * @return
     */
    @RequestMapping("/deleteBatch")
    @InvokeLog
    public BaseResult<String> deleteBatch(@RequestBody BatchIdReq ids){
        return purchaseForecastService.deleteBatch(ids);
    }

    /**
     * 下发
     * @param ids  id集合
     * @return
     */
    @RequestMapping("/issued")
    @ResponseBody
    @InvokeLog
    public BaseResult<String> issued(@RequestBody List<Long> ids,@RequestHeader("bizType") String bizType){
        if(CollectionUtils.isEmpty(ids)){
            return BaseResult.applicationError(SpsResponseCodeEnum.PARAMS_IS_EMPTY);
        }
        return purchaseForecastService.issuedForecasts(ids,bizType);
    }

    /**
     * 下发所有
     * @return
     */
    @RequestMapping("/issuedBatch")
    @ResponseBody
    @InvokeLog
    public BaseResult<String> issuedBatch(@RequestHeader("bizType") String bizType){
        List<PurchaseForecastPo> pos = purchaseForecastService.listUnissued(bizType);
        if(CollectionUtils.isEmpty(pos)){
            return BaseResult.applicationError(-1,"无待处理数据");
        }
        purchaseForecastService.issuedBatch(bizType, pos);
         return BaseResult.OK(0,"下发中，请稍后查看结果");
    }

}
