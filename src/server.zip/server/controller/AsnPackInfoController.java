package com.jiduauto.sps.server.controller;


import cn.hutool.core.bean.BeanUtil;
import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.param.AsnDeliverListParam;
import com.jiduauto.sps.server.pojo.dto.param.AsnPackListParam;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.AsnDeliverListReq;
import com.jiduauto.sps.server.pojo.vo.req.AsnPackListReq;
import com.jiduauto.sps.server.pojo.vo.resp.AsnDeliverListResp;
import com.jiduauto.sps.server.pojo.vo.resp.AsnPackListResp;
import com.jiduauto.sps.server.service.IAsnPackInfoService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * 包装信息 前端控制器
 *
 * @author generate
 * @since 2022-12-14
 */
@RestController
@RequestMapping("/asn/pack")
@AllArgsConstructor
@Slf4j
public class AsnPackInfoController {

    private final IAsnPackInfoService asnPackInfoService;

    /**
     * 包装信息列表
     * @param param
     * @return
     */
    @PostMapping("/list")
    @LoginCheck
    public BaseResult<BasePageData<AsnPackListResp>> page(@RequestBody @Validated BasePageParam<AsnPackListReq> param) {
        log.info("AsnBasicController-page-param:{}", param);
        AsnPackListParam req = BeanUtil.copyProperties(param.getParam(), AsnPackListParam.class);
        BasePageData basePageData = asnPackInfoService.listByPage(req,param.getPage(),param.getSize());
        return BaseResult.OK(basePageData);
    }
}
