package com.jiduauto.sps.server.controller;


import cn.hutool.core.bean.BeanUtil;
import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.param.AsnBasicListParam;
import com.jiduauto.sps.server.pojo.dto.param.AsnDeliverListParam;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.AsnBasicListReq;
import com.jiduauto.sps.server.pojo.vo.req.AsnDeliverListReq;
import com.jiduauto.sps.server.pojo.vo.resp.AsnBasicListResp;
import com.jiduauto.sps.server.pojo.vo.resp.AsnDeliverListResp;
import com.jiduauto.sps.server.service.IAsnDeliverInfoService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * 发货信息表 前端控制器
 *
 * @author generate
 * @since 2022-12-14
 */
@RestController
@RequestMapping("/asn/deliver")
@AllArgsConstructor
@Slf4j
public class AsnDeliverInfoController {

    private final IAsnDeliverInfoService asnDeliverInfoService;

    /**
     * 发货信息page
     * @param param
     * @return
     */
    @PostMapping("/list")
    @LoginCheck
    public BaseResult<BasePageData<AsnDeliverListResp>> page(@RequestBody @Validated BasePageParam<AsnDeliverListReq> param) {
        log.info("AsnDeliverInfoController-page-param:{}", param);
        AsnDeliverListParam req = BeanUtil.copyProperties(param.getParam(), AsnDeliverListParam.class);
        BasePageData basePageData = asnDeliverInfoService.listByPage(req,param.getPage(),param.getSize());
        return BaseResult.OK(basePageData);
    }
}
