package com.jiduauto.sps.server.controller;

import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.service.ICommonService;
import feign.Param;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * 行政区域地址管理
 *
 * @author dong.li01
 * @since 5/4/23 4:40 PM
 */
@RestController
@RequestMapping("address")
public class AddressController {

    @Resource
    private ICommonService commonService;

    /**
     * 行政区域-省市二级数据下拉列表
     *
     * @author dong.li
     * @date 5/4/23 2:36 PM
     */
    @PostMapping("provinceDropDownList")
    @ResponseBody
    public BaseResult provinceDropDownList() {
        return BaseResult.OK(commonService.listProvinces());
    }

    /**
     * 行政区域-省市级区三级数据下拉列表
     *
     * @author dong.li
     * @date 5/4/23 2:36 PM
     */
    @PostMapping("districtDropDownList")
    @ResponseBody
    public BaseResult districtDropDownList() {
        return BaseResult.OK(commonService.listDistrict());
    }

    /**
     * 根据code获取下级数据
     * @Author O_chaopeng.huang
     * @Date 17:40 2023/5/5
     **/
    @GetMapping("/listChild")
    @ResponseBody
    public BaseResult listChild(@Param("code") String code) {
        return BaseResult.OK(commonService.listChild(code));
    }
   /* public static void main(String[] args) throws IOException {
        CloseableHttpClient httpClient= HttpClients.createDefault();
        HttpGet httpPost = new HttpGet("https://cloud.jiduapp.cn/api/map-location/client/v1/district/listChild?code=130000");
        httpPost.setHeader("Content-type", "application/x-www-form-urlencoded");

        // 执行http请求
        CloseableHttpResponse response = httpClient.execute(httpPost);
        String resultString = EntityUtils.toString(response.getEntity(), "utf-8");

        System.out.println(resultString);
    }*/

}
