package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.ApplyCarMaterialOrderDetailDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.NoReq;
import com.jiduauto.sps.server.service.IApplyCarMaterialOrderDetailService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 整车拉料订单明细表 前端控制器
 */
@RestController
@RequestMapping("/applyCarMaterialOrderDetail")
public class ApplyCarMaterialOrderDetailController {

    @Resource
    private IApplyCarMaterialOrderDetailService applyCarMaterialOrderDetailService;

    /**
     * 整车拉料详情分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<ApplyCarMaterialOrderDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<NoReq> pageParam) {
        return BaseResult.OK(applyCarMaterialOrderDetailService.pageSearch(pageParam));
    }
}
