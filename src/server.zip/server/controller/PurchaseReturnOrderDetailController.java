package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.excel.ExcelThreadLocalHolder;
import com.jiduauto.sps.server.excel.ExtendExportDto;
import com.jiduauto.sps.server.excel.PurchaseReturnOrderDetailImportHandler;
import com.jiduauto.sps.server.excel.check.PurchaseReturnOrderDetailBatchPreCheck;
import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderDetailDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.service.IPurchaseReturnOrderDetailService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 采购退货订单明细 前端控制器
 *
 * @author generate
 * @since 2023-05-04
 */
@RestController
@RequestMapping("/purchaseReturnOrder/detail")
public class PurchaseReturnOrderDetailController {

    @Resource
    private IPurchaseReturnOrderDetailService purchaseReturnOrderDetailService;

    @Resource
    private PurchaseReturnOrderDetailImportHandler purchaseReturnOrderDetailImportHandler;
    /**
     * @description 明细列表查询
     * @param request 订单号
     * @return list
     */
    @PostMapping("/list")
    public BaseResult<List<PurchaseReturnOrderDetailDto>> list(@RequestBody @Valid OrderAndSupplierReq request) {
        return BaseResult.OK(purchaseReturnOrderDetailService.listByOrderNo(request));
    }

    /**
     * 明细删除
     * @param request 明细id
     * @return bool
     */
    @PostMapping("/delete")
    public BaseResult<Boolean> delete(@RequestBody @Valid IdReq request) {
        return BaseResult.OK(purchaseReturnOrderDetailService.removeById(request.getId()));
    }
    /**
     * 明细增加
     * @param addReq 添加参数
     * @return bool
     */
    @Deprecated
    @PostMapping("/add")
    public BaseResult<Boolean> add(@RequestBody @Valid PurchaseReturnOrderDetailSaveReq addReq) {
        return BaseResult.OK(purchaseReturnOrderDetailService.add(addReq));
    }
    /**
     * 明细编辑
     * @param editReq 编辑参数
     * @return bool
     */
    @PostMapping("/edit")
    public BaseResult<Boolean> edit(@RequestBody @Valid PurchaseReturnOrderDetailEditReq editReq) {
        return BaseResult.OK(purchaseReturnOrderDetailService.edit(editReq));
    }

    /**
     * 明细导入
     * @param bizType 业务类型
     * @param file 文件
     * @return res
     */
    @PostMapping("/import")
    @LoginCheck
    public BaseResult<ImportResultResp> importOrderPlan(
            @RequestHeader("bizType") String bizType,
            @RequestParam("orderNo") String orderNo,
            @RequestPart("file") MultipartFile file) {
        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        ExcelThreadLocalHolder.put(PurchaseReturnOrderDetailBatchPreCheck.KEY_RETURN_ORDER_NO,orderNo);
        ImportReturnDataInfo<ExtendExportDto<PurchaseReturnOrderDetailImportReq>> resp = purchaseReturnOrderDetailImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return BaseResult.OK(resultResp);
    }


    /**
     * 明细增加批量
     * @param addBatchReq 添加参数
     * @return bool
     */
    @PostMapping("/addBatch")
    public BaseResult<Boolean> addBatch(@RequestBody @Valid PurchaseReturnOrderDetailBatchSaveReq addBatchReq) {
        return BaseResult.OK(purchaseReturnOrderDetailService.addBatch(addBatchReq));
    }

}
