package com.jiduauto.sps.server.controller;


import cn.hutool.core.bean.BeanUtil;
import com.jiduauto.sps.server.Enum.GlobalCodeEnum;
import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.dto.DictDto;
import com.jiduauto.sps.server.pojo.dto.param.DictAddParam;
import com.jiduauto.sps.server.pojo.dto.param.DictEditParam;
import com.jiduauto.sps.server.pojo.dto.param.DictParam;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.DictAddReq;
import com.jiduauto.sps.server.pojo.vo.req.DictEditReq;
import com.jiduauto.sps.server.pojo.vo.req.DictReq;
import com.jiduauto.sps.server.pojo.vo.req.EditStatusCommonReq;
import com.jiduauto.sps.server.pojo.vo.resp.DictResp;
import com.jiduauto.sps.server.service.IDictService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * 后台字典表 前端控制器
 *
 * @author generate
 * @since 2022-12-06
 */
@Slf4j
@RestController
@RequestMapping("/dict")
@AllArgsConstructor
public class DictController {

    private final IDictService iDictService;

    /**
     * 数据字典首页
     *
     * @param req
     * @return BaseResult<List<DictResp>>
     */
    @PostMapping("/list")
    public BaseResult<List<DictResp>> page(@RequestBody @Valid DictReq req) {

        DictParam dictParam = BeanUtil.copyProperties(req, DictParam.class);

        List<DictDto> resultDto = iDictService.list(dictParam);
        List<DictResp> resultResp = BeanUtil.copyToList(resultDto, DictResp.class);

        return BaseResult.OK(resultResp);
    }

    /**
     * 状态编辑
     *
     * @param req
     * @return BaseResult<String>
     */
    @PostMapping("/status")
    @LoginCheck
    public BaseResult<String> statusEdit(@RequestBody @Validated EditStatusCommonReq req) {

        iDictService.editStatus(req.getId(),req.getStatus());

        return BaseResult.OK();
    }

    /**
     * 新增
     *
     * @param req
     * @return BaseResult<String>
     */
    @PostMapping("/add")
    @LoginCheck
    public BaseResult<String> add(@RequestBody @Validated DictAddReq req) {

        DictAddParam param = BeanUtil.copyProperties(req, DictAddParam.class);

        try {
            iDictService.add(param);
        } catch (DataAccessException e) {
            // 捕获添加时code冲突
            log.info("DictController.add.exception.message:{}", "唯一键冲突", e);
            return BaseResult.packageObject(null, GlobalCodeEnum.GL_FAIL_9994.getCode(), "该编码已存在");
        } catch (BizException e) {
            return BaseResult.packageObject(null, GlobalCodeEnum.GL_FAIL_9994.getCode(), e.getErrMessage());
        } catch (Exception e) {
            log.error("DictController.add.exception", e);
            return BaseResult.packageObject(null, GlobalCodeEnum.GL_FAIL_9994.getCode(), "添加失败");
        }

        return BaseResult.OK();
    }

    /**
     * 详情
     *
     * @param id
     * @return BaseResult<DictResp>
     */
    @GetMapping("/detail")
    @LoginCheck
    public BaseResult<DictResp> detail(@RequestParam("id") Long id) {

        DictDto detail = iDictService.detail(id);

        DictResp resp = BeanUtil.copyProperties(detail, DictResp.class);
        return BaseResult.OK(resp);
    }

    /**
     * 编辑
     *
     * @param req
     * @return BaseResult<String>
     */
    @PostMapping("/edit")
    @LoginCheck
    public BaseResult<String> edit(@RequestBody @Validated DictEditReq req) {

        DictEditParam param = BeanUtil.copyProperties(req, DictEditParam.class);
        iDictService.edit(param);
        return BaseResult.OK();
    }
}
