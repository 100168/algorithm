package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.annotation.InvokeLog;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.LingkeBackOrderDto;
import com.jiduauto.sps.server.pojo.fileexport.LingkeBackOrderExportDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.LingkeBackOrderPageSearch;
import com.jiduauto.sps.server.service.ILingkeBackOrderService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 领克缺件订单 前端控制器
 */
@RestController
@RequestMapping("/lingkeBackOrder")
public class LingkeBackOrderController {
    @Autowired
    private ILingkeBackOrderService lingkeBackOrderService;
    /**
     * 领克缺件分页查询
     */
    @RequestMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<LingkeBackOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<LingkeBackOrderPageSearch> req) {
        return BaseResult.OK(lingkeBackOrderService.pageSearch(req));
    }

    /**
     * 领克缺件订单导出
     */
    @RequestMapping("/export")
    @InvokeLog
    public void export(@RequestBody @Valid BasePageParam<LingkeBackOrderPageSearch> pageParam) {
        try {
            HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getResponse();
            ExcelUtils.exportXlsxResponse(response, "领克缺件订单");
            EasyExcel.write(response.getOutputStream(), LingkeBackOrderExportDto.class).sheet("领克缺件订单").doWrite(lingkeBackOrderService.export(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

    /**
     * 领克缺件订单详情取消 传入 bo detail 主键
     *
     * @param req lingke bo detail 主键
     */
    @PostMapping("/cancel")
    public BaseResult<String> cancel(@RequestBody @Valid IdReq req) {
        return lingkeBackOrderService.cancelBackOrder(req.getId());
    }

}
