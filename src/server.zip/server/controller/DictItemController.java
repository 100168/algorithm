package com.jiduauto.sps.server.controller;


import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.server.Enum.GlobalCodeEnum;
import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.DictItemDetailDto;
import com.jiduauto.sps.server.pojo.dto.DictItemDto;
import com.jiduauto.sps.server.pojo.dto.param.DictItemAddParam;
import com.jiduauto.sps.server.pojo.dto.param.DictItemEditParam;
import com.jiduauto.sps.server.pojo.dto.param.DictItemReq;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.DictItemAddReq;
import com.jiduauto.sps.server.pojo.vo.req.DictItemEditReq;
import com.jiduauto.sps.server.pojo.vo.req.EditStatusCommonReq;
import com.jiduauto.sps.server.pojo.vo.resp.DictItemDetailResp;
import com.jiduauto.sps.server.pojo.vo.resp.DictItemResp;
import com.jiduauto.sps.server.service.IDictItemService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * 后台字典item表 前端控制器
 *
 * @author generate
 * @since 2022-12-06
 */
@RestController
@RequestMapping("/dictItem")
@Slf4j
@AllArgsConstructor
public class DictItemController {

    private final IDictItemService iDictItemService;


    /**
     * 修改明细状态
     *
     * @param req
     * @return BaseResult<String>
     */
    @PostMapping("/status")
    @LoginCheck
    public BaseResult<String> statusEdit(@RequestBody @Validated EditStatusCommonReq req) {

        iDictItemService.editStatus(req.getId(),req.getStatus());

        return BaseResult.OK();
    }

    /**
     * 添加明细
     *
     * @param req
     * @return BaseResult<String>
     */
    @PostMapping("/add")
    @LoginCheck
    public BaseResult<String> add(@RequestBody @Validated DictItemAddReq req) {

        DictItemAddParam param = BeanUtil.copyProperties(req, DictItemAddParam.class);

        try {
            iDictItemService.add(param);
        } catch (DataAccessException e) {
            // 捕获添加时code冲突
            log.error("DictItemController.add.exception.message:{}", "唯一键冲突", e);
            return BaseResult.packageObject(null, GlobalCodeEnum.GL_FAIL_9994.getCode(), "该类型编码已存在");
        } catch (BizException e) {
            return BaseResult.packageObject(null, GlobalCodeEnum.GL_FAIL_9994.getCode(), e.getErrMessage());
        } catch (Exception e) {
            log.error("DictItemController.add.exception", e);
            return BaseResult.packageObject(null, GlobalCodeEnum.GL_FAIL_9994.getCode(), "添加失败");
        }

        return BaseResult.OK();
    }

    /**
     * 明细详情
     *
     * @param id
     * @return BaseResult<DictItemDetailResp>
     */
    @GetMapping("/detail")
    @LoginCheck
    public BaseResult<DictItemDetailResp> detail(@RequestParam("id") Long id) {

        DictItemDetailDto detail = iDictItemService.detail(id);

        DictItemDetailResp resp = BeanUtil.copyProperties(detail, DictItemDetailResp.class);
        return BaseResult.OK(resp);
    }

    /**
     * 编辑明细
     *
     * @param req
     * @return BaseResult<String>
     */
    @PostMapping("/edit")
    @LoginCheck
    public BaseResult<String> edit(@RequestBody @Validated DictItemEditReq req) {

        DictItemEditParam param = BeanUtil.copyProperties(req, DictItemEditParam.class);
        iDictItemService.edit(param);

        return BaseResult.OK();
    }

    /**
     * 根据数据字典code获取明细
     *
     * @param dictCode 详情见https://wiki.jiduauto.com/pages/viewpage.action?pageId=249595748
     * @return BaseResult<DictResp>
     */
    @GetMapping("/getItemByDictCode")
    public BaseResult<List<DictItemResp>> getItemByDictCode(@RequestHeader("bizType") String bizType,
                                                            @RequestParam("dict") String dictCode,
                                                            @RequestParam("status") Boolean status,
                                                            @RequestParam(value = "bizType", required = false) String bt) {
        if (StringUtils.isEmpty(dictCode)) {
            return BaseResult.packageObject(null, GlobalCodeEnum.GL_FAIL_9998.getCode(), "数据字典code为空");
        }
        if (bizType == null && bt == null) {
            return BaseResult.error("当前业务类型为空");
        }
        List<DictItemDto> dtoList = iDictItemService.getItemByDictCode(StrUtil.emptyToDefault(bt, bizType), dictCode, status);

        List<DictItemResp> resp = BeanUtil.copyToList(dtoList, DictItemResp.class);
        return BaseResult.OK(resp);
    }

    /**
     * 模糊查询
     */
    @RequestMapping("/pageList")
    public BaseResult<BasePageData<DictItemResp>> pageList(@RequestBody @Valid BasePageParam<DictItemReq> params) {
        return BaseResult.OK(iDictItemService.pageList(params));
    }

}
