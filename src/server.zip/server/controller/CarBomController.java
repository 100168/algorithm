package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.pojo.dto.CarBomDto;
import com.jiduauto.sps.sdk.pojo.dto.CarBomItemDto;
import com.jiduauto.sps.sdk.pojo.fileExport.CarBomItemExportDto;
import com.jiduauto.sps.sdk.pojo.fileImport.CarBomImportResultResp;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultDataResp;
import com.jiduauto.sps.sdk.pojo.po.CarBomItemPo;
import com.jiduauto.sps.sdk.pojo.po.CarBomPo;
import com.jiduauto.sps.sdk.pojo.req.*;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.server.client.req.CarBomSyncFeignReq;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.po.CarPo;
import com.jiduauto.sps.server.pojo.vo.resp.ApplyOrderAnItemExportRest;
import com.jiduauto.sps.server.service.ICarBomItemService;
import com.jiduauto.sps.server.service.ICarBomService;
import com.jiduauto.sps.server.service.ICarService;
import com.jiduauto.sps.server.utils.BeanCopierUtil;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.checkerframework.checker.units.qual.C;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 车辆BOM零件信息 前端控制器
 *
 * @author generate
 * @since 2024-04-02
 */
@Slf4j
@RestController
@RequestMapping("/carBom")
public class CarBomController {


    @Resource
    private ICarBomService carBomService;
    @Resource
    private ICarService carService;

    @Resource
    private ICarBomItemService carBomItemService;


    /**
     * 分页查询
     * @return
     */
    @PostMapping("pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<CarBomDto>> pageSearch(@RequestBody @Valid BasePageParam<CarBomPageSearchReq> pageParam){

        return BaseResult.OK(carBomService.pageSearch(pageParam));
    }


    /**
     * 从BOM拉取数据
     * @return
     */
    @PostMapping("syncFromBom")
    @ResponseBody
    public BaseResult syncFromBom(@RequestBody @Valid CarBomSyncReq carBomSyncReq){

        return carBomService.syncFromBom(carBomSyncReq);
    }


    /**
     * 删除
     * @return
     */
    @PostMapping("deleteById")
    @ResponseBody
    public BaseResult deleteById(@RequestBody @Valid IdReq idReq){
        carBomService.deleteById(idReq.getId());
        return BaseResult.OK();
    }

    /**
     * 明细查询
     * @param carBomItemPageSearchReq
     * @return
     */
    @PostMapping("itemList")
    @ResponseBody
    public BaseResult<BasePageData<CarBomItemDto>> itemList(@RequestBody @Valid BasePageParam<CarBomItemPageSearchReq> carBomItemPageSearchReq){
        return BaseResult.OK(carBomService.itemList(carBomItemPageSearchReq));
    }


    @PostMapping("updateWorkStation")
    @ResponseBody
    public BaseResult updateWorkStation(@RequestBody @Valid CarBomItemUpdateReq carBomItemUpdateReq){
        carBomService.updateWorkStation(carBomItemUpdateReq);
        return BaseResult.OK();
    }

    /**
     * 单车BOM 信息查询
     * @return
     */
    @PostMapping("detailById")
    @ResponseBody
    public BaseResult<CarBomDto> detailById(@RequestBody @Valid IdReq idReq){
        CarBomPo carBomPo = carBomService.getById(idReq.getId());
        CarPo carPo = carService.getOne(Wrappers.lambdaQuery(CarPo.class)
                .eq(CarPo::getCode,carBomPo.getCarNo())
                .eq(CarPo::getBizType,idReq.getBizType()));
        if(carPo != null){
            carBomPo.setProject(carPo.getProjectTypeCode());
            carBomPo.setStage(carPo.getStageSpecCode());
        }
        return BaseResult.OK(BeanCopierUtil.copy(carBomPo,CarBomDto.class));
    }

    /**
     * 重新从BOM同步最新信息(更新按钮)
     * @return
     */
    @PostMapping("syncAgain")
    @ResponseBody
    public BaseResult syncAgain(@RequestBody @Valid IdReq idReq){
        return carBomService.syncAgain(idReq.getId());
    }



    /**
     * 导出  所有明细
     * @return
     */
    @PostMapping("export")
    @ResponseBody
    public void export(HttpServletResponse response, @RequestBody @Valid CarBomPageSearchReq searchReq){
        try {
            ExcelUtils.exportXlsxResponse(response, "单车bom信息导出");
            EasyExcel.write(response.getOutputStream(),  CarBomItemExportDto.class)
                    .sheet("模板")
                    .doWrite(carBomService.exportSearch(searchReq));
        } catch (Exception e) {
            log.error("导出异常",e);
            throw new BizException(e.getMessage());
        }
    }


    /**
     * 编辑保存
     * @param carBomUpdateReq
     * @return
     */
    @PostMapping("update")
    @ResponseBody
    public BaseResult update(@RequestBody @Valid CarBomUpdateReq carBomUpdateReq){

        carBomService.updateEdit(carBomUpdateReq);

        return BaseResult.OK();
    }


    /**
     * 工位导入
     * @param bizType
     * @param id  主键
     * @param file
     * @return
     */
    @PostMapping("/importWorkStation")
    @ResponseBody
    public BaseResult<ImportResultDataResp<CarBomImportResultResp>> importWorkStation(@RequestHeader("bizType") String bizType ,
                                                                                      @RequestParam("id") Long id,
                                                                                      @RequestPart("file") MultipartFile file){
        if (StringUtils.isBlank(bizType)) {
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9998);
        }
        ImportResultDataResp<CarBomImportResultResp>  resp = carBomService.importWorkStation(file, id,bizType);
        return BaseResult.OK(resp);
    }

}
