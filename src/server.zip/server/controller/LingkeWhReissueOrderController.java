package com.jiduauto.sps.server.controller;


import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.sdk.pojo.dto.LingkeWhReissueOrderAllDto;
import com.jiduauto.sps.sdk.pojo.dto.LingkeWhReissueOrderDto;
import com.jiduauto.sps.sdk.pojo.req.ExtensionImportResultResp;
import com.jiduauto.sps.sdk.pojo.resp.LingkeWhReissueOrderExportResp;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.service.ILingkeWhReissueOrderService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 领克仓补差异订单 前端控制器
 *
 * @author generate
 * @since 2023-12-11
 */
@RestController
@RequestMapping("/lingkeWhReissueOrder")
public class LingkeWhReissueOrderController {

    @Resource
    private ILingkeWhReissueOrderService lingkeWhReissueOrderService;


    /**
     * 编辑详情
     */
    @PostMapping("/editDetail")
    public BaseResult<String> editDetail(@RequestBody @Valid LingkeWhReissueOrderDetailEditReq req) {
        lingkeWhReissueOrderService.editDetail(req);
        return BaseResult.OK();
    }

    /**
     * 页面 提交审核
     */
    @PostMapping("/commit")
    public BaseResult<String> edit(@RequestBody NoReq req) {
        lingkeWhReissueOrderService.commit(req);
        return BaseResult.OK();
    }

    /**
     * 删除
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody NoReq req) {
        lingkeWhReissueOrderService.delete(req);
        return BaseResult.OK();
    }

    /**
     * 编辑主数据
     */
    @PostMapping("/edit")
    public BaseResult<String> edit(@RequestBody @Valid LingkeWhReissueOrderEditReq req) {
        lingkeWhReissueOrderService.edit(req);
        return BaseResult.OK();
    }

    /**
     * 提交审批 & 保存
     */
    @PostMapping("/commitAudit")
    public BaseResult<String> commitAudit(@RequestBody LingkeWhReissueOrderEditReq req) {
        return lingkeWhReissueOrderService.commitAudit(req);
    }

    /**
     * 转采购申请
     * @param req no为差异单单号
     */
    @PostMapping("/turnOrder")
    public BaseResult<String> turnOrder(@RequestBody NoReq req) {
        lingkeWhReissueOrderService.createPRandPushSAP(req.getNo(), true);
        return BaseResult.OK();
    }

    /**
     * 领克仓补单 分页
     *
     * @author O_chaopeng.huang
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<LingkeWhReissueOrderAllDto>> pageSearch(
            @RequestBody @Valid BasePageParam<LingkeWhReissueOrderPageSearchReq> pageParam) {
        return BaseResult.OK(lingkeWhReissueOrderService.pageSearch(pageParam));
    }

    /**
     * 领克仓补单 详情
     *
     * @author O_chaopeng.huang
     */
    @PostMapping("/selectById")
    public BaseResult<LingkeWhReissueOrderDto> selectById(@RequestBody @Valid IdReq req) {
        return BaseResult.OK(lingkeWhReissueOrderService.selectById(req));
    }

    /**
     * 领克仓补单 导出
     *
     * @author O_chaopeng.huang
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response, @RequestBody @Valid BasePageParam<LingkeWhReissueOrderPageSearchReq> pageParam) {
        try {
            ExcelUtils.exportXlsxResponse(response, "领克仓补单导出");
            EasyExcel.write(response.getOutputStream(), LingkeWhReissueOrderExportResp.class)
                    .sheet("模板")
                    .doWrite(lingkeWhReissueOrderService.export(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

    /**
     * 导入订单
     */
    @PostMapping("/import")
    public BaseResult<ExtensionImportResultResp> importWhReissueOrder(@RequestHeader("bizType") String bizType,
                                                                      @RequestPart("file") MultipartFile file,
                                                                      @RequestParam("fileUid") String fileUid
    ) {
        if (StrUtil.isEmpty(fileUid)) {
            throw new BizException("fileUid can't be null");
        }
        return BaseResult.OK(lingkeWhReissueOrderService.importWhReissueOrder(bizType, file, fileUid));
    }

}
