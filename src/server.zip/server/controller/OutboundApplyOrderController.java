package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.sdk.pojo.fileExport.OutboundApplyOrderDetailExportDto;
import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.AdvicePickDto;
import com.jiduauto.sps.server.pojo.dto.OutboundApplyOrderDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;
import com.jiduauto.sps.server.pojo.vo.req.OutboundApplyOrderPageSearch;
import com.jiduauto.sps.server.pojo.vo.req.PickBatchReq;
import com.jiduauto.sps.server.service.IOutboundApplyOrderService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 出库申请 前端控制器
 *
 * @author generate
 * @since 2023-06-27
 */
@Slf4j
@RestController
@RequestMapping("/outboundApplyOrder")
public class OutboundApplyOrderController {

    @Resource
    private IOutboundApplyOrderService outboundApplyOrderService;

    /**
     * 拣货
     * status = success 表示成功
     * status = zero 表示存在库存为0
     * status = part 表示库存可以部分
     *
     * @param pickBatchReq batchIdReq
     * @return BaseResult
     */
    @PostMapping("/pick")
    @LoginCheck
    public BaseResult<AdvicePickDto> pick(@RequestBody @Valid PickBatchReq pickBatchReq) {
        return BaseResult.OK(outboundApplyOrderService.proxyPick(pickBatchReq));
    }

    /**
     * 出库申请分页查询接口
     *
     * @param req
     * @return BaseResult<BasePageData < ApplyOrderDto>>
     * @author O_chaopeng.huang
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<OutboundApplyOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<OutboundApplyOrderPageSearch> req) {
        return BaseResult.OK(outboundApplyOrderService.pageSearch(req));
    }

    /**
     * 出库申请详情接口
     *
     * @param req
     * @return BaseResult<BasePageData < ApplyOrderDto>>
     * @author O_chaopeng.huang
     */
    @PostMapping("/selectById")
    @ResponseBody
    public BaseResult<OutboundApplyOrderDto> selectById(@RequestBody @Valid IdReq req) {
        return outboundApplyOrderService.selectById(req);
    }

    /**
     * 拣货确认
     *
     * @param req req
     * @return BaseResult
     */
    @PostMapping("/confirm")
    @ResponseBody
    public BaseResult<Boolean> confirm(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(outboundApplyOrderService.confirm(req));
    }

    /**
     * 撤销
     *
     * @param req req
     * @return BaseResult
     */
    @PostMapping("/repeal")
    @ResponseBody
    public BaseResult<Boolean> repeal(@RequestBody @Valid IdReq req) {
        return BaseResult.OK(outboundApplyOrderService.repeal(req));
    }


    /**
     * 导出 拉料 缺少库存的零件信息
     * @param response
     * @param req
     */
    @PostMapping("exportMaterialByLackStock")
    public void exportMaterialByLackStock(HttpServletResponse response, @RequestBody @Valid OrderNoReq req) {
        try {
            ExcelUtils.exportXlsxResponse(response, "缺料bom零件信息导出");
            EasyExcel.write(response.getOutputStream(),  OutboundApplyOrderDetailExportDto.class)
                    .sheet("模板")
                    .doWrite(outboundApplyOrderService.exportMaterialByLackStock(req.getOrderNo(),req.getBizType()))
            ;
        } catch (Exception e) {
            log.error("导出异常",e);
            throw new BizException(e.getMessage());
        }
    }
}
