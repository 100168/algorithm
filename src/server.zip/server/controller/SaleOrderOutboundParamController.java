package com.jiduauto.sps.server.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 销售订单出库关系表 前端控制器
 * </p>
 *
 * @author generate
 * @since 2023-07-10
 */
@RestController
@RequestMapping("/server/saleOrderOutboundParam")
public class SaleOrderOutboundParamController {

}
