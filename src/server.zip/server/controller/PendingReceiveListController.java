package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PendingReceiveListDto;
import com.jiduauto.sps.server.pojo.fileexport.PendingReceiveExportDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.service.IPendingReceiveListService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;


/**
 * 待收货列表 前端控制器
 *
 * @author generate
 * @since 2023-08-22
 */
@RestController
@RequestMapping("/pendingReceiveList")
@Slf4j
public class PendingReceiveListController {

    @Resource
    private IPendingReceiveListService pendingReceiveListService;


    /**
     * 创建（测试使用）
     *
     * @param req req
     * @return BaseResult<BasePageData < PendingReceiveListDto>>
     */
    @PostMapping("/create")
    @ResponseBody
    public BaseResult<String> create(@RequestBody @Valid PendingReceiveListCreateReq req) {
        return BaseResult.OK(pendingReceiveListService.create(req));
    }
    /**
     * 待收货列表分页查询
     *
     * @param req req
     * @return BaseResult<BasePageData < PendingReceiveListDto>>
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<PendingReceiveListDto>> pageSearch(@RequestBody @Valid BasePageParam<PendingReceiveListPageSearch> req) {
        return BaseResult.OK(pendingReceiveListService.pageSearch(req));
    }

    /**
     * 关单
     *
     * @param req req
     * @return BaseResult<BasePageData < PendingReceiveListDto>>
     */
    @PostMapping("/close")
    @ResponseBody
    public BaseResult<Boolean> close(@RequestBody @Valid PendingReceiveListCloseReq req) {
        return BaseResult.OK(pendingReceiveListService.close(req));
    }

    /**
     * 删单
     */
    @PostMapping("/delete")
    @ResponseBody
    public BaseResult<String> delete(@RequestBody @Valid IdReq req) {
        pendingReceiveListService.delete(req);
        return BaseResult.OK();
    }

    /**
     * 收货
     *
     * @param req req
     * @return BaseResult<BasePageData < PendingReceiveListDto>>
     */
    @PostMapping("/receive")
    @ResponseBody
    public BaseResult<Boolean> receive(@RequestBody @Valid PendingReceiveListReceiveReq req) {
        return BaseResult.OK(pendingReceiveListService.receive(req));
    }

    /**
     * 异地收货
     */
    @PostMapping("/remotePlace/receive")
    @ResponseBody
    public BaseResult<Boolean> remotePlaceReceive(@RequestBody @Valid PendingReceiveListReceiveReq req) {
        return BaseResult.OK(pendingReceiveListService.remotePlaceReceive(req));
    }

    /**
     * 导出
     **/
    @PostMapping("/export")
    public void export(HttpServletResponse response, @RequestBody @Valid BasePageParam<PendingReceiveListPageSearch> req) {
        try {
            req.setPage(BaseConstants.ImportExport.PAGE_START_AT); // 导出最大返回前10000条
            req.setSize(BaseConstants.ImportExport.MAX_SIZE_10000);
            ExcelUtils.exportXlsxResponse(response, "待收货查询结果");
            EasyExcel.write(response.getOutputStream(), PendingReceiveExportDto.class)
                    .sheet("查询结果").doWrite(pendingReceiveListService.exportSearch(req));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw new BizException(e.getMessage());
        }
    }
}
