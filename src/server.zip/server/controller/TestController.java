package com.jiduauto.sps.server.controller;


import cn.hutool.core.date.DateUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.jiduauto.business.crm.auth.api.model.mq.OrganizationCreateMesPO;
import com.jiduauto.business.crm.auth.api.model.rpc.response.OrganizationRpcItem;
import com.jiduauto.passport.conf.UserInfoThreadHolder;
import com.jiduauto.sps.api.enums.OperationType;
import com.jiduauto.sps.sdk.client.req.StockOutMapBusinessDto;
import com.jiduauto.sps.sdk.client.req.StockOutMapBusinessItemDto;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.enums.OperateTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.BackOrderPo;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.Enum.GenerateSerialEnum;
import com.jiduauto.sps.server.Enum.GlobalCodeEnum;
import com.jiduauto.sps.server.caches.DictItemCache;
import com.jiduauto.sps.server.client.ChargePartnerClient;
import com.jiduauto.sps.server.client.LingkeClient;
import com.jiduauto.sps.server.client.TestClient;
import com.jiduauto.sps.server.client.WmsClient;
import com.jiduauto.sps.server.client.req.DHLOutboundReq;
import com.jiduauto.sps.server.client.req.LingkeBOCancelReq;
import com.jiduauto.sps.server.client.resp.ResultResp;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.controller.external.StockExternalController;
import com.jiduauto.sps.server.convertor.PurchaseOrderConvertor;
import com.jiduauto.sps.server.excel.AsnImportHandler;
import com.jiduauto.sps.server.excel.ExtendExportDto;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.exception.RetryException;
import com.jiduauto.sps.server.mq.producer.StockOperationSyncProducer;
import com.jiduauto.sps.server.pojo.dto.ApplyOrderAllInfoDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseOrderDto;
import com.jiduauto.sps.server.pojo.dto.SynchoResultDto;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.dto.stock.StockPutOutResultMessage;
import com.jiduauto.sps.server.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.http.HttpBaseResponse;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.pojo.vo.req.stock.PoOccupyStockReq;
import com.jiduauto.sps.server.pojo.vo.resp.AsnImportResp;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.service.impl.stock.SapServiceImpl;
import com.jiduauto.sps.server.service.impl.stock.StockSPServiceImpl;
import com.jiduauto.sps.server.threads.SAPThread;
import com.jiduauto.sps.server.utils.*;
import com.jiduauto.sps.server.xxljobs.OutboxMessageXxlJob;
import com.jiduauto.sps.server.xxljobs.StockIn2ReceiveOrderJob;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Flux;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * @author generate
 * @since 2022-12-14
 */
@RestController
@RequestMapping("/test")
@AllArgsConstructor
@Slf4j
public class TestController {

    @Autowired
    private ChargePartnerClient chargePartnerClient;

    @Resource
    private RedissonClient redissonClient;
    @Autowired
    private IStockService stockService;

    @Autowired
    private IStockItemService stockItemService;
    @Autowired
    private StockCommonService stockCommonService;

    @Resource
    private final IAsnBasicService asnBasicService;
    @Resource
    private final ICommonService commonService;
    @Resource

    private final AsnImportHandler asnImportHandler;

    @Autowired
    private final ISupplierService supplierService;
    @Resource
    private PurchaseOrderConvertor purchaseOrderConvertor;


    @Resource
    private GenerateSerialNoUtil generateSerialNoUtil;

    @Resource
    private StringRedisTemplate stringRedisTemplate;

    @Resource
    private OutboxMessageXxlJob outboxMessageXxlJob;
    @Autowired
    private IApplyOrderService applyOrderService;

    @Resource
    private DictItemCache dictItemCache;

    @Resource
    private LingkeClient lingkeClient;

    @Resource
    private IStockCheckOrderService stockCheckOrderService;

    @PostMapping("/sleep")
    public BaseResult<String> sleep(){
        try {
            Thread.sleep(11000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return BaseResult.OK("success");
    }

    @PostMapping("/prCancel")
    public BaseResult<Object> lingkePoCancel(@RequestBody PRDetailCancelReq param) {
        return BaseResult.OK(lingkeClient.prCancel(param));
    }

    @PostMapping("/boCancel")
    public BaseResult<Object> boCancel(@RequestBody LingkeBOCancelReq param) {
        return BaseResult.OK(lingkeClient.boCancel(param));
    }

    @PostMapping("/addRedisNo")
    public BaseResult<String> addRedisNo() {
        String redisKeyPO = String.format(com.jiduauto.sps.sdk.consts.BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "PR",
                com.jiduauto.sps.sdk.utils.DateUtils.getDateStr(DateUtil.date(), com.jiduauto.sps.sdk.utils.DateUtils.SHORT_DATE_FORMAT_2),
                "SP");

        Long serialNo = redisUtil.incrAndExpire(redisKeyPO, 1000L,
                24 * 60 * 60);

        String dateFormat = DateUtils.format(LocalDateTime.now(), BaseConstants.DatePattern.NO_DATE);
        String redisKeyOrderPlan = String.format(BaseConstants.RedisKey.ORDER_PLAN_SERIAL_NO_KEY, dateFormat);
        Long serialNoOrderPlan = redisUtil.incrAndExpire(redisKeyOrderPlan, 1000L,
                24 * 60 * 60);
        return BaseResult.OK("success");
    }


    @RequestMapping("/testException")
    @ResponseBody
    public BaseResult testException(@RequestBody AsnPushReq asnPushReq) {
        throw new BizException("天王盖地虎");
    }
    @Resource
    IBosService bosService;

    @RequestMapping("file")
    public BaseResult saveFile(MultipartFile file) {
        try {
            //FileUtil.saveFileToLocal(file.getInputStream(), file.getName(), FileUtil.SUFFIX);
            try(InputStream inputStream = file.getInputStream()){
                System.out.println(file.getOriginalFilename());
                BosFileResult bosFileResult = bosService.uploadFile(inputStream, file.getOriginalFilename());
                if (bosFileResult == null){
                    throw new BizException( "请求log文件上传BOS失败！");
                }
                System.out.println(JSON.toJSONString(bosFileResult));
            }catch (Exception e){
                log.error("updateRequestUrl", e);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return BaseResult.OK();
    }


    @RequestMapping("getStockKeyByOrderOutNo/{orderNo}")
    @ResponseBody
    public BaseResult<Map<String, Map<String, InAndOutStockParam>>> getStockKeyByOrderOutNo(
            @RequestHeader("bizType") String bizType,
            @PathVariable String orderNo) {
        return BaseResult.OK(stockService.getStockKeyByOrderOutNo(bizType, orderNo));
    }

    @RequestMapping("getStockKeyByOrderInNo/{orderNo}")
    @ResponseBody
    public BaseResult<Map<String, Map<String, InAndOutStockParam>>> getStockKeyByOrderInNo(
            @RequestHeader("bizType") String bizType,
            @PathVariable String orderNo) {
        return BaseResult.OK(stockService.getStockKeyByOrderInNo(bizType, orderNo));

    }

    @PostMapping("/import")
    public BaseResult<ImportResultResp> importAsn(@RequestPart("file") MultipartFile file,
            @RequestHeader("bizType") String bizType) {
        log.info("AsnBasicController-import-param:{}", bizType);
        commonService.checkExcelFile(file);

        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        importParam.setParam(bizType);
        //导入
        ImportReturnDataInfo<ExtendExportDto<AsnImportResp>> resp = asnImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return BaseResult.OK(resultResp);
    }



    @RequestMapping("/convertor")
    public BaseResult<Map<String, BigDecimal>> convertor() {

        PurchaseOrderPo purchaseOrderPo = new PurchaseOrderPo();

        ArrayList<PurchaseOrderPo> purchaseOrderPos = new ArrayList<>();
        for (int j = 0; j < 1000000; j++) {
            purchaseOrderPos.add(new PurchaseOrderPo());
        }
        long start = DateUtil.date().getTime();
        List<PurchaseOrderDto> purchaseOrderDtos = purchaseOrderConvertor.toDtoList(purchaseOrderPos);
        long end1 = DateUtil.date().getTime();
        long costMapStruct = end1 - start;
        for (int j = 0; j < 1000000; j++) {
            BeanCopierUtil.copy(purchaseOrderPo, PurchaseOrderDto.class);
        }
        long end2 = DateUtil.date().getTime();
        long costBeanCopier = (end2 - end1);


//        for (int i = 0; i < 1000000; i++) {
//            PurchaseOrderDto purchaseOrderDto = new PurchaseOrderDto();
//            BeanUtils.copyProperties(purchaseOrderPo,purchaseOrderDto);
//        }
//        long end3 = DateUtil.date().getTime();
//        long costBeanUtils = (end3-end2);

//        for (int i = 0; i < 100000; i++) {
//            PurchaseOrderDto purchaseOrderDto = new PurchaseOrderDto();
//            BeanUtil.copyProperties(purchaseOrderPo,purchaseOrderDto,"commitTime");
//        }
//        long end4 = DateUtil.date().getTime();
//        long costBeanUtil = (end4-end3);

        HashMap<String, BigDecimal> ansMap = new HashMap<>();
        ansMap.put("costMapStruct", BigDecimal.valueOf(costMapStruct));
        ansMap.put("costBeanCopier", BigDecimal.valueOf(costBeanCopier));
        ansMap.put("costBeanCopier/costMapStruct",
                BigDecimal.valueOf(costBeanCopier).divide(BigDecimal.valueOf(costMapStruct), RoundingMode.UP));
//        ansMap.put("costBeanUtils",costBeanUtils);
//        ansMap.put("costBeanUtil",costBeanUtil);

        return BaseResult.OK(ansMap);

    }

    @Autowired
    IStockTempService stockTempService;

    @PostMapping("/occupy")
    public BaseResult occupy(@RequestBody @Valid PoOccupyStockReq request) {
        return stockTempService.poOccupyPartStock(request);
    }
    @Autowired
    private IStoreService storeService;

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private WebhookUtil webhookUtil;

    @PostMapping("/testMq1")
    public BaseResult testMq1(@RequestBody @Valid PoOccupyStockReq request) {
        return stockTempService.poOccupyPartStock(request);
    }

    @PostMapping("/testMq2")
    public void testMq2(@RequestBody @Valid Object m) {
        String message = JSON.toJSONString(m);
        log.info(message.toString());
        OrganizationCreateMesPO po = null;
        try {
            po = JSON.parseObject(message.toString(), OrganizationCreateMesPO.class);

            List<OrganizationRpcItem> list = po.getItemList();
            if (CollectionUtils.isNotEmpty(list)) {
                storeService.syncFromCrm(list);
            }
        } catch (Exception e) {
            //以消息组装时间作为唯一key
            if (Objects.nonNull(po) && Objects.nonNull(po.getCurrentTime())) {
                String key = String.valueOf(po.getCurrentTime());
                boolean b = redisUtil.hasKey(key);
                if (b) {
                    //获取
                    long incr = redisUtil.incr(key, 1L);
                    if (incr >= 10) {
                        webhookUtil.sendTextMessage("同步门店数据出问题啦,快来看看我" + po.toString());
                        redisUtil.del(key);
                    }
                } else {
                    redisUtil.set(key, String.valueOf(1));
                }
            }
            log.info("异常:{}", e.getMessage());
            throw new RuntimeException(e);
        }
    }

    @PostMapping("/generateSerial")
    public String generateSerial() {
        Properties info = stringRedisTemplate.getRequiredConnectionFactory().getConnection().info("server");
        val map = new HashMap<String, String>();
        map.put("orderNo", generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.PO, BizTypeEnum.SP.getBizType()));
        String dateStr = DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2);
        val redisKey = generateSerialNoUtil.getRedisKey(GenerateSerialEnum.PO, dateStr, BizTypeEnum.SP.getBizType());
        val redisKeyValue = (String) redisUtil.get(redisKey);
        map.put(redisKey,redisKeyValue);
        map.put("redisInfo",JSONUtil.toJsonStr(info));
        return JSONUtil.toJsonStr(map);

    }
    private static ExecutorService executorService = Executors.newFixedThreadPool(8);

    @Resource
    TestClient testClient;

    @PostMapping("/testRetry")
    public BaseResult testRetry(){
        testClient.testRetry();
        return BaseResult.OK();
    }

    @GetMapping("/outbox")
    public BaseResult outbox() throws Exception {
        outboxMessageXxlJob.handleAllOutboxMessage("");
        return BaseResult.OK();
    }

    @Autowired
    private StockExternalController externalController;
    @Resource
    private com.jiduauto.sps.server.service.impl.SpsOrderDataQuery spsOrderDataQuery;

    @PostMapping("mockDHlPutOutStock")
    public BaseResult mockDHlPutOutStock(@RequestBody PutOutStockRequest request){
        log.info("外部出库api参数:"+ JSON.toJSONString(request));
        request.setBizType("SP");
        List<InAndOutStockParam> params = new ArrayList<>();
        List<SaleOrderDetailPo> saleOrderDetailPos = spsOrderDataQuery.selectSODetailList(request.getTradeNo());
        //saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
               // .eq(SaleOrderDetailPo::getSaleOrderNo, request.getTradeNo()));
        Set<String> materialCodes ;
        Set<String> warehouseCodes = new HashSet<>();
        warehouseCodes.add("G59");
        Set<Integer> materialStatus = new HashSet<>();
        materialStatus.add(1);
        Set<Integer> stockStatus = new HashSet<>();
        stockStatus.add(1);
        for(SaleOrderDetailPo detailPo:saleOrderDetailPos){
            materialCodes = new HashSet<>();
            materialCodes.add(detailPo.getSalePartNum());
            List<StockItemPo>  pos = stockItemService.outStockSearch(request.getBizType(),materialCodes,warehouseCodes,
                    null,
                    null,materialStatus,stockStatus);
            if(CollectionUtils.isEmpty(pos)){
                throw new BizException(-1,detailPo.getSalePartNum()+"库存记录不存在，请检查");
            }
            InAndOutStockParam param = new InAndOutStockParam();
            param.setSumQuantity(detailPo.getQty());
            param.setMaterialStatus(1);
            param.setStockStatus(1);
            param.setMaterialCode(detailPo.getSalePartNum());
            param.setWarehouseCode("G59");
            for(StockItemPo stockItemPo:pos){
                if(stockItemPo.getSumQuantity().compareTo(detailPo.getQty()) > 0){
                    param.setSupplierCode(stockItemPo.getSupplierCode());
                    param.setBatchNo(stockItemPo.getBatchNo());
                    params.add(param);
                    break;
                }
            }
        }


        InAndOutStockRequest newRequest = BeanCopierUtil.copy(request,InAndOutStockRequest.class);
        newRequest.setBusinessBillNo(request.getTradeNo());
        newRequest.setBizType("SP");
//        newRequest.setWmsFlag(true);
        newRequest.setOperationType(OperationType.UN_OCCUPY_SUBTRACT);
        newRequest.setIdempotentNo(request.getTradeNo());
        newRequest.setBusinessType("SP20");
        newRequest.setOperateTime(LocalDateTime.now());
        newRequest.setOperateUser("hhhhhhh");
        newRequest.setParams(params);

        String lockKey = String.format(BaseConstants.RedisKey.STOCK_LOCK_KEY,request.getBizType(),request.getBusinessBillNo());
        RLock rLock = redissonClient.getLock(lockKey);
        try{
            rLock.lock();
            return stockCommonService.putOutStock(newRequest);
        }catch (RetryException e){
            throw e;
        }catch (BizException e){
            log.error("入库操作异常",e);
            return BaseResult.systemError(e.getErrCode(),e.getErrMessage());
        }catch (Exception e){
            log.error("入库操作异常",e);
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9999);
        }finally {
            rLock.unlock();
        }
    }

    @PostMapping("testApplyOrder")
    public void testApplyOrder(@RequestBody  StockPutOutResultMessage resultMessage){
        // 零备件 精品的领料单 出库
        if(resultMessage.getResult() == 1){
            List<ApplyOrderAllInfoDto> outQuantityList = new ArrayList<>();
            for(InAndOutStockParam param: resultMessage.getStockParams()){
                ApplyOrderAllInfoDto dto = new ApplyOrderAllInfoDto();
                dto.setApplySumItem(param.getSumQuantity());
                dto.setMaterialCode(param.getMaterialCode());
                dto.setLineNo(param.getColumnNo());
                dto.setWarehouseCode(param.getWarehouseCode());
                outQuantityList.add(dto);
            }
            applyOrderService.updateDeliverQty(resultMessage.getTradeNo(),resultMessage.getSapNoForSo() , outQuantityList);
        }
    }

    @PostMapping("testRedis")
    public void testRedis(){
        JVMCachesReq req = new JVMCachesReq();
        req.setBizType("SP");
        redisUtil.convertAndSend(BaseConstants.RocketMqTopic.CACHES_DELETE,JSON.toJSONString(req));
    }

    @PostMapping("testCache")
    @ResponseBody
    public Map<String, String> testCache(String dictCode){
       return dictItemCache.getCodeAndNameMap(dictCode);
    }

    @Autowired
    private StockSPServiceImpl stockSPService;
    @Autowired
    private SapServiceImpl sapService;

    @PostMapping("sendSd014")
    public void sendSd014(@RequestBody  @Valid InAndOutStockRequest request){
        sapService.updateStockSp20ToSAP(request);
    }

    @Autowired
    private WmsClient wmsClient;
    @PostMapping("testWmsClient")
    @ResponseBody
    @Deprecated
    public ResultResp<Object> testWmsClient(@RequestBody DHLOutboundReq dhlOutboundReq){
       return wmsClient.outbound(dhlOutboundReq);
    }


    @Autowired
    private StockOperationSyncProducer stockOperationSyncProducer;
    @PostMapping("testMqOrder")
    @ResponseBody
    public ResultResp<Object> testMqOrder(@RequestBody   InAndOutStockRequest request){
          for(int i =0; i < 10; i ++){
              if(i % 2 == 0){
                  request.setBizType("SP");
              }else{
                  request.setBizType("SM");
              }
//              stockOperationSyncProducer.putOutResult(request);
          }
          return ResultResp.error(1,"");
    }


    @PostMapping("testSAP")
    @ResponseBody
    public ResultResp<Object> testSAP(){
        List<Future<HttpBaseResponse>> futures = new ArrayList<>();

        for(int i =0; i < 5; i++){
            String json = "{\n" +
                    "    \"MessageHeader\": {\n" +
                    "        \"Sender\": \"SPS\",\n" +
                    "        \"SerialNum\": \"1690859187879"+i+"\",\n" +
                    "        \"SendTime\": \"110627\",\n" +
                    "        \"SendDate\": \"20230801\",\n" +
                    "        \"InterfaceID\": \"MM_033\"\n" +
                    "    },\n" +
                    "    \"MessageBody\": {\n" +
                    "        \"Header\": {\n" +
                    "            \"Type\": \"40\",\n" +
                    "            \"Header_Key\": \"DHL-1690859185"+i+"\",\n" +
                    "            \"Receiver\": \"SAP\",\n" +
                    "            \"PostDate\": \"20230717\",\n" +
                    "            \"RequestUser\": \"UATSZXP0025\",\n" +
                    "            \"RequestNo\": \"SM-JO2380100001"+i+"\"\n" +
                    "        },\n" +
                    "        \"Item1\": [\n" +
                    "            {\n" +
                    "                \"RequestQty\": \"1\",\n" +
                    "                \"MaterialId\": \"J99L01001A\",\n" +
                    "                \"Plant\": \"6000\",\n" +
                    "                \"RequestItem\": 1,\n" +
                    "                \"StockId\": \"6002\",\n" +
                    "                \"orderunit\": \"EA\",\n" +
                    "                \"Item_Key\": \"1690859187879\"\n" +
                    "            },\n" +
                    "            {\n" +
                    "                \"RequestQty\": \"1\",\n" +
                    "                \"MaterialId\": \"A990000007\",\n" +
                    "                \"Plant\": \"6000\",\n" +
                    "                \"RequestItem\": 2,\n" +
                    "                \"StockId\": \"6002\",\n" +
                    "                \"orderunit\": \"EA\",\n" +
                    "                \"Item_Key\": \"1690859187879\"\n" +
                    "            }\n" +
                    "        ]\n" +
                    "    }\n" +
                    "}";
            Future<HttpBaseResponse> future =  executorService.submit(new SAPThread(json));
            futures.add(future);
        }


        try{
            for(Future<HttpBaseResponse> temp : futures){
                System.out.println("##############"+JSON.toJSONString(temp.get()));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }


    @Autowired
    private IStockOperationHistoryService stockOperationHistoryService;
    @PostMapping("retryPutOut")
    @ResponseBody
    public BaseResult  retryPutOut(@RequestBody  List<Integer> ids){
        if(CollectionUtils.isEmpty(ids)){
            return BaseResult.OK();
        }
        for(Integer id:ids){
            StockOperationHistoryPo po  = stockOperationHistoryService.getById(id);
            if(po == null){
                continue;
            }
            InAndOutStockRequest request = JSON.parseObject(po.getRequestJson(),InAndOutStockRequest.class);
            try {
                BaseResult baseResult = stockService.outOfStock(request);
                log.info(JSON.toJSONString(baseResult));

            } catch (Exception e) {
                log.info("出库重试失败:"+request.getTradeNo());
            }
        }

        return BaseResult.OK();
    }
    @RequestMapping("/testSpToQe")
    @ResponseBody
    public BaseResult  testSpToQe(){
        supplierService.sameSpToQe();
        return BaseResult.OK();
    }
    @RequestMapping("/testEx")
    @ResponseBody
    public BaseResult  testEx(HttpServletRequest req) throws Exception {
        System.out.println((req.getAttribute("User_info")));
        System.out.println((UserInfoThreadHolder.getCurrentUser()));
        throw new Exception("测试");
    }

    @Resource
    private ISalePriceService salePriceService;
    @RequestMapping("/addMore")
    @ResponseBody
    @Transactional
    public BaseResult  addMore()  {

        return BaseResult.OK();
    }

    @Resource
    ISynchroService synchroOrderService;

    @RequestMapping("/testSynchoSearch")
    public BaseResult<SynchoResultDto> testSynchoSearch(@RequestBody BackOrderPo po){
        return BaseResult.OK(synchroOrderService.getAll(po.getEstArrivalTime()));
    }
    @Resource
    private WebhookUtil fsWebhookUtil;
    @RequestMapping("/testfeishu")
    public BaseResult testfeishu(){

        webhookUtil.sendMarkdownMessageV2(-1,"Kit订单同步SAP异常 request:"+ JSON.toJSONString(1)+" result:发大发","Kit订单同步SAP异常",null);
        return BaseResult.OK();
    }

    @Resource
    IStockOutMapBusinessService stockOutMapBusinessService;

    @RequestMapping("/testMap")
    public BaseResult testMap(@RequestBody WmsBillInfoRequest request){
//        stockOutMapBusinessService.stockOutFinished(request);

//        stockOutMapBusinessService.createOrUpdate(updateStockOutMapBusinessDto(request.getBusinessNo(),request.getBusinessOrderType(),request.getBillNo()));
        return BaseResult.OK(commonService.getCityInfoByCode("310100"));
    }

    /**
     * 构建 更新 出库关联订单请求体
     * @param orderNo
     * @param orderType
     * @param logisticsNo
     * @return
     */
    private StockOutMapBusinessDto updateStockOutMapBusinessDto(String orderNo , String orderType, String logisticsNo){
        List<StockOutMapBusinessItemDto> itemDtos = new ArrayList<>();
        StockOutMapBusinessDto dto = new StockOutMapBusinessDto();
        dto.setOrderNo(orderNo);
        dto.setLogisticsNo(logisticsNo);
        dto.setOutType(orderType);
        dto.setOperateType(OperateTypeEnum.UPDATE);
        dto.setDtos(itemDtos);
        return dto;
    }

    @RequestMapping("/unFrozenStock")
    public BaseResult unFrozenStock(@RequestBody OrderNoReq request){
//        stockOutMapBusinessService.stockOutFinished(request);

//        stockOutMapBusinessService.createOrUpdate(updateStockOutMapBusinessDto(request.getBusinessNo(),request.getBusinessOrderType(),request.getBillNo()));
        stockCheckOrderService.unFrozenStock(request);
        return BaseResult.OK();
    }


    @Deprecated
    @RequestMapping("/sSStockUpdateFixJob")
    @ResponseBody
    public BaseResult sSStockUpdateFixJob(@RequestBody  List<UpdateStockRequest>  requests ){
        for(UpdateStockRequest warehouseReq :requests){
            warehouseReq.setIdempotentNo(warehouseReq.getIdempotentNo()+"1");
            stockTempService.fixStockForSS(warehouseReq);
        }
       return BaseResult.OK();
    }

    @Resource
    private IReceiveOrderService receiveOrderService;
    @RequestMapping("/insertPutInStockOrder")
    @ResponseBody
    public BaseResult insertPutInStockOrder(@RequestBody  InAndOutStockRequest request ){
        receiveOrderService.insertPutInStockOrder(request);
       return BaseResult.OK();
    }


    @Resource
    private StockIn2ReceiveOrderJob stockIn2ReceiveOrderJob;
    @RequestMapping("/stockIn2ReceiveOrder")
    @ResponseBody
    public BaseResult  stockIn2ReceiveOrder(String param){
        stockIn2ReceiveOrderJob.asnAddPushHandler(param);
        return BaseResult.OK();
    }

    @RequestMapping("/dictItemList")
    @ResponseBody
    public BaseResult< List<String>>  dictItemList(){
        List<String> list =  commonService.dictItemList("VP", DictEnum.WorkStation.getDictCode());
        return BaseResult.OK(list);
    }

    @RequestMapping("fileUrl")
    @ResponseBody
    public String fielUrl(String key){
        return bosService.getFileUrlByKey2(key, 100000);
    }

}
