package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.Enum.GlobalCodeEnum;
import com.jiduauto.sps.server.Enum.SpsResponseCodeEnum;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.StoreWarehouseConfigDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.ValidGroup;
import com.jiduauto.sps.server.pojo.vo.req.StoreWarehouseConfigEditAndAddReq;
import com.jiduauto.sps.server.pojo.vo.req.StoreWarehouseConfigPageSearch;
import com.jiduauto.sps.server.service.IStoreWarehouseConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.groups.Default;
import java.util.List;

/**
 * 门店_仓库_配置 前端控制器
 *
 * @author generate
 * @since 2023-03-10
 */
@RestController
@RequestMapping("/storeWarehouseConfig")
@Slf4j
public class StoreWarehouseConfigController {

    @Autowired
    private IStoreWarehouseConfigService storeWarehouseConfigService;


    /**
     * 分页查询
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<StoreWarehouseConfigDto>> pageSearch(@RequestBody BasePageParam<StoreWarehouseConfigPageSearch> pageSearch) {
        return BaseResult.OK(storeWarehouseConfigService.pageSearch(pageSearch));
    }

    /**
     * 添加
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/add")
    @ResponseBody
    public BaseResult add(@RequestBody @Validated({ValidGroup.Add.class, Default.class}) StoreWarehouseConfigEditAndAddReq req) {
        try {
            return storeWarehouseConfigService.add(req);
        } catch (Exception e) {
            log.error("门店仓库配置添加异常", e);

            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9998);
        }
    }

    /**
     * 详情
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/selectById")
    @ResponseBody
    public BaseResult<StoreWarehouseConfigDto> selectById(@RequestParam("id") Long id) {
        return storeWarehouseConfigService.selectById(id);
    }

    /**
     * 修改
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/edit")
    @ResponseBody
    public BaseResult edit(@RequestBody @Validated({ValidGroup.Edit.class, Default.class}) StoreWarehouseConfigEditAndAddReq req) {

        try {
            return storeWarehouseConfigService.edit(req);
        } catch (Exception e) {
            log.error("门店仓库配置编辑异常", e);
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9998);
        }
    }

    /**
     * 删除
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/delete")
    @ResponseBody
    public BaseResult delete(@RequestParam("id") Long id) {
        try {
            return storeWarehouseConfigService.delete(id);
        } catch (Exception e) {
            log.error("门店仓库配置删除异常", e);
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9998);
        }
    }

    /**
     * 导入
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/importConfig")
    @ResponseBody
    public BaseResult<ImportResultResp> importConfig(@RequestHeader("bizType") String bizType,
                                                     @RequestPart("file")
                                                     MultipartFile file) {
        try {
            return BaseResult.OK(storeWarehouseConfigService.importConfig(bizType, file));
        } catch (Exception e) {
            log.error("门店仓库配置导入异常", e);
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9998);
        }
    }


}
