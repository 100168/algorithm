package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.StockInLocationRecommendationDetailDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.DetailBatchDelReq;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.LocationRecommendationDetailSaveEditReq;
import com.jiduauto.sps.server.service.IStockInLocationRecommendationDetailService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 库位规划详情 前端控制器
 */
@RestController
@RequestMapping("/stockInLocationRecommendation/detail")
public class StockInLocationRecommendationDetailController {

    @Resource
    private IStockInLocationRecommendationDetailService stockInLocationRecommendationDetailService;

    /**
     * 上架库位规划详情查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StockInLocationRecommendationDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<IdReq> pageParam) {
        return BaseResult.OK(stockInLocationRecommendationDetailService.pageSearch(pageParam));
    }

    /**
     * 新增详情
     */
    @PostMapping("/save")
    public BaseResult<Long> save(@RequestBody @Valid LocationRecommendationDetailSaveEditReq req) {
        return BaseResult.OK(stockInLocationRecommendationDetailService.save(req));
    }

    /**
     * 编辑详情
     */
    @PostMapping("/edit")
    public BaseResult<String> edit(@RequestBody @Valid LocationRecommendationDetailSaveEditReq req) {
        stockInLocationRecommendationDetailService.edit(req);
        return BaseResult.OK();
    }

    /**
     * 批量删除
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid DetailBatchDelReq req) {
        stockInLocationRecommendationDetailService.delete(req);
        return BaseResult.OK();
    }

    /**
     * 导入
     */
    @PostMapping("/import")
    public BaseResult<ImportResultResp> importDetail(@RequestHeader("bizType") String bizType,
                                                     @RequestParam("id") Long id,
                                                     @RequestPart("file") MultipartFile file) {
        return BaseResult.OK(stockInLocationRecommendationDetailService.importDetail(bizType, id, file));
    }
}
