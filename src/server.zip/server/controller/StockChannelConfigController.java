package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.dto.StockChannelConfigDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.StockChannelConfigSaveReq;
import com.jiduauto.sps.server.service.IStockChannelConfigService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 库存渠道配置表 前端控制器
 *
 * @author generate
 * @since 2024-09-26
 */
@RestController
@RequestMapping("/stockChannelConfig")
public class StockChannelConfigController {


    @Resource
    private IStockChannelConfigService stockChannelConfigService;

    /**
     * 库存渠道列表查询
     *
     * @return list
     */
    @PostMapping("/list")
    @ResponseBody
    public BaseResult<List<StockChannelConfigDto>> list() {
        return BaseResult.OK(stockChannelConfigService.selectList());
    }

    /**
     * 库存渠道保存
     */
    @PostMapping("/save")
    public BaseResult<String> save(@RequestBody @Valid StockChannelConfigSaveReq req) {
        stockChannelConfigService.save(req);
        return BaseResult.OK();
    }

    /**
     * 库存渠道删除
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid IdReq req) {
        stockChannelConfigService.delete(req);
        return BaseResult.OK();
    }
}
