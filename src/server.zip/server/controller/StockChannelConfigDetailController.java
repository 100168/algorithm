package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.dto.StockChannelConfigDetailDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.StockChannelConfigDetailReq;
import com.jiduauto.sps.server.pojo.vo.req.StockChannelConfigDetailSaveReq;
import com.jiduauto.sps.server.service.IStockChannelConfigDetailService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 库存渠道配置明细表 前端控制器
 * @author generate
 * @since 2024-09-26
 */
@RestController
@RequestMapping("stockChannelConfigDetail")
public class StockChannelConfigDetailController {


    @Resource
    private IStockChannelConfigDetailService stockChannelConfigDetailService;

    /**
     * 库存渠道明细查询
     *
     * @return list
     */
    @PostMapping("/list")
    @ResponseBody
    public BaseResult<List<StockChannelConfigDetailDto>> list(@RequestBody @Valid StockChannelConfigDetailReq req) {
        return BaseResult.OK(stockChannelConfigDetailService.selectList(req));
    }


    /**
     * 库存渠道明细保存
     */
    @PostMapping("/save")
    @ResponseBody
    public BaseResult<String> save(@RequestBody @Valid StockChannelConfigDetailSaveReq req) {
        stockChannelConfigDetailService.save(req);
        return BaseResult.OK();
    }

    /**
     * 库存渠道明细删除
     */
    @PostMapping("/delete")
    @ResponseBody
    public BaseResult<String> delete(@RequestBody @Valid IdReq req) {
        stockChannelConfigDetailService.delete(req);
        return BaseResult.OK();
    }

}
