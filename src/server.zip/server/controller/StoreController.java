package com.jiduauto.sps.server.controller;

import com.alibaba.fastjson.JSON;
import com.jiduauto.business.crm.auth.api.model.mq.OrganizationCreateMesPO;
import com.jiduauto.business.crm.auth.api.model.mq.OrganizationUpdateMesPO;
import com.jiduauto.business.crm.auth.api.model.rpc.response.OrganizationRpcItem;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.StoreReq;
import com.jiduauto.sps.server.pojo.vo.resp.StoreDto;
import com.jiduauto.sps.server.pojo.vo.resp.StoreResp;
import com.jiduauto.sps.server.service.IStoreService;
import com.jiduauto.sps.server.utils.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;

/**
 * 门店主数据控制器
 */
@RestController
@RequestMapping("/store")
public class StoreController {

    @Resource
    private IStoreService storeService;

    /**
     * 分页查询门店主数据
     * @param param
     * @return
     */
    @ResponseBody
    @PostMapping("/page")
    public BaseResult<BasePageData<StoreResp>> queryPage(@RequestBody @Valid BasePageParam<StoreReq> param){
        return BaseResult.OK(storeService.queryList(param));
    }
    /**
     * 获取门店主数据状态全量数据
     * @param
     * @return
     */
    @ResponseBody
    @PostMapping("/listStatus")
    public BaseResult<List<String>> listStatus(){
        return BaseResult.OK(storeService.listStatus());
    }


    @ResponseBody
    @PostMapping("/test")
    public BaseResult listStatus(String message){
        System.out.println(message);

        OrganizationCreateMesPO po = JSON.parseObject(message.toString(), OrganizationCreateMesPO.class);
        List<OrganizationRpcItem> list = po.getItemList();
        if(CollectionUtils.isNotEmpty(list)){
            storeService.syncFromCrm(list);
        }
        return BaseResult.OK();
    }


    @ResponseBody
    @PostMapping("/update")
    public BaseResult testUpdate(String message){

        OrganizationUpdateMesPO po = JSON.parseObject(message, OrganizationUpdateMesPO.class);
        List<OrganizationRpcItem> list = Arrays.asList(po.getNewOrgInfo());
        if(CollectionUtils.isNotEmpty(list)){
            storeService.syncFromCrm(list);
        }
        return BaseResult.OK();
    }

    /**
     * 针对ss业务下调拨单门店(组织)下拉框 该业务下获取sp下的门店数据
     */
    @ResponseBody
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StoreDto>> pageSearch(@RequestBody @Valid BasePageParam<StoreReq> param){
        return BaseResult.OK(storeService.pageSearch(param));
    }

}
