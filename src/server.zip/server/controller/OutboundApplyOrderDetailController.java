package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.OutboundApplyOrderDetailDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;
import com.jiduauto.sps.server.service.IOutboundApplyOrderDetailService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * <p>
 * 出库申请单明细 前端控制器
 * </p>
 *
 * @author generate
 * @since 2024-02-01
 */
@RestController
@RequestMapping("/outboundApplyOrder/detail")
public class OutboundApplyOrderDetailController {



    @Resource
    private IOutboundApplyOrderDetailService outboundApplyOrderDetailService;
    /**
     * 出库申请明细分页查询接口
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<OutboundApplyOrderDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<OrderNoReq> req) {
        return BaseResult.OK(outboundApplyOrderDetailService.pageSearch(req));
    }
}
