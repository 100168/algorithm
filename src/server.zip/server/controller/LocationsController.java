package com.jiduauto.sps.server.controller;


import cn.hutool.core.bean.BeanUtil;
import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.Enum.OperateTypeEnum;
import com.jiduauto.sps.server.annotation.InvokeLog;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.handler.WarehousePositionHandler;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.baseData.WarehousePositionDto;
import com.jiduauto.sps.server.pojo.dto.param.LocationOperateParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.fileexport.WarehousePositionExportDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.SpsBaseReq;
import com.jiduauto.sps.server.pojo.vo.ValidGroup;
import com.jiduauto.sps.server.pojo.vo.req.LocationOperateReq;
import com.jiduauto.sps.server.pojo.vo.req.baseData.*;
import com.jiduauto.sps.server.pojo.vo.resp.AreaDropDownResp;
import com.jiduauto.sps.server.pojo.vo.resp.WareHouseDropDownResp;
import com.jiduauto.sps.server.pojo.vo.resp.material.WarehousePositionImportResultResp;
import com.jiduauto.sps.server.service.IAreasService;
import com.jiduauto.sps.server.service.ILocationsService;
import com.jiduauto.sps.server.service.IWarehouseService;
import com.jiduauto.sps.server.utils.BeanCopierUtil;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.groups.Default;
import java.util.List;

/**
 * 库存库位信息 前端控制器
 *
 * @author generate
 * @since 2022-12-30
 */
@RestController
@RequestMapping("/location")
@AllArgsConstructor
public class LocationsController {

    private final ILocationsService locationsService;


    @Autowired
    private IWarehouseService warehouseService;

    @Autowired
    private IAreasService areasService;
    @Autowired
    private WarehousePositionHandler warehousePositionHandler;

    /**
     * 新增区域 主数据， 存在 就走更新逻辑
     *
     * @param
     * @return
     */
    @RequestMapping("/operate")
    @ResponseBody
    public BaseResult operate(@RequestBody @Validated LocationOperateReq locationOperateReq) {
        LocationOperateParam locationOperateParam = BeanUtil.copyProperties(locationOperateReq, LocationOperateParam.class);
        locationOperateParam.setOperateTypeEnum(OperateTypeEnum.getByCode(locationOperateReq.getOperateType()));
        locationOperateParam.setList(BeanCopierUtil.copyList(locationOperateReq.getList(), LocationOperateParam.class));
        return locationsService.operate(locationOperateParam);
    }

    /**
     * 库位信息条件查询
     *
     * @return
     * @Author O_chaopeng.huang
     * @Date 10:35 2023/2/20
     * @Param
     **/
    @PostMapping("/pageSearch")
    @ResponseBody

    public BaseResult<BasePageData<WarehousePositionDto>> pageSearch(@RequestBody @Valid BasePageParam<WareHousePositionPageSearchReq> pageParam) {
        return BaseResult.OK(locationsService.pageSearch(pageParam));
    }

    /**
     * 库位信息根据唯一id查询
     *
     * @return
     * @Author O_chaopeng.huang
     * @Date 11:17 2023/2/20
     * @Param
     **/
    @PostMapping("/selectById")
    @ResponseBody

    public BaseResult selectById(@RequestBody @Validated WareHousePageSearchReq wareHousePageSearchReq) {
        return locationsService.selectById(wareHousePageSearchReq);
    }


    /**
     * 仓库下拉列表获取
     * @return
     * @Author O_chaopeng.huang
     * @Date 11:38 2023/2/20
     * @Param
     **/
    @PostMapping("/dropList")
    @ResponseBody
    public BaseResult<List<WareHouseDropDownResp>> dropList(@RequestBody @Validated SpsBaseReq spsBaseReq) {
        return BaseResult.OK(warehouseService.dropList(spsBaseReq.getBizType()));

    }

    /**
     * 区域下拉列表获取
     * @Author O_chaopeng.huang
     * @Date 13:25 2023/2/20
     * @Param
     * @return
     **/
    @PostMapping("/dropAreaList")
    @ResponseBody
    public BaseResult<List<AreaDropDownResp>> dropAreaList(@RequestBody @Validated AreaDropDownReq areaDropDownReq) {
        return areasService.dropAreaList(areaDropDownReq);

    }

    /**
     * 库位信息添加
     * @Author O_chaopeng.huang
     * @Date 15:26 2023/2/20
     * @Param
     * @return
     **/
    @PostMapping("/singleAdd")
    @ResponseBody

    public BaseResult singleAdd(@RequestBody @Validated({ValidGroup.Add.class, Default.class}) WarehousePositionEditAndSingleAddReq warehousePositionEditAndSingleAddReq) {
        return locationsService.singleAdd(warehousePositionEditAndSingleAddReq);
    }

    /**
     * 库位信息修改
     * @Author O_chaopeng.huang
     * @Date 16:25 2023/2/20
     * @Param
     * @return
     **/
    @PostMapping("/edit")
    @ResponseBody
    @InvokeLog
    public BaseResult edit(@RequestBody @Validated({ValidGroup.Edit.class, Default.class}) WarehousePositionEditAndSingleAddReq warehousePositionEditAndSingleAddReq) {
        return locationsService.edit(warehousePositionEditAndSingleAddReq);
    }

    /**
     * 库位信息删除
     * @Author O_chaopeng.huang
     * @Date 11:00 2023/2/22
     * @Param
     * @return
     **/
    @PostMapping("/deleteOne")
    @ResponseBody
    @InvokeLog
    public BaseResult deleteOne(@RequestBody @Validated WarehousePositionDeleteReq warehouseDeleteReq) {
        return locationsService.deleteOne(warehouseDeleteReq);
    }


    /**
     * 库位信息导入
     * @Author O_chaopeng.huang
     * @Date 18:06 2023/2/20
     * @Param
     * @return
     **/
    @PostMapping("/import")

    public BaseResult<ImportResultResp> importWarehousePosition(@RequestHeader(value = "bizType") String bizType, @RequestPart("file") MultipartFile file) {
        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        ImportReturnDataInfo<WarehousePositionImportResultResp> resp = warehousePositionHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return BaseResult.OK(resultResp);
    }

    /**
     * 库位信息导出
     * @Author O_chaopeng.huang
     * @Date 9:09 2023/2/22
     * @Param
     * @return
     **/
    @PostMapping("/export")

    public void exportWarehousePosition(@RequestBody @Valid BasePageParam<WareHousePositionPageSearchReq> pageParam, HttpServletResponse response) {
        try {
            pageParam.setPage(BaseConstants.ImportExport.PAGE_START_AT); // 导出最大返回前1000条
            pageParam.setSize(BaseConstants.ImportExport.MAX_SIZE_10000);
            ExcelUtils.exportXlsxResponse(response, "库位信息");
            EasyExcel.write(response.getOutputStream(), WarehousePositionExportDto.class).sheet("库位信息").doWrite(locationsService.getExportDtoList(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }
}
