package com.jiduauto.sps.server.controller;

import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.SalePriceApprovalDetailDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.service.IDictService;
import com.jiduauto.sps.server.service.ISalePriceApprovalDetailService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 销售价格审批-价格明细 前端控制器
 */
@RestController
@RequestMapping("salePriceApproval/detail")
public class SalePriceApprovalDetailController {

    @Resource
    private IDictService dictService;

    @Resource
    private ISalePriceApprovalDetailService salePriceApprovalDetailService;

    /**
     * 新增
     * @param request
     * @return
     */
    @PostMapping("/add")
    public BaseResult add(@RequestBody @Valid SalePriceApprovalDetailAddReq request) {
        salePriceApprovalDetailService.add(request);
        return BaseResult.OK();
    }

    /**
     * 编辑
     * @param request
     * @return
     */
    @PostMapping("/edit")
    public BaseResult edit(@RequestBody @Valid SalePriceApprovalDetailEditReq request) {
        salePriceApprovalDetailService.edit(request);
        return BaseResult.OK();
    }

    /**
     * 删除
     * @param request
     * @return
     */
    @PostMapping("/delete")
    public BaseResult delete(@RequestBody @Valid ItemIdReq request) {
        salePriceApprovalDetailService.delete(request);
        return BaseResult.OK();
    }

    /**
     * 清空
     * @param approvalIdReq
     * @return
     */
    @PostMapping("/deleteAll")
    public BaseResult deleteAll(@RequestBody @Valid IdReq approvalIdReq) {
        salePriceApprovalDetailService.deleteAll(approvalIdReq);
        return BaseResult.OK();
    }

    /**
     * 条件查询
     * @param pageSearchReq
     * @return
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<SalePriceApprovalDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<SalePriceApprovalDetailPageSearchReq> pageSearchReq) {
        return BaseResult.OK(salePriceApprovalDetailService.pageSearch(pageSearchReq));
    }

    /**
     * 导入
     * @param bizType
     * @param approvalId
     * @param file
     * @return
     */
    @PostMapping("/import")
    @LoginCheck
    public BaseResult<ImportResultResp> importDetail(@RequestHeader("bizType") String bizType,
                                                     @RequestParam("approvalId") Long approvalId,
                                                     @RequestPart("file") MultipartFile file) {
        if (!dictService.isContained(bizType, DictEnum.BIZTYPE)) {
            throw new BizException("bizType错误");
        }
        return BaseResult.OK(salePriceApprovalDetailService.importDetail(bizType, approvalId, file));
    }
}
