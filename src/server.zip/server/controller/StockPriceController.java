package com.jiduauto.sps.server.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 库存价值计算结果 前端控制器
 * </p>
 *
 * @author generate
 * @since 2024-08-05
 */
@RestController
@RequestMapping("/server/stockPrice")
public class StockPriceController {

}
