package com.jiduauto.sps.server.controller;


import cn.hutool.core.lang.Pair;
import com.jiduauto.javakit.common.biz.Result;
import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.service.IDictService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 *
 *
 * @author generate
 * @since 2022-12-14
 */
@RestController
@AllArgsConstructor
public class BaseController {

    private final IDictService dictService;

    /**
     *获取bizType
     * @param
     * @return BaseResult<DictResp>
     */
    @GetMapping("/base/list")
    @LoginCheck
    public BaseResult<List<Pair<String,String>>> getBizTypeList(@RequestHeader String accessToken) {

        List<Pair<String, String>> resps = dictService.getUserBizType(accessToken);
        return BaseResult.OK(resps);
    }

    @RequestMapping("/misc/ping")
    @ResponseBody
    public Result<String> ping() {
        return Result.ofSuccess("success");
    }
}
