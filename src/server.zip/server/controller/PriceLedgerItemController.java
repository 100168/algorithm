package com.jiduauto.sps.server.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 价格台账明细 前端控制器
 * </p>
 *
 * @author generate
 * @since 2024-04-16
 */
@RestController
@RequestMapping("/server/priceLedgerItemPo")
public class PriceLedgerItemController {

}
