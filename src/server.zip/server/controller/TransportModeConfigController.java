package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.TransportModeConfigDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.ValidGroup;
import com.jiduauto.sps.server.pojo.vo.req.TransportModeConfigEditAndAddReq;
import com.jiduauto.sps.server.pojo.vo.req.TransportModeConfigPageSearch;
import com.jiduauto.sps.server.service.ITransportModeConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.groups.Default;
import java.util.List;

/**
 *
 * 运输_方式_配置 前端控制器
 *
 *
 * @author generate
 * @since 2023-03-10
 */
@RestController
@RequestMapping("/transportModeConfig")
public class TransportModeConfigController {

    @Autowired
    private ITransportModeConfigService transportModeConfigService;


    /**
     * 分页查询
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<TransportModeConfigDto>> pageSearch(@RequestBody BasePageParam<TransportModeConfigPageSearch> pageSearch) {
        return BaseResult.OK(transportModeConfigService.pageSearch(pageSearch));
    }

    /**
     * 添加
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/add")
    @ResponseBody
    public BaseResult add(@RequestBody @Validated({ValidGroup.Add.class, Default.class}) TransportModeConfigEditAndAddReq req) {
        return transportModeConfigService.add(req);
    }

    /**
     * 详情
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/selectById")
    @ResponseBody
    public BaseResult selectById(@RequestParam("id") Long id) {
        return transportModeConfigService.selectById(id);
    }

    /**
     * 修改
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/edit")
    @ResponseBody
    public BaseResult edit(@RequestBody @Validated({ValidGroup.Edit.class, Default.class}) TransportModeConfigEditAndAddReq req) {
        return transportModeConfigService.edit(req);
    }

    /**
     * 删除
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/delete")
    @ResponseBody
    public BaseResult delete(@RequestParam("id") Long id) {
        return transportModeConfigService.delete(id);
    }
   /**
     * 导入
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/importConfig")
    @ResponseBody
    public BaseResult<ImportResultResp> importConfig(@RequestHeader("bizType") String bizType,
                                                     @RequestPart("file")
                                                     MultipartFile file) {
        return BaseResult.OK(transportModeConfigService.importConfig(bizType,file));
    }



}
