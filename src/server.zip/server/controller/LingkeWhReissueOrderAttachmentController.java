package com.jiduauto.sps.server.controller;


import cn.hutool.http.HttpUtil;
import com.jiduauto.sps.sdk.pojo.dto.AttachmentDto;
import com.jiduauto.sps.sdk.pojo.dto.LingkeWhReissueOrderAttachmentDto;
import com.jiduauto.sps.sdk.pojo.po.LingkeWhReissueOrderAttachmentPo;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.service.ILingkeWhReissueOrderAttachmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * 领克仓补差异订单附件 前端控制器
 *
 * @author generate
 * @since 2023-12-11
 */
@Slf4j
@RestController
@RequestMapping("/lingkeWhReissueOrderAttachment")
public class LingkeWhReissueOrderAttachmentController {

    @Resource
    IBosService bosService;
    @Resource
    ILingkeWhReissueOrderAttachmentService lingkeWhReissueOrderAttachmentService;

    /**
     * 多个文件上传
     *
     * @param files
     * @return
     */
    @RequestMapping("/file")
    @ResponseBody
    public BaseResult<List<LingkeWhReissueOrderAttachmentDto>> saveFile(@RequestHeader("bizType") String bizType, @RequestPart("files") MultipartFile[] files) {
        List<LingkeWhReissueOrderAttachmentDto> attachmentDtos = new ArrayList<>();
        for (MultipartFile file : files) {
            try (InputStream inputStream = file.getInputStream()) {
                BosFileResult bosFileResult = bosService.uploadFile(inputStream, file.getOriginalFilename());
                if (bosFileResult == null) {
                    throw new BizException("请求log文件上传BOS失败！");
                }

                LingkeWhReissueOrderAttachmentPo po = new LingkeWhReissueOrderAttachmentPo();
                po.setFileUrl(bosFileResult.getFileUrl());
                po.setFileName(file.getOriginalFilename());
                po.setFileKey(bosFileResult.getObjectKey());
                po.setBizType(bizType);
                lingkeWhReissueOrderAttachmentService.save(po);

                LingkeWhReissueOrderAttachmentDto attachmentDto = new LingkeWhReissueOrderAttachmentDto();
                attachmentDto.setId(po.getId());
                attachmentDto.setFileName(file.getOriginalFilename());
                attachmentDto.setFileKey(bosFileResult.getObjectKey());
                attachmentDtos.add(attachmentDto);
            } catch (Exception e) {
                log.error("updateRequestUrl", e);
            }
        }

        return BaseResult.OK(attachmentDtos);
    }

    /**
     * 领克详情附件列表
     */
    @RequestMapping("listAttachment")
    @ResponseBody
    public BaseResult<List<AttachmentDto>> listAttachment(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(lingkeWhReissueOrderAttachmentService.attachmentList(req));
    }

    /**
     * 领克详情附件下载
     */
    @GetMapping("/download/{id}")
    public void downloadFile(@PathVariable Long id, HttpServletResponse response) throws IOException {
        LingkeWhReissueOrderAttachmentPo po = lingkeWhReissueOrderAttachmentService.getById(id);
        if (po == null) {
            throw new BizException("附件不存在");
        }
        response.setCharacterEncoding("utf-8");
        response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");
        response.setHeader("Content-disposition", "attachment;filename=" + URLEncoder.encode(po.getFileName(), "UTF-8").replaceAll("\\+", "%20"));
        HttpUtil.download(bosService.getFileUrlByKey(po.getFileKey(), 30 * 60), response.getOutputStream(), false);
    }


}
