package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderOperateLogDto;
import com.jiduauto.sps.server.pojo.dto.SaleOrderDetailDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;
import com.jiduauto.sps.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.server.service.IPurchaseReturnOrderOperateLogService;
import javax.annotation.Resource;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 采购退货订单操作记录 前端控制器
 * @author generate
 * @since 2023-05-04
 */
@RestController
@RequestMapping("/purchaseReturnOrder/operateLog")
public class PurchaseReturnOrderOperateLogController {


    @Resource
    private IPurchaseReturnOrderOperateLogService purchaseReturnOrderOperateLogService;
    /**
     * 采购退货订单操作日志分页查询
     * @param pageParam 分页参数
     * @return BaseResult
     */
    @PostMapping("pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<PurchaseReturnOrderOperateLogDto>> pageSearch(@RequestBody @Valid BasePageParam<OrderNoReq> pageParam) {
        return BaseResult.OK(purchaseReturnOrderOperateLogService.pageSearch(pageParam));
    }
}
