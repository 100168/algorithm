package com.jiduauto.sps.server.controller;

import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.excel.ExtendExportDto;
import com.jiduauto.sps.server.excel.OrderCalendarImportHandler;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.ValidGroup;
import com.jiduauto.sps.server.pojo.vo.req.OrderCalendarDelOrQueryReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderCalendarSaveReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderCalenderImportReq;
import com.jiduauto.sps.server.pojo.vo.req.baseData.ExportReq;
import com.jiduauto.sps.server.pojo.vo.resp.OrderAlendarResp;
import com.jiduauto.sps.server.pojo.vo.resp.OrderCalendarImportResp;
import com.jiduauto.sps.server.service.ICommonService;
import com.jiduauto.sps.server.service.IOrderCalendarService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.groups.Default;

/**
 * 訂單日曆前端控制器
 * @author dengxx
 * @since 2023/3/9
 */
@RestController
@AllArgsConstructor
@Slf4j
@RequestMapping("/orderAlendar")
public class OrderCalendarController {

    private final IOrderCalendarService service;

    private final ICommonService commonService;

    private final OrderCalendarImportHandler orderAlendarImportHandler;

    /**
     * 分頁查詢列表
     * @param param
     * @return
     */
    @PostMapping("/page")
    @ResponseBody
    public BaseResult<BasePageData<OrderAlendarResp>> pages(@RequestBody @Valid BasePageParam<OrderCalendarDelOrQueryReq> param){
        return BaseResult.OK(service.queryList(param));
    }

    /**
     * 保存訂單日曆
     * @param req
     * @return
     */
    @PostMapping("/save")
    @ResponseBody
    public BaseResult save(@RequestBody @Validated({ValidGroup.Add.class, Default.class}) OrderCalendarSaveReq req){
        return service.add(req);
    }

    /**
     * 修改訂單日曆
     * @param req
     * @return
     */
    @PostMapping("/update")
    @ResponseBody
    public BaseResult<Boolean> update(@RequestBody @Validated({ValidGroup.Edit.class, Default.class}) OrderCalendarSaveReq req){
        return BaseResult.OK(service.edit(req));
    }

    /**
     * 刪除訂單日曆
     */
    @RequestMapping("/delete")
    @ResponseBody
    public BaseResult<Boolean> delete(@RequestParam("id") Long id){
        return BaseResult.OK(service.deleteStoreOrder(id));
    }

    /**
     * 导入
     */
    @PostMapping("/import")
    @ResponseBody
    public BaseResult<ImportResultResp> importExcel(@RequestPart("file") MultipartFile file, @RequestHeader("bizType") String bizType){
        log.info("AsnBasicController-import-param:{}", bizType);
        commonService.checkExcelFile(file);

        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        importParam.setParam(bizType);
        //导入
        ImportReturnDataInfo<ExtendExportDto<OrderCalenderImportReq>> resp = orderAlendarImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return BaseResult.OK(resultResp);
    }

    /**
     * 导出
     */
    @PostMapping("/export")
    @ResponseBody
    public void outExcel(@RequestBody @Valid BasePageParam<ExportReq> pageParam, HttpServletResponse response){
        try {
            ExcelUtils.exportXlsxResponse(response, "订单日历信息");
            EasyExcel.write(response.getOutputStream(), OrderCalendarImportResp.class).sheet("订单日历信息").doWrite(service.excelOut(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }


}
