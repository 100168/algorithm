package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.excel.ExtendExportDto;
import com.jiduauto.sps.server.excel.PurchaseApplyOrderImportHandler;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderExportDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.service.IPurchaseApplyOrderService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 采购申请订单 前端控制器
 *
 * @author generate
 * @since 2023-06-08
 */
@Slf4j
@RestController
@RequestMapping("/purchaseApplyOrder")
public class PurchaseApplyOrderController {

    @Resource
    private IPurchaseApplyOrderService purchaseApplyOrderService;

    @Resource
    private PurchaseApplyOrderImportHandler purchaseApplyOrderImportHandler;


    /**
     * 列表分页查询
     *
     * @param pageParam 请求参数
     * @return page
     */

    @PostMapping("/pageSearch")
    @LoginCheck
    public BaseResult<BasePageData<PurchaseApplyOrderDto>> pageSearch(
            @RequestBody @Valid BasePageParam<PurchaseApplyOrderSearchReq> pageParam) {
        return BaseResult.OK(purchaseApplyOrderService.pageSearch(pageParam));
    }


    /**
     * 采购申请新建
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/createTempRecord")
    @LoginCheck
    public BaseResult<PurchaseApplyOrderDto> createTempRecord(@RequestBody @Valid PurchaseApplyOrderAddReq request) {
        return purchaseApplyOrderService.createTempRecord(request);
    }

    /**
     * 保存草稿
     *
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/enableTempRecord")
    @LoginCheck
    public BaseResult<Boolean> enableTempRecord(@RequestBody @Valid IdReq request) {
        return purchaseApplyOrderService.enableTempRecord(request);
    }

    /**
     * 编辑
     *
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/edit")
    @LoginCheck
    public BaseResult<PurchaseApplyOrderDto> edit(@RequestBody @Valid PurchaseApplyOrderEditReq request) {
        return purchaseApplyOrderService.edit(request);
    }

    /**
     * 列表删除
     *
     * @param request id
     * @return boolean
     */
    @PostMapping("/delete")
    @LoginCheck
    public BaseResult<Boolean> delete(@RequestBody @Valid IdReq request) {
        return purchaseApplyOrderService.deleteById(request);
    }


    /**
     * 提交
     *
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/commit")
    @LoginCheck
    public BaseResult<Boolean> commit(@RequestBody @Valid IdReq request) {
        return purchaseApplyOrderService.commit(request);
    }

    /**
     * 批量提交
     */
    @PostMapping("/commitBatch")
    public BaseResult<String> commitBatch(@RequestBody @Valid BatchIdReq idList) {
        return purchaseApplyOrderService.commitBatch(idList);
    }

    /**
     * 审核
     *
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/audit")
    @LoginCheck
    public BaseResult<Boolean> audit(@RequestBody @Valid PurchaseApplyOrderAuditReq request) {
        return purchaseApplyOrderService.audit(request);
    }

    /**
     * 已审核提交
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/auditEditCommit")
    @LoginCheck
    public BaseResult<Boolean> auditEditCommit(@RequestBody @Valid PurchaseApplyOrderDetailAuditEditReq request) {
        return purchaseApplyOrderService.auditEditCommit(request);
    }

    /**
     * 列表导出
     */
    @PostMapping("export")
    @LoginCheck
    public void export(@RequestBody @Valid BasePageParam<PurchaseApplyOrderSearchReq> pageParam, HttpServletResponse response) {
        try {
            // 导出最大返回前10000条
            ExcelUtils.exportXlsxResponse(response, "采购申请");
            EasyExcel.write(response.getOutputStream(), PurchaseApplyOrderExportDto.class).sheet("采购申请").doWrite(purchaseApplyOrderService.export(pageParam.getParam()));
        } catch (Exception e) {
            log.error("采购申请导出异常",e);
            throw new BizException(e.getMessage());
        }
    }

    /**
     * 列表导入
     *
     * @param bizType 业务类型
     * @param file    文件
     * @return res
     */
    @PostMapping("/import")
    @LoginCheck
    public BaseResult<ImportResultResp> importPurchaseOrder(
            @RequestHeader("bizType") String bizType,
            @RequestPart("file") MultipartFile file) {
        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        ImportReturnDataInfo<ExtendExportDto<PurchaseApplyOrderImportReq>> resp = purchaseApplyOrderImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return BaseResult.OK(resultResp);
    }
}
