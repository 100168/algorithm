package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PickingApplyDetailDto;
import com.jiduauto.sps.server.pojo.dto.PickingOrderDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.BatchIdReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;
import com.jiduauto.sps.server.pojo.vo.req.PickingOrderPageSearch;
import com.jiduauto.sps.server.pojo.vo.req.PickingOrderPartCancelReq;
import com.jiduauto.sps.server.service.IPickingOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * 拣货单 前端控制器
 *
 * @author generate
 * @since 2023-06-29
 */
@RestController
@RequestMapping("/pickingOrder")
public class PickingOrderController {
    @Autowired
    private IPickingOrderService pickingOrderService;

    /**
     * 拣货单分页
     *
     * @param req
     * @return BaseResult<BasePageData < PickingOrderDto>>
     * @author O_chaopeng.huang
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<PickingOrderDto>>
    pageSearch(@RequestBody @Valid BasePageParam<PickingOrderPageSearch> req) {
        return BaseResult.OK(pickingOrderService.pageSearch(req));
    }

    /**
     * 拣货单确认
     *
     * @param batchIdReq batchIdReq
     * @return boolean
     */
    @PostMapping("/confirm")
    @ResponseBody
    public BaseResult<Boolean>
    pageSearch(@RequestBody @Valid BatchIdReq batchIdReq) {
        return BaseResult.OK(pickingOrderService.confirm(batchIdReq));
    }

    /**
     * 拣货单撤销
     *
     * @param pickingOrderPartCancelReq idReq
     * @return boolean
     */
    @PostMapping("/cancel")
    @ResponseBody
    public BaseResult<String> cancel(@RequestBody @Valid PickingOrderPartCancelReq pickingOrderPartCancelReq) {
        pickingOrderService.cancel(pickingOrderPartCancelReq);
        return BaseResult.OK();
    }

    /**
     * 拣货单领料明细
     *
     * @param orderNoReq idReq
     * @return boolean
     */
    @PostMapping("/pickingApplyDetail")
    @ResponseBody
    public BaseResult<List<PickingApplyDetailDto>> cancel(@RequestBody @Valid OrderNoReq orderNoReq) {
        return BaseResult.OK(pickingOrderService.pickingApplyDetail(orderNoReq));
    }


}
