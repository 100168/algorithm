package com.jiduauto.sps.server.controller;

import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.annotation.InvokeLog;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.SalePriceDto;
import com.jiduauto.sps.server.pojo.fileexport.AreaExportDto;
import com.jiduauto.sps.server.pojo.fileexport.SalePriceExportDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.SalePricePageSearchReq;
import com.jiduauto.sps.server.service.ISalePriceService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * 销售价格-前端控制器
 */
@RestController
@RequestMapping("/salePrice")
public class SalePriceController {

    @Resource
    private ISalePriceService salePriceService;

    /**
     * 条件查询
     * @param pageParam
     * @return
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<SalePriceDto>> pageSearch(@RequestBody @Valid BasePageParam<SalePricePageSearchReq> pageParam) {
        return BaseResult.OK(salePriceService.pageSearch(pageParam));
    }
    /**
     * 价格导出
     * @param pageParam
     * @return
     */
    @PostMapping("/export")
    @InvokeLog
    public void export(@RequestBody @Valid BasePageParam<SalePricePageSearchReq> pageParam) {
        try {
            HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getResponse();
            ExcelUtils.exportXlsxResponse(response, "价格信息");
            EasyExcel.write(response.getOutputStream(), SalePriceExportDto.class).sheet("价格信息").doWrite(salePriceService.export(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }
}
