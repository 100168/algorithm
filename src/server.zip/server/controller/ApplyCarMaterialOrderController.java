package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.ApplyCarMaterialOrderDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.service.IApplyCarMaterialOrderService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 整车拉料订单表 前端控制器
 */
@RestController
@RequestMapping("/applyCarMaterialOrder")
public class ApplyCarMaterialOrderController {

    @Resource
    private IApplyCarMaterialOrderService applyCarMaterialOrderService;

    /**
     * 整车拉料列表查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<ApplyCarMaterialOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<ApplyCarMaterialOrderPageSearchReq> pageParam) {
        return BaseResult.OK(applyCarMaterialOrderService.pageSearch(pageParam));
    }

    /**
     * 删除拉料订单
     * no传入单号
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@Valid @RequestBody NoReq req) {
        applyCarMaterialOrderService.delete(req);
        return BaseResult.OK();
    }

    /**
     * 批量确认
     * 传入拉料单号
     */
    @PostMapping("/batchConfirm")
    public BaseResult<String> delete(@Valid @RequestBody IdBatchReq req) {
        applyCarMaterialOrderService.batchConfirm(req);
        return BaseResult.OK();
    }

    /**
     * 新建
     */
    @PostMapping("/create")
    public BaseResult<String> create(@Valid @RequestBody ApplyCarMaterialOrderCreateAndEditReq req) {
        applyCarMaterialOrderService.create(req);
        return BaseResult.OK();
    }

    /**
     * 编辑
     */
    @PostMapping("/edit")
    public BaseResult<String> edit(@Valid @RequestBody ApplyCarMaterialOrderCreateAndEditReq req) {
        applyCarMaterialOrderService.edit(req);
        return BaseResult.OK();
    }

    @GetMapping("/detail/{id}")
    public BaseResult<ApplyCarMaterialOrderDto> detail(@PathVariable Long id) {
        return BaseResult.OK(applyCarMaterialOrderService.detail(id));
    }
}
