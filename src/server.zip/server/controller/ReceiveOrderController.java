package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.ReceiveOrderDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.ReceiveOrderPageSearch;
import com.jiduauto.sps.server.pojo.vo.req.ReceiveOrderRackReq;
import com.jiduauto.sps.server.service.IReceiveOrderService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 收货单 前端控制器
 *
 * @author generate
 * @since 2023-08-22
 */
@RestController
@RequestMapping("/receiveOrder")
public class ReceiveOrderController {


    @Resource
    private IReceiveOrderService receiveOrderService;

    /**
     * 收货分页查询
     *
     * @param req req
     * @return BaseResult<BasePageData < PendingReceiveListDto>>
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<ReceiveOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<ReceiveOrderPageSearch> req) {
        return BaseResult.OK(receiveOrderService.pageSearch(req));
    }


    /**
     * 上架推荐
     *
     * @param req req
     * @return BaseResult<BasePageData < PendingReceiveListDto>>
     */
    @PostMapping("/rack")
    @ResponseBody
    public BaseResult<String> rack(@RequestBody @Valid ReceiveOrderRackReq req) {
        receiveOrderService.rack(req);
        return BaseResult.OK();
    }
}
