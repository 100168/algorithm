package com.jiduauto.sps.server.controller;


import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.po.ReceiveOrderPrintDetailPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.StockInOrderPrintDetailReq;
import com.jiduauto.sps.server.service.IReceiveOrderPrintDetailService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 入库单打印记录明细 前端控制器
 * </p>
 *
 * @author generate
 * @since 2024-02-20
 */
@RestController
@RequestMapping("/stockInOrder/detail/print")
public class ReceiveOrderPrintDetailController {

    @Resource
    private IReceiveOrderPrintDetailService receiveOrderPrintDetailService;

    /**
     * 打印明细的数量更新保存
     *
     * @param reqList 请求明细
     * @return ok
     */
    @PostMapping("/updateQty")
    public BaseResult<String> updateQty(@RequestBody List<StockInOrderPrintDetailReq> reqList,
                                        @RequestHeader("bizType") String bizType) {
        if (CollUtil.isEmpty(reqList)) {
            throw new BizException("明细不能为空");
        }
        String orderNo = reqList.get(0).getStockInOrderNo();
        receiveOrderPrintDetailService.remove(Wrappers.lambdaUpdate(ReceiveOrderPrintDetailPo.class)
                .eq(ReceiveOrderPrintDetailPo::getBizType, bizType)
                .eq(ReceiveOrderPrintDetailPo::getReceiveOrderNo, orderNo));
        List<ReceiveOrderPrintDetailPo> list = BeanUtil.copyToList(reqList, ReceiveOrderPrintDetailPo.class);
        for (ReceiveOrderPrintDetailPo detailPo : list) {
            detailPo.setBizType(bizType);
            detailPo.setReceiveOrderNo(orderNo);
        }
        receiveOrderPrintDetailService.saveBatch(list);
        return BaseResult.OK();
    }
}
