package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.sdk.pojo.dto.PriceLedgerItemDto;
import com.jiduauto.sps.sdk.pojo.fileExport.CarBomItemExportDto;
import com.jiduauto.sps.sdk.pojo.fileExport.PriceLedgerItemExportDto;
import com.jiduauto.sps.sdk.pojo.req.PriceLedgerSearchReq;
import com.jiduauto.sps.sdk.pojo.req.PriceLedgerSyncReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.server.Enum.GlobalCodeEnum;
import com.jiduauto.sps.server.Enum.SpsResponseCodeEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.service.IPriceLedgerService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 价格台账 前端控制器
 *
 * @author generate
 * @since 2024-04-16
 */
@Slf4j
@RestController
@RequestMapping("/priceLedger")
public class PriceLedgerController {

    @Resource
    private IPriceLedgerService priceLedgerService;

    @Autowired
    private RedissonClient redissonClient;

    /**
     *  从SRM 同步 价格台账信息
     * @return
     */
    @PostMapping("/syncFromSrm")
    @ResponseBody
    public BaseResult syncFromSrm(@RequestBody @Valid PriceLedgerSyncReq req){
        //单线程操作
        RLock rLock = redissonClient.getLock(BaseConstants.RedisKey.PRICE_LEDGER_LOCK_KEY);
        try{
            if(rLock.tryLock()){
                priceLedgerService.syncFromSrm(req);
            }else{
                return BaseResult.applicationError(SpsResponseCodeEnum.DUPLICATE_OPERATION);
            }
        }catch (Exception e){
            log.error("入库操作异常",e);
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9999);
        }finally {
            rLock.unlock();
        }
        return BaseResult.OK();
    }


    /**
     * 分页查询
     * @param pageParam
     * @return
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<PriceLedgerItemDto>> pageSearch(@RequestBody @Valid BasePageParam<PriceLedgerSearchReq> pageParam){

        return priceLedgerService.pageSearch(pageParam);
    }


    /**
     *  查询结果导出
     * @param req
     * @return
     */
    @PostMapping("/export")
    @ResponseBody
    public void export(HttpServletResponse response,@RequestBody @Valid  PriceLedgerSearchReq req){

        try {
            ExcelUtils.exportXlsxResponse(response, "价格台账导出");
            EasyExcel.write(response.getOutputStream(),  PriceLedgerItemExportDto.class)
                    .sheet("模板")
                    .doWrite(priceLedgerService.exportSearch(req));
        } catch (Exception e) {
            log.error("导出异常",e);
            throw new BizException(e.getMessage());
        }

    }
}
