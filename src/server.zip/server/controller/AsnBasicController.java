package com.jiduauto.sps.server.controller;


import cn.hutool.core.bean.BeanUtil;
import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.excel.AsnImportHandler;
import com.jiduauto.sps.server.excel.ExtendExportDto;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.param.AsnBasicListParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.fileexport.AsnBasicExportDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.AsnBasicListReq;
import com.jiduauto.sps.server.pojo.vo.req.AsnDeleteReq;
import com.jiduauto.sps.server.pojo.vo.req.AsnPushReq;
import com.jiduauto.sps.server.pojo.vo.req.baseData.AsnSyncReq;
import com.jiduauto.sps.server.pojo.vo.resp.AsnBasicListResp;
import com.jiduauto.sps.server.pojo.vo.resp.AsnImportResp;
import com.jiduauto.sps.server.service.IAsnBasicService;
import com.jiduauto.sps.server.service.IAsnOperateService;
import com.jiduauto.sps.server.service.IAsnPushService;
import com.jiduauto.sps.server.service.ICommonService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 预发货单基础信息 前端控制器
 *
 * @author generate
 * @since 2022-12-14
 */
@RestController
@RequestMapping("/asn/basic")
@Slf4j
@AllArgsConstructor
public class AsnBasicController {

    private final IAsnBasicService asnBasicService;

    private final ICommonService commonService;

    private final AsnImportHandler asnImportHandler;

    private final IAsnPushService asnPushService;

    private final IAsnOperateService asnOperateService;

    @PostMapping("/list")
    @LoginCheck
    public BaseResult<BasePageData<AsnBasicListResp>> page(@RequestBody @Validated BasePageParam<AsnBasicListReq> param) {
        log.info("AsnBasicController-page-param:{}", param);
        AsnBasicListParam req = BeanUtil.copyProperties(param.getParam(), AsnBasicListParam.class);
        BasePageData basePageData = asnBasicService.listByPage(req, param.getPage(), param.getSize());
        return BaseResult.OK(basePageData);
    }

    /**
     * 删除
     *
     * @param req
     * @return BaseResult<>
     */
    @PostMapping("/delete")
    @LoginCheck
    @Deprecated
    public BaseResult delete(@RequestBody @Valid AsnDeleteReq req) {
        log.info("AsnBasicController-delete-param:{}", req);
        asnOperateService.webDelete(req.getId(), req.getBizType());
        return BaseResult.OK();
    }

    @PostMapping("/import")
    @LoginCheck
    public BaseResult<ImportResultResp> importAsn(@RequestPart("file") MultipartFile file, @RequestHeader("bizType") String bizType) {
        log.info("AsnBasicController-import-param:{}", bizType);
        commonService.checkExcelFile(file);

        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        importParam.setParam(bizType);
        //导入
        ImportReturnDataInfo<ExtendExportDto<AsnImportResp>> resp = asnImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return BaseResult.OK(resultResp);
    }


    /**
     * @ignore
     */
    @PostMapping("/export/template")
    @Deprecated
    public void exportTemplate(HttpServletResponse response){
    }

    /**
     * @ignore
     */
    @PostMapping("/push")
    @Deprecated
    public BaseResult asnPush(@RequestBody @Validated AsnPushReq asnPushReq) {
      return BaseResult.OK();
    }


    /**
     * 同步接口 待发货 发货失败  删除待同步，删除同步失败可以重试
     * @param req
     * @return BaseResult<>
     */
    @PostMapping("/manual/sync")
    @LoginCheck
    @Deprecated
    public BaseResult sync(@RequestBody @Valid AsnSyncReq req) {
        log.info("AsnBasicController-sync-param:{}", req);
        asnPushService.manualPushAsn(req.getAsnCode(), req.getBizType());
        return BaseResult.OK();
    }

    /**
     * 导出
     **/
    @PostMapping("/export")
    public void export(HttpServletResponse response, @RequestBody @Valid BasePageParam<AsnBasicListReq> pageParam){
        try {
            //最大一万条
            ExcelUtils.exportXlsxResponse(response, "ASN查询结果");
            EasyExcel.write(response.getOutputStream(), AsnBasicExportDto.class)
                    .sheet("ASN查询结果").doWrite(asnBasicService.exportSearch(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }


}
