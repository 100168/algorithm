package com.jiduauto.sps.server.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 零件库存的生命周期 前端控制器
 * </p>
 *
 * @author generate
 * @since 2024-09-05
 */
@RestController
@RequestMapping("/server/materialStockLifeCyclePo")
public class MaterialStockLifeCycleController {

}
