package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.excel.ExcelThreadLocalHolder;
import com.jiduauto.sps.server.excel.ExtendExportDto;
import com.jiduauto.sps.server.excel.PurchaseApplyOrderDetailImportHandler;
import com.jiduauto.sps.server.excel.check.PurchaseApplyOrderDetailBatchPreCheck;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderDetailDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.service.IPurchaseApplyOrderDetailService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 采购申请订单明细 前端控制器
 *
 * @author generate
 * @since 2023-06-08
 */
@RestController
@RequestMapping("/purchaseApplyOrder/detail")
public class PurchaseApplyOrderDetailController {

    @Resource
    private IPurchaseApplyOrderDetailService purchaseApplyOrderDetailService;

    @Resource
    private PurchaseApplyOrderDetailImportHandler purchaseApplyOrderDetailImportHandler;

    /**
     * 列表分页查询
     *
     * @param pageSearchReq 请求参数
     * @return page
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<PurchaseApplyOrderDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<PRDetailSearchReq> pageSearchReq) {
        return BaseResult.OK(purchaseApplyOrderDetailService.pageSearch(pageSearchReq));
    }

    /**
     * 查询所有明细
     *
     * @param idReq 请求参数
     * @return page
     */
    @PostMapping("/list")
    public BaseResult<List<PurchaseApplyOrderDetailDto>> list(@RequestBody @Valid OrderIdReq idReq) {
        return BaseResult.OK(purchaseApplyOrderDetailService.list(idReq));
    }
    /**
     * 明细删除
     *
     * @param request 明细id
     * @return bool
     */
    @PostMapping("/delete")
    public BaseResult<Boolean> delete(@RequestBody @Valid IdReq request) {
        return BaseResult.OK(purchaseApplyOrderDetailService.deleteById(request.getId()));
    }

    /**
     * 明细增加
     *
     * @param addReq 添加参数
     * @return bool
     */
    @PostMapping("/add")
    public BaseResult<Boolean> add(@RequestBody @Valid PurchaseApplyOrderDetailAddReq addReq) {
        return BaseResult.OK(purchaseApplyOrderDetailService.add(addReq));
    }

    /**
     * 明细编辑
     *
     * @param editReq 编辑参数
     * @return bool
     */
    @PostMapping("/edit")
    public BaseResult<Boolean> edit(@RequestBody @Valid PurchaseApplyOrderDetailEditReq editReq) {
        return BaseResult.OK(purchaseApplyOrderDetailService.edit(editReq));
    }

    /**
     * 明细导入
     *
     * @param bizType 业务类型
     * @param file    文件
     * @return res
     */
    @PostMapping("/import")
    @LoginCheck
    public BaseResult<ImportResultResp> importDetail(
            @RequestHeader("bizType") String bizType,
            @RequestParam("orderId") Long orderId,
            @RequestPart("file") MultipartFile file) {
        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        ExcelThreadLocalHolder.put(PurchaseApplyOrderDetailBatchPreCheck.KEY_PURCHASE_APPLY_ORDER_ID, orderId);
        ImportReturnDataInfo<ExtendExportDto<PurchaseApplyOrderDetailImportReq>> resp = purchaseApplyOrderDetailImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return BaseResult.OK(resultResp);
    }

    /**
     * 领克取消
     *
     * @param req id
     * @return bool
     */
    @PostMapping("/cancel")
    public BaseResult<Boolean> cancel(@RequestBody @Valid IdReq req) {
        return BaseResult.OK(purchaseApplyOrderDetailService.cancel(req));
    }

}
