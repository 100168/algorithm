package com.jiduauto.sps.server.controller;

import com.jiduauto.sps.sdk.pojo.dto.LingkeWhReissueOrderItemDto;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.service.ILingkeWhReissueOrderDetailService;
import javax.annotation.Resource;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * 领克仓补差异订单明细 前端控制器
 * @ClassName LingkeWhReissueOrderDetailController
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/12/26 14:23
 */
@RestController
@RequestMapping("/lingkeWhReissueOrderDetail")
public class LingkeWhReissueOrderDetailController {
    @Resource
    private ILingkeWhReissueOrderDetailService lingkeWhReissueOrderDetailService;
    /**
     * 领克仓补单 零件信息分页
     *
     * @author O_chaopeng.huang
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<LingkeWhReissueOrderItemDto>> pageSearch(@RequestBody @Valid BasePageParam<OrderNoReq> req) {
        return BaseResult.OK(lingkeWhReissueOrderDetailService.pageSearch(req));
    }
}
