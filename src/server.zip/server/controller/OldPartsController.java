package com.jiduauto.sps.server.controller;

import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.ClaimDto;
import com.jiduauto.sps.server.pojo.dto.OldPartsDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.ClaimPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.IdQuery;
import com.jiduauto.sps.server.pojo.vo.req.OldPartsOrderReq;
import com.jiduauto.sps.server.pojo.vo.req.OldPartsPageReq;
import com.jiduauto.sps.server.service.IFreightClaimService;
import com.jiduauto.sps.server.service.IOldPartsService;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 旧件处理 前端控制器
 */
@RestController
@RequestMapping("/oldParts")
public class OldPartsController {

    @Resource
    private IOldPartsService oldPartsService;

    @Resource
    private IFreightClaimService freightClaimService;

    /**
     * 创建旧件处理单
     */
    @PostMapping("/createOrder")
    public BaseResult<String> createOrder(@RequestBody @Valid OldPartsOrderReq req) {
        return oldPartsService.createOrder(req);
    }

    /**
     * 旧件处理单分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<OldPartsDto>> pageSearch(@RequestBody @Validated BasePageParam<OldPartsPageReq> req){
        return BaseResult.OK(oldPartsService.pageSearch(req));
    }

    /**
     * 旧件处理选择索赔单分页查询
     */
    @PostMapping("/claim/pageSearch")
    public BaseResult<BasePageData<ClaimDto>> oldPartsClaimPageSearch(@RequestBody @Valid BasePageParam<ClaimPageSearchReq> pageParam){
        return BaseResult.OK(freightClaimService.oldPartsClaimPageSearch(pageParam));
    }

    /**
     * 旧件处理单详情分页查询
     *
     * @param req id传入旧件单单号
     */
    @PostMapping("/detail/pageSearch")
    public BaseResult<BasePageData<ClaimDto>> detailPageSearch(@RequestBody @Validated BasePageParam<IdQuery> req){
        return BaseResult.OK(oldPartsService.detailPageSearch(req));
    }


}
