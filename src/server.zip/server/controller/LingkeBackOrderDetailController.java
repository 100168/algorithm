package com.jiduauto.sps.server.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * 领克缺件订单明细 前端控制器
 */
@RestController
@RequestMapping("/server/lingkeBackOrderDetailPo")
public class LingkeBackOrderDetailController {

}
