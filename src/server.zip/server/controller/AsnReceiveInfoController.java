package com.jiduauto.sps.server.controller;

import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.AsnReceiveReq;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * 外部系统收货信息
 * @author generate
 * @since 2022-12-14
 */
@RestController
@RequestMapping("/asn/receive")
@AllArgsConstructor
@Slf4j
public class AsnReceiveInfoController {

    /**
     * 收货接口
     *
     * @param req
     * @return BaseResult<>
     */
    @Deprecated
    @PostMapping()
    public BaseResult receiveDeatail(@RequestBody @Valid AsnReceiveReq req) {
        log.info("AsnReceiveInfoController-receive-param:{}", req);
        return BaseResult.OK();
    }
}
