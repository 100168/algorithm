package com.jiduauto.sps.server.controller;

import com.alibaba.excel.EasyExcel;
import com.jiduauto.javakit.common.biz.Result;
import com.jiduauto.spare.parts.api.model.rpc.claim.ClaimOrderResourceVO;
import com.jiduauto.spare.parts.api.model.rpc.claim.ClaimOrderVO;
import com.jiduauto.spare.parts.api.model.rpc.request.claim.ClaimOrderDetailRequest;
import com.jiduauto.spare.parts.api.service.ClaimRpcService;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.ClaimDto;
import com.jiduauto.sps.server.pojo.fileexport.ClaimExportResp;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.ChangeClaimStateReq;
import com.jiduauto.sps.server.pojo.vo.req.ClaimNoReq;
import com.jiduauto.sps.server.pojo.vo.req.ClaimPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.ClaimResponsiblePartyUpdateReq;
import com.jiduauto.sps.server.service.IFreightClaimService;
import com.jiduauto.sps.server.threads.DownloadBatchThread;
import com.jiduauto.sps.server.utils.ExcelUtils;
import com.jiduauto.sps.server.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 物流索赔 前端控制器
 */
@Slf4j
@RestController
@RequestMapping("/freightClaim")
public class FreightClaimController {

    @Resource
    private IFreightClaimService freightClaimService;

    @Resource
    private ClaimRpcService claimRpcService;

    private static ExecutorService executorService = Executors.newFixedThreadPool(8);


    /**
     *  物流索赔列表查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<ClaimDto>> pageSearch(@RequestBody @Valid BasePageParam<ClaimPageSearchReq> pageParam){
        return BaseResult.OK(freightClaimService.pageSearch(pageParam));
    }

    /**
     * 索赔单详情
     */
    @PostMapping("/detail")
    public BaseResult<ClaimDto> detail(@RequestBody @Valid ClaimNoReq claimNoReq){
        return freightClaimService.detail(claimNoReq);
    }

    /**
     * 索赔单审核
     */
    @PostMapping("changeClaimState")
    public BaseResult<String> changeClaimState(@RequestBody @Valid ChangeClaimStateReq req){
        return freightClaimService.changeClaimState(req);
    }

    /**
     *  责任认定 更新责任方
     */
    @PostMapping("changeResponsibleParty")
    public BaseResult<String> changeResponsibleParty(@RequestBody @Valid ClaimResponsiblePartyUpdateReq req){
        return freightClaimService.changeResponsibleParty(req);
    }
    /**
     *  二次责任认定 更新责任方
     */
    @PostMapping("secondChangeResponsibleParty")
    public BaseResult<String> secondChangeResponsibleParty(@RequestBody @Valid ClaimResponsiblePartyUpdateReq req){
        return freightClaimService.secondChangeResponsibleParty(req);
    }
    /**
     *  物流索赔导出
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response,@RequestBody @Valid BasePageParam<ClaimPageSearchReq>  param){
        try {
            ExcelUtils.exportXlsxResponse(response, "物流索赔导出");
            EasyExcel.write(response.getOutputStream(),  ClaimExportResp.class)
                    .sheet("模板")
                    .doWrite(freightClaimService.export(param));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }

    }


    /**
     * 一次性下载所有文件压缩包
     */@GetMapping("/downloadAllZip/{claimNo}")
    public void downloadAllZip(@PathVariable(name = "claimNo") String claimNo, HttpServletResponse response) throws IOException {
        ZipOutputStream zipOut = null;

        try {
            if(StringUtils.isBlank(claimNo)){
                return;
            }
            ClaimOrderDetailRequest req = new ClaimOrderDetailRequest();
            req.setClaimOrderNo(claimNo);
            Result<ClaimOrderVO> detail = claimRpcService.getClaimOrderDetail(req);
            if(detail.getCode() != 0 || detail.getData() == null){
                return;
            }
            response.setContentType("application/zip");
            response.setHeader("Content-Disposition", "attachment; filename=downloadedFiles.zip");
            zipOut = new ZipOutputStream(response.getOutputStream());
            Map<String, Future<byte[]>> futures = new HashMap<>();
            Map<String, String>  map = new HashMap<>();
            for (ClaimOrderResourceVO resourceVO : detail.getData().getResourceList()) {
                String key = map.get(resourceVO.getResourceUrl());
                if(key == null){
                    map.put(resourceVO.getResourceUrl(),resourceVO.getResourceUrl());
                }else{
                    //去重
                    continue;
                }

                Future<byte[]> future = executorService.submit(new DownloadBatchThread(resourceVO.getResourceUrl()));
                futures.put(resourceVO.getResourceUrl(),future);


            }

            for(Map.Entry<String, Future<byte[]>> entry:futures.entrySet()){
                byte[]bytes = entry.getValue().get();

                ByteArrayInputStream zipStream = new ByteArrayInputStream(bytes);
                ZipEntry zipEntry = new ZipEntry(StringUtils.getLastBySplit(entry.getKey(),"/"));
                zipOut.putNextEntry(zipEntry);

                byte[] temp = new byte[1024];
                int length;
                while ((length = zipStream.read(temp)) >= 0) {
                    zipOut.write(temp, 0, length);
                }
                zipStream.close();
            }
            zipOut.close();
        } catch (IOException | ExecutionException |InterruptedException e) {
            log.error("物流索赔文件下载失败",e);
        } finally {
            if(zipOut != null){
                zipOut.close();
            }
        }
    }
}
