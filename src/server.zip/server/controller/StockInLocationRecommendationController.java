package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.server.excel.CustomSheetWriteHandler;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.ExcelDescription;
import com.jiduauto.sps.server.pojo.dto.StockInLocationRecommendationDetailImportDto;
import com.jiduauto.sps.server.pojo.dto.StockInLocationRecommendationDto;
import com.jiduauto.sps.server.pojo.po.StockInLocationRecommendationPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.LocationRecommendationEditReq;
import com.jiduauto.sps.server.pojo.vo.req.LocationRecommendationNextStepReq;
import com.jiduauto.sps.server.pojo.vo.req.LocationRecommendationPageSearchReq;
import com.jiduauto.sps.server.service.ICommonService;
import com.jiduauto.sps.server.service.IStockInLocationRecommendationService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 上架库位规划 前端控制器
 */
@Slf4j
@RestController
@RequestMapping("/stockInLocationRecommendation")
public class StockInLocationRecommendationController {

    @Resource
    private IStockInLocationRecommendationService stockInLocationRecommendationService;

    @Resource
    private ICommonService commonService;

    /**
     * 上架库位规划查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StockInLocationRecommendationDto>> pageSearch(@RequestBody @Valid BasePageParam<LocationRecommendationPageSearchReq> pageParam) {
        return BaseResult.OK(stockInLocationRecommendationService.pageSearch(pageParam));
    }

    /**
     * 库位规划主数据查询
     */
    @PostMapping("/headInfo")
    public BaseResult<StockInLocationRecommendationDto> headInfo(@RequestBody @Valid IdReq req) {
        return BaseResult.OK(stockInLocationRecommendationService.headInfo(req));
    }

    /**
     * 删除
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid IdReq req) {
        stockInLocationRecommendationService.delete(req);
        return BaseResult.OK();
    }

    /**
     * 新建 - 下一步
     * 返回 id
     */
    @PostMapping("/nextStep")
    public BaseResult<Long> nextStep(@RequestBody @Valid LocationRecommendationNextStepReq req) {
        return BaseResult.OK(stockInLocationRecommendationService.nextStep(req));
    }

    /**
     * 保存
     */
    @PostMapping("/save")
    public BaseResult<String> save(@RequestBody @Valid IdReq req) {
        stockInLocationRecommendationService.save(req);
        return BaseResult.OK();
    }

    /**
     * 编辑
     */
    @PostMapping("/edit")
    public BaseResult<String> edit(@RequestBody @Valid LocationRecommendationEditReq req) {
        stockInLocationRecommendationService.edit(req);
        return BaseResult.OK();
    }


    public final static List<ExcelDescription> EXCEL_DESCRIPTIONS = Arrays.asList(
            new ExcelDescription("零件编码", "请填写系统内维护的零件编码"),
            new ExcelDescription("零件状态", "填写以下值：良好；质损；待处理；待维修；待质检"),
            new ExcelDescription("样件状态", "请填写系统内维护的样件状态"),
            new ExcelDescription("零件种类", "普通件；特殊件；标准件"),
            new ExcelDescription("车辆号", "请填写系统内车辆号维护的车辆号"),
            new ExcelDescription("批次", "限制30位字符以内"),
            new ExcelDescription("序列号", "限制50位字符以内"),
            new ExcelDescription("零件条码", "限制50位字符以内"),
            new ExcelDescription("入库日期", "填写格式2023/01/01"),
            new ExcelDescription("生产日期", "填写格式2023/01/01"),
            new ExcelDescription("失效日期", "填写格式2023/01/01"),
            new ExcelDescription("库存状态", "正常；冻结"),
            new ExcelDescription("供应商代码", "请填写系统内供应商维护的供应商代码"),
            new ExcelDescription("项目", "请填写数据字典内项目维护的明细编码"),
            new ExcelDescription("阶段", "请填写数据字典内阶段维护的明细编码"),
            new ExcelDescription("WBS编号", "限制50位字符以内"),
            new ExcelDescription("业务单号", "限制30位字符以内"),
            new ExcelDescription("业务单行号", "限制30位字符以内"),
            new ExcelDescription("托盘号", "请填写系统内维护的托盘号"),
            new ExcelDescription("料箱号", "请填写系统内区域维护的料箱号"),
            new ExcelDescription("仓库代码", "请填写仓库的编码"),
            new ExcelDescription("区域代码", "请填写系统内区域维护的编码"),
            new ExcelDescription("库位代码", "请填写系统内区域维护的编码")
    );

    /**
     * 模板下载
     */
    @PostMapping("/template/download")
    public void downloadFile(@RequestBody @Valid IdReq req, HttpServletResponse response) {
        try {
            ExcelUtils.exportXlsxResponse(response, "库位规划导入模板");
            StockInLocationRecommendationPo po = stockInLocationRecommendationService.getById(req.getId());
            String tempStr = po.getWarehouseField() + "," + po.getStockField();
            List<StockInLocationRecommendationDetailImportDto> objects = new ArrayList<>();
            ExcelWriter excelWriter = EasyExcel.write(response.getOutputStream()).build();
            WriteSheet writeSheet = EasyExcel.writerSheet(1, "库位规划导入模板")
                    .head(StockInLocationRecommendationDetailImportDto.class)
                    .includeColumnFiledNames(Arrays.stream(tempStr.split(",")).collect(Collectors.toList()))
                    .registerWriteHandler(new CustomSheetWriteHandler(commonService))
                    .build();
            WriteSheet writeSheet2 = EasyExcel.writerSheet(2, "填写说明")
                    .head(ExcelDescription.class)
                    .build();
            excelWriter.write(objects, writeSheet);
            excelWriter.write(EXCEL_DESCRIPTIONS, writeSheet2);
            excelWriter.finish();
        } catch (Exception e) {
            log.error("导出异常", e);
            throw new BizException(e.getMessage());
        }
    }

}
