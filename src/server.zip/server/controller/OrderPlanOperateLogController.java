package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.OrderPlanOperateLogDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.service.IOrderPlanOperateLogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 要货计划操作记录 前端控制器
 */
@Slf4j
@RestController
@RequestMapping("/orderPlanOperateLog")
public class OrderPlanOperateLogController {

    @Resource
    private IOrderPlanOperateLogService operateLogService;

    /**
     * 分页查询
     * @param pageParam
     * @return
     */
    @PostMapping("/pageSearch")
    @LoginCheck
    public BaseResult<BasePageData<OrderPlanOperateLogDto>> pageSearch(@RequestBody @Valid BasePageParam<IdReq> pageParam) {
        return BaseResult.OK(operateLogService.pageSearch(pageParam));
    }
}
