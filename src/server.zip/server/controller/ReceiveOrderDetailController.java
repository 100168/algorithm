package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.sdk.pojo.fileExport.PriceLedgerItemExportDto;
import com.jiduauto.sps.sdk.pojo.fileExport.ReceiveOrderDetailExportDto;
import com.jiduauto.sps.sdk.pojo.req.PriceLedgerSearchReq;
import com.jiduauto.sps.sdk.pojo.req.ReceiveOrderDetailPageSearch;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.ReceiveOrderDetailDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;
import com.jiduauto.sps.server.service.IReceiveOrderDetailService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * 收货单明细
 *
 * @author generate
 * @since 2023-08-22
 */
@Slf4j
@RestController
@RequestMapping("/receiveOrder/detail")
public class ReceiveOrderDetailController {


    @Resource
    private IReceiveOrderDetailService receiveOrderDetailService;

    /**
     *
     * 收货单详情-收货明细分页查询
     *
     * @param req req
     * @return page
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<ReceiveOrderDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<OrderNoReq> req) {
        return BaseResult.OK(receiveOrderDetailService.pageSearch(req));
    }


    /**
     * 收货明细页面 分页查询
     * @param req
     * @return
     */
    @PostMapping("/pageSearchList")
    @ResponseBody
    public BaseResult<BasePageData<ReceiveOrderDetailDto>> pageSearchList(@RequestBody @Valid BasePageParam<ReceiveOrderDetailPageSearch> req) {
        return BaseResult.OK(receiveOrderDetailService.pageSearchList(req));
    }


    /**
     *  查询结果导出
     * @param req
     * @return
     */
    @PostMapping("/export")
    @ResponseBody
    public void export(HttpServletResponse response, @RequestBody @Valid ReceiveOrderDetailPageSearch req){

        try {
            ExcelUtils.exportXlsxResponse(response, "收货结果清单");
            EasyExcel.write(response.getOutputStream(),  ReceiveOrderDetailExportDto.class)
                    .sheet("收货结果清单")
                    .doWrite((receiveOrderDetailService.exportSearchList(req)));
        } catch (Exception e) {
            log.error("导出异常",e);
            throw new BizException(e.getMessage());
        }

    }



    /**
     * 查询收货单的所有明细
     * @param req
     * @return
     */
     @PostMapping("/listAll")
    @ResponseBody
    public BaseResult<List<ReceiveOrderDetailDto>> listAll(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(receiveOrderDetailService.listAll(req));
    }


}
