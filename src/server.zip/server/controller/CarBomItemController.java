package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.sdk.pojo.dto.CarBomItemDto;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.CarBomItemPageReq;
import com.jiduauto.sps.server.service.ICarBomItemService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.math.BigDecimal;

/**
 * 车辆BOM零件信息明细 前端控制器
 */
@RestController
@RequestMapping("/carBomItem")
public class CarBomItemController {

    @Resource
    private ICarBomItemService carBomItemService;


    /**
     * 用于 整车领料查询 bom 零件分页接口
     */
    @PostMapping("/pageSearchEffective")
    public BaseResult<BasePageData<CarBomItemDto>> pageSearch(@RequestBody @Valid BasePageParam<CarBomItemPageReq> pageParam) {
        return BaseResult.OK(carBomItemService.queryEffectiveCarBomItemPageSearch(pageParam));
    }

    /**
     * 用于 整车领料查询 对应条件bom下 总零件数量
     */
    @PostMapping("/queryTotalMaterialCount")
    public BaseResult<BigDecimal> queryTotalMaterialCount(@RequestBody @Valid CarBomItemPageReq req) {
        return BaseResult.OK(carBomItemService.queryTotalMaterialCount(req));
    }
}
