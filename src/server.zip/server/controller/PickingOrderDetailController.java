package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.dto.PickingOrderDetailSaveReq;
import com.jiduauto.sps.server.pojo.dto.PickingOrderDetailUpdateReq;
import com.jiduauto.sps.server.pojo.dto.PickingOrderDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;
import com.jiduauto.sps.server.pojo.vo.req.stock.PickingOrderDetailReq;
import com.jiduauto.sps.server.service.IPickingOrderDetailService;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 拣货单详情 前端控制器
 *
 * @author generate
 * @since 2023-06-29
 */
@RestController
@RequestMapping("/pickingOrderDetail")
public class PickingOrderDetailController {

    @Autowired
    private IPickingOrderDetailService pickingOrderDetailService;
    /**
     * 拣货单详情列表
     * @author O_chaopeng.huang
     * @param  req
     * @return BaseResult<BasePageData<PickingOrderDetailDto>>
     */
    @PostMapping("/listDrop")
    @ResponseBody
    public BaseResult<PickingOrderDto>
    listDrop(@RequestBody @Valid OrderNoReq req) {
        return pickingOrderDetailService.listDrop(req);
    }

    /**
     * 拣货单明细修改
     * @param  req req
     * @return BaseResult<BasePageData<PickingOrderDetailDto>>
     */
    @PostMapping("/update")
    @ResponseBody
    public BaseResult<Boolean> update(@RequestBody @Valid PickingOrderDetailUpdateReq req) {
        return BaseResult.OK(pickingOrderDetailService.update(req));
    }

    /**
     * 拣货单明细保存
     * @param  req req
     * @return Boolean
     */
    @PostMapping("/save")
    @ResponseBody
    public BaseResult<Boolean> save(@RequestBody @Valid PickingOrderDetailSaveReq req) {
        return BaseResult.OK(pickingOrderDetailService.save(req));
    }
}