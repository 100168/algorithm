package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.FreightClaimOperateLogDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.ClaimNoReq;
import com.jiduauto.sps.server.service.IFreightClaimOperateLogService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 物流索赔状态变更记录表 前端控制器
 */
@RestController
@RequestMapping("/freightClaimOperateLog")
public class FreightClaimOperateLogController {

    @Resource
    private IFreightClaimOperateLogService freightClaimOperateLogService;

    /**
     *  状态变更分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<FreightClaimOperateLogDto>> pageSearch(@RequestBody @Valid BasePageParam<ClaimNoReq> pageParam) {
        return BaseResult.OK(freightClaimOperateLogService.pageSearch(pageParam));
    }

}
