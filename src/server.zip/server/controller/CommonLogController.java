package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.sdk.pojo.dto.CommonLogDto;
import com.jiduauto.sps.sdk.pojo.req.CommonLogReq;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.ClaimNoReq;
import com.jiduauto.sps.server.service.ICommonLogService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 通用日志记录 前端控制器
 */
@RestController
@RequestMapping("/commonLog")
public class CommonLogController {
    @Resource
    private ICommonLogService commonLogService;
    /**
     * 领克缺件订单日志分页查询
     */
    @PostMapping("/pageSearchLingKeBackLog")
    public BaseResult<BasePageData<CommonLogDto>> pageSearchLingKeBackLog(@RequestBody @Valid BasePageParam<CommonLogReq> req) {
        return BaseResult.OK(commonLogService.pageSearchLingKeBackLog(req));
    }
    /**
     * 领克销售日志订单分页查询
     */
    @PostMapping("/pageSearchLingKeSaleLog")
    public BaseResult<BasePageData<CommonLogDto>> pageSearchLingKeSaleLog(@RequestBody @Valid BasePageParam<CommonLogReq> req) {
        return BaseResult.OK(commonLogService.pageSearchLingKeSaleLog(req));
    }
    /**
     *  物流索赔值变更分页查询
     */
    @PostMapping("/pageSearchClaim")
    public BaseResult<BasePageData<CommonLogDto>> pageSearchClaim(@RequestBody @Valid BasePageParam<ClaimNoReq> pageParam) {
        return BaseResult.OK(commonLogService.pageSearchClaim(pageParam));
    }
}
