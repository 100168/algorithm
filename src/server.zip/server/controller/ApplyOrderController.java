package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.server.Enum.ApplyTypeEnum;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.Enum.GlobalCodeEnum;
import com.jiduauto.sps.server.Enum.SpsResponseCodeEnum;
import com.jiduauto.sps.server.consts.ApplyOrderStatusEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.exception.BizSAPException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.ApplyOrderDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.po.ApplyOrderPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.ValidGroup;
import com.jiduauto.sps.server.pojo.vo.req.*;
import com.jiduauto.sps.server.pojo.vo.req.stock.IdIpage;
import com.jiduauto.sps.server.pojo.vo.resp.ApplyOrderAnItemExportRest;
import com.jiduauto.sps.server.pojo.vo.resp.TrackDetailItemResp;
import com.jiduauto.sps.server.service.IApplyOrderService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import com.jiduauto.sps.server.utils.UserUtil;
import com.jiduauto.sps.server.utils.WebhookUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.groups.Default;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 领料单 前端控制器
 *
 * @author generate
 * @since 2023-05-15
 */
@RestController
@RequestMapping("/applyOrder")
@Slf4j
public class ApplyOrderController {

    @Autowired
    private IApplyOrderService applyOrderService;
    @Resource
    private RedissonClient redissonClient;

    @Autowired
    private WebhookUtil webhookUtil;

    /**
     * 添加
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/add")
    @ResponseBody
    public BaseResult add(@RequestBody @Validated({ValidGroup.Add.class, Default.class}) ApplyOrderReq req) {
        try {
            return applyOrderService.add(req);
        } catch (BizException e) {
            log.error("领料单添加异常", e);
            return BaseResult.error(e.getMessage());
        } catch (Exception e) {
            log.error("领料单添加异常", e);
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9998);
        }
    }

    /**
     * 已确认更正
     **/
    @RequestMapping("/modify")
    @ResponseBody
    public BaseResult<Boolean> modify(@RequestBody @Validated ApplyOrderEditReq req) {
        return applyOrderService.modify(req);
    }

    /**
     * 取消
     **/
    @RequestMapping("/cancel")
    @ResponseBody
    public BaseResult<Boolean> cancel(@RequestBody @Validated OrderIdReq req) {
        return applyOrderService.cancel(req);
    }

    /**
     * 详情列表
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/selectList")
    @ResponseBody
    public BaseResult<ApplyOrderDto> selectList(@RequestBody IdIpage pageParam) {
        return applyOrderService.selectList(pageParam);
    }

    /**
     * 修改
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    @RequestMapping("/edit")
    @ResponseBody
    public BaseResult edit(@RequestBody @Validated({ValidGroup.Edit.class, Default.class}) ApplyOrderReq req) {

        //以出库单抬头及业务类型及清单号为值加锁
        RLock lock = redissonClient.getLock(String.format(BaseConstants.RedisKey.APPLY_ORDER_NO_KEY, req.getBizType(), req.getApplyOrderNo()));
        try {
            if (lock.tryLock(1, 1, TimeUnit.SECONDS)) {
                return applyOrderService.edit(req);
            } else {
                return BaseResult.applicationError(SpsResponseCodeEnum.DUPLICATE_OPERATE);

            }
        } catch (BizException e) {
            log.error("编辑领料单异常", e);
            return BaseResult.systemError(e.getErrCode(), e.getErrMessage());
        } catch (Exception e) {
            log.error("编辑领料单异常", e);
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9998);
        } finally {
            //释放锁
            if (lock.isHeldByCurrentThread()) {
                lock.unlock();
            }
        }
    }


    /**
     * 更新 物流单号
     * @param noReq
     * @return
     */
    @RequestMapping("updateLogisticNo")
    @ResponseBody
    public BaseResult updateLogisticNo(@RequestHeader("bizType") String bizType,
                                       @RequestBody @Validated ApplyOrderUpdateLogisticNoReq noReq){
        if(bizType.equals(BizTypeEnum.VP.getBizType()) || bizType.equals(BizTypeEnum.JADT.getBizType())){
            ApplyOrderPo applyOrderPo = applyOrderService.getById(noReq.getId());
            if(applyOrderPo != null && (
                    applyOrderPo.getStatus().equals(ApplyOrderStatusEnum.allApply.getCode()) ||
                            applyOrderPo.getStatus().equals(ApplyOrderStatusEnum.partApply.getCode())
                    )  && applyOrderPo.getApplyType().equals(ApplyTypeEnum.EXP.getCode())){
                //业务类型为试制试验&智驾，状态为【部分领用/全部领用】且取货方式为快递时
                applyOrderService.updateLogisticNo(noReq.getId(), noReq.getLogisticNo());
            }
        }

        return BaseResult.OK();
    }

    /**
     * 领料单 确认
     *
     * @param bizType
     * @param orderNumbers 领料单单号
     * @return
     */
    @RequestMapping("confirm")
    @ResponseBody
    public BaseResult confirm(@RequestHeader("bizType") String bizType,
                              @RequestBody List<String> orderNumbers) {

        return applyOrderService.confirm(bizType, orderNumbers);
    }

    /**
     * 领料单 手动出库确认
     *
     * @param bizType
     * @param req
     * @return
     */
    @RequestMapping("outStockConfirm")
    @ResponseBody
    public BaseResult outStockConfirm(@RequestHeader("bizType") String bizType,
                                      @RequestBody @Validated({ValidGroup.Edit.class, Default.class}) ApplyOrderReq req) {

        try {
            return applyOrderService.outStockConfirm(bizType, req);
        } catch (BizSAPException e) {
            log.error("更正领料单异常", e);
            webhookUtil.sendMarkdownMessageV2(-1, e.getErrMessage() + ",request:" + JSON.toJSONString(req), "库存异步处理业务异常信息-领料订单", UserUtil.getUserName());
            return BaseResult.systemError(e.getErrCode(), e.getErrMessage());
        }
    }

    /**
     * 领料订单分页查询接口
     *
     * @author dong.li
     * @date 5/15/23 2:16 PM
     */
    @PostMapping("pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<ApplyOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<ApplyOrderPageSearchReq> req) {
        return BaseResult.OK(applyOrderService.pageSearch(req));
    }

    /**
     * 删除领料订单接口
     *
     * @author dong.li
     * @date 5/15/23 4:37 PM
     */
    @PostMapping("delete")
    @ResponseBody
    public BaseResult<String> delete(@RequestBody @Valid ApplyOrderIdReq req) {
        return applyOrderService.deleteById(req);
    }

    /**
     * 领料订单导入
     *
     * @author dong.li
     * @date 5/15/23 5:26 PM
     */
    @PostMapping("importExcel")
    @ResponseBody
    public BaseResult<ImportResultResp> importExcel(@RequestHeader("bizType") String bizType,
                                                    @RequestPart("file") MultipartFile file
    ) {
        if (StringUtils.isBlank(bizType)) {
            return BaseResult.systemError(GlobalCodeEnum.GL_FAIL_9998);
        }
        ImportResultResp res = applyOrderService.importFile(bizType, file);
        return BaseResult.OK(res);
    }

    /**
     * 领料订单导出
     *
     * @author dong.li
     * @date 5/15/23 5:26 PM
     */
    @PostMapping("export")
    @ResponseBody
    public void export(HttpServletResponse response, @RequestBody @Valid ApplyOrderPageSearchReq req) {
        try {
            ExcelUtils.exportXlsxResponse(response, "领料单导出");
            EasyExcel.write(response.getOutputStream(),  ApplyOrderAnItemExportRest.class)
                    .excludeColumnFiledNames(Arrays.asList("occupyQuantity"))
                    .sheet("模板")
                    .doWrite(applyOrderService.export(req));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

    /**
     * 物流轨迹
     *
     * @param req 运单号
     * @author O_chaopeng.huang
     */
    @PostMapping("/trackDetail")
    public BaseResult<List<TrackDetailItemResp>> trackDetail(@RequestBody LogisticNoReq req) {
        return BaseResult.OK(applyOrderService.trackDetail(req));
    }

    /**
     * 领料租户
     */
    @RequestMapping("/saveApplyBizType")
    @ResponseBody
    public BaseResult<String> save(@RequestBody @Valid ApplyBizTypeUpdateReq req) {

        applyOrderService.saveApplyBizType(req);
        return BaseResult.OK();
    }
}
