package com.jiduauto.sps.server.controller;


import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PendingReceiveListDetailDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;
import com.jiduauto.sps.server.service.IPendingReceiveListDetailService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 待收货列表明细 前端控制器
 *
 * @author generate
 * @since 2023-08-22
 */
@RestController
@RequestMapping("/pendingReceiveList/detail")
public class PendingReceiveListDetailController {


    @Resource
    private IPendingReceiveListDetailService pendingReceiveListDetailService;

    /**
     * 待收货明细分页查询
     * @param req req
     * @return page
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<PendingReceiveListDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<OrderNoReq> req) {
        return BaseResult.OK(pendingReceiveListDetailService.pageSearch(req));
    }

    /**
     * 待收货和关单列表
     *
     * @param req req
     * @return page
     */
    @PostMapping("/waitReceiveList")
    @ResponseBody
    public BaseResult<List<PendingReceiveListDetailDto>> waitReceiveList(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(pendingReceiveListDetailService.waitReceiveList(req));
    }


}
