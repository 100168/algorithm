package com.jiduauto.sps.server.controller;


import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.AsnAllDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderAddReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderAsnPageSearch;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderAuditReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderEditReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderSearchReq;
import com.jiduauto.sps.server.service.IPurchaseReturnOrderService;

import lombok.extern.slf4j.Slf4j;

/**
 * 采购退货订单 前端控制器
 *
 * @author generate
 * @since 2023-05-04
 */
@RestController
@RequestMapping("/purchaseReturnOrder")
@Slf4j
public class PurchaseReturnOrderController {

    @Resource
    private IPurchaseReturnOrderService purchaseReturnOrderService;


    /**
     * 列表分页查询
     *
     * @param pageParam 请求参数
     * @return page
     */

    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<PurchaseReturnOrderDto>> pageSearch(
            @RequestBody @Valid BasePageParam<PurchaseReturnOrderSearchReq> pageParam) {
        return BaseResult.OK(purchaseReturnOrderService.pageSearch(pageParam));
    }


    /**
     * 采购退货单新建
     *
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/createTempRecord")
    @LoginCheck
    public BaseResult<PurchaseReturnOrderDto> createTempRecord(@RequestBody @Valid PurchaseReturnOrderAddReq request) {
        return purchaseReturnOrderService.createTempRecord(request);
    }

    /**
     * 保存草稿
     *
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/enableTempRecord")
    @LoginCheck
    public BaseResult<Boolean> enableTempRecord(@RequestBody @Valid IdReq request) {
        return purchaseReturnOrderService.enableTempRecord(request);
    }

    /**
     * 编辑
     *
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/edit")
    @LoginCheck
    public BaseResult<PurchaseReturnOrderDto> edit(@RequestBody @Valid PurchaseReturnOrderEditReq request) {
        return purchaseReturnOrderService.edit(request);
    }

    /**
     * 编辑提交
     *
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/commit")
    @LoginCheck
    public BaseResult<Boolean> commit(@RequestBody @Valid IdReq request) {
        return purchaseReturnOrderService.commit(request);
    }


    /**
     * 列表删除
     *
     * @param request id
     * @return boolean
     */
    @PostMapping("/delete")
    @LoginCheck
    public BaseResult<Boolean> delete(@RequestBody @Valid IdReq request) {
        return purchaseReturnOrderService.deleteById(request);
    }

    /**
     * 审核通过
     *
     * @param request 请求
     * @return boolean
     */
    @PostMapping("/audit")
    @LoginCheck
    public BaseResult<Boolean> audit(@RequestBody @Valid PurchaseReturnOrderAuditReq request) {
        return BaseResult.OK(purchaseReturnOrderService.audit(request));
    }
    /**
     * 根据已绑定ans采购的退货明细过滤已选asn
     * @author O_chaopeng.huang
     * @param  param
     * @return BaseResult<BasePageData<AsnAllDto>>
     */
    @PostMapping("/pageList")
    public BaseResult<BasePageData<AsnAllDto>> pageList(@RequestBody @Validated BasePageParam<PurchaseReturnOrderAsnPageSearch> param) {
        log.info("AsnBasicController-page-param:{}", param);
        return BaseResult.OK(purchaseReturnOrderService.pageList(param));
    }

}
