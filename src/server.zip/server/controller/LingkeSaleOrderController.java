package com.jiduauto.sps.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.server.annotation.InvokeLog;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.LingkeSaleOrderDetailDto;
import com.jiduauto.sps.server.pojo.dto.LingkeSaleOrderDto;
import com.jiduauto.sps.server.pojo.fileexport.LingkeSaleOrderExportDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.LingkeSaleOrderPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderIdReq;
import com.jiduauto.sps.server.service.ILingkeSaleOrderService;
import com.jiduauto.sps.server.utils.ExcelUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 领克销售订单 前端控制器
 */
@RestController
@RequestMapping("/lingkeSaleOrder")
public class LingkeSaleOrderController {

    @Resource
    private ILingkeSaleOrderService lingkeSaleOrderService;
    /**
      * 领克销售分页查询
      */
    @RequestMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<LingkeSaleOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<LingkeSaleOrderPageSearchReq> req) {
        return BaseResult.OK(lingkeSaleOrderService.pageSearch(req));
    }
    /**
     * 领克销售详情
     */
    @RequestMapping("/selectById")
    @ResponseBody
    public BaseResult<BasePageData<LingkeSaleOrderDetailDto>> selectById(@RequestBody @Valid BasePageParam<OrderIdReq>  req) {
        return BaseResult.OK(lingkeSaleOrderService.selectById(req));
    }
    /**
     * 领克销售订单导出
     */
    @RequestMapping("/export")
    @InvokeLog
    public void export(@RequestBody @Valid BasePageParam<LingkeSaleOrderPageSearchReq> pageParam) {
        try {
            HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getResponse();
            ExcelUtils.exportXlsxResponse(response, "领克销售订单");
            EasyExcel.write(response.getOutputStream(), LingkeSaleOrderExportDto.class).sheet("领克销售订单").doWrite(lingkeSaleOrderService.export(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }
}
