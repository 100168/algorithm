package com.jiduauto.sps.server.controller;

import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.SalePriceApprovalAttachmentDto;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.ItemIdReq;
import com.jiduauto.sps.server.service.IDictService;
import com.jiduauto.sps.server.service.ISalePriceApprovalAttachmentService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 销售价格审批-附件明细 前端控制器
 */
@RestController
@RequestMapping("/salePriceApproval/attachment")
public class SalePriceApprovalAttachmentController {

    @Resource
    private IDictService dictService;

    @Resource
    private ISalePriceApprovalAttachmentService salePriceApprovalAttachmentService;

    /**
     * 上传
     * @param bizType
     * @param approvalId
     * @param files
     * @return
     */
    @PostMapping("/upload")
    @LoginCheck
    public BaseResult upload(@RequestHeader("bizType") String bizType,
                             @RequestParam("approvalId") Long approvalId,
                             @RequestPart("files") MultipartFile[] files) {
        if (!dictService.isContained(bizType, DictEnum.BIZTYPE)) {
            throw new BizException("bizType错误");
        }
        salePriceApprovalAttachmentService.upload(bizType, approvalId, files);
        return BaseResult.OK();
    }

    /**
     * 删除
     * @param request
     * @return
     */
    @PostMapping("/delete")
    @LoginCheck
    public BaseResult delete(@RequestBody @Valid ItemIdReq request) {
        salePriceApprovalAttachmentService.delete(request);
        return BaseResult.OK();
    }

    /**
     * 分页查询
     * @param pageSearchReq
     * @return
     */
    @PostMapping("/pageSearch")
    @LoginCheck
    public BaseResult<BasePageData<SalePriceApprovalAttachmentDto>> pageSearch(@RequestBody @Valid BasePageParam<IdReq> pageSearchReq) {
        return BaseResult.OK(salePriceApprovalAttachmentService.pageSearch(pageSearchReq));
    }
}
