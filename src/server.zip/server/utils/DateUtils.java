/**
 * ymm56.com Inc.
 * Copyright (c) 2013-2018 All Rights Reserved.
 */
package com.jiduauto.sps.server.utils;



import com.jiduauto.sps.server.exception.BizException;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

@Slf4j
public class DateUtils {

    public static final String STANDARD_DATE_FORMAT = "yyyy-MM-dd";
    public static final String STANDARD_DATE_RIGHT_LINE_FORMAT = "yyyy/MM/dd";
    public static final String STANDARD_DATE_RIGHT_LINE_FORMAT_2 = "yyyy/M/d";

    public static final String SHORT_DATE_FORMAT = "yyyyMMdd";
    public static final String SHORT_DATE_FORMAT_FULL = "yyyyMMddHHmmss";
    public static final String SHORT_DATE_FORMAT_2 = "yyMMdd";
    public static final String SHORT_MONTH_FORMAT = "yyyyMM";
    public static final String SHORT_MONTH_FORMAT_2 = "yyyy-MM";
    public static final String SHORT_ONLY_TIME_FORMAT = "HHmmss";
    public static final String SHORT_ONLY_TIME_FORMAT1 = "HH:mm:ss";

    public static final String STANDARD_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static final String SHORT_TIME_FORMAT = "yyyy-MM-dd HH:mm";

    public static final String YEAR_TIME_FORMAT = "yyyy";

    public static final String STANDARD_DOT_DATE_FORMAT = "yyyy.MM.dd";

    public static final String STANDARD_DOT_TIME_FORMAT = "yyyy.MM.dd HH:mm:ss";


    /**
     * 2018-06-30
     */
    private static final String STANDARD_DATE_PATTERN = "^\\d{4}-\\d{2}-\\d{2}$";

    private static final String STANDARD_RIGHT_LINE_DATE_PATTERN = "^\\d{4}\\/\\d{1,2}\\/\\d{1,2}$";


    /**
     * 20180630
     */
    private static final String SHORT_DATE_PATTERN = "^\\d{8}$";


    /**
     * 2018-06-30 10:00:00
     */
    private static final String STANDARD_TIME_PATTERN = "^\\d{4}-\\d{1,2}-\\d{1,2} \\d{2}:\\d{2}:\\d{2}$";

    /**
     * 2018-06-30 10:00
     */
    private static final String SHORT_TIME_PATTERN = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}$";

    /**
     * 2019
     */
    private static final String YEAR_TIME_PATTERN = "^\\d{4}$";

    /**
     * 2019.12.01
     */
    private static final String STANDARD_DOT_DATE_PATTERN = "^\\d{4}\\.\\d{2}\\.\\d{2}$";

    /**
     * 2019.12.01 00:00:00
     */
    private static final String STANDARD_DOT_TIME_PATTERN = "^\\d{4}\\.\\d{2}\\.\\d{2} \\d{2}:\\d{2}:\\d{2}$";

    public static final Pattern yyyy_MM_dd = Pattern.compile("[0-9]{4}-[0-9]{2}-[0-9]{2}");
    public static final Pattern yyyyMMdd = Pattern.compile("[0-9]{4}[0-9]{2}[0-9]{2}");
    //HH:mm:ss
    public static final Pattern HHmmss = Pattern.compile("[0-9]{2}:[0-9]{2}:[0-9]{2}");
    public static final Pattern Hmmss = Pattern.compile("[0-9]{1}:[0-9]{2}:[0-9]{2}");
    /**
     * 校验日期格式
     *
     * @param date
     * @param pattern
     * @return
     */
    public static boolean isDateFormat(String date, Pattern pattern) {
        if (StringUtils.isBlank(date)) {
            return false;
        }
        return pattern.matcher(date).matches();
    }

    /**
     * 不包含时分秒
     * string 转 localdateTime
     * @param dateStr
     * @param format
     * @return
     */
    public static LocalDateTime parse(String dateStr, String format){
        if(StringUtils.isBlank(dateStr)){
            return null;
        }
        SimpleDateFormat smf = new SimpleDateFormat(format);
        Date date ;
        try {
            date = smf.parse(dateStr);
            return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        } catch (ParseException e) {
            throw new BizException("日期转换失败 date" +dateStr+format);
        }
    }
    /**
     * 不包含时分秒
     * string 转 localdateTime
     * @param dateStr
     * @param format
     * @return
     */
    public static String parseFormat(String dateStr, String format){
        if(StringUtils.isBlank(dateStr)){
            return null;
        }
        SimpleDateFormat smf = new SimpleDateFormat(format);
        Date date ;
        try {
            date = smf.parse(dateStr);
            return smf.format(date);
        } catch (ParseException e) {
            throw new BizException("日期转换失败 date" +dateStr+format);
        }
    }

    /**
     * localDateTime to string
     * @param localDateTime
     * @param format
     * @return
     */
    public static String format(LocalDateTime localDateTime,String format){
        if(localDateTime == null){
            return null;
        }
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(format);
        return dateTimeFormatter.format(localDateTime);
    }

    public static String format(String dateStr, String  sourceFormat, String targetFormat){
        if (StringUtils.isBlank(dateStr)) {
            return null;
        }

        DateTimeFormatter sourceFormatter = DateTimeFormatter.ofPattern(sourceFormat);
        LocalDate parsedDate = LocalDate.parse(dateStr, sourceFormatter);

        DateTimeFormatter targetFormatter = DateTimeFormatter.ofPattern(targetFormat);
        return parsedDate.format(targetFormatter);}

    /**
     * 字符串转化为日期类型
     *
     * @param dateStr 字符串类型日期
     * @return 日期
     */
    public static Date getDate(String dateStr) {
        if (StringUtils.isEmpty(dateStr)) {
            return null;
        }
        dateStr = StringUtils.trim(dateStr);
        String formatStr = null;
        if (dateStr.matches(STANDARD_DATE_PATTERN)) {
            formatStr = STANDARD_DATE_FORMAT;
        } else if (dateStr.matches(SHORT_DATE_PATTERN)) {
            formatStr = SHORT_DATE_FORMAT;
        } else if (dateStr.matches(STANDARD_TIME_PATTERN)) {
            formatStr = STANDARD_TIME_FORMAT;
        } else if (dateStr.matches(SHORT_TIME_PATTERN)) {
            formatStr = SHORT_TIME_FORMAT;
        } else if (dateStr.matches(YEAR_TIME_PATTERN)) {
            formatStr = YEAR_TIME_FORMAT;
        } else if (dateStr.matches(STANDARD_DOT_DATE_PATTERN)) {
            formatStr = STANDARD_DOT_DATE_FORMAT;
        } else if (dateStr.matches(STANDARD_DOT_TIME_PATTERN)) {
            formatStr = STANDARD_DOT_TIME_FORMAT;
        }
        if (formatStr == null || StringUtils.isEmpty(dateStr)) {
            return null;
        }
        SimpleDateFormat df = new SimpleDateFormat(formatStr);
        Date date = null;
        try {
            date = df.parse(dateStr);
        } catch (ParseException e) {
            log.error("字符串转化日期异常" + dateStr, e);
        }
        return date;
    }

    /**
     * 验证日志格式
     *
     * @param dateStr
     * @return
     */
    public static boolean checkDateFormat(String dateStr) {
        if (dateStr.matches(STANDARD_DATE_PATTERN)) {
            return true;
        } else if (dateStr.matches(SHORT_DATE_PATTERN)) {
            return true;
        } else if (dateStr.matches(STANDARD_TIME_PATTERN)) {
            return true;
        } else if (dateStr.matches(SHORT_TIME_PATTERN)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 间隔时间
     *
     * @param startDate 开始时间
     * @param endDate   结束时间
     * @return 间隔多少天
     */
    public static int getDayOffset(String startDate, String endDate) {
        Date date1 = getDate(startDate);
        Date date2 = getDate(endDate);
        if (date1 == null || date2 == null) {
            throw new RuntimeException("日期格式不正确");
        }
        return (int) ((date1.getTime() - date2.getTime()) / (1000 * 3600 * 24));
    }

    /**
     * 根据日期获取字符串
     *
     * @param date      日期类型
     * @param formatStr yyyy-MM-dd
     * @return 字符串
     */
    public static String getDateStr(Date date, String formatStr) {
        if (date == null) {
            return null;
        }
        SimpleDateFormat df = new SimpleDateFormat(formatStr);
        String timeStr = null;
        try {
            timeStr = df.format(date);
        } catch (Exception e) {
            log.error("日期转化字符串异常" + date, e);
        }
        return timeStr;
    }
/**
     * 根据日期获取字符串
     *
     * @param date      日期类型
     * @param formatStr yyyy-MM-dd
     * @return 字符串
     */
    public static String getLocalDateTimeStr(LocalDateTime date, String formatStr) {
        if(date == null){
            return null;
        }
        return date.format(DateTimeFormatter.ofPattern(formatStr));
    }/**
     * 根据日期获取字符串
     *
     * @param date      日期类型
     * @param formatStr yyyy-MM-dd
     * @return 字符串
     */
    public static String getLocalDateStr(LocalDate date, String formatStr) {
        if(date == null){
            return null;
        }
        return date.format(DateTimeFormatter.ofPattern(formatStr));
    }
    public static LocalDateTime getLocalDateTimeByFormat(LocalDateTime date, String formatStr) {
        if(date == null){
            return null;
        }
        return LocalDateTime.parse(getLocalDateTimeStr(date,formatStr));
    }


    public static Date currentStartDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    public static Date currentEndDay() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        return calendar.getTime();
    }
    public static String currentStartDayStr() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return getDateStr(calendar.getTime(),STANDARD_TIME_FORMAT);
    }

    public static String currentEndDayStr() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        return getDateStr(calendar.getTime(),STANDARD_TIME_FORMAT);
    }
    //当天的前X天的开始时间
    public static String beforeCurrentStartDayStr(int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, days);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return getDateStr(calendar.getTime(),STANDARD_TIME_FORMAT);
    }
    //当天的前X天的结束时间
    public static String beforeCurrentEndDayStr(int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH,days);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        return getDateStr(calendar.getTime(),STANDARD_TIME_FORMAT);
    } //当天的前X天的结束时间
    public static String beforeCurrentEndDayStr(int days, String format) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH,days);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        return getDateStr(calendar.getTime(),format);
    }

    public static String addMonthForDate(LocalDateTime date, int month, String format){
        date = date.plusMonths(month);
        return date.format(DateTimeFormatter.ofPattern(format));
    }

    /**
     * 当年时间增加分钟
     * @param date
     * @param minutes
     * @param format
     * @return
     */
    public static String addMinutesForDate(LocalDateTime date, int minutes, String format){
        date = date.plusMinutes(minutes);
        return date.format(DateTimeFormatter.ofPattern(format));
    }

    /**
     * 当天还剩多少秒
     *
     * @return
     */
    public static int getLeftSecondsCurrentDay() {
        Calendar calendar = Calendar.getInstance();
        return (int) ((currentEndDay().getTime() - calendar.getTimeInMillis()) / 1000);
    }

    /**
     * 当前小时内 还剩多少秒
     *
     * @return
     */
    public static int getLeftSecondsCurrentOur() {
        LocalDateTime nowHour = LocalDateTime.now();
        LocalDateTime endHour = LocalDateTime.now().plusHours(1).withMinute(0).withSecond(0);
        return (int) ChronoUnit.SECONDS.between(nowHour, endHour);
    }

    /**
     * 获取当前时间
     * @param formatStr
     * @return
     */
    public static String getCurrentDate(String formatStr){

        SimpleDateFormat df = new SimpleDateFormat(formatStr);
        String timeStr = null;
        Date date = new Date();
        try {
            timeStr = df.format(date);
        } catch (Exception e) {
            log.error("日期转化字符串异常" + date, e);
        }
        return timeStr;
    }



    /**
     * 获取日期date 前/后 monthOffSet 个月的最后一天
     * eg： 获取上个月的最后一天
     *
     * @param date        基准时间
     * @param monthOffSet 日期偏移
     * @return 时间
     */
    public static Date getMonthEndDay(Date date, int monthOffSet) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        instance.set(Calendar.MONTH, instance.get(Calendar.MONTH) + monthOffSet);
        /*如果不把天置为1，会导致  startDate=20200531在执行完月份-1后,时间为20200431，但实际没有31号，所以根据时间戳其实是20200501，
        instance.getActualMaximum(Calendar.DAY_OF_MONTH) 获取的不是4月的最大天数，而是5月的*/
        instance.set(Calendar.DAY_OF_MONTH, 1);
        instance.set(Calendar.DAY_OF_MONTH, instance.getActualMaximum(Calendar.DAY_OF_MONTH));
        instance.set(Calendar.HOUR_OF_DAY, 0);
        instance.set(Calendar.MINUTE, 0);
        instance.set(Calendar.SECOND, 0);
        instance.set(Calendar.MILLISECOND, 0);
        return instance.getTime();
    }

    /**
     * 获取日期date 前/后 monthOffSet 个月的第一天
     * eg： 获取上个月的第一天
     *
     * @param date        基准时间
     * @param monthOffSet 日期偏移
     * @return 时间
     */
    public static Date getMonthStartDay(Date date, int monthOffSet) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        instance.set(Calendar.MONTH, instance.get(Calendar.MONTH) + monthOffSet);
        instance.set(Calendar.DAY_OF_MONTH, instance.getActualMinimum(Calendar.DAY_OF_MONTH));
        instance.set(Calendar.HOUR_OF_DAY, 0);
        instance.set(Calendar.MINUTE, 0);
        instance.set(Calendar.SECOND, 0);
        instance.set(Calendar.MILLISECOND, 0);
        return instance.getTime();
    }

    /**
     * 获取上个月最后一天
     */
    public static int getLastMonthEndDay(int startDate) {
        Date date = DateUtils.getDate(String.valueOf(startDate));
        Date lastDayLastMonth = getMonthEndDay(date, -1);
        return Integer.parseInt(DateUtils.getDateStr(lastDayLastMonth, DateUtils.SHORT_DATE_FORMAT));
    }

    /**
     * 获取上个月的第一天
     */
    public static int getLastMonthStartDay(int startDate) {
        Date date = DateUtils.getDate(String.valueOf(startDate));
        Date firstDayLastMonth = getMonthStartDay(date, -1);
        return Integer.parseInt(DateUtils.getDateStr(firstDayLastMonth, DateUtils.SHORT_DATE_FORMAT));
    }


    public static Date getNextDay(Date date, int offSet) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        instance.set(Calendar.DAY_OF_MONTH, instance.get(Calendar.DAY_OF_MONTH) + offSet);
        instance.set(Calendar.HOUR_OF_DAY, 0);
        instance.set(Calendar.MINUTE, 0);
        instance.set(Calendar.SECOND, 0);
        instance.set(Calendar.MILLISECOND, 0);
        return instance.getTime();
    }

    public static int getDayOfWeek(String date){
        Date now = DateUtils.getDate(date);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(now);
        //周一 为一周的第一天
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        return calendar.get(Calendar.DAY_OF_WEEK) - 1;
    }

    /**
     * after 晚于  before。
     * @param after
     * @param before
     * @return
     */
    public static  boolean afterTo(Date after, Date before){
       return  after.compareTo(before) > 0;
    }

    public static boolean localTimeBefore(String before, String after) {
        return LocalTime.parse(before).isBefore(LocalTime.parse(after));
    }

    public static String getFormat(String dateStr){
        if (StringUtils.isEmpty(dateStr)) {
            return null;
        }
        String formatStr = null;
        if (dateStr.matches(STANDARD_DATE_PATTERN)) {
            formatStr = STANDARD_DATE_FORMAT;
        } else if (dateStr.matches(SHORT_DATE_PATTERN)) {
            formatStr = SHORT_DATE_FORMAT;
        } else if (dateStr.matches(STANDARD_TIME_PATTERN)) {
            formatStr = STANDARD_TIME_FORMAT;
        } else if (dateStr.matches(SHORT_TIME_PATTERN)) {
            formatStr = SHORT_TIME_FORMAT;
        } else if (dateStr.matches(YEAR_TIME_PATTERN)) {
            formatStr = YEAR_TIME_FORMAT;
        } else if (dateStr.matches(STANDARD_DOT_DATE_PATTERN)) {
            formatStr = STANDARD_DOT_DATE_FORMAT;
        } else if (dateStr.matches(STANDARD_DOT_TIME_PATTERN)) {
            formatStr = STANDARD_DOT_TIME_FORMAT;
        } else if (dateStr.matches(STANDARD_RIGHT_LINE_DATE_PATTERN)) {
            formatStr = STANDARD_DATE_RIGHT_LINE_FORMAT;
        }

        return formatStr;
    }

    public static LocalDateTime parse(String dateStr){
        if(StringUtils.isNotBlank(dateStr)){
           return  LocalDateTime.parse(dateStr,DateTimeFormatter.ofPattern(getFormat(dateStr)));
        }
        return null;
    }
    public static LocalDateTime dateToLocalDateTime(String str) {
        Date date = getDate(str);
        if (null == date) {
            return null;
        }
        final Instant instant = date.toInstant();
        final ZoneId zoneId = ZoneId.systemDefault();
        final LocalDateTime localDateTime = instant.atZone(zoneId).toLocalDateTime();
        return localDateTime;
    }

    /**
     * UTC时间转换为 本地时间
     * @param localDateTime
     * @return
     */
    public static LocalDateTime utcToLocal(LocalDateTime localDateTime){
        if(localDateTime == null){
            return null;
        }
        ZoneId localZone = ZoneId.systemDefault();
        return  localDateTime.atZone(ZoneOffset.UTC).withZoneSameInstant(localZone).toLocalDateTime();
    }

    /**
     * UTC时间转换为 本地时间
     * @param localDateTime
     * @return
     */
    public static LocalDateTime utcStrToLocal(String localDateTime){
       return  utcToLocal(parse(localDateTime));
    }

    /**
     * UTC时间转换为 本地时间
     * @param localDateTime
     * @return
     */
    public static String utcStrToLocalStr(String localDateTime){
       LocalDateTime temp =  utcToLocal(parse(localDateTime));
       return format(temp, STANDARD_TIME_FORMAT);
    }

    public static void main(String[] args) {
        String dateStr = "2024/8/19";
        String sourceFormat = "yyyy/M/d";
        String targetFormat = "yyyy-MM-dd";
        String formattedDate = format(dateStr, sourceFormat, targetFormat);
        System.out.println("Parsed and formatted date: " + formattedDate);
//        System.out.println(utcStrToLocalStr("2023-09-01 00:11:11"));
//        System.out.println(isDateFormat("2023-09-01", Pattern.compile(STANDARD_DATE_PATTERN)));
//        System.out.println(isDateFormat("2023-09-01", yyyy_MM_dd));
//       String pa =  "^\\d{4}\\/\\d{1,2}\\/\\d{1,2}$";
//        System.out.println("2023/1/1".matches(pa));
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("[yyyy-MM-dd][yyyy-M-dd][yyyy-MM-dd HH:mm:ss][yyyy-M-dd HH:mm:ss]");
//        System.out.println(dateToLocalDateTime("0023-05-17 15:42:00"));
//        System.out.println(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
//        System.out.println(parse("2023-01-01 00:00:00"));
//        System.out.println(getCurrentDate("yyMMdd"));
//        parse("2023/1/1",SHORT_DATE_FORMAT);
//        System.out.println(LocalDate.parse("2021-01-01", DateTimeFormatter.ofPattern(STANDARD_DATE_FORMAT)));
//        System.out.println(parse("2021-01-01"));
//        System.out.println(getCurrentDate(SHORT_ONLY_TIME_FORMAT));
//        System.out.println(addMonthForDate(LocalDateTime.now(), 1, SHORT_DATE_FORMAT));
        //
//        System.out.println(getDayOfWeek("2021-01-01"));
//        System.out.println(getLeftSecondsCurrentOur());
//
//
//        int dayOffset = getDayOffset("2020.02.27 00:00:00", "2020.03.02 01:00:00");
//        System.out.println(dayOffset);

//        int day = 0;
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTime(DateUtils.getDate("2021-10-24"));
//        //周一 为一周的第一天
//        calendar.setFirstDayOfWeek(Calendar.MONDAY);
//        int weekOfMonth = calendar.get(Calendar.WEEK_OF_YEAR);
//        int year = calendar.get(Calendar.YEAR);
//        //极端新年第一天是星期几
//        int dayOfWeek = DateUtils.getDayOfWeek(year+"-01-01");
//        if(dayOfWeek > 4){
//            //新年第一周不足 半周，从第二周开始全第一周
//            day =  weekOfMonth - 1;
//        }else{
//            day = weekOfMonth;
//        }
//        System.out.println(year  + "   "+day);
    }

    /**
     * 获取当月的开始日期时间
     * @return
     */
    public static LocalDateTime getStartTimeOfCurrentMonth(){
        return LocalDateTime.now().withDayOfMonth(1).with(LocalTime.MIN);
    }

    /**
     * 获取当月的结束时间
     * @return
     */
    public static LocalDateTime getEndTimeOfCurrentMonth(){
        return LocalDateTime.now().withDayOfMonth(1).plusMonths(1).minusDays(1).with(LocalTime.MAX);
    }


    public static boolean  checkFormat(String dateStr, String formatStr){
        if(StringUtils.isBlank(dateStr)){
            return true;
        }
        String source = getFormat(dateStr);
        return formatStr.equals(source);
    }

    /**
     * 两个日期之间的天数
     * @param startDate
     * @param endDate
     * @return
     */
    public static Integer betweenDays(LocalDate endDate, LocalDate startDate,  int addDays){
        if(startDate != null && endDate != null){
            long days =  ChronoUnit.DAYS.between(startDate, endDate);
            return (int) days + addDays;
        }
        return null;
    }

    /**
     * 字符串 转为 localdate
     * @param dateStr
     * @return
     */
    public static LocalDate parseDate(String dateStr){
        if(StringUtils.isBlank(dateStr)){
            return null;
        }
        return LocalDate.parse(dateStr);
    }

    /**
     * 返回连个日期中较大的值
     * @param startDate
     * @param endDate
     * @return
     */
    public static LocalDate maxDate(LocalDate startDate, LocalDate endDate){
        if(startDate == null ){
            return endDate;
        }
        if(endDate == null){
            return startDate;
        }
        if(startDate.isAfter(endDate)){
            return startDate;
        }
        return endDate;
    }
}