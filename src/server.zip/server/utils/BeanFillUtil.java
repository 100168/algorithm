package com.jiduauto.sps.server.utils;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;

/**
 * @author panjian
 */
public class BeanFillUtil {

    public static <T> void fillNullStr(T resp){

      BeanUtil.edit(resp, field -> {
           try {
               Class<?> declaringClass = field.getType();
               if (declaringClass != String.class) {
                   return field;
               }
               field.setAccessible(true);
               Object value = field.get(resp);
               if (value != null){
                   return field;
               }
               field.set(resp, StrUtil.EMPTY);
               return field;

           } catch (IllegalAccessException e) {
               throw new RuntimeException(e);
           }
       });
    }

}
