package com.jiduauto.sps.server.utils;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * @author HuangKun
 * @date 2022/10/26
 */
public class NumberUtil {
    private static final Pattern NUMBER_PATTERN = Pattern.compile("-?\\d+(\\.\\d+)?");
    private static final Pattern INTEGER_PATTERN = Pattern.compile("[1-9]\\d*");
    private static final Pattern DOUBLE_PATTERN = Pattern.compile("\\d+(\\.\\d+)?");
    private static final Pattern ONE_DECIMAL_PATTERN = Pattern.compile("^[+-]?(0|([1-9]\\d*))(\\.\\d{1})?$");
    private static final Pattern THREE_DECIMAL_PATTERN = Pattern.compile("^[+-]?(0|([1-9]\\d*))(\\.\\d{1,3})?$");


    public static boolean validLongValue(Long longValue) {
        return !Objects.isNull(longValue) && longValue.compareTo(0L) > 0;
    }

    public static Boolean validIntegerValue(Integer intValue) {
        if (Objects.isNull(intValue) || intValue.compareTo(0) <= 0) {
            return false;
        }
        return true;
    }

    public static Boolean validDoubleValue(Double doubleValue) {
        if (Objects.isNull(doubleValue) || doubleValue.compareTo(0.0) <= 0) {
            return false;
        }
        return true;
    }

    public static Boolean validIntegerAndZeroValue(Integer intValue) {
        if (Objects.isNull(intValue) || intValue.compareTo(0) < 0) {
            return false;
        }
        return true;
    }

    /**
     * 获取BigDecimal小数点后几位
     *
     * @param value
     * @return Integer
     */
    public static Integer getNumberOfDecimalPlace(BigDecimal value) {
        final String str = value.toPlainString();
        final int index = str.indexOf('.');
        if (index < 0) {
            return 0;
        }
        return str.length() - 1 - index;
    }

    public static boolean isNumeric(String str) {
        return str != null && NUMBER_PATTERN.matcher(str).matches();
    }

    public static boolean isPositiveInteger(String str) {
        return str != null && INTEGER_PATTERN.matcher(str).matches();
    }
    public static boolean isPositiveDouble(String str) {
        return str != null && DOUBLE_PATTERN.matcher(str).matches();
    }
    // 最多带有一位小数的数字
    public static boolean isOneDecimalNumber(String str){
        return ONE_DECIMAL_PATTERN.matcher(str).matches();
    }

    /**
     * 最大三位小数
     * @param str
     * @return
     */
    public static boolean isMaxThreeDecimalNumber(String str){
        return THREE_DECIMAL_PATTERN.matcher(str).matches();
    }
}
