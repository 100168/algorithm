package com.jiduauto.sps.server.utils;

import com.jiduauto.passport.conf.UserInfoThreadHolder;
import com.jiduauto.passport.pojo.dto.UserInfo;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.po.BaseEntity;
import java.time.LocalDateTime;
import org.springframework.util.StringUtils;

/**
 * 用户信息工具类
 *
 * @author HuangKun
 * @date 2022/10/9
 */
public class UserUtil {

    private final static int NAME_LENGTH_LIMIT = 32;

    private UserUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static UserInfo getLoginUserInfo() {
        UserInfo user = UserInfoThreadHolder.getCurrentUser();
        if (user == null || StringUtils.isEmpty(user.getUsername())) {
            throw new BizException("用户登录信息异常");
        }
        return user;
    }

    public static String getUserName(){
        UserInfo user = UserInfoThreadHolder.getCurrentUser();
        if (user == null || StringUtils.isEmpty(user.getUsername())) {
            return null;
        }
        return formatName(user.getName());
    }

    public static <T extends BaseEntity> void fillCreateOrUpdateInfo(T po,boolean isCreated){
        if (isCreated){
            po.setCreateTime(LocalDateTime.now());
            po.setCreateUser(getUserName());
        }
        po.setUpdateUser(getUserName());
        po.setUpdateTime(LocalDateTime.now());
    }



    /**
     * 格式化名称，超长则截取
     */
    public static String formatName(String name) {
        if (com.jiduauto.sps.server.utils.StringUtils.isEmpty(name)) {
            return com.jiduauto.sps.server.utils.StringUtils.EMPTY;
        }

        if (name.contains(" ") && name.contains("(")) {
            name = name.substring(0, name.indexOf(" ")).concat(name.substring(name.indexOf("(")));
        }
        return name.length() > NAME_LENGTH_LIMIT ? name.substring(0, NAME_LENGTH_LIMIT) : name;
    }

    public static void removeUserInfo() {
        UserInfoThreadHolder.remove();
    }
}
