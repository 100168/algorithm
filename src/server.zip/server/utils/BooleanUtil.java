package com.jiduauto.sps.server.utils;

import cn.hutool.core.util.StrUtil;
import java.util.Objects;

public class BooleanUtil {


    public static String toChinese(Boolean bool) {
        if (Objects.isNull(bool)) {
            return "";
        }
        return bool ? "是" : "否";
    }

    public static String toYN(Boolean bool) {
        if (Objects.isNull(bool)) {
            return "";
        }
        return bool ? "Y" : "N";
    }

    public static String yesOrNoToShort(String bool) {
        if (Objects.isNull(bool)) {
            return "";
        }
        if("YES".equals(bool) || "yes".equals(bool)){
            return "Y";
        }else if("NO".equals(bool) || "no".equals(bool)){
            return "N";
        }else{
            return bool;
        }
    }

    public static String chineseToYN(String chineseBool) {
        if (Objects.isNull(chineseBool)) {
            return null;
        }
        if(chineseBool.equals("Y")){
            return "是";
        }
        if(chineseBool.equals("N")){
            return "否";
        }
        return null;
    }

    public static String chineseDescToYN(String chineseBool) {
        if (Objects.isNull(chineseBool)) {
            return StrUtil.EMPTY;
        }
        if(chineseBool.equals("是")){
            return "Y";
        }
        if(chineseBool.equals("否")){
            return "N";
        }
        return StrUtil.EMPTY;
    }

    public static String oneOrZeroToChinese(String oneOrZero) {
        if (Objects.isNull(oneOrZero)) {
            return StrUtil.EMPTY;
        }
        if ("1".equals(oneOrZero)) {
            return "是";
        } else if ("0".equals(oneOrZero)) {
            return "否";
        } else {
            return StrUtil.EMPTY;
        }
    }
}
