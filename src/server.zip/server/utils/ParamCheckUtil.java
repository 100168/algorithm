package com.jiduauto.sps.server.utils;

import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.server.pojo.vo.req.baseData.SupplierPageSearch;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * 参数校验工具类
 *
 * @author HuangKun
 * @date 2022/10/19
 */
@Slf4j
public class ParamCheckUtil {


    /**
     * 级联参数验证
     * 规则 ：后面参数存在时，前面参数不能为null,可以全部为null
     * 举例 ：
     * 正确的 ：["1","2",null,null] , [null,null]
     * 错误的 ：["1",null,"2",null] , [null,"1"]
     *
     * @param list
     * @return boolean
     */
    public static boolean cascadeParam(Object... list) {
        if (list.length == 0) {
            return true;
        }

        //参数出现不为null时 为true
        boolean flag = false;

        //返回值
        boolean result = true;

        //从后往前遍历
        for (int i = list.length - 1; i >= 0; i--) {
            if (!Objects.isNull(list[i])) {
                //出现不为null的参数
                flag = true;
            } else if (flag) {
                //之前出现不为null的参数，但是后面还有为null的参数时
                result = false;
                break;
            }

        }

        return result;
    }

    /**
     * 验证手机号 由于号码段不断的更新，只需要判断手机号有11位，并且全是数字以及1开头
     *
     * @param phoneNumber 手机号码
     * @return
     */
    public static boolean matchPhoneNumber(String phoneNumber) {
        String regex = "^1\\d{10}$";
        if (phoneNumber == null || phoneNumber.length() == 0) {
            return false;
        }
        return Pattern.matches(regex, phoneNumber);
    }

    /**
     * 把对象里的空字符串设置为null
     * 用于查询时， 前端会对查询字段传值空字符串 表示 null
     * @param o
     */
    public static void resetEmptyToNull(Object o){
        Field[] fields = o.getClass().getDeclaredFields();
        for(Field field:fields){
            field.setAccessible(true);
           try{
               Object val = field.get(o);
               if(val != null &&  val instanceof String && StringUtils.isBlank(val.toString())){
                   field.set(o,null);
               }
           }catch (Exception e){
               log.error(e.getMessage(),e);
           }
        }
    }

    public static void main(String[] args) {
        SupplierPageSearch supplierPageSearch  = new SupplierPageSearch();
        supplierPageSearch.setSapCode("");
        supplierPageSearch.setSupplierName("dfd");
        System.out.println(JSON.toJSONString(supplierPageSearch));
        resetEmptyToNull(supplierPageSearch);
        System.out.println(JSON.toJSONString(supplierPageSearch));
    }
}
