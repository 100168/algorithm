package com.jiduauto.sps.server.utils;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import net.sf.cglib.beans.BeanCopier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Slf4j
public class BeanCopierUtil {

    private static Logger logger = LoggerFactory.getLogger(BeanCopierUtil.class);

    private final static ConcurrentMap<String, BeanCopier> CACHE_BEAN_COPIER = new ConcurrentHashMap<>();

    private static BeanCopier getBeanCopier(Object fromClazz, Object toClazz) {
        String key = genKey(fromClazz.getClass(), toClazz.getClass());
        BeanCopier beanCopier = CACHE_BEAN_COPIER.get(key);
        if (beanCopier == null) {
            beanCopier = BeanCopier.create(fromClazz.getClass(), toClazz.getClass(), false);
            CACHE_BEAN_COPIER.putIfAbsent(key, beanCopier);
        }
        return beanCopier;
    }

    public static <T> T copy(Object fromClazz, Class<T> classOfT) {

        if (null == fromClazz) {
            return null;
        }

        try {
            T t = classOfT.newInstance();
            BeanCopier beanCopier = getBeanCopier(fromClazz, t);
            beanCopier.copy(fromClazz, t, null);
            return t;
        } catch (Exception e) {
            e.printStackTrace();
            logger.warn("copy异常：{}", e.getMessage());
            return null;
        }
    }

    public static <T, E> List<T> copyList(List<E> fromClazzList, Class<T> classOfT) {

        if (CollectionUtils.isEmpty(fromClazzList)) {
            return null;
        }
        List<T> resultList = new ArrayList<>();
        for (E e : fromClazzList) {
            resultList.add(copy(e, classOfT));
        }
        return resultList;
    }

    /**
     * map通过反射转换成java bean
     */
    public static <T> T convert(Map<String, Object> map, Class<T> clazz) {
        try {
            T obj = clazz.newInstance();
            BeanInfo beanInfo = Introspector.getBeanInfo(clazz);
            PropertyDescriptor[] properties = beanInfo.getPropertyDescriptors();
            for (PropertyDescriptor prop : properties) {
                String key = prop.getName();
                if (map.containsKey(key) && map.get(key) != null) {
                    Object value = map.get(key);
                    Method setMethod = prop.getWriteMethod();
                    setMethod.invoke(obj, value);
                }
            }
            return obj;
        } catch (Exception e) {
            log.error("BeanCopierUtil.convert error", e);
        }
        return null;
    }

    public static <T> T copyByJson(Object fromClazz, Class<T> classOfT) {

        if (null == fromClazz) {
            return null;
        }

        try {
            String json = JSON.toJSONString(fromClazz);
            return JSON.parseObject(json, classOfT);
        } catch (Exception e) {
            e.printStackTrace();
            logger.warn("copyByJson异常：{}", e.getMessage());
            return null;
        }
    }

    public static <T, E> List<T> copyListByJson(List<E> fromClazzList, Class<T> classOfT) {

        if (CollectionUtils.isEmpty(fromClazzList)) {
            return null;
        }
        try {
            String json = JSON.toJSONString(fromClazzList);
            return JSON.parseArray(json, classOfT);
        } catch (Exception e) {
            e.printStackTrace();
            logger.warn("copyListByJson异常：{}", e.getMessage());
            return null;
        }
    }

    private static String genKey(Class<?> srcClazz, Class<?> destClazz) {
        return srcClazz.getName() + destClazz.getName();
    }


    public static void fillNullField(Object target, Object origin) {
        try {
            Field[] fields = target.getClass().getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true);
                Object val = field.get(target);
                if (val == null) {
                    field.set(target, field.get(origin));
                }
            }
        } catch (Exception e) {
            logger.error("", e);
        }
    }
}
