package com.jiduauto.sps.server.utils;

public class DataMaskingUtils {

    private final static String MASK = "*";

    /**
     * 对姓名进行脱敏处理，仅保留姓氏的第一个字，其他部分用"*"代替
     *
     * @param name 姓名
     * @return 脱敏后的姓名
     */
    public static String maskName(String name) {
        if (StringUtils.isEmpty(name)) {
            return name;
        }
        return name.charAt(0) + StringUtils.repeat(MASK, name.length() - 1);
    }

    /**
     * 对手机号进行脱敏处理，保留前三位和后四位，其他部分用"*"代替
     *
     * @param phoneNumber 手机号
     * @return 脱敏后的手机号
     */
    public static String maskPhoneNumber(String phoneNumber) {
        if (StringUtils.isEmpty(phoneNumber)) {
            return phoneNumber;
        }
        int length = phoneNumber.length();
        if (length <= 7) {
            return phoneNumber;
        }
        int maskLength = length - 7;
        return phoneNumber.substring(0, 3) +
                StringUtils.repeat(MASK, maskLength) +
                phoneNumber.substring(length - 4, length);
    }

    /**
     * 对地址进行脱敏处理，保留前三个字符和最后一个字符，其他部分用"*"代替
     *
     * @param address 地址
     * @return 脱敏后的地址
     */
    public static String maskAddress(String address) {
        if (StringUtils.isEmpty(address)) {
            return address;
        }
        return StringUtils.repeat(MASK, address.length());
    }

    public static void main(String[] args) {
        String name = "张三11";
        String maskedName = DataMaskingUtils.maskName(name);
        System.out.println("脱敏后的姓名：" + maskedName);

        String phoneNumber = "13812345678";
        String maskedPhoneNumber = DataMaskingUtils.maskPhoneNumber(phoneNumber);
        System.out.println("脱敏后的手机号：" + maskedPhoneNumber);

        String address = "北京市朝阳区XXX街道123号";
        String maskedAddress = DataMaskingUtils.maskAddress(address);
        System.out.println("脱敏后的地址：" + maskedAddress);
    }
}

