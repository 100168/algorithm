package com.jiduauto.sps.server.utils;

import com.alibaba.excel.annotation.ExcelProperty;
import com.jiduauto.sps.server.exception.BizException;

import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * @author tao.wang
 * @date 2022/12/19
 * @description
 */
public class ExcelUtils {


    /**
     * 获取excel 表头
     *
     * @param tclass
     * @return
     */
    public static List<String> headList(Class tclass) {
        List<String> headList = new ArrayList<>();
        Field[] fields = tclass.getDeclaredFields();
        for (Field field : fields) {
            try {
                boolean annotationPresent = field.isAnnotationPresent(ExcelProperty.class);
                if (annotationPresent) {
                    ExcelProperty excelProperty = field.getAnnotation(ExcelProperty.class);
                    String head = excelProperty.value()[0];
                    headList.add(head);
                }
            } catch (Exception e) {
                throw new BizException("getHeadList-err");
            }
        }
        return headList;
    }

    public static void exportXlsxResponse(HttpServletResponse response, String fileName) throws UnsupportedEncodingException {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");
        response.setHeader("Content-disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20") + ".xlsx");
    }
}
