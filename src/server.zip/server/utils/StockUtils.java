package com.jiduauto.sps.server.utils;

import cn.hutool.json.JSONUtil;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.dto.param.UpdateStockParam;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import com.jiduauto.sps.server.pojo.po.StockPo;
import com.jiduauto.sps.server.pojo.vo.req.UpdateStockRequest;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * 库存公共方法
 */
@Slf4j
public class StockUtils {

    public static void main(String[] args) {
//        List<String> list = Arrays.asList("12b7c362855d408406e11d751de68d52","19975f2a5c0ac06b1c67015e763691e1","1e46951d32c4d59061e1f96e40f555ce","2406b94006a5057bd0f5870942a597c6","279caab73475f6a470ece16fe30a5559","308bd45de149c14ba39554fa666f2d71","30de05908a53680a04a9a245b561aec6","329b6225e5ac5921a86369e03315287e","332635b68c4eed882c5a756cd1db0a8f","397b37e29cd3d6e7e9c17dec460c2ad5","3a944a6db732eac30b615bb9b9f71cf6","3c0f5510dcbc376a310cc8fda1242ecb","3f18dd0b37c73ab7795867253dcb7c4f","41e9e78013827e245b44c170d10a8f1e","42aedbef47de64169c20b8118049351f","4544c31fc96e2d1b170e802c2dd004de","476358e8ddb09c339d3b9be68a70578a","4f40c3ac21a5ec7bde481da61967772f","52e9ce1640ed6b201fdc41cc30455af3","55d33a7bc0e6b6449edd4170da0ba1a3","564690468d390fdea921789241b404a0","5898295d8a783c2ab01bf114ab3cfa91","699c44044085b70f606f380bbf07498d","6d0263812816d0e93a67f6890811aea6","7df39478edbd157c8c231894018980ce","815b8ca275e7127fa255e327f6a7f192","8685f1207cb9ae1603a02cc0ea24bea1","88baea373e0fff6c9608d7306de5fe91","8c3cfe6745f7132fa09baac93f981ff1","8d15d46ffcbfc0c1c44bf7b2177b3b23","958ee20e1c646eff562e4f94f0be90d0","97ee016ebecab4cf5a3eb96ec4e30e38","9b80e542317c7300a5a0da8694426c68","a0cd2927fee4b89e87168f136b28c6c8","a36ac4cc20957ef3c77364a51b6c1b25","a3dcbd783fc0dcfa82c8404d1f59221f","a7aba7107c81be8df8e42c8096f178fb","a8baadf05764db00f0715d2b79ee6b3e","ab796ab21421b9ef91bae1aaa37dc886","bbe1faf2abd6817543dad20f325a4bd6","bbeef0aa97d42cc74c365c47a0d9975e","bc223b6eb3b273fefe021e13790284b1","c147c67ba792b6c58d13839cb5ba2f2c","c24f824b3ace9d8b29beef495fb8df27","ca9748c6628753931e02ad1f15b68814","ccedc2379183984e33603549d67f542a","cdec751611535321121658281dbaea8a","d2301d5201c425fefb4e07ac20d368c1","d2610debaf11bf23fe55fdb2b5a87ff4","d2770e1a42365c5670110d50836f1628","d3aa882fae93ec114da24a30a3b7cd17","d9f66cca6284fda7acd8f89b5ae27816","da0bee0034e4dc7bd3358e27ba18dd5e","ddcbe6c01eb3ad96057abf14879cc3b6","e3f4c8db305b76144ef0603e9f834232","e5a1336788749310739d720fe865ee39","e6b9554f7ba81c3acca47b99d3ce66a4","f6b624d924a23d4209803033c13dbc86","fb1a9a7b148554d9282e9e33f87b1f85");
//        JSONArray array = JSON.parseArray("[{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000041\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"TWC-502RMB\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000042\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"KWB-412\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000043\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"98103\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000044\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"62701\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000045\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"2000*600*2000mm\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000046\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"TLT440W\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000047\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"TLT240SCA\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000048\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"X-831E\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000049\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"GSA12V-Li\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"12000050\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"HLG-60H-24\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000052\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"70843\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A34-01-01\",\"materialCode\":\"12000053\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"优质国产\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000054\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"GSB185-LI\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000055\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"91502\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000056\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"GLM150C\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000058\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"S-400-12\",\"stockStatus\":1,\"sumQuantity\":6.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000059\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"PTi120\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000061\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"0-300mm\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"12000063\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"17B+\",\"stockStatus\":1,\"sumQuantity\":6.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000067\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"96312\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"12000068\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"02002A\",\"stockStatus\":1,\"sumQuantity\":3.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000069\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"zx32\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000070\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"Form3\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000071\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"9935\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000072\",\"materialSort\":\"1\",\"materialStatus\":1,\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000009\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"93452/3\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"14000010\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"2.5*150\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000011\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"3911\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000012\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"3919\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"14000013\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"4.6*300\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000073\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"90621+90723\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000014\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"48mm长20y\",\"stockStatus\":1,\"sumQuantity\":10.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000015\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"91202\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000016\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"70631\",\"stockStatus\":1,\"sumQuantity\":3.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000017\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"70632\",\"stockStatus\":1,\"sumQuantity\":3.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A13-03-04\",\"materialCode\":\"12000074\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"GN-804D\",\"stockStatus\":1,\"sumQuantity\":3.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000075\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"GN-C5\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"14000018\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"9314\",\"stockStatus\":1,\"sumQuantity\":3.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000076\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"9342\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000078\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"91112\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"12000079\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"3902\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"14000019\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"18mm*1000mm\",\"stockStatus\":1,\"sumQuantity\":20.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000020\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"90790\",\"stockStatus\":1,\"sumQuantity\":5.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000022\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"GN-C5\",\"stockStatus\":1,\"sumQuantity\":8.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000081\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"JTCGK2019\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-01\",\"materialCode\":\"12000082\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"GSB 600 RE\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000021\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\" 94166-00\",\"stockStatus\":1,\"sumQuantity\":6.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-04\",\"materialCode\":\"14000023\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"DB9\",\"stockStatus\":1,\"sumQuantity\":20.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-04\",\"materialCode\":\"14000024\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"DB9\",\"stockStatus\":1,\"sumQuantity\":20.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000025\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"11924\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000200\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"XH0849\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000083\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"91127\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000084\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"GWS 720\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000085\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"302+\",\"stockStatus\":1,\"sumQuantity\":4.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"12000086\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"50451\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000087\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"GLL3-80\",\"stockStatus\":1,\"sumQuantity\":1.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-01\",\"materialCode\":\"12000088\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"Bosch GO 2\",\"stockStatus\":1,\"sumQuantity\":9.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"12000089\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"09002\",\"stockStatus\":1,\"sumQuantity\":6.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-01\",\"materialCode\":\"12000090\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"DCP J12 E\",\"stockStatus\":1,\"sumQuantity\":2.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"A21-04-03\",\"materialCode\":\"14000027\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"90313\",\"stockStatus\":1,\"sumQuantity\":3.000,\"warehouseCode\":\"YZ02\"},{\"areaCode\":\"NR01\",\"locationCode\":\"B01-01-01\",\"materialCode\":\"14000028\",\"materialSort\":\"1\",\"materialStatus\":1,\"sequenceNo\":\"0.35mm*100M\",\"stockStatus\":1,\"sumQuantity\":5.000,\"warehouseCode\":\"YZ02\"}]");
//        for(int i =0; i < array.size(); i++){
//            InAndOutStockParam param = JSON.parseObject(array.getString(i),InAndOutStockParam.class);
////            System.out.println(getStockKeyByParam("materialCode,materialStatus,stockStatus,projectCode,stageCode,purchaseOrderNo,warehouseCode,areaCode,locationCode,sequenceNo,samplePartStatus", "JADT", param));
//            String key = getStockKeyByParam("materialCode,materialStatus,stockStatus,projectCode,stageCode,purchaseOrderNo,warehouseCode,areaCode,locationCode,sequenceNo,samplePartStatus", "JADT", param);
//            if(!list.contains(key)){
//                System.out.println(param.getMaterialCode());
//            }
//        }

        //item  c619dd80a97cb15f3fc1a7829d9e13a3
        //item  fad8f65dd5a5e7244f6a59127c8951ff

        cn.hutool.json.JSON json = JSONUtil.readJSON(new File("/Users/panjian/Library/Application Support/JetBrains/IntelliJIdea2024.2/scratches/case.json"), StandardCharsets.UTF_8);

        UpdateStockRequest bean = json.toBean(UpdateStockRequest.class);
        List<UpdateStockParam> cancelParams = bean.getCancelParams();
        for (UpdateStockParam param : cancelParams) {
            InAndOutStockParam stockParam = BeanCopierUtil.copy(param,InAndOutStockParam.class);
            String key2 = getStockKeyByParam("materialCode,materialStatus,batchNo,expireDate,stockStatus,supplierCode,purchaseOrderNo,warehouseCode,sequenceNo", "ES", stockParam);
            String key1 = getStockKeyByParam("materialCode,materialStatus,stockStatus,warehouseCode", "ES", stockParam);
            System.out.println(key2);
            System.out.println(key1);
        }


    }

    /**
     * 解析配置的字段 唯一键值
     * 如果选中了某个字段，但是参数里为空， 那么就按""空字符串处理。
     *
     * @return
     */
    public static String getStockKeyByParam(String field, String bizType, InAndOutStockParam request) {
        return MD5Util.encodeString(getKeyValue(field,bizType,request));
    }

    /**
     * MD5 转码 明文key
     * @param key
     * @return
     */
    public static String getStockKeyByKey(String key) {
        return MD5Util.encodeString(key);
    }

    public static String  getKeyValue(String field, String bizType, InAndOutStockParam request){
        if (StringUtils.isBlank(field)) {
            return null;
        }
        String[] fields = field.split(",");
        Field[] obejctFields = getAllFields(InAndOutStockParam.class);
        Map<String, String> map = new HashMap<>();
        map.put("bizType", bizType);
        for (Field f : obejctFields) {
            try {
                f.setAccessible(true);
                Object o = f.get(request);
                if (o == null) {
                    map.put(f.getName(), "");
                } else {
                    map.put(f.getName(), o.toString());
                }
            } catch (Exception e) {
                log.error("拼接库存唯一字段组合值异常", e);
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(bizType);
        for (String name : fields) {
            sb.append(map.get(name));
        }
        return sb.toString();
    }

    /**
     * 解析配置的字段 唯一键值
     * 如果选中了某个字段，但是参数里为空， 那么就按""空字符串处理。
     *
     * @return
     */
    public static StockPo initFieldStock(String key, String field, String bizType, InAndOutStockParam request, StockPo
            stockPo) {

        String[] fields = field.split(",");
        Class<?> paramClass = request.getClass();
        Class<?> stockClass = stockPo.getClass();
        try {
            for (String name : fields) {
                Method me = paramClass.getDeclaredMethod("get" + StringUtils.firstUpperCase(name));
                Object value = me.invoke(request);
                if (value == null || name.equals("addDate") || name.equals("productDate") || name.equals("expireDate")) {
                    continue;
                }
                Field fieldTemp = stockClass.getDeclaredField(name);
                fieldTemp.setAccessible(true);
                fieldTemp.set(stockPo, value);
                fieldTemp.setAccessible(false);
            }
        } catch (Exception e) {
            log.error("入库类型转换异常", e);
            throw new BizException(-1, "入库类型转换异常");
        }
        stockPo.setBizConfigField(key);
        return stockPo;
    }

    /**
     * 解析配置的字段 唯一键值
     * 如果选中了某个字段，但是参数里为空， 那么就按""空字符串处理。
     *
     * @return
     */
    public static StockItemPo initFieldStockItem(String key, String field, String bizType, InAndOutStockParam
            request, StockItemPo stockPo) {

        String[] fields = field.split(",");
        Class<?> paramClass = request.getClass();
        Class<?> stockClass = stockPo.getClass();
        try {
            for (String name : fields) {
                Method me = paramClass.getDeclaredMethod("get" + StringUtils.firstUpperCase(name));
                Object value = me.invoke(request);
                if (value == null || name.equals("addDate") || name.equals("productDate") || name.equals("expireDate")) {
                    continue;
                }
                Field fieldTemp = stockClass.getDeclaredField(name);
                fieldTemp.setAccessible(true);
                fieldTemp.set(stockPo, value);
                fieldTemp.setAccessible(false);
            }
        } catch (Exception e) {
            log.error("入库类型转换异常", e);
            throw new BizException(-1, "入库类型转换异常");
        }
        stockPo.setBizConfigField(key);
        return stockPo;
    }

    /**
     * 获取 库存明细 转换为  库存
     * @param field
     * @param stockItemPo
     * @return
     */
    public static StockPo convertStockItemToStock(String field,StockItemPo stockItemPo) {
        String[] fields = field.split(",");
        StockPo stockPo = new StockPo();
        Class<?> paramClass = stockItemPo.getClass();
        Class<?> stockClass = stockPo.getClass();
        StringBuilder sb = new StringBuilder();
        sb.append(stockItemPo.getBizType());
        try {
            for (String name : fields) {
                Method me = paramClass.getDeclaredMethod("get" + StringUtils.firstUpperCase(name));
                Object value = me.invoke(stockItemPo);
                if (value == null || name.equals("addDate") || name.equals("productDate") || name.equals("expireDate")) {
                    continue;
                }
                sb.append(value);
                Field fieldTemp = stockClass.getDeclaredField(name);
                fieldTemp.setAccessible(true);
                fieldTemp.set(stockPo, value);
                fieldTemp.setAccessible(false);
            }
        } catch (Exception e) {
            log.error("入库类型转换异常", e);
            throw new BizException(-1, "入库类型转换异常");
        }
        stockPo.setBizConfigField(getStockKeyByKey(sb.toString()));
        stockPo.setSumQuantity(stockItemPo.getSumQuantity());
        stockPo.setBizType(stockItemPo.getBizType());
        return stockPo;
    }

    /**
     * 获取本类及其父类的属性的方法
     *
     * @param clazz 当前类对象
     * @return 字段数组
     */
    private static Field[] getAllFields(Class<?> clazz) {
        List<Field> fieldList = new ArrayList<>();
        while (clazz != null) {
            fieldList.addAll(new ArrayList<>(Arrays.asList(clazz.getDeclaredFields())));
            clazz = clazz.getSuperclass();
        }
        Field[] fields = new Field[fieldList.size()];
        return fieldList.toArray(fields);
    }
}
