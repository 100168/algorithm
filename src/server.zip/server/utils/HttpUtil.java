/**
 * ymm56.com Inc.
 * Copyright (c) 2013-2018 All Rights Reserved.
 */
package com.jiduauto.sps.server.utils;

import com.jiduauto.sps.server.pojo.http.HttpBaseResponse;
import com.jiduauto.sps.server.pojo.http.HttpConfig;
import com.jiduauto.sps.server.pojo.http.HttpResponseStatus;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;

import javax.net.ssl.*;
import java.io.UnsupportedEncodingException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;

/**
 *
 * @author he.huang
 * @version $Id: HttpUtil.java, v 0.1 2018-06-20 16:05 he.huang Exp $$
 */
@Slf4j
public class HttpUtil {
    public static final String CONTENT_TYPE_JSON = "application/json";

    public static final String PARAM_START_CHAR = "?";
    public static final String PARAM_SEPARATOR = "&";
    public static final String PARAM_CONNECTOR = "=";
    private static Object lock = new Object();
    private static SSLSocketFactory createSSLSocketFactory(){
        SSLSocketFactory sslSocketFactory = null;
        try{
            SSLContext sc  = SSLContext.getInstance("TLS");
            sc.init(null,  new TrustManager[]{new TrustAllManager()}, new SecureRandom());
            sslSocketFactory = sc.getSocketFactory();
        }catch (Exception e){
            log.error(e.getMessage(),e);
        }
        return sslSocketFactory;
    }

    private static class TrustAllManager implements X509TrustManager{
        @Override
        public void checkClientTrusted(X509Certificate[] var1, String var2) throws CertificateException{

        }
        @Override
        public void checkServerTrusted(X509Certificate[] var1, String var2) throws CertificateException{

        }

        @Override
        public X509Certificate[] getAcceptedIssuers(){
            return new X509Certificate[0];
        }
    }

    private static class TrustAllHotNameVerifier implements HostnameVerifier {
        @Override
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }
    private static OkHttpClient okHttpClient = null;
    public static OkHttpClient getInstance(){
        if(okHttpClient != null){
            return okHttpClient;
        }
        synchronized (lock){
            if(okHttpClient != null){
                return okHttpClient;
            }
            okHttpClient = new OkHttpClient.Builder()
//                    .connectTimeout(3, TimeUnit.SECONDS)
//                    .readTimeout(3, TimeUnit.SECONDS)
//                    .writeTimeout(3, TimeUnit.SECONDS)
                    .sslSocketFactory(createSSLSocketFactory(), new TrustAllManager())
                    .hostnameVerifier(new TrustAllHotNameVerifier()).build();
            return okHttpClient;
        }
    }

    public static HttpBaseResponse doGet(String url, Map<String, Object> params){

        try{
            Request request = new Request.Builder()
                    .url(packageUrl(url,params))
                    .get().build();
            Response response = getInstance().newCall(request).execute();
            if(response.isSuccessful()){
                return new HttpBaseResponse(HttpResponseStatus.SUCCESS,null, response.body().string());
            }else{
                return new HttpBaseResponse(HttpResponseStatus.FAILED,null, response.body().string());
            }

        }catch(SocketTimeoutException ste){
            //timeout
            log.warn(ste.getMessage(),ste);
        }catch (SocketException se){
            log.warn(se.getMessage(),se);
        }catch (Exception e){
            log.error(e.getMessage(),e);
        }
        return new HttpBaseResponse(HttpResponseStatus.UNCONFIRM_RESPONSE,null, null);
    }

    private static String packageUrl(String url, Map<String, Object> params) throws Exception{
        if (params == null || params.isEmpty()) {
            return url;
        }

        StringBuilder result = new StringBuilder(url);

        if (result.indexOf(PARAM_START_CHAR) < 0) {
            result.append(PARAM_START_CHAR);
        }

        if (result.indexOf(PARAM_SEPARATOR) >= 0 || result.indexOf(PARAM_CONNECTOR) >= 0) {
            result.append(PARAM_SEPARATOR);
        }

        for (Map.Entry<String, Object> entry : params.entrySet()) {
            result.append(entry.getKey()).append(PARAM_CONNECTOR).append(httpEncode(entry.getValue().toString())).append(PARAM_SEPARATOR);
        }
        result.deleteCharAt(result.length() - 1);

        return result.toString();
    }

    public static HttpBaseResponse doPost(String url, HttpConfig config) {
        try {
            RequestBody body = buildPostBody(config);
            Request request = new Request.Builder()
                    .url(url).post(body)
                    .build();
            Response response = getInstance().newCall(request).execute();
            if (response.isSuccessful()) {
                return new HttpBaseResponse(HttpResponseStatus.SUCCESS, null, response.body().string());
            } else {
                return new HttpBaseResponse(HttpResponseStatus.FAILED, null, response.body().string());
            }
        } catch (SocketException se) {
            log.warn(se.getMessage(), se);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return new HttpBaseResponse(HttpResponseStatus.UNCONFIRM_RESPONSE, null, null);
    }

    public static HttpBaseResponse doPost(String url, HttpConfig config, Map<String,String> headers) {
        String errorMsg = "";
        try {
            log.info(String.format("http请求:url:%s requestBody:%s",url,config.getJsonParam()));
            RequestBody body = buildPostBody(config);
            Request request = new Request.Builder()
                    .url(url).post(body).headers(setHeaderParams(headers))
                    .build();
            Response response = getInstance().newCall(request).execute();
            String resultResponse = response.body().string();
            log.info(String.format("http请求:url:%s requestBody:%s  response:%s",url,config.getJsonParam(), resultResponse));
            if (response.isSuccessful()) {
                return new HttpBaseResponse(HttpResponseStatus.SUCCESS, null, resultResponse);
            } else {
                return new HttpBaseResponse(HttpResponseStatus.FAILED, null, resultResponse);
            }
        } catch (SocketException se) {
            errorMsg = se.getMessage();
            log.warn(se.getMessage(), se);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            errorMsg = e.getMessage();
        }
        return new HttpBaseResponse(HttpResponseStatus.UNCONFIRM_RESPONSE, null,url+":"+ errorMsg);
    }

    public static HttpBaseResponse doPost(String url, String jsonParam) {
        try {
            RequestBody body = RequestBody.create(MediaType.parse("application/json"), jsonParam);
            Request request = new Request.Builder()
                    .url(url).post(body)
                    .build();
            Response response = getInstance().newCall(request).execute();
            if (response.isSuccessful()) {
                return new HttpBaseResponse(HttpResponseStatus.SUCCESS, null, response.body().string());
            } else {
                return new HttpBaseResponse(HttpResponseStatus.FAILED, null, response.body().string());
            }
        } catch (SocketException se) {
            log.warn(se.getMessage(), se);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return new HttpBaseResponse(HttpResponseStatus.UNCONFIRM_RESPONSE, null, null);
    }

    /**
     * @param config httpConfig
     * @return post请求
     */
    private static RequestBody buildPostBody(HttpConfig config) {
        MediaType mediaType = null;
        if (StringUtils.isNotEmpty(config.getContentType())) {
            mediaType = MediaType.parse(config.getContentType());
        }
        if(StringUtils.isBlank(config.getJsonParam())){
            config.setJsonParam("{}");
        }
        return RequestBody.create(mediaType, config.getJsonParam());
    }

    public static String httpEncode(String httpUrl) throws UnsupportedEncodingException {
        return URLEncoder.encode(httpUrl, "UTF-8");
    }

    /**
     * 添加headers
     *
     * @param headerParams
     * @return
     */
    private static Headers setHeaderParams(Map<String, String> headerParams) {
        Headers headers = null;
        Headers.Builder headersbuilder = new Headers.Builder();
        if (headerParams != null && headerParams.size() > 0) {
            for (String key : headerParams.keySet()) {
                if (StringUtils.isNotBlank(key) && StringUtils.isNotBlank(headerParams.get(key))) {
                    //如果参数不是null并且不是""，就拼接起来
                    headersbuilder.add(key, headerParams.get(key));
                }
            }
        }

        headers = headersbuilder.build();
        return headers;
    }
}
