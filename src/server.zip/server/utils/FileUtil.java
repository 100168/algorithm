package com.jiduauto.sps.server.utils;

import cn.hutool.core.io.IoUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilterOutputStream;
import java.io.InputStream;

@Slf4j
public class FileUtil {
    private static final String FILE_PATH = "/app/temp/%s%s";

    public static final String SUFFIX = ".xlsx";

    static {
        File file = new File(FILE_PATH);
        if(file.exists()){
            file.mkdirs();
        }
    }

    public static void main(String[] args) {
        try{
            FileInputStream fileInputStream = new FileInputStream(new File(String.format(FILE_PATH,"64142a85e4b04d168f53bb4b_失败原因",SUFFIX)));
            String fileName = String.valueOf(System.currentTimeMillis());
            saveFileToLocal(fileInputStream, fileName,SUFFIX);
            deleteTempFile(fileName,SUFFIX);
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public static File saveFileToLocal(InputStream source, String fileName,String suffix){
        File file = new File(String.format(FILE_PATH,fileName,suffix));
        try {
            FileUtils.copyInputStreamToFile(source,file);
            return file;
        }catch (Exception e){
            log.error("保存文件异常",e);
            return null;
        }
    }

    public static void deleteTempFile(String fileName, String suffix){
       try{
           FileUtils.forceDelete(new File(String.format(FILE_PATH,fileName,suffix)));
       }catch (Exception e){
           log.error("删除零食文件异常",e);
       }
    }
}
