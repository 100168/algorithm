package com.jiduauto.sps.server.utils;

/**
 * @author panjian
 */
public class VirtualWarehouseUtil {


    final static String PREFIX = "V_";

    /**
     * 获取虚拟仓库代码
     *
     * @param warehouseCode warehouseCode
     * @return VirtualWarehouse
     */
    public static String getVirtualWarehouse(String warehouseCode) {
        return PREFIX + warehouseCode;
    }

    public static String getDefaultVirtualWarehouse() {
        return PREFIX + "G59";
    }

}
