package com.jiduauto.sps.server.utils;


import java.util.*;

/**
 * 集合工具类
 */
public class CollectionUtils {


    public static boolean isEmpty(Collection<?> collection) {
        return (collection == null || collection.isEmpty());
    }


    public static boolean isEmpty(Map collection) {
        return (collection == null || collection.isEmpty());
    }

    /**
     * 集合空判断
     * @param collection
     * @return
     */
    public static boolean isNotEmpty(Collection<?> collection) {
        return !(collection == null || collection.isEmpty());
    }

    /**
     * 集合最大的个数校验
     * @param collection
     * @param maxSize
     * @return
     */
    public static boolean maxSize(Collection<?> collection, int maxSize){
        if(isNotEmpty(collection) && collection.size() <= maxSize){
            return true;
        }else{
            return false;
        }
    }

    /**
     * String集合过滤null 0
     * @param ids
     * @return
     */
    public static List<String> removeZeroString(List<String> ids){
        Iterator<String> iterator = ids.iterator();
        while(iterator.hasNext()){
            String id = iterator.next();
            if(StringUtils.isBlank(id) || "0".equals(id)){
                iterator.remove();
            }
        }
        return ids;
    }

    /**
     * long集合过滤null 0
     * @param ids
     * @return
     */
    public static List<Long> removeZeroLong(List<Long> ids){
        Iterator<Long> iterator = ids.iterator();
        while(iterator.hasNext()){
            Long id = iterator.next();
            if(!longGreaterThanZero(id)){
                iterator.remove();
            }
        }
        return ids;
    }


    public static List<Long> listrem(List<Long> listA,List<Long> listB){
        HashSet hs1 = new HashSet(listA);
        HashSet hs2 = new HashSet(listB);
        hs1.removeAll(hs2);
        List<Long> listC = new ArrayList<Long>();
        listC.addAll(hs1);
        return listC;
    }


    /**
     * long 型 大于0
     * @param value
     * @return
     */
    public static boolean longGreaterThanZero(Long value){
        if(value != null && value >0){
            return true;
        }
        return false;
    }
}
