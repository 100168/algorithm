package com.jiduauto.sps.server.utils;

import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;

@Component
@Slf4j
public class OnlineDutyUtil {

    @Value("${sps.online.duty.mobile}")
    private String dutyUsers;

    @Autowired
    private RedisUtil redisUtil;

    public String  getMobile()  {
        Object indexObj = redisUtil.get(BaseConstants.RedisKey.ONLINE_DUTY_USER_INDEX);
        Integer index = 0;
        if(indexObj == null){
            index = 0;
            redisUtil.set(BaseConstants.RedisKey.ONLINE_DUTY_USER_INDEX,index.toString());
        }else{
            index = Integer.valueOf(indexObj.toString());
        }

        if(StringUtils.isNotBlank(dutyUsers)){
            List<String> mobiles = JSON.parseArray(dutyUsers,String.class);
            LocalDateTime now = LocalDateTime.now();
            if(now.getDayOfWeek() == DayOfWeek.MONDAY){
                index++;
                if(index == mobiles.size()){
                    index = 0;
                }
                redisUtil.set(BaseConstants.RedisKey.ONLINE_DUTY_USER_INDEX,index.toString());
            }
            return mobiles.get(index);
        }

        return "";
    }
}
