package com.jiduauto.sps.server.utils;

import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.http.HttpBaseResponse;
import com.jiduauto.sps.server.pojo.http.HttpConfig;
import lombok.extern.slf4j.Slf4j;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * http basic auth 工具类
 */
@Slf4j
public class HttpBasicAuthUtil {

    public static  HttpBaseResponse invoke(Object request, String userName, String password, String url){
        return invoke(JSON.toJSONString(request), userName, password,url);
    }

    public static  HttpBaseResponse invoke(String json , String userName, String password, String url){
        HttpConfig httpConfig = new HttpConfig();
        httpConfig.setContentType(HttpUtil.CONTENT_TYPE_JSON);
        httpConfig.setJsonParam(json);

        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Basic " + Base64.getUrlEncoder().encodeToString((userName+":"+password).getBytes()));
        try{
           return  HttpUtil.doPost(url, httpConfig,headers);
        }catch (Exception e){
            log.error("Http请求失败:"+url,e);
            throw new BizException(-1,url+"下游依赖接口访问异常");
        }
    }
}
