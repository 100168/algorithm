package com.jiduauto.sps.server.utils;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.util.StrUtil;
import com.jiduauto.isc.sdk.keyuse.AESLibUtil;
import com.jiduauto.isc.sdk.keyuse.CipherMode;
import com.jiduauto.isc.sdk.keyuse.IvUtil;
import com.jiduauto.sps.server.pojo.po.WarehouseDistributeLogisticPo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AESUtil {

    @Value("${encode.key}")
    private String key;

    public static void main(String[] args) {

//        String data = Base64.encode("待加密数据");
//        String iv = IvUtil.getIvStr(12);
//        System.out.println("向量：" + iv);
//        String encryptStr = AESLibUtil.encrypt(CipherMode.GCM, key, iv, "", data);
//        System.out.println("密文：" + encryptStr);
        String decryptStr = AESLibUtil.decrypt(CipherMode.GCM, "WXVVRnQ0Q0EqtvT052fuWZV75CceFhKEa6nZ9cLE+7fDye+7ZJdlKuCN8IViUy/o+1rWDcg=EulENqjXhIeg==", "zjpGIxD2WzT0i7AP", "", "02IQbrVGB5AMgAApM22gbETSpGBk08LQDg==");
        System.out.println("明文Base64：" + decryptStr);
        System.out.println("明文：" + Base64.decodeStr(decryptStr));
    }

    public void encode(WarehouseDistributeLogisticPo warehouseDistributeLogisticPo) {
        String encodeShipper = Base64.encode(warehouseDistributeLogisticPo.getShipper());
        String encodeShipperContact = Base64.encode(warehouseDistributeLogisticPo.getShipperContact());
        String encodeDeliverAddress = Base64.encode(warehouseDistributeLogisticPo.getDeliverAddress());
        String encodeReceiver = Base64.encode(warehouseDistributeLogisticPo.getReceiver());
        String encodeReceiverContact = Base64.encode(warehouseDistributeLogisticPo.getReceiverContact());
        String encodeReceiveAddress = Base64.encode(warehouseDistributeLogisticPo.getReceiveAddress());
        String iv = IvUtil.getIvStr(12);
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getShipper())) {
            warehouseDistributeLogisticPo.setShipper(AESLibUtil.encrypt(CipherMode.GCM, key, iv, "", encodeShipper));        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getShipperContact())) {
            warehouseDistributeLogisticPo.setShipperContact(AESLibUtil.encrypt(CipherMode.GCM, key, iv, "", encodeShipperContact));
        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getDeliverAddress())) {
            warehouseDistributeLogisticPo.setDeliverAddress(AESLibUtil.encrypt(CipherMode.GCM, key, iv, "", encodeDeliverAddress));
        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getReceiver())){
            warehouseDistributeLogisticPo.setReceiver(AESLibUtil.encrypt(CipherMode.GCM, key, iv, "", encodeReceiver));
        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getReceiverContact())){
            warehouseDistributeLogisticPo.setReceiverContact(AESLibUtil.encrypt(CipherMode.GCM, key, iv, "", encodeReceiverContact));
        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getReceiveAddress())){
            warehouseDistributeLogisticPo.setReceiveAddress(AESLibUtil.encrypt(CipherMode.GCM, key, iv, "", encodeReceiveAddress));
        }


        warehouseDistributeLogisticPo.setIv(iv);
    }

    public void decode(WarehouseDistributeLogisticPo warehouseDistributeLogisticPo) {
        String iv = warehouseDistributeLogisticPo.getIv();
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getShipper())) {
            warehouseDistributeLogisticPo.setShipper(Base64.decodeStr(AESLibUtil.decrypt(CipherMode.GCM, key, iv, "", warehouseDistributeLogisticPo.getShipper())));
        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getShipperContact())) {
            warehouseDistributeLogisticPo.setShipperContact(Base64.decodeStr(AESLibUtil.decrypt(CipherMode.GCM, key, iv, "", warehouseDistributeLogisticPo.getShipperContact())));
        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getDeliverAddress())) {
            warehouseDistributeLogisticPo.setDeliverAddress(Base64.decodeStr(AESLibUtil.decrypt(CipherMode.GCM, key, iv, "", warehouseDistributeLogisticPo.getDeliverAddress())));
        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getReceiver())){
            warehouseDistributeLogisticPo.setReceiver(Base64.decodeStr(AESLibUtil.decrypt(CipherMode.GCM, key, iv, "", warehouseDistributeLogisticPo.getReceiver())));
        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getReceiverContact())){
            warehouseDistributeLogisticPo.setReceiverContact(Base64.decodeStr(AESLibUtil.decrypt(CipherMode.GCM, key, iv, "", warehouseDistributeLogisticPo.getReceiverContact())));
        }
        if (StrUtil.isNotEmpty(warehouseDistributeLogisticPo.getReceiveAddress())){
            warehouseDistributeLogisticPo.setReceiveAddress(Base64.decodeStr(AESLibUtil.decrypt(CipherMode.GCM, key, iv, "", warehouseDistributeLogisticPo.getReceiveAddress())));
        }
    }
}
