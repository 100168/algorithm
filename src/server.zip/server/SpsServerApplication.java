package com.jiduauto.sps.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * @author zhaojl
 */
@SpringBootApplication
@EnableFeignClients(basePackages = {"com.jiduauto.sps.server", "com.jiduauto.track", "com.jiduauto.spare", "com.jiduauto.tms", "com.jiduauto.sps.sdk.client"})
@EnableDiscoveryClient(autoRegister = false)
@EnableAsync
@EnableRetry
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ServletComponentScan
public class SpsServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpsServerApplication.class, args);
    }

}
