package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.po.DhlStockItemPo;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface DhlStockItemMapper extends BaseMapper<DhlStockItemPo> {

    /**
     * 批量插入
     *
     * @param dhlStockItemPos
     * @return
     */
    int batchInsert(@Param("list") List<DhlStockItemPo> dhlStockItemPos);


    /**
     * 根据库存时间删除过期数据
     *
     * @param minCreateTime
     */
    void deleteExpireData(@Param("minCreateTime") LocalDateTime minCreateTime);
}