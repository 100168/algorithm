package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.StockOperationHistoryPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 出入库库存操作记录 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-07-31
 */
@Mapper
public interface StockOperationHistoryMapper extends BaseMapper<StockOperationHistoryPo> {

    /**
     * 查询失败记录 按时间区间
     * @param endTime
     * @param startTime
     * @return
     */
    List<StockOperationHistoryPo> getErrorList(@Param("endTime") Long endTime, @Param("startTime") Long startTime);
}
