package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.sdk.pojo.dto.CarBomItemDto;
import com.jiduauto.sps.sdk.pojo.po.CarBomItemPo;
import com.jiduauto.sps.server.pojo.vo.req.CarBomItemPageReq;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 车辆BOM零件信息明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-04-02
 */
public interface CarBomItemMapper extends BaseMapper<CarBomItemPo> {

    List<CarBomItemDto> queryEffectiveCarBomItem(@Param("param")CarBomItemPageReq param);

    IPage<CarBomItemDto> queryEffectiveCarBomItemPageSearch(IPage<CarBomItemDto> page, CarBomItemPageReq param);
}
