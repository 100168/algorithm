package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.baseData.FrameContractDto;
import com.jiduauto.sps.server.pojo.dto.param.MaterialSearchParam;
import com.jiduauto.sps.server.pojo.fileexport.FrameContractExportDto;
import com.jiduauto.sps.server.pojo.po.FrameContractPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.vo.req.baseData.FrameContractPageSearch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 框架协议 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-01-28
 */
@Mapper
public interface FrameContractMapper extends BaseMapper<FrameContractPo> {

    /**
     * 分页查询
     * @param page
     * @param params
     * @return
     */
    IPage<FrameContractDto> page(@Param("page") Page<FrameContractPo> page, @Param("params") FrameContractPageSearch params);

    /**
     * 导出查询
     * @param params
     * @param lastId
     * @return
     */
    List<FrameContractExportDto>  pageExport(@Param("params") FrameContractPageSearch params, @Param("lastId") Long lastId);

    /**
     * 批量查询
     * @param list
     * @return
     */
    List<FrameContractPo> searchByContractNos(@Param("bizType") String bizType, @Param("list") List<String> list);

    /**
     * 批量插入
     * @param list
     * @return
     */
    Integer batchInsert(List<FrameContractPo> list);

    List<FrameContractDto> listBySalePartNums(@Param("bizType") String bizType, @Param("salePartNums") List<String> salePartNums);

}
