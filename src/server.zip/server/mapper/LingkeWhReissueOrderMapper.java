package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.sdk.pojo.dto.LingkeWhReissueOrderAllDto;
import com.jiduauto.sps.sdk.pojo.po.LingkeWhReissueOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.LingkeWhReissueOrderPageSearchReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 领克仓补差异订单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-12-11
 */
@Mapper
public interface LingkeWhReissueOrderMapper extends BaseMapper<LingkeWhReissueOrderPo> {

    IPage<LingkeWhReissueOrderAllDto> pageSearch(Page<Object> objectPage, @Param ("param") LingkeWhReissueOrderPageSearchReq param);
}
