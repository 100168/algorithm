package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.ApplyCarMaterialOrderDetailPo;

/**
 * <p>
 * 整车拉料订单明细表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-04-02
 */
public interface ApplyCarMaterialOrderDetailMapper extends BaseMapper<ApplyCarMaterialOrderDetailPo> {

}
