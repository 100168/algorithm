package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.AsnPackInfoPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 包装信息表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
public interface AsnPackInfoMapper extends BaseMapper<AsnPackInfoPo> {

}
