package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.dto.AsnAllDto;
import com.jiduauto.sps.server.pojo.fileexport.AsnBasicExportDto;
import com.jiduauto.sps.server.pojo.po.AsnBasicPo;
import com.jiduauto.sps.server.pojo.vo.req.AsnBasicListReq;
import com.jiduauto.sps.server.pojo.vo.req.ExcludeParam;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderAsnPageSearch;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderDetailSaveReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 预发货单基础信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
@Mapper
public interface AsnBasicMapper extends BaseMapper<AsnBasicPo> {

    List<AsnBasicPo> selectSyncList();

    AsnBasicPo selectByBizTypeAndAsnCode(@Param("bizType") String bizType, @Param("asnNo") String asnNo);

    /**
     * @param asnBasicPo
     * @param status
     * @return */
    int updateIsDelAndSyncStatus(@Param("asnBasicPo") AsnBasicPo asnBasicPo,@Param("status") long status);
    /**
      * 根据供应商编码,bizType,asnCode,asnLineNo(明细行号),salePartNum(集度售后件号)获取唯一asn发货信息
      * @author O_chaopeng.huang
      */
    AsnAllDto selectAsnAllDto(@Param("param") PurchaseReturnOrderDetailSaveReq req);

    /**
     * 根据{供应商编码,bizType,asnCode获取}集合获取对应唯一asn发货信息集合
     * @author O_chaopeng.huang
     */
    List<AsnAllDto> selectAsnAllDtos(@Param("supplier")String supplier ,@Param("bizType") String bizType
            ,@Param("asnCodes")List<String> asnCodes);

    /**
     *  根据已绑定ans采购的退货明细过滤已选asn
     * @author O_chaopeng.huang
     */
    IPage<AsnAllDto>  pageList(IPage<AsnAllDto> iPage,@Param("param") PurchaseReturnOrderAsnPageSearch req,@Param("excludeParams")List<ExcludeParam> excludeParams);

    /**
     * 导出查询
     */
    List<AsnBasicExportDto> exportSearch(@Param("param")AsnBasicListReq param);
}
