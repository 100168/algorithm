package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderDetailPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 采购退货订单明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-05-04
 */
public interface PurchaseReturnOrderDetailMapper extends BaseMapper<PurchaseReturnOrderDetailPo> {

}
