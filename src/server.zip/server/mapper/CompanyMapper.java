package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.po.CompanyPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 公司信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
@Mapper
public interface CompanyMapper extends BaseMapper<CompanyPo> {

    /**
     * 根据bizType和公司code查询唯一记录
     */
    CompanyPo getByBizAndCode(@Param("bizType") String bizType, @Param("code") String code);
    /**
     * 根据bizType和公司code查询唯一记录
     */
    List<CompanyPo> getByBizAndCodes(@Param("bizType") String bizType, @Param("codes") List<String> codes);

    /**
     * 根据条件分页查询公司信息
     * @param page
     * @param companyPo
     * @return
     */
    IPage<CompanyPo> pageSearch(IPage<CompanyPo> page, @Param("company") CompanyPo companyPo);
}
