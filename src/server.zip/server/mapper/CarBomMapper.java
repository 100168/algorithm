package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.sdk.pojo.dto.CarBomAllInfoDto;
import com.jiduauto.sps.sdk.pojo.dto.CarBomDto;
import com.jiduauto.sps.sdk.pojo.po.CarBomPo;
import com.jiduauto.sps.sdk.pojo.req.CarBomPageSearchReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 车辆BOM零件信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-04-02
 */
@Mapper
public interface CarBomMapper extends BaseMapper<CarBomPo> {

    IPage<CarBomDto> pageSearch(@Param(value = "page") Page<CarBomDto> page, @Param(value = "param") CarBomPageSearchReq param);
    List<CarBomAllInfoDto> exportSearch(@Param(value = "param") CarBomPageSearchReq param);
    List<CarBomAllInfoDto> exportSearchByIds(@Param(value = "param") CarBomPageSearchReq param);
}
