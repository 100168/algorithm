package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.po.CompanyPo;
import com.jiduauto.sps.server.pojo.po.OrderPlanOperateLogPo;
import com.jiduauto.sps.server.pojo.po.OrderPlanPo;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderPlanPageSearchReq;
import org.apache.ibatis.annotations.Param;

public interface OrderPlanOperateLogMapper extends BaseMapper<OrderPlanOperateLogPo> {

    IPage<OrderPlanOperateLogPo> pageSearch(IPage<CompanyPo> page, @Param("orderPlanId") Long orderPlanId);
}