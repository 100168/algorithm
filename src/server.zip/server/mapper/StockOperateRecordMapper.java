package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.po.StockOperateLogPo;
import com.jiduauto.sps.server.pojo.po.StockOperateRecordPo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 库存交易记录表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-04-28
 */
public interface StockOperateRecordMapper extends BaseMapper<StockOperateRecordPo> {

    /**
     * 查询幂等性字段 防止重复提交
     */
    StockOperateLogPo getByBizTypeAndIdempotentNo(String bizType, String idempotentNo);

    /**
     * 根据库存 key 查询占用记录
     */
    List<StockOperateRecordPo> occupyStockSearch(@Param("stockKey") String stockKey, @Param("id") Long id);
}
