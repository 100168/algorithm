package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.po.AreasPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.po.WarehousePo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 库存的区域信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-30
 */
@Mapper
public interface AreasMapper extends BaseMapper<AreasPo> {
    /**
     * 唯一建  查询仓库数据
     * @param bizType
     * @param code
     * @return
     */
    AreasPo getByBizAndCode(@Param("bizType") String bizType, @Param("code")  String code);

    /**
     * 唯一建  查询仓库数据
     * @param bizType
     * @param code
     * @return
     */
    AreasPo getByWareHouseAndCode(@Param("bizType") String bizType, @Param("code")  String code,@Param("wareHouse")  String wareHouse);

    /**
     * 唯一建  查询仓库数据
     * @param bizType
     * @param codes
     * @return
     */
    List<AreasPo> getByBizAndCodes(@Param("bizType") String bizType, @Param("codes")  List<String> codes);

    /**
     * 唯一建  查询仓库数据
     * @param bizType
     * @param codes
     * @return
     */
    List<String> getDistinctByBizAndCodes(@Param("bizType") String bizType, @Param("codes")  List<String> codes);


     /*
      * @Author O_chaopeng.huang
      * @Description //   获取区域编码集合
      * @Date 10:21 2023/2/21
      * @Param
      * @return
      **/
    List<String> getACodes(@Param("bizType") String bizType, @Param("areas") List<String> saleAreas,@Param("wares") List<String> saleWarehouse);
}
