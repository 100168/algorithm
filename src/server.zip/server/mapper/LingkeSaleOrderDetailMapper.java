package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.LingkeSaleOrderDetailPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 领克销售订单明细 Mapper 接口
 */
public interface LingkeSaleOrderDetailMapper extends BaseMapper<LingkeSaleOrderDetailPo> {

}
