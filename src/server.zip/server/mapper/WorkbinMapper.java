package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.WorkbinPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 料箱主数据 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-02-23
 */
@Mapper
public interface WorkbinMapper extends BaseMapper<WorkbinPo> {

    int batchInsert(@Param("list") List<WorkbinPo> workbinPos1);

    List<String> getByWPCodes(@Param("bizType") String bizType, @Param("list") List<String> saleCodes);
}
