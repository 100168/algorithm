package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.param.SalePricePageSearchParam;
import com.jiduauto.sps.server.pojo.dto.param.SalePriceSearchParam;
import com.jiduauto.sps.server.pojo.po.SalePricePo;
import com.jiduauto.sps.server.pojo.vo.req.SalePricePageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.SalePriceSyncPageSearchReq;
import java.time.LocalDateTime;
import java.util.ArrayList;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SalePriceMapper extends BaseMapper<SalePricePo> {

    IPage<SalePricePo> pageSearch(IPage<SalePricePo> page, @Param("searchParam") SalePricePageSearchParam pageSearch);

    IPage<SalePricePo> syncPageSearch(IPage<SalePricePo> page, @Param("pageSearch") SalePriceSyncPageSearchReq pageSearch);

    List<SalePricePo> listEffectivePrice(@Param("searchParam") SalePriceSearchParam searchParam);

    /**
     * 查询当天最新的有效价格
     * @param searchParam
     * @return
     */
    List<SalePricePo> listEffectivePriceV2(@Param("searchParam") SalePricePageSearchParam searchParam);

    void insertBatch(@Param("pos") ArrayList<SalePricePo> pos);
}