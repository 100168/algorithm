package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderStatusLogPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 采购申请订单状态变更记录 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-06-08
 */
public interface PurchaseApplyOrderStatusLogMapper extends BaseMapper<PurchaseApplyOrderStatusLogPo> {

}
