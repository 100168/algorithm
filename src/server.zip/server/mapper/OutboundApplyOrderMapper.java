package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.sdk.pojo.dto.OutboundApplyOrderDetailAllInfoDto;
import com.jiduauto.sps.sdk.pojo.fileExport.OutboundApplyOrderDetailExportDto;
import com.jiduauto.sps.server.pojo.dto.OutboundApplyOrderDto;
import com.jiduauto.sps.server.pojo.po.OutboundApplyOrderPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.vo.req.OutboundApplyOrderPageSearch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 出库申请 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-06-29
 */
@Mapper
public interface OutboundApplyOrderMapper extends BaseMapper<OutboundApplyOrderPo> {

    IPage<OutboundApplyOrderPo> pageSearch(IPage<OutboundApplyOrderPo> page,@Param("param") OutboundApplyOrderPageSearch param);

    /**
     * 查询  待出库列表的 库存不足的 零件信息
     * @param bizType
     * @return
     */
    List<OutboundApplyOrderDetailAllInfoDto> exportMaterialByLackStock(@Param("bizType") String bizType, @Param("applyOrderNo") String applyOrderNo);
}
