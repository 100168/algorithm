package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.SaleOrderOutboundParamPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 销售订单出库关系表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-07-10
 */
public interface SaleOrderOutboundParamMapper extends BaseMapper<SaleOrderOutboundParamPo> {

}
