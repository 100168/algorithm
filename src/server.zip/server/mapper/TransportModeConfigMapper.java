package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.TransportModeConfigPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 运输_方式_配置 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-03-10
 */
@Mapper
public interface TransportModeConfigMapper extends BaseMapper<TransportModeConfigPo> {

    int insertBatch(@Param("list") List<TransportModeConfigPo> list);
}
