package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.po.StoreWarehouseConfigPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.vo.req.StoreWarehouseConfigPageSearch;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p>
 * 门店_仓库_配置 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-03-10
 */
@Mapper
public interface StoreWarehouseConfigMapper extends BaseMapper<StoreWarehouseConfigPo> {


    int insertBatch(@Param("list") List<StoreWarehouseConfigPo> list);

    int updateBatch(@Param("list")List<StoreWarehouseConfigPo> list);

    /**
     * 查询门店的仓库配置
     * @param code
     * @return
     */
    List<StoreWarehouseConfigPo> getByStoreCode(@Param("code") String code, @Param("bizType") String bizType);

    IPage<StoreWarehouseConfigPo> page(@Param("code")IPage<StoreWarehouseConfigPo> page, @Param("searchReq") StoreWarehouseConfigPageSearch param);
}
