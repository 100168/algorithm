package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.InvokeLogPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 接口调用log，参数快照 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-30
 */
@Mapper
public interface InvokeLogMapper extends BaseMapper<InvokeLogPo> {

}
