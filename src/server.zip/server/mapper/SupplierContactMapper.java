package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.dto.baseData.SupplierSimpleDto;
import com.jiduauto.sps.server.pojo.po.SupplierContactPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 供应商联系人 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
@Mapper
public interface SupplierContactMapper extends BaseMapper<SupplierContactPo> {

    /**
     * 查询某个服务商的 联系人
     * @param supplierId
     * @return
     */
    List<SupplierContactPo> selectBySupplierId(Long supplierId);

    /**
     * 查询多个 服务商的 联系人
     * @param supplierIds
     * @return
     */
    List<SupplierContactPo> selectBySupplierIds(@Param("supplierIds") List<Long> supplierIds);    /**
     * 查询多个 服务商的 主 联系人
     * @param supplierCodes
     * @return
     */
    List<SupplierSimpleDto> selectMainBySupplierCodes(@Param("supplierCodes") List<String> supplierCodes);

    /**
     * 批量插入
     * @param list
     * @return
     */
    long batchInsert(List<SupplierContactPo> list);
}
