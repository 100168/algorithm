package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.fileexport.PendingReceiveExportDto;
import com.jiduauto.sps.server.pojo.po.PendingReceiveListPo;
import com.jiduauto.sps.server.pojo.vo.req.PendingReceiveListPageSearch;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 待收货列表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-08-22
 */
public interface PendingReceiveListMapper extends BaseMapper<PendingReceiveListPo> {

    IPage<PendingReceiveListPo> pageSearch(Page<PendingReceiveListPo> pendingReceiveListPoPage,@Param("search") PendingReceiveListPageSearch search);

    IPage<PendingReceiveExportDto> exportSearch(Page<PendingReceiveListPo> pendingReceiveListPoPage, @Param("search") PendingReceiveListPageSearch search);
}
