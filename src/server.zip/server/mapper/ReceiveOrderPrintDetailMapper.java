package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.ReceiveOrderPrintDetailPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 收货单打印记录明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-02-20
 */
public interface ReceiveOrderPrintDetailMapper extends BaseMapper<ReceiveOrderPrintDetailPo> {

}
