package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.StockConfigPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * 库存业务配置表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-29
 */
@Mapper
public interface StockConfigMapper extends BaseMapper<StockConfigPo> {
    /**
     * 查询 业务配置的 字段集合
     * @param bizType
     * @return
     */
    List<StockConfigPo> getByBizType(String bizType);
}
