package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.PurchaseForecastDto;
import com.jiduauto.sps.server.pojo.dto.param.PurchaseForecastParam;
import com.jiduauto.sps.server.pojo.po.PurchaseForecastPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 采购预测 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-02-09
 */
@Mapper
public interface PurchaseForecastMapper extends BaseMapper<PurchaseForecastPo> {
    IPage<PurchaseForecastPo> page(@Param("page") Page<PurchaseForecastPo> page, @Param("params") PurchaseForecastParam params);

    /**
     * 批量插入
     * @param list
     * @return
     */
    long batchInsert(List<PurchaseForecastPo> list);

    /**
     * 获取 未下发的记录
     * @return
     */
    List<PurchaseForecastPo> listUnissued(@Param("bizType") String bizType);
}
