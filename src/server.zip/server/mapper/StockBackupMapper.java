package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.StockBackupPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 库存备份表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-10-23
 */
public interface StockBackupMapper extends BaseMapper<StockBackupPo> {


    /**
     * 查询所有需要备份的库存 零附件
     */
    List<StockBackupPo> needBackupForG59();

    /**
     * 门店
     * @return
     */
    List<StockBackupPo> needBackupForSS();
    List<StockBackupPo> needBackupForSS2();

    /**
     * 能源
     * @return
     */
    List<StockBackupPo> needBackupForES();
}
