package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.stock.StockInOrderItemAllDto;
import com.jiduauto.sps.server.pojo.fileexport.StockInOrderItemExportDto;
import com.jiduauto.sps.server.pojo.po.CompanyPo;
import com.jiduauto.sps.server.pojo.po.StockInOrderItemPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.po.StockInOrderPo;
import com.jiduauto.sps.server.pojo.po.SupplierCalendarPo;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockInOrderItemSearch;
import com.jiduauto.sps.server.pojo.xxljob.StockInOrderLifeCycleDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 入库单明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-02-28
 */
@Mapper
public interface StockInOrderItemMapper extends BaseMapper<StockInOrderItemPo> {


    long batchInsert(@Param("list") List<StockInOrderItemPo> list);

    IPage<StockInOrderItemAllDto> pageSearch(IPage<StockInOrderItemPo> page,@Param("search") StockInOrderItemSearch pageParam);

    IPage<StockInOrderItemAllDto> pageSearchThree(Page<Object> objectPage, @Param("search")StockInOrderItemSearch param);

    List<StockInOrderItemExportDto> exportSearch(@Param("search") StockInOrderItemSearch pageParam, @Param("lastId") Long lastId);

    List<StockInOrderItemExportDto> exportSearchThree(@Param("search")StockInOrderItemSearch param,@Param("lastId") Long lastId);

    List<Long> selectGetIds(@Param("bizType") String bizType ,@Param("orderN") String orderNumber);

    List<StockInOrderItemAllDto>  selectByOrderNumbers(@Param("bizType") String bizType , @Param("numbers") List<String> numbers);

    List<StockInOrderLifeCycleDto> groupByMaterialAndWarehouse(@Param("bizType") String bizType,
                                                               @Param("inTypes")List<String> inTypes);
}
