package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.dto.param.OrderPlanAuditParam;
import com.jiduauto.sps.server.pojo.po.CompanyPo;
import com.jiduauto.sps.server.pojo.po.OrderPlanPo;
import com.jiduauto.sps.server.pojo.vo.req.OrderPlanPageSearchReq;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderPlanMapper extends BaseMapper<OrderPlanPo> {

    int commitOrderPlan(@Param("auditParam") OrderPlanAuditParam auditParam);

    int auditOrderPlan(@Param("auditParam") OrderPlanAuditParam auditParam);

    IPage<OrderPlanPo> pageSearch(IPage<CompanyPo> page, @Param("searchReq") OrderPlanPageSearchReq searchReq);

    List<OrderPlanPo> listAuditedOrderPlan(@Param("ids") List<Long> ids);

    List<OrderPlanPo> listAuditedOrderPlanByNo(@Param("bizType") String bizType, @Param("orderPlanNos") List<String> orderPlanNos);

    int updateSyncStatus(@Param("ids") List<Long> ids, @Param("syncStatus") String syncStatus, @Param("description") String description);

    List<OrderPlanPo> listSyncFailedOrderPlan();
}