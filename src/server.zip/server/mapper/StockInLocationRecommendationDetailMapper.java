package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.StockInLocationRecommendationDetailPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 库位规划详情 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-07-04
 */
public interface StockInLocationRecommendationDetailMapper extends BaseMapper<StockInLocationRecommendationDetailPo> {

    /**
     * 无视是否删除直接查询
     */
    List<StockInLocationRecommendationDetailPo> listByIds(@Param("detailList") List<Long> detailList);

    void del(@Param("detailList")List<Long> detailList);

    List<StockInLocationRecommendationDetailPo> queryByRecommendId(@Param("recommendId") Long recommendId);
}
