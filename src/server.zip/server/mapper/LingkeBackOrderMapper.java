package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.dto.LingkeBackOrderDto;
import com.jiduauto.sps.server.pojo.po.LingkeBackOrderPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.vo.req.LingkeBackOrderPageSearch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 领克缺件订单 Mapper 接口
 */
@Mapper
public interface LingkeBackOrderMapper extends BaseMapper<LingkeBackOrderPo> {

    IPage<LingkeBackOrderDto> pageSearch(IPage<LingkeBackOrderDto> page, @Param("param") LingkeBackOrderPageSearch param);
}
