package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.sdk.pojo.dto.StockAdjustOrderItemDto;
import com.jiduauto.sps.sdk.pojo.po.StockAdjustOrderItemPo;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 库存数量调整单明细 Mapper 接口
 *
 * @author generate
 * @since 2023-12-01
 */
@Mapper
public interface StockAdjustOrderItemMapper extends BaseMapper<StockAdjustOrderItemPo> {

    List<StockAdjustOrderItemDto> itemList(@Param("param") OrderNoReq param);

    IPage<StockAdjustOrderItemDto> pageItemList(IPage<Object> objectPage, @Param("param") OrderNoReq param);
}
