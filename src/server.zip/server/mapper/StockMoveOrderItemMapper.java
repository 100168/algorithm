package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.dto.stock.StockMoveOrderItemDto;
import com.jiduauto.sps.server.pojo.dto.stock.StockMovetemDto;
import com.jiduauto.sps.server.pojo.po.StockMoveOrderItemPo;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 移库单详情 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-05-23
 */
@Mapper
public interface StockMoveOrderItemMapper extends BaseMapper<StockMoveOrderItemPo> {
    int insertBatch(List<StockMoveOrderItemPo> itemPos);

    List<StockMovetemDto> selectItemAndMaterial(String bizType, String no);
    /**
     * 批量查询
     * @param bizType bizType
     * @param nos nos
     * @return List
     */
    List<StockMoveOrderItemDto> selectItemList(String bizType, List<String> nos);

    int updateBatchIds(@Param("list") List<StockMoveOrderItemPo> oldItemList);
}
