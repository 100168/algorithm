package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.LingkeBackOrderDetailPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 领克缺件订单明细 Mapper 接口
 */
public interface LingkeBackOrderDetailMapper extends BaseMapper<LingkeBackOrderDetailPo> {

}
