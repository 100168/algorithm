package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.MaterialStockLifeCyclePo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 零件库存的生命周期 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-09-05
 */
public interface MaterialStockLifeCycleMapper extends BaseMapper<MaterialStockLifeCyclePo> {

    void batchInsert(@Param("list") List<MaterialStockLifeCyclePo> list);
}
