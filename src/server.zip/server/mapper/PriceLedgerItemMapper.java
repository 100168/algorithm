package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.PriceLedgerItemPo;

/**
 * <p>
 * 价格台账明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-04-16
 */
public interface PriceLedgerItemMapper extends BaseMapper<PriceLedgerItemPo> {

}
