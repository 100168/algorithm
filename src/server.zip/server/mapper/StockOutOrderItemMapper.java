package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.stock.StockInOrderItemAllDto;
import com.jiduauto.sps.server.pojo.dto.stock.StockOutOrderItemAllDto;
import com.jiduauto.sps.server.pojo.fileexport.StockOutOrderItemExportDto;
import com.jiduauto.sps.server.pojo.po.StockOutOrderItemPo;
import com.jiduauto.sps.server.pojo.po.StockOutOrderItemPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockOutOrderItemSearch;
import com.jiduauto.sps.server.pojo.xxljob.StockInOrderLifeCycleDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 出库单明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-02-28
 */
@Mapper
public interface StockOutOrderItemMapper extends BaseMapper<StockOutOrderItemPo> {

    long batchInsert(List<StockOutOrderItemPo> list);


    IPage<StockOutOrderItemAllDto> pageSearch(IPage<StockOutOrderItemPo> page, @Param("search") StockOutOrderItemSearch pageParam, @Param("hasMaterial")boolean hasMaterial);

    List<StockOutOrderItemExportDto> exportSearch(@Param("search")StockOutOrderItemSearch param, @Param("lastId") Long lastId, @Param("hasMaterial")boolean hasMaterial);


    List<StockOutOrderItemAllDto>  selectByOrderNumbers(@Param("bizType") String bizType , @Param("numbers") List<String> numbers);


    List<StockInOrderLifeCycleDto> groupByMaterialAndWarehouse(@Param("bizType") String bizType,
                                                               @Param("inTypes")List<String> inTypes);
}
