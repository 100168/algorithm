package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.po.SalePriceApprovalPo;
import com.jiduauto.sps.server.pojo.vo.req.SalePriceApprovalPageSearchReq;
import org.apache.ibatis.annotations.Param;

public interface SalePriceApprovalMapper extends BaseMapper<SalePriceApprovalPo> {

    int createTempRecord(@Param("po") SalePriceApprovalPo salePriceApprovalPo);

    int enableTempRecord(@Param("id") Long id, @Param("bizType") String bizType);

    IPage<SalePriceApprovalPo> pageSearch(IPage<SalePriceApprovalPo> page, @Param("pageSearchReq") SalePriceApprovalPageSearchReq pageSearchReq);

    SalePriceApprovalPo getById(@Param("id") Long id, @Param("bizType") String bizType);

    int updateDetailQty(@Param("id") Long id, @Param("detailQty") Integer detailQty, @Param("updateUser") String updateUser);

    int updateAttachmentQty(@Param("id") Long id, @Param("attachmentQty") Integer attachmentQty, @Param("updateUser") String updateUser);
}