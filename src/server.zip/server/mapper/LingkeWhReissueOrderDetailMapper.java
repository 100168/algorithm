package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.dto.LingkeWhReissueOrderItemDto;
import com.jiduauto.sps.sdk.pojo.po.LingkeWhReissueOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import java.util.List;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 领克仓补订单明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-12-25
 */
public interface LingkeWhReissueOrderDetailMapper extends BaseMapper<LingkeWhReissueOrderDetailPo> {

    List<LingkeWhReissueOrderItemDto> listDto(@Param("req") OrderNoReq req);
}
