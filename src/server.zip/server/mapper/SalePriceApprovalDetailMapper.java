package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.dto.param.SalePriceApprovalQueryParam;
import com.jiduauto.sps.server.pojo.po.SalePriceApprovalDetailPo;
import com.jiduauto.sps.server.pojo.vo.req.SalePriceApprovalDetailPageSearchReq;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SalePriceApprovalDetailMapper extends BaseMapper<SalePriceApprovalDetailPo> {

    IPage<SalePriceApprovalDetailPo> pageSearch(IPage<SalePriceApprovalDetailPo> page, @Param("pageSearchReq") SalePriceApprovalDetailPageSearchReq pageSearchReq);

    int batchInsert(List<SalePriceApprovalDetailPo> salePriceApprovalDetailPos);

    List<SalePriceApprovalDetailPo> listSalePriceApprovalDetailPo(@Param("queryParam") SalePriceApprovalQueryParam queryParam);

    int deleteById(@Param("id") Long id);

    int deleteByApprovalId(@Param("approvalId") Long approvalId);
}