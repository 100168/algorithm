package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.dto.ApplyOrderAllInfoDto;
import com.jiduauto.sps.server.pojo.dto.ApplyOrderAndItemDto;
import com.jiduauto.sps.server.pojo.po.ApplyOrderItemPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 领料单明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-05-15
 */
@Mapper
public interface ApplyOrderItemMapper extends BaseMapper<ApplyOrderItemPo> {

    int batchInsert(List<ApplyOrderItemPo> list);

    /**
     * 批量查询
     * @param orderNumbers  单号
     * @param status  状态
     * @return
     */
    List<ApplyOrderAllInfoDto> getByOrderNumbersAndStatus(@Param("orderNumbers") List<String> orderNumbers,
                                                          @Param("status") String status,
                                                          @Param("bizType") String bizType);

    /**
     * 查询所有明细数据
     * @return
     */
    List<ApplyOrderAndItemDto> getAllInfo();

    int updateBatchIds(@Param("list") List<ApplyOrderItemPo> oldItemList);
}
