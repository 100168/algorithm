package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.po.WarehousePo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 仓库主数据 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
@Mapper
public interface WarehouseMapper extends BaseMapper<WarehousePo> {
    /**
     * 唯一建  查询仓库数据
     * @param bizType
     * @param code
     * @return
     */
    WarehousePo getByBizAndCode(@Param("bizType") String bizType,@Param("code")  String code);
      /**
     * 唯一建  查询仓库数据
     * @param bizType
     * @param codes
     * @return
     */
    List<WarehousePo> getByBizAndCodes(@Param("bizType") String bizType,@Param("codes") List<String> codes);

    /**
     * 查询仓库信息  包括已经删除的
     * @param bizType
     * @param codes
     * @return
     */
    List<WarehousePo> getAllByBizAndCodes(@Param("bizType") String bizType,@Param("codes") List<String> codes);


     /*
      * @Author O_chaopeng.huang
      * @Description //   获取仓库编码集合
      * @Date 10:16 2023/2/21
      * @Param
      * @return
      **/
    List<String> getByWCodes(@Param("bizType") String bizType,@Param("list") List<String> saleWarehouse);

    /**
     * 查询存在的仓库code
     *
     * @param warehouseCodes
     * @return
     */
    List<String> listExistWarehouseCodes(@Param("warehouseCodes") List<String> warehouseCodes);
}
