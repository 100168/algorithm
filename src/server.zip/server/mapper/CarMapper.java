package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.CarPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 车辆主数据 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-02-24
 */
@Mapper
public interface CarMapper extends BaseMapper<CarPo> {



     /*
      * @Author O_chaopeng.huang
      * @Description //   获取车辆编码
      * @Date 9:02 2023/2/27
      * @Param
      * @return
      **/
    List<String> getByWPCodes(@Param("bizType") String bizType, @Param("list") List<String> saleCodes);

     /*
      * @Author O_chaopeng.huang
      * @Description //   批量插入
      * @Date 9:02 2023/2/27
      * @Param
      * @return
      **/
    int batchInsert(List<CarPo> pos);
}
