package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.AsnReceiveInfoPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 外部系统收货信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
@Mapper
public interface AsnReceiveInfoMapper extends BaseMapper<AsnReceiveInfoPo> {

}
