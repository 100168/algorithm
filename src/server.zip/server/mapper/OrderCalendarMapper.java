package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.dto.param.StoreCodeParam;
import com.jiduauto.sps.server.pojo.po.OrderCalendarPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface OrderCalendarMapper extends BaseMapper<OrderCalendarPo> {

    List<OrderCalendarPo> listOrderCalendarPo(@Param("codeParams") List<StoreCodeParam> codeParams);
}
