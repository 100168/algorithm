package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;

/**
 * <p>
 * 采购退货订单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-05-04
 */
public interface PurchaseReturnOrderMapper extends BaseMapper<PurchaseReturnOrderPo> {

    /**
     * 保存草稿
     * @param request id和业务类型
     * @return 更新条数
     */
    int enableTempRecord(IdReq request);

    /**
     * 根据id查询数据包括临时数据
     * @param request id和业务类型
     * @return 退货单
     */
    PurchaseReturnOrderPo getByIdWithDel(IdReq request);

}
