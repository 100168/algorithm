package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.kit.KitOrderStatusLogPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * KIT订单状态变更记录表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
public interface KitOrderStatusLogMapper extends BaseMapper<KitOrderStatusLogPo> {

}
