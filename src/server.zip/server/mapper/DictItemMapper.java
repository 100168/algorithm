package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.po.DictItemPo;
import com.jiduauto.sps.server.pojo.vo.req.baseData.WorkbinEditAndSingleAddReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 后台字典item表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-06
 */
@Mapper
public interface DictItemMapper extends BaseMapper<DictItemPo> {

     /*
      * @Author O_chaopeng.huang
      * @Description //   获取对应类型名称编码
      * @Date 9:23 2023/2/27
      * @Param
      * @return
      **/
    @Select("select item_code from dict_item where item_code in (#{add.boxSpecCode}, #{add.boxTypeCode})and item_name in (#{add.boxSpecName}, #{add.name})")
    List<String> getItemCode(@Param("add") WorkbinEditAndSingleAddReq workbinEditAndSingleAddReq);


     /*
      * @Author O_chaopeng.huang
      * @Description //   获取类型编码
      * @Date 9:23 2023/2/27
      * @Param
      * @return
      **/
    List<String> getByWCodes(@Param("list") List<String> saleWarehouse);
}
