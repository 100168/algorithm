package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.stock.DiffStockDto;
import com.jiduauto.sps.server.pojo.dto.stock.StockAllDto;
import com.jiduauto.sps.server.pojo.fileexport.StockExportAllDto;
import com.jiduauto.sps.server.pojo.po.StockPo;
import com.jiduauto.sps.server.pojo.vo.req.StockSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockSearch;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockSearchForSum;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockSearchForSumByMaterialAndWareHouse;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockSearchForSSMaterialSumResp;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockSearchForSSResp;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * 库存表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-29
 */
@Mapper
public interface StockMapper extends BaseMapper<StockPo> {
    /**
     * 后台配置的唯一字段组合key  查询库存记录
     * @param bizConfigField
     * @return
     */
    StockPo getByBizConfigField(@Param("bizConfigField") String bizConfigField);

    /**
     * 后台配置的唯一字段组合key  查询库存记录  批量
     * @param bizConfigFields
     * @return
     */
    List<StockPo> getByBizConfigFields(@Param("bizConfigFields") List<String> bizConfigFields);

    List<StockPo> getByBizConfigFieldsV2(@Param("bizConfigFields") Set<String> bizConfigFields);

    /**
     * 分页查询
     * @param page
     * @param params
     * @return
     */
    IPage<StockPo> page(@Param("page") Page<StockPo> page, @Param("params") StockSearchReq params);


    /**
     *  限量查询 1000
     * @param params
     * @return
     */
    List<StockPo> search(@Param("params") StockSearchReq params);

    /**
     * 批量插入
     * @param list
     * @return
     */
    int batchInsert(@Param("list") List<StockPo> list);

    /**
     * 版本号 乐观锁更新数量
     * @param po
     * @return
     */
    int updateQuantityById(StockPo po);
    /**
     *  直接重置库存占用  小于库存总数
     *  门店智子专用
     * @param po
     * @return
     */
    int resetStockOccupyById(StockPo po);

    /**
     * 库存分页查询
     * @Author O_chaopeng.huang
     * @Date 16:09 2023/5/4
     * @Param
     * @return
     **/
    IPage<StockAllDto> selectStockAllDtoPage(IPage<StockAllDto> page,@Param("search") StockSearch pageParam, @Param("hasMaterial")boolean hasMaterial);

    /**
     * 库存总数 分页查询 按零件号 分组， 查每个零件的库存总数
     * @Param
     * @return
     **/
    IPage<StockSearchForSSResp> pageSearchSumStock(IPage<StockSearchForSSResp> page, @Param("search") StockSearchForSum pageParam);


    /**
     * 库存导出查询
     * @param param
     * @param hasMaterial
     * @return
     */
    List<StockExportAllDto> exportSearchAll(@Param("search")StockSearch param, @Param("lastId")Long lastId, @Param("hasMaterial")boolean hasMaterial);
    /**
      * 根据查询结果获取零件总库存
      *
      * @author O_chaopeng.huang
      */
    BigDecimal selectAndGetSum(@Param("search") StockSearch param, @Param("hasMaterial")boolean hasMaterial);


    BigDecimal getSumPrice(@Param("search") StockSearch param, @Param("hasMaterial") boolean hasMaterial);

    List<DiffStockDto> selectDiffStock(@Param("bizType")String bizType);

    /**
     * 库存总数 分页查询 按零件号和仓库 分组， 查每个零件的库存总数
     **/
    IPage<StockSearchForSSMaterialSumResp> pageSearchSumStockByMaterialAndWareHouse(IPage<StockSearchForSSMaterialSumResp> page, @Param("search") StockSearchForSumByMaterialAndWareHouse param);

    /**
     * 减少占用数量
     */
    int unOccupyQuantityById(Long id, Integer qty);

    /**
     * 增加占用数量
     */
    int occupyQuantityById(Long id, Integer qty);

    /**
     * 查询所有需要备份的库存
     */
    List<StockPo> needBackup();
}
