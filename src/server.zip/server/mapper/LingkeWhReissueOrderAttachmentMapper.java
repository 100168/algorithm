package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.LingkeWhReissueOrderAttachmentPo;

/**
 * <p>
 * 领克仓补差异订单附件 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-12-11
 */
public interface LingkeWhReissueOrderAttachmentMapper extends BaseMapper<LingkeWhReissueOrderAttachmentPo> {

}
