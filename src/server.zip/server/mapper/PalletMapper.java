package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.PalletPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 托盘主数据 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-02-22
 */
@Mapper
public interface PalletMapper extends BaseMapper<PalletPo> {


int batchInsert( @Param("list") List<PalletPo> palletPos);

    List<String> getByWPCodes(@Param("bizType") String bizType, @Param("list") List<String> saleCodes);
}
