package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.po.SalePriceApprovalAttachmentPo;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import org.apache.ibatis.annotations.Param;

public interface SalePriceApprovalAttachmentMapper extends BaseMapper<SalePriceApprovalAttachmentPo> {

    IPage<SalePriceApprovalAttachmentPo> pageSearch(IPage<SalePriceApprovalAttachmentPo> page, @Param("pageSearchReq") IdReq idReq);
}