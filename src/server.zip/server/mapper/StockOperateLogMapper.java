package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.StockOperateLogPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 库存交易记录表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-29
 */
@Mapper
public interface StockOperateLogMapper extends BaseMapper<StockOperateLogPo> {
    /**
     * 查询幂等性字段 防止重复提交
     * @param bizType
     * @param idempotentNo
     * @return
     */
    StockOperateLogPo getByBizTypeAndIdempotentNo(@Param("bizType") String bizType, @Param("idempotentNo") String idempotentNo);

    /**
     * 查询 某个业务单号的 库存操作记录
     * @param bizType
     * @param idempotentNo
     * @return
     */
    List<StockOperateLogPo> selectLogsByIdempotentNo(@Param("bizType") String bizType, @Param("idempotentNo") String idempotentNo);

    /**
     * 批量插入
     * @param list
     * @return
     */
    int batchInsert(List<StockOperateLogPo> list);
}
