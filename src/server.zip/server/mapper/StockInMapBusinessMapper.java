package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.dto.StockInMapBusinessDto;
import com.jiduauto.sps.server.pojo.po.StockInMapBusinessPo;
import com.jiduauto.sps.server.pojo.vo.req.StockInMapBusinessPageSearchReq;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 入库订单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-05-29
 */
public interface StockInMapBusinessMapper extends BaseMapper<StockInMapBusinessPo> {

    IPage<StockInMapBusinessDto> pageSearch(IPage<StockInMapBusinessDto> page, @Param("param") StockInMapBusinessPageSearchReq pageParam);
}
