package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.SupplierSrmCompanyPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * 从SRM同步过来的供应商的公司信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-02-01
 */
@Mapper
public interface SupplierSrmCompanyMapper extends BaseMapper<SupplierSrmCompanyPo> {

    List<SupplierSrmCompanyPo> getBySupplierSrmId(Long supplierSrmId);

    Integer batchInsert(List<SupplierSrmCompanyPo> list);
}
