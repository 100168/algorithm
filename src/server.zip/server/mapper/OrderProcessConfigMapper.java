package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.OrderProcessConfigPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 业务流程配置表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-09-03
 */
public interface OrderProcessConfigMapper extends BaseMapper<OrderProcessConfigPo> {

}
