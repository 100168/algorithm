package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.dto.PickingOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.PickingOrderDetailPo;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;
import com.jiduauto.sps.server.pojo.vo.req.stock.PickingOrderDetailReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 拣货单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-06-29
 */
@Mapper
public interface PickingOrderDetailMapper extends BaseMapper<PickingOrderDetailPo> {

    List<PickingOrderDetailDto> listDrop(@Param("param") OrderNoReq param);
}
