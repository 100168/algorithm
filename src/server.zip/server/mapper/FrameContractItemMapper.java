package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.dto.baseData.FrameContractDto;
import com.jiduauto.sps.server.pojo.po.FrameContractItemPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 框架协议中物料信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-01-30
 */
@Mapper
public interface FrameContractItemMapper extends BaseMapper<FrameContractItemPo> {

    List<FrameContractItemPo> selectByContractId(Long contractId);

    /**
     * 售后件号 查询 对应的 供应商信息
     * @param frameType  对应 bizType
     * @param materialPartNumbers
     * @return
     */
    List<FrameContractDto>  selectSupplierByMaterials(@Param("frameType") String frameType, @Param("materialPartNumbers") List<String> materialPartNumbers);


    /**
     * 批量插入
     * @param list
     * @return
     */
    Integer batchInsert(List<FrameContractItemPo> list);
}
