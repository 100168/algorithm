package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.StockChannelUpdateOrderPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 渠道库存调整单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-10-09
 */
public interface StockChannelUpdateOrderMapper extends BaseMapper<StockChannelUpdateOrderPo> {

}
