package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.ClaimSecondResponsiblePo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 物流索赔二次责任认定记录 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-01-31
 */
public interface ClaimSecondResponsibleMapper extends BaseMapper<ClaimSecondResponsiblePo> {

}
