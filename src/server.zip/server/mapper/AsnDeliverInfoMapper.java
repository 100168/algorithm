package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.AsnDeliverInfoPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 发货信息表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
@Mapper
public interface AsnDeliverInfoMapper extends BaseMapper<AsnDeliverInfoPo> {

    List<AsnDeliverInfoPo> selectByAsnCode(@Param("asnCode") String asnCode, @Param("bizType") String bizType);
}
