package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.param.MaterialSearchParam;
import com.jiduauto.sps.server.pojo.dto.param.MaterialSimpleParam;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 备件主数据表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-08
 */
@Mapper
public interface MaterialMapper extends BaseMapper<MaterialPo> {

    /**
     * 零件编号查询
     * @param bizType
     * @param number
     * @return
     */
    MaterialPo selectByNumber(@Param("bizType") String bizType, @Param("number") String number);
    /**
     * 零件编号查询
     * @param number
     * @return
     */
    List<MaterialPo> selectListByNumber(@Param("number") String number);

    /**
     * 零件编号查询
     * @param bizType
     * @param numbers
     * @return
     */
    List<MaterialPo> selectByMaterialNumberAndBizType(@Param("bizType") String bizType, @Param("numbers") List<String> numbers);
    /**
     * 批量 售后件号查询
     * @param bizType
     * @param numbers
     * @return
     */
    List<MaterialPo> selectByNumbers(@Param("bizType") String bizType, @Param("numbers") List<String> numbers);/**
     * 批量 售后件号查询
     * @param bizType
     * @param numbers
     * @return
     */
    List<String> selectDistinctByNumbers(@Param("bizType") String bizType, @Param("numbers") List<String> numbers);

    /**
     * 售后件号查询
     * @param bizType
     * @param salePartNum  售后件号
     * @return
     */
    MaterialPo selectBySalePartNum(@Param("bizType") String bizType, @Param("salePartNum") String salePartNum);
    /**
     * 批量 售后件号查询
     * @param bizType
     * @param salePartNum  售后件号
     * @return
     */
    List<MaterialPo> selectBySalePartNums(@Param("bizType") String bizType, @Param("salePartNums") List<String> salePartNum);
    /**
     * 批量 售后件号查询  不区分 业务类型
     * @param salePartNum  售后件号
     * @return
     */
    List<MaterialPo> selectAllBySalePartNum(@Param("salePartNum") String salePartNum);

    /**
     * 批量 售后件号查询  不区分 业务类型
     * @param salePartNums  售后件号
     * @return
     */
    List<MaterialPo> selectAllBySalePartNums(@Param("salePartNums") List<String> salePartNums);


    /**
     * 备件号查重
     * @param list
     * @return
     */
    List<String> getBySalePartNums(@Param("bizType") String bizType, @Param("list")List<String> list);



    /**
     * 批量插入
     * @param list
     * @return
     */
    int batchInsert(List<MaterialPo> list);

    /**
     * 分页查询
     * @param page
     * @param params
     * @return
     */
    IPage<MaterialPo> page(@Param("page") Page<MaterialPo> page, @Param("params")MaterialSearchParam params);

    /**
     * 导出的时候 条件查询
     * @param params
     * @param lastId
     * @return
     */
    List<MaterialPo> pageExport( @Param("params")MaterialSearchParam params, @Param("id") Long lastId);

    /**
     * 条件查询
     * @param params
     * @param lastId
     * @return
     */
    List<MaterialPo> searchList(@Param("params") MaterialSimpleParam params, @Param("id") Long lastId);

    /**
     * 批量导出
     * @param po
     * @return
     */
    List<MaterialPo> export(@Param("po")MaterialPo po);

    /**
     * 根据业务类新与零件number集合获取零件信息
     * @Author O_chaopeng.huang
     * @Date 22:15 2023/3/1
     * @Param
     * @return
     **/
    List<MaterialPo> selectMaterials(@Param("bizType") String bizType, @Param("list") List<String> collect);

    /**
     * 查询存在的销售件号
     *
     * @param salePartNums
     * @return
     */
    List<String> listExistSalePartNums(@Param("salePartNums") List<String> salePartNums);

    void updateSql(@Param("po") MaterialPo materialPo);
}
