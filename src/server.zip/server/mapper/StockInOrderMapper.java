package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.po.StockInOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockInOrderSearch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 入库单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-02-28
 */
@Mapper
public interface StockInOrderMapper extends BaseMapper<StockInOrderPo> {

    IPage<StockInOrderPo> pageSearch(@Param("page") Page<StockInOrderPo> page, @Param("params")StockInOrderSearch params);

    long batchInsert(List<StockInOrderPo> list);

    StockInOrderPo selectByOrderNumber(@Param("bizType")String bizType, @Param("orderNumber")String orderNumber);

    Page<StockInOrderPo> selectPageSearch(IPage<StockInOrderPo> page, @Param("param") StockInOrderSearch param);



    /**
     * id 大小 分页查询
     * @param id
     * @return
     */
    List<StockInOrderPo> pageSearchNoCount( @Param("limit")int limit , @Param("bizType")String bizType, @Param("id") long id, @Param("maxId") long maxId);

    /**
     * 查询入库日期 是 日期 的非 API记录
     * @return
     */
    List<StockInOrderPo> searchByInDate();
}
