package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.sdk.pojo.fileExport.ReceiveOrderDetailExportDto;
import com.jiduauto.sps.sdk.pojo.req.ReceiveOrderDetailPageSearch;
import com.jiduauto.sps.server.pojo.dto.ReceiveOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.ReceiveOrderDetailPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.xxljob.StockInOrderLifeCycleDto;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 收货单明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-08-22
 */
public interface ReceiveOrderDetailMapper extends BaseMapper<ReceiveOrderDetailPo> {


    /**
     * 批量插入
     * @param list
     */
    void batchInsert(List<ReceiveOrderDetailPo> list);

    /**
     * 分页查询
     * @param page
     * @param param
     * @return
     */
    IPage<ReceiveOrderDetailDto> pageSearchList(Page<ReceiveOrderDetailDto> page,  @Param("search") ReceiveOrderDetailPageSearch param);

    /**
     * 导出查询
     * @param param
     * @return
     */
    List<ReceiveOrderDetailExportDto> exportSearchList(@Param("search") ReceiveOrderDetailPageSearch param);



    List<StockInOrderLifeCycleDto> groupByMaterialAndWarehouse(@Param("bizType") String bizType,
                                                               @Param("inTypes")List<String> inTypes);

}
