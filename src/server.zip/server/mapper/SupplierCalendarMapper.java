package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.dto.param.SupplierCalendarCodeParam;
import com.jiduauto.sps.server.pojo.po.CompanyPo;
import com.jiduauto.sps.server.pojo.po.SupplierCalendarPo;
import com.jiduauto.sps.server.pojo.vo.req.SupplierCalendarPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.SupplierCalendarSyncPageSearchReq;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SupplierCalendarMapper extends BaseMapper<SupplierCalendarPo> {

    /**
     * 根据条件分页查询供应商日历
     * @param page
     * @param searchReq
     * @return
     */
    IPage<SupplierCalendarPo> pageSearch(IPage<CompanyPo> page, @Param("searchReq") SupplierCalendarPageSearchReq searchReq);

    /**
     * 同步数据分页查询
     * @param page
     * @param searchReq
     * @return
     */
    IPage<SupplierCalendarPo> syncPageSearch(IPage<CompanyPo> page, @Param("searchReq") SupplierCalendarSyncPageSearchReq searchReq);

    /**
     * 批量插入
     * @param supplierCalendarPos
     * @return
     */
    int batchInsert(List<SupplierCalendarPo> supplierCalendarPos);

    /**
     * 根据codes批量查询
     * @param bizType
     * @param codeParams
     * @return
     */
    List<SupplierCalendarPo> listByBizAndCodes(@Param("bizType") String bizType, @Param("codeParams")  List<SupplierCalendarCodeParam> codeParams);



    int deleteById(@Param("id") Long id);
}