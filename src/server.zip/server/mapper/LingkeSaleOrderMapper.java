package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.LingkeSaleOrderDto;
import com.jiduauto.sps.server.pojo.fileexport.LingkeSaleOrderExportDto;
import com.jiduauto.sps.server.pojo.po.LingkeSaleOrderPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.vo.req.LingkeSaleOrderPageSearchReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 领克销售订单 Mapper 接口
 */
@Mapper
public interface LingkeSaleOrderMapper extends BaseMapper<LingkeSaleOrderPo> {

    IPage<LingkeSaleOrderDto> pageSearch(IPage<LingkeSaleOrderDto> objectPage,@Param("param") LingkeSaleOrderPageSearchReq param);

    IPage<LingkeSaleOrderExportDto> pageSearchExport(IPage<LingkeSaleOrderExportDto> page, LingkeSaleOrderPageSearchReq param);
}
