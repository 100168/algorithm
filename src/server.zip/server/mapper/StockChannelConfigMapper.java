package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.StockChannelConfigPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 库存渠道配置表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-09-26
 */
public interface StockChannelConfigMapper extends BaseMapper<StockChannelConfigPo> {

}
