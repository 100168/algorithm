package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.po.SupplierPo;
import com.jiduauto.sps.server.pojo.vo.req.baseData.SupplierPageSearch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 供应商信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
@Mapper
public interface SupplierMapper extends BaseMapper<SupplierPo> {
    /**
     * 唯一建  查询
     * @param bizType
     * @param code
     * @return
     */
    SupplierPo getByBizAndCode(@Param("bizType") String bizType, @Param("code")  String code);

    /**
     * 唯一建  查询
     * @param bizType
     * @param codes
     * @return
     */
    List<SupplierPo> getByBizAndCodes(@Param("bizType") String bizType, @Param("codes")  List<String> codes);

    /**
     * 供应商底阿妈  查询
     * @param codes
     * @return
     */
    List<SupplierPo> getByCodes(@Param("codes")  List<String> codes);
    /**
    * 唯一建  查询
     * @param bizType
     * @param codes
     * @return
     */
    List<String> getDistinctByBizAndCodes(@Param("bizType") String bizType, @Param("codes")  List<String> codes);

    /**
     * 分页查询
     * @param page
     * @param params
     * @return
     */
    IPage<SupplierPo> page(@Param("page") Page<SupplierPo> page, @Param("params") SupplierPageSearch params);

    /**
     * 批量导入
     * @param supplierPos
     */
    void batchInsert(List<SupplierPo> supplierPos);

    /**
     * 查询存在的供应商代码
     *
     * @param supplierCodes
     * @return
     */
    List<String> listExistSupplierCodes(@Param("supplierCodes") List<String> supplierCodes);
}
