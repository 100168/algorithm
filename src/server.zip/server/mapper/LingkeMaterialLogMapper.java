package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.LingkeMaterialLogPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 领克同步物料属性记录 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-10-27
 */
@Mapper
public interface LingkeMaterialLogMapper extends BaseMapper<LingkeMaterialLogPo> {

    int insert(LingkeMaterialLogPo po);

    List<LingkeMaterialLogPo> getByIds(@Param("ids") List<Long> ids);
}
