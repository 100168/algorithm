package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.dto.kit.KitOrderItemDto;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderItemPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.vo.req.kit.KitOrderItemPageReq;

import java.util.List;

/**
 * <p>
 * KIT订单表明细表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
public interface KitOrderItemMapper extends BaseMapper<KitOrderItemPo> {

    IPage<KitOrderItemDto> pageSearch(IPage<KitOrderItemDto> page, KitOrderItemPageReq param);

    void updateBatchByNoAndMaterialCode(List<KitOrderItemPo> outQuantityList);
}
