package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.dto.kit.KitItemDto;
import com.jiduauto.sps.server.pojo.po.kit.KitItemPo;
import com.jiduauto.sps.server.pojo.vo.req.kit.KitItemPageSearchReq;

/**
 * <p>
 * kit主数据明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
public interface KitItemMapper extends BaseMapper<KitItemPo> {

    /**
     * 分页查询
     * @param page
     * @param param
     * @return
     */
    IPage<KitItemDto> pageSearch(IPage<KitItemPo> page, KitItemPageSearchReq param);
}
