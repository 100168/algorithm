package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.SupplierSrmPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * <p>
 * SRM同步的供应商信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-01-31
 */
@Mapper
public interface SupplierSrmMapper extends BaseMapper<SupplierSrmPo> {

    List<SupplierSrmPo> getByCodes(List<String> codes);
    SupplierSrmPo getByCode(String code);

    Integer batchInsert(List<SupplierSrmPo> pos);
}
