package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseApplyOrderSearchReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 采购申请订单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-06-08
 */
@Mapper
public interface PurchaseApplyOrderMapper extends BaseMapper<PurchaseApplyOrderPo> {
    /**
     * 保存草稿
     * @param idReq id和业务类型
     * @return 更新条数
     */
    int enableTempRecord(IdReq idReq);

    /**
     * 分页查询
     *
     * @param param id和业务类型
     * @param page  page
     * @return page
     */
    IPage<PurchaseApplyOrderPo> pageSearch(IPage<PurchaseApplyOrderPo> page, @Param("param") PurchaseApplyOrderSearchReq param);

    /**
     * 导出明细
     *
     * @param param id和业务类型
     * @return page
     */
    List<PurchaseApplyOrderDetailDto> exportList(@Param("param") PurchaseApplyOrderSearchReq param);


    PurchaseApplyOrderPo getById(@Param("id") Long id);

    PurchaseApplyOrderPo getChild(@Param("associateNo") String associateNo, @Param("salePartNum") String salePartNum);
}
