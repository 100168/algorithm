package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.PickingOrderDto;
import com.jiduauto.sps.server.pojo.po.PickingOrderPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.vo.req.PickingOrderPageSearch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;


/**
 * <p>
 * 拣货单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-06-29
 */
@Mapper
public interface PickingOrderMapper extends BaseMapper<PickingOrderPo> {

    IPage<PickingOrderDto> pageSearch(Page<PickingOrderDto> page,@Param("param") PickingOrderPageSearch param);

    /**
     * 使数据生效
     * @param bizType bizType
     * @param orderNo orderNo
     * @return
     */
    int enableRecord(String bizType, String orderNo);
}
