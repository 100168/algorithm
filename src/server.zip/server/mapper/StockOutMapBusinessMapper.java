package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.sdk.pojo.dto.StockOutMapBusinessAllDto;
import com.jiduauto.sps.sdk.pojo.po.StockOutMapBusinessPo;
import com.jiduauto.sps.sdk.pojo.req.StockOutMapBusinessSearchReq;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 库存出库和个业务线的映射 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-12-04
 */
@Mapper
public interface StockOutMapBusinessMapper extends BaseMapper<StockOutMapBusinessPo> {

    IPage<StockOutMapBusinessAllDto> pageSearch(IPage<Object> objectPage,@Param("param") StockOutMapBusinessSearchReq param);

    List<StockOutMapBusinessAllDto> export(@Param("param") StockOutMapBusinessSearchReq param);
}
