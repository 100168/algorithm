package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.baseData.LogisticsDto;
import com.jiduauto.sps.server.pojo.dto.param.LogisticsSearchParam;
import com.jiduauto.sps.server.pojo.po.LogisticsPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.vo.req.baseData.LogisticsPageSearchReq;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 物流时效主数据表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-05-04
 */
public interface LogisticsMapper extends BaseMapper<LogisticsPo> {

    /**
     * 获取物流时效主数据详情
     *
     * @author dong.li
     * @date 5/5/23 2:24 PM
     */
    LogisticsDto detail(@Param(value = "param") LogisticsSearchParam param);

    IPage<LogisticsDto> pageSearch(@Param(value = "page") Page<LogisticsDto> page, @Param(value = "param") LogisticsPageSearchReq param);
}
