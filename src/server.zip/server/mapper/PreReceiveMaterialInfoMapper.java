package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.PreReceiveMaterialInfoPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 预收货零件属性信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-04-24
 */
public interface PreReceiveMaterialInfoMapper extends BaseMapper<PreReceiveMaterialInfoPo> {

}
