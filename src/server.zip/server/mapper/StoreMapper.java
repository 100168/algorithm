package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.po.StorePo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface StoreMapper extends BaseMapper<StorePo> {

    List<StorePo> getByBizTypeStoreCode(@Param("bizType") String bizType, @Param("codes") List<String> codes);
}
