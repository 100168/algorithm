package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.sdk.pojo.dto.PriceLedgerItemDto;
import com.jiduauto.sps.sdk.pojo.fileExport.PriceLedgerItemExportDto;
import com.jiduauto.sps.sdk.pojo.po.PriceLedgerPo;
import com.jiduauto.sps.sdk.pojo.req.PriceLedgerSearchReq;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 价格台账 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-04-16
 */
public interface PriceLedgerMapper extends BaseMapper<PriceLedgerPo> {


    IPage<PriceLedgerItemDto> pageSearch(Page<PriceLedgerItemDto> page, @Param("param") PriceLedgerSearchReq param);

   List<PriceLedgerItemExportDto> exportSearch(@Param("param") PriceLedgerSearchReq param);

    List<PriceLedgerItemDto> listByMaterialCodes(@Param("bizType") String bizType, @Param("materialCodes") List<String> materialCodes);
}
