package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.dto.stock.StockPriceComputeDto;
import com.jiduauto.sps.server.pojo.po.StockPricePo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 库存价值计算结果 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-08-05
 */
public interface StockPriceMapper extends BaseMapper<StockPricePo> {


    List<StockPricePo> getPrice(@Param("bizType") String bizType, @Param("list") List<StockPriceComputeDto.StockPriceComputeDetail> items);

}
