package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.sdk.pojo.po.LingkeWhReissueOrderLogPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 领克仓补差异订单操作记录 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-12-11
 */
public interface LingkeWhReissueOrderLogMapper extends BaseMapper<LingkeWhReissueOrderLogPo> {

}
