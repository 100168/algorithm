package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.dto.LocationsDto;
import com.jiduauto.sps.server.pojo.dto.LocationsInfo;
import com.jiduauto.sps.server.pojo.po.LocationsPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 库存库位信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-30
 */
@Mapper
public interface LocationsMapper extends BaseMapper<LocationsPo> {
    /**
     * 唯一建  查询仓库数据
     * @param bizType
     * @param code
     * @return
     */
    LocationsPo getByBizAndCode(@Param("bizType") String bizType, @Param("code")  String code);

    /**
     * 仓库 区域下 code唯一
     * @param bizType
     * @param code
     * @param wareHouse
     * @return
     */
    LocationsPo getByWareHouseAndCode(@Param("bizType") String bizType, @Param("code")  String code,@Param("wareHouse")  String wareHouse,@Param("areaCode")  String areaCode);

    /**
     * 唯一建  查询仓库数据
     * @param bizType
     * @param codes
     * @return
     */
    List<LocationsPo> getByBizAndCodes(@Param("bizType") String bizType, @Param("codes")  List<String> codes);

    /*
     * @Author O_chaopeng.huang
     * @Description //   根据业务类型与库位编码查询
     * @Date 17:54 2023/2/21
     * @Param
     * @return List<String>
     **/
    List<String> getByWPCodes(@Param("bizType") String bizType,@Param("list") List<String> saleCode);


    /*
     * @Author O_chaopeng.huang
     * @Description //   根据业务类型与库位编码查询
     * @Date 17:53 2023/2/21
     * @Param
     * @return List<WarehousePositionPo>
     **/
    List<LocationsPo> selectWPPList(@Param("bizType") String bizType, @Param("list")List<String> saleWPCode);

    /*
     * @Author O_chaopeng.huang
     * @Description //   库位信息批量添加hcp
     * @Date 17:52 2023/2/21
     * @Param
     * @return
     **/
    int batchInsert(List<LocationsPo> warehousePositionPos);

    LocationsInfo selectLocation(@Param("bizType") String bizType, @Param("materialCode") String materialCode, @Param("list") List<LocationsDto> locations, @Param("isEmpty") boolean isEmpty);
}
