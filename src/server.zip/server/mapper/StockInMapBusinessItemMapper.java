package com.jiduauto.sps.server.mapper;

import com.jiduauto.sps.server.pojo.po.StockInMapBusinessItemPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 入库订单明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-05-29
 */
public interface StockInMapBusinessItemMapper extends BaseMapper<StockInMapBusinessItemPo> {

}
