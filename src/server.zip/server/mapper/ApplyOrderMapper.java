package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.ApplyOrderAndItemDto;
import com.jiduauto.sps.server.pojo.dto.ApplyOrderDto;
import com.jiduauto.sps.server.pojo.po.ApplyOrderPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import com.jiduauto.sps.server.pojo.vo.req.ApplyOrderPageSearchReq;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 领料单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-05-15
 */
@Mapper
public interface ApplyOrderMapper extends BaseMapper<ApplyOrderPo> {


    /**
     * 领料订单分页查询
     *
     * @author dong.li
     * @date 5/15/23 2:44 PM
     */
    IPage<ApplyOrderDto> pageSearch(@Param(value = "page") Page<ApplyOrderDto> page, @Param(value = "param") ApplyOrderPageSearchReq param);
    /**
      * 获取详情
      * @author O_chaopeng.huang
      */
    List<ApplyOrderAndItemDto> selectId(Long id);
    /**
     * 导出查询
     * @author O_chaopeng.huang
     */
    List<ApplyOrderAndItemDto> export(@Param("req") ApplyOrderPageSearchReq req);
}
