package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.server.pojo.dto.stock.StockUpdateAllDto;
import com.jiduauto.sps.server.pojo.dto.stock.StockUpdateOrderAllDto;
import com.jiduauto.sps.server.pojo.dto.stock.StockUpdateOrderItemDto;
import com.jiduauto.sps.server.pojo.po.StockUpdateOrderItemPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 库存调整单详情 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-04-10
 */
@Mapper
public interface StockUpdateOrderItemMapper extends BaseMapper<StockUpdateOrderItemPo> {

    int insertBatch(@Param("list") List<StockUpdateOrderItemPo> collect);

    List<StockUpdateAllDto> selectAndMaterialList(@Param("bizType") String bizType , @Param("stockUpdateNumber")String stockUpdateNumber);

    List<StockUpdateOrderItemPo> selectByStockUpdateNumbers(@Param("bizType") String bizType , @Param("stockUpdateNumbers")List<String> stockUpdateNumberx);

    IPage<StockUpdateOrderItemDto> pageSearch(@Param("page") IPage<StockUpdateOrderItemDto> page, @Param("param") OrderNoReq param);
}

