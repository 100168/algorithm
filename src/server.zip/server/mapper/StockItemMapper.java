package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.dto.stock.StockAllDto;
import com.jiduauto.sps.server.pojo.fileexport.StockExportAllDto;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import com.jiduauto.sps.server.pojo.po.StockOutOrderItemPo;
import com.jiduauto.sps.server.pojo.vo.req.StockSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockSearch;
import java.math.BigDecimal;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Set;

/**
 * <p>
 * 库存明细表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2022-12-29
 */
@Mapper
public interface StockItemMapper extends BaseMapper<StockItemPo> {

    /**
     * 后台配置的唯一字段组合key  查询库存明细记录
     * @param bizConfigField
     * @return
     */
    StockItemPo getByBizConfigField(@Param("bizConfigField") String bizConfigField);


    /**
     * 后台配置的唯一字段组合key  查询库存明细记录  批量
     * @param bizConfigFields
     * @return
     */
    List<StockItemPo> getByBizConfigFields(@Param("bizConfigFields") List<String> bizConfigFields);
    List<StockItemPo> getByBizConfigFieldsV2(@Param("bizConfigFields") Set<String> bizConfigFields);
    /**
     * 分页查询
     * @param page
     * @param params
     * @return
     */
    IPage<StockItemPo> page(@Param("page") Page<StockItemPo> page, @Param("params") StockSearchReq params);

    List<StockItemPo> search( @Param("params") StockSearchReq params);


    /**
     * 批量插入
     * @param list
     * @return
     */
    int batchInsert(List<StockItemPo> list);


    int updateQuantityById(StockItemPo po);


    IPage<StockAllDto> pageSearch(IPage<StockOutOrderItemPo> page, @Param("search") StockSearch pageParam, @Param("hasMaterial")boolean hasMaterial);

    /**
     * 库存明细导出
     * @param param
     * @param lastId
     * @param hasMaterial
     * @return
     */
    List<StockExportAllDto> exportSearch(@Param("search")StockSearch param, @Param("lastId") Long lastId, @Param("hasMaterial")boolean hasMaterial);


    IPage<StockAllDto> pageSearchHandleId(Page<StockOutOrderItemPo> page,@Param("search") StockSearch param,@Param("hasMaterial") boolean hasMaterial);

    /**
     * 出库查询库存 校验库存是否存在
     * @param bizType
     * @param materialCodes
     * @param warehouseCodes
     * @param supplierCodes
     * @param batchNos
     * @param materialStatus
     * @param stockStatus
     * @return
     */
    List<StockItemPo> searchByListParams(@Param("bizType")String bizType,
                                         @Param("materialCodes") Set<String> materialCodes,
                                         @Param("warehouseCodes") Set<String> warehouseCodes,
                                         @Param("supplierCodes") Set<String> supplierCodes ,
                                         @Param("batchNos") Set<String> batchNos,
                                         @Param("materialStatus") Set<Integer> materialStatus,
                                         @Param("stockStatus") Set<Integer> stockStatus);

    /**
     *  返回需要冻结的零件信息  零件+仓库+零件状态（良好）+库存状态（正常）
     */
    List<StockItemPo> queryByMaterialAndWarehouse(@Param("needFrozenStocks") List<InAndOutStockParam> needFrozenStocks, @Param("bizType")String bizType);
    /**
     * 根据查询结果获取零件总库存明细
     *
     * @author O_chaopeng.huang
     */
    BigDecimal selectAndGetItemSum(@Param("search")StockSearch param, @Param("hasMaterial")boolean hasMaterial);
}
