package com.jiduauto.sps.server.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.server.pojo.po.StockUpdateOrderItemPo;
import com.jiduauto.sps.server.pojo.po.StockUpdateOrderPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockUpdateOrderPageSearch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 库存调整单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-04-10
 */
@Mapper
public interface StockUpdateOrderMapper extends BaseMapper<StockUpdateOrderPo> {

    List<StockUpdateOrderPo> selectByStockUpdateNumbers(@Param("bizType") String bizType , @Param("stockUpdateNumbers")List<String> stockUpdateNumbers);

    StockUpdateOrderPo selectByStockUpdateNumber(@Param("bizType") String bizType , @Param("stockUpdateNumber")String stockUpdateNumber);

    IPage<StockUpdateOrderPo> selectPageSearch(IPage<StockUpdateOrderPo> page, @Param("param") StockUpdateOrderPageSearch param);

    List<StockUpdateOrderPo> selectSearch(@Param("param") StockUpdateOrderPageSearch param);
}
