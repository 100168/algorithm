package com.jiduauto.sps.server.facade;

import com.jiduauto.sps.server.pojo.dto.param.MaterialAddParam;

import java.util.List;

/**
 * 零件主数据异步处理方法
 */
public interface MaterialSyncService {

    /**
     * tis 同步零件主数据到SPS
     * @param bizType
     * @param real
     * @param salePartNums
     * @param materialNumbers
     */
     void tisToSps(String bizType, List<MaterialAddParam> real, List<String> salePartNums, List<String> materialNumbers );

}
