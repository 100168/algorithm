package com.jiduauto.sps.server.facade;

import com.jiduauto.sps.sdk.pojo.dto.PriceLedgerItemDto;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.server.pojo.po.StockOutOrderItemPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;

import java.util.List;
import java.util.Map;

/**
 * sps-order 对接接口
 */
public interface SpsOrderInternalService {
    /**
     * 库存操作
     * @param request
     * @param operateType
     * @see com.jiduauto.sps.server.consts.BaseConstants.StockOperationType
     *
     */
    void stockOperate(InAndOutStockRequest request, String operateType);
   /**
     * 库存操作
     * @param request
     * @param operateType
     * @see com.jiduauto.sps.server.consts.BaseConstants.StockOperationType
     *
     */
   BaseResult putOutStockMultiBizType(List<InAndOutStockRequest> request, String operateType);

    /**
     * 查询零件 的框架协议信息和供应商信息 有效期内的。
     * @param materialCodes
     */
    Map<String, List<PriceLedgerItemDto>> searchFrameContracts(List<String> materialCodes, String bizType);

    /**
     * 商城出库结果清单
     *
     * @param req 入参
     */
    BaseResult<List<StockOutOrderItemPo>> getStockOutOrderItemList(OrderNoReq req);
    BaseResult<BaseDataResp> searchBaseData(BaseDataReq req);
}
