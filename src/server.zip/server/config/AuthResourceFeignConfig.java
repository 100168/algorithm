package com.jiduauto.sps.server.config;

import feign.RequestInterceptor;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.context.annotation.Bean;

import javax.annotation.Resource;

/**
 * @author HuangKun
 * @date 2022/11/15
 */
public class AuthResourceFeignConfig {

    @Resource
    private PassportProperties properties;

    @Bean
    public RequestInterceptor requestInterceptor() {
        return requestTemplate -> {
            StringBuilder sb = new StringBuilder();
            long now = System.currentTimeMillis();
            String signature = sb.append("timestamp=").append(now)
                    .append("&url=").append(requestTemplate.url())
                    .append("&identity=").append(properties.getAccess_key())
                    .append("&body=").append(DigestUtils.md5Hex(requestTemplate.requestBody().asBytes()))
                    .append("&secret=").append(properties.getSecret_key()).toString();
            requestTemplate.header("Timestamp", String.valueOf(now));
            requestTemplate.header("x-jidu-accesskey", properties.getAccess_key());
            requestTemplate.header("x-jidu-accesskey-signature", DigestUtils.md5Hex(signature));
        };
    }
}
