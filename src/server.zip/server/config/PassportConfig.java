package com.jiduauto.sps.server.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * @Author di.ma
 * @Date 2022/6/21 14:17
 */
@Data
@Configuration
public class PassportConfig {

    @Value("${passport.secret_key}")
    private String secretKey;

    @Value("${passport.client_id}")
    private String clientId;

}
