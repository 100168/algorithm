package com.jiduauto.sps.server.config;

import feign.Request;
import feign.Retryer;
import org.springframework.context.annotation.Bean;


/**
 * @author tao.wang
 * @date 2023/1/9
 * @description
 */
public class ChargePartnerFeignConfig {

    /**
     * 配置请求重试
     */
    @Bean
    public Retryer feignRetryer() {
        return new Retryer.Default();
    }


    /**
     * 设置请求超时时间
     * 默认
     * public Options() {
     * }
     */
    @Bean
    Request.Options feignOptions() {
        return new Request.Options(5 * 1000, 5 * 1000);
    }
}
