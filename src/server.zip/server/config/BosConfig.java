package com.jiduauto.sps.server.config;

import com.baidubce.auth.DefaultBceCredentials;
import com.baidubce.services.bos.BosClient;
import com.baidubce.services.bos.BosClientConfiguration;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Author xKun
 * @Date 2022/1/26 14:05
 * @Version 1.0
 * @Desc
 */
@Slf4j
@Data
@Configuration
public class BosConfig {

    @Value("${baidu.bos.access_key_id}")
    private String accessKeyId;

    @Value("${baidu.bos.secret_key}")
    private String secretKey;

    /**
     * 公共桶
     */
    @Value("${baidu.bos.bucket_name}")
    private String bucketName;

    @Value("${baidu.bos.endpoint}")
    private String endpoint;


    @Bean
    public BosClient bosClient(){
        BosClientConfiguration config = new BosClientConfiguration();
        config.setCredentials(new DefaultBceCredentials(accessKeyId, secretKey));
        config.setEndpoint(endpoint);
//        config.setProtocol(Protocol.HTTPS);

        BosClient client = new BosClient(config);
        log.info("---------BosClient---------初始化end");
        return client;
    }

}
