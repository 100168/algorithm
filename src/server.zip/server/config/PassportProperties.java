package com.jiduauto.sps.server.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author HuangKun
 * @date 2022/10/11
 */
@Configuration
@Data
@ConfigurationProperties(prefix = "passport")
public class PassportProperties {

    /**
     * 应用客户端id
     */
    String client_id;
    /**
     * 应用秘钥
     */
    String secret_key;
    /**
     * 应用登录跳转地址
     */
    String redirect_uri;
    /**
     * passport服务地址
     */
    String passport_url;


    /**
     * iam-server地址
     */
    String iam_url;


    /**
     * 登陆地址
     */
    String login_url;

    /**
     * 拦截器拦截地址
     */
    String[] include_patterns;
    /**
     * 拦截器排除地址
     */
    String[] exclude_patterns;

    /**
     * 权限管理key值
     */
    String access_key;

    String key="c99c8d5d78d34baaadaaf237e286f4ba";

}
