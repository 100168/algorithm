package com.jiduauto.sps.server.config;

import com.baidubce.auth.DefaultBceCredentials;
import com.baidubce.services.bos.BosClient;
import com.baidubce.services.bos.BosClientConfiguration;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * sps私有同初始化
 */
@Slf4j
@Data
@Configuration
public class BosSpsConfig {

    @Value("${baidu.bos.sps_access_key_id}")
    private String accessKeyId;

    @Value("${baidu.bos.sps_secret_key}")
    private String secretKey;

    /**
     * 公共桶
     */
    @Value("${baidu.bos.sps_bucket_name}")
    private String bucketName;

    /**
     * SPS独有
     */
    @Value("${baidu.bos.sps_bucket_name}")
    private String spsBucketName;

    @Value("${baidu.bos.endpoint}")
    private String endpoint;


    @Bean
    public BosClient bosSpsClient(){
        BosClientConfiguration config = new BosClientConfiguration();
        config.setCredentials(new DefaultBceCredentials(accessKeyId, secretKey));
        config.setEndpoint(endpoint);
//        config.setProtocol(Protocol.HTTPS);

        BosClient client = new BosClient(config);
        log.info("---------BosClient---------初始化end");
        return client;
    }

}
