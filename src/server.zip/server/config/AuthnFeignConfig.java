package com.jiduauto.sps.server.config;

import feign.RequestInterceptor;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.Header;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.context.annotation.Bean;

import javax.annotation.Resource;
import java.nio.charset.Charset;

/**
 * @author HuangKun
 * @date 2022/10/11
 */
public class AuthnFeignConfig {

    @Resource
    private PassportProperties properties;


    @Bean
    public RequestInterceptor requestInterceptor() {
        return requestTemplate -> {
            StringBuilder sb = new StringBuilder();
            long now = System.currentTimeMillis();
            String signature = sb.append("timestamp=").append(now)
                    .append("&url=").append(requestTemplate.url())
                    .append("&identity=").append(properties.getClient_id())
                    .append("&body=").append(DigestUtils.md5Hex(requestTemplate.requestBody().asBytes()))
                    .append("&secret=").append(properties.getSecret_key()).toString();
            requestTemplate.header("Timestamp", String.valueOf(now));
            requestTemplate.header("x-jidu-clientid", properties.getClient_id());
            requestTemplate.header("x-jidu-clientid-signature", DigestUtils.md5Hex(signature));
            System.out.println("");
        };
    }

 /*   @Bean
    public RequestInterceptor requestInterceptor() {
        return requestTemplate -> {
            requestTemplate.header("Authorization", getBasicAuth());
        };
    }*/


    private String getBasicAuth() {
        String auth = "c9290146869a49cc" + ":" + "191f7ee3d4d64d4186f0a19fb66511bd";
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
        String authHeader = "Basic " + new String(encodedAuth);
        return authHeader;
    }
}
