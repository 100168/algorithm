package com.jiduauto.sps.server.config;

import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.listeners.LocalCacheUpdateSubscriber;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.listener.PatternTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;

@Configuration
public class RedisConfig {
    @Bean
    public RedisMessageListenerContainer container(RedisConnectionFactory redisConnectionFactory,MessageListenerAdapter createLocalCacheUpdateSubscriber){
        RedisMessageListenerContainer container = new RedisMessageListenerContainer();
        // 设置连接工厂
        container.setConnectionFactory(redisConnectionFactory);
        // 监听本地缓存更新消息
        container.addMessageListener(createLocalCacheUpdateSubscriber, new PatternTopic(BaseConstants.RocketMqTopic.CACHES_DELETE));
        return container;
    }

    @Bean
    public MessageListenerAdapter createLocalCacheUpdateSubscriber(LocalCacheUpdateSubscriber localCacheUpdateSubscriber){
        return new MessageListenerAdapter(localCacheUpdateSubscriber);
    }
}
