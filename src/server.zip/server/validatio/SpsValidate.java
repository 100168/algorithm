package com.jiduauto.sps.server.validatio;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.vo.req.WarehouseAddReq;
import com.jiduauto.sps.server.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.LocalDateTime;

/**
 * sps内部自定义校验
 */
@Slf4j
public class SpsValidate {

    public static void main(String[] args) {
        WarehouseAddReq warehouseAddReq = new WarehouseAddReq();
        warehouseAddReq.setCode("1");
        warehouseAddReq.setBizType("1");
        warehouseAddReq.setAddress("df");
        warehouseAddReq.setContact("eraef");
        warehouseAddReq.setCreateTime(LocalDateTime.now());
        warehouseAddReq.setCreateUser("huan");
        warehouseAddReq.setName("上海");
        warehouseAddReq.setOperateType("SAVE");
        warehouseAddReq.setOrganizationCode("123");
        warehouseAddReq.setPhoneNumber("13111111111");
//        validate(warehouseAddReq,"UPDATE");
        System.out.printf(JSON.toJSONString(warehouseAddReq));

    }

    public static void validate(Object obj, String operation){
        Field[] fields = obj.getClass().getDeclaredFields();
        StringBuilder sb = new StringBuilder();
        for(Field field:fields){
            String underlineCase = StrUtil.toUnderlineCase(field.getName());
            if ("$jacocoData".equals(field.getName()) ||
                    "$jacoco_data".equals(field.getName()) ||
                    "$jacoco_data".equals(underlineCase)) {
                continue;
            }
            SpsNotNull spsNotNull =  field.getAnnotation(SpsNotNull.class);
            Object value = getFieldValueByName(field.getName(),obj);
            if(value == null && spsNotNull != null){
                String[] groups = spsNotNull.groups();
                if(groups.length == 0 || contants(groups, operation)){
                    sb.append(spsNotNull.message()).append(";");
                }
            }
        }
        if(sb.length() > 0){
            throw new BizException(sb.toString());
        }
    }

    public static boolean contants(String[] array, String value){
        if(StringUtils.isBlank(value)){
            return true;
        }
        for(String arr:array){
            if(arr.equals(value)){
                return true;
            }
        }
        return false;
    }

    private static Object getFieldValueByName(String fieldName, Object o) {
        try {
            String firstLetter = fieldName.substring(0, 1).toUpperCase();
            String getter = "get" + firstLetter + fieldName.substring(1);
            Method method = o.getClass().getMethod(getter, new Class[] {});
            Object value = method.invoke(o, new Object[] {});
            return value;
        } catch (Exception e) {
            log.error("获取属性值失败！" + e, e);
        }
        return null;
    }
}
