package com.jiduauto.sps.server.validatio;

import javax.validation.constraints.NotNull;
import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.util.List;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.ElementType.TYPE_USE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 自定义 空判断 校验，可以动态置顶组
 */
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE })
@Retention(RUNTIME)
@Documented
public @interface SpsNotNull {

    /**
     * 描述提示
     * @return
     */
    String message() default "";

    /**
     * 分组 同一个接口， 不同的逻辑，可写不同的空校验规则
     * @return
     */
    String[] groups() default {};
}
