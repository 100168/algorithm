package com.jiduauto.sps.server.threads;

import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.po.PurchaseForecastPo;
import com.jiduauto.sps.server.service.IPurchaseForecastService;

import java.util.concurrent.Callable;

/**
 * 多线程处理 下发 采购预测 到SAP
 */
public class PurchaseForeCastIssuedThread implements Callable {
    private IPurchaseForecastService purchaseForecastService;
    private PurchaseForecastPo po;
    private MaterialPo materialPo;
    private String bizType;

    public PurchaseForeCastIssuedThread(IPurchaseForecastService purchaseForecastService, PurchaseForecastPo po, MaterialPo materialPo, String bizType) {
        this.purchaseForecastService = purchaseForecastService;
        this.po = po;
        this.materialPo = materialPo;
        this.bizType = bizType;
    }

    @Override
    public Object call() throws Exception {
        return purchaseForecastService.issuedForecast(po,materialPo,bizType);
    }
}
