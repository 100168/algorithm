package com.jiduauto.sps.server.threads;

import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.po.PurchaseForecastPo;
import com.jiduauto.sps.server.service.IPurchaseForecastService;

import java.util.List;
import java.util.concurrent.Callable;

/**
 * 多线程处理 下发 采购预测 到SAP
 */
public class PurchaseForeCastIssued2Thread implements Callable {
    private IPurchaseForecastService purchaseForecastService;
    private List<PurchaseForecastPo> pos;
    private String bizType;
    /**
     * 当前操作用户
     */
    private String currentUser;

    public PurchaseForeCastIssued2Thread(IPurchaseForecastService purchaseForecastService,
                                         List<PurchaseForecastPo> pos,
                                         String bizType,
                                         String currentUser) {
        this.purchaseForecastService = purchaseForecastService;
        this.pos = pos;
        this.bizType = bizType;
        this.currentUser = currentUser;
    }

    @Override
    public Object call() throws Exception {
        return purchaseForecastService.issued2Srm(bizType,pos,currentUser);
    }
}
