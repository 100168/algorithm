package com.jiduauto.sps.server.threads;

import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.server.pojo.http.HttpBaseResponse;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.service.IStockService;
import com.jiduauto.sps.server.utils.HttpBasicAuthUtil;

import java.util.concurrent.Callable;

public class SAPThread implements Callable {
String json;

    public SAPThread(String json) {
        this.json = json;
    }

    @Override
    public Object call() throws Exception {
        HttpBaseResponse response = HttpBasicAuthUtil.invoke(json, "SYS_S4D",
                "Aa12345678", "http://devpodapp.jiduauto.com:50000/RESTAdapter/SPS/MM033");

        return response;
    }
}
