package com.jiduauto.sps.server.threads;

import com.jiduauto.sps.server.mapper.MaterialMapper;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;

import com.jiduauto.sps.server.utils.UserUtil;
import java.util.List;
import java.util.concurrent.Callable;
import lombok.extern.slf4j.Slf4j;

/**
 * 零件主数据到入时 异步处理
 */
@Slf4j
public class MaterialUpdateThread implements Callable<BaseResult<String>> {

    private MaterialMapper materialMapper;
    private List<MaterialPo> materialPos;

    public MaterialUpdateThread(MaterialMapper materialMapper, List<MaterialPo> materialPos) {
        this.materialMapper = materialMapper;
        this.materialPos = materialPos;
    }

    @Override
    public BaseResult<String> call() throws Exception {
        try{
            for(MaterialPo materialPo:materialPos){
                materialMapper.updateById(materialPo);
            }
        }catch (Exception e){
            BaseResult<String> baseResult =   BaseResult.error(-1,"处理失败:"+e.getMessage());
            baseResult.setData(materialPos.get(0).getSalePartNum());
            return baseResult;
        }
        return BaseResult.OK();
    }
}
