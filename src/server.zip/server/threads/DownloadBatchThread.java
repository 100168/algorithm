package com.jiduauto.sps.server.threads;

import cn.hutool.http.HttpUtil;

import java.util.concurrent.Callable;

public class DownloadBatchThread implements Callable<byte[]> {

    public DownloadBatchThread(String resourceUrl) {
        this.resourceUrl = resourceUrl;
    }

    String resourceUrl;
    @Override
    public byte[] call() throws Exception {
        return HttpUtil.downloadBytes(resourceUrl);
    }
}
