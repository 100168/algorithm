package com.jiduauto.sps.server.excel;

import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.excel.check.BatchPreCheck;
import com.jiduauto.sps.server.mapper.SalePriceApprovalDetailMapper;
import com.jiduauto.sps.server.mapper.SalePriceApprovalMapper;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.po.SalePriceApprovalDetailPo;
import com.jiduauto.sps.server.pojo.po.SalePriceApprovalPo;
import com.jiduauto.sps.server.pojo.vo.req.SalePriceApprovalDetailImportReq;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import com.jiduauto.sps.server.utils.UserUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class SalePriceApprovalDetailImportHandler extends ExtendImportHandler<SalePriceApprovalDetailImportReq> {

    public final static String KEY_MATERIAL_MAP = "KEY_MATERIAL_MAP";
    public final static String KEY_SALE_PRICE_APPROVAL = "KEY_SALE_PRICE_APPROVAL";
    public final static String KEY_RATE_AFTER_VAT = "KEY_RATE_AFTER_VAT";

    @Resource
    private SalePriceApprovalMapper salePriceApprovalMapper;

    @Resource
    private SalePriceApprovalDetailMapper salePriceApprovalDetailMapper;


    public SalePriceApprovalDetailImportHandler(List<BatchPreCheck<SalePriceApprovalDetailImportReq>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchPreChecks;
        super.eClass = SalePriceApprovalDetailImportReq.class;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    protected void saveData(List<ExtendExportDto<SalePriceApprovalDetailImportReq>> extendExportDto) {
        Map<String, MaterialPo> materialMap = ExcelThreadLocalHolder.getObject(KEY_MATERIAL_MAP, Map.class);
        SalePriceApprovalPo salePriceApprovalPo = ExcelThreadLocalHolder.getObject(KEY_SALE_PRICE_APPROVAL, SalePriceApprovalPo.class);
        BigDecimal rateAfterVat = ExcelThreadLocalHolder.getObject(KEY_RATE_AFTER_VAT, BigDecimal.class);
        List<SalePriceApprovalDetailPo> salePriceApprovalDetailPos = extendExportDto.stream().map(ExtendExportDto::getT).map(item -> {
            SalePriceApprovalDetailPo save = new SalePriceApprovalDetailPo();
            BeanUtils.copyProperties(item, save);
            save.setBizType(BizTypeThreadHolder.getBizType());
            save.setApprovalId(salePriceApprovalPo.getId());
            save.setPriceBeforeVat(new BigDecimal(item.getPriceBeforeVatStr()));
            save.setPriceAfterVat(save.getPriceBeforeVat().multiply(rateAfterVat));
            save.setMaterialNumber(materialMap.get(item.getSalePartNum()).getNumber());
            LocalDateTime effectiveStartTime = LocalDate.parse(item.getEffectiveStartDateStr(), DateTimeFormatter.ofPattern(BaseConstants.DatePattern.NONE_DATE)).atTime(LocalTime.MIN);
            save.setEffectiveStartTime(effectiveStartTime);
            return save;
        }).collect(Collectors.toList());

        int rows = salePriceApprovalDetailMapper.batchInsert(salePriceApprovalDetailPos);
        if(rows > 0){
            salePriceApprovalMapper.updateDetailQty(salePriceApprovalPo.getId(), salePriceApprovalPo.getDetailQty() + rows, UserUtil.getUserName());
        }
    }
}
