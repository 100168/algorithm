package com.jiduauto.sps.server.excel;

import lombok.Data;

import java.io.Serializable;

/**
 * @author tao.wang
 * @date 2022/12/19
 * @description
 */
@Data
public class ExtendExportDto<T> implements Serializable {

    private T t;

    private String checkResult;


    public ExtendExportDto(T t, String checkResult) {
        this.t = t;
        this.checkResult = checkResult;
    }
}
