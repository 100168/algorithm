package com.jiduauto.sps.server.excel;


import cn.hutool.core.collection.CollUtil;
import com.google.common.collect.Lists;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author tao.wang
 * @date 2022/8/15
 * @description
 */
public class AsnImportThreadHolder {

    private static final ThreadLocal<Map<String, List<String>>> ASN_THREAD_LOCAL = new ThreadLocal<>();

    public static void setAsnNo(String k, String v) {
        Map<String, List<String>> asnMap = ASN_THREAD_LOCAL.get();
        if (CollUtil.isEmpty(asnMap)) {
            ASN_THREAD_LOCAL.set(new HashMap<>());
        }
        if (asnMap.containsKey(k)) {
            List<String> saleNos = asnMap.get(k);
            saleNos.add(v);
        } else {
            asnMap.put(k, Lists.newArrayList(v));
            ASN_THREAD_LOCAL.set(asnMap);
        }
    }

    public static Boolean containSalesNo(String k, String v) {
        Map<String, List<String>> asnMap = ASN_THREAD_LOCAL.get();
        if (CollUtil.isEmpty(asnMap)) {
            ASN_THREAD_LOCAL.set(new HashMap<>());
            return false;
        }
        if (!asnMap.containsKey(k)) {
            return false;
        }
        List<String> saleNos = asnMap.get(k);
        if (saleNos.contains(v)) {
            return true;
        }
        return false;
    }

    public static void remove() {
        ASN_THREAD_LOCAL.remove();
    }
}
