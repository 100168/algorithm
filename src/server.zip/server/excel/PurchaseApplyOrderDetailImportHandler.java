package com.jiduauto.sps.server.excel;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.convertor.PurchaseApplyOrderDetailConvertor;
import com.jiduauto.sps.server.excel.check.BatchPreCheck;
import com.jiduauto.sps.server.excel.check.PurchaseApplyOrderDetailBatchPreCheck;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderDetailPo;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseApplyOrderDetailImportReq;
import com.jiduauto.sps.server.service.IPurchaseApplyOrderDetailService;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import com.jiduauto.sps.server.utils.DateUtils;
import lombok.val;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author panjian
 */
@Component
public class PurchaseApplyOrderDetailImportHandler extends ExtendImportHandler<PurchaseApplyOrderDetailImportReq> {


    @Resource
    private IPurchaseApplyOrderDetailService purchaseApplyOrderDetailService;
    @Resource
    private PurchaseApplyOrderDetailConvertor purchaseApplyOrderDetailConvertor;

    public PurchaseApplyOrderDetailImportHandler(
            List<BatchPreCheck<PurchaseApplyOrderDetailImportReq>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        batchChecks = batchPreChecks;
        super.eClass = PurchaseApplyOrderDetailImportReq.class;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void saveData(List<ExtendExportDto<PurchaseApplyOrderDetailImportReq>> extendExportDtos) {
        String bizType = BizTypeThreadHolder.getBizType();
        Long orderId = ExcelThreadLocalHolder.getLong(PurchaseApplyOrderDetailBatchPreCheck.KEY_PURCHASE_APPLY_ORDER_ID);
        val salePartNums = extendExportDtos.stream().map(ExtendExportDto::getT)
                .map(PurchaseApplyOrderDetailImportReq::getSalePartNum).collect(
                        Collectors.toList());
        val detailPoMap = purchaseApplyOrderDetailService.mapPurchaseApplyOrderDetailPo(
                bizType, orderId, salePartNums);

        List<PurchaseApplyOrderDetailPo> addList = new ArrayList<>();
        List<PurchaseApplyOrderDetailPo> updateList = new ArrayList<>();
        PurchaseApplyOrderDetailPo lastDetailPo = purchaseApplyOrderDetailService.getLastDetailPo(orderId);
        int nextLineNo = Objects.isNull(lastDetailPo) ? BaseConstants.LineNo.START : lastDetailPo.getLineNo() + BaseConstants.LineNo.STEP;
        for (ExtendExportDto<PurchaseApplyOrderDetailImportReq> exportDto : extendExportDtos) {
            val item = exportDto.getT();
            val detailPo = purchaseApplyOrderDetailConvertor.importReqToPo(item);
            detailPo.setBizType(bizType);
            detailPo.setOrderId(orderId);
            detailPo.setContractNo(item.getContractNo());
            detailPo.setLedgerCode(item.getLedgerCode());
            detailPo.setEstArrivalTime(StrUtil.nullToEmpty(item.getEstArrivalTime()));
            if (StrUtil.isNotEmpty(item.getEstArrivalTime())){
                DateTime dateTime = DateUtil.parse(item.getEstArrivalTime(), DateUtils.SHORT_DATE_FORMAT);
                detailPo.setEstArrivalTime(dateTime.toDateStr());
            }
            detailPo.setOrderUnit(item.getOrderUnit());
            val po = detailPoMap.get(item.getSalePartNum());
            if (Objects.isNull(po)) {
                detailPo.setLineNo(nextLineNo);
                addList.add(detailPo);
                nextLineNo += BaseConstants.LineNo.STEP;
                continue;
            }
            detailPo.setId(po.getId());
            updateList.add(detailPo);
        }
        if (!updateList.isEmpty()) {
            purchaseApplyOrderDetailService.updateBatchById(updateList);
        }
        if (!addList.isEmpty()) {
            purchaseApplyOrderDetailService.saveBatch(addList);
        }
    }
}
