package com.jiduauto.sps.server.excel;

import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.write.handler.SheetWriteHandler;
import com.alibaba.excel.write.handler.context.SheetWriteHandlerContext;
import com.jiduauto.sps.sdk.utils.FieldUtil;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import com.jiduauto.sps.server.service.ICommonService;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.util.CellRangeAddressList;

import java.util.*;

/**
 * 自定义拦截器.对第一列第一行和第二行的数据新增下拉框，显示 测试1 测试2
 */
@Slf4j
public class CustomSheetWriteHandler implements SheetWriteHandler {

    private final ICommonService commonService;

    public CustomSheetWriteHandler(ICommonService commonService) {
        this.commonService = commonService;
    }

    @Override
    public void afterSheetCreate(SheetWriteHandlerContext context) {
        String bizType = BizTypeThreadHolder.getBizType();
        log.info("第{}个Sheet写入成功。", context.getWriteSheetHolder().getSheetNo());
        // 区间设置 第一列第一行和第二行的数据。由于第一行是头，所以第一、二行的数据实际上是第二三行
        Collection<String> includeColumnFieldNames = context.getWriteSheetHolder().getIncludeColumnFieldNames();
        if (includeColumnFieldNames.isEmpty()) {
            return;
        }
        Map<Integer, Head> headMap = context.getWriteSheetHolder().getExcelWriteHeadProperty().getHeadMap();
        int i = 0;
        for (Map.Entry<Integer, Head> entry : headMap.entrySet()) {
            String str = entry.getValue().getFieldName();
            CellRangeAddressList cellRangeAddressList = new CellRangeAddressList(1, 100, i, i);
            DataValidationHelper helper = context.getWriteSheetHolder().getSheet().getDataValidationHelper();
            String[] arr = null;
            String materialSort = FieldUtil.getFieldName(StockItemPo::getMaterialSort);
            String projectCode = FieldUtil.getFieldName(StockItemPo::getProjectCode);
            String stageCode = FieldUtil.getFieldName(StockItemPo::getStageCode);
            String materialStatus = FieldUtil.getFieldName(StockItemPo::getMaterialStatus);
            String stockStatus = FieldUtil.getFieldName(StockItemPo::getStockStatus);

            if (str.equals(materialSort)) {
                arr = commonService.getDictItemDescList(DictEnum.MaterialSort).toArray(new String[0]);
            }
            if (str.equals(projectCode)) {
                arr = commonService.dictItemList(bizType, DictEnum.Project.getDictCode()).toArray(new String[0]);
            }
            if (str.equals(stageCode)) {
                arr = commonService.dictItemList(bizType, DictEnum.Stage.getDictCode()).toArray(new String[0]);
            }
            if (str.equals(materialStatus)) {
                arr = commonService.getDictItemDescList(DictEnum.MaterialStockStatus).toArray(new String[0]);
            }
            if (str.equals(stockStatus)) {
                arr = commonService.getDictItemDescList(DictEnum.StockStatus).toArray(new String[0]);
            }
            if (arr == null || arr.length == 0) {
                i++;
                continue;
            }
            DataValidationConstraint constraint = helper.createExplicitListConstraint(arr);
            DataValidation dataValidation = helper.createValidation(constraint, cellRangeAddressList);
            context.getWriteSheetHolder().getSheet().addValidationData(dataValidation);
            i++;
        }
    }
}