package com.jiduauto.sps.server.excel;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.style.column.SimpleColumnWidthStyleStrategy;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.excel.check.BatchPreCheck;
import com.jiduauto.sps.server.excel.check.PreCheck;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.handler.BaseImportHandler;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import com.jiduauto.sps.server.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;


/**
 * @author tao.wang
 * @date 2022/12/16
 * @description 导入扩展类  将校验逻辑解耦
 * 只需要提供 实现 precheck接口和提供已个consumer
 */
@Slf4j
public abstract class ExtendImportHandler<E> extends BaseImportHandler<E, ExtendExportDto<E>> {

    protected List<BatchPreCheck<E>> batchChecks;

    protected List<PreCheck<E>> checks;

    protected Class<E> eClass;

    protected List<String> headList;

    protected BosServiceImpl bosService;

    protected Integer MAX_LIMIT;


    @PostConstruct
    private void initHeadList() {
        headList = ExcelUtils.headList(eClass);
    }

    @Override
    public List<ImportDataInfo<E>> readFile(MultipartFile file) throws BizException {
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<E>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, eClass, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> fileHeads = readCellDataList.stream().map(ReadCellData::getStringValue).collect(Collectors.toList());
                    if (!Objects.equals(headList, fileHeads)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    /**
                     * 可选择的数量校验
                     */
                    if (Objects.nonNull(MAX_LIMIT) && rowNum > MAX_LIMIT) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");

                    }
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        E data = (E) o;
                        info.setData(data);
                        importList.add(info);
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;
        } catch (Exception e) {
            log.error("订单日历导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(e.getMessage());
        }
    }

    /**
     * 抽象校验方法
     *
     * @param list
     * @return
     * @throws BizException
     */
    @Override
    protected ImportReturnDataInfo<ExtendExportDto<E>> process(List<ImportDataInfo<E>> list) throws BizException {
        log.info("extendImportHandler-process-start");
        ImportReturnDataInfo<ExtendExportDto<E>> importReturnDataInfo = new ImportReturnDataInfo();
        List<ExtendExportDto<E>> extendExportDtos = list.stream().map(item -> new ExtendExportDto<>(item.getData(), "")).collect(Collectors.toList());
        if(!CollectionUtils.isEmpty(checks)){
            extendExportDtos.forEach(item -> {
                for (PreCheck<E> preCheck : checks) {
                    preCheck.invoke(item);
                }
            });
        }
        if (!CollectionUtils.isEmpty(batchChecks)){
            for (BatchPreCheck<E> batchPreCheck : batchChecks){
                batchPreCheck.invoke(extendExportDtos);
            }
        }

       // List<ExtendExportDto<E>> passList = Optional.ofNullable(extendExportDtos).orElse(Lists.newArrayList()).stream().filter(o -> StrUtil.isEmpty(o.getCheckResult())).collect(Collectors.toList());

        importReturnDataInfo.setData(extendExportDtos);
       // importReturnDataInfo.setError(errorList);
        return importReturnDataInfo;
    }

    /**
     * 根据结果 保存或者 导出错误
     *
     * @param returnDataInfo
     * @throws BizException
     */
    @Override
    protected void afterProcess(ImportReturnDataInfo<ExtendExportDto<E>> returnDataInfo) throws BizException {
        log.info("extendImportHandler-afterProcess-start");
        List<ExtendExportDto<E>> extendExportDtos = returnDataInfo.getData();
        List<ExtendExportDto<E>> errorList = Optional.ofNullable(extendExportDtos).orElse(Lists.newArrayList()).stream().filter(o -> StrUtil.isNotEmpty(o.getCheckResult())).collect(Collectors.toList());
        //没有错误
        if (!CollectionUtils.isEmpty(errorList)) {
            String fileKey = createErrExcel(returnDataInfo.getData());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        }
        // 校验成功-导入
        if (!CollectionUtils.isEmpty(returnDataInfo.getData())) {
            // 保存
            saveData(returnDataInfo.getData());
            returnDataInfo.setImportFlag(true);
        }
    }


    /**
     * 上传错误文件
     *
     * @param error
     * @return
     */
    public String createErrExcel(List<ExtendExportDto<E>> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            EasyExcel.write(excelFile.getAbsoluteFile())
                    .registerWriteHandler(new SimpleColumnWidthStyleStrategy(20))
                    .head(head()).sheet("失败列表")
                    .doWrite(data(error));
        } catch (Exception e) {
            log.error("extendImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }
///上传 bos
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(excelFile);
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("extendImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    log.info(ExceptionUtils.getStackTrace(e));
                }
            }
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }

    /**
     * 生成导出表头
     *
     * @return
     */
    public List<List<String>> head() {
        List<List<String>> headList = new ArrayList<List<String>>();
        List<String> head = ExcelUtils.headList(eClass);
        head.forEach(h->{
            headList.add( Lists.newArrayList(h));
           });
        headList.add(Lists.newArrayList("报错信息"));
        return headList;
    }

    /**
     * 输出数据
     * @param error
     * @return
     */
    public List<List<Object>> data(List<ExtendExportDto<E>> error) {
        return error.stream().map(err -> {
            List<Object> list = Lists.newArrayList();
            E t = err.getT();
            Field[] fields = ReflectUtil.getFields(t.getClass());
            for (Field field : fields) {
                boolean annotationPresent = field.isAnnotationPresent(ExcelProperty.class);
                if (annotationPresent) {
                    list.add(ReflectUtil.getFieldValue(t, field));
                }
            }
            list.add(err.getCheckResult());
            return list;
        }).collect(Collectors.toList());
    }

    @Override
    public void release() {
        super.release();
    }

    /**
     * 数据保存 子类实现 目前通过consumer 之后可以通过继承实现
     *
     * @param extendExportDto
     */
    protected abstract void saveData(List<ExtendExportDto<E>> extendExportDto);
}
