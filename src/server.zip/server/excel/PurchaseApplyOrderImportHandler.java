package com.jiduauto.sps.server.excel;

import com.jiduauto.sps.server.Enum.GenerateSerialEnum;
import com.jiduauto.sps.server.Enum.PRTypeEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.convertor.PurchaseApplyOrderConvertor;
import com.jiduauto.sps.server.convertor.PurchaseApplyOrderDetailConvertor;
import com.jiduauto.sps.server.excel.check.BatchPreCheck;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseApplyOrderImportReq;
import com.jiduauto.sps.server.service.IPurchaseApplyOrderDetailService;
import com.jiduauto.sps.server.service.IPurchaseApplyOrderService;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import com.jiduauto.sps.server.utils.GenerateSerialNoUtil;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * @author panjian
 */
@Component
public class PurchaseApplyOrderImportHandler extends ExtendImportHandler<PurchaseApplyOrderImportReq> {


    @Resource
    private IPurchaseApplyOrderDetailService purchaseApplyOrderDetailService;
    @Resource
    private PurchaseApplyOrderDetailConvertor purchaseApplyOrderDetailConvertor;
    @Resource
    private PurchaseApplyOrderConvertor purchaseApplyOrderConvertor;
    @Resource
    private GenerateSerialNoUtil generateSerialNoUtil;

    @Resource

    private IPurchaseApplyOrderService purchaseApplyOrderService;

    public PurchaseApplyOrderImportHandler(
            List<BatchPreCheck<PurchaseApplyOrderImportReq>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        batchChecks = batchPreChecks;
        super.eClass = PurchaseApplyOrderImportReq.class;
    }

    //todo
    //按相同公司代码，相同收货仓库，相同供应商，生成不同的待提交状态的采购申请，
    //相同物料号、相同的预计到货日期（匹配供应商日历后），进行合并
    //相同物料号，不同的预计到货日期，拆分到不同的采购申请
    //零件为DB总成件，一个物料号+预计到货日期维度，生成单独的采购申请，
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void saveData(List<ExtendExportDto<PurchaseApplyOrderImportReq>> extendExportDtos) {
        String bizType = BizTypeThreadHolder.getBizType();
        List<PurchaseApplyOrderDetailPo> addDetailList = new ArrayList<>();

        //总成件订单
        List<PurchaseApplyOrderImportReq> dbs = extendExportDtos.stream().map(ExtendExportDto::getT).filter(PurchaseApplyOrderImportReq::getDbFlag).collect(Collectors.toList());
        for (PurchaseApplyOrderImportReq db : dbs) {
            PurchaseApplyOrderPo purchaseApplyOrderPo = purchaseApplyOrderConvertor.toPo(db);
            purchaseApplyOrderPo.setOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.PR, bizType));
            purchaseApplyOrderPo.setOrderType(PRTypeEnum.DB.getCode());
            purchaseApplyOrderPo.setBizType(bizType);
            PurchaseApplyOrderDetailPo detailPo = purchaseApplyOrderDetailConvertor.importReqToPo(db);
            detailPo.setBizType(bizType);
            detailPo.setLineNo(BaseConstants.LineNo.START);
            purchaseApplyOrderService.save(purchaseApplyOrderPo);
            detailPo.setOrderId(purchaseApplyOrderPo.getId());
            addDetailList.add(detailPo);
        }
        Map<String, List<PurchaseApplyOrderImportReq>> map = extendExportDtos.stream().map(ExtendExportDto::getT).filter(e -> !e.getDbFlag())
                .collect(Collectors.groupingBy(PurchaseApplyOrderImportReq::getOrderType));
        for (Map.Entry<String, List<PurchaseApplyOrderImportReq>> entry : map.entrySet()) {
            List<PurchaseApplyOrderImportReq> purchaseApplyOrderImportReqs = entry.getValue();
            Map<String, List<PurchaseApplyOrderImportReq>> groupByMap = purchaseApplyOrderImportReqs.stream().collect(Collectors.groupingBy(e -> e.getCompanyCode() + e.getWarehouseCode() + e.getSupplierCode()));

            for (Map.Entry<String, List<PurchaseApplyOrderImportReq>> groupEntry : groupByMap.entrySet()) {
                List<PurchaseApplyOrderImportReq> entryValue = groupEntry.getValue();
                Map<String, List<PurchaseApplyOrderImportReq>> salePartMap = entryValue.stream().sorted(Comparator.comparing(PurchaseApplyOrderImportReq::getEstArrivalTime)).collect(Collectors.groupingBy(PurchaseApplyOrderImportReq::getSalePartNum));
                ConcurrentHashMap<String, Integer> indexMap = new ConcurrentHashMap<>();
                for (String key : salePartMap.keySet()) {
                    indexMap.put(key, 0);
                }
                while (!indexMap.isEmpty()) {
                    PurchaseApplyOrderPo purchaseApplyOrderPo = null;
                    int maxLine = 0;
                    for (String key : indexMap.keySet()) {
                        List<PurchaseApplyOrderImportReq> salePartEntryValue = salePartMap.get(key);
                        int size = salePartEntryValue.size();
                        Integer index = indexMap.get(key);
                        int firstIndex = index;
                        PurchaseApplyOrderImportReq firstReq = salePartEntryValue.get(firstIndex);
                        BigDecimal firstQty = new BigDecimal(firstReq.getQty());
                        while (index < size - 1 && Objects.equals(salePartEntryValue.get(index).getEstArrivalTime(), salePartEntryValue.get(index + 1).getEstArrivalTime())) {
                            index++;
                            firstQty = firstQty.add(new BigDecimal(salePartEntryValue.get(index).getQty()));
                        }
                        if (purchaseApplyOrderPo == null) {
                            purchaseApplyOrderPo = purchaseApplyOrderConvertor.toPo(firstReq);
                            purchaseApplyOrderPo.setOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.PR, bizType));
                            purchaseApplyOrderPo.setOrderType(PRTypeEnum.getByName(firstReq.getOrderType()).getCode());
                            purchaseApplyOrderPo.setBizType(bizType);
                            purchaseApplyOrderService.save(purchaseApplyOrderPo);
                        }
                        indexMap.put(key, ++index);
                        PurchaseApplyOrderDetailPo detailPo = purchaseApplyOrderDetailConvertor.importReqToPo(firstReq);
                        detailPo.setBizType(bizType);
                        detailPo.setLineNo(maxLine + BaseConstants.LineNo.STEP);
                        detailPo.setOrderId(purchaseApplyOrderPo.getId());
                        detailPo.setContractNo(firstReq.getContractNo());
                        detailPo.setLedgerCode(firstReq.getLedgerCode());
                        detailPo.setQty(firstQty);
                        addDetailList.add(detailPo);
                        maxLine = detailPo.getLineNo();
                        if (index == size) {
                            indexMap.remove(key);
                        }
                    }
                }
            }
        }
        purchaseApplyOrderDetailService.saveBatch(addDetailList);
    }
}
