package com.jiduauto.sps.server.excel;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.jiduauto.sps.server.convertor.PurchaseReturnOrderDetailConvertor;
import com.jiduauto.sps.server.excel.check.BatchPreCheck;
import com.jiduauto.sps.server.excel.check.PurchaseReturnOrderDetailBatchPreCheck;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderDetailPo;
import com.jiduauto.sps.server.pojo.vo.req.PurchaseReturnOrderDetailImportReq;
import com.jiduauto.sps.server.service.IPurchaseReturnOrderDetailService;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import com.jiduauto.sps.server.utils.DateUtils;

import lombok.val;

/**
 * @author panjian
 */
@Component
public class PurchaseReturnOrderDetailImportHandler extends ExtendImportHandler<PurchaseReturnOrderDetailImportReq> {


    @Resource
    private IPurchaseReturnOrderDetailService purchaseReturnOrderDetailService;
    @Resource
    private PurchaseReturnOrderDetailConvertor purchaseReturnOrderDetailConvertor;

    public PurchaseReturnOrderDetailImportHandler(
            List<BatchPreCheck<PurchaseReturnOrderDetailImportReq>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchPreChecks;
        super.eClass = PurchaseReturnOrderDetailImportReq.class;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void saveData(List<ExtendExportDto<PurchaseReturnOrderDetailImportReq>> extendExportDtos) {
        String bizType = BizTypeThreadHolder.getBizType();
        String orderNo = ExcelThreadLocalHolder.getString(PurchaseReturnOrderDetailBatchPreCheck.KEY_RETURN_ORDER_NO);
        val salePartNums = extendExportDtos.stream().map(ExtendExportDto::getT)
                .map(PurchaseReturnOrderDetailImportReq::getSalePartNum).collect(
                        Collectors.toList());
        val detailPoMap = purchaseReturnOrderDetailService.mapPurchaseReturnOrderDetailPo(
                bizType, orderNo, salePartNums);

        List<PurchaseReturnOrderDetailPo> addList = new ArrayList<>();
        List<PurchaseReturnOrderDetailPo> updateList = new ArrayList<>();
        for (ExtendExportDto<PurchaseReturnOrderDetailImportReq> exportDto : extendExportDtos) {
            val item = exportDto.getT();
            val detailPo = purchaseReturnOrderDetailConvertor.importReqToPo(item);
            detailPo.setBizType(bizType);
            detailPo.setOrderNo(orderNo);
            LocalDateTime priceTime = DateUtils.parse(item.getPriceTime(), DateUtils.SHORT_DATE_FORMAT);
            detailPo.setPriceTime(String.valueOf(priceTime));
            val po = detailPoMap.get(item.getSalePartNum());
            if (Objects.isNull(po)) {
                addList .add(detailPo);
                continue;
            }
            detailPo.setId(po.getId());
            updateList.add(detailPo);
        }
        if (!updateList.isEmpty()) {
            purchaseReturnOrderDetailService.updateBatchById(updateList);
        }
        if (!addList.isEmpty()) {
            purchaseReturnOrderDetailService.saveBatch(addList);
        }
    }

}
