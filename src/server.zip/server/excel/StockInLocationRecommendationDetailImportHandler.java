package com.jiduauto.sps.server.excel;


import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.google.common.collect.Lists;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.excel.check.BatchPreCheck;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.dto.StockInLocationRecommendationDetailImportDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.StockInLocationRecommendationDetailPo;
import com.jiduauto.sps.server.pojo.po.StockInLocationRecommendationPo;
import com.jiduauto.sps.server.service.ICommonService;
import com.jiduauto.sps.server.service.IStockInLocationRecommendationDetailService;
import com.jiduauto.sps.server.service.IStockInLocationRecommendationService;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import com.jiduauto.sps.server.service.impl.StockInLocationRecommendationServiceImpl;
import com.jiduauto.sps.server.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.*;
import java.util.stream.Collectors;

import static com.jiduauto.sps.server.excel.check.StockInLocationRecommendationDetailBatchPreCheck.KEY_CONFIG_STR;
import static com.jiduauto.sps.server.excel.check.StockInLocationRecommendationDetailBatchPreCheck.KEY_RECOMMENDATION_ID;

@Slf4j
@Component
public class StockInLocationRecommendationDetailImportHandler extends ExtendImportHandler<StockInLocationRecommendationDetailImportDto> {

    @Resource
    private IStockInLocationRecommendationDetailService stockInLocationRecommendationDetailService;

    @Resource
    private IStockInLocationRecommendationService stockInLocationRecommendationService;

    @Resource
    private ICommonService commonService;

    private final Integer MAX_LIMIT = 10000;

    public StockInLocationRecommendationDetailImportHandler(List<BatchPreCheck<StockInLocationRecommendationDetailImportDto>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchPreChecks;
        super.eClass = StockInLocationRecommendationDetailImportDto.class;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public List<ImportDataInfo<StockInLocationRecommendationDetailImportDto>> readFile(MultipartFile file) throws BizException {
        String configStr = ExcelThreadLocalHolder.getString(KEY_CONFIG_STR);
        List<String> configList = Arrays.stream(configStr.split(",")).sorted().collect(Collectors.toList());

        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<StockInLocationRecommendationDetailImportDto>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, eClass, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONUtil.toJsonStr(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    //noinspection unchecked
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> fileHeads = readCellDataList.stream().map(ReadCellData::getStringValue)
                            .map(o -> {
                                String str = StockInLocationRecommendationServiceImpl.FIELD_DESC_MAP.getKey(o);
                                return StringUtils.defaultIfNull(str, "");
                            })
                            .sorted().collect(Collectors.toList());

                    //比较两个list
                    if (!Objects.equals(fileHeads, configList)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    int rowNum = readRowHolder.getRowIndex() + 1;

                    if (rowNum > MAX_LIMIT) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");
                    }
                    try {
                        ImportDataInfo<StockInLocationRecommendationDetailImportDto> info = new ImportDataInfo<>();
                        StockInLocationRecommendationDetailImportDto data = (StockInLocationRecommendationDetailImportDto) o;
                        info.setData(data);
                        importList.add(info);
                    } catch (Exception e) {
                        log.error("第{}行,数据解析异常", rowNum, e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;
        } catch (Exception e) {
            log.error("导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(e.getMessage());
        }
    }

    @Override
    protected void afterProcess(ImportReturnDataInfo<ExtendExportDto<StockInLocationRecommendationDetailImportDto>> returnDataInfo) throws BizException {
        log.info("extendImportHandler-afterProcess-start");
        List<ExtendExportDto<StockInLocationRecommendationDetailImportDto>> extendExportDtos = returnDataInfo.getData();
        List<ExtendExportDto<StockInLocationRecommendationDetailImportDto>> errorList = Optional.ofNullable(extendExportDtos).orElse(Lists.newArrayList()).stream().filter(o -> StrUtil.isNotEmpty(o.getCheckResult())).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(errorList)) {

            errorList.stream().map(ExtendExportDto::getT).forEach(o -> {
                o.setMaterialStatus(StringUtils.defaultIfBlank(commonService.getDictItemDesc(DictEnum.MaterialStockStatus, o.getMaterialStatus()), o.getMaterialStatus()));
                o.setMaterialSort(StringUtils.defaultIfBlank(commonService.getDictItemDesc(DictEnum.MaterialSort, o.getMaterialSort()), o.getMaterialSort()));
                o.setStockStatus(StringUtils.defaultIfBlank(commonService.getDictItemDesc(DictEnum.StockStatus, o.getStockStatus()), o.getStockStatus()));
            });

            String fileKey = createErrExcel(returnDataInfo.getData());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        }
        // 校验成功-导入
        if (!CollectionUtils.isEmpty(returnDataInfo.getData())) {
            // 保存
            saveData(returnDataInfo.getData());
            returnDataInfo.setImportFlag(true);
        }
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveData(List<ExtendExportDto<StockInLocationRecommendationDetailImportDto>> extendExportDto) {
        Long id = ExcelThreadLocalHolder.getLong(KEY_RECOMMENDATION_ID);
        List<StockInLocationRecommendationDetailImportDto> collect = extendExportDto.stream().map(ExtendExportDto::getT).collect(Collectors.toList());

        StockInLocationRecommendationPo po = stockInLocationRecommendationService.getById(id);

        List<StockInLocationRecommendationDetailPo> detailPos = BeanUtil.copyToList(collect, StockInLocationRecommendationDetailPo.class);
        detailPos = detailPos.stream().peek(o -> {
            o.setRecommendationId(id);
            o.setIsDel(po.getIsDel());
        }).collect(Collectors.toList());
        stockInLocationRecommendationDetailService.saveBatch(detailPos);

        //主数据还未确认
        if (po.getIsDel()) {
            List<StockInLocationRecommendationDetailPo> update = detailPos.stream().peek(o -> o.setDelUniqueKey(o.getId())).collect(Collectors.toList());
            stockInLocationRecommendationDetailService.updateBatchById(update);
        }
    }

    /**
     * 生成错误导出表头
     */
    public List<List<String>> head() {
        List<List<String>> headList = new ArrayList<>();

        String configStr = ExcelThreadLocalHolder.getString(KEY_CONFIG_STR);
        //错误模板动态导出
        List<String> head  = Arrays.stream(configStr.split(",")).map(StockInLocationRecommendationServiceImpl.FIELD_DESC_MAP::get).collect(Collectors.toList());
        head.forEach(h-> headList.add( Lists.newArrayList(h)));
        headList.add(Lists.newArrayList("报错信息"));
        return headList;
    }

    /**
     * 输出数据
     */
    public List<List<Object>> data(List<ExtendExportDto<StockInLocationRecommendationDetailImportDto>> error) {
        return error.stream().map(err -> {
            List<Object> list = Lists.newArrayList();
            StockInLocationRecommendationDetailImportDto t = err.getT();
            Field[] fields = ReflectUtil.getFields(t.getClass());
            // 动态模板  要根据字段是否配置输出
            String configStr = ExcelThreadLocalHolder.getString(KEY_CONFIG_STR);
            //错误模板动态导出
            Set<String> set  = Arrays.stream(configStr.split(",")).collect(Collectors.toSet());
            for (Field field : fields) {
                boolean annotationPresent = field.isAnnotationPresent(ExcelProperty.class);
                if (annotationPresent && set.contains(field.getName())) {
                    list.add(ReflectUtil.getFieldValue(t, field));
                }
            }
            list.add(err.getCheckResult());
            return list;
        }).collect(Collectors.toList());
    }
}
