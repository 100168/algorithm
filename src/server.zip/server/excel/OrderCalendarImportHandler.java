package com.jiduauto.sps.server.excel;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.jiduauto.sps.server.excel.check.BatchPreCheck;
import com.jiduauto.sps.server.mapper.OrderCalendarMapper;
import com.jiduauto.sps.server.pojo.po.OrderCalendarPo;
import com.jiduauto.sps.server.pojo.vo.req.OrderCalenderImportReq;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import com.jiduauto.sps.server.utils.DateUtils;
import com.jiduauto.sps.server.utils.UserUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class OrderCalendarImportHandler extends ExtendImportHandler<OrderCalenderImportReq> {
    private static final List<String> character = Arrays.asList(",", "、");

    @Resource
    private OrderCalendarMapper orderAlendarMapper;

    public OrderCalendarImportHandler(List<BatchPreCheck<OrderCalenderImportReq>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        //
        this.batchChecks = batchPreChecks;
        //获取表头
        super.eClass = OrderCalenderImportReq.class;
    }

    /**
     * 保存导入数据
     *
     * @param extendExportDto
     */
    @Override
    protected void saveData(List<ExtendExportDto<OrderCalenderImportReq>> extendExportDto) {

        String bizType = BizTypeThreadHolder.getBizType();
        List<OrderCalendarPo> pos = extendExportDto.stream().map(ExtendExportDto::getT).map(item -> {
            OrderCalendarPo po = new OrderCalendarPo();

            //校验数据库中的数据是否存在
            OrderCalendarPo orderCalendarPo = orderAlendarMapper.selectOne(new LambdaQueryWrapper<OrderCalendarPo>()
                    .eq(OrderCalendarPo::getBizType, bizType)
                    .eq(OrderCalendarPo::getStoreCode, item.getStoreCode()));

            //如果存在则进行修改
            if (ObjectUtil.isNotEmpty(orderCalendarPo)) {
                if ("按周".equals(item.getOrderCycleType())) {
                    po.setOrderCycleType(0);
                } else if ("按月".equals(item.getOrderCycleType())) {
                    po.setOrderCycleType(1);
                }
                extracted(item);
                orderAlendarMapper.update(null, new LambdaUpdateWrapper<OrderCalendarPo>()
                        .eq(OrderCalendarPo::getBizType, bizType)
                        .eq(OrderCalendarPo::getStoreCode, item.getStoreCode())
                        .set(StrUtil.isNotEmpty(item.getOrderCycleType()), OrderCalendarPo::getOrderCycleType, po.getOrderCycleType())
                        .set(StrUtil.isNotEmpty(item.getOrderCycle()), OrderCalendarPo::getOrderCycle, item.getOrderCycle())
                        .set(ObjectUtil.isNotEmpty(item.getStoreReportDeadline()), OrderCalendarPo::getStoreReportDeadline, item.getStoreReportDeadline())
                        .set(ObjectUtil.isNotEmpty(item.getTransferTime()), OrderCalendarPo::getTransferTime, item.getTransferTime())
                        .set(ObjectUtil.isNotEmpty(item.getTransferTime2()), OrderCalendarPo::getTransferTime2, item.getTransferTime2())
                        .set(OrderCalendarPo::getUpdateTime, LocalDateTime.now())
                        .set(StrUtil.isNotBlank(item.getIssueAmount()), OrderCalendarPo::getIssueAmount, new BigDecimal(item.getIssueAmount()))
                        .set(OrderCalendarPo::getUpdateUser, UserUtil.getUserName()));
            } else {
                if ("按周".equals(item.getOrderCycleType())) {
                    po.setOrderCycleType(0);
                } else if ("按月".equals(item.getOrderCycleType())) {
                    po.setOrderCycleType(1);
                }
                extracted(item);
                po.setStoreCode(item.getStoreCode());
                po.setOrderCycle(item.getOrderCycle());
                po.setStoreReportDeadline(DateUtils.parse(item.getStoreReportDeadline(), DateUtils.SHORT_ONLY_TIME_FORMAT1));
                po.setTransferTime(DateUtils.parse(item.getTransferTime(), DateUtils.SHORT_ONLY_TIME_FORMAT1));
                if (ObjectUtil.isNotEmpty(item.getTransferTime2())) {
                    po.setTransferTime2(DateUtils.parse(item.getTransferTime2(), DateUtils.SHORT_ONLY_TIME_FORMAT1));
                }
                po.setBizType(bizType);
                po.setCreateTime(LocalDateTime.now());
                po.setCreateUser(UserUtil.getUserName());
                po.setUpdateTime(LocalDateTime.now());
                if (StrUtil.isNotBlank(item.getIssueAmount())) {
                    po.setIssueAmount(new BigDecimal(item.getIssueAmount()));
                }
                orderAlendarMapper.insert(po);
            }
            return po;
        }).collect(Collectors.toList());
    }

    private static void extracted(OrderCalenderImportReq item) {
        for (String s : character) {
            if (item.getOrderCycle().contains(s)) {
                List<Integer> collect = Arrays.stream(item.getOrderCycle().split(s)).mapToInt(Integer::parseInt).distinct().sorted().boxed().collect(Collectors.toList());
                StringBuffer stringBuffer = new StringBuffer();
                sort(collect, stringBuffer);
                item.setOrderCycle(stringBuffer.toString());
            }
        }
    }

    private static void sort(List<Integer> collect, StringBuffer stringBuffer) {
        for (int i = 0; i < collect.size(); i++) {
            if (i == collect.size() - 1) {
                stringBuffer.append(collect.get(i));
            } else {
                stringBuffer.append(collect.get(i) + "、");
            }
        }
    }
}
