package com.jiduauto.sps.server.excel;

import com.jiduauto.sps.server.excel.check.PreCheck;
import com.jiduauto.sps.server.pojo.vo.resp.AsnImportResp;
import com.jiduauto.sps.server.service.IAsnBasicService;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.function.Consumer;

/**
 * @author tao.wang
 * @date 2022/12/19
 * @description 导入方法实现累
 */
@Slf4j
@Service
public class AsnImportHandler extends ExtendImportHandler<AsnImportResp> {

    private Consumer<List<ExtendExportDto<AsnImportResp>>> consumer;

    public AsnImportHandler(List<PreCheck<AsnImportResp>> preChecks, BosServiceImpl bosService, IAsnBasicService asnBasicService) {
        super.bosService = bosService;
        super.checks = preChecks;
        super.eClass = AsnImportResp.class;
        this.consumer = asnBasicService.getImportConsumer();

    }

    /**
     * 释放资源
     */
    @Override
    public void release() {
        super.release();
        AsnImportThreadHolder.remove();
    }

    @Override
    protected void saveData(List<ExtendExportDto<AsnImportResp>> extendExportDto) {
        consumer.accept(extendExportDto);
    }
}
