package com.jiduauto.sps.server.excel;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.server.Enum.OrderPlanStatusEnum;
import com.jiduauto.sps.server.Enum.PriorityEnum;
import com.jiduauto.sps.server.Enum.PurchaseModeEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.excel.check.BatchPreCheck;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.OrderPlanMapper;
import com.jiduauto.sps.server.mapper.SupplierCalendarMapper;
import com.jiduauto.sps.server.pojo.dto.baseData.FrameContractDto;
import com.jiduauto.sps.server.pojo.dto.param.SupplierCalendarCodeParam;
import com.jiduauto.sps.server.pojo.po.OrderPlanPo;
import com.jiduauto.sps.server.pojo.po.SupplierCalendarPo;
import com.jiduauto.sps.server.pojo.vo.req.OrderPlanImportReq;
import com.jiduauto.sps.server.service.IOrderPlanService;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import com.jiduauto.sps.server.service.impl.OrderPlanServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

@Component
public class OrderPlanImportHandler extends ExtendImportHandler<OrderPlanImportReq> {

    public final static String KEY_FRAME_CONTRACT_DTO = "KEY_FCD_%s_%s";

    @Resource
    private IOrderPlanService orderPlanService;
    @Resource
    private OrderPlanMapper orderPlanMapper;
    @Resource
    private SupplierCalendarMapper supplierCalendarMapper;

    public OrderPlanImportHandler(List<BatchPreCheck<OrderPlanImportReq>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchPreChecks;
        super.eClass = OrderPlanImportReq.class;
    }

    @Override
    protected void saveData(List<ExtendExportDto<OrderPlanImportReq>> extendExportDtos) {
        String bizType = BizTypeThreadHolder.getBizType();
        extendExportDtos.stream().map(ExtendExportDto::getT).map(item -> {
            OrderPlanPo save = new OrderPlanPo();
            BeanUtils.copyProperties(item, save);
            save.setBizType(bizType);
            save.setOrderPlanNo(orderPlanService.generateSerialNo());
            save.setPlanStatus(OrderPlanStatusEnum.WAIT_COMMIT.getItemCode());

            save.setQuantity(Integer.valueOf(item.getQuantityStr()));

            if (Objects.nonNull(item.getUrgent())) {
                save.setPriority("是".equals(item.getUrgent()) ? PriorityEnum.P1_MAJOR.getItemCode() : PriorityEnum.P2_MEDIUM.getItemCode());
            }

            String frameContractUniqueKey = String.format(OrderPlanImportHandler.KEY_FRAME_CONTRACT_DTO, item.getSalePartNum(), item.getSupplierSapCode());
            FrameContractDto frameContractDto = ExcelThreadLocalHolder.getObject(frameContractUniqueKey, FrameContractDto.class);
            if (Objects.isNull(frameContractDto)) {
                throw new BizException("数据异常，框架协议为空");
            }

            save.setSupplierSapCode(frameContractDto.getSupplierCode());
            save.setCompanyCode(frameContractDto.getCompanyCode());
            save.setPlantCode(frameContractDto.getPlantCode());
            save.setContractNo(frameContractDto.getContractNo());
            save.setOrderUnit(frameContractDto.getBasicUnitMeasurement());

            LocalDateTime estArrivalTime = LocalDate.parse(item.getEstArrivalTimeStr(), DateTimeFormatter.ofPattern(BaseConstants.DatePattern.NONE_DATE)).atTime(23, 59, 59);

            SupplierCalendarPo supplierCalendar = getSupplierCalendar(bizType, SupplierCalendarCodeParam.builder()
                    .supplierSapCode(frameContractDto.getSupplierCode())
                    .companyCode(frameContractDto.getCompanyCode())
                    .warehouseCode(item.getReceiveWarehouseCode())
                    .build());
            if (Objects.nonNull(supplierCalendar)) {
                save.setEstArrivalTime(OrderPlanServiceImpl.chooseEstArrivalTime(estArrivalTime, supplierCalendar.getSupplyCycleType(), supplierCalendar.getSupplyCycleValue()));
            } else {
                save.setEstArrivalTime(estArrivalTime);
            }
            save.setReceiptType(PurchaseModeEnum.L.getCode());
            return save;
        }).forEach(item -> {
            orderPlanMapper.insert(item);
        });
    }

    private SupplierCalendarPo getSupplierCalendar(String bizType, SupplierCalendarCodeParam codeParam) {
        return supplierCalendarMapper.selectOne(Wrappers.<SupplierCalendarPo>lambdaQuery()
                .eq(SupplierCalendarPo::getBizType, bizType)
                .eq(SupplierCalendarPo::getSupplierSapCode, codeParam.getSupplierSapCode())
                .eq(SupplierCalendarPo::getCompanyCode, codeParam.getCompanyCode())
                .eq(SupplierCalendarPo::getWarehouseCode, codeParam.getWarehouseCode()));
    }
}
