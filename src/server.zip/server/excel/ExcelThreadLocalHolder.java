package com.jiduauto.sps.server.excel;


import com.google.common.collect.Maps;

import java.util.Map;

/**
 * 导入通用线程变量
 */
public class ExcelThreadLocalHolder {

    private static final ThreadLocal<Map<String, Object>> threadLocal = ThreadLocal.withInitial(Maps::newHashMap);

    public static void put(String key, Object value) {
        threadLocal.get().put(key, value);
    }

    public static Object get(String key) {
        return threadLocal.get().get(key);
    }

    public static Integer getInteger(String key) {
        return getObject(key, Integer.class);
    }

    public static Long getLong(String key) {
        return getObject(key, Long.class);
    }

    public static String getString(String key) {
        return getObject(key, String.class);
    }

    public static <T> T getObject(String key, Class<T> clazz) {
        Object value = threadLocal.get().get(key);
        return clazz.isInstance(value) ? (T) value : null;
    }

    public static void remove() {
        threadLocal.remove();
    }
}
