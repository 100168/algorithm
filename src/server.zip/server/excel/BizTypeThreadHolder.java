package com.jiduauto.sps.server.excel;


/**
 * @author tao.wang
 * @date 2022/8/15
 * @description
 */
public class BizTypeThreadHolder {

    private static final ThreadLocal<String> bizThreadLocal = new ThreadLocal();

    public BizTypeThreadHolder() {
    }

    public static void setBizThreadLocal(String bizType) {
        bizThreadLocal.set(bizType);
    }

    public static String getBizType() {
        return bizThreadLocal.get();
    }

    public static void remove() {
        bizThreadLocal.remove();
    }
}
