package com.jiduauto.sps.server.excel;

import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.sdk.pojo.po.BackOrderPo;
import com.jiduauto.sps.server.client.SpsOrderClient;
import com.jiduauto.sps.server.excel.check.BatchPreCheck;
import com.jiduauto.sps.server.pojo.vo.req.BackOrderImportReq;
import com.jiduauto.sps.server.service.impl.BosServiceImpl;
import com.jiduauto.sps.server.utils.DateUtils;
import com.jiduauto.sps.server.utils.UserUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author panjian
 */
@Component
public class BackOrderImportHandler extends ExtendImportHandler<BackOrderImportReq> {


    @Resource
    private SpsOrderClient spsOrderClient;

    public BackOrderImportHandler(List<BatchPreCheck<BackOrderImportReq>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchPreChecks;
        super.eClass = BackOrderImportReq.class;
    }

    @Override
    protected void saveData(List<ExtendExportDto<BackOrderImportReq>> extendExportDtos) {
        String bizType = BizTypeThreadHolder.getBizType();
        List<BackOrderPo> backOrderPos = extendExportDtos.stream().map(ExtendExportDto::getT).map(item -> {
            BackOrderPo save = new BackOrderPo();
            BeanUtils.copyProperties(item, save);
            if (StrUtil.isNotEmpty(item.getEstArrivalTime())) {
                LocalDateTime parseDate = DateUtils.parse(item.getEstArrivalTime(), DateUtils.SHORT_DATE_FORMAT);
                save.setEstArrivalTime(DateUtils.format(parseDate, DateUtils.STANDARD_DATE_FORMAT));
            }

            save.setBizType(bizType);
            save.setUpdateUser(UserUtil.getUserName());
            save.setUpdateTime(LocalDateTime.now());
            return save;
        }).collect(Collectors.toList());

        spsOrderClient.updateByBoNo(backOrderPos, IdUtil.fastSimpleUUID()).check();
    }
}
