package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.sdk.enums.StockCheckOrderStatusEnum;
import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderItemPo;
import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderPo;
import com.jiduauto.sps.sdk.pojo.req.StockCheckOrderImportReq;
import com.jiduauto.sps.sdk.pojo.resp.StockCheckOrderImportResp;
import com.jiduauto.sps.server.Enum.ColumnNameArrayEnum;
import com.jiduauto.sps.server.caches.DictItemCache;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.convertor.InAndOutStockParamConvertor;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.excel.ExcelThreadLocalHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.StockItemMapper;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.utils.*;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @ClassName IStockCheckOrderImportHandler
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/12/14 16:26
 */
@Service
@Slf4j
public class IStockCheckOrderImportHandler extends
        BaseImportHandler<StockCheckOrderImportReq, StockCheckOrderImportResp> {

    @Autowired
    private IBosService bosService;
    @Autowired
    private DictItemCache dictItemCache;
    @Autowired
    private IMaterialService materialService;
    @Autowired
    private IWarehouseService warehouseService;
    @Autowired
    private IAreasService areasService;
    @Autowired
    private ILocationsService locationsService;
    @Autowired
    private IPalletService palletService;
    @Autowired
    private IWorkbinService workbinService;
    @Autowired
    private ICarService carService;
    @Autowired
    private ISupplierService supplierService;
    @Autowired
    private ICommonService commonService;
    @Autowired
    private IStockConfigService stockConfigService;
    @Autowired
    private StockItemMapper stockItemMapper;
    @Autowired
    private IStockCheckOrderItemService stockCheckOrderItemService;

    public final static String KEY_CHECK_ORDER_NO = "KEY_CHECK_ORDER_NO";
    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST = Arrays.asList("零件编码", "零件状态", "样件状态", "零件种类",
            "车辆号",
            "批次", "序列号", "零件条码", "入库日期", "生产日期", "失效日期", "实物库存数量", "库存状态", "供应商代码",
            "项目", "阶段", "WBS编号",
            "业务单号", "业务单行号", "仓库代码", "区域代码", "库位代码", "托盘号",
            "料箱号");

    @Override
    public List<ImportDataInfo<StockCheckOrderImportReq>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<StockCheckOrderImportReq>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, StockCheckOrderImportReq.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", ""))
                            .collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        StockCheckOrderImportReq data = (StockCheckOrderImportReq) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {// 所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (Exception e) {
            log.error("盘点单导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "盘点单导入解析异常,请检查文件格式");
        }
    }

    @Override
    protected ImportReturnDataInfo<StockCheckOrderImportResp> process(
            List<ImportDataInfo<StockCheckOrderImportReq>> list)
            throws BizException {
        StockCheckOrderPo po = ExcelThreadLocalHolder.getObject(KEY_CHECK_ORDER_NO,
                StockCheckOrderPo.class);
        boolean hasError = false;
        String bizType = BizTypeThreadHolder.getBizType();

        ImportReturnDataInfo<StockCheckOrderImportResp> returnDataInfo = new ImportReturnDataInfo<>();
        List<StockCheckOrderImportResp> resultResps = new ArrayList<>();
        Map<String, StockCheckOrderItemPo> itemPoMap = stockCheckOrderItemService.list(
                        Wrappers.lambdaQuery(StockCheckOrderItemPo.class)
                                .eq(StockCheckOrderItemPo::getBizType, po.getBizType())
                                .eq(StockCheckOrderItemPo::getStockCheckOrderNo, po.getOrderNo())).stream()
                .collect(Collectors.toMap(StockCheckOrderItemPo::getBizConfigField, Function.identity(), (k, v) -> v));
        List<String> areaList = new ArrayList<>();
        List<String> locationList = new ArrayList<>();
        Map<String, String> stockStatusMap = dictItemCache.getNameAndCodeMap(DictEnum.StockStatus.getDictCode());
        List<String> palletList = new ArrayList<>();
        StockConfigPo stockConfigPo2 = stockConfigService.getByBizTypeAndConfigType(bizType, 2);
        List<String> workbinList = new ArrayList<>();
        Map<String, String> materialStockStatusMap =
                dictItemCache.getNameAndCodeMap(DictEnum.MaterialStockStatus.getDictCode());
        List<String> supplierList = new ArrayList<>();
        List<String> carList = new ArrayList<>();
        List<String> stockItemKeys = new ArrayList<>();
        Map<String, String> sortMap = dictItemCache.getNameAndCodeMap(DictEnum.MaterialSort.getDictCode());
        List<String> materialList = new ArrayList<>();
        List<String> warehouseList = new ArrayList<>();

        for (ImportDataInfo<StockCheckOrderImportReq> extendExportDto : list) {
            StockCheckOrderImportReq t = extendExportDto.getData();
            materialList.add(t.getMaterialCode());
            warehouseList.add(t.getWarehouseCode());
            areaList.add(t.getAreaCode());
            locationList.add(t.getLocationCode());
            palletList.add(t.getPalletNo());
            workbinList.add(t.getCaseNo());
            supplierList.add(t.getSupplierCode());
            carList.add(t.getCarCode());
            t.setMaterialSortCode(sortMap.get(t.getMaterialSort()));
            t.setMaterialStatusCode(materialStockStatusMap.get(t.getMaterialStatus()));
            t.setStockStatusCode(stockStatusMap.get(t.getStockStatus()));
            InAndOutStockParam param = buildInAndOutStockParam(bizType, t);
            String itemKey = StockUtils.getStockKeyByParam(stockConfigPo2.getField(), bizType, param);
            stockItemKeys.add(itemKey);
        }
        val warehousePoMap = warehouseService.mapWarehousePo(bizType, warehouseList);
        val locationsPoMap = locationsService.mapWarehouseCodeAreaCodeLocationKey(bizType, locationList);
        val areasPoMap = areasService.mapWarehouseCodeAndAreaCodeKey(bizType, areaList);
        val palletPoMap = palletService.mapPalletPo(bizType, palletList);
        val materialPoMap = materialService.mapMaterialPo(bizType, materialList);
        val carPoMap = carService.mapCarPo(bizType, carList);
        val workbinPoMap = workbinService.mapWorkbinPo(bizType, workbinList);
        val supplierPoMap = supplierService.mapSupplierPo(bizType, supplierList);

        Map<String, String> projectMap = dictItemCache.getNameAndCodeMap(DictEnum.Project.getDictCode());
        Map<String, StockCheckOrderImportReq> check = new HashMap<>();
        Map<String, String> stageMap = dictItemCache.getNameAndCodeMap(DictEnum.Stage.getDictCode());
        Map<String, StockCheckOrderImportReq> hashMap = new HashMap<>();
        Map<String, StockItemPo> stockItemPoMap = stockItemMapper.getByBizConfigFields(stockItemKeys).stream()
                .collect(Collectors.toMap(StockItemPo::getBizConfigField, Function.identity()));
        for (ImportDataInfo<StockCheckOrderImportReq> extendExportDto : list) {
            StockCheckOrderImportReq t = extendExportDto.getData();
            StringBuilder errors = new StringBuilder();
            //校验明细参数
            hasError = checkParam(t, hasError, errors, materialStockStatusMap, stockStatusMap, materialPoMap,
                    warehousePoMap,
                    areasPoMap, locationsPoMap, carPoMap, workbinPoMap, palletPoMap, supplierPoMap, sortMap, stageMap,
                    projectMap);
            t.setStockCheckOrderNo(po.getOrderNo());
            // 校验重复性
            String objectString =
                    commonService.getObjectString(t,
                            ColumnNameArrayEnum.STOCK_CHECK_ITEM_ORDER_IMPORT_COLUMN.getCode());
            if (hashMap.containsKey(objectString)) {
                errors.append("该物料(").append(t.getMaterialCode()).append(")重复");
                hasError = true;
            }
            {
                hashMap.put(objectString, t);
            }
            InAndOutStockParam param = buildInAndOutStockParam(bizType, t);
            String itemKey = StockUtils.getStockKeyByParam(stockConfigPo2.getField(), bizType, param);
                StockItemPo stockItemPo = stockItemPoMap.get(itemKey);
            if (Objects.nonNull(stockItemPo)) {
                t.setQty(stockItemPo.getSumQuantity());
                t.setBizConfigField(itemKey);
            } else {
                t.setQty(new BigDecimal(0));
            }
            StockCheckOrderStatusEnum statusEnum = StockCheckOrderStatusEnum.getByCode(po.getOrderStatus());
            switch (statusEnum) {
                case CONFIRM:
                    t.setFirstQty( new BigDecimal(t.getQtyReal()));
                        break;
                case FIRST_FINISHED:
                    t.setSecondQty(new BigDecimal(t.getQtyReal()));
                        break;
                case SECOND_FINISHED:
                    t.setFinalQty(new BigDecimal(t.getQtyReal()));
                        break;
                }
            // 同一单下是否绑定到同一库存明细校验
            if (!check.containsKey(itemKey)) {
                check.put(itemKey, t);
            } else {
                hasError = true;
                errors.append("该物料(").append(t.getMaterialCode()).append(")匹配到同一库存明细请检查");
            }
            //已存在明细列表中是否存在
            if (itemPoMap.containsKey(t.getBizConfigField())) {
                hasError = true;
                errors.append("数据已存在(").append(t.getMaterialCode()).append(")");
            }
            StockCheckOrderImportResp orderImportResp = BeanCopierUtil.copy(t, StockCheckOrderImportResp.class);
            orderImportResp.setErrorInfo(String.valueOf(errors));
            resultResps.add(orderImportResp);
        }
        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    /**
     * 校验明细参数
     */
    private boolean checkParam(StockCheckOrderImportReq t, boolean hasError, StringBuilder errors,
            Map<String, String> materialStockStatusMap, Map<String, String> stockStatusMap,
            Map<String, MaterialPo> materialPoMap, Map<String, WarehousePo> warehousePoMap,
            Map<String, AreasPo> areasPoMap, Map<String, LocationsPo> locationsPoMap, Map<String, CarPo> carPoMap,
            Map<String, WorkbinPo> workbinPoMap, Map<String, PalletPo> palletPoMap,
            Map<String, SupplierPo> supplierPoMap, Map<String, String> sortMap, Map<String, String> stageMap,
            Map<String, String> projectMap) {
        if (StringUtils.isBlank(t.getQtyReal())){
            hasError = true;
            errors.append("实物库存数量未填写");
        }else {
            if (new BigDecimal(t.getQtyReal()).compareTo(new BigDecimal(0))<0){
                hasError = true;
                errors.append("实物库存数量必须大于等于0");
            }
        }
        if (StringUtils.isNotBlank(t.getAddDate())) {
            if (StringUtils.isBlank(DateUtils.getFormat(t.getAddDate()))) {
                hasError = true;
                errors.append("入库日期格式不正确yyyy/MM/dd");
            }
        }
        if (StringUtils.isNotBlank(t.getProductDate())) {
            if (StringUtils.isBlank(DateUtils.getFormat(t.getProductDate()))) {
                hasError = true;
                errors.append("生产日期格式不正确yyyy/MM/dd");
            }
        }
        if (StringUtils.isNotBlank(t.getExpireDate())) {
            if (StringUtils.isBlank(DateUtils.getFormat(t.getExpireDate()))) {
                hasError = true;
                errors.append("失效日期格式不正确yyyy/MM/dd");
            }
        }
        if (StringUtils.isNotBlank(t.getMaterialSort()) && Objects.isNull(t.getMaterialSortCode())) {
            hasError = true;
            errors.append("零件种类填写不正确");
        }
        if (Objects.isNull(t.getMaterialStatusCode())) {
            hasError = true;
            errors.append("零件状态不能为空");
        } else {
            String string = materialStockStatusMap.get(t.getMaterialStatus());
            if (StringUtils.isBlank(string)) {
                hasError = true;
                errors.append("零件状态填写不正确");
            }
        }
        if (Objects.isNull(t.getStockStatusCode())) {
            hasError = true;
            errors.append("库存状态不能为空");
        } else {
            String string = stockStatusMap.get(t.getStockStatus());
            if (StringUtils.isBlank(string)) {
                hasError = true;
                errors.append("库存状态填写不正确");
            }
        }
        if (!materialPoMap.containsKey(t.getMaterialCode())) {
            hasError = true;
            errors.append("零件编码不存在");
        }
        if (!warehousePoMap.containsKey(t.getWarehouseCode())) {
            hasError = true;
            errors.append("仓库编码不存在");
        }
        if (StringUtils.isNotBlank(t.getAreaCode()) && !areasPoMap.containsKey(
                t.getWarehouseCode() + t.getAreaCode())) {
            hasError = true;
            errors.append("区域编码不存在");
        }
        if (StringUtils.isNotBlank(t.getSamplePartStatus()) && t.getSamplePartStatus().length() > 50) {
            hasError = true;
            errors.append("样件状态字符长度要在50位以内");
        }
        if (StringUtils.isNotBlank(t.getLocationCode()) &&!locationsPoMap.containsKey(t.getWarehouseCode() + t.getAreaCode() + t.getLocationCode())) {
            hasError = true;
            errors.append("库位编码不存在");
        }
        if (StringUtils.isNotBlank(t.getSequenceNo()) && t.getSequenceNo().length() > 50) {
            hasError = true;
            errors.append("序列号字符长度要在50位以内");
        }
        if (StringUtils.isNotBlank(t.getWbsCode()) && t.getWbsCode().length() > 50) {
            hasError = true;
            errors.append("wbs编号字符长度要在50位以内");
        }
        if (StringUtils.isNotBlank(t.getBatchNo()) && t.getBatchNo().length() > 20) {
            hasError = true;
            errors.append("批次号字符长度要在20位以内");
        }
        if (StringUtils.isNotBlank(t.getPurchaseOrderNo()) && t.getPurchaseOrderNo().length() > 20) {
            hasError = true;
            errors.append("业务单号字符长度要在20位以内");
        }
        if (StringUtils.isNotBlank(t.getMaterialBarCode()) && t.getMaterialBarCode().length() > 50) {
            hasError = true;
            errors.append("零件条码字符长度要在50位以内");
        }
        if (StringUtils.isNotBlank(t.getColumnProjectNo()) && t.getColumnProjectNo().length() > 20) {
            errors.append("业务单行号字符长度要在20位以内");
            hasError = true;
        }
        if (StringUtils.isNotBlank(t.getCarCode())) {
            if (!carPoMap.containsKey(t.getCarCode())) {
                errors.append("车辆号不存在");
                hasError = true;
            }
        }
        if (StringUtils.isNotBlank(t.getCaseNo())) {
            if (!workbinPoMap.containsKey(t.getCaseNo())) {
                errors.append("料箱号不存在");
                hasError = true;
            }
        }
        if (StringUtils.isNotBlank(t.getPalletNo())) {
            if (!palletPoMap.containsKey(t.getPalletNo())) {
                errors.append("托盘号不存在");
                hasError = true;
            }
        }
        if (StringUtils.isNotBlank(t.getSupplierCode())) {
            if (!supplierPoMap.containsKey(t.getSupplierCode())) {
                errors.append("供应商不存在");
                hasError = true;
            }
        }
        if (StringUtils.isNotBlank(t.getMaterialSort())) {
            if (!sortMap.containsKey(t.getMaterialSort())) {
                errors.append("零件种类不存在");
                hasError = true;
            }
        }

        if (StringUtils.isNotBlank(t.getStageCode())) {
            if (!stageMap.containsKey(t.getStageCode())) {
                errors.append("阶段不存在");
                hasError = true;
            }
        }
        if (StringUtils.isNotBlank(t.getProjectCode())) {
            if (!projectMap.containsKey(t.getProjectCode())) {
                errors.append("项目不存在");
                hasError = true;
            }
        }
        return hasError;
    }

    @Resource
    private InAndOutStockParamConvertor inAndOutStockParamConvertor;

    private InAndOutStockParam buildInAndOutStockParam(String bizType, StockCheckOrderImportReq req) {
        InAndOutStockParam request = inAndOutStockParamConvertor.toParam(req, bizType);
        log.info("IStockCheckOrderImportHandler#buildInAndOutStockParam#param : {}", JsonUtil.toJsonString(request));
        return request;
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void afterProcess(ImportReturnDataInfo<StockCheckOrderImportResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        } else {
            try {
                String bizType = BizTypeThreadHolder.getBizType();
                List<StockCheckOrderItemPo> itemPos = new ArrayList<>();
                for (StockCheckOrderImportReq dto : returnDataInfo.getData()) {
                    StockCheckOrderItemPo itemPo = BeanCopierUtil.copy(dto, StockCheckOrderItemPo.class);
                    itemPo.setBizType(bizType);
                    if (Objects.nonNull(dto.getMaterialStatusCode())) {
                        itemPo.setMaterialStatus(Integer.valueOf(dto.getMaterialStatusCode()));
                    }
                    if (Objects.nonNull(dto.getStockStatusCode())) {
                        itemPo.setStockStatus(Integer.valueOf(dto.getStockStatusCode()));
                    }
                    if (StringUtils.isNotBlank(dto.getAddDate())) {
                        itemPo.setAddDate(dto.getAddDate().replace("/", "-"));
                    }
                    if (StringUtils.isNotBlank(dto.getProductDate())) {
                        itemPo.setProductDate(dto.getProductDate().replace("/", "-"));
                    }
                    if (StringUtils.isNotBlank(dto.getExpireDate())) {
                        itemPo.setExpireDate(dto.getExpireDate().replace("/", "-"));
                    }
                    itemPo.setMaterialSort(dto.getMaterialSort());
                    stockCheckOrderItemService.initItemStatus(
                            StringUtils.isBlank(dto.getQtyReal()) ? new BigDecimal(0)
                                    : new BigDecimal(dto.getQtyReal()), itemPo);
                    itemPos.add(itemPo);
                }
                stockCheckOrderItemService.saveBatch(itemPos);
            } catch (NumberFormatException e) {
                throw new BizException(e.getMessage());
            }
        }
        returnDataInfo.setImportFlag(true);
    }


    private String createErrExcel(List<StockCheckOrderImportResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            // 创建临时文件
            excelFile =
                    File.createTempFile(
                            DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN)
                                    + "库存数量单明细导入失败文件",
                            BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel.write(excelFile.getAbsoluteFile(), StockCheckOrderImportResp.class)
                    .registerConverter(new LongStringConverter()).build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("IStockCheckOrderImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("IStockCheckOrderImportHandler-createErrExcel-putLowsObjInputStream-error:{}",
                    ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("库存数量单明细导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }
}
