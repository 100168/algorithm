package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.conditions.query.QueryChainWrapper;
import com.jiduauto.sps.server.Enum.SupplierStatusEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.PurchaseForecastStatus;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.CompanyMapper;
import com.jiduauto.sps.server.mapper.MaterialMapper;
import com.jiduauto.sps.server.mapper.PurchaseForecastMapper;
import com.jiduauto.sps.server.mapper.SupplierMapper;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.material.PurchaseForecastImportResp;
import com.jiduauto.sps.server.pojo.vo.resp.material.PurchaseForecastImportResultResp;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.service.IPurchaseForecastService;
import com.jiduauto.sps.server.service.ISupplierService;
import com.jiduauto.sps.server.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.checkerframework.checker.units.qual.A;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 采购计划导入
 */
@Component
@Slf4j
public class PurchaseForecastImportHandler extends BaseImportHandler<PurchaseForecastImportResp, PurchaseForecastImportResultResp>{
    @Autowired
    private IBosService bosService;
    @Autowired
    private SupplierMapper supplierMapper;
    @Resource
    private CompanyMapper companyMapper;
    @Autowired
    private MaterialMapper materialMapper;

    @Autowired
    private PurchaseForecastMapper purchaseForecastMapper;


    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("*公司代码","*工厂代码","*供应商代码","*售后件号","N+1","N+2","N+3","N+4","N+5","N+6","N+7","N+8","N+9","N+10","N+11","N+12","N+13","N+14","N+15","N+16","N+17","N+18");

    public List<ImportDataInfo<PurchaseForecastImportResp>> readFile(MultipartFile file) throws BizException {
        if(file.isEmpty()){
            throw new BizException("文件不能为空");
        }
        try(InputStream inputStream = file.getInputStream()){
            List<ImportDataInfo<PurchaseForecastImportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream,PurchaseForecastImportResp.class,new ReadListener(){
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if(headMap == null){
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s->s.getStringValue().replace("\n","")).collect(Collectors.toList());
                    if(!Objects.equals(headList,HEAD_VALUE_LIST)){
                        throw new BizException("模板表头数据不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if(rowNumber > MAX_LIMIT+1){
                        throw new BizException("单次导入最大数据量"+MAX_LIMIT+"行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try{
                        ImportDataInfo info = new ImportDataInfo();
                        PurchaseForecastImportResp data = (PurchaseForecastImportResp)o;
                        if(data != null){
                            info.setData(data);
                            importList.add(info);
                        }
                    }catch(Exception e){
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        }catch(Exception e){
            log.error("采购计划导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "采购计划导入解析异常,请检查文件格式");
        }
    }


    /**
     * 校验文件
     *
     * @param list
     * @return
     * @throws BizException
     */
    @Override
    protected ImportReturnDataInfo<PurchaseForecastImportResultResp> process(List<ImportDataInfo<PurchaseForecastImportResp>> list) throws BizException {
        boolean hasError = false;
        ImportReturnDataInfo<PurchaseForecastImportResultResp> importResult = new ImportReturnDataInfo();
        String bizType = BizTypeThreadHolder.getBizType();
        List<String> supplierCodes = new ArrayList<>();
        List<String> companyCodes = new ArrayList<>();
        List<String> factoryCodes = new ArrayList<>();
        List<String> salePartCodes = new ArrayList<>();

        Map<String, Integer> duplicateMap = new HashMap<>();
        List<PurchaseForecastImportResultResp> result = new ArrayList<>();
        for(int i = 0; i < list.size(); i++){
            ImportDataInfo<PurchaseForecastImportResp> dataInfo = list.get(i);
            PurchaseForecastImportResp resp = dataInfo.getData();
            PurchaseForecastImportResultResp resultResp =  BeanCopierUtil.copy(resp,PurchaseForecastImportResultResp.class );

            StringBuilder sb = new StringBuilder();
            if(StringUtils.isBlank(resp.getCompanyCode())){
                sb.append("公司代码不能为空;");
                hasError = true;
            }else{
                companyCodes.add(resp.getCompanyCode());
            }

            if(StringUtils.isBlank(resp.getFactoryCode())){
                sb.append("工厂代码不能为空;");
                hasError = true;
            }else{
                factoryCodes.add(resp.getFactoryCode());
            }

            if(StringUtils.isBlank(resp.getSupplierCode())){
                sb.append("供应商代码不能为空;");
                hasError = true;
            }else{
                supplierCodes.add(resp.getSupplierCode());
            }

            if(StringUtils.isBlank(resp.getSalePartNumber())){
                sb.append("售后件号不能为空;");
                hasError = true;
            }else{
                salePartCodes.add(resp.getSalePartNumber());
            }
            String key = resp.getCompanyCode()+resp.getFactoryCode()+resp.getSupplierCode()+resp.getSalePartNumber();
            if(duplicateMap.containsKey(key)){
                sb.append("和第"+duplicateMap.get(key)+"行记录重复;");
                hasError = true;
            }else{
                duplicateMap.put(key,(i+2));
            }
            if(hasError){
                resultResp.setErrorInfo(sb.toString());
            }
            result.add(resultResp);
        }
        List<SupplierPo> supplierPos = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(supplierCodes)){
            supplierPos = supplierMapper.getByBizAndCodes(bizType,supplierCodes);
        }

        Map<String,SupplierPo> supplierMap = new HashMap<>();
        for(SupplierPo po:supplierPos){
            supplierMap.put(po.getSapCode(), po);
        }
        List<CompanyPo> companyPos = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(companyCodes)){
            companyPos = companyMapper.getByBizAndCodes(bizType,companyCodes);
        }
        Map<String,String> comMap = new HashMap<>();
        for(CompanyPo po:companyPos){
            comMap.put(po.getCode(), po.getName());
        }
        List<MaterialPo> materialPos = new ArrayList<>();
        if(CollectionUtils.isNotEmpty(salePartCodes)){
            materialPos = materialMapper.selectBySalePartNums(bizType,salePartCodes);
        }

        Map<String,String> materialMap = new HashMap<>();
        for(MaterialPo po:materialPos){
            materialMap.put(po.getSalePartNum(), po.getSalePartNum());
        }

        for(PurchaseForecastImportResultResp temp:result){
            StringBuilder errorTemp = new StringBuilder();
            String key = temp.getCompanyCode()+temp.getFactoryCode()+temp.getSupplierCode()+temp.getSalePartNumber();

            if(temp.getSupplierCode() != null){
                SupplierPo supplierPo =   supplierMap.get(temp.getSupplierCode());
                if(supplierPo == null ||
                        supplierPo.getStatus() == null ||
                        !SupplierStatusEnum.NOMINATED.getItemCode().equals(supplierPo.getStatus())){
                    errorTemp.append("供应商不是有效供应商;");
                    hasError = true;
                }
            }if(temp.getCompanyCode() != null &&  !comMap.containsKey(temp.getCompanyCode())){
                errorTemp.append("公司代码不存在;");
                hasError = true;
            }if(temp.getSalePartNumber() != null && !materialMap.containsKey(temp.getSalePartNumber())){
                errorTemp.append("售后件号不存在;");
                hasError = true;
            }
            if(hasError){
                temp.setErrorInfo( (temp.getErrorInfo() != null?temp.getErrorInfo() :"") +errorTemp.toString());
            }
        }

        if(hasError){
            importResult.setError(result);
            importResult.setImportFlag(false);
        }else{
            //按预测月份+公司代码+工厂代码+供应商，删除对应所有预测数据（包括各种状态）
            purchaseForecastMapper.delete(Wrappers.lambdaQuery(PurchaseForecastPo.class)
                    .eq(PurchaseForecastPo::getBizType,bizType)
                    .between(PurchaseForecastPo::getCreateTime,DateUtils.getStartTimeOfCurrentMonth(), DateUtils.getEndTimeOfCurrentMonth())
                    .in(PurchaseForecastPo::getSupplierCode,supplierCodes)
                    .in(PurchaseForecastPo::getCompanyCode,companyCodes)
                    .in(PurchaseForecastPo::getFactoryCode,factoryCodes)) ;

            importResult.setData(result);
            importResult.setImportFlag(true);
        }
        return importResult;
    }

    /**
     * 返回结果
     *
     * @param returnDataInfo
     * @throws BizException
     */
    @Override
    protected void afterProcess(ImportReturnDataInfo<PurchaseForecastImportResultResp> returnDataInfo) throws BizException {
        if(returnDataInfo.getImportFlag()){
            String bizType = BizTypeThreadHolder.getBizType();

            //校验成功

            List<PurchaseForecastImportResultResp> list = returnDataInfo.getData();
            List<PurchaseForecastPo> purchaseForecastPos = new ArrayList<>();
            for(PurchaseForecastImportResultResp resultResp:list){
                PurchaseForecastPo supplierPo = BeanCopierUtil.copy(resultResp, PurchaseForecastPo.class);
                supplierPo.setBizType(bizType);
                supplierPo.setCreateUser(UserUtil.getUserName());
                purchaseForecastPos.add(supplierPo);

            }
            purchaseForecastMapper.batchInsert(purchaseForecastPos);

        }else{
            //校验失败  返回失败文件地址
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
        }
    }

    private String createErrExcel(List<PurchaseForecastImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "供应商导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}",excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), PurchaseForecastImportResultResp.class).excludeColumnFiledNames(Arrays.asList("id"))
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet( "失败列表" ).build();
            writer.write(error,writeSheet1);
        }
        catch (Exception e) {
            log.error("PurchaseForecastImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        }finally {
            if(writer !=null){
                writer.finish();
            }
        }

        try(InputStream inputStream = Files.newInputStream(excelFile.toPath())){
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "供应商导入失败原因.xlsx");
            if (bosFileResult == null){
                throw new BizException( "异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        }catch (Exception e){
            log.error("PurchaseForecastImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if(excelFile.exists()){
                boolean delete = excelFile.delete();
                log.info("供应商导入失败原因临时文件删除结果：{}",delete);
            }
        }
    }
}
