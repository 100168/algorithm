package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.Enum.SupplyCycleTypeEnum;
import com.jiduauto.sps.server.caches.DictItemCache;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.SupplierCalendarMapper;
import com.jiduauto.sps.server.pojo.dto.param.SupplierCalendarCodeParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.SupplierCalendarPo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.req.SupplierCalendarImportReq;
import com.jiduauto.sps.server.pojo.vo.resp.SupplierCalendarImportResultResp;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Component
@Slf4j
public class SupplierCalendarImportHandler extends BaseImportHandler<SupplierCalendarImportReq, SupplierCalendarImportResultResp> {

    private static final Pattern TIME_INTERVAL_PATTERN = Pattern.compile(BaseConstants.Regex.SUPPLIER_CALENDAR_TIME_INTERVAL);

    private static final Pattern MONTHLY_PATTERN = Pattern.compile(BaseConstants.Regex.SUPPLIER_CALENDAR_MONTHLY);

    private static final Pattern WEEKLY_PATTERN = Pattern.compile(BaseConstants.Regex.SUPPLIER_CALENDAR_WEEKLY);

    @Resource
    private IBosService bosService;

    @Resource
    private DictItemCache dictItemCache;

    @Resource
    private SupplierCalendarMapper supplierCalendarMapper;

    @Resource
    private ICompanyService companyService;

    @Resource
    private ISupplierService supplierService;

    @Resource
    private IWarehouseService warehouseService;

    @Resource
    private IDictService dictService;

    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("*公司代码", "*仓库代码", "*供应商代码", "*供货周期类型", "*供货周期", "供货时间");

    public List<ImportDataInfo<SupplierCalendarImportReq>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        if (!dictService.isContained(BizTypeThreadHolder.getBizType(), DictEnum.BIZTYPE)) {
            throw new BizException("请输入正确的bizType");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<SupplierCalendarImportReq>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, SupplierCalendarImportReq.class, new ReadListener<SupplierCalendarImportReq>() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板表头数据不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(SupplierCalendarImportReq rowData, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");
                    }
                    if (rowData == null) {
                        return;
                    }
                    ImportDataInfo<SupplierCalendarImportReq> info = new ImportDataInfo<>();
                    info.setData(rowData);
                    importList.add(info);
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;
        } catch (Exception e) {
            log.error("零件主数据计划导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(e.getMessage());
        }
    }


    /**
     * 校验文件
     *
     * @param list
     * @return
     * @throws BizException
     */
    @Override
    protected ImportReturnDataInfo<SupplierCalendarImportResultResp> process(List<ImportDataInfo<SupplierCalendarImportReq>> list) throws BizException {
        ImportReturnDataInfo<SupplierCalendarImportResultResp> importResult = new ImportReturnDataInfo<>();
        List<SupplierCalendarImportResultResp> dataList = new ArrayList<>();

        String bizType = BizTypeThreadHolder.getBizType();

        List<String> excelDuplicateUniqueIds = getDuplicateUniqueIdFromExcel(list);
        List<String> dbDuplicateUniqueIds = getDuplicateUniqueIdFromDB(bizType, list.stream().map(ImportDataInfo::getData).collect(Collectors.toList()));

        Map<String, String> companyNameMap = companyService.getCodeAndNameMap(bizType, list.stream().map(ImportDataInfo::getData).map(SupplierCalendarImportReq::getCompanyCode).distinct().collect(Collectors.toList()));
        Map<String, String> supplierNameMap = supplierService.getCodeAndNameMap(bizType, list.stream().map(ImportDataInfo::getData).map(SupplierCalendarImportReq::getSupplierSapCode).distinct().collect(Collectors.toList()));
        Map<String, String> wareHouseNameMap = warehouseService.getCodeAndNameMap(bizType, list.stream().map(ImportDataInfo::getData).map(SupplierCalendarImportReq::getWarehouseCode).distinct().collect(Collectors.toList()));
        Map<String, String> supplyCycleTypeMap = dictItemCache.getNameAndCodeMap(DictEnum.SupplyCycleType.getDictCode());

        boolean hasError = false;
        for (ImportDataInfo<SupplierCalendarImportReq> importDataInfo : list) {
            SupplierCalendarImportResultResp resultResp = new SupplierCalendarImportResultResp();
            BeanUtils.copyProperties(importDataInfo.getData(), resultResp);
            StringBuilder errors = new StringBuilder();
            if (StringUtils.isEmpty(resultResp.getCompanyCode())) {
                errors.append("公司代码为空;");
            } else if (!companyNameMap.containsKey(resultResp.getCompanyCode())) {
                errors.append("公司代码不存在;");
            }
            if (StringUtils.isEmpty(resultResp.getSupplierSapCode())) {
                errors.append("供应商代码为空;");
            } else if (!supplierNameMap.containsKey(resultResp.getSupplierSapCode())) {
                errors.append("供应商代码不存在;");
            }
            if (StringUtils.isEmpty(resultResp.getWarehouseCode())) {
                errors.append("仓库代码为空;");
            } else if (!wareHouseNameMap.containsKey(resultResp.getWarehouseCode())) {
                errors.append("仓库代码不存在;");
            }
            if (StringUtils.isEmpty(resultResp.getSupplyCycleTypeName())) {
                errors.append("供货周期类型为空;");
            } else if (!supplyCycleTypeMap.containsKey(resultResp.getSupplyCycleTypeName())) {
                errors.append("供货周期类型不存在;");
            }
            if (StringUtils.isEmpty(resultResp.getSupplyCycleValue())) {
                errors.append("供货周期为空;");
            } else {
                Pattern pattern = null;
                if (SupplyCycleTypeEnum.MONTHLY.getItemName().equals(resultResp.getSupplyCycleTypeName())) {
                    pattern = MONTHLY_PATTERN;
                } else if (SupplyCycleTypeEnum.WEEKLY.getItemName().equals(resultResp.getSupplyCycleTypeName())) {
                    pattern = WEEKLY_PATTERN;
                }
                resultResp.setSupplyCycleValue(resultResp.getSupplyCycleValue().replace("，", ","));
                if (pattern != null && !pattern.matcher(resultResp.getSupplyCycleValue()).matches()) {
                    errors.append("供货周期不正确;");
                }
            }
            if (StringUtils.isNotEmpty(resultResp.getSupplyTime())) {
                resultResp.setSupplyTime(resultResp.getSupplyTime().replace("：", ":"));
                if (!TIME_INTERVAL_PATTERN.matcher(resultResp.getSupplyTime()).matches()) {
                    errors.append("供货时间不正确;");
                } else {
                    String[] localTimes = resultResp.getSupplyTime().split("-");
                    if (!DateUtils.localTimeBefore(localTimes[0], localTimes[1])) {
                        errors.append("供货时间不正确;");
                    }
                }
            }

            String uniqueId = concatUniqueId(resultResp);
            if (!CollectionUtils.isEmpty(excelDuplicateUniqueIds) && excelDuplicateUniqueIds.contains(uniqueId)) {
                errors.append("数据重复;");
            }
            if (!CollectionUtils.isEmpty(dbDuplicateUniqueIds) && dbDuplicateUniqueIds.contains(uniqueId)) {
                errors.append("数据已存在;");
            }

            if (errors.length() > 0) {
                hasError = true;
                resultResp.setErrorInfo(errors.toString());
            }
            dataList.add(resultResp);
        }

        if (hasError) {
            importResult.setError(dataList);
            importResult.setImportFlag(false);
        } else {
            importResult.setData(dataList);
            importResult.setImportFlag(true);
        }
        return importResult;
    }

    /**
     * 返回结果
     *
     * @param returnDataInfo
     * @throws BizException
     */
    @Override
    protected void afterProcess(ImportReturnDataInfo<SupplierCalendarImportResultResp> returnDataInfo) throws BizException {
        if (returnDataInfo.getImportFlag()) {
            if (CollectionUtils.isEmpty(returnDataInfo.getData())) {
                return;
            }
            String bizType = BizTypeThreadHolder.getBizType();
            Map<String, String> supplyCycleTypeMap = dictItemCache.getNameAndCodeMap(DictEnum.SupplyCycleType.getDictCode());
            List<SupplierCalendarPo> supplierCalendarPos = returnDataInfo.getData().stream().map(item -> {
                SupplierCalendarPo po = new SupplierCalendarPo();
                BeanUtils.copyProperties(item, po, "id");
                po.setBizType(bizType);
                po.setSupplyCycleType(supplyCycleTypeMap.get(item.getSupplyCycleTypeName()));
                po.setSupplyCycleValue(Arrays.stream(po.getSupplyCycleValue().split(",")).map(Integer::valueOf).distinct().sorted().map(Objects::toString).collect(Collectors.joining(",")));
                return po;
            }).collect(Collectors.toList());
            try {
                supplierCalendarMapper.batchInsert(supplierCalendarPos);
            }catch (DuplicateKeyException e){
                List<String> dbDuplicateUniqueIds = getDuplicateUniqueIdFromDB(bizType, returnDataInfo.getData());
                returnDataInfo.getData().stream()
                        .filter(item -> dbDuplicateUniqueIds.contains(concatUniqueId(item)))
                        .forEach(item -> item.setErrorInfo("数据已存在;"));
                returnDataInfo.setError(returnDataInfo.getData());
                assembleFailedResult(returnDataInfo);
            }
        } else {
            assembleFailedResult(returnDataInfo);
        }
    }

    private void assembleFailedResult(ImportReturnDataInfo<SupplierCalendarImportResultResp> returnDataInfo) {
        String fileKey = createErrExcel(returnDataInfo.getError());
        returnDataInfo.setImportFlag(false);
        returnDataInfo.setFileUrl(fileKey);
    }

    private String createErrExcel(List<SupplierCalendarImportResultResp> error) {
        File excelFile;
        try {
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "供应商日历导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            EasyExcel.write(excelFile.getAbsoluteFile(), SupplierCalendarImportResultResp.class)
                    .sheet("失败列表")
                    .doWrite(error);
        } catch (Exception e) {
            log.error("SupplierCalendarImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "供应商日历导入失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();
        } catch (Exception e) {
            log.error("SupplierCalendarImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("供应商导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }

    private List<String> getDuplicateUniqueIdFromExcel(List<ImportDataInfo<SupplierCalendarImportReq>> list) {
        return list.stream().map(ImportDataInfo::getData).map(this::concatUniqueId)
                .collect(Collectors.toMap(Function.identity(), item -> 1, Integer::sum))
                .entrySet().stream()
                .filter(item -> item.getValue() > 1)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    private List<String> getDuplicateUniqueIdFromDB(String bizType, List<? extends SupplierCalendarImportReq> list) {
        List<SupplierCalendarCodeParam> distinctCodeParams = list.stream()
                .collect(Collectors.toMap(this::concatUniqueId, Function.identity(), (p, n) -> n))
                .values().stream()
                .map(item -> {
                    SupplierCalendarCodeParam codeParam = new SupplierCalendarCodeParam();
                    BeanUtils.copyProperties(item, codeParam);
                    return codeParam;
                }).collect(Collectors.toList());
        return supplierCalendarMapper.listByBizAndCodes(bizType, distinctCodeParams).stream()
                .map(this::concatUniqueId)
                .distinct()
                .collect(Collectors.toList());
    }


    private String concatUniqueId(SupplierCalendarImportReq req) {
        return StringUtils.defaultString(req.getCompanyCode()).concat("_").concat(StringUtils.defaultString(req.getSupplierSapCode())).concat("_").concat(StringUtils.defaultString(req.getWarehouseCode()));
    }

    private String concatUniqueId(SupplierCalendarPo po) {
        return StringUtils.defaultString(po.getCompanyCode()).concat("_").concat(StringUtils.defaultString(po.getSupplierSapCode())).concat("_").concat(StringUtils.defaultString(po.getWarehouseCode()));
    }
}
