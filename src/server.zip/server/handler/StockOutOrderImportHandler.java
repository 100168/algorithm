package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.Enum.OrderProcessCode;
import com.jiduauto.sps.server.Enum.StockOperationType;
import com.jiduauto.sps.server.consts.*;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.*;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.AreasPo;
import com.jiduauto.sps.server.pojo.po.LocationsPo;
import com.jiduauto.sps.server.pojo.po.StockOutOrderItemPo;
import com.jiduauto.sps.server.pojo.po.StockOutOrderPo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockOutOrderImportResp;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockOutOrderImportResultResp;
import com.jiduauto.sps.server.service.IAreasService;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.service.ICommonService;
import com.jiduauto.sps.server.service.ILocationsService;
import com.jiduauto.sps.server.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 出库单导入
 */
@Service
@Slf4j
public class StockOutOrderImportHandler extends BaseImportHandler<StockOutOrderImportResp, StockOutOrderImportResultResp> {

    @Autowired
    private MaterialMapper materialMapper;
    @Autowired
    private WarehouseMapper warehouseMapper;
    @Autowired
    private IAreasService areasService;
    @Autowired
    private ILocationsService locationsService;
    @Autowired
    private SupplierMapper supplierMapper;
    @Autowired
    private PalletMapper palletMapper;
    @Autowired
    private WorkbinMapper workbinMapper;
    @Autowired
    private CarMapper carMapper;

    @Autowired
    private StockOutOrderMapper stockOutOrderMapper;
    @Autowired
    private StockOutOrderItemMapper stockOutOrderItemMapper;

    @Autowired
    private IBosService bosService;

    @Autowired
    private RedisUtil redisUtil;
    @Autowired
    private ICommonService commonService;

    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("出库日期", "出库类型", "领用人", "使用人", "出库人员", "工位", "关联车号", "备注",
                    "零件编码", "零件种类", "零件状态", "样件状态", "车辆号", "批次", "序列号", "零件条码", "入库日期",
                    "生产日期", "失效日期", "实出数量", "项目", "阶段", "WBS编号", "业务单号", "业务单行号",
                    "供应商代码", "仓库代码", "区域代码", "库位代码", "托盘号", "料箱号", "备注");

    public List<ImportDataInfo<StockOutOrderImportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<StockOutOrderImportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, StockOutOrderImportResp.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        StockOutOrderImportResp data = (StockOutOrderImportResp) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (Exception e) {
            log.error("出库单导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "出库单导入解析异常,请检查文件格式");
        }
    }

    @Override
    protected ImportReturnDataInfo<StockOutOrderImportResultResp> process(List<ImportDataInfo<StockOutOrderImportResp>> list) throws BizException {
        ImportReturnDataInfo<StockOutOrderImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        List<String> materialNumbers = new ArrayList<>();
        log.info("出库单导入:" + JSON.toJSONString(list));
        boolean hasError = false;
        String bizType = BizTypeThreadHolder.getBizType();
        Set<String> warehouseCodes = new HashSet<>();
        Set<String> supplierCodes = new HashSet<>();
        Set<String> areaCodes = new HashSet<>();
        Set<String> locationCodes = new HashSet<>();
        Set<String> palletCodes = new HashSet<>();
        Set<String> workbinCodes = new HashSet<>();
        Set<String> carCodes = new HashSet<>();
        Map<String, String> checkMap = new HashMap<>();

        Integer no = 0;
        List<StockOutOrderImportResultResp> resultResps = new ArrayList<>();
        for (ImportDataInfo<StockOutOrderImportResp> dataInfo : list) {
            StockOutOrderImportResp resp = dataInfo.getData();
            StockOutOrderImportResultResp resultResp = new StockOutOrderImportResultResp();
            BeanUtils.copyProperties(resp, resultResp);
            StringBuilder sb = new StringBuilder();
            warehouseCodes.add(resp.getWarehouseCode());
            areaCodes.add(resp.getAreaCode());
            locationCodes.add(resp.getLocationCode());
            String s = resp.getOutDate() + resp.getOutType() + resp.getReceiveUser();
            s = s.replaceAll("null", "");
            StockOutOrderItemPo itemPo = BeanCopierUtil.copy(resultResp, StockOutOrderItemPo.class);
            if (StringUtils.isNotBlank(s)) {
                no++;
                resp.setOrderNumber(String.valueOf(no));
            } else {
                resp.setOrderNumber(String.valueOf(no));
            }
//            String objectString = commonService.getObjectString(itemPo, ColumnNameArrayEnum.OUT_ORDER_IMPORT_COLUMN.getCode());
//            if (checkMap.containsKey(objectString)) {
//                sb.append("该单下该零件物料(" + resp.getMaterialNumber() + ")存在除备注,与数量外其他字段一样的重复物料");
//                hasError = true;
//            } else {
//                checkMap.put(objectString, objectString);
//            }

            if (StringUtils.isNotBlank(resp.getPalletCode())) {
                palletCodes.add(resp.getPalletCode());

            }
            if (StringUtils.isNotBlank(resp.getWorkbinCode())) {
                workbinCodes.add(resp.getWorkbinCode());

            }
            if (StringUtils.isNotBlank(resp.getCarCode())) {
                carCodes.add(resp.getCarCode());

            }
            if (StringUtils.isNotBlank(resp.getSupplierCode())) {
                supplierCodes.add(resp.getSupplierCode());
            }
            if (resp.getOutDate() == null && StringUtils.isNotBlank(resp.getOutType())) {
                //日期为空
                sb.append("出库日期不可以为空;");
                hasError = true;
            }
            if (resp.getOutDate() != null && StringUtils.isBlank(resp.getOutType())) {
                //出库类型代码为空
                sb.append("出库类型代码不可以为空;");
                hasError = true;
            }

            if (StringUtils.isNotBlank(resp.getOutType())) {
                String inTypeDesc = commonService.getDictItemDesc(DictEnum.OutboundType, resp.getOutType());
                if (StringUtils.isBlank(inTypeDesc)) {
                    sb.append("出库类型代码和数据字典不符合;");
                    hasError = true;
                }
                if (resp.getOutType().equals(StockOperationType.QXSHCK.getOperationType())) {
                    sb.append("取消收货出库类型请在出库单页面新建;");
                    hasError = true;
                }
            }

            if (StringUtils.isNotBlank(resp.getWorkStation())) {
                String inTypeDesc = commonService.getDictItemDesc(DictEnum.WorkStation, resp.getWorkStation());
                if (StringUtils.isBlank(inTypeDesc)) {
                    sb.append("工位和数据字典不符合;");
                    hasError = true;
                }
            }


            materialNumbers.add(resp.getMaterialNumber());
            if (StringUtils.isEmpty(resp.getMaterialNumber())) {
                sb.append("零件编码不可以为空;");
                hasError = true;
            }
            //取消项目与阶段必填校验
//            if(StringUtils.isBlank(resp.getProjectCode())){
//                sb.append("项目不可以为空;");
//                hasError = true;
//            }
//            if(StringUtils.isBlank(resp.getStageCode())){
//                sb.append("阶段不可以为空;");
//                hasError = true;
//            }
            if (StringUtils.isNotBlank(resp.getProjectCode())) {
                if (StringUtils.isBlank(commonService.getDictItemDesc(DictEnum.Project, resp.getProjectCode()))) {
                    sb.append("项目和数据字典不匹配;");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(resp.getStageCode())) {
                if (StringUtils.isBlank(commonService.getDictItemDesc(DictEnum.Stage, resp.getStageCode()))) {
                    sb.append("阶段和数据字典不匹配;");
                    hasError = true;
                }
            }
            //供应商非必填
          /*  if (StringUtils.isEmpty(resp.getSupplierCode())) {
                sb.append("供应商代码不可以为空;");
                hasError = true;
            }*/
            if (StringUtils.isEmpty(resp.getWarehouseCode())) {
                sb.append("仓库代码不可以为空;");
                hasError = true;
            }
//            if (StringUtils.isEmpty(resp.getAreaCode())) {
//                sb.append("区域代码不可以为空;");
//                hasError = true;
//            }
//            if (StringUtils.isEmpty(resp.getLocationCode())) {
//                sb.append("库位代码不可以为空;");
//                hasError = true;
//            }

            if (StringUtils.isNotBlank(resp.getMaterialSort()) &&
                    resp.getMaterialSort().equals(MaterialSortEnum.special.getDesc()) &&
                    StringUtils.isBlank(resp.getCarCode())) {
                sb.append("车辆号不可以为空;");
                hasError = true;
            }


            if (StringUtils.isEmpty(resp.getOutQuantity())) {
                sb.append("出库数量不可以为空;");
                hasError = true;
            } else {
                if (!NumberUtil.isNumeric(resp.getOutQuantity())) {
                    sb.append("出库数量必须是数字;");
                    hasError = true;
                }
                if (NumberUtil.isNumeric(resp.getOutQuantity()) && new BigDecimal(resp.getOutQuantity()).compareTo(BigDecimal.ZERO) < 0) {
                    sb.append("出库数量必须大于0;");
                    hasError = true;
                }
            }
            resultResp.setErrorInfo(sb.toString());
            resultResps.add(resultResp);
        }
        List<String> warehousePo = new ArrayList<>();
        List<String> supplierPos = new ArrayList<>();
        Map<String,AreasPo> areasPos = new HashMap<>();
        Map<String, LocationsPo> locationsPos = new HashMap<>();
        List<String> carPos = new ArrayList<>();
        List<String> workbinPos = new ArrayList<>();
        List<String> palletPos = new ArrayList<>();
        if (!CollectionUtils.isEmpty(warehouseCodes)) {
            warehousePo = warehouseMapper.getByWCodes(bizType, new ArrayList<>(warehouseCodes));
        }
        if (!CollectionUtils.isEmpty(supplierCodes)) {
            supplierPos = supplierMapper.getDistinctByBizAndCodes(bizType, new ArrayList<>(supplierCodes));
        }
        if (!CollectionUtils.isEmpty(areaCodes)) {
            areasPos = areasService.mapWarehouseCodeAndAreaCodeKey(bizType,new ArrayList<>(areaCodes));
        }
        if (!CollectionUtils.isEmpty(locationCodes)) {
            locationsPos = locationsService.mapWarehouseCodeAreaCodeLocationKey(bizType, new ArrayList<>(locationCodes));
        }
        if (!CollectionUtils.isEmpty(carCodes)) {
            carPos = carMapper.getByWPCodes(bizType, new ArrayList<>(carCodes));
        }
        if (!CollectionUtils.isEmpty(workbinCodes)) {
            workbinPos = workbinMapper.getByWPCodes(bizType, new ArrayList<>(workbinCodes));
        }
        if (!CollectionUtils.isEmpty(palletCodes)) {
            palletPos = palletMapper.getByWPCodes(bizType, new ArrayList<>(palletCodes));
        }

        List<String> duplicate = materialMapper.selectDistinctByNumbers(bizType, materialNumbers);

        for (StockOutOrderImportResultResp resultResp : resultResps) {
            StringBuilder sb = new StringBuilder(resultResp.getErrorInfo());
            if (resultResp.getMaterialNumber() != null && !duplicate.contains(resultResp.getMaterialNumber())) {
                sb.append("该零件编码不存在;");
                hasError = true;
            }
            if (resultResp.getWarehouseCode() != null && !warehousePo.contains(resultResp.getWarehouseCode())) {
                sb.append("该仓库不存在;");
                hasError = true;
            }
            if (resultResp.getSupplierCode() != null && !supplierPos.contains(resultResp.getSupplierCode())) {
                sb.append("该供应商编码不存在;");
                hasError = true;
            }
            if (resultResp.getAreaCode() != null && !areasPos.containsKey(resultResp.getWarehouseCode() + resultResp.getAreaCode())) {
                sb.append("该区域不存在;");
                hasError = true;
            }
            if (resultResp.getCarCode() != null && !carPos.contains(resultResp.getCarCode())) {
                sb.append("该车辆编码不存在;");
                hasError = true;
            }
            if (resultResp.getWorkbinCode() != null && !workbinPos.contains(resultResp.getWorkbinCode())) {
                sb.append("该料箱号不存在;");
                hasError = true;
            }
            if (resultResp.getPalletCode() != null && !palletPos.contains(resultResp.getPalletCode())) {
                sb.append("该托盘号不存在;");
                hasError = true;
            }
            if (resultResp.getLocationCode() != null && !locationsPos.containsKey(resultResp.getWarehouseCode() + resultResp.getAreaCode() +
                    resultResp.getLocationCode())) {
                sb.append("该库位不存在;");
                hasError = true;
            }
            resultResp.setErrorInfo(sb.toString());
        }

        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    @Override
    protected void afterProcess(ImportReturnDataInfo<StockOutOrderImportResultResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        } else {
            String bizType = BizTypeThreadHolder.getBizType();

            Map<String, BigDecimal> sumMap = new HashMap<>();
            // 校验通过 保存出库
            List<StockOutOrderPo> orderPos = new ArrayList<>();
            List<StockOutOrderItemPo> orderItemPos = new ArrayList<>();
            String lastOrderNumber = null;
            String user = UserUtil.getUserName();
            for (StockOutOrderImportResultResp resultResp : returnDataInfo.getData()) {
                if (StringUtils.isBlank(resultResp.getMaterialStatus())) {
                    resultResp.setMaterialStatus(MaterialStockStatusEnum.S1.getDesc());
                }
                if (StringUtils.isBlank(resultResp.getMaterialSort())) {
                    resultResp.setMaterialSort(MaterialSortEnum.normal.getDesc());
                }
                if (resultResp.getOutDate() == null) {
                    //子项
                    StockOutOrderItemPo itemPo = BeanCopierUtil.copy(resultResp, StockOutOrderItemPo.class);
                    itemPo.setOrderNumber(lastOrderNumber);
                    itemPo.setBizType(bizType);
                    itemPo.setCreateUser(user);
                    itemPo.setUpdateUser(user);
                    itemPo.setRemark(StringUtils.defaultIfNull(resultResp.getRemarkItem()));
                    itemPo.setMaterialSort(commonService.getDictItemCode(DictEnum.MaterialSort, resultResp.getMaterialSort()));
                    itemPo.setMaterialStatus(commonService.getDictItemCode(DictEnum.MaterialStockStatus, resultResp.getMaterialStatus()));
                    itemPo.setOutQuantity(new BigDecimal(resultResp.getOutQuantity()));
                    orderItemPos.add(itemPo);
                    BigDecimal sum = sumMap.get(lastOrderNumber).add(new BigDecimal(resultResp.getOutQuantity()));
                    sumMap.put(lastOrderNumber, sum);
                } else {
                    StockOutOrderPo po = new StockOutOrderPo();
                    String orderNumber = commonService.initStockOutOrderNumber(bizType);
                    po.setOrderNumber(orderNumber);
                    po.setOutDate(DateUtils.getLocalDateTimeStr(resultResp.getOutDate(), DateUtils.STANDARD_DATE_FORMAT));
                    po.setOutType(resultResp.getOutType());
                    po.setStockSource("SYS");
                    po.setStatus(StockOrderStatus.putIn.getCode());
                    po.setStockOutUser(resultResp.getStockOutUser());
                    po.setUseUser(resultResp.getUseUser());
                    po.setReceiveUser(resultResp.getReceiveUser());
                    po.setWorkStation(resultResp.getWorkStation());
                    po.setBizType(bizType);
                    po.setCreateUser(user);
                    po.setUpdateUser(user);
                    po.setRemark(StringUtils.defaultIfNull(resultResp.getRemark()));
                    po.setAssociationCar(StringUtils.defaultIfNull(resultResp.getAssociationCar()));
                    po.setProcessCode(OrderProcessCode.P204.getCode());
                    orderPos.add(po);
                    StockOutOrderItemPo itemPo = BeanCopierUtil.copy(resultResp, StockOutOrderItemPo.class);
                    itemPo.setOrderNumber(orderNumber);
                    itemPo.setBizType(bizType);
                    itemPo.setCreateUser(user);
                    itemPo.setUpdateUser(user);
                    itemPo.setMaterialSort(commonService.getDictItemCode(DictEnum.MaterialSort, resultResp.getMaterialSort()));
                    itemPo.setMaterialStatus(commonService.getDictItemCode(DictEnum.MaterialStockStatus, resultResp.getMaterialStatus()));
                    itemPo.setRemark(StringUtils.defaultIfNull(resultResp.getRemarkItem()));
                    orderItemPos.add(itemPo);
                    itemPo.setOutQuantity(new BigDecimal(resultResp.getOutQuantity()));
                    sumMap.put(orderNumber, new BigDecimal(resultResp.getOutQuantity()));
                    lastOrderNumber = orderNumber;
                }

            }

            for (StockOutOrderPo tempPo : orderPos) {
                tempPo.setSumQuantity(sumMap.get(tempPo.getOrderNumber()));
                if(StringUtils.isBlank(tempPo.getWorkStation())){
                    tempPo.setWorkStation("");
                }
            }
            stockOutOrderItemMapper.batchInsert(orderItemPos);
            stockOutOrderMapper.batchInsert(orderPos);

        }
        returnDataInfo.setImportFlag(true);
    }

    private String createErrExcel(List<StockOutOrderImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "出库单导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), StockOutOrderImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("materialImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("materialImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("出库单导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }


}
