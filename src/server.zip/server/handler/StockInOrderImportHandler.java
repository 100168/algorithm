package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.Enum.OrderProcessCode;
import com.jiduauto.sps.server.consts.*;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.*;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.AreasPo;
import com.jiduauto.sps.server.pojo.po.LocationsPo;
import com.jiduauto.sps.server.pojo.po.StockInOrderItemPo;
import com.jiduauto.sps.server.pojo.po.StockInOrderPo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockInOrderImportResp;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockInOrderImportResultResp;
import com.jiduauto.sps.server.service.IAreasService;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.service.ICommonService;
import com.jiduauto.sps.server.service.ILocationsService;
import com.jiduauto.sps.server.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 入库单导入
 */
@Service
@Slf4j
public class StockInOrderImportHandler extends BaseImportHandler<StockInOrderImportResp, StockInOrderImportResultResp> {

    @Autowired
    private MaterialMapper materialMapper;
    @Autowired
    private WarehouseMapper warehouseMapper;
    @Autowired
    private IAreasService areasService;
    @Autowired
    private ILocationsService locationsService;
    @Autowired
    private SupplierMapper supplierMapper;
    @Autowired
    private PalletMapper palletMapper;
    @Autowired
    private WorkbinMapper workbinMapper;
    @Autowired
    private CarMapper carMapper;

    @Autowired
    private StockInOrderMapper stockInOrderMapper;
    @Autowired
    private StockInOrderItemMapper stockInOrderItemMapper;
    @Autowired
    private IBosService bosService;
    @Autowired
    private ICommonService commonService;

    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("入库日期", "入库类型代码", "验收人", "备注","零件编码", "零件种类", "车辆号", "零件状态", "样件状态", "批次", "序列号", "零件条码", "生产日期", "失效日期", "入库数量", "项目", "阶段", "WBS编号", "业务单号", "业务单行号", "PSS分类", "供应商代码", "仓库代码", "区域代码", "库位代码", "托盘号", "料箱号", "备注");

    public List<ImportDataInfo<StockInOrderImportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<StockInOrderImportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, StockInOrderImportResp.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        StockInOrderImportResp data = (StockInOrderImportResp) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (Exception e) {
            log.error("入库单导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "入库单导入解析异常,请检查文件格式");
        }
    }

    @Override
    protected ImportReturnDataInfo<StockInOrderImportResultResp> process(List<ImportDataInfo<StockInOrderImportResp>> list) throws BizException {
        ImportReturnDataInfo<StockInOrderImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        Set<String> materialNumbers = new HashSet<>();
        log.info("入库单导入:" + JSON.toJSONString(list));
        boolean hasError = false;
        String bizType = BizTypeThreadHolder.getBizType();
        Set<String> warehouseCodes = new HashSet<>();
        Set<String> supplierCodes = new HashSet<>();
        Set<String> areaCodes = new HashSet<>();
        Set<String> locationCodes = new HashSet<>();
        Set<String> palletCodes = new HashSet<>();
        Set<String> workbinCodes = new HashSet<>();
        Set<String> carCodes = new HashSet<>();
        Map<String, String> checkMap = new HashMap<>();
        Integer no = 0;
        List<StockInOrderImportResultResp> resultResps = new ArrayList<>();
        for (ImportDataInfo<StockInOrderImportResp> dataInfo : list) {
            StockInOrderImportResp resp = dataInfo.getData();
            StockInOrderImportResultResp resultResp = new StockInOrderImportResultResp();
            BeanUtils.copyProperties(resp, resultResp);
            StringBuilder sb = new StringBuilder();
            warehouseCodes.add(resp.getWarehouseCode());
            areaCodes.add(resp.getAreaCode());
            locationCodes.add(resp.getLocationCode());
            String s = resp.getInDate() + resp.getInType() + resp.getCheckUser();
            s = s.replaceAll("null", "");
            if (StringUtils.isNotBlank(s)) {
                no++;
                resp.setOrderNumber(String.valueOf(no));
            } else {
                resp.setOrderNumber(String.valueOf(no));
            }
            StockInOrderItemPo itemPo = BeanCopierUtil.copy(resp, StockInOrderItemPo.class);
//            String objectString = commonService.getObjectString(itemPo, ColumnNameArrayEnum.IN_ORDER_IMPORT_COLUMN.getCode());
//            if (checkMap.containsKey(objectString)) {
//                sb.append("该单下该零件物料(" + resp.getMaterialNumber() + ")存在除备注,与数量外其他字段一样的重复物料");
//                hasError = true;
//            } else {
//                checkMap.put(objectString, objectString);
//            }
            if (StringUtils.isNotBlank(resp.getPalletCode())) {
                palletCodes.add(resp.getPalletCode());

            }
            if (StringUtils.isNotBlank(resp.getWorkbinCode())) {
                workbinCodes.add(resp.getWorkbinCode());

            }
            if (StringUtils.isNotBlank(resp.getCarCode())) {
                carCodes.add(resp.getCarCode());

            }
            if (StringUtils.isNotBlank(resp.getSupplierCode())) {
                supplierCodes.add(resp.getSupplierCode());

            }

            materialNumbers.add(resp.getMaterialNumber());

            if (resp.getInDate() == null && StringUtils.isNotBlank(resp.getInType())) {
                //日期为空
                sb.append("入库日期不可以为空;");
                hasError = true;
            }
            if (resp.getInDate() != null && StringUtils.isBlank(resp.getInType())) {
                //日期为空
                sb.append("入库类型代码不可以为空;");
                hasError = true;
            }

            if (StringUtils.isNotBlank(resp.getInType())) {
                String inTypeDesc = commonService.getDictItemDesc(DictEnum.InboundType, resp.getInType());
                if (StringUtils.isBlank(inTypeDesc)) {
                    sb.append("入库类型代码和数据字典不符合;");
                    hasError = true;
                }
            }


            if (StringUtils.isEmpty(resp.getMaterialNumber())) {
                sb.append("零件编码不可以为空;");
                hasError = true;
            }

            if (StringUtils.isNotBlank(resp.getMaterialStatus())) {
                String code = commonService.getDictItemCode(DictEnum.MaterialStockStatus, resp.getMaterialStatus());
                if (StringUtils.isBlank(code)) {
                    sb.append("零件状态和数据字典不匹配;");
                    hasError = true;
                }
            }

            if (StringUtils.isNotBlank(resp.getProjectCode())) {
                if (StringUtils.isBlank(commonService.getDictItemDesc(DictEnum.Project, resp.getProjectCode()))) {
                    sb.append("项目和数据字典不匹配;");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(resp.getStageCode())) {
                if (StringUtils.isBlank(commonService.getDictItemDesc(DictEnum.Stage, resp.getStageCode()))) {
                    sb.append("阶段和数据字典不匹配;");
                    hasError = true;
                }
            }
            //取消供应商必填验证
          /*  if (StringUtils.isEmpty(resp.getSupplierCode())) {
                sb.append("供应商代码不可以为空;");
                hasError = true;
            }*/
            if (StringUtils.isEmpty(resp.getWarehouseCode())) {
                sb.append("仓库代码不可以为空;");
                hasError = true;
            }
//            if (StringUtils.isEmpty(resp.getAreaCode())) {
//                sb.append("区域代码不可以为空;");
//                hasError = true;
//            }
//            if (StringUtils.isEmpty(resp.getLocationCode())) {
//                sb.append("库位代码不可以为空;");
//                hasError = true;
//            }

            if (StringUtils.isBlank(resp.getMaterialSort())) {
                resp.setMaterialSort(MaterialSortEnum.normal.getDesc());
            }
            if (resp.getMaterialSort().equals(MaterialSortEnum.special.getDesc()) &&
                    StringUtils.isBlank(resp.getCarCode())) {
                sb.append("车辆号不可以为空;");
                hasError = true;
            }


            if (StringUtils.isEmpty(resp.getInQuantity())) {
                sb.append("入库数量不可以为空;");
                hasError = true;
            } else {
                if (!NumberUtil.isNumeric(resp.getInQuantity())) {
                    sb.append("入库数量必须是数字;");
                    hasError = true;
                }
                if (NumberUtil.isNumeric(resp.getInQuantity()) && new BigDecimal(resp.getInQuantity()).compareTo(BigDecimal.ZERO) < 0) {
                    sb.append("出库数量必须大于0;");
                    hasError = true;
                }
            }


            resultResp.setErrorInfo(sb.toString());
            resultResps.add(resultResp);
        }
        //过滤掉carCode为空的因为不是必填
        List<String> cCollect = carCodes.stream().filter((e
        ) -> {
            return StringUtils.isNotBlank(e);
        }).collect(Collectors.toList());
        List<String> warehousePo = new ArrayList<>();
        List<String> supplierPos = new ArrayList<>();
        Map<String,AreasPo> areasPos = new HashMap<>();
        Map<String, LocationsPo> locationsPos = new HashMap<>();
        List<String> carPos = new ArrayList<>();
        List<String> workbinPos = new ArrayList<>();
        List<String> palletPos = new ArrayList<>();
        if (!CollectionUtils.isEmpty(warehouseCodes)) {
            warehousePo = warehouseMapper.getByWCodes(bizType, new ArrayList<>(warehouseCodes));
        }
        if (!CollectionUtils.isEmpty(supplierCodes)) {
            supplierPos = supplierMapper.getDistinctByBizAndCodes(bizType, new ArrayList<>(supplierCodes));
        }
        if (!CollectionUtils.isEmpty(areaCodes)) {
            areasPos = areasService.mapWarehouseCodeAndAreaCodeKey(bizType,new ArrayList<>(areaCodes));
        }
        if (!CollectionUtils.isEmpty(locationCodes)) {
            locationsPos = locationsService.mapWarehouseCodeAreaCodeLocationKey(bizType, new ArrayList<>(locationCodes));
        }
        if (!CollectionUtils.isEmpty(carCodes)) {

            carPos = carMapper.getByWPCodes(bizType, new ArrayList<>(cCollect));
        }
        if (!CollectionUtils.isEmpty(workbinCodes)) {
            workbinPos = workbinMapper.getByWPCodes(bizType, new ArrayList<>(workbinCodes));
        }
        if (!CollectionUtils.isEmpty(palletCodes)) {
            palletPos = palletMapper.getByWPCodes(bizType, new ArrayList<>(palletCodes));
        }

        List<String> duplicate = materialMapper.selectDistinctByNumbers(bizType, new ArrayList<>(materialNumbers));

        for (StockInOrderImportResultResp resultResp : resultResps) {
            StringBuilder sb = new StringBuilder(resultResp.getErrorInfo());
            if (resultResp.getMaterialNumber() != null && !duplicate.contains(resultResp.getMaterialNumber())) {
                sb.append("该零件编码不存在;");
                hasError = true;
            }
            if (resultResp.getWarehouseCode() != null && !warehousePo.contains(resultResp.getWarehouseCode())) {
                sb.append("该仓库不存在;");
                hasError = true;
            }
            if (resultResp.getSupplierCode() != null && !supplierPos.contains(resultResp.getSupplierCode())) {
                sb.append("该供应商编码不存在;");
                hasError = true;
            }
            if (StringUtils.isNotBlank(resultResp.getAreaCode()) && !areasPos.containsKey(resultResp.getWarehouseCode() + resultResp.getAreaCode())) {
                sb.append("该区域不存在;");
                hasError = true;
            }
            if (resultResp.getCarCode() != null && !carPos.contains(resultResp.getCarCode())) {
                sb.append("该车辆编码不存在;");
                hasError = true;
            }
            if (resultResp.getWorkbinCode() != null && !workbinPos.contains(resultResp.getWorkbinCode())) {
                sb.append("该料箱号不存在;");
                hasError = true;
            }
            if (resultResp.getPalletCode() != null && !palletPos.contains(resultResp.getPalletCode())) {
                sb.append("该托盘号不存在;");
                hasError = true;
            }
            if (StringUtils.isNotBlank(resultResp.getLocationCode() ) && !locationsPos.containsKey(resultResp.getWarehouseCode() +
                    resultResp.getAreaCode() + resultResp.getLocationCode())) {
                sb.append("该库位不存在;");
                hasError = true;
            }
            resultResp.setErrorInfo(sb.toString());
        }

        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    @Override
    protected void afterProcess(ImportReturnDataInfo<StockInOrderImportResultResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        } else {
            String bizType = BizTypeThreadHolder.getBizType();
            Map<String, BigDecimal> sumMap = new HashMap<>();

            // 校验通过 保存入库
            List<StockInOrderPo> orderPos = new ArrayList<>();
            List<StockInOrderItemPo> orderItemPos = new ArrayList<>();
            String lastOrderNumber = null;
            String user = UserUtil.getUserName();
            for (StockInOrderImportResultResp resultResp : returnDataInfo.getData()) {
                if (StringUtils.isBlank(resultResp.getMaterialStatus())) {
                    resultResp.setMaterialStatus(MaterialStockStatusEnum.S1.getDesc());
                }
                if (StringUtils.isBlank(resultResp.getMaterialSort())) {
                    resultResp.setMaterialSort(MaterialSortEnum.normal.getDesc());
                }
                if (resultResp.getInDate() == null) {
                    //子项
                    StockInOrderItemPo itemPo = BeanCopierUtil.copy(resultResp, StockInOrderItemPo.class);
                    itemPo.setOrderNumber(lastOrderNumber);
                    itemPo.setBizType(bizType);
                    itemPo.setCreateUser(user);
                    itemPo.setDelRight(1);
                    itemPo.setPlanInQuantity(BigDecimal.ZERO);
                    itemPo.setRemark(resultResp.getRemarkItem());
                    itemPo.setUpdateUser(user);
                    itemPo.setInQuantity(new BigDecimal(resultResp.getInQuantity()));
                    itemPo.setMaterialSort(commonService.getDictItemCode(DictEnum.MaterialSort, resultResp.getMaterialSort()));
                    itemPo.setMaterialStatus(commonService.getDictItemCode(DictEnum.MaterialStockStatus, resultResp.getMaterialStatus()));
                    orderItemPos.add(itemPo);
                    BigDecimal sum = sumMap.get(lastOrderNumber).add(new BigDecimal(resultResp.getInQuantity()));
                    sumMap.put(lastOrderNumber, sum);
                } else {
                    StockInOrderPo po = new StockInOrderPo();
                    String orderNumber = commonService.initStockInOrderNumber(bizType);
                    po.setOrderNumber(orderNumber);
                    po.setInDate(DateUtils.getLocalDateTimeStr(resultResp.getInDate(), DateUtils.STANDARD_DATE_FORMAT));
                    po.setInType(resultResp.getInType());
                    po.setCheckUser(resultResp.getCheckUser());
                    po.setStockSource("SYS");
                    po.setStatus(StockOrderStatus.putIn.getCode());
                    po.setBizType(bizType);
                    po.setCreateUser(user);
                    po.setUpdateUser(user);
                    po.setRemark(StringUtils.defaultIfNull(resultResp.getRemark()));
                    orderPos.add(po);
                    StockInOrderItemPo itemPo = BeanCopierUtil.copy(resultResp, StockInOrderItemPo.class);
                    itemPo.setOrderNumber(orderNumber);
                    itemPo.setDelRight(1);
                    itemPo.setPlanInQuantity(BigDecimal.ZERO);
                    itemPo.setBizType(bizType);
                    itemPo.setRemark(StringUtils.defaultIfNull(resultResp.getRemarkItem()));
                    itemPo.setCreateUser(user);
                    itemPo.setUpdateUser(user);
                    itemPo.setInQuantity(new BigDecimal(resultResp.getInQuantity()));
                    itemPo.setMaterialSort(commonService.getDictItemCode(DictEnum.MaterialSort, resultResp.getMaterialSort()));
                    itemPo.setMaterialStatus(commonService.getDictItemCode(DictEnum.MaterialStockStatus, resultResp.getMaterialStatus()));
                    sumMap.put(orderNumber, new BigDecimal(resultResp.getInQuantity()));
                    orderItemPos.add(itemPo);
                    lastOrderNumber = orderNumber;
                }

            }

            for (StockInOrderPo tempPo : orderPos) {
                tempPo.setSumQuantity(sumMap.get(tempPo.getOrderNumber()));
                tempPo.setProcessCode(OrderProcessCode.P104.getCode());
            }
            stockInOrderItemMapper.batchInsert(orderItemPos);
            stockInOrderMapper.batchInsert(orderPos);

        }
        returnDataInfo.setImportFlag(true);
    }

    private String createErrExcel(List<StockInOrderImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "零件主数据导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), StockInOrderImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("materialImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("materialImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("零件主数据导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }


}
