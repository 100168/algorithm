package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.server.Enum.SpsResponseCodeEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.StoreMapper;
import com.jiduauto.sps.server.mapper.StoreWarehouseConfigMapper;
import com.jiduauto.sps.server.mapper.WarehouseMapper;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.StoreWarehouseConfigResultResp;
import com.jiduauto.sps.server.pojo.po.StorePo;
import com.jiduauto.sps.server.pojo.po.StoreWarehouseConfigPo;
import com.jiduauto.sps.server.pojo.po.WarehousePo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.req.StoreWarehouseAndPriority;
import com.jiduauto.sps.server.pojo.vo.req.StoreWarehouseConfigEditAndAddReq;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.utils.CollectionUtils;
import com.jiduauto.sps.server.utils.StringUtils;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @ClassName StoreWarehouseConfigImportHandler
 * @AuThor O_chaopeng.huang
 * @Date 2023/3/13 15:08
 * @Version 5.0
 */
@Service
@Slf4j
public class StoreWarehouseConfigImportHandler extends BaseImportHandler<StoreWarehouseConfigResultResp, StoreWarehouseConfigResultResp> {

    private static final Integer MAX_LIMIT = 500;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("*门店code", "*仓库优先级", "*仓库代码");
    @Autowired
    private WarehouseMapper warehouseMapper;
    @Autowired
    private IBosService bosService;
    @Autowired
    private StoreWarehouseConfigMapper storeWarehouseConfigMapper;
    @Autowired
    private StoreMapper storeMapper;

    public List<ImportDataInfo<StoreWarehouseConfigResultResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<StoreWarehouseConfigResultResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, StoreWarehouseConfigResultResp.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    try {
                        List<String> headList = readCellDataList.stream().filter(e -> StringUtils.isNotBlank(e.getStringValue())).map((s) -> {
                            String replace = s.getStringValue().replace("\n", "");
                            return replace;
                        }).collect(Collectors.toList());
                        if (!Objects.equals(headList, HEAD_VALUE_LIST) || headList.size() <= 0 || CollectionUtils.isEmpty(headList)) {
                            throw new BizException("模板表头数据不合规, 请检查！");
                        }
                    } catch (BizException e) {
                        throw new BizException("模板表头数据不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");
                    }
                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        StoreWarehouseConfigResultResp data = (StoreWarehouseConfigResultResp) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;
        } catch (Exception e) {
            log.error("库位主数据计划导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(e.getMessage());
        }
    }

    @Override
    protected ImportReturnDataInfo<StoreWarehouseConfigResultResp> process(List<ImportDataInfo<StoreWarehouseConfigResultResp>> list) throws BizException {
        String bizType = BizTypeThreadHolder.getBizType();
        ImportReturnDataInfo<StoreWarehouseConfigResultResp> importResult = new ImportReturnDataInfo<>();
        List<String> saleStoreCodes = new ArrayList<>();
        List<String> saleWarehouses = new ArrayList<>();
        List<String> salePriority = new ArrayList<>();
        Map<String, String> storeWarehouse = new HashMap<>();
        boolean hasError = false;
        List<StoreWarehouseConfigResultResp> resultResps = new ArrayList<>();
        for (ImportDataInfo<StoreWarehouseConfigResultResp> data : list) {
            StringBuilder errors = new StringBuilder();
            StoreWarehouseConfigResultResp planResp = data.getData();
            StoreWarehouseConfigResultResp resultResp = new StoreWarehouseConfigResultResp();
            BeanUtils.copyProperties(planResp, resultResp);
            if (StringUtils.isBlank(planResp.getStoreCode())) {
                errors.append("门店code为空;");
                hasError = true;
            } else {
                saleStoreCodes.add(planResp.getStoreCode());
            }
            if (StringUtils.isBlank(planResp.getWarehouseCode())) {
                errors.append("仓库代码为空;");
                hasError = true;
            } else {
                String s = storeWarehouse.get(planResp.getStoreCode());
                if (storeWarehouse.containsKey(planResp.getStoreCode() + planResp.getWarehouseCode())) {
                    errors.append("同一门店下同一仓库代码不能重复;");
                    hasError = true;
                } else {
                    saleWarehouses.add(planResp.getWarehouseCode());
                    storeWarehouse.put(planResp.getStoreCode() + planResp.getWarehouseCode(), planResp.getWarehouseCode());
                }
            }
            if (StringUtils.isBlank(planResp.getPriority())) {
                errors.append("优先级不能为空;");
                hasError = true;
            } else {
                Pattern pattern = Pattern.compile("[1-9]*");
                Matcher isNum = pattern.matcher(planResp.getPriority());
                if( !isNum.matches() ){
                    errors.append("优先级必须为正整数;");
                    hasError = true;
                }
                salePriority.add(planResp.getPriority());
            }
            resultResp.setErrorInfo(errors.toString());
            resultResps.add(resultResp);
        }
        if (CollectionUtils.isNotEmpty(saleStoreCodes) && CollectionUtils.isNotEmpty(saleWarehouses)) {
            LambdaQueryWrapper<StoreWarehouseConfigPo> wrapper = Wrappers.lambdaQuery();
            wrapper.eq(StoreWarehouseConfigPo::getBizType, bizType)
                    .in(StoreWarehouseConfigPo::getStoreCode, saleStoreCodes);
            List<StoreWarehouseConfigPo> storeWarehouseConfigPos = storeWarehouseConfigMapper.selectList(wrapper);
            List<StoreWarehouseConfigPo> collect = storeWarehouseConfigPos.stream().filter((e) -> {
                return e != null;
            }).collect(Collectors.toList());
            if (CollectionUtils.isNotEmpty(collect)) {
                for (StoreWarehouseConfigResultResp resultResp : resultResps) {
                    for (StoreWarehouseConfigPo po : collect) {
                        if (resultResp.getStoreCode().equals(po.getStoreCode()) && resultResp.getWarehouseCode().equals(po.getWarehouseCode())) {
                            if (StringUtils.isEmpty(resultResp.getErrorInfo())) {
                                resultResp.setErrorInfo("门店仓库配置已存在;");
                            } else {
                                resultResp.setErrorInfo(resultResp.getErrorInfo() + "门店仓库配置已存在;");
                            }
                            hasError = true;
                        }
                    }
                    for (StoreWarehouseConfigPo po : collect) {
                        if (resultResp.getStoreCode().equals(po.getStoreCode())
                                && resultResp.getPriority().equals(String.valueOf(po.getPriority()))) {
                            if (StringUtils.isEmpty(resultResp.getErrorInfo())) {
                                resultResp.setErrorInfo("该门店仓库配置该优先级重复;");
                            } else {
                                resultResp.setErrorInfo(resultResp.getErrorInfo() + "该门店仓库配置该优先级重复;");
                            }
                            hasError = true;
                        }
                    }
                }
            }
        }
        if (CollectionUtils.isNotEmpty(saleWarehouses)) {
            List<String> byBizAndCodes = warehouseMapper.getByWCodes(bizType, saleWarehouses);
            for (StoreWarehouseConfigResultResp resultResp : resultResps) {
                if (!byBizAndCodes.contains(resultResp.getWarehouseCode())) {
                    if (StringUtils.isEmpty(resultResp.getErrorInfo())) {
                        resultResp.setErrorInfo("填写的仓库代码不存在;");
                    } else {
                        resultResp.setErrorInfo(resultResp.getErrorInfo() + "填写的仓库代码不存在;");
                    }
                    hasError = true;
                }
            }
        }
        if (CollectionUtils.isNotEmpty(saleStoreCodes)) {
            //校验门店
            List<String> storePos = storeMapper.selectList(new LambdaQueryWrapper<StorePo>().in(StorePo::getStoreCode, saleStoreCodes)).stream().map((itm) -> {
                return itm.getStoreCode();
            }).collect(Collectors.toList());
            for (StoreWarehouseConfigResultResp resultResp : resultResps) {
                if (!storePos.contains(resultResp.getStoreCode())) {
                    if (StringUtils.isEmpty(resultResp.getErrorInfo())) {
                        resultResp.setErrorInfo("填写的门店code不存在;");
                    } else {
                        resultResp.setErrorInfo(resultResp.getErrorInfo() + "填写的门店code不存在;");
                    }
                    hasError = true;
                }
            }
        }
        if (hasError) {
            importResult.setError(resultResps);
            importResult.setImportFlag(false);
        } else {
            importResult.setData(resultResps);
            importResult.setImportFlag(true);
        }
        return importResult;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    protected void afterProcess(ImportReturnDataInfo<StoreWarehouseConfigResultResp> returnDataInfo) throws BizException {
        String bizType = BizTypeThreadHolder.getBizType();
        String userName = UserUtil.getUserName();
        if (!org.springframework.util.CollectionUtils.isEmpty(returnDataInfo.getError())) {
            //校验失败  返回失败文件地址
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        }
        List<StoreWarehouseConfigResultResp> data = returnDataInfo.getData();
        List<StoreWarehouseConfigPo> collect = data.stream().map((itm) -> {
            StoreWarehouseConfigPo po = new StoreWarehouseConfigPo();
            BeanUtils.copyProperties(itm, po);
            po.setPriority(Integer.valueOf(itm.getPriority()));
            po.setBizType(bizType);
            return po;
        }).collect(Collectors.toList());
            List<String> storeCodes = new ArrayList<>();
            for (StoreWarehouseConfigResultResp datum : data) {
                storeCodes.add(datum.getStoreCode());
            }
            LambdaQueryWrapper<StoreWarehouseConfigPo> wrapper = new LambdaQueryWrapper<StoreWarehouseConfigPo>()
                    .eq(StoreWarehouseConfigPo::getBizType, bizType)
                    .in(StoreWarehouseConfigPo::getStoreCode, storeCodes);
            List<StoreWarehouseConfigPo> poList = storeWarehouseConfigMapper.selectList(wrapper);
            //如果该门店存在仓库配置
            if (CollectionUtils.isNotEmpty(poList)) {
                List<StoreWarehouseConfigPo> oldAndNewList = new ArrayList<>();
                List<StoreWarehouseConfigPo> newList = new ArrayList<>();
                //将存在的与不存在的区分出来
                for (StoreWarehouseConfigPo oldPo : poList) {
                    for (StoreWarehouseConfigPo newPo : collect) {
                        if (oldPo.getStoreCode().equals(newPo.getStoreCode())) {
                            oldAndNewList.add(oldPo);
                            oldAndNewList.add(newPo);
                        }
                    }
                }
                for (StoreWarehouseConfigPo newPo : collect) {
                    if (!newList.contains(newPo) && !oldAndNewList.contains(newPo)) {
                        newList.add(newPo);
                    }
                }
                //去除重复的根据门店分类再按优先级倒序
                oldAndNewList = oldAndNewList.stream().distinct().sorted(Comparator.comparing(StoreWarehouseConfigPo::getStoreCode)
                        .thenComparing(StoreWarehouseConfigPo::getPriority).reversed()).map((itm) -> {
                    itm.setUpdateUser(userName);
                    return itm;
                }).collect(Collectors.toList());
                //已有仓库配置的门店添加修改人信息
                storeWarehouseConfigMapper.updateBatch(poList);
                //删除原有的
                storeWarehouseConfigMapper.delete(wrapper);
                //重新新增
                storeWarehouseConfigMapper.insertBatch(oldAndNewList);
                //如果有门店不存在仓库配置直接新增
                if (CollectionUtils.isNotEmpty(newList)) {
                    newList = newList.stream().distinct().map((itm) -> {
                        itm.setCreateUser(userName);
                        return itm;
                    }).collect(Collectors.toList());
                    storeWarehouseConfigMapper.insertBatch(newList);
                }
            } else {
                collect = collect.stream().map((itm) -> {
                    itm.setCreateUser(userName);
                    return itm;
                }).collect(Collectors.toList());
                //没有直接新增
                storeWarehouseConfigMapper.insertBatch(collect);
            }
        returnDataInfo.setImportFlag(true);
    }

    private String createErrExcel(List<StoreWarehouseConfigResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "库位主数据计划导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), StoreWarehouseConfigResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("StoreWarehouseConfigResultResp-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }
        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "计划导入失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();
        } catch (Exception e) {
            log.error("StoreWarehouseConfigResultResp-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("门店仓库配置计划导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }
}
