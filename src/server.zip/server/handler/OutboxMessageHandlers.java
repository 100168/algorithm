package com.jiduauto.sps.server.handler;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.dit.outbox.anno.MessageHandle;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.pojo.Result;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.server.Enum.AsnSyncIndexEnum;
import com.jiduauto.sps.server.Enum.PRDetailStatusEnum;
import com.jiduauto.sps.server.client.*;
import com.jiduauto.sps.server.client.req.*;
import com.jiduauto.sps.server.client.resp.*;
import com.jiduauto.sps.server.consts.BaseConstants.AsnSyncIndex;
import com.jiduauto.sps.server.consts.BaseConstants.RoSyncIndex;
import com.jiduauto.sps.server.convertor.InboundReqConvertor;
import com.jiduauto.sps.server.convertor.OutboundReqConvertor;
import com.jiduauto.sps.server.convertor.RoSrmReqConvertor;
import com.jiduauto.sps.server.convertor.SapReqConvertor;
import com.jiduauto.sps.server.pojo.dto.LingkeBOCancelContextDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderAuditEditDto;
import com.jiduauto.sps.server.pojo.po.AsnBasicPo;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderPo;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderPo;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.service.impl.stock.SapServiceImpl;
import com.jiduauto.sps.server.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import static com.jiduauto.sps.server.consts.BaseConstants.KitOrderSyncIndex.INBOUND;
import static com.jiduauto.sps.server.consts.OutboxConst.MessageType.*;

/**
 * @author panjian
 */
@Component
@Slf4j
public class OutboxMessageHandlers {

    @Resource
    private OutboundReqConvertor outboundReqConvertor;

    @Resource
    private RoSrmReqConvertor roSrmReqConvertor;

    @Resource
    private InboundReqConvertor inboundReqConvertor;
    @Resource
    private PdpClient pdpClient;
    @Resource
    private WmsClient wmsClient;
    @Resource
    private SrmClient srmClient;

    @Resource
    private IMaterialService materialService;

    @Resource
    private SapReqConvertor sapReqConvertor;


    @Resource
    private SAPRestAdapterClient sapRestAdapterClient;

    @Resource
    private IPurchaseApplyOrderService purchaseApplyOrderService;
    @Resource
    private IPurchaseApplyOrderDetailService purchaseApplyOrderDetailService;

    @Resource
    private SpsOrderClient spsOrderClient;


    @Resource
    private IStockOutMapBusinessService stockOutMapBusinessService;


    @Resource
    private SapServiceImpl sapService;

    @Resource
    private QEClient qeClient;

    @Resource
    private IAsnPushService asnPushService;

    /**
     * 采购退货出库异步同步dhl
     */
    @MessageHandle(msgType = RETURN_ORDER_PUSH)
    public Result roDhlOutBoundHandle(OutboxMessage outboxMessage) {
        PurchaseReturnOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseReturnOrderPo.class);
        DHLOutboundReq dhlOutboundReq = outboundReqConvertor.toDhlOutBoundReq(orderPo);
        ResultResp<Object> resultResp = pdpClient.outbound(dhlOutboundReq);
        log.info("OutboxMessageHandler#roDhlOutBoundHandle, param: {}, result: {}",
                JsonUtil.toJsonString(dhlOutboundReq), JsonUtil.toJsonString(resultResp));
        if(resultResp.isSuccess()){
            stockOutMapBusinessService.createOrUpdateForPR(orderPo,dhlOutboundReq);
        }
        return resultResp.isSuccess() ? Result.success() : Result.error(resultResp.getMsg());
    }

    /**
     * 采购退货审核通过同步srm
     */
    @MessageHandle(msgType = RETURN_ORDER_PUSH, bitIndex = RoSyncIndex.SRM)
    public Result roPushSrmHandle(OutboxMessage outboxMessage) {
        PurchaseReturnOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseReturnOrderPo.class);
        RoSyncSrmReq roSyncSrmReq = roSrmReqConvertor.toSrmReq(orderPo);
        RoSyncSrmResp resultResp = srmClient.syncPurchaseOrder(roSyncSrmReq);
        log.info("OutboxMessageHandler#pushToSrmHandle, param: {}, result: {}", JsonUtil.toJsonString(roSyncSrmReq),
                JsonUtil.toJsonString(resultResp));
        return RoSyncSrmResp.success(resultResp) ? Result.success() : Result.error(resultResp.getErrorMsg());
    }

    /**
     * 免费订单、计划外订单 采购申请审核通过同步dhl入库
     */
    @MessageHandle(msgType = PURCHASE_APPLY_ORDER_TO_DHL)
    public Result prDhlInBoundHandle(OutboxMessage outboxMessage) {
        PurchaseApplyOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseApplyOrderPo.class);
        AsnAddSyncReq inBoundReq = inboundReqConvertor.toInBoundReq(orderPo);
        ResultResp<Object> resultResp = wmsClient.pushAsn(inBoundReq);
        log.info("OutboxMessageHandler#prDhlInBoundHandle, param: {}, result: {}", JsonUtil.toJsonString(inBoundReq),
                JsonUtil.toJsonString(resultResp));
        return resultResp.isSuccess() ? Result.success() : Result.error(resultResp.getMsg());
    }

    /**
     * 采购申请审核通过同步sap
     * */
    @MessageHandle(msgType = PURCHASE_APPLY_ORDER_TO_SAP)
    public Result prToSapHandle(OutboxMessage outboxMessage) {
        PurchaseApplyOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseApplyOrderPo.class);
        DfsOrderPlanSyncReq dfsOrderPlanSyncReq = sapReqConvertor.toDfsOrderPlanSyncReq(orderPo);
        DfsOrderPlanSyncResp dfsOrderPlanSyncResp = sapRestAdapterClient.syncDfsOrderPlan(dfsOrderPlanSyncReq);
        //反写sap号
        if (DfsOrderPlanSyncResp.success(dfsOrderPlanSyncResp)) {
            orderPo.setSapOrderNo(dfsOrderPlanSyncResp.getMessageBody()[0].getHeader().getEBELN());
            purchaseApplyOrderService.update(Wrappers.<PurchaseApplyOrderPo>lambdaUpdate()
                    .eq(PurchaseApplyOrderPo::getId, orderPo.getId())
                    .set(PurchaseApplyOrderPo::getSapOrderNo, orderPo.getSapOrderNo()));
        }
        return DfsOrderPlanSyncResp.success(dfsOrderPlanSyncResp) ? Result.success() : Result.error(JSONUtil.toJsonStr(dfsOrderPlanSyncResp));
    }

    /**
     * 采购申请删除同步sap
     * */
    @MessageHandle(msgType = PR_DELETE_TO_SAP)
    public Result prDeleteToSapHandle(OutboxMessage outboxMessage) {
        PurchaseApplyOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseApplyOrderPo.class);
        List<PurchaseApplyOrderDetailPo> detailPos = purchaseApplyOrderDetailService.listByOrderId(orderPo.getId());
        detailPos = detailPos.stream().peek(e -> e.setIsDel(true)).collect(Collectors.toList());
        DelOrderPlanSyncForModeFReq delOrderPlanSyncForModeFReq = sapReqConvertor.toDelOrderPlanSyncForModeFReq(orderPo, detailPos);
        DelOrderPlanSyncForModeFResp resp = sapRestAdapterClient.syncDelOrderPlanForModeF(delOrderPlanSyncForModeFReq);
        return DelOrderPlanSyncForModeFResp.success(resp) ? Result.success() : Result.error(JSONUtil.toJsonStr(resp));
    }

    /**
     * 采购申请已审核编辑同步sap
     */
    @MessageHandle(msgType = PR_AUDIT_EDIT_TO_SAP)
    public Result prAuditDeleteToSapHandle(OutboxMessage outboxMessage) {
        PurchaseApplyOrderAuditEditDto dto = JSONUtil.toBean(outboxMessage.getContent(), PurchaseApplyOrderAuditEditDto.class);
        DelOrderPlanSyncForModeFReq delOrderPlanSyncForModeFReq = sapReqConvertor.toDelOrderPlanSyncForModeFReq(dto.getOrderPo(), dto.getDetailPos());
        DelOrderPlanSyncForModeFResp resp = sapRestAdapterClient.syncDelOrderPlanForModeF(delOrderPlanSyncForModeFReq);
        return DelOrderPlanSyncForModeFResp.success(resp) ? Result.success() : Result.error(JSONUtil.toJsonStr(resp));
    }

    /**
     *领克采购申请取消同步sap*/
    @MessageHandle(msgType = PR_CANCEL_TO_SAP)
    public Result prCancelToSapHandle(OutboxMessage outboxMessage) {
        PurchaseApplyOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseApplyOrderPo.class);
        List<PurchaseApplyOrderDetailPo> detailPos = purchaseApplyOrderDetailService.listByOrderId(orderPo.getId());
        detailPos = detailPos.stream().filter(e -> e.getSpsStatus().equals(PRDetailStatusEnum.PASS.getCode())).peek(e -> e.setIsDel(true)).collect(Collectors.toList());
        DelOrderPlanSyncForModeFReq delOrderPlanSyncForModeFReq = sapReqConvertor.toDelOrderPlanSyncForModeFReq(orderPo, detailPos);
        DelOrderPlanSyncForModeFResp resp = sapRestAdapterClient.syncDelOrderPlanForModeF(delOrderPlanSyncForModeFReq);
        return DelOrderPlanSyncForModeFResp.success(resp) ? Result.success() : Result.error(JSONUtil.toJsonStr(resp));
    }

    /**
     * 领克缺件取消同步SAP
     */
    @MessageHandle(msgType = LINGKE_BO_CANCEL_TO_SAP)
    public Result lingkeBOCancelToSap(OutboxMessage outboxMessage) {
        LingkeBOCancelContextDto context = JsonUtil.toObject(outboxMessage.getContent(), LingkeBOCancelContextDto.class);
        List<PurchaseApplyOrderDetailPo> prUpdateList = context.getPrUpdateList();
        prUpdateList = prUpdateList.stream().peek(e -> {
            if (e.getQty().compareTo(BigDecimal.ZERO) == 0) {
                e.setIsDel(true);
            }
        }).collect(Collectors.toList());
        PurchaseApplyOrderPo po = purchaseApplyOrderService.getById(prUpdateList.get(0).getOrderId());
        DelOrderPlanSyncForModeFReq delOrderPlanSyncForModeFReq = sapReqConvertor.toDelOrderPlanSyncForModeFReq(po, prUpdateList);
        DelOrderPlanSyncForModeFResp resp = sapRestAdapterClient.syncDelOrderPlanForModeF(delOrderPlanSyncForModeFReq);
        return DelOrderPlanSyncForModeFResp.success(resp) ? Result.success() : Result.error(JSONUtil.toJsonStr(resp));
    }


    /**
     * kit订单出库指令
     */
    @MessageHandle(msgType = KIT_ORDER_CONFIRM_OR_CANCEL)
    public Result kitDhlOutboundHandle(OutboxMessage outboxMessage) {
        KitOrderPo kitOrderPo = JsonUtil.toObject(outboxMessage.getContent(), KitOrderPo.class);
        DHLOutboundReq dhlOutboundReq = outboundReqConvertor.toDhlOutBoundReq(kitOrderPo);
        ResultResp<Object> resultResp = pdpClient.outbound(dhlOutboundReq);
        log.info("OutboxMessageHandler#kitDhlOutboundHandle, param: {}, result: {}",
                JsonUtil.toJsonString(dhlOutboundReq), JsonUtil.toJsonString(resultResp));
        if(resultResp.isSuccess()){
            stockOutMapBusinessService.createOrUpdateForKit(kitOrderPo,dhlOutboundReq);
        }
        return resultResp.isSuccess() ? Result.success() : Result.error(resultResp.getMsg());
    }

    /**
     * kit订单入库指令
     */
    @MessageHandle(msgType = KIT_ORDER_CONFIRM_OR_CANCEL, bitIndex = INBOUND)
    public Result kitDhlInboundHandle(OutboxMessage outboxMessage) {
        KitOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), KitOrderPo.class);
        AsnAddSyncReq inBoundReq = inboundReqConvertor.toInBoundReq(orderPo);
        ResultResp<Object> resultResp = wmsClient.pushAsn(inBoundReq);
        log.info("OutboxMessageHandler#kitDhlInboundHandle, param: {}, result: {}", JsonUtil.toJsonString(inBoundReq),
                JsonUtil.toJsonString(resultResp));
        return resultResp.isSuccess() ? Result.success() : Result.error(resultResp.getMsg());
    }


//    /**
//     * 履约完成同步sap
//     */
////    @Deprecated
////    @MessageHandle(msgType = SM_ORDER_RECEIVE_TO_SAP)
////    public Result smReceiveToSapHandle(OutboxMessage outboxMessage) {
//        WarehouseDistributeOrderPo po = JSONUtil.toBean(outboxMessage.getContent(), WarehouseDistributeOrderPo.class);
//        SMCompleteSyncSapReq smCompleteSyncSapReq = SMCompleteSyncSapReq.newInstance();
//        smCompleteSyncSapReq.setBodyHead(po);
//        SapResp sapResp = sapRestAdapterClient.SMOrderCompleteSync(smCompleteSyncSapReq);
//        log.info("OutboxMessageHandler#smReceiveToSapHandle, param: {}, result: {}", JsonUtil.toJsonString(smCompleteSyncSapReq),
//                JsonUtil.toJsonString(sapResp));
//        return SapResp.success(sapResp) ? Result.success() : Result.error(JsonUtil.toJsonString(sapResp));
//    }

//    @MessageHandle(msgType = WD_ORDER_TO_DHL)
//    public Result wdOrderToDhlInbound(OutboxMessage outboxMessage) {
//        WarehouseDistributeOrderAllPo allPo = JSONUtil.toBean(outboxMessage.getContent(), WarehouseDistributeOrderAllPo.class);
//        AsnAddSyncReq inBoundReq = inboundReqConvertor.toInBoundReq(allPo);
//        ResultResp<Object> resultResp = wmsClient.pushAsn(inBoundReq);
//        log.info("OutboxMessageHandler#wdOrderToDhlInbound, param: {}, result: {}", JsonUtil.toJsonString(inBoundReq),
//                JsonUtil.toJsonString(resultResp));
//        return resultResp.isSuccess() ? Result.success() : Result.error(resultResp.getMsg());
//    }
//
//    /**
//     * 履约完成同步sap
//     */
//    @MessageHandle(msgType = SM11_TO_SAP)
//    public Result sm11ReceiveToSapHandle(OutboxMessage outboxMessage) {
//        InAndOutStockRequest request = JSONUtil.toBean(outboxMessage.getContent(), InAndOutStockRequest.class);
//        SMCompleteSyncSapReq smCompleteSyncSapReq = SMCompleteSyncSapReq.newInstance();
//        MM033SyncReq mm033SyncReq = MM033SyncReq.newInstance();
//        OrderNoReq orderNoReq = new OrderNoReq();
//        orderNoReq.setBizType(request.getBizType());
//        orderNoReq.setOrderNo(request.getTradeNo());
//        BaseResult<WarehouseDistributeOrderPo> resp = spsOrderClient.wdOrderGetByBusinessNo(orderNoReq);
//        mm033SyncReq.setBodyHead(resp.getData());
//        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(request.getParams().stream().map(InAndOutStockParam::getMaterialCode).collect(Collectors.toList()));
//        mm033SyncReq.setBodyItem(request, materialPoMap);
//        SapRespList sapResp = sapRestAdapterClient.syncToMm033(mm033SyncReq);
//        log.info("OutboxMessageHandler#sm11ReceiveToSapHandle, param: {}, result: {}", JsonUtil.toJsonString(smCompleteSyncSapReq),
//                JsonUtil.toJsonString(sapResp));
//        return SapRespList.success(sapResp) ? Result.success() : Result.error(JsonUtil.toJsonString(sapResp));
//    }

    /**
     * 试制 ASN 收货同步 SAP
     */
    @MessageHandle(msgType = VP_ASN_RECEIVE_TO_SAP)
    public Result vpAsnReceiveToSapHandle(OutboxMessage outboxMessage) {
        AsnReceiveSyncReq request = JSONUtil.toBean(outboxMessage.getContent(), AsnReceiveSyncReq.class);
        SapResp sapResp = sapRestAdapterClient.syncReceiveInfo(request);
        log.info("OutboxMessageHandler#vpAsnReceiveToSapHandle, param: {}, result: {}", JsonUtil.toJsonString(request),
                JsonUtil.toJsonString(sapResp));
        return SapResp.success(sapResp) ? Result.success() : Result.error(JsonUtil.toJsonString(sapResp));
    }

    /**
     *  门店SO单 总仓发货（出库）同步给SAP
     */
    @MessageHandle(msgType = SP_SO_DELIVER_TO_SAP_SD014)
    public Result spSpDeliverToSapSd014(OutboxMessage outboxMessage) {
        InAndOutStockRequest request = JSONUtil.toBean(outboxMessage.getContent(), InAndOutStockRequest.class);
        try{
            sapService.updateStockSp20ToSAP(request);
        }catch (Exception e){
            log.info("OutboxMessageHandler#spSpDeliverToSapSd014#error, param: {}, result: {}", JsonUtil.toJsonString(request),
                    e.getMessage());
            return Result.error(e.getMessage());
        }
        return Result.success() ;
    }

    /**
     * 质量出入库同步质量系统
     */
    @MessageHandle(msgType = STOCK_IN_AND_OUT_TO_QE)
    public Result stockInAndOutToQE(OutboxMessage outboxMessage) {
        StockInAndOutSynQEReq request = JSONUtil.toBean(outboxMessage.getContent(), StockInAndOutSynQEReq.class);
        BaseResult<String> ret = qeClient.synStock(request);
        log.info("OutboxMessageHandler#stockInAndOutToQE, param: {}, result: {}", JsonUtil.toJsonString(request),
                JsonUtil.toJsonString(ret));
        return ret.getCode() == 0 ? Result.success() : Result.error(JsonUtil.toJsonString(ret));
    }

    @MessageHandle(msgType = ASN_PUSH_THIRD_WAREHOUSE)
    public Result pushESWarehouse(OutboxMessage outboxMessage) {
        AsnBasicPo asnBasicPo = JSONUtil.toBean(outboxMessage.getContent(), AsnBasicPo.class);
        BaseResult ret = asnPushService.doPushAsnSyncByOutbox(asnBasicPo, AsnSyncIndexEnum.ES.getBitIndex());
        log.info("OutboxMessageHandler#pushESWarehouse, param: {}, result: {}", outboxMessage.getContent(),
                JsonUtil.toJsonString(ret));
        return ret.getCode() == 0 ? Result.success() : Result.error(JsonUtil.toJsonString(ret));
    }

    @MessageHandle(msgType = ASN_PUSH_THIRD_WAREHOUSE, bitIndex = AsnSyncIndex.WMS)
    public Result pushWMSWarehouse(OutboxMessage outboxMessage) {
        AsnBasicPo asnBasicPo = JSONUtil.toBean(outboxMessage.getContent(), AsnBasicPo.class);
        BaseResult ret = asnPushService.doPushAsnSyncByOutbox(asnBasicPo, AsnSyncIndexEnum.WMS.getBitIndex());
        log.info("OutboxMessageHandler#pushWMSWarehouse, param: {}, result: {}", outboxMessage.getContent(),
                JsonUtil.toJsonString(ret));
        return ret.getCode() == 0 ? Result.success() : Result.error(JsonUtil.toJsonString(ret));
    }

}
