package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.SupplierMapper;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.SupplierContactPo;
import com.jiduauto.sps.server.pojo.po.SupplierPo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.material.SupplierImportResp;
import com.jiduauto.sps.server.pojo.vo.resp.material.SupplierImportResultResp;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.service.ISupplierService;
import com.jiduauto.sps.server.utils.BeanCopierUtil;
import com.jiduauto.sps.server.utils.CollectionUtils;
import com.jiduauto.sps.server.utils.RedisUtil;
import com.jiduauto.sps.server.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
public class SupplierImportHandler extends BaseImportHandler<SupplierImportResp, SupplierImportResultResp>{
    @Autowired
    private IBosService bosService;
    @Autowired
    private SupplierMapper supplierMapper;

    @Autowired
    private ISupplierService supplierService;
    @Autowired
    private RedisUtil redisUtil;

    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("供应商代码","供应商名称","发货地址","主联系人","联系电话","邮箱","备注","联系人2","联系电话","邮箱","备注","联系人3","联系电话","邮箱","备注");

    public List<ImportDataInfo<SupplierImportResp>> readFile(MultipartFile file) throws BizException {
        if(file.isEmpty()){
            throw new BizException("文件不能为空");
        }
        try(InputStream inputStream = file.getInputStream()){
            List<ImportDataInfo<SupplierImportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream,SupplierImportResp.class,new ReadListener(){
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if(headMap == null){
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s->s.getStringValue().replace("\n","")).collect(Collectors.toList());
                    if(!Objects.equals(headList,HEAD_VALUE_LIST)){
                        throw new BizException("模板表头数据不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if(rowNumber > MAX_LIMIT+1){
                        throw new BizException("单次导入最大数据量"+MAX_LIMIT+"行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try{
                        ImportDataInfo info = new ImportDataInfo();
                        SupplierImportResp data = (SupplierImportResp)o;
                        if(data != null){
                            info.setData(data);
                            importList.add(info);
                        }
                    }catch(Exception e){
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        }catch(Exception e){
            log.error("零件主数据计划导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(e.getMessage());
        }
    }


    /**
     * 校验文件
     *
     * @param list
     * @return
     * @throws BizException
     */
    @Override
    protected ImportReturnDataInfo<SupplierImportResultResp> process(List<ImportDataInfo<SupplierImportResp>> list) throws BizException {
        boolean hasError = false;
        ImportReturnDataInfo<SupplierImportResultResp> importResult = new ImportReturnDataInfo();
        String bizType = BizTypeThreadHolder.getBizType();
        List<String> codes = new ArrayList<>();
        List<SupplierImportResultResp> result = new ArrayList<>();
        Map<String,SupplierImportResultResp> map = new HashMap<>();
        for(ImportDataInfo<SupplierImportResp> dataInfo:list){
            SupplierImportResp resp = dataInfo.getData();
            SupplierImportResultResp resultResp =  BeanCopierUtil.copy(resp,SupplierImportResultResp.class );
            StringBuilder sb = new StringBuilder();
            if(StringUtils.isBlank(resp.getSapCode())){
                sb.append("供应商代码不能为空;");
                hasError = true;
            }else{
                codes.add(resp.getSapCode());
                if(map.containsKey(resp.getSapCode())){
                    sb.append("供应商代码有重复记录，请检查;");
                    hasError = true;
                }else{
                    map.put(resp.getSapCode(),resultResp);
                }
            }
            if(StringUtils.isBlank(resp.getSupplierName())){
                sb.append("供应商名称不能为空;");
                hasError = true;
            }

            if(StringUtils.isBlank(resp.getAddress())){
                sb.append("发货地址不能为空;");
                hasError = true;
            }

            if(StringUtils.isBlank(resp.getName1())){
                sb.append("主联系人不能为空;");
                hasError = true;
            }

            if(StringUtils.isBlank(resp.getMobile1())){
                sb.append("主联系人联系电话不能为空;");
                hasError = true;
            }
            if(hasError){
                resultResp.setErrorInfo(sb.toString());
            }
            result.add(resultResp);
        }

        List<SupplierPo> supplierPos = supplierMapper.getByBizAndCodes(bizType,codes);
        if(CollectionUtils.isNotEmpty(supplierPos)){
            hasError = true;
            //不为空 表示有记录 已经存在
            for(SupplierPo po: supplierPos){
                SupplierImportResultResp resultResp = map.get(po.getSapCode());
                if(StringUtils.isBlank(resultResp.getErrorInfo())){
                    resultResp.setErrorInfo("供应商代码已经存在;");
                }else{
                    resultResp.setErrorInfo("供应商代码已经存在;"+resultResp.getErrorInfo());
                }
            }
        }

        if(hasError){
            importResult.setError(result);
            importResult.setImportFlag(false);
        }else{
            importResult.setData(result);
            importResult.setImportFlag(true);
        }
        return importResult;
    }

    /**
     * 返回结果
     *
     * @param returnDataInfo
     * @throws BizException
     */
    @Override
    protected void afterProcess(ImportReturnDataInfo<SupplierImportResultResp> returnDataInfo) throws BizException {
        if(returnDataInfo.getImportFlag()){
            String bizType = BizTypeThreadHolder.getBizType();

            //校验成功
            String operationType = (String)getThreadLocal().get();
            List<SupplierImportResultResp> list = returnDataInfo.getData();
            List<SupplierPo> supplierPos = new ArrayList<>();
            List<SupplierContactPo> contactPos = new ArrayList<>();
            for(SupplierImportResultResp resultResp:list){
                SupplierPo supplierPo = BeanCopierUtil.copy(resultResp, SupplierPo.class);
                Long id = supplierPo.getId();
                if("new".equals(operationType)){
                    id = IdUtil.getSnowflake().nextId();
                    supplierPo.setId(id);
                    supplierPo.setBizType(bizType);
                }
                supplierPo.setStatus(StringUtils.defaultIfNull(supplierPo.getStatus(),""));
                supplierPos.add(supplierPo);
                SupplierContactPo contactPo1 = new SupplierContactPo();
                contactPo1.setSupplierId(id);
                contactPo1.setContactName(resultResp.getName1());
                contactPo1.setEmail(resultResp.getEmail1());
                contactPo1.setMobile(resultResp.getMobile1());
                contactPo1.setRemark(resultResp.getRemark1());
                contactPo1.setStatus(1);
                contactPos.add(contactPo1);
                if(StringUtils.isNotBlank(resultResp.getName2())){
                    SupplierContactPo contactPo2 = new SupplierContactPo();
                    contactPo2.setSupplierId(id);
                    contactPo2.setContactName(resultResp.getName2());
                    contactPo2.setEmail(resultResp.getEmail2());
                    contactPo2.setMobile(resultResp.getMobile2());
                    contactPo2.setRemark(resultResp.getRemark2());
                    contactPo2.setStatus(2);
                    contactPos.add(contactPo2);
                }
                if(StringUtils.isNotBlank(resultResp.getName3())){
                    SupplierContactPo contactPo3 = new SupplierContactPo();
                    contactPo3.setSupplierId(id);
                    contactPo3.setContactName(resultResp.getName3());
                    contactPo3.setEmail(resultResp.getEmail3());
                    contactPo3.setMobile(resultResp.getMobile3());
                    contactPo3.setRemark(resultResp.getRemark3());
                    contactPo3.setStatus(3);
                    contactPos.add(contactPo3);
                }
            }
            supplierService.batchInsert(supplierPos,contactPos);

        }else{
            //校验失败  返回失败文件地址
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
        }
    }

    private String createErrExcel(List<SupplierImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "供应商导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}",excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), SupplierImportResultResp.class).excludeColumnFiledNames(Arrays.asList("id"))
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet( "失败列表" ).build();
            writer.write(error,writeSheet1);
        }
        catch (Exception e) {
            log.error("supplierImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        }finally {
            if(writer !=null){
                writer.finish();
            }
        }

        try(InputStream inputStream = Files.newInputStream(excelFile.toPath())){
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "供应商导入失败原因.xlsx");
            if (bosFileResult == null){
                throw new BizException( "异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        }catch (Exception e){
            log.error("supplierImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if(excelFile.exists()){
                boolean delete = excelFile.delete();
                log.info("供应商导入失败原因临时文件删除结果：{}",delete);
            }
        }
    }
}
