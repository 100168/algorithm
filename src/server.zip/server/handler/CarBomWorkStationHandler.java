package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.sdk.enums.CarBomStatusEnum;
import com.jiduauto.sps.sdk.pojo.fileImport.CarBomImportResp;
import com.jiduauto.sps.sdk.pojo.fileImport.CarBomImportResultResp;
import com.jiduauto.sps.sdk.pojo.po.CarBomItemPo;
import com.jiduauto.sps.sdk.pojo.po.CarBomPo;
import com.jiduauto.sps.sdk.pojo.req.CarBomItemUpdateReq;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.utils.BeanCopierUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 单车bom明细  工位导入
 */
@Service
@Slf4j
public class CarBomWorkStationHandler extends BaseImportHandler<CarBomImportResp, CarBomImportResultResp>{


    @Autowired
    private ICommonService commonService;

    @Resource
    private ICarBomItemService carBomItemService;

    @Resource
    private ICarBomService carBomService;


    @Resource
    private IBosService bosService;

    @Resource
    private IMaterialService materialService;

    private static final List<String> HEAD_VALUE_LIST = Arrays.asList("* 行标识","* 零件编码","工位");

    @Override
    public List<ImportDataInfo<CarBomImportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<CarBomImportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, CarBomImportResp.class, new ReadListener() {

                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        CarBomImportResp data = (CarBomImportResp) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (BizException e) {
            log.error("工位导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw e;
        } catch (Exception e) {
            log.error("工位导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "工位导入解析异常,请检查文件格式");
        }
    }


    /**
     * 校验文件
     *
     * @param list
     * @return
     * @throws BizException
     */
    @Override
    protected ImportReturnDataInfo<CarBomImportResultResp> process(List<ImportDataInfo<CarBomImportResp>> list) throws BizException {
        ImportReturnDataInfo<CarBomImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        boolean hasError = false;
        Map<String, String> map = new HashMap<>();
        // 从当前线程中获取bizType
        String bizType = BizTypeThreadHolder.getBizType();
        Long id = (Long) getThreadLocal().get();
        List<String> workStationList = commonService.dictItemList(bizType, DictEnum.WorkStation.getDictCode());

        List<CarBomItemPo> itemList = carBomItemService.list(Wrappers.lambdaQuery(CarBomItemPo.class)
                .eq(CarBomItemPo::getCarBomId,id));

        // 提前获取零件主数据的所有零件编号
        List<String> materialCodes = itemList.stream().map(CarBomItemPo::getMaterialCode).collect(Collectors.toList());
        Map<String, CarBomItemPo> carBomItemPoMap = itemList.stream().collect(Collectors.toMap( p -> p.getLineNo()+p.getMaterialCode(), Function.identity()));
        // 获取零件主数据
//        Map<String, MaterialPo> materialMap = materialService.mapMaterialPo(bizType,materialCodes);
        List<CarBomImportResultResp> resultRespList = new ArrayList<>();
        Map<String, String> dulicateMap = new HashMap<>();
        for(ImportDataInfo<CarBomImportResp> data: list){
            CarBomImportResp importResp = data.getData();
            CarBomImportResultResp resultResp = BeanCopierUtil.copy(importResp,CarBomImportResultResp.class);
            StringBuilder sb = new StringBuilder();

            if (StringUtils.isBlank(importResp.getSalePartNum())) {
                sb.append("零件编码不能为空;");

            }
            if (StringUtils.isBlank(importResp.getLineNo())) {
                sb.append("行标识不能为空;");

            }
            String key = importResp.getLineNo()+importResp.getSalePartNum();
            if(dulicateMap.containsKey(key)){
                sb.append("行标识和零件编码有重复行;");
            }else{
                dulicateMap.put(key, key);
            }
            if(StringUtils.isNotBlank(importResp.getSalePartNum()) &&
                    StringUtils.isNotBlank(importResp.getLineNo()) &&
             !carBomItemPoMap.containsKey(key)){
                sb.append("行标识或零件编码不存在;");
            }

            if (StringUtils.isBlank(importResp.getWorkStation())) {
                continue;
            } else {
                if (!workStationList.contains(importResp.getWorkStation())) {
                    sb.append("工位不存在;");
                }
            }
            if (StringUtils.isNotBlank(sb.toString())) {
                hasError = true;
            }
            resultResp.setErrorInfo(sb.toString());
            resultRespList.add(resultResp);
        }
        if (hasError) {
            returnDataInfo.setError(resultRespList);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultRespList);
            returnDataInfo.setImportFlag(true);
            returnDataInfo.setParam(carBomItemPoMap);
        }
        return returnDataInfo;
    }

    /**
     * 返回结果
     *
     * @param returnDataInfo
     * @throws BizException
     */
    @Override
    protected void afterProcess(ImportReturnDataInfo<CarBomImportResultResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
        }else{
            returnDataInfo.setImportFlag(true);
            boolean allHaveWorkStation = true;
            Map<String, CarBomItemPo> carBomItemPoMap = (Map<String, CarBomItemPo>) returnDataInfo.getParam();
            for(CarBomImportResultResp updateReq:returnDataInfo.getData()){
                String key = updateReq.getLineNo()+updateReq.getSalePartNum();
                CarBomItemPo inserted = carBomItemPoMap.get(key);
                CarBomItemPo carBomItemPo = new CarBomItemPo();
                carBomItemPo.setId(inserted.getId());
                inserted.setWorkStation(updateReq.getWorkStation());
                carBomItemPo.setWorkStation(updateReq.getWorkStation());
                carBomItemService.updateById(carBomItemPo);
            }

            for(CarBomItemPo carBomItemPo:carBomItemPoMap.values()){
                if(StringUtils.isBlank(carBomItemPo.getWorkStation())){
                    allHaveWorkStation = false;
                }
            }

            //状态变更
            if(allHaveWorkStation){
                Long id = (Long) getThreadLocal().get();
                //全部配置好了工位
                CarBomPo update = new CarBomPo();
                update.setId(id);
                update.setSyncStatus(CarBomStatusEnum.WORK_STATION_DONE.getCode());
                carBomService.updateById(update);
            }
        }
    }


    private String createErrExcel(List<CarBomImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "单车bom工位导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), CarBomImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("CarBomWorkStationHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();
        } catch (Exception e) {
            log.error("CarBomWorkStationHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("单车bom工位导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }
}
