package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.ImmutableMap;
import com.jiduauto.sps.sdk.enums.LingkeWhReissueOrderStatus;
import com.jiduauto.sps.sdk.pojo.po.LingkeWhReissueOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.LingkeWhReissueOrderPo;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.Enum.GenerateSerialEnum;
import com.jiduauto.sps.server.consts.AsnStatusEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.AsnBasicPo;
import com.jiduauto.sps.server.pojo.po.AsnDeliverInfoPo;
import com.jiduauto.sps.server.pojo.po.AsnReceiveInfoPo;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.LingkeWhReissueOrderImportExportResp;
import com.jiduauto.sps.server.pojo.vo.resp.LingkeWhReissueOrderImportResultResp;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.utils.BeanFillUtil;
import com.jiduauto.sps.server.utils.GenerateSerialNoUtil;
import com.jiduauto.sps.server.utils.NumberUtil;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

/**
 * 领克仓补订单数据导入
 */
@Service
@Slf4j
public class LingkeWhReissueOrderImportHandler extends BaseImportHandler<LingkeWhReissueOrderImportExportResp, LingkeWhReissueOrderImportResultResp> {

    @Autowired
    private IMaterialService materialService;

    @Autowired
    private ICommonService commonService;

    @Autowired
    private IBosService bosService;

    @Resource
    private IAsnBasicService asnBasicService;

    @Lazy
    @Resource
    private IAsnReceiveInfoService asnReceiveInfoService;

    @Resource
    private IAsnDeliverInfoService asnDeliverInfoService;

    @Resource
    private IPurchaseApplyOrderService purchaseApplyOrderService;

    @Resource
    private ILingkeWhReissueOrderService lingkeWhReissueOrderService;

    @Resource
    private ILingkeWhReissueOrderDetailService lingkeWhReissueOrderDetailService;

    @Resource
    private GenerateSerialNoUtil generateSerialNoUtil;

    /**
     * 货损货差类型与处理方式有对应关系
     * https://jiduauto.feishu.cn/wiki/P8ZmwX7iDinwLAkwYDKcPi33nTb
     * 0-货损，1-货差，2-货错，3-补单，4-退货
     * 0-退货，1--换货，2-补发，3-保留，4-补单，5-线下
     * 货差-补发；
     * 补单-补单；
     * 退货-线下；
     * 货损-换货；
     */
    public static Map<String, String> STYLE_DEAL_WAY_MAP = ImmutableMap.<String, String>builder()
            .put("1", "2")
            .put("3", "4")
            .put("4", "5")
            .put("0", "1")
            .build();

    private static ExecutorService executorService = Executors.newFixedThreadPool(8);
    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("*ASN", "*行号", "*售后件号", "工程件号", "零件名称", "到货日期", "送货单数量", "实收数量",
                    "*不良数量", "不良类型", "不良编号", "不良原因", "联系人姓名", "联系人电话", "*货损货差类型", "*处理方式");

    public List<ImportDataInfo<LingkeWhReissueOrderImportExportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<LingkeWhReissueOrderImportExportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, LingkeWhReissueOrderImportExportResp.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
//                    if (rowNumber > 100) {
//                        throw new BizException("单次导入最大数据量不能超过 1 行");
//                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    if (rowNum > 2) {
                        throw new BizException("单次导入最大数据量不能超过 1 行");
                    }
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        LingkeWhReissueOrderImportExportResp data = (LingkeWhReissueOrderImportExportResp) o;
                        //    if (data != null && !StringUtils.isEmpty(data.getSalePartNum())) {
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (BizException e) {
            log.error("领克仓补数据导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw e;
        } catch (Exception e) {
            log.error("领克仓补数据导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "领克仓补数据导入解析异常,请检查文件格式");
        }
    }

    @Override
    protected ImportReturnDataInfo<LingkeWhReissueOrderImportResultResp> process(List<ImportDataInfo<LingkeWhReissueOrderImportExportResp>> list) throws BizException {
        ImportReturnDataInfo<LingkeWhReissueOrderImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        boolean hasError = false;
        AsnBasicPo asnPo = null;
        List<LingkeWhReissueOrderImportResultResp> resultResps = new ArrayList<>();
        for (ImportDataInfo<LingkeWhReissueOrderImportExportResp> dataInfo : list) {
            LingkeWhReissueOrderImportExportResp resp = dataInfo.getData();

            LingkeWhReissueOrderImportResultResp resultResp = new LingkeWhReissueOrderImportResultResp();
            BeanUtils.copyProperties(resp, resultResp);
            StringBuilder sb = new StringBuilder();
            if (StringUtils.isEmpty(resp.getAsnNo())) {
                sb.append("asn 不可以为空;");
                hasError = true;
            }

            if (StringUtils.isNotBlank(resp.getAsnNo())) {
                asnPo = asnBasicService.getOne(Wrappers.<AsnBasicPo>lambdaQuery()
                        .eq(AsnBasicPo::getAsnCode, resp.getAsnNo())
                        .eq(AsnBasicPo::getBizType, BizTypeEnum.SP.getBizType())
                );
                if (asnPo == null) {
                    sb.append("asn 不存在;");
                    hasError = true;
                }
                if (asnPo != null && !purchaseApplyOrderService.isSpecialSupplier(BizTypeEnum.SP.getBizType(), asnPo.getSuppierSapCode())) {
                    sb.append("该 ASN 不属于领克供应商;");
                    hasError = true;
                }
                if (asnPo != null && (!AsnStatusEnum.PartReceived.getItemCode().equals(asnPo.getState()) &&
                        !AsnStatusEnum.AllReceived.getItemCode().equals(asnPo.getState()))
                ) {
                    sb.append("该 ASN 状态不允许创建仓补订单;");
                    hasError = true;
                }
            }

            if (StringUtils.isEmpty(resp.getLineNo())) {
                sb.append("行号不可以为空;");
                hasError = true;
            }
            if (StringUtils.isNotBlank(resp.getLineNo()) && asnPo != null) {
                AsnDeliverInfoPo asnDeliverInfoPo = asnDeliverInfoService.getOne(Wrappers.<AsnDeliverInfoPo>lambdaQuery()
                        .eq(AsnDeliverInfoPo::getAsnCode, resp.getAsnNo())
                        .eq(AsnDeliverInfoPo::getBizType, BizTypeEnum.SP.getBizType())
                        .eq(AsnDeliverInfoPo::getAsnLineNo, resp.getLineNo())
                );
                if (asnDeliverInfoPo == null) {
                    sb.append("该ASN不存在对应行号数据;");
                    hasError = true;
                }
            }
            if (StringUtils.isEmpty(resp.getSalePartNum())) {
                sb.append("零件编码不可以为空;");
                //文档中 写的零件编码  但是实际对应的是 售后件号 来做校验
                hasError = true;
            } else {
                // 去除字符串最前与最端段空格
                resultResp.setSalePartNum(StringUtils.deleteWhitespace(resp.getSalePartNum()));
                MaterialPo materialPo = materialService.getOne(Wrappers.<MaterialPo>lambdaQuery()
                        .eq(MaterialPo::getSalePartNum, resultResp.getSalePartNum())
                        .eq(MaterialPo::getBizType, BizTypeEnum.SP.getBizType())
                );
                if (materialPo == null) {
                    sb.append("该零件编码数据不存在;");
                    hasError = true;
                }
            }
            if (StringUtils.isEmpty(resp.getAsnNo())) {
                sb.append("行号不可以为空;");
                hasError = true;
            }
            if (StringUtils.isBlank(resp.getBadQty())) {
                sb.append("不良数量不可以为空;");
                hasError = true;
            }
            if (StringUtils.isNotBlank(resp.getBadType())) {
                if (commonService.getDictItemCode(DictEnum.WHROWrongType, resp.getBadType()) == null) {
                    sb.append("不良类型不存在;");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(resp.getBadQty()) && !NumberUtil.isNumeric(resp.getBadQty())) {
                sb.append("不良数量请填写数字;");
                hasError = true;
            }
            String WHROReissueType = commonService.getDictItemCode(DictEnum.WHROReissueType, resp.getStyle());
            String WHRODealWay = commonService.getDictItemCode(DictEnum.WHRODealWay, resp.getDealWay());

            if (StringUtils.isEmpty(resp.getStyle())) {
                sb.append("货损货差类型为空;");
                hasError = true;
            } else {
                if (WHROReissueType == null) {
                    sb.append("货损货差类型不正确;");
                    hasError = true;
                }
            }
            if (StringUtils.isBlank(resp.getDealWay())) {
                sb.append("处理方式不可以为空;");
                hasError = true;
            } else {
                if (WHRODealWay == null) {
                    sb.append("处理方式类型不正确;");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(WHROReissueType) && StringUtils.isNotBlank(WHRODealWay)) {
                if (STYLE_DEAL_WAY_MAP.containsKey(WHROReissueType) && !STYLE_DEAL_WAY_MAP.get(WHROReissueType).equals(WHRODealWay)) {
                    sb.append("货损货差与处理方式关系不正确;");
                    hasError = true;
                }
            }
            if (StrUtil.isNotBlank(resp.getBadNo()) && resp.getBadNo().length() >= 200) {
                sb.append("不良编号长度不能超过200;");
                hasError = true;
            }
            if (StrUtil.isNotBlank(resp.getBadReason()) && resp.getBadReason().length() >= 200) {
                sb.append("不良原因长度不能超过200;");
                hasError = true;
            }
            resultResp.setErrorInfo(sb.toString());
            resultResps.add(resultResp);
        }

        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    @Override
    protected void afterProcess(ImportReturnDataInfo<LingkeWhReissueOrderImportResultResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
        } else {

            LingkeWhReissueOrderImportResultResp resultResp = returnDataInfo.getData().get(0);
            // 校验通过 保存入库
            AsnDeliverInfoPo asnDeliverInfoPo = asnDeliverInfoService.getOne(Wrappers.<AsnDeliverInfoPo>lambdaQuery()
                    .eq(AsnDeliverInfoPo::getAsnCode, resultResp.getAsnNo())
                    .eq(AsnDeliverInfoPo::getBizType, BizTypeEnum.SP.getBizType())
                    .eq(AsnDeliverInfoPo::getAsnLineNo, resultResp.getLineNo())
            );

            List<AsnReceiveInfoPo> list = asnReceiveInfoService.list(Wrappers.<AsnReceiveInfoPo>lambdaQuery()
                    .eq(AsnReceiveInfoPo::getAsnCode, resultResp.getAsnNo())
                    .eq(AsnReceiveInfoPo::getBizType, BizTypeEnum.SP.getBizType())
                    .eq(AsnReceiveInfoPo::getAsnLineNo, resultResp.getLineNo())
            );
            int totalQty = list.stream().map(AsnReceiveInfoPo::getReceivedQty).reduce(0, Integer::sum);

            LingkeWhReissueOrderPo po = new LingkeWhReissueOrderPo();

            BeanFillUtil.fillNullStr(resultResp);
            BeanUtils.copyProperties(resultResp, po);
            po.setCreateUser(UserUtil.getUserName());
            po.setUpdateUser(UserUtil.getUserName());
            po.setBizType(BizTypeEnum.SP.getBizType());

            po.setOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.CY, BizTypeEnum.SP.getBizType()));
            po.setOrderStatus(LingkeWhReissueOrderStatus.WAIT_COMMIT.getItemCode());
            po.setAsnNo(resultResp.getAsnNo());
            po.setContractName(resultResp.getContacter());
            po.setContractMobile(resultResp.getTel());
            po.setReissueType(commonService.getDictItemCode(DictEnum.WHROReissueType, resultResp.getStyle()));
            po.setDealWay(commonService.getDictItemCode(DictEnum.WHRODealWay, resultResp.getDealWay()));
            lingkeWhReissueOrderService.save(po);
            List<LingkeWhReissueOrderDetailPo> detailList = new ArrayList<>();
            for (LingkeWhReissueOrderImportResultResp detail : returnDataInfo.getData()) {
                LingkeWhReissueOrderDetailPo detailPo = new LingkeWhReissueOrderDetailPo();
                detailPo.setLingkeWhReissueOrderNo(po.getOrderNo());
                detailPo.setBizType(po.getBizType());
                detailPo.setCreateUser(UserUtil.getUserName());
                detailPo.setUpdateUser(UserUtil.getUserName());


                MaterialPo materialPo = materialService.getOne(Wrappers.<MaterialPo>lambdaQuery()
                        .eq(MaterialPo::getSalePartNum, resultResp.getSalePartNum())
                        .eq(MaterialPo::getBizType, BizTypeEnum.SP.getBizType())
                );
                detailPo.setAsnLineNo(resultResp.getLineNo());
                detailPo.setMaterialCode(resultResp.getSalePartNum());
                detailPo.setMaterialNumber(materialPo.getNumber());
                detailPo.setPlanQuantity(new BigDecimal(asnDeliverInfoPo.getDeliveryQty()));
                detailPo.setRealQuantity(new BigDecimal(totalQty));
                detailPo.setWrongQuantity(new BigDecimal(resultResp.getBadQty()));
                if (StrUtil.isNotBlank(resultResp.getBadType())) {
                    detailPo.setWrongType(commonService.getDictItemCode(DictEnum.WHROWrongType, resultResp.getBadType()));
                }
                detailPo.setWrongNo(resultResp.getBadNo());
                detailPo.setWrongReason(resultResp.getBadReason());
                detailList.add(detailPo);
            }
            lingkeWhReissueOrderDetailService.saveBatch(detailList);
            returnDataInfo.setParam(po.getOrderNo());
            returnDataInfo.setImportFlag(true);
        }
    }

    private String createErrExcel(List<LingkeWhReissueOrderImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "数据导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), LingkeWhReissueOrderImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("LingkeWhReissueOrderImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("LingkeWhReissueOrderImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("领克仓补数据导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }
}
