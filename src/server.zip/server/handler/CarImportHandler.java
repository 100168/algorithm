package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.CarMapper;
import com.jiduauto.sps.server.mapper.DictItemMapper;
import com.jiduauto.sps.server.pojo.fileImport.CarImportDto;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.CarPo;
import com.jiduauto.sps.server.pojo.po.DictItemPo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.material.CarImportResultResp;
import com.jiduauto.sps.server.pojo.vo.resp.material.WarehousePositionImportResultResp;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.utils.StringUtils;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @ClassName CarImportHandler
 * @Description  车辆信息导入
 * @AuThor O_chaopeng.huang
 * @Date 2023/2/24 17:47
 * @Version 5.0
 */
@Component
@Slf4j
public class CarImportHandler extends BaseImportHandler<CarImportDto, CarImportResultResp> {

    private static final Integer MAX_LIMIT = 500;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("车辆号", "所属项目代码", "所属阶段代码", "描述");

    @Autowired
    private CarMapper carMapper;

    @Autowired
    private DictItemMapper dictItemMapper;

    @Autowired
    private IBosService bosService;

    public List<ImportDataInfo<CarImportDto>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<CarImportDto>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, CarImportDto.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板表头数据不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        CarImportDto data = (CarImportDto) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (Exception e) {
            log.error("库位主数据计划导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(e.getMessage());
        }
    }

    @Override
    protected ImportReturnDataInfo<CarImportResultResp> process(List<ImportDataInfo<CarImportDto>> list) throws BizException {
        String bizType = BizTypeThreadHolder.getBizType();
        ImportReturnDataInfo<CarImportResultResp> importResult = new ImportReturnDataInfo<>();
        List<String> saleCodes = new ArrayList<>();
        List<String> saleDictItem = new ArrayList<>();
        List<String> saleDescri = new ArrayList<>();
        HashMap<String, String> infoMap = new HashMap<>();
        boolean hasError = false;
        List<CarImportResultResp> resultResps = new ArrayList<>();
        for (ImportDataInfo<CarImportDto> data : list) {
            StringBuilder errors = new StringBuilder();
            CarImportDto planResp = data.getData();
            CarImportResultResp resultResp = new CarImportResultResp();
            BeanUtils.copyProperties(planResp, resultResp);
            String code = planResp.getCode();
            if (StringUtils.isBlank(code)) {
                errors.append("车辆编码为空;");
                hasError = true;
            } else {
                saleCodes.add(code);
                resultResp.setCode(code);
            }
            if (StringUtils.isNotBlank(planResp.getDescription())) {
                saleDescri.add(planResp.getDescription());
            }
            if (StringUtils.isNotBlank(planResp.getProjectTypeCode())) {
                saleDictItem.add(planResp.getProjectTypeCode());
            }
            if (StringUtils.isNotBlank(planResp.getStageSpecCode())) {
                saleDictItem.add(planResp.getStageSpecCode());
            }
            String uniCode = planResp.getCode() + bizType + planResp.getCode();
            if (infoMap.containsKey(uniCode)) {
                errors.append("同一业务车辆编码重复了,请检查文件;");
                hasError = true;
            } else {
                infoMap.put(uniCode, uniCode);
            }
            resultResp.setErrorInfo(errors.toString());
            resultResps.add(resultResp);
        }
        if (!CollectionUtils.isEmpty(saleDescri)){
            for (CarImportResultResp resultResp : resultResps) {
                for (String saleName : saleDescri) {
                    if (saleName.length()>100) {
                        if (StringUtils.isEmpty(resultResp.getErrorInfo())) {
                            resultResp.setErrorInfo("描述长度限制100;");
                        } else {
                            resultResp.setErrorInfo(resultResp.getErrorInfo() + "描述长度限制100;");
                        }
                        hasError = true;
                    }
                }
            }
        }
        if (!CollectionUtils.isEmpty(saleCodes)) {
            for (CarImportResultResp resultResp : resultResps) {
                for (String saleCode : saleCodes) {
                    if (saleCode.length()>50) {
                        if (StringUtils.isEmpty(resultResp.getErrorInfo())) {
                            resultResp.setErrorInfo("车辆编号长度限制50;");
                        } else {
                            resultResp.setErrorInfo(resultResp.getErrorInfo() + "车辆编号长度限制50;");
                        }
                        hasError = true;
                    }
                }
            }
            List<String> duplicate = carMapper.getByWPCodes(bizType, saleCodes);
            for (CarImportResultResp resultResp : resultResps) {
                if (duplicate.contains(resultResp.getCode())) {
                    if (StringUtils.isEmpty(resultResp.getErrorInfo())) {
                        resultResp.setErrorInfo("车辆编号已存在;");
                    } else {
                        resultResp.setErrorInfo(resultResp.getErrorInfo() + "车辆编号已存在;");
                    }
                    hasError = true;
                }
            }
            List<String> collect = saleDictItem.stream().distinct().collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(collect)) {

                List<String> byWCodes = dictItemMapper.getByWCodes(collect);
                for (CarImportResultResp resultResp : resultResps) {

                    if (!byWCodes.contains(resultResp.getProjectTypeCode())) {
                        if (StringUtils.isEmpty(resultResp.getErrorInfo())) {
                            resultResp.setErrorInfo("项目类型编号不存在;");
                        } else {
                            resultResp.setErrorInfo(resultResp.getErrorInfo() + "项目类型编号不存在;");
                        }
                        hasError = true;
                    }
                }
                for (CarImportResultResp resultResp : resultResps) {
                    if (!byWCodes.contains(resultResp.getStageSpecCode())) {
                        if (StringUtils.isEmpty(resultResp.getErrorInfo())) {
                            resultResp.setErrorInfo("项目阶段类型编号不存在;");
                        } else {
                            resultResp.setErrorInfo(resultResp.getErrorInfo() + "项目阶段类型不存在;");
                        }
                        hasError = true;
                    }
                }
            }

        }
        if (hasError) {
            importResult.setError(resultResps);
            importResult.setImportFlag(false);
        } else {
            importResult.setData(resultResps);
            importResult.setImportFlag(true);
        }
        return importResult;
    }

    @Override
    protected void afterProcess(ImportReturnDataInfo<CarImportResultResp> returnDataInfo) throws BizException {
        String bizType = BizTypeThreadHolder.getBizType();
        String userName = UserUtil.getUserName();
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            //校验失败  返回失败文件地址
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        }

        LambdaQueryWrapper<DictItemPo> wrapper = Wrappers.lambdaQuery();


        List<DictItemPo> dictItemPos = dictItemMapper.selectList(wrapper);

        List<CarPo> pos = returnDataInfo.getData().stream().map((item) -> {
            CarPo po = new CarPo();
            BeanUtils.copyProperties(item, po, "id");
            for (DictItemPo dictItemPo : dictItemPos) {
                if (dictItemPo.getItemCode().equals(item.getProjectTypeCode())) {

                    po.setProjectTypeName(dictItemPo.getItemName());
                } else if (dictItemPo.getItemCode().equals(item.getStageSpecCode())) {

                    po.setStageSpecName(dictItemPo.getItemName());

                }
            }
            po.setCreateUser(userName);
            po.setUpdateUser(userName);
            po.setBizType(bizType);
            return po;
        }).collect(Collectors.toList());

        int i = carMapper.batchInsert(pos);

        returnDataInfo.setImportFlag(true);


    }

    private String createErrExcel(List<CarImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "库位主数据计划导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), CarImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("CarImportResultResp-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "计划导入失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("carImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("车辆数据计划导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }


}
