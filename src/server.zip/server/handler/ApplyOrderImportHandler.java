package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.server.Enum.ApplyOrderTypeEnum;
import com.jiduauto.sps.server.Enum.ApplyTypeEnum;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.Enum.SalePriceTypeEnum;
import com.jiduauto.sps.server.caches.DictItemCache;
import com.jiduauto.sps.server.client.resp.DistrictResp;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.consts.StockOrderStatus;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.ApplyOrderItemMapper;
import com.jiduauto.sps.server.mapper.CompanyMapper;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.ApplyOrderExportResp;
import com.jiduauto.sps.server.pojo.vo.resp.ApplyOrderImportResultResp;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.utils.BeanCopierUtil;
import com.jiduauto.sps.server.utils.DateUtils;
import com.jiduauto.sps.server.utils.RedisUtil;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 领料订单导入
 *
 * @author dong.li01
 * @since 5/16/23 10:29 AM
 */
@Service
@Slf4j
public class ApplyOrderImportHandler extends BaseImportHandler<ApplyOrderExportResp, ApplyOrderImportResultResp> {

    @Resource
    private IBosService bosService;

    @Resource
    private IMaterialService materialService;

    @Resource
    private DictItemCache dictItemCache;

    @Resource
    private IWarehouseService warehouseService;

    @Resource
    private IApplyOrderService applyOrderService;
    @Autowired
    private ISalePriceService salePriceService;

    @Resource
    private ApplyOrderItemMapper applyOrderItemMapper;
    @Autowired
    private CompanyMapper companyMapper;
    @Autowired
    private ICommonService commonService;
    @Autowired
    private IApplyOrderItemService applyOrderItemService;
    private static final List<String> HEAD_VALUE_LIST = Arrays.asList("* 订单类型", "* 领用日期", "* 领用人", "领用人电话", "领用公司", "被领用公司","领用部门","领用目的", "领用用途", "外部系统单号", "备注", "* 取货方式", "* 收件人", "* 收件人电话", "* 省", "* 市", "区", "* 详细地址", "* 零件编码", "零件状态", "样件状态", "零件种类", "* 领用数量", "项目", "阶段", "成本中心", "WBS", "SAP卡片号", "* 仓库代码", "是否计划内领料", "备注");

    private static final Integer MAX_LIMIT = 1000;

    @Override
    public List<ImportDataInfo<ApplyOrderExportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<ApplyOrderExportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, ApplyOrderExportResp.class, new ReadListener() {

                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");
                    }
                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        ApplyOrderExportResp data = (ApplyOrderExportResp) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (BizException e) {
            log.error("领料订单导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw e;
        } catch (Exception e) {
            log.error("领料订单导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "领料订单导入解析异常,请检查文件格式");
        }
    }

    @Override
    protected ImportReturnDataInfo<ApplyOrderImportResultResp> process(List<ImportDataInfo<ApplyOrderExportResp>> list) throws BizException {
        ImportReturnDataInfo<ApplyOrderImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        boolean hasError = false;
        Map<String, String> map = new HashMap<>();
        // 从当前线程中获取bizType
        String bizType = BizTypeThreadHolder.getBizType();
        BizTypeEnum byBizType = BizTypeEnum.getByBizType(bizType);
        List<ApplyOrderImportResultResp> resultResps = new ArrayList<>();
        // 提前获取零件主数据的所有零件编号
        List<String> mCodes = list.stream().map(e -> {
            return e.getData().getMaterialCode();
        }).collect(Collectors.toList());
        Map<String, MaterialPo> materalCodes = materialService.mapMaterialPo(bizType,mCodes);
        // 提前获取仓库主数据的所有仓库代码
        Set<String> warehouseCodes = warehouseService.listObjs(
                Wrappers.<WarehousePo>lambdaQuery().select(WarehousePo::getCode).eq(WarehousePo::getBizType, bizType),
                Object::toString).stream().collect(Collectors.toSet());
//        Map<String, SalePricePo> salePriceMap = new HashMap<>();
        //公司主数据
        Map<String, String> cM = companyMapper.selectList(Wrappers.<CompanyPo>lambdaQuery().select(CompanyPo::getCode, CompanyPo::getBizType).eq(CompanyPo::getBizType, bizType)).stream().collect(Collectors.toMap(CompanyPo::getCode, CompanyPo::getCode, (p, n) -> n));
//        if (BizTypeEnum.SP.getBizType().equals(bizType)) {
//            List<String> salePriceTypes = new ArrayList<>();
//            salePriceTypes.add(SalePriceTypeEnum.B.getCode());
//            salePriceMap = salePriceService.getSalePriceMap(bizType, mCodes,
//                    salePriceTypes);
//        }
        // 从数据字典缓存中取出name-code键值对
        Map<String, String> mSS = dictItemCache.getNameAndCodeMap(DictEnum.MaterialStockStatus.getDictCode());
        // 从数据字典缓存中取出name-code键值对
        Map<String, String> mS = dictItemCache.getNameAndCodeMap(DictEnum.MaterialSort.getDictCode());
        Map<String, String> pM = dictItemCache.getCodeAndNameMap(DictEnum.Project.getDictCode());
        Map<String, String> sM = dictItemCache.getCodeAndNameMap(DictEnum.Stage.getDictCode());
        Map<String, String> aSM = dictItemCache.getNameAndCodeMap(DictEnum.ApplySake.getDictCode());
        Map<String, String> aOSM = dictItemCache.getCodeAndNameMap(DictEnum.ApplyOrderType.getDictCode());
        Map<String, DistrictResp> provinceMap = commonService.getProvinceMap();
        Map<String, DistrictResp> cityMap = commonService.getCityMap();
        Map<String, DistrictResp> districtMap = commonService.getDistrictMap();
        Map<String, String> map4 = dictItemCache.getCodeAndNameMap(DictEnum.ApplyOrderTransfer.getDictCode());
        Map<String, String> purposeMap = dictItemCache.getNameAndCodeMap(DictEnum.ApplyPurpose.getDictCode());
        int count = 0;
        Integer applyNo = 0;
        String orderTyep = "";
        for (ImportDataInfo<ApplyOrderExportResp> dataInfo : list) {
            count++;
            ApplyOrderExportResp resp = dataInfo.getData();
            ApplyOrderImportResultResp resultResp = new ApplyOrderImportResultResp();
            BeanUtils.copyProperties(resp, resultResp);
            StringBuilder sb = new StringBuilder();
            StringBuilder curKey = new StringBuilder();
            String curValue = null;
            String s = getString(resp);
            s = s.replaceAll("null", "");
            //校验第一条数据表头信息是否为空
            if (count == 1 && StringUtils.isBlank(s)) {
                sb.append("领料单表头信息不能为空");

            }
            if (StringUtils.isNotBlank(s)) {
                if (StringUtils.isBlank(resp.getOrderType())) {
                    sb.append("订单类型不能为空");

                } else {
                    if (!aOSM.containsKey(resp.getOrderType())) {
                        sb.append("订单类型不存在");

                    } else {
                        orderTyep = resp.getOrderType();
                    }
                }
                if (StringUtils.isNotBlank(resp.getApplyPurpose())) {
                    if (!purposeMap.containsKey(resp.getApplyPurpose())) {
                        sb.append("领用目的不存在");

                    }
                }
                if(bizType.equals(BizTypeEnum.JADT.getBizType())  && StringUtils.isBlank(resp.getRemark())){
                    sb.append("备注不可以为空;");
                }
                if (StringUtils.isNotBlank(resp.getApplyCompany())) {
                    if (!cM.containsKey(resp.getApplyCompany())) {
                        sb.append("领用公司不存在");

                    }
                }
                if (StringUtils.isNotBlank(resp.getNeedCompany())) {
                    if (!cM.containsKey(resp.getNeedCompany())) {
                        sb.append("被领用公司不存在");

                    }
                }
                if (StringUtils.isBlank(resp.getApplyDate())) {
                    sb.append("领用日期不能为空");

                } else {
                    if (!DateUtils.checkDateFormat(resp.getApplyDate())) {
                        sb.append("领用日期不为yyyyMMdd");

                    }
                }
                if (StringUtils.isBlank(resp.getApplyer())) {
                    sb.append("领用人不能为空");

                } else {
                    if (resp.getApplyer().length() > 50) {
                        sb.append("领用人限制长度50");

                    }
                }
                if (StringUtils.isNotBlank(resp.getApplyContact()) && resp.getApplyContact().length() > 50) {
                    sb.append("领用人电话限制长度50");

                }if (StringUtils.isNotBlank(resp.getApplyDepartment()) && resp.getApplyDepartment().length() > 50) {
                    sb.append("领用部门限制长度50");

                }
                if (StringUtils.isNotBlank(resp.getExternalOrderNo()) && resp.getExternalOrderNo().length() > 50) {
                    sb.append("外部系统单号限制长度50");

                }
                if (StringUtils.isNotBlank(resp.getRemark()) && resp.getRemark().length() > 50) {
                    sb.append("备注限制长度50");

                }
                if (StringUtils.isNotBlank(resp.getApplySake())) {
                    if (!aSM.containsKey(resp.getApplySake())) {
                        sb.append("领用用途不存在");

                    }
                }
                if (StringUtils.isBlank(resp.getApplyType())) {
                    sb.append("取货方式不能为空");

                } else {
                    if (!map4.containsKey(resp.getApplyType())) {
                        sb.append("该取货方式不存在");

                    } else {
                        if (resp.getApplyType().equals(ApplyTypeEnum.EXP.getCode())) {
                            if (StringUtils.isBlank(resp.getReceiver())) {
                                sb.append("收件人不能为空");

                            }
                            if (StringUtils.isBlank(resp.getReceiverContact())) {
                                sb.append("收件人电话不能为空");

                            }
                            if (StringUtils.isBlank(resp.getReceiverProvince())) {
                                sb.append("省不能为空");

                            } else {
                                if (!provinceMap.containsKey(resp.getReceiverProvince())) {
                                    sb.append("所填省不存在");

                                }
                            }
                            if (StringUtils.isBlank(resp.getReceiverCity())) {
                                sb.append("市不能为空");

                            } else {
                                if (!cityMap.containsKey(resp.getReceiverProvince() + resp.getReceiverCity())) {
                                    sb.append("所填市不存在");

                                }
                            }
                            if (StringUtils.isNotBlank(resp.getReceiverDistrict()) &&
                                    !districtMap.containsKey(resp.getReceiverProvince() + resp.getReceiverCity()
                                            + resp.getReceiverDistrict())) {
                                    sb.append("所填区不存在");

                            }
                            if (StringUtils.isBlank(resp.getReceiverAddress())) {
                                sb.append("详情地址不能为空");

                            } else {
                                if (resp.getReceiverAddress().length() > 100) {
                                    sb.append("详情地址长度限制100");

                                }
                            }
                        }
                    }
                }
            }
            // 零件编码必填
            if (StringUtils.isEmpty(resp.getMaterialCode())) {
                sb.append("零件编码不可以为空;");

            } else {
                if (!materalCodes.containsKey(resp.getMaterialCode())) {
                    sb.append("该零件编码系统不存在;");

                }
//                if (BizTypeEnum.SP.getBizType().equals(bizType)) {
//                    if (!salePriceMap.containsKey(resp.getMaterialCode())) {
//                        sb.append("该零件无早于当前日期的授权钣喷采购价");
//
//                    }
//                }
            }
            // 零件状态非必填
            if (StringUtils.isNotEmpty(resp.getMaterialStatus())) {

                if (!mSS.containsKey(resp.getMaterialStatus())) {
                    sb.append("零件状态系统不存在;");

                }
            }
            // 样件状态非必填
            if (StringUtils.isNotEmpty(resp.getSamplePartStatus())) {
                if (resp.getSamplePartStatus().length() > 50) {
                    sb.append("样件状态字段超过长度限制;");

                }
            }
            // 零件种类非必填
            if (StringUtils.isNotEmpty(resp.getMaterialSort())) {

                if (!mS.containsKey(resp.getMaterialSort())) {
                    sb.append("零件种类系统不存在;");

                }
            }
            // 领用数量必填
            if (StringUtils.isEmpty(resp.getApplySum())) {
                sb.append("领用数量不可以为空;");

            } else {
                try {
                    BigDecimal bigDecimal = new BigDecimal(resp.getApplySum());
                    // 判断是否是合法数字
                    if (bigDecimal.compareTo(new BigDecimal(0)) != 1) {
                        sb.append("领用数量数值填写有误;");

                    }
                } catch (Exception e) {
                    sb.append("领用数量数值填写有误;");

                }
            }
            // 项目非必填
            if (StringUtils.isNotEmpty(resp.getProjectCode())) {

                if (!pM.containsKey(resp.getProjectCode())) {
                    sb.append("项目系统不存在;");

                }
            }
            // 阶段非必填
            if (StringUtils.isNotEmpty(resp.getStageCode())) {
                if (!sM.containsKey(resp.getStageCode())) {
                    sb.append("阶段系统不存在;");

                }
            }
            // 成本中心非必填
            if (StringUtils.isNotEmpty(resp.getCostCenter())) {
                if (resp.getCostCenter().length() > 50) {
                    sb.append("成本中心字段超过长度限制;");

                }
            }
            if (bizType.equals(BizTypeEnum.ES.getBizType())) {
                if (StringUtils.isEmpty(resp.getCostCenter())) {
                    sb.append("成本中心不能为空;");
                }
            }
            // WBS非必填
            if (StringUtils.isNotEmpty(resp.getWbs())) {
                if (resp.getWbs().length() > 50) {
                    sb.append("WBS字段超过长度限制;");

                }
            }
                switch (byBizType) {
                    case SP:
                        MaterialPo materialPo = materalCodes.getOrDefault(resp.getMaterialCode(),new MaterialPo());
                        if (StringUtils.isNotBlank(materialPo.getMinPackage()) && new BigDecimal(
                                materialPo.getMinPackage()).compareTo(new BigDecimal(0)) != 0) {
                            var divide = new BigDecimal(resultResp.getApplySum()).remainder(new BigDecimal(
                                    materialPo.getMinPackage()));
                            if (divide.compareTo(new BigDecimal(0)) != 0) {
                                sb.append("请填写零件最小包装数的整数倍(").append(resp.getMaterialCode()).append(");");
                            }
                        }
                    case JC:
                        if (StringUtils.isBlank(resp.getCostCenter())
                                || StringUtils.isBlank(
                                resp.getWarehouseCode())) {
                            sb.append("该零件(").append(resp.getMaterialCode())
                                    .append(")该业务下成本中心与仓库不能为空;");
                        }
                        break;
                    case VP:
                        if (StringUtils.isBlank(resp.getProjectCode())) {
                            sb.append("该零件(").append(resp.getMaterialCode()).append(")项目类型不能为空;");
                        }
                        if (StringUtils.isBlank(resp.getStageCode())) {
                            sb.append("该零件(").append(resp.getMaterialCode()).append(")项目阶段不能为空;");
                        }
                        break;
                }
                // 仓库代码非必填
            if (StringUtils.isNotBlank(resp.getWarehouseCode())) {
                if (!warehouseCodes.contains(resp.getWarehouseCode())) {
                    sb.append("仓库代码系统不存在;");

                }
            }else{
                sb.append("仓库代码必填;");

            }
            // 是否计划内领料非必填
            if (StringUtils.isNotEmpty(resp.getIsApply())) {
                if (!resp.getIsApply().equals("是") && !resp.getIsApply().equals("否")) {
                    sb.append("是否计划内领料填写有误;");

                }
            }
            // 备注非必填
            if (StringUtils.isNotEmpty(resp.getRemark())) {
                if (resp.getRemark().length() > 50) {
                    sb.append("备注字段超过长度限制;");

                }
            }
            if (StringUtils.isNotBlank(s)) {
                applyNo++;
            }
            resultResp.setApplyOrderNo(String.valueOf(applyNo));
            //不是内部领料时校验明细的重复性
            if (!orderTyep.equals(ApplyOrderTypeEnum.AOT21.getDesc())) {
                curKey.append(resp.getMaterialCode());
                curKey.append(resp.getMaterialStatus());
                curKey.append(resp.getSamplePartStatus());
                curKey.append(resp.getMaterialSort());
                curKey.append(resp.getProjectCode());
                curKey.append(resp.getStageCode());
                curKey.append(resp.getCostCenter());
                curKey.append(resp.getWbs());
                curKey.append(resp.getWarehouseCode());
                curKey.append(resp.getIsApply());
            } else {
                curKey.append(resp.getMaterialCode());
                curKey.append(resp.getWarehouseCode());
            }
            curKey.append(applyNo);
            if (map.containsKey(curKey.toString())) {
                sb.append("(" + resp.getMaterialCode() + ")" + "该领料单下该零件有除领用数量与备注字段外的其他字段一样的重复领料明细数据");
            } else {
                map.put(curKey.toString(), curValue);
            }
            if (StringUtils.isNotBlank(sb.toString())) {
                hasError = true;
            }
            resultResp.setErrorInfo(sb.toString());
            resultResps.add(resultResp);
        }
        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    private static String getString(ApplyOrderExportResp resp) {
        return resp.getOrderType() + resp.getApplyDate() + resp.getApplyer() + resp.getApplyContact()
                + resp.getApplyCompany() + resp.getNeedCompany() + resp.getApplySake()
                + resp.getExternalOrderNo() + resp.getRemark() + resp.getApplyType() + resp.getReceiver()
                + resp.getReceiverContact() + resp.getReceiverProvince() + resp.getReceiverCity()
                + resp.getReceiverDistrict() + resp.getReceiverAddress();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void afterProcess(ImportReturnDataInfo<ApplyOrderImportResultResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        } else {
            // 校验通过 开始保存入库
            String bizType = returnDataInfo.getBizType();
            // 从数据字典缓存中取出零件状态name-code键值对
            Map<String, String> materialStockStatusNameAndCodeMap = dictItemCache.getNameAndCodeMap(DictEnum.MaterialStockStatus.getDictCode());
            // 从数据字典缓存中取出零件状态name-code键值对
            Map<String, String> materialSortNameAndCodeMap = dictItemCache.getNameAndCodeMap(DictEnum.MaterialSort.getDictCode());
            // 从数据字典缓存中取出name-code键值对
            Map<String, String> mSS = dictItemCache.getNameAndCodeMap(DictEnum.MaterialStockStatus.getDictCode());
            // 从数据字典缓存中取出name-code键值对
            Map<String, String> aSM = dictItemCache.getNameAndCodeMap(DictEnum.ApplySake.getDictCode());
            Map<String, DistrictResp> provinceMap = commonService.getProvinceMap();
            Map<String, DistrictResp> cityMap = commonService.getCityMap();
            Map<String, DistrictResp> districtMap = commonService.getDistrictMap();
            Map<String, String> purposeMap = dictItemCache.getNameAndCodeMap(DictEnum.ApplyPurpose.getDictCode());
            List<ApplyOrderItemPo> poList = new ArrayList<>();
            List<ApplyOrderPo> list = new ArrayList<>();
            Map<String, BigDecimal> sumMap = new HashMap<>();
            String user = UserUtil.getUserName();
            String orderNumber = null;
            String sake  = null;
            Integer nextLineNo = 0;
            for (ApplyOrderImportResultResp resultResp : returnDataInfo.getData()) {
                String string = getString(resultResp);
                string = string.replaceAll("null", "");
                resultResp.setApplySake(aSM.get(resultResp.getApplySake()));
                String cKey = resultResp.getReceiverProvince() + resultResp.getReceiverCity();
                String dKey = resultResp.getReceiverProvince() + resultResp.getReceiverCity()
                        + resultResp.getReceiverDistrict();
                resultResp.setReceiverProvince(provinceMap.getOrDefault(resultResp.getReceiverProvince(),new DistrictResp()).getCode());
                resultResp.setReceiverCity(
                        cityMap.getOrDefault(cKey,
                                new DistrictResp()).getCode());
                resultResp.setReceiverDistrict(districtMap.getOrDefault(
                        dKey, new DistrictResp()).getCode());
                resultResp.setMaterialStatus(mSS.get(resultResp.getMaterialStatus()));
                if (StringUtils.isBlank(string)) {
                    nextLineNo = nextLineNo + BaseConstants.LineNo.STEP;
                    ApplyOrderItemPo applyOrderItemPo = new ApplyOrderItemPo();
                    setValue(bizType, materialStockStatusNameAndCodeMap, materialSortNameAndCodeMap, orderNumber, resultResp, applyOrderItemPo);
                    applyOrderItemPo.setCreateUser(user);
                    applyOrderItemPo.setRemark(resultResp.getRemarkItem());
                    applyOrderItemPo.setApplySake(sake);
                    applyOrderItemPo.setLineNo(nextLineNo);
                    poList.add(applyOrderItemPo);
                    BigDecimal sum = sumMap.get(orderNumber).add(new BigDecimal(resultResp.getApplySum()));
                    sumMap.put(orderNumber, sum);
                } else {
                    // 创建领料单号
                    String no = initOrderNumber(bizType);
                    nextLineNo = applyOrderItemService.getNextLineNo(no, bizType);
                    // 领用用途
                    sake = resultResp.getApplySake();
                    ApplyOrderPo applyOrderPo = setOrderValue(bizType, no, resultResp);
                    applyOrderPo.setCreateUser(user);
                    applyOrderPo.setApplyPurpose(purposeMap.get(resultResp.getApplyPurpose()));
                    if (StringUtils.isBlank(applyOrderPo.getOutStockReq())){
                        applyOrderPo.setOutStockReq("");
                    }
                    applyOrderPo.setApplyDate(
                        DateUtils.parse(resultResp.getApplyDate(), DateUtils.SHORT_DATE_FORMAT).toLocalDate());
                    list.add(applyOrderPo);
                    ApplyOrderItemPo applyOrderItemPo = new ApplyOrderItemPo();
                    setValue(bizType, materialStockStatusNameAndCodeMap, materialSortNameAndCodeMap, no, resultResp, applyOrderItemPo);
                    applyOrderItemPo.setCreateUser(user);
                    applyOrderItemPo.setApplySake(sake);
                    applyOrderItemPo.setRemark(resultResp.getRemarkItem());
                    applyOrderItemPo.setLineNo(nextLineNo);
                    sumMap.put(no, new BigDecimal(resultResp.getApplySum()));
                    poList.add(applyOrderItemPo);
                    orderNumber = no;
                }
            }
            //获取总数量值
            for (ApplyOrderPo po : list) {
                po.setApplySum(sumMap.get(po.getApplyOrderNo()));
            }
            applyOrderService.saveBatch(list);
            applyOrderItemMapper.batchInsert(poList);
        }
        returnDataInfo.setImportFlag(true);
    }

    /**
     * 设值领料单表头值
     *
     * @author O_chaopeng.huang
     */
    private ApplyOrderPo setOrderValue(String bizType, String applyOrderNo, ApplyOrderImportResultResp req) {
        ApplyOrderPo applyOrderPo = BeanCopierUtil.copy(req, ApplyOrderPo.class);

        // 设置领料订单号
        applyOrderPo.setApplyOrderNo(applyOrderNo);
        // 设置状态
        applyOrderPo.setStatus(StockOrderStatus.putIn.getCode());
        // 设置业务类型
        applyOrderPo.setBizType(bizType);
        // 领用人电话
        if (StringUtils.isEmpty(applyOrderPo.getApplyContact())) {
            applyOrderPo.setApplyContact("");
        }
        // 领用公司
        if (StringUtils.isEmpty(applyOrderPo.getApplyCompany())) {
            applyOrderPo.setApplyCompany("");
        }
        // 外部系统单号
        if (StringUtils.isEmpty(applyOrderPo.getExternalOrderNo())) {
            applyOrderPo.setExternalOrderNo("");
        }
        // 备注
        if (StringUtils.isEmpty(applyOrderPo.getRemark())) {
            applyOrderPo.setRemark("");
        }
        // 如果取货方式是自提，其他几个搞成null
        if (applyOrderPo.getApplyType().equals(ApplyTypeEnum.SPK.getCode())) {
            // 收件人
            applyOrderPo.setReceiver("");
            // 收件人联系方式
            applyOrderPo.setReceiverContact("");
            // 省
            applyOrderPo.setReceiverProvince("");
            // 市
            applyOrderPo.setReceiverCity("");
            // 区
            applyOrderPo.setReceiverDistrict("");
            // 详情地址
            applyOrderPo.setReceiverAddress("");
        }
        // 被领用公司
        if (StringUtils.isEmpty(applyOrderPo.getNeedCompany())) {
            applyOrderPo.setNeedCompany("");
        }
        // 领用用途
        if (StringUtils.isEmpty(applyOrderPo.getApplySake())) {
            applyOrderPo.setApplySake("");
        }
        return applyOrderPo;
    }

    /**
     * 设值领料单明细值
     *
     * @author O_chaopeng.huang
     */
    private void setValue(String bizType, Map<String, String> materialStockStatusNameAndCodeMap, Map<String, String> materialSortNameAndCodeMap, String applyOrderNo, ApplyOrderImportResultResp resultResp, ApplyOrderItemPo applyOrderItemPo) {
        // 领料订单编号
        applyOrderItemPo.setApplyOrderNo(applyOrderNo);
        // 零件编码
        applyOrderItemPo.setMaterialCode(resultResp.getMaterialCode());
        // 零件状态，不填写默认是良好
        if (StringUtils.isNotBlank(resultResp.getMaterialStatus())) {
            applyOrderItemPo.setMaterialStatus(Integer.parseInt(materialStockStatusNameAndCodeMap.getOrDefault(resultResp.getMaterialStatus(), "1")));
        } else {
            applyOrderItemPo.setMaterialStatus(1);
        }
        // 样例状态
        applyOrderItemPo.setSamplePartStatus(resultResp.getSamplePartStatus());
        // 零件种类,不填写不给默认值
        if (StringUtils.isNotEmpty(resultResp.getMaterialSort())) {
            applyOrderItemPo.setMaterialSort(materialSortNameAndCodeMap.get(resultResp.getMaterialSort()));
        }
        // 领用数量
        applyOrderItemPo.setApplySum(new BigDecimal(resultResp.getApplySum()));
        // 项目
        applyOrderItemPo.setProjectCode(resultResp.getProjectCode());
        // 阶段
        applyOrderItemPo.setStageCode(resultResp.getStageCode());
        // 成本中心
        applyOrderItemPo.setCostCenter(resultResp.getCostCenter());
        // WBS
        applyOrderItemPo.setWbs(resultResp.getWbs());
        // sap卡片号
        applyOrderItemPo.setSapCode(resultResp.getSapCode());
        // 仓库代码
        applyOrderItemPo.setWarehouseCode(resultResp.getWarehouseCode());
        // 是否计划内领料,不填写默认是
        if (StringUtils.isEmpty(resultResp.getIsApply())) {
            applyOrderItemPo.setIsApply(true);
        } else {
            applyOrderItemPo.setIsApply(resultResp.getIsApply().equals("是"));
        }
        // 备注
        applyOrderItemPo.setRemark(resultResp.getRemark());
        // 业务类型
        applyOrderItemPo.setBizType(bizType);
    }

    private String createErrExcel(List<ApplyOrderImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "领料订单导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), ApplyOrderImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("ApplyOrderImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();
        } catch (Exception e) {
            log.error("ApplyOrderImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("领料订单导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }

    // todo 下面都是原文件中写好的，不用复制过去
    @Resource
    private RedisUtil redisUtil;

    /**
     * 生成 单号
     * 业务代码-LL年月日4位流水号
     */
    private String initOrderNumber(String bizType) {
        String date = DateUtils.getCurrentDate(DateUtils.SHORT_DATE_FORMAT_2);
        String redisKey = String.format(BaseConstants.RedisKey.APPLY_ORDER_NO_KEY, bizType, date);
        Long serialNo = redisUtil.incrAndExpire(redisKey, BaseConstants.RedisConstants.APPLY_ORDER_ITEM_NO_DELTA, DateUtils.getLeftSecondsCurrentDay());
        return String.format("%s-LL%s%04d", bizType, date, serialNo);
    }

}
