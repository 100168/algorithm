package com.jiduauto.sps.server.handler;

import cn.hutool.json.JSONUtil;
import com.jiduauto.dit.outbox.anno.ResultCallback;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.pojo.Result;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.client.req.AsnReceiveSyncReq;
import com.jiduauto.sps.server.client.req.StockInAndOutSynQEReq;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.BaseConstants.MessageTitle;
import com.jiduauto.sps.server.consts.BaseConstants.RoSyncIndex;
import com.jiduauto.sps.server.convertor.NoticedDtoConvertor;
import com.jiduauto.sps.server.pojo.dto.LingkeBOCancelContextDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderAuditEditDto;
import com.jiduauto.sps.server.pojo.po.AsnBasicPo;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderPo;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderPo;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.service.IStockOperationHistoryService;
import com.jiduauto.sps.server.service.IStockTempService;
import com.jiduauto.sps.server.service.impl.SpsOrderDataQuery;
import com.jiduauto.sps.server.utils.JsonUtil;
import com.jiduauto.sps.server.utils.WebhookUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;

import static com.jiduauto.sps.server.consts.BaseConstants.KitOrderSyncIndex.INBOUND;
import static com.jiduauto.sps.server.consts.OutboxConst.MessageType.*;

/**
 * @author panjian
 */
@Slf4j
@Component
public class OutboxMessageCallbacks {

    @Resource
    private WebhookUtil webhookUtil;
    @Resource
    private NoticedDtoConvertor noticedDtoConvertor;

    @Resource
    private IStockTempService stockTempService;

    @Resource
    private SpsOrderDataQuery spsOrderDataQuery;
    @Resource
    private IStockOperationHistoryService stockOperationHistoryService;

    @ResultCallback(msgType = RETURN_ORDER_PUSH, bitIndex = RoSyncIndex.WMS)
    public void roDhlOutBoundNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            PurchaseReturnOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseReturnOrderPo.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(), MessageTitle.OUTBOUND_DHL));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.OUTBOUND_DHL);
        }
    }

    @ResultCallback(msgType = RETURN_ORDER_PUSH, bitIndex = RoSyncIndex.SRM)
    public void roPushSrmNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            PurchaseReturnOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseReturnOrderPo.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(), MessageTitle.PUSH_SRM));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.PUSH_SRM);
        }
    }


    @ResultCallback(msgType = PURCHASE_APPLY_ORDER_TO_DHL)
    public void prDhlInBoundNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            PurchaseApplyOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseApplyOrderPo.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(), MessageTitle.PR_INBOUND_DHL));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.PR_INBOUND_DHL);
        }
    }

    @ResultCallback(msgType = PURCHASE_APPLY_ORDER_TO_SAP)
    public void prToSapNotice(OutboxMessage outboxMessage, Result result) {

        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            PurchaseApplyOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseApplyOrderPo.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(), MessageTitle.PR_TO_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.PR_TO_SAP);
        }
        

    }

    @ResultCallback(msgType = PR_DELETE_TO_SAP)
    public void prDelToSapNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            PurchaseApplyOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseApplyOrderPo.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(), MessageTitle.PR_DEL_TO_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.PR_DEL_TO_SAP);
        }
    }

    @ResultCallback(msgType = PR_AUDIT_EDIT_TO_SAP)
    public void prAuditEditToSapNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            PurchaseApplyOrderAuditEditDto dto = JSONUtil.toBean(outboxMessage.getContent(), PurchaseApplyOrderAuditEditDto.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(dto.getOrderPo(), result.getMessage(), MessageTitle.PR_AUDIT_EDIT_TO_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.PR_AUDIT_EDIT_TO_SAP);
        }
    }

    @ResultCallback(msgType = PR_CANCEL_TO_SAP)
    public void prCancelToSapNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            PurchaseApplyOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), PurchaseApplyOrderPo.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(), MessageTitle.PR_CANCEL_TO_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.PR_CANCEL_TO_SAP);
        }
    }

    @ResultCallback(msgType = LINGKE_BO_CANCEL_TO_SAP)
    public void lingkeBOCancelToSapNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            LingkeBOCancelContextDto contextDto = JsonUtil.toObject(outboxMessage.getContent(), LingkeBOCancelContextDto.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(contextDto.getPurchaseApplyOrder(), result.getMessage(), MessageTitle.LINGKE_BO_CANCEL_TO_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.LINGKE_BO_CANCEL_TO_SAP);
        }
    }

    @ResultCallback(msgType = KIT_ORDER_CONFIRM_OR_CANCEL)
    public void kitDhlOutBoundNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            KitOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), KitOrderPo.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(), MessageTitle.KIT_OUTBOUND_DHL));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.KIT_OUTBOUND_DHL);
        }
    }

    @ResultCallback(msgType = KIT_ORDER_CONFIRM_OR_CANCEL, bitIndex = INBOUND)
    public void kitDhlInBoundNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            KitOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), KitOrderPo.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(), MessageTitle.KIT_INBOUND_DHL));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.KIT_INBOUND_DHL);
        }
    }

    @ResultCallback(msgType = VP_ASN_RECEIVE_TO_SAP)
    public void vpAsnReceiveToSapCallback(OutboxMessage outboxMessage, Result result) {
        AsnReceiveSyncReq request = JSONUtil.toBean(outboxMessage.getContent(), AsnReceiveSyncReq.class);
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            AsnBasicPo orderPo = new AsnBasicPo();
            orderPo.setBizType(BizTypeEnum.VP.getBizType());
            orderPo.setAsnCode(request.getMessageBody().getHeader().getReceivenote());
            Map<String, String> msgMap = webhookUtil.buildMsgMap(noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(),
                    MessageTitle.VP_ASN_RECEIVE_TO_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.VP_ASN_RECEIVE_TO_SAP);
        }
    }

    /**
     * 门店SO单 总仓发货（出库）同步给SAP 定时重试 失败异常处理
     * @param outboxMessage
     * @param result
     */
    @ResultCallback(msgType = SP_SO_DELIVER_TO_SAP_SD014)
    public void spSpDeliverToSapSd014Callback(OutboxMessage outboxMessage, Result result) {
        InAndOutStockRequest request = JSONUtil.toBean(outboxMessage.getContent(), InAndOutStockRequest.class);
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            //失败发送 飞书提醒
            Map<String, String> msgMap = webhookUtil.buildMsgMap(noticedDtoConvertor.buildNoticedDto(request, result.getMessage(), MessageTitle.SP_SO_DELIVER_TO_SAP_SD014));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.SP_SO_DELIVER_TO_SAP_SD014);
        }else{
            //成功 更新重试记录状态
            stockOperationHistoryService.finishedHistory(request.getBusinessType(),request.getBizType(),request.getTradeNo());
        }
    }

    @ResultCallback(msgType = STOCK_IN_AND_OUT_TO_QE)
    public void stockInAndOutToQE(OutboxMessage outboxMessage, Result result) {
        StockInAndOutSynQEReq request = JSONUtil.toBean(outboxMessage.getContent(), StockInAndOutSynQEReq.class);
        if (!result.isSuccess() && sendFlag(outboxMessage)) {
            Map<String, String> msgMap = webhookUtil.buildMsgMap(noticedDtoConvertor.buildNoticedDto(BizTypeEnum.QE.getBizType(), request.getTradeNo(), result.getMessage(), MessageTitle.STOCK_IN_AND_OUT_TO_QE));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), MessageTitle.STOCK_IN_AND_OUT_TO_QE);
        }
    }

    @ResultCallback(msgType = ASN_PUSH_THIRD_WAREHOUSE)
    public void pushESWarehouse(OutboxMessage outboxMessage, Result result) {
        AsnBasicPo asnBasicPo = JSONUtil.toBean(outboxMessage.getContent(), AsnBasicPo.class);

        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            Map<String, String> contentMap = webhookUtil.buildMsgMap(noticedDtoConvertor.buildNoticedDto(asnBasicPo, result.getMessage(), MessageTitle.ANS_PUSH_ES));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(contentMap));
        }
    }

    @ResultCallback(msgType = ASN_PUSH_THIRD_WAREHOUSE, bitIndex = BaseConstants.AsnSyncIndex.WMS)
    public void pushWMSWarehouse(OutboxMessage outboxMessage, Result resultResp) {
        AsnBasicPo asnBasicPo = JSONUtil.toBean(outboxMessage.getContent(), AsnBasicPo.class);
        if (!resultResp.isSuccess()  && sendFlag(outboxMessage)) {
            Map<String, String> contentMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(asnBasicPo, resultResp.getMessage(),
                            MessageTitle.ANS_PUSH_WMS));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(contentMap));
        }
    }

    /**
     * 重试次数 等于 提醒次数的时候 才发送 飞书告警， 提高告警敏捷性
     * @param outboxMessage
     * @return
     */
    private boolean sendFlag(OutboxMessage outboxMessage){
        return outboxMessage.getNoticeCount() == (outboxMessage.getRetryCount() + 1);
    }
}
