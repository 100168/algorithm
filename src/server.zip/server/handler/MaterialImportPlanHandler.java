package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.MaterialMapper;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.material.MaterialImportPlanResp;
import com.jiduauto.sps.server.pojo.vo.resp.material.MaterialImportPlanResultResp;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.threads.MaterialUpdateThread;
import com.jiduauto.sps.server.utils.BeanFillUtil;
import com.jiduauto.sps.server.utils.BooleanUtil;
import com.jiduauto.sps.server.utils.NumberUtil;
import com.jiduauto.sps.server.utils.StringUtils;
import com.jiduauto.sps.server.utils.UserUtil;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 * 零件主数据 计划导入 解析
 * 快慢流属性 MOQ	LeadTime	是否DFS	安全库存	计划员
 */

@Service
@Slf4j
public class MaterialImportPlanHandler extends BaseImportHandler<MaterialImportPlanResp, MaterialImportPlanResultResp>{
    @Autowired
    private MaterialMapper materialMapper;

    @Autowired
    private IBosService bosService;

    private static ExecutorService executorService = Executors.newFixedThreadPool(8);


    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("*售后件号",	"快慢流属性",	"MOQ","LeadTime","是否DFS","是否定制件",	"安全库存",	"计划员","是否DB总成件");

    public List<ImportDataInfo<MaterialImportPlanResp>> readFile(MultipartFile file) throws BizException {
        if(file.isEmpty()){
            throw new BizException("文件不能为空");
        }
        try(InputStream inputStream = file.getInputStream()){
            List<ImportDataInfo<MaterialImportPlanResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream,MaterialImportPlanResp.class,new ReadListener(){
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if(headMap == null){
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s->s.getStringValue().replace("\n","")).collect(Collectors.toList());
                    if(!Objects.equals(headList,HEAD_VALUE_LIST)){
                        throw new BizException("模板表头数据不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if(rowNumber > BaseConstants.MAX_LIMIT_MATERIAL_IMPORT+1){
                        throw new BizException("单次导入最大数据量"+BaseConstants.MAX_LIMIT_MATERIAL_IMPORT+"行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try{
                        ImportDataInfo info = new ImportDataInfo();
                        MaterialImportPlanResp data = (MaterialImportPlanResp)o;
                        if(data != null){
                            info.setData(data);
                            importList.add(info);
                        }
                    }catch(Exception e){
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        }catch(BizException e){
            log.error("零件主数据导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw e;
        }catch(Exception e){
            log.error("零件主数据计划导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "零件主数据导入解析异常,请检查文件格式");
        }
    }
    /**
     * 校验文件
     *
     * @param list
     * @return
     * @throws BizException
     */
    @Override
    protected ImportReturnDataInfo<MaterialImportPlanResultResp> process(List<ImportDataInfo<MaterialImportPlanResp>> list) throws BizException {
        ImportReturnDataInfo<MaterialImportPlanResultResp> importResult = new ImportReturnDataInfo<>();
        List<String> salePartNums = new ArrayList<>();
        boolean hasError = false;
        Map<String,String> infoMap = new HashMap<>();
        List<MaterialImportPlanResultResp> resultResps = new ArrayList<>();
        for(ImportDataInfo<MaterialImportPlanResp> data:list){
            StringBuilder errors = new StringBuilder();
            MaterialImportPlanResp planResp = data.getData();
            MaterialImportPlanResultResp resultResp = new MaterialImportPlanResultResp();
            BeanUtils.copyProperties(planResp, resultResp);
            String salePartNum =  planResp.getSalePartNum();
            if(StringUtils.isBlank(salePartNum)){
                errors.append("售后件号为空;");
                hasError = true;
            }else{
                // 去除字符串最前与最端段空格
                resultResp.setSalePartNum(StringUtils.trim(salePartNum));
                salePartNum = StringUtils.deleteWhitespace(salePartNum);
                salePartNums.add(salePartNum);
            }
            if(StringUtils.isNotBlank(planResp.getMoq()) && !NumberUtil.isPositiveInteger(planResp.getMoq()) ){
                errors.append("MOQ请填写正整数;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(planResp.getSafeStock()) && !NumberUtil.isPositiveInteger(planResp.getSafeStock()) ){
                errors.append("安全库存请填写正整数;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(planResp.getLeadTime()) && !NumberUtil.isPositiveInteger(planResp.getLeadTime())){
                errors.append("LeadTime请填写正整数;");
                hasError = true;
            }
            if(infoMap.containsKey(planResp.getSalePartNum())){
                errors.append("售后件号重复了,请检查文件;");
                hasError = true;
            }else{
                infoMap.put(planResp.getSalePartNum(),planResp.getSalePartNum());
            }
            if(StringUtils.isNotBlank(planResp.getIsDfs()) &&( !"是".equals(planResp.getIsDfs()) &&
                    !"否".equals(planResp.getIsDfs()) )){
                errors.append("是否DFS填写 是/否;");
                hasError = true;
            }

            if(StringUtils.isNotBlank(planResp.getIsCustom()) &&( !"是".equals(planResp.getIsCustom()) &&
                    !"否".equals(planResp.getIsCustom()) )){
                errors.append("是否定制件 是/否;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(planResp.getDbFlag()) &&( !"是".equals(planResp.getDbFlag()) &&
                    !"否".equals(planResp.getDbFlag()) )){
                errors.append("是否DB总成件 是/否;");
                hasError = true;
            }
            resultResp.setErrorInfo(errors.toString());
            resultResps.add(resultResp);
        }

        List<String> duplicate = materialMapper.getBySalePartNums(BizTypeThreadHolder.getBizType(),salePartNums);
        for(MaterialImportPlanResultResp resultResp:resultResps){
            if(!duplicate.contains(resultResp.getSalePartNum())){
                if(StringUtils.isEmpty(resultResp.getErrorInfo())){
                    resultResp.setErrorInfo("售后件号不存在;");
                }else{
                    resultResp.setErrorInfo(resultResp.getErrorInfo()+"售后件号不存在;");
                }
                hasError = true;
            }
        }

        if(hasError){
            importResult.setError(resultResps);
            importResult.setImportFlag(false);
        }else{
            importResult.setData(resultResps);
            importResult.setImportFlag(true);
        }
        return importResult;
    }

    /**
     * 返回结果
     *
     * @param returnDataInfo
     * @throws BizException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void afterProcess(ImportReturnDataInfo<MaterialImportPlanResultResp> returnDataInfo) throws BizException {
        if(!CollectionUtils.isEmpty(returnDataInfo.getError())){
            //校验失败  返回失败文件地址
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        }else{
            List<String> salePartNums = returnDataInfo.getData().stream().map(MaterialImportPlanResultResp::getSalePartNum).collect(Collectors.toList());
            List<MaterialPo>  materialPos = materialMapper.selectBySalePartNums(returnDataInfo.getBizType(),salePartNums);
            Map<String, MaterialPo> materialPoMap = materialPos.stream().collect(Collectors.toMap(MaterialPo::getSalePartNum, MaterialPo -> MaterialPo));

            // 找到业务类型为SS的 售后件号-零件主数据键值对
            Map<String, MaterialPo> ssUpdateMap = materialMapper.selectBySalePartNums(BizTypeEnum.SS.getBizType(), salePartNums).stream()
                    .collect(Collectors.toMap(MaterialPo::getSalePartNum, MaterialPo -> MaterialPo));

            List<Future<BaseResult<String>>> futures = new ArrayList<>();
            Map<String, MaterialImportPlanResultResp> resultRespMap = new HashMap<>();
            // 校验通过 更新
            for(MaterialImportPlanResultResp resultResp: returnDataInfo.getData()){
                resultRespMap.put(resultResp.getSalePartNum(),resultResp);
                BeanFillUtil.fillNullStr(resultResp);
                MaterialPo po = new MaterialPo();
                BeanUtils.copyProperties(resultResp, po);
                if(StringUtils.isNotBlank(resultResp.getMoq())){
                    po.setMoq(Integer.valueOf(resultResp.getMoq()));
                }else {
                    po.setMoq(1);
                }
                po.setIsDfs(BooleanUtil.chineseDescToYN(resultResp.getIsDfs()));
                po.setIsCustom(BooleanUtil.chineseDescToYN(resultResp.getIsCustom()));
                po.setDbFlag(BooleanUtil.chineseDescToYN(resultResp.getDbFlag()));
                po.setId(materialPoMap.get(resultResp.getSalePartNum()).getId());
                po.setUpdateUser(UserUtil.getUserName());
                List<MaterialPo> updateList = new ArrayList<>();
                updateList.add(po);

                if(returnDataInfo.getBizType().equals(BizTypeEnum.JC.getBizType())){
                    MaterialPo ssUpdateTemp = ssUpdateMap.get(resultResp.getSalePartNum());
                    // 业务类型为JC且在SS中已存在当前数据则在SS中走更新逻辑，防止空指针
                    if(ssUpdateTemp != null){
                        MaterialPo ssUpdate = new MaterialPo();
                        BeanUtils.copyProperties(po,ssUpdate);
                        // 设置唯一标识，其他的一样
                        ssUpdate.setBizType(BizTypeEnum.SS.getBizType());
                        ssUpdate.setId(ssUpdateTemp.getId());
                        materialMapper.updateById(ssUpdate);
                        updateList.add(ssUpdate);
                    }
                }
                Future<BaseResult<String>> future = executorService.submit(new MaterialUpdateThread(materialMapper,updateList));
                futures.add(future);
            }
            boolean success = true;
            List<MaterialImportPlanResultResp> errorList = new ArrayList<>();
            for(Future<BaseResult<String>> future:futures){
                try{
                    if(future.get().isError()){
                        MaterialImportPlanResultResp resultResp = resultRespMap.get(future.get().getData());
                        resultResp.setErrorInfo("更新失败，请检查");
                        success = false;
                        errorList.add(resultResp);
                    }
                }catch (Exception e){
                    throw new BizException(-1,"导入失败请稍,后重试");
                }
            }
            if(!success){
                String fileKey = createErrExcel(errorList);
                returnDataInfo.setImportFlag(false);
                returnDataInfo.setFileUrl(fileKey);
                return;
            }

        }
        returnDataInfo.setImportFlag(true);
    }


    private String createErrExcel(List<MaterialImportPlanResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "零件主数据计划导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}",excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), MaterialImportPlanResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet( "失败列表" ).build();
            writer.write(error,writeSheet1);
        }
        catch (Exception e) {
            log.error("materialImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        }finally {
            if(writer !=null){
                writer.finish();
            }
        }

        try(InputStream inputStream = Files.newInputStream(excelFile.toPath())){
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "计划导入失败原因.xlsx");
            if (bosFileResult == null){
                throw new BizException( "异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        }catch (Exception e){
            log.error("materialImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if(excelFile.exists()){
                boolean delete = excelFile.delete();
                log.info("零件主数据计划导入失败原因临时文件删除结果：{}",delete);
            }
        }
    }

    public static void main(String[] args) {
        MaterialPo materialPo = new MaterialPo();
        MaterialImportPlanResultResp resp = new MaterialImportPlanResultResp();
        BeanUtils.copyProperties(resp,materialPo);
        System.out.println(materialPo);
    }
}
