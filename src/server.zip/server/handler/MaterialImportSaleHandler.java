package com.jiduauto.sps.server.handler;

import com.jiduauto.sps.server.Enum.YNEnums;
import com.jiduauto.sps.server.Enum.YesNoEnums;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.MaterialMapper;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.material.MaterialImportSaleResp;
import com.jiduauto.sps.server.pojo.vo.resp.material.MaterialImportSaleResultResp;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.service.ICommonService;
import com.jiduauto.sps.server.threads.MaterialUpdateThread;
import com.jiduauto.sps.server.utils.BeanFillUtil;
import com.jiduauto.sps.server.utils.BooleanUtil;
import com.jiduauto.sps.server.utils.StringUtils;
import com.jiduauto.sps.server.utils.UserUtil;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * 零件主数据 销售导入 解析
 * *售后件号	最小包装	是否销售	零件销售属性	精确追溯件标识	钣喷是否可订购	BO是否转单
 */

@Service
@Slf4j
public class MaterialImportSaleHandler extends BaseImportHandler<MaterialImportSaleResp, MaterialImportSaleResultResp>{
    @Autowired
    private MaterialMapper materialMapper;

    @Autowired
    private IBosService bosService;
    @Autowired
    private ICommonService commonService;

    private static ExecutorService executorService = Executors.newFixedThreadPool(8);
    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("*售后件号","是否销售",	"零件销售属性",
                    "精确追溯件标识",	"钣喷是否可订购",	"BO是否转单","是否必备件","是否管控件");

    public List<ImportDataInfo<MaterialImportSaleResp>> readFile(MultipartFile file) throws BizException {
        if(file.isEmpty()){
            throw new BizException("文件不能为空");
        }
        try(InputStream inputStream = file.getInputStream()){
            List<ImportDataInfo<MaterialImportSaleResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream,MaterialImportSaleResp.class,new ReadListener(){
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if(headMap == null){
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s->s.getStringValue().replace("\n","")).collect(Collectors.toList());
                    if(!Objects.equals(headList,HEAD_VALUE_LIST)){
                        throw new BizException("模板表头数据不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if(rowNumber > BaseConstants.MAX_LIMIT_MATERIAL_IMPORT+1){
                        throw new BizException("单次导入最大数据量"+BaseConstants.MAX_LIMIT_MATERIAL_IMPORT+"行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try{
                        ImportDataInfo info = new ImportDataInfo();
                        MaterialImportSaleResp data = (MaterialImportSaleResp)o;
                        if(data != null){
                            info.setData(data);
                            importList.add(info);
                        }
                    }catch(Exception e){
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        }catch(BizException e){
            log.error("零件主数据导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw e;
        }catch(Exception e){
            log.error("零件主数据计划导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "零件主数据导入解析异常,请检查文件格式");
        }
    }
    /**
     * 校验文件
     *
     * @param list
     * @return
     * @throws BizException
     */
    @Override
    protected ImportReturnDataInfo<MaterialImportSaleResultResp> process(List<ImportDataInfo<MaterialImportSaleResp>> list) throws BizException {
        ImportReturnDataInfo<MaterialImportSaleResultResp> importResult = new ImportReturnDataInfo<>();
        List<String> salePartNums = new ArrayList<>();
        boolean hasError = false;
        Map<String,String> infoMap = new HashMap<>();
        List<MaterialImportSaleResultResp> resultResps = new ArrayList<>();
        for(ImportDataInfo<MaterialImportSaleResp> data:list){
            StringBuilder errors = new StringBuilder();
            MaterialImportSaleResp saleResp = data.getData();
            MaterialImportSaleResultResp resultResp = new MaterialImportSaleResultResp();
            BeanUtils.copyProperties(saleResp, resultResp);
            String salePartNum =  saleResp.getSalePartNum();
            if(StringUtils.isBlank(salePartNum)){
                errors.append("售后件号为空;");
                hasError = true;
            }else{
                // 去除字符串最前与最端段空格
                resultResp.setSalePartNum(StringUtils.trim(salePartNum));
                salePartNum = StringUtils.deleteWhitespace(salePartNum);
                salePartNums.add(salePartNum);
            }
            if(infoMap.containsKey(saleResp.getSalePartNum())){
                errors.append("售后件号重复了,请检查文件;");
                hasError = true;
            }else{
                infoMap.put(saleResp.getSalePartNum(),saleResp.getSalePartNum());
            }
            if(StringUtils.isNotBlank(saleResp.getIsSale()) &&( !"是".equals(saleResp.getIsSale()) &&
                    !"否".equals(saleResp.getIsSale()) )){
                errors.append("是否销售填写 是/否;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(saleResp.getAccurateTrace()) &&( !"是".equals(saleResp.getAccurateTrace()) &&
                    !"否".equals(saleResp.getAccurateTrace()) )){
                errors.append("精确追溯件标识 是/否;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(saleResp.getBanPenOrder()) &&( !"是".equals(saleResp.getBanPenOrder()) &&
                    !"否".equals(saleResp.getBanPenOrder()) )){
                errors.append("钣喷是否可订购 是/否;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(saleResp.getBoTransfer()) &&( !"是".equals(saleResp.getBoTransfer()) &&
                    !"否".equals(saleResp.getBoTransfer()) )){
                errors.append("BO是否转单 是/否;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(saleResp.getIsRequire()) &&( !"是".equals(saleResp.getIsRequire()) &&
                    !"否".equals(saleResp.getIsRequire()) )){
                errors.append("是否必备件 是/否;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(saleResp.getIsRequire()) &&( !YNEnums.Y.getValue().equals(saleResp.getIsRequire()) &&
                    !YNEnums.N.getValue().equals(saleResp.getIsRequire()) )){
                errors.append("是否必备件 是/否;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(saleResp.getPartSaleField())){
                String code  = commonService.getDictItemCode(DictEnum.PartSaleField, saleResp.getPartSaleField());
                if(code == null){
                    errors.append("零件销售属性不符合字典项;");
                    hasError = true;
                }
            }

            resultResp.setErrorInfo(errors.toString());
            resultResps.add(resultResp);
        }
        if(!CollectionUtils.isEmpty(salePartNums)){
            List<String> duplicate = materialMapper.getBySalePartNums(BizTypeThreadHolder.getBizType(),salePartNums);
            for(MaterialImportSaleResultResp resultResp:resultResps){
                if(!duplicate.contains(resultResp.getSalePartNum())){
                    if(StringUtils.isEmpty(resultResp.getErrorInfo())){
                        resultResp.setErrorInfo("售后件号不存在;");
                    }else{
                        resultResp.setErrorInfo(resultResp.getErrorInfo()+"售后件号不存在;");
                    }
                    hasError = true;
                }
            }
        }

        if(hasError){
            importResult.setError(resultResps);
            importResult.setImportFlag(false);
        }else{
            importResult.setData(resultResps);
            importResult.setImportFlag(true);
        }
        return importResult;
    }

    /**
     * 返回结果
     *
     * @param returnDataInfo
     * @throws BizException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    protected void afterProcess(ImportReturnDataInfo<MaterialImportSaleResultResp> returnDataInfo) throws BizException {
        if(!CollectionUtils.isEmpty(returnDataInfo.getError())){
            //校验失败  返回失败文件地址
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        }else{
            List<String> salePartNums = returnDataInfo.getData().stream().map(MaterialImportSaleResultResp::getSalePartNum).collect(Collectors.toList());
            List<MaterialPo>  materialPos = materialMapper.selectBySalePartNums(returnDataInfo.getBizType(),salePartNums);
            Map<String, MaterialPo> materialPoMap = materialPos.stream().collect(Collectors.toMap(MaterialPo::getSalePartNum, MaterialPo -> MaterialPo));

            // 找到业务类型为SS的 售后件号-零件主数据键值对
            Map<String, MaterialPo> ssUpdateMap = materialMapper.selectBySalePartNums(BizTypeEnum.SS.getBizType(), salePartNums).stream()
                    .collect(Collectors.toMap(MaterialPo::getSalePartNum, MaterialPo -> MaterialPo));
            List<Future<BaseResult<String>>> futures = new ArrayList<>();

            Map<String, MaterialImportSaleResultResp> resultRespMap = new HashMap<>();
            // 校验通过 更新
            for(MaterialImportSaleResultResp resultResp: returnDataInfo.getData()){

                resultRespMap.put(resultResp.getSalePartNum(),resultResp);
                MaterialPo po = new MaterialPo();
                BeanFillUtil.fillNullStr(resultResp);
                BeanUtils.copyProperties(resultResp, po);
                MaterialPo oldPo = materialPoMap.get(po.getSalePartNum());

                po.setId(oldPo.getId());
                po.setUpdateUser(UserUtil.getUserName());
                po.setIsRequire(BooleanUtil.chineseDescToYN(resultResp.getIsRequire()));
                po.setIsControl(BooleanUtil.chineseDescToYN(resultResp.getIsControl()));
                List<MaterialPo> updateList = new ArrayList<>();
                updateList.add(po);

                if(returnDataInfo.getBizType().equals(BizTypeEnum.JC.getBizType())){
                    MaterialPo ssUpdateTemp = ssUpdateMap.get(resultResp.getSalePartNum());
                    // 业务类型为JC且在SS中已存在当前数据则在SS中走更新逻辑，防止空指针
                    if(ssUpdateTemp != null){
                        MaterialPo ssUpdate = new MaterialPo();
                        BeanUtils.copyProperties(po,ssUpdate);
                        // 设置唯一标识，其他的一样
                        ssUpdate.setBizType(BizTypeEnum.SS.getBizType());
                        ssUpdate.setId(ssUpdateTemp.getId());
                        updateList.add(ssUpdate);
                    }
                }

                Future<BaseResult<String>> future = executorService.submit(new MaterialUpdateThread(materialMapper,updateList));
                futures.add(future);

            }
            boolean success = true;
            List<MaterialImportSaleResultResp> errorList = new ArrayList<>();
            for(Future<BaseResult<String>> future:futures){
                try{
                    if(future.get().isError()){
                        MaterialImportSaleResultResp resultResp = resultRespMap.get(future.get().getData());
                        resultResp.setErrorInfo("更新失败，请检查");
                        success = false;
                        errorList.add(resultResp);
                    }
                }catch (Exception e){
                    throw new BizException(-1,"导入失败请稍,后重试");
                }
            }
            if(!success){
                String fileKey = createErrExcel(errorList);
                returnDataInfo.setImportFlag(false);
                returnDataInfo.setFileUrl(fileKey);
                return;
            }
        }
        returnDataInfo.setImportFlag(true);
    }


    private String createErrExcel(List<MaterialImportSaleResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "零件主数据销售字段导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}",excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), MaterialImportSaleResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet( "失败列表" ).build();
            writer.write(error,writeSheet1);
        }
        catch (Exception e) {
            log.error("materialImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        }finally {
            if(writer !=null){
                writer.finish();
            }
        }

        try(InputStream inputStream = Files.newInputStream(excelFile.toPath())){
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "零件主数据销售字段导入失败原因.xlsx");
            if (bosFileResult == null){
                throw new BizException( "异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        }catch (Exception e){
            log.error("materialImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if(excelFile.exists()){
                boolean delete = excelFile.delete();
                log.info("零件主数据计划导入失败原因临时文件删除结果：{}",delete);
            }
        }
    }
}
