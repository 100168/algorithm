package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.Enum.BackOrderOccupyEnum;
import com.jiduauto.sps.server.Enum.ShippingMethodEnum;
import com.jiduauto.sps.server.caches.DictItemCache;
import com.jiduauto.sps.server.client.MapLocationClient;
import com.jiduauto.sps.server.client.resp.DistrictResp;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.dto.param.LogisticsSoleParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.LogisticsPo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.LogisticsExportResp;
import com.jiduauto.sps.server.pojo.vo.resp.LogisticsImportResultResp;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.service.ILogisticsService;
import com.jiduauto.sps.server.utils.BeanCopierUtil;
import com.jiduauto.sps.server.utils.NumberUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 物流时效主数据导入
 *
 * @author dong.li01
 * @since 5/6/23 10:05 AM
 */
@Service
@Slf4j
public class LogisticsImportHandler extends BaseImportHandler<LogisticsExportResp, LogisticsImportResultResp> {

    @Resource
    private IBosService bosService;

    @Resource
    private ILogisticsService logisticsService;

    @Resource
    private DictItemCache dictItemCache;

    @Resource
    private MapLocationClient mapLocationClient;

    private static final Integer MAX_LIMIT = 1000;

    private static final List<String> HEAD_VALUE_LIST = Arrays.asList("始发省份", "始发城市", "目的地省份", "目的地城市", "订单类型", "运输方式", "时效(天)");

    public List<ImportDataInfo<LogisticsExportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<LogisticsExportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, LogisticsExportResp.class, new ReadListener() {

                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");
                    }
                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        LogisticsExportResp data = (LogisticsExportResp) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (Exception e) {
            log.error("物流时效主数据导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "物流时效主数据导入解析异常,请检查文件格式");
        }
    }

    @Override
    protected ImportReturnDataInfo<LogisticsImportResultResp> process(List<ImportDataInfo<LogisticsExportResp>> list) throws BizException {
        ImportReturnDataInfo<LogisticsImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        boolean hasError = false;
        Map<String, String> map = new HashMap<>();
        List<LogisticsImportResultResp> resultResps = new ArrayList<>();
        // 获取省市字典
        Map<String, String> nameAndCodeMap = dictItemCache.getNameAndCodeMap(DictEnum.MapLocationDistrict.getDictCode());
        for (ImportDataInfo<LogisticsExportResp> dataInfo : list) {
            LogisticsExportResp resp = dataInfo.getData();
            LogisticsImportResultResp resultResp = new LogisticsImportResultResp();
            BeanUtils.copyProperties(resp, resultResp);
            StringBuilder sb = new StringBuilder();
            StringBuilder curKey = new StringBuilder();
            final String curValue = null;
            if (StringUtils.isEmpty(resp.getStartProvince())) {
                sb.append("始发省份不可以为空;");
                hasError = true;
            } else {
                if (!nameAndCodeMap.containsKey(resp.getStartProvince())) {
                    sb.append("始发省份不存在;");
                    hasError = true;
                } else {
                    curKey.append(nameAndCodeMap.get(resp.getStartProvince()));
                }
            }
            if (StringUtils.isEmpty(resp.getStartCity())) {
                sb.append("始发城市不可以为空;");
                hasError = true;
            } else {
                if (!nameAndCodeMap.containsKey(resp.getStartCity())) {
                    sb.append("始发城市不存在;");
                    hasError = true;
                } else {
                    curKey.append(nameAndCodeMap.get(resp.getStartCity()));
                }
            }
            if (StringUtils.isEmpty(resp.getEndProvince())) {
                sb.append("目的地省份不可以为空;");
                hasError = true;
            } else {
                if (!nameAndCodeMap.containsKey(resp.getEndProvince())) {
                    sb.append("目的地省份不存在;");
                    hasError = true;
                } else {
                    curKey.append(nameAndCodeMap.get(resp.getEndProvince()));
                }
            }
            if (StringUtils.isEmpty(resp.getEndCity())) {
                sb.append("目的地城市不可以为空;");
                hasError = true;
            } else {
                if (!nameAndCodeMap.containsKey(resp.getEndCity())) {
                    sb.append("目的地城市不存在;");
                    hasError = true;
                } else {
                    curKey.append(nameAndCodeMap.get(resp.getEndCity()));
                }
            }
            if (StringUtils.isEmpty(resp.getLogisticsOrderType())) {
                sb.append("订单类型;");
                hasError = true;
            } else {
                if (BackOrderOccupyEnum.getBeanNameByCode(resp.getLogisticsOrderType()) == null) {
                    sb.append("订单类型不存在;");
                    hasError = true;
                } else {
                    curKey.append(resp.getLogisticsOrderType());
                }
            }
            if (StringUtils.isEmpty(resp.getShippingMethod())) {
                sb.append("运输方式不可以为空;");
                hasError = true;
            } else {
                if (ShippingMethodEnum.getDesc(resp.getShippingMethod()) == null) {
                    sb.append("运输方式不存在;");
                    hasError = true;
                } else {
                    curKey.append(resp.getShippingMethod());
                }
            }
            if (StringUtils.isEmpty(resp.getLogisticsAging())) {
                sb.append("时效不可以为空;");
                hasError = true;
            } else {
                try {
                    BigDecimal bigDecimal = new BigDecimal(resp.getLogisticsAging());
                    // 判断是否是整数或者值哦雨一位小数
                    if (bigDecimal.compareTo(new BigDecimal(0)) != 1 || !NumberUtil.isOneDecimalNumber(resp.getLogisticsAging())) {
                        sb.append("时效的值为正整数或者保留一位小数;");
                        hasError = true;
                    }
                } catch (Exception e) {
                    sb.append("时效格式错误;");
                    hasError = true;
                }
            }
            if (map.containsKey(curKey.toString())) {
                sb.append("当前输入数据重复，请检查文件");
                hasError = true;
            } else {
                map.put(curKey.toString(), curValue);
            }
            resultResp.setErrorInfo(sb.toString());
            resultResps.add(resultResp);
        }
        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    @Override
    protected void afterProcess(ImportReturnDataInfo<LogisticsImportResultResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        } else {
            List<LogisticsPo> poList = new ArrayList<>();
            // 获取省市字典
            Map<String, String> nameAndCodeMap = dictItemCache.getNameAndCodeMap(DictEnum.MapLocationDistrict.getDictCode());
            // 校验通过 保存入库
            for (LogisticsImportResultResp resultResp : returnDataInfo.getData()) {
                LogisticsPo po = new LogisticsPo();
                if (resultResp.getStartProvince().equals(resultResp.getStartCity())) {
                    // 导入数据中始发省市名称一样的情况(北京市-北京市)
                    String[] provinceAndCityCode = getProvinceAndCityCode(resultResp.getStartProvince());
                    // 始发省份
                    po.setStartProvince(provinceAndCityCode[0]);
                    // 始发城市
                    po.setStartCity(provinceAndCityCode[1]);
                } else {
                    // 始发省份
                    po.setStartProvince(nameAndCodeMap.get(resultResp.getStartProvince()));
                    // 始发城市
                    po.setStartCity(nameAndCodeMap.get(resultResp.getStartCity()));
                }
                if (resultResp.getEndProvince().equals(resultResp.getEndCity())) {
                    // 导入数据中目的地省市名称一样的情况(北京市-北京市)
                    String[] provinceAndCityCode = getProvinceAndCityCode(resultResp.getEndProvince());
                    // 始发省份
                    po.setEndProvince(provinceAndCityCode[0]);
                    // 始发城市
                    po.setEndCity(provinceAndCityCode[1]);
                } else {
                    // 目的地省份
                    po.setEndProvince(nameAndCodeMap.get(resultResp.getEndProvince()));
                    // 目的地城市
                    po.setEndCity(nameAndCodeMap.get(resultResp.getEndCity()));
                }
                // 订单类型
                po.setLogisticsOrderType(resultResp.getLogisticsOrderType());
                // 运输方式
                po.setShippingMethod(resultResp.getShippingMethod());
                // 时效
                po.setLogisticsAging(new BigDecimal(resultResp.getLogisticsAging()));
                // 业务类型
                po.setBizType(returnDataInfo.getBizType());
                poList.add(po);
            }
            // 存在则更新，否则插入
            poList.stream().forEach(e -> {
                LogisticsPo logisticsPo = logisticsService.getBySixAttribute(BeanCopierUtil.copy(e, LogisticsSoleParam.class));
                // 不为空，说明只有时效不一样，直接覆盖
                if (logisticsPo != null) {
                    logisticsPo.setLogisticsAging(e.getLogisticsAging());
                    logisticsService.updateById(logisticsPo);
                } else {
                    logisticsService.save(BeanCopierUtil.copy(e, LogisticsPo.class));
                }
            });
        }
        returnDataInfo.setImportFlag(true);
    }

    private String createErrExcel(List<LogisticsImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "物流时效主数据导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), LogisticsImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("LogisticsImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();
        } catch (Exception e) {
            log.error("LogisticsImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("物流时效主数据导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }

    // 导入数据中省市名称一样的情况(北京市-北京市)
    private String[] getProvinceAndCityCode(String name) {
        List<DistrictResp> data = mapLocationClient.listProvinces().getData();
        String[] res = new String[2];
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).getName().equals(name)) {
                // 省份code
                res[0] = data.get(i).getCode();
                // 城市code
                res[1] = data.get(i).getChildList().get(0).getCode();
                return res;
            }
        }
        return res;
    }
}
