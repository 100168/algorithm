package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.Enum.GenerateSerialEnum;
import com.jiduauto.sps.server.caches.DictItemCache;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.consts.StockOrderStatus;
import com.jiduauto.sps.server.consts.StockSource;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.StockItemMapper;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.StockConfigPo;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import com.jiduauto.sps.server.pojo.po.StockMoveOrderItemPo;
import com.jiduauto.sps.server.pojo.po.StockMoveOrderPo;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockMoveOrderImportReq;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockMoveOrderImportResp;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.utils.*;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @ClassName StockMoveOrderImportHandler
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/8/28 13:34
 */
@Service
@Slf4j
public class StockMoveOrderImportHandler extends BaseImportHandler<StockMoveOrderImportReq, StockMoveOrderImportResp> {
    @Autowired
    private IBosService bosService;
    @Autowired
    private DictItemCache dictItemCache;
    @Autowired
    private IMaterialService materialService;
    @Autowired
    private IWarehouseService warehouseService;
    @Autowired
    private IAreasService areasService;
    @Autowired
    private ILocationsService locationsService;
    @Autowired
    private IPalletService palletService;
    @Autowired
    private IWorkbinService workbinService;
    @Autowired
    private ICarService carService;
    @Autowired
    private ISupplierService supplierService;
    @Autowired
    private IStockConfigService stockConfigService;
    @Autowired
    private StockItemMapper stockItemMapper;
    @Autowired
    private GenerateSerialNoUtil generateSerialNoUtil;
    @Autowired
    private IStockMoveOrderService stockMoveOrderService;
    @Autowired
    private IStockMoveOrderItemService stockMoveOrderItemService;
    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST = Arrays.asList("移库日期", "备注", "零件编码", "零件种类", "车辆号", "零件状态",
        "样件状态", "库存状态", "批次", "序列号", "零件条码", "生产日期", "失效日期", "项目", "阶段", "WBS编号", "业务单号", "业务单行号", "供应商代码", "托盘号",
        "料箱号", "源仓库", "源区域", "源库位", "移库数量", "目标仓库", "目标区域", "目标库位", "目标托盘", "目标料箱", "备注");

    public List<ImportDataInfo<StockMoveOrderImportReq>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<StockMoveOrderImportReq>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, StockMoveOrderImportReq.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", ""))
                        .collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        StockMoveOrderImportReq data = (StockMoveOrderImportReq)o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {// 所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (Exception e) {
            log.error("移库单导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "移库单导入解析异常,请检查文件格式");
        }
    }

    @Override
    protected ImportReturnDataInfo<StockMoveOrderImportResp> process(List<ImportDataInfo<StockMoveOrderImportReq>> list)
        throws BizException {
        ImportReturnDataInfo<StockMoveOrderImportResp> returnDataInfo = new ImportReturnDataInfo<>();
        boolean hasError = false;
        String bizType = BizTypeThreadHolder.getBizType();
        StockConfigPo stockConfigPo2 = stockConfigService.getByBizTypeAndConfigType(bizType, 2);
        Map<String, String> sortMap = dictItemCache.getNameAndCodeMap(DictEnum.MaterialSort.getDictCode());
        Map<String, String> materialStockStatusMap =
            dictItemCache.getNameAndCodeMap(DictEnum.MaterialStockStatus.getDictCode());
        Map<String, String> stockStatusMap = dictItemCache.getNameAndCodeMap(DictEnum.StockStatus.getDictCode());
        List<String> palletList = new ArrayList<>();
        List<String> warehouseList = new ArrayList<>();
        List<String> materialList = new ArrayList<>();
        List<String> areaList = new ArrayList<>();
        List<String> locationList = new ArrayList<>();
        List<String> workbinList = new ArrayList<>();
        List<String> supplierList = new ArrayList<>();
        List<String> carList = new ArrayList<>();
        List<String> stockItemKeys = new ArrayList<>();
        List<StockMoveOrderImportResp> resultResps = new ArrayList<>();
        for (ImportDataInfo<StockMoveOrderImportReq> extendExportDto : list) {
            StockMoveOrderImportReq t = extendExportDto.getData();
            materialList.add(t.getMaterialCode());
            warehouseList.add(t.getWarehouseCode());
            areaList.add(t.getAreaCode());
            locationList.add(t.getLocationCode());
            palletList.add(t.getPalletNo());
            workbinList.add(t.getCaseNo());
            warehouseList.add(t.getTargetWarehouseCode());
            areaList.add(t.getTargetAreaCode());
            locationList.add(t.getTargetLocationCode());
            palletList.add(t.getTargetPalletCode());
            workbinList.add(t.getTargetWorkbinCode());
            supplierList.add(t.getSupplierCode());
            carList.add(t.getCarCode());
            if (StringUtils.isBlank(t.getMaterialSort())) {
                String string = sortMap.get("普通件");
                t.setMaterialSortCode(string);
            } else {
                String string = sortMap.get(t.getMaterialSort());
                t.setMaterialSortCode(string);
            }
            if (StringUtils.isBlank(t.getMaterialStatus())) {
                String string = materialStockStatusMap.get("良好");
                t.setMaterialStatusCode(Integer.valueOf(string));
            } else {
                String string = materialStockStatusMap.get(t.getMaterialStatus());
                t.setMaterialStatusCode(Integer.valueOf(string));
            }
            if (StringUtils.isBlank(t.getStockStatus())) {
                String string = stockStatusMap.get("正常");
                t.setStockStatusCode(Integer.valueOf(string));
            } else {
                String string = stockStatusMap.get(t.getStockStatus());
                t.setStockStatusCode(Integer.valueOf(string));
            }
            InAndOutStockParam param = buildInAndOutStockParam(bizType, t);
            String itemKey = StockUtils.getStockKeyByParam(stockConfigPo2.getField(), bizType, param);
            stockItemKeys.add(itemKey);
        }
        val materialPoMap = materialService.mapMaterialPo(bizType, materialList);
        val warehousePoMap = warehouseService.mapWarehousePo(bizType, warehouseList);
        val areasPoMap = areasService.mapWarehouseCodeAndAreaCodeKey(bizType, areaList);
        val locationsPoMap = locationsService.mapWarehouseCodeAreaCodeLocationKey(bizType, locationList);
        val palletPoMap = palletService.mapPalletPo(bizType, palletList);
        val workbinPoMap = workbinService.mapWorkbinPo(bizType, workbinList);
        val carPoMap = carService.mapCarPo(bizType, carList);
        val supplierPoMap = supplierService.mapSupplierPo(bizType, supplierList);

        Map<String, String> projectMap = dictItemCache.getCodeAndNameMap(DictEnum.Project.getDictCode());
        Map<String, String> stageMap = dictItemCache.getCodeAndNameMap(DictEnum.Stage.getDictCode());
        int count = 0;
        Map<String, StockMoveOrderImportReq> hashMap = new HashMap<>();
        Map<String, StockMoveOrderImportReq> check = new HashMap<>();
        Map<String, String> stockKeyMap = new HashMap<>();
        Map<String, StockItemPo> stockItemPoMap = stockItemMapper.getByBizConfigFields(stockItemKeys).stream()
            .collect(Collectors.toMap(StockItemPo::getBizConfigField, Function.identity()));
        for (ImportDataInfo<StockMoveOrderImportReq> extendExportDto : list) {
            StockMoveOrderImportReq t = extendExportDto.getData();
            StringBuilder errors = new StringBuilder();
            if (count == 0) {
                checkHead(t, errors, hasError);
                count++;
            } else {
                if (StringUtils.isNotBlank(t.getRemark()) || StringUtils.isNotBlank(t.getStockMoveDate())) {
                    checkHead(t, errors, hasError);
                    count++;
                }
            }
            t.setStockMoveNumber(String.valueOf(count));
            if (StringUtils.isBlank(t.getMaterialCode())) {
                hasError = true;
                errors.append("零件编码不能为空");
            }
            if (!warehousePoMap.containsKey(t.getWarehouseCode())) {
                hasError = true;
                errors.append("源仓库编码不能为空");
            }
//            if (!BizTypeEnum.ES.getBizType().equals(bizType) && StringUtils.isBlank(t.getAreaCode())) {
//                hasError = true;
//                errors.append("源区域编码不能为空");
//            }
//            if (!BizTypeEnum.ES.getBizType().equals(bizType) && StringUtils.isBlank(t.getLocationCode())) {
//                hasError = true;
//                errors.append("源库位编码不能为空");
//            }
            if (!warehousePoMap.containsKey(t.getTargetWarehouseCode())) {
                hasError = true;
                errors.append("目标仓库编码不能为空");
            }
//            if (!BizTypeEnum.ES.getBizType().equals(bizType) && StringUtils.isBlank(t.getTargetAreaCode())) {
//                hasError = true;
//                errors.append("目标区域编码不能为空");
//            }
//            if (!BizTypeEnum.ES.getBizType().equals(bizType) && StringUtils.isBlank(t.getTargetLocationCode())) {
//                hasError = true;
//                errors.append("目标库位编码不能为空");
//            }
            // 校验明细参数
            if (!materialPoMap.containsKey(t.getMaterialCode())) {
                hasError = true;
                errors.append("零件编码不存在");
            }
            if (!warehousePoMap.containsKey(t.getWarehouseCode())) {
                hasError = true;
                errors.append("源仓库编码不存在");
            }
            if (!warehousePoMap.containsKey(t.getTargetWarehouseCode())) {
                hasError = true;
                errors.append("目标仓库编码不存在");
            }
            if (StringUtils.isNotBlank(t.getAreaCode())
                    && !areasPoMap.containsKey(
                    t.getWarehouseCode() + t.getAreaCode())) {
                hasError = true;
                errors.append("源区域编码不存在");
            }
            if (StringUtils.isNotBlank(t.getTargetAreaCode())
                    && !areasPoMap.containsKey(
                    t.getTargetWarehouseCode() + t.getTargetAreaCode())) {
                hasError = true;
                errors.append("目标区域编码不存在");
            }
            if (StringUtils.isNotBlank(
                    t.getLocationCode()) && !locationsPoMap.containsKey(
                    t.getWarehouseCode() + t.getAreaCode() + t.getLocationCode())) {
                hasError = true;
                errors.append("源库位编码不存在");
            }
            if (StringUtils.isNotBlank(
                    t.getTargetLocationCode()) && !locationsPoMap
                    .containsKey(t.getTargetWarehouseCode() + t.getTargetAreaCode() + t.getTargetLocationCode())) {
                hasError = true;
                errors.append("目标库位编码不存在");
            }

            if (StringUtils.isNotBlank(t.getRemarkItem()) && t.getRemarkItem().length() > 50) {
                hasError = true;
                errors.append("明细备注字符长度要在50位以内");
            }
            if (StringUtils.isNotBlank(t.getSamplePartStatus()) && t.getSamplePartStatus().length() > 50) {
                hasError = true;
                errors.append("样件状态字符长度要在50位以内");
            }
            if (StringUtils.isNotBlank(t.getBatchNo()) && t.getBatchNo().length() > 20) {
                hasError = true;
                errors.append("批次号字符长度要在20位以内");
            }
            if (StringUtils.isNotBlank(t.getSequenceNo()) && t.getSequenceNo().length() > 50) {
                hasError = true;
                errors.append("序列号字符长度要在50位以内");
            }
            if (StringUtils.isNotBlank(t.getMaterialBarCode()) && t.getMaterialBarCode().length() > 50) {
                hasError = true;
                errors.append("零件条码字符长度要在50位以内");
            }
            if (StringUtils.isNotBlank(t.getWbsCode()) && t.getWbsCode().length() > 50) {
                hasError = true;
                errors.append("wbs编号字符长度要在50位以内");
            }
            if (StringUtils.isNotBlank(t.getPurchaseOrderNo()) && t.getPurchaseOrderNo().length() > 20) {
                hasError = true;
                errors.append("业务单号字符长度要在20位以内");
            }
            if (StringUtils.isNotBlank(t.getColumnProjectNo()) && t.getColumnProjectNo().length() > 20) {
                errors.append("业务单行号字符长度要在20位以内");
                hasError = true;
            }
            if (StringUtils.isNotBlank(t.getProductDate())
                    && !DateUtils.isDateFormat(t.getProductDate(), DateUtils.yyyyMMdd)) {
                errors.append("生产日期格式不正确yyyyMMdd");
                hasError = true;
            }
            if (StringUtils.isNotBlank(t.getExpireDate())
                    && !DateUtils.isDateFormat(t.getExpireDate(), DateUtils.yyyyMMdd)) {
                errors.append("失效日期格式不正确yyyyMMdd");
                hasError = true;
            }
            if (StringUtils.isNotBlank(t.getCarCode())) {
                if (!carPoMap.containsKey(t.getCarCode())) {
                    errors.append("车辆号不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getPalletNo())) {
                if (!palletPoMap.containsKey(t.getPalletNo())) {
                    errors.append("托盘号不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getCaseNo())) {
                if (!workbinPoMap.containsKey(t.getCaseNo())) {
                    errors.append("料箱号不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getSupplierCode())) {
                if (!supplierPoMap.containsKey(t.getSupplierCode())) {
                    errors.append("供应商不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getTargetPalletCode())) {
                if (!palletPoMap.containsKey(t.getTargetPalletCode())) {
                    errors.append("目标托盘不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getTargetWorkbinCode())) {
                if (!workbinPoMap.containsKey(t.getTargetWorkbinCode())) {
                    errors.append("目标料箱不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getMaterialSort())) {
                if (!sortMap.containsKey(t.getMaterialSort())) {
                    errors.append("零件种类不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getMaterialStatus())) {
                if (!materialStockStatusMap.containsKey(t.getMaterialStatus())) {
                    errors.append("零件装态不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getStockStatus())) {
                if (!stockStatusMap.containsKey(t.getStockStatus())) {
                    errors.append("库存状态不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getProjectCode())) {
                if (!projectMap.containsKey(t.getProjectCode())) {
                    errors.append("项目不存在");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(t.getStageCode())) {
                if (!stageMap.containsKey(t.getStageCode())) {
                    errors.append("阶段不存在");
                    hasError = true;
                }
            }
            // 校验重复性
//            String objectString =
//                    commonService.getObjectString(t, ColumnNameArrayEnum.STOCK_MOVE_ORDER_IMPORT_COLUMN.getCode());
//            if (hashMap.containsKey(objectString)) {
//                errors.append("同一移库单下该物料(").append(t.getMaterialCode()).append(")重复");
//                hasError = true;
//            }
//            {
//                hashMap.put(objectString, t);
//            }
            // 所填库存维度存不存在校验
            InAndOutStockParam param = buildInAndOutStockParam(bizType, t);
            String itemKey = StockUtils.getStockKeyByParam(stockConfigPo2.getField(), bizType, param);
            if (stockItemPoMap.containsKey(itemKey)) {
                t.setStockItemId(stockItemPoMap.get(itemKey).getId());
                t.setOriginalStockSum(stockItemPoMap.get(itemKey).getSumQuantity());
            } else {
                errors.append("未查询到库存记录");
                hasError = true;
            }
            // 同一单下是否绑定到同一库存明细校验
//            if (check.containsKey(t.getStockMoveNumber() + t.getStockItemId())) {
//                StockMoveOrderImportReq stockMoveOrderImportReq =
//                    check.get(t.getStockMoveNumber() + t.getStockItemId());
//                hasError = true;
//                errors.append("同一订单下物料(").append(stockMoveOrderImportReq.getMaterialCode()).append(")与该物料(")
//                    .append(t.getMaterialCode()).append(")匹配到同一库存明细请检查");
//            } else {
//                check.put(t.getStockMoveNumber() + t.getStockItemId(), t);
//            }
            if(stockKeyMap.containsKey(itemKey)){
                hasError = true;
                errors.append("同一移库单下该物料(").append(t.getMaterialCode()).append(")重复");
            }else{
                stockKeyMap.put(itemKey,itemKey);
            }
            StockMoveOrderImportResp stockMoveOrderImportResp = BeanCopierUtil.copy(t, StockMoveOrderImportResp.class);
            stockMoveOrderImportResp.setErrorInfo(String.valueOf(errors));
            resultResps.add(stockMoveOrderImportResp);
        }
        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }


    private InAndOutStockParam buildInAndOutStockParam(String bizType, StockMoveOrderImportReq t) {
        InAndOutStockParam request = new InAndOutStockParam();
        request.setBizType(bizType);
        request.setMaterialCode(t.getMaterialCode());
        request.setMaterialSort(t.getMaterialSortCode());
        request.setCarCode(t.getCarCode());
        request.setMaterialStatus(t.getMaterialStatusCode());
        request.setSamplePartStatus(t.getSamplePartStatus());
        request.setStockStatus(t.getStockStatusCode());
        request.setBatchNo(t.getBatchNo());
        request.setSequenceNo(t.getSequenceNo());
        request.setMaterialBarCode(t.getMaterialBarCode());
        request.setProductDate(t.getProductDate());
        request.setExpireDate(t.getExpireDate());
        request.setProjectCode(t.getProjectCode());
        request.setStageCode(t.getStageCode());
        request.setWbsCode(t.getWbsCode());
        request.setPurchaseOrderNo(t.getPurchaseOrderNo());
        request.setColumnProjectNo(t.getColumnProjectNo());
        request.setSupplierCode(t.getSupplierCode());
        request.setPalletNo(t.getPalletNo());
        request.setCaseNo(t.getCaseNo());
        request.setWarehouseCode(t.getWarehouseCode());
        request.setAreaCode(t.getAreaCode());
        request.setLocationCode(t.getLocationCode());
        request.setRemark(t.getRemarkItem());
        log.info("StockMoveOrderBatchPreCheck#buildInAndOutStockParam#param : {}", JsonUtil.toJsonString(request));
        return request;
    }

    private  void checkHead(StockMoveOrderImportReq t, StringBuilder errors, Boolean hasError) {
        if (StringUtils.isBlank(t.getStockMoveDate())) {
            hasError = true;
            errors.append("移库日期不能为空");
        } else {
            if (!DateUtils.isDateFormat(t.getStockMoveDate(), DateUtils.yyyyMMdd)) {
                hasError = true;
                errors.append("移库日期格式不正确yyyyMMdd");
            }
        }
        if (StringUtils.isNotBlank(t.getRemark()) && t.getRemark().length() > 50) {
            hasError = true;
            errors.append("表单备注字符长度要在50位以内");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    protected void afterProcess(ImportReturnDataInfo<StockMoveOrderImportResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        } else {
            String bizType = BizTypeThreadHolder.getBizType();
            List<StockMoveOrderPo> stockMoveOrderPos = new ArrayList<>();
            List<StockMoveOrderItemPo> stockMoveOrderItemPos = new ArrayList<>();
            String orderNum = null;
            for (StockMoveOrderImportResp dto : returnDataInfo.getData()) {

                StockMoveOrderImportReq t = BeanCopierUtil.copy(dto,StockMoveOrderImportReq.class);
                if (StringUtils.isNotBlank(t.getStockMoveDate())){
                    orderNum = generateSerialNoUtil.generateOrderNoPreBiz(GenerateSerialEnum.MS, bizType);
                    StockMoveOrderPo stockMoveOrderPo = new StockMoveOrderPo();
                    stockMoveOrderPo.setBizType(bizType);
                    stockMoveOrderPo.setStockMoveNumber(orderNum);
                    stockMoveOrderPo.setStockSource(StockSource.SYS.getCode());
                    stockMoveOrderPo.setStatus(StockOrderStatus.putIn.getCode());
                    stockMoveOrderPo.setRemark(t.getRemark());
                    stockMoveOrderPo.setStockMoveDate(
                            Objects.requireNonNull(DateUtils.parse(t.getStockMoveDate(), DateUtils.SHORT_DATE_FORMAT)).toLocalDate());
                    StockMoveOrderItemPo stockMoveOrderItemPo = getStockMoveOrderItemPo(bizType, orderNum, t);
                    stockMoveOrderPos.add(stockMoveOrderPo);
                    stockMoveOrderItemPos.add(stockMoveOrderItemPo);
                }else {
                    StockMoveOrderItemPo stockMoveOrderItemPo = getStockMoveOrderItemPo(bizType, orderNum, t);
                    stockMoveOrderItemPos.add(stockMoveOrderItemPo);
                }
            }
            stockMoveOrderService.saveBatch(stockMoveOrderPos);
            stockMoveOrderItemService.saveBatch(stockMoveOrderItemPos);
        }
        returnDataInfo.setImportFlag(true);
    }

    private  StockMoveOrderItemPo getStockMoveOrderItemPo(String bizType, String no, StockMoveOrderImportReq t) {
        StockMoveOrderItemPo stockMoveOrderItemPo = new StockMoveOrderItemPo();
        stockMoveOrderItemPo.setBizType(bizType);
        stockMoveOrderItemPo.setStockMoveNumber(no);
        stockMoveOrderItemPo.setMoveSumQuantity(t.getMoveSumQuantity());
        stockMoveOrderItemPo.setTargetWarehouseCode(t.getTargetWarehouseCode());
        stockMoveOrderItemPo.setTargetAreaCode(t.getTargetAreaCode());
        stockMoveOrderItemPo.setTargetLocation(t.getTargetLocationCode());
        stockMoveOrderItemPo.setTargetPalletCode(t.getTargetPalletCode());
        stockMoveOrderItemPo.setTargetWorkbinCode(t.getTargetWorkbinCode());
        stockMoveOrderItemPo.setStockItemId(t.getStockItemId());
        stockMoveOrderItemPo.setRemark(t.getRemarkItem());
        stockMoveOrderItemPo.setOriginalStockSum(t.getOriginalStockSum());
        return stockMoveOrderItemPo;
    }
    private String createErrExcel(List<StockMoveOrderImportResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            // 创建临时文件
            excelFile =
                File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "移库单导入失败文件",
                    BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel.write(excelFile.getAbsoluteFile(), StockMoveOrderImportResp.class)
                .registerConverter(new LongStringConverter()).build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("StockMoveOrderImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("StockMoveOrderImportHandler-createErrExcel-putLowsObjInputStream-error:{}",
                ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("移库单导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }
}
