package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.ChannelStockChannelType;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.*;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockChannelUpdateOrderItemImportResp;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockChannelUpdateOrderItemImportResultResp;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class StockChannelUpdateOrderItemImportHandler extends BaseImportHandler<StockChannelUpdateOrderItemImportResp, StockChannelUpdateOrderItemImportResultResp> {

    @Autowired
    private WarehouseMapper warehouseMapper;
    @Resource
    private StockMapper stockMapper;


    @Autowired
    private IBosService bosService;
    @Autowired
    private ICommonService commonService;

    @Resource
    private IStockConfigService stockConfigService;

    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("*零件编码","*调整数量","*源库存渠道","*目标库存渠道","*库存状态","*零件状态","*仓库代码");

    @Resource
    private IMaterialService materialService;

    public List<ImportDataInfo<StockChannelUpdateOrderItemImportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<StockChannelUpdateOrderItemImportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, StockChannelUpdateOrderItemImportResp.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        StockChannelUpdateOrderItemImportResp data = (StockChannelUpdateOrderItemImportResp) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (Exception e) {
            log.error("库存属性调整单明细导入导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "库存属性调整单明细导入导入解析异常,请检查文件格式");
        }
    }
    /**
     * 校验文件
     *
     * @param list
     * @return
     * @throws BizException
     */
    @Override
    protected ImportReturnDataInfo<StockChannelUpdateOrderItemImportResultResp> process(List<ImportDataInfo<StockChannelUpdateOrderItemImportResp>> list) throws BizException {
        ImportReturnDataInfo<StockChannelUpdateOrderItemImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        List<String> materialNumbers = new ArrayList<>();
        log.info("渠道库存属性调整单明细导入:" + JSON.toJSONString(list));
        boolean hasError = false;
        String bizType = BizTypeThreadHolder.getBizType();
        Set<String> warehouseCodes = new HashSet<>();

        Map<String, String> checkMap = new HashMap<>();
        StockConfigPo stockConfigPo = stockConfigService.getByBizTypeAndConfigType(bizType, 1);
        List<String> stockItemKeys = new ArrayList<>();
        Map<Integer, String> keyIndexMap = new HashMap<>();
        Integer index = 0;
        List<StockChannelUpdateOrderItemImportResultResp> resultResps = new ArrayList<>();
        for (ImportDataInfo<StockChannelUpdateOrderItemImportResp> dataInfo : list) {
            StockChannelUpdateOrderItemImportResp resp = dataInfo.getData();
            StockChannelUpdateOrderItemImportResultResp resultResp = new StockChannelUpdateOrderItemImportResultResp();
            BeanUtils.copyProperties(resp, resultResp);
            StringBuilder sb = new StringBuilder();
            warehouseCodes.add(resp.getWarehouseCode());

            InAndOutStockParam param = convertStockParam(resultResp);
            String itemKey = StockUtils.getStockKeyByParam(stockConfigPo.getField(), bizType, param);
            stockItemKeys.add(itemKey);
            keyIndexMap.put(index++,itemKey);

            String objectString = commonService.getObjectString(resp, new String[]{});
            if (checkMap.containsKey(objectString)) {
                sb.append("该单下该零件物料(" + resp.getMaterialNumber() + ")存在数量外其他字段一样的重复物料;");
                hasError = true;
            } else {
                checkMap.put(objectString, objectString);
            }


            materialNumbers.add(resp.getMaterialNumber());
            if (StringUtils.isEmpty(resp.getMaterialNumber())) {
                sb.append("零件编码不可以为空;");
                hasError = true;
            }

            if (StringUtils.isNotBlank(resp.getTargetChannelCode())) {
                if (StringUtils.isBlank(commonService.getDictItemCode(DictEnum.STOCK_CHANNEL_CODE, resp.getTargetChannelCode()))) {
                    sb.append("目标库存渠道和数据字典不匹配;");
                    hasError = true;
                }
            }else{
                sb.append("目标库存渠道不可以为空;");
                hasError = true;
            }

            if (StringUtils.isNotBlank(resp.getChannelCode())) {
                if (StringUtils.isBlank(commonService.getDictItemCode(DictEnum.STOCK_CHANNEL_CODE, resp.getChannelCode()))) {
                    sb.append("源库存渠道和数据字典不匹配;");
                    hasError = true;
                }
            }else{
                sb.append("源库存渠道不可以为空;");
                hasError = true;
            }


            if (StringUtils.isEmpty(resp.getWarehouseCode())) {
                sb.append("仓库代码不可以为空;");
                hasError = true;
            }
            if (StringUtils.isEmpty(resp.getMaterialStatus())) {
                sb.append("零件状态不可以为空;");
                hasError = true;
            }

            if (StringUtils.isEmpty(resp.getStockStatus())) {
                sb.append("库存状态不可以为空;");
                hasError = true;
            }



            if (StringUtils.isEmpty(resp.getUpdateSumQuantity())) {
                sb.append("调整数量不可以为空;");
                hasError = true;
            } else {
                if (!NumberUtil.isNumeric(resp.getUpdateSumQuantity())) {
                    sb.append("调整数量必须是数字;");
                    hasError = true;
                }else if(new BigDecimal(resp.getUpdateSumQuantity()).compareTo(BigDecimal.ZERO) < 0) {
                    sb.append("调整数量必须大于0;");
                    hasError = true;
                }else if(!NumberUtil.isMaxThreeDecimalNumber(resp.getUpdateSumQuantity())){
                    sb.append("调整数量最多三位小数;");
                    hasError = true;

                }
            }
            resultResp.setErrorInfo(sb.toString());
            resultResps.add(resultResp);
        }

        Map<String, StockPo> stockItemPoMap = stockMapper.getByBizConfigFields(stockItemKeys).stream()
                .collect(Collectors.toMap(StockPo::getBizConfigField, Function.identity()));

        List<String> warehousePo = new ArrayList<>();
        if (!CollectionUtils.isEmpty(warehouseCodes)) {
            warehousePo = warehouseMapper.getByWCodes(bizType, new ArrayList<>(warehouseCodes));
        }

        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(bizType, materialNumbers);

        for (StockChannelUpdateOrderItemImportResultResp resultResp : resultResps) {
            StringBuilder sb = new StringBuilder(resultResp.getErrorInfo());

            InAndOutStockParam param = convertStockParam(resultResp);
            String itemKey = StockUtils.getStockKeyByParam(stockConfigPo.getField(), bizType, param);
            StockPo po = stockItemPoMap.get(itemKey);
            log.info("##############"+JSON.toJSONString(param)+"##############"+JSON.toJSONString(po));
            BigDecimal updateQuantity = new BigDecimal(resultResp.getUpdateSumQuantity());
            if(po == null || po.getSumQuantity().subtract(po.getOccupyQuantity()).compareTo(updateQuantity) < 0){
                sb.append("库存不足;");
                hasError = true;
            }else{
                resultResp.setStockId(po.getId().toString());
                resultResp.setAvailableSum(po.getSumQuantity().subtract(Objects.isNull(po.getOccupyQuantity()) ? new BigDecimal(0)
                        : po.getOccupyQuantity()));

            }

            if (resultResp.getMaterialNumber() != null && !materialPoMap.containsKey(resultResp.getMaterialNumber())) {
                sb.append("该零件编码不存在;");
                hasError = true;
            }else{
                MaterialPo materialPo = materialPoMap.get(resultResp.getMaterialNumber());
                if(materialPo != null){
                    resultResp.setMaterialName(materialPo.getMaterialName());
                }
            }
            if (resultResp.getWarehouseCode() != null && !warehousePo.contains(resultResp.getWarehouseCode())) {
                sb.append("该仓库不存在;");
                hasError = true;
            }

            resultResp.setErrorInfo(sb.toString());
        }

        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            for (StockChannelUpdateOrderItemImportResultResp resultResp : resultResps) {
                resultResp.setTargetChannelCode(commonService.getDictItemCode(DictEnum.STOCK_CHANNEL_CODE,resultResp.getTargetChannelCode()));
            }

            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    /**
     * 返回结果
     *
     * @param returnDataInfo
     * @throws BizException
     */
    @Override
    protected void afterProcess(ImportReturnDataInfo<StockChannelUpdateOrderItemImportResultResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
        }else{
            returnDataInfo.setImportFlag(true);
        }
    }

    private String createErrExcel(List<StockChannelUpdateOrderItemImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "渠道库存属性调整导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), StockChannelUpdateOrderItemImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("StockUpdateOrderItemImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("StockUpdateOrderItemImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("渠道库存属性调整单明细导入导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }


    private InAndOutStockParam convertStockParam(StockChannelUpdateOrderItemImportResultResp resp){
        InAndOutStockParam stockParam = BeanCopierUtil.copy(resp, InAndOutStockParam.class);
        stockParam.setMaterialCode(resp.getMaterialNumber());
        if(StringUtils.isNotBlank(resp.getMaterialStatus())){
            stockParam.setMaterialStatus(Integer.valueOf(commonService.getDictItemCode(DictEnum.MaterialStockStatus,resp.getMaterialStatus())));
        }
        if(StringUtils.isNotBlank(resp.getStockStatus())){
            stockParam.setStockStatus(Integer.valueOf(commonService.getDictItemCode(DictEnum.StockStatus,resp.getStockStatus())));
        }
        if(StringUtils.isNotBlank(resp.getChannelCode())){
            if(resp.getChannelCode().equals(ChannelStockChannelType.defaultChannel)){
                stockParam.setChannelCode("");
            }else{
                stockParam.setChannelCode(commonService.getDictItemCode(DictEnum.STOCK_CHANNEL_CODE,resp.getChannelCode()));
            }
        }

        return stockParam;
    }
}
