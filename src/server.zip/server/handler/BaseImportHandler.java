package com.jiduauto.sps.server.handler;

import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.excel.ExcelThreadLocalHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.fileImport.*;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.Serializable;
import java.util.List;

/**
 * @author yu.wang
 * @date 2022/05/30
 * @description 导入处理器
 */
@Slf4j
public abstract class BaseImportHandler<E, R extends Serializable>{

    private final ThreadLocal<Object> threadLocal = new ThreadLocal<>();

    public ThreadLocal getThreadLocal(){
        return threadLocal;
    }


    /**
     * 文件数据源的任务处理
     * @param importParamReq
     * @return
     * @throws BizException
     */
    public ImportReturnDataInfo<R> doTask(ImportParamDto importParamReq) throws BizException {
        log.info("文件导入路径:{}", importParamReq.getFileUrl());
        try{
            threadLocal.set(importParamReq.getParam());
            BizTypeThreadHolder.setBizThreadLocal(importParamReq.getBizType());
            List<ImportDataInfo<E>> dataList;
            if(!StringUtils.isEmpty(importParamReq.getFileUrl())){
                dataList = readFileByUrl(importParamReq.getFileUrl());
            }else if(!StringUtils.isEmpty(importParamReq.getFile())){
                dataList = readFile(importParamReq.getFile());
            }else{
                throw new BizException("文件为空");
            }

            if (CollectionUtils.isEmpty(dataList)) {
                throw new BizException("文件内容为空, 请检查");
            }
            ImportReturnDataInfo<R> returnDataInfo = process(dataList);
            returnDataInfo.setCreateUser(UserUtil.getUserName());
            returnDataInfo.setBizType(importParamReq.getBizType());
            afterProcess(returnDataInfo);
            return returnDataInfo;
        }finally {
            release();
        }
    }

    /**
     * 从文件中读取数据并转换，入参：url地址
     * @param fileUrl
     * @return
     * @throws BizException
     */
    public List<ImportDataInfo<E>> readFileByUrl(String fileUrl) throws BizException{
        throw new BizException("readFileByUrl err");
    }

    /**
     * 从文件中读取数据并转换，入参：文件对象
     * @param file
     * @return
     * @throws BizException
     */
    public List<ImportDataInfo<E>> readFile(MultipartFile file) throws BizException{
        throw new BizException("readFile err");
    }

    /**
     * 校验文件
     * @param list
     * @return
     * @throws BizException
     */
    protected abstract ImportReturnDataInfo<R> process(List<ImportDataInfo<E>> list) throws BizException;

    /**
     * 返回结果
     * @param returnDataInfo
     * @throws BizException
     */
    protected abstract void afterProcess(ImportReturnDataInfo<R> returnDataInfo) throws BizException;

    /**
     * 资源释放
     */
    public void release(){
        threadLocal.remove();
        BizTypeThreadHolder.remove();
        ExcelThreadLocalHolder.remove();
    }


}
