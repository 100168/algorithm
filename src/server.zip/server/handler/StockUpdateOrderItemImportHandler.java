package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.Enum.ColumnNameArrayEnum;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.*;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.*;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.stock.*;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockUpdateOrderItemImportResp;
import com.jiduauto.sps.server.service.*;
import com.jiduauto.sps.server.service.impl.MaterialServiceImpl;
import com.jiduauto.sps.server.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class StockUpdateOrderItemImportHandler  extends BaseImportHandler<StockUpdateOrderItemImportResp, StockUpdateOrderItemImportResultResp> {
    @Autowired
    private MaterialMapper materialMapper;
    @Autowired
    private WarehouseMapper warehouseMapper;
    @Autowired
    private IAreasService areasService;
    @Autowired
    private ILocationsService locationsService;
    @Autowired
    private SupplierMapper supplierMapper;
    @Autowired
    private PalletMapper palletMapper;
    @Autowired
    private WorkbinMapper workbinMapper;
    @Autowired
    private CarMapper carMapper;

    @Autowired
    private IBosService bosService;
    @Autowired
    private ICommonService commonService;

    @Resource
    private StockItemMapper stockItemMapper;
    @Resource
    private IStockConfigService stockConfigService;

    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("零件编码","调整数量","源零件状态","目标零件状态","源库存状态","目标库存状态","仓库代码","区域代码","库位代码","源序列号","目标序列号","源样件状态","目标样件状态","源零件种类","目标零件种类","源车辆号","目标车辆号","源批次","目标批次","源项目","目标项目","源阶段","目标阶段","源入库日期","目标入库日期","零件条码","生产日期","失效日期","供应商代码","WBS编号","业务单号","业务单行号","托盘号","料箱号","备注");

    @Resource
    private IMaterialService materialService;

    public List<ImportDataInfo<StockUpdateOrderItemImportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<StockUpdateOrderItemImportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, StockUpdateOrderItemImportResp.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        StockUpdateOrderItemImportResp data = (StockUpdateOrderItemImportResp) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (Exception e) {
            log.error("库存属性调整单明细导入导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "库存属性调整单明细导入导入解析异常,请检查文件格式");
        }
    }
    /**
     * 校验文件
     *
     * @param list
     * @return
     * @throws BizException
     */
    @Override
    protected ImportReturnDataInfo<StockUpdateOrderItemImportResultResp> process(List<ImportDataInfo<StockUpdateOrderItemImportResp>> list) throws BizException {
        ImportReturnDataInfo<StockUpdateOrderItemImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        List<String> materialNumbers = new ArrayList<>();
        log.info("库存属性调整单明细导入:" + JSON.toJSONString(list));
        boolean hasError = false;
        String bizType = BizTypeThreadHolder.getBizType();
        Set<String> warehouseCodes = new HashSet<>();
        Set<String> supplierCodes = new HashSet<>();
        Set<String> areaCodes = new HashSet<>();
        Set<String> locationCodes = new HashSet<>();
        Set<String> palletCodes = new HashSet<>();
        Set<String> workbinCodes = new HashSet<>();
        Set<String> carCodes = new HashSet<>();
        Set<String> targetCarCodes = new HashSet<>();


        Map<String, String> checkMap = new HashMap<>();
        StockConfigPo stockConfigPo2 = stockConfigService.getByBizTypeAndConfigType(bizType, 2);
        List<String> stockItemKeys = new ArrayList<>();
        Map<Integer, String> keyIndexMap = new HashMap<>();
        Integer index = 0;
        List<StockUpdateOrderItemImportResultResp> resultResps = new ArrayList<>();
        for (ImportDataInfo<StockUpdateOrderItemImportResp> dataInfo : list) {
            StockUpdateOrderItemImportResp resp = dataInfo.getData();
            StockUpdateOrderItemImportResultResp resultResp = new StockUpdateOrderItemImportResultResp();
            BeanUtils.copyProperties(resp, resultResp);
            StringBuilder sb = new StringBuilder();
            warehouseCodes.add(resp.getWarehouseCode());
            areaCodes.add(resp.getAreaCode());
            locationCodes.add(resp.getLocationCode());
            targetCarCodes.add(resp.getTargetCarCode());
            supplierCodes.add(resp.getSupplierCode());

            InAndOutStockParam param = convertStockParam(resultResp);
            String itemKey = StockUtils.getStockKeyByParam(stockConfigPo2.getField(), bizType, param);
            stockItemKeys.add(itemKey);
            keyIndexMap.put(index++,itemKey);

            String objectString = commonService.getObjectString(resp, ColumnNameArrayEnum.STOCK_UPDATE_ORDER_ITEM_IMPORT_COLUMN.getCode());
            if (checkMap.containsKey(objectString)) {
                sb.append("该单下该零件物料(" + resp.getMaterialNumber() + ")存在除备注,数量外其他字段一样的重复物料;");
                hasError = true;
            } else {
                checkMap.put(objectString, objectString);
            }

            String sourceStr = resp.getMaterialStatus()+resp.getStockStatus()+resp.getSequenceNo()+resp.getSamplePartStatus()+resp.getMaterialSort()+resp.getCarCode()+resp.getBatchNo()+resp.getProjectCode()+resp.getStageCode()+resp.getAddDate();
            StringBuilder targetStr = new StringBuilder();
            if(StringUtils.isBlank(resp.getTargetMaterialStatus())){
                targetStr.append(resp.getMaterialStatus());
            }else{
                targetStr.append(resp.getTargetMaterialStatus());
            }

            if(StringUtils.isBlank(resp.getTargetStockStatus())){
                targetStr.append(resp.getStockStatus());
            }else{
                targetStr.append(resp.getTargetStockStatus());
            }

            if(StringUtils.isBlank(resp.getTargetSequenceNo())){
                targetStr.append(resp.getSequenceNo());
            }else{
                targetStr.append(resp.getTargetSequenceNo());
            }

            if(StringUtils.isBlank(resp.getTargetSamplePartStatus())){
                targetStr.append(resp.getSamplePartStatus());
            }else{
                targetStr.append(resp.getTargetSamplePartStatus());
            }

            if(StringUtils.isBlank(resp.getTargetMaterialSort())){
                targetStr.append(resp.getMaterialSort());
            }else{
                targetStr.append(resp.getTargetMaterialSort());
            }

            if(StringUtils.isBlank(resp.getTargetCarCode())){
                targetStr.append(resp.getCarCode());
            }else{
                targetStr.append(resp.getTargetCarCode());
            }

            if(StringUtils.isBlank(resp.getTargetBatchNo())){
                targetStr.append(resp.getBatchNo());
            }else{
                targetStr.append(resp.getTargetBatchNo());
            }

            if(StringUtils.isBlank(resp.getTargetProjectCode())){
                targetStr.append(resp.getProjectCode());
            }else{
                targetStr.append(resp.getTargetProjectCode());
            }

            if(StringUtils.isBlank(resp.getTargetStageCode())){
                targetStr.append(resp.getStageCode());
            }else{
                targetStr.append(resp.getTargetStageCode());
            }

            if(StringUtils.isBlank(resp.getTargetAddDate())){
                targetStr.append(resp.getAddDate());
            }else{
                targetStr.append(resp.getTargetAddDate());
            }
            if(sourceStr.equals(targetStr.toString())){
                sb.append("目标属性未做改动;");
                hasError = true;
            }
            if(StringUtils.gtMaxLength(resp.getSequenceNo(), 50)){
                sb.append("源序列号最大长度为50;");
                hasError = true;
            }
            if(StringUtils.gtMaxLength(resp.getTargetSequenceNo(), 50)){
                sb.append("目标序列号最大长度为50;");
                hasError = true;
            }
            if(StringUtils.gtMaxLength(resp.getSamplePartStatus(), 50)){
                sb.append("源样件状态最大长度为50;");
                hasError = true;
            }
            if(StringUtils.gtMaxLength(resp.getTargetSamplePartStatus(), 50)){
                sb.append("目标样件状态最大长度为50;");
                hasError = true;
            }
            if(StringUtils.gtMaxLength(resp.getBatchNo(), 20)){
                sb.append("源批次号最大长度为20;");
                hasError = true;
            }
            if(StringUtils.gtMaxLength(resp.getTargetBatchNo(), 20)){
                sb.append("目标批次号最大长度为20;");
                hasError = true;
            }
            if(StringUtils.gtMaxLength(resp.getMaterialBarCode(), 50)){
                sb.append("零件条码最大长度为50;");
                hasError = true;
            }
            if(StringUtils.gtMaxLength(resp.getWbsCode(), 50)){
                sb.append("WBS编码最大长度为50;");
                hasError = true;
            }

            if(StringUtils.gtMaxLength(resp.getPurchaseOrderNo(), 20)){
                sb.append("业务单号最大长度为20;");
                hasError = true;
            }

            if(StringUtils.gtMaxLength(resp.getColumnProjectNo(), 20)){
                sb.append("业务单行号最大长度为20;");
                hasError = true;
            }
            if(StringUtils.gtMaxLength(resp.getRemark(), 100)){
                sb.append("备注最大长度为100;");
                hasError = true;
            }
            if(!DateUtils.checkFormat(resp.getAddDate(), DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT)){
                sb.append("源入库日期填写格式错误;");
                hasError = true;
            }
            if(!DateUtils.checkFormat(resp.getTargetAddDate(), DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT)){
                sb.append("目标入库日期填写格式错误;");
                hasError = true;
            }
            if(!DateUtils.checkFormat(resp.getProductDate(), DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT)){
                sb.append("生产日期填写格式错误;");
                hasError = true;
            }
            if(!DateUtils.checkFormat(resp.getExpireDate(), DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT)){
                sb.append("失效日期填写格式错误;");
                hasError = true;
            }
            if (StringUtils.isNotBlank(resp.getPalletNo())) {
                palletCodes.add(resp.getPalletNo());

            }
            if (StringUtils.isNotBlank(resp.getCaseNo())) {
                workbinCodes.add(resp.getCaseNo());

            }
            if (StringUtils.isNotBlank(resp.getCarCode())) {
                carCodes.add(resp.getCarCode());

            }


            if (StringUtils.isNotBlank(resp.getSupplierCode())) {
                supplierCodes.add(resp.getSupplierCode());
            }

            if (StringUtils.isNotBlank(resp.getAreaCode())) {
                areaCodes.add(resp.getAreaCode());
            }

            if (StringUtils.isNotBlank(resp.getLocationCode())) {
                locationCodes.add(resp.getLocationCode());
            }

            if (StringUtils.isNotBlank(resp.getTargetCarCode())) {
                targetCarCodes.add(resp.getTargetCarCode());
            }


            materialNumbers.add(resp.getMaterialNumber());
            if (StringUtils.isEmpty(resp.getMaterialNumber())) {
                sb.append("零件编码不可以为空;");
                hasError = true;
            }

            if (StringUtils.isNotBlank(resp.getProjectCode())) {
                if (StringUtils.isBlank(commonService.getDictItemDesc(DictEnum.Project, resp.getProjectCode()))) {
                    sb.append("项目和数据字典不匹配;");
                    hasError = true;
                }
            } if (StringUtils.isNotBlank(resp.getTargetProjectCode())) {
                if (StringUtils.isBlank(commonService.getDictItemDesc(DictEnum.Project, resp.getTargetProjectCode()))) {
                    sb.append("项目和数据字典不匹配;");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(resp.getStageCode())) {
                if (StringUtils.isBlank(commonService.getDictItemDesc(DictEnum.Stage, resp.getStageCode()))) {
                    sb.append("目标阶段和数据字典不匹配;");
                    hasError = true;
                }
            }
            if (StringUtils.isNotBlank(resp.getTargetStageCode())) {
                if (StringUtils.isBlank(commonService.getDictItemDesc(DictEnum.Stage, resp.getTargetStageCode()))) {
                    sb.append("目标阶段和数据字典不匹配;");
                    hasError = true;
                }
            }

            if (StringUtils.isEmpty(resp.getWarehouseCode())) {
                sb.append("仓库代码不可以为空;");
                hasError = true;
            }



            if (StringUtils.isEmpty(resp.getUpdateSumQuantity())) {
                sb.append("出库数量不可以为空;");
                hasError = true;
            } else {
                if (!NumberUtil.isNumeric(resp.getUpdateSumQuantity())) {
                    sb.append("出库数量必须是数字;");
                    hasError = true;
                }else if(new BigDecimal(resp.getUpdateSumQuantity()).compareTo(BigDecimal.ZERO) < 0) {
                    sb.append("出库数量必须大于0;");
                    hasError = true;
                }else if(!NumberUtil.isMaxThreeDecimalNumber(resp.getUpdateSumQuantity())){
                    sb.append("出库数量最多三位小数;");
                    hasError = true;

                }
            }
            resultResp.setErrorInfo(sb.toString());
            resultResps.add(resultResp);
        }

        Map<String, StockItemPo> stockItemPoMap = stockItemMapper.getByBizConfigFields(stockItemKeys).stream()
                .collect(Collectors.toMap(StockItemPo::getBizConfigField, Function.identity()));

        List<String> warehousePo = new ArrayList<>();
        List<String> supplierPos = new ArrayList<>();
        Map<String, AreasPo> areasPos = new HashMap<>();
        Map<String, LocationsPo> locationsPos = new HashMap<>();
        List<String> carPos = new ArrayList<>();
        List<String> targetCarPos = new ArrayList<>();
        List<String> workbinPos = new ArrayList<>();
        List<String> palletPos = new ArrayList<>();
        if (!CollectionUtils.isEmpty(warehouseCodes)) {
            warehousePo = warehouseMapper.getByWCodes(bizType, new ArrayList<>(warehouseCodes));
        }
        if (!CollectionUtils.isEmpty(supplierCodes)) {
            supplierPos = supplierMapper.getDistinctByBizAndCodes(bizType, new ArrayList<>(supplierCodes));
        }
        if (!CollectionUtils.isEmpty(areaCodes)) {
            areasPos = areasService.mapWarehouseCodeAndAreaCodeKey(bizType,new ArrayList<>(areaCodes));
        }
        if (!CollectionUtils.isEmpty(locationCodes)) {
            locationsPos = locationsService.mapWarehouseCodeAreaCodeLocationKey(bizType, new ArrayList<>(locationCodes));
        }
        if (!CollectionUtils.isEmpty(carCodes)) {
            carPos = carMapper.getByWPCodes(bizType, new ArrayList<>(carCodes));
        }

        if (!CollectionUtils.isEmpty(targetCarCodes)) {
            targetCarPos = carMapper.getByWPCodes(bizType, new ArrayList<>(targetCarCodes));
        }

        if (!CollectionUtils.isEmpty(workbinCodes)) {
            workbinPos = workbinMapper.getByWPCodes(bizType, new ArrayList<>(workbinCodes));
        }
        if (!CollectionUtils.isEmpty(palletCodes)) {
            palletPos = palletMapper.getByWPCodes(bizType, new ArrayList<>(palletCodes));
        }
        Map<String, MaterialPo> materialPoMap = materialService.mapMaterialPo(bizType, materialNumbers);

        for (StockUpdateOrderItemImportResultResp resultResp : resultResps) {
            StringBuilder sb = new StringBuilder(resultResp.getErrorInfo());

            InAndOutStockParam param = convertStockParam(resultResp);
            String itemKey = StockUtils.getStockKeyByParam(stockConfigPo2.getField(), bizType, param);
            StockItemPo po = stockItemPoMap.get(itemKey);
            if(po == null || po.getSumQuantity().compareTo(BigDecimal.ZERO) <= 0){
                sb.append("库存不足;");
                hasError = true;
            }else{
                resultResp.setStockId(po.getId().toString());
                resultResp.setStockItemQuantity(po.getSumQuantity());
            }

            if (resultResp.getMaterialNumber() != null && !materialPoMap.containsKey(resultResp.getMaterialNumber())) {
                sb.append("该零件编码不存在;");
                hasError = true;
            }else{
                MaterialPo materialPo = materialPoMap.get(resultResp.getMaterialNumber());
                if(materialPo != null){
                    resultResp.setMaterialName(materialPo.getMaterialName());
                }
            }
            if (resultResp.getWarehouseCode() != null && !warehousePo.contains(resultResp.getWarehouseCode())) {
                sb.append("该仓库不存在;");
                hasError = true;
            }
            if (resultResp.getSupplierCode() != null && !supplierPos.contains(resultResp.getSupplierCode())) {
                sb.append("该供应商编码不存在;");
                hasError = true;
            }
            if (resultResp.getAreaCode() != null && !areasPos.containsKey(resultResp.getWarehouseCode() + resultResp.getAreaCode())) {
                sb.append("该区域不存在;");
                hasError = true;
            }
            if (resultResp.getCarCode() != null && !carPos.contains(resultResp.getCarCode())) {
                sb.append("该车辆编码不存在;");
                hasError = true;
            }
            if (resultResp.getTargetCarCode() != null && !targetCarPos.contains(resultResp.getTargetCarCode())) {
                sb.append("该目标车辆编码不存在;");
                hasError = true;
            }
            if (resultResp.getCaseNo() != null && !workbinPos.contains(resultResp.getCaseNo())) {
                sb.append("该料箱号不存在;");
                hasError = true;
            }
            if (resultResp.getPalletNo() != null && !palletPos.contains(resultResp.getPalletNo())) {
                sb.append("该托盘号不存在;");
                hasError = true;
            }
            if (resultResp.getLocationCode() != null && !locationsPos.containsKey(resultResp.getWarehouseCode() + resultResp.getAreaCode() +
                    resultResp.getLocationCode())) {
                sb.append("该库位不存在;");
                hasError = true;
            }
            resultResp.setErrorInfo(sb.toString());
        }

        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    /**
     * 返回结果
     *
     * @param returnDataInfo
     * @throws BizException
     */
    @Override
    protected void afterProcess(ImportReturnDataInfo<StockUpdateOrderItemImportResultResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        }else{
            returnDataInfo.setImportFlag(true);
            for(StockUpdateOrderItemImportResultResp resp:returnDataInfo.getData()){
                if(StringUtils.isBlank(resp.getTargetMaterialStatus())){
                    resp.setTargetMaterialStatus(resp.getMaterialStatus());
                }

                if(StringUtils.isBlank(resp.getTargetStockStatus())){
                    resp.setTargetStockStatus(resp.getStockStatus());
                }

                if(StringUtils.isBlank(resp.getTargetSequenceNo())){
                    resp.setTargetSequenceNo(resp.getSequenceNo());
                }

                if(StringUtils.isBlank(resp.getTargetSamplePartStatus())){
                    resp.setTargetSamplePartStatus(resp.getSamplePartStatus());
                }

                if(StringUtils.isBlank(resp.getTargetMaterialSort())){
                    resp.setTargetMaterialSort(resp.getMaterialSort());
                }

                if(StringUtils.isBlank(resp.getTargetCarCode())){
                    resp.setTargetCarCode(resp.getCarCode());
                }

                if(StringUtils.isBlank(resp.getTargetBatchNo())){
                    resp.setTargetBatchNo(resp.getBatchNo());
                }

                if(StringUtils.isBlank(resp.getTargetProjectCode())){
                    resp.setTargetProjectCode(resp.getProjectCode());
                }

                if(StringUtils.isBlank(resp.getTargetStageCode())){
                    resp.setTargetStageCode(resp.getStageCode());
                }

                if(StringUtils.isBlank(resp.getTargetAddDate())){
                    resp.setTargetAddDate(resp.getAddDate());
                }
                resp.setAddDate(DateUtils.format(resp.getAddDate(),DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT_2, DateUtils.STANDARD_DATE_FORMAT));
                resp.setProductDate(DateUtils.format(resp.getProductDate(),DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT_2, DateUtils.STANDARD_DATE_FORMAT));
                resp.setExpireDate(DateUtils.format(resp.getExpireDate(),DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT_2, DateUtils.STANDARD_DATE_FORMAT));
                resp.setTargetAddDate(DateUtils.format(resp.getTargetAddDate(),DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT_2, DateUtils.STANDARD_DATE_FORMAT));
            }
        }
    }

    private String createErrExcel(List<StockUpdateOrderItemImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "库存属性调整单明细导入导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), StockUpdateOrderItemImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("StockUpdateOrderItemImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("StockUpdateOrderItemImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("库存属性调整单明细导入导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }


    private InAndOutStockParam convertStockParam(StockUpdateOrderItemImportResultResp resp){
        InAndOutStockParam stockParam = BeanCopierUtil.copy(resp, InAndOutStockParam.class);
        stockParam.setMaterialCode(resp.getMaterialNumber());
        if(StringUtils.isNotBlank(resp.getMaterialStatus())){
            stockParam.setMaterialStatus(Integer.valueOf(commonService.getDictItemCode(DictEnum.MaterialStockStatus,resp.getMaterialStatus())));
        }
        if(StringUtils.isNotBlank(resp.getStockStatus())){
            stockParam.setStockStatus(Integer.valueOf(commonService.getDictItemCode(DictEnum.StockStatus,resp.getStockStatus())));
        }
        stockParam.setMaterialSort(commonService.getDictItemCode(DictEnum.MaterialSort,resp.getMaterialSort()));
        stockParam.setAddDate(DateUtils.format(resp.getAddDate(),DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT_2, DateUtils.STANDARD_DATE_FORMAT));
        stockParam.setProductDate(DateUtils.format(resp.getProductDate(),DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT_2, DateUtils.STANDARD_DATE_FORMAT));
        stockParam.setExpireDate(DateUtils.format(resp.getExpireDate(),DateUtils.STANDARD_DATE_RIGHT_LINE_FORMAT_2, DateUtils.STANDARD_DATE_FORMAT));
        log.info(JSON.toJSONString(stockParam));
        return stockParam;
    }
}
