package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.api.enums.OperationType;
import com.jiduauto.sps.server.Enum.StockOperationType;
import com.jiduauto.sps.server.consts.*;
import com.jiduauto.sps.server.excel.BizTypeThreadHolder;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.*;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockImportResp;
import com.jiduauto.sps.server.pojo.vo.resp.stock.StockImportResultResp;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.service.ICommonService;
import com.jiduauto.sps.server.service.IStockInOrderService;
import com.jiduauto.sps.server.service.IStockService;
import com.jiduauto.sps.server.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 库存导入 初始化
 */
@Service
@Slf4j
public class StockImportHandler extends BaseImportHandler<StockImportResp, StockImportResultResp> {

    @Autowired
    private MaterialMapper materialMapper;
    @Autowired
    private WarehouseMapper warehouseMapper;
    @Autowired
    private AreasMapper areasMapper;
    @Autowired
    private LocationsMapper locationsMapper;
    @Autowired
    private SupplierMapper supplierMapper;
    @Autowired
    private PalletMapper palletMapper;
    @Autowired
    private WorkbinMapper workbinMapper;
    @Autowired
    private CarMapper carMapper;

    @Autowired
    private StockMapper StockMapper;
    @Autowired
    private StockItemMapper StockItemMapper;
    @Autowired
    private IStockService stockService;
    @Resource
    private IStockInOrderService stockInOrderService;

    @Autowired
    private IBosService bosService;

    @Autowired
    private RedisUtil redisUtil;
    @Autowired
    private ICommonService commonService;

    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("零件编码", "零件状态", "样件状态", "零件种类", "车辆号", "批次", "序列号", "零件条码", "入库日期", "生产日期", "失效日期", "库存数量", "库存状态", "供应商代码", "项目", "阶段", "WBS编号", "业务单号", "业务单行号", "仓库代码", "区域代码", "库位代码", "托盘号", "料箱号");

    @Override
    public List<ImportDataInfo<StockImportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<StockImportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, StockImportResp.class, new ReadListener() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s -> s.getStringValue().replace("\n", "")).collect(Collectors.toList());
                    if (!Objects.equals(headList, HEAD_VALUE_LIST)) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > MAX_LIMIT + 1) {
                        throw new BizException("单次导入最大数据量" + MAX_LIMIT + "行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try {
                        ImportDataInfo info = new ImportDataInfo();
                        StockImportResp data = (StockImportResp) o;
                        if (data != null) {
                            info.setData(data);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        } catch (Exception e) {
            log.error("库存导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "库存导入解析异常,请检查数据格式:" + e.getMessage());
        }
    }

    @Override
    protected ImportReturnDataInfo<StockImportResultResp> process(List<ImportDataInfo<StockImportResp>> list) throws BizException {
        ImportReturnDataInfo<StockImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        Set<String> materialNumbers = new HashSet<>();

        boolean hasError = false;
        String bizType = BizTypeThreadHolder.getBizType();
        Set<String> warehouseCodes = new HashSet<>();
        Set<String> supplierCodes = new HashSet<>();
        Set<String> areaCodes = new HashSet<>();
        Set<String> locationCodes = new HashSet<>();
        Set<String> palletCodes = new HashSet<>();
        Set<String> workbinCodes = new HashSet<>();
        Set<String> carCodes = new HashSet<>();

        List<StockImportResultResp> resultResps = new ArrayList<>();
        for (ImportDataInfo<StockImportResp> dataInfo : list) {
            StockImportResp resp = dataInfo.getData();
            StringBuilder sb = new StringBuilder();
            warehouseCodes.add(resp.getWarehouseCode());
            supplierCodes.add(resp.getSupplierCode());
            areaCodes.add(resp.getAreaCode());
            locationCodes.add(resp.getLocationCode());
            palletCodes.add(resp.getPalletCode());
            workbinCodes.add(resp.getWorkbinCode());
            carCodes.add(resp.getCarCode());
            materialNumbers.add(resp.getMaterialNumber());


            StockImportResultResp resultResp = new StockImportResultResp();
            BeanUtils.copyProperties(resp, resultResp);

            if (StringUtils.isEmpty(resp.getMaterialNumber())) {
                sb.append("零件编码不可以为空;");
                hasError = true;
            }
            if (StringUtils.isEmpty(resp.getInQuantity())) {
                sb.append("入库数量不可以为空;");
                hasError = true;
            } else {
                if (!NumberUtil.isNumeric(resp.getInQuantity())) {
                    sb.append("入库数量必须是数字;");
                    hasError = true;
                }
            }
          /*  if (StringUtils.isEmpty(resp.getMaterialStatus())) {
                sb.append("零件状态不可以为空;");
                hasError = true;
            }*/
       /*     if (StringUtils.isEmpty(resp.getMaterialSort())) {
                sb.append("零件种类不可以为空;");
                hasError = true;
            }*/

            if (StringUtils.isEmpty(resp.getStockStatus())) {
                sb.append("库存状态不可以为空;");
                hasError = true;
            }
            if (StringUtils.isEmpty(resp.getWarehouseCode())) {
                sb.append("仓库代码不可以为空;");
                hasError = true;
            }

            resultResp.setErrorInfo(sb.toString());
            resultResps.add(resultResp);
        }
        List<String> warehousePo = new ArrayList<>();
        List<String> supplierPos = new ArrayList<>();
        List<String> areasPos = new ArrayList<>();
        List<String> locationsPos = new ArrayList<>();
        List<String> carPos = new ArrayList<>();
        List<String> workbinPos = new ArrayList<>();
        List<String> palletPos = new ArrayList<>();
        if (!CollectionUtils.isEmpty(warehouseCodes)) {
            warehousePo = warehouseMapper.getByWCodes(bizType, new ArrayList<>(warehouseCodes));
        }
        if (!CollectionUtils.isEmpty(supplierCodes)) {
            supplierPos = supplierMapper.getDistinctByBizAndCodes(bizType, new ArrayList<>(supplierCodes));
        }
        if (!CollectionUtils.isEmpty(areaCodes)) {
            //TODO
            areasPos = areasMapper.getACodes(bizType, new ArrayList<>(areaCodes), new ArrayList<>(warehouseCodes));
        }
        if (!CollectionUtils.isEmpty(locationCodes)) {
            locationsPos = locationsMapper.getByWPCodes(bizType, new ArrayList<>(locationCodes));
        }
        if (!CollectionUtils.isEmpty(carCodes)) {
            carPos = carMapper.getByWPCodes(bizType, new ArrayList<>(carCodes));
        }
        if (!CollectionUtils.isEmpty(workbinCodes)) {
            workbinPos = workbinMapper.getByWPCodes(bizType, new ArrayList<>(workbinCodes));
        }
        if (!CollectionUtils.isEmpty(palletCodes)) {
            palletPos = palletMapper.getByWPCodes(bizType, new ArrayList<>(palletCodes));
        }

        List<String> duplicate = materialMapper.selectDistinctByNumbers(bizType, new ArrayList<>(materialNumbers));

        for (StockImportResultResp resultResp : resultResps) {
            StringBuilder sb = new StringBuilder(resultResp.getErrorInfo());
            if (resultResp.getMaterialNumber() != null && !duplicate.contains(resultResp.getMaterialNumber())) {
                sb.append("该零件编码不存在;");
                hasError = true;
            }
            if (resultResp.getWarehouseCode() != null && !warehousePo.contains(resultResp.getWarehouseCode())) {
                sb.append("该仓库不存在;");
                hasError = true;
            }
            if (resultResp.getSupplierCode() != null && !supplierPos.contains(resultResp.getSupplierCode())) {
                sb.append("该供应商编码不存在;");
                hasError = true;
            }
            if (resultResp.getAreaCode() != null && !areasPos.contains(resultResp.getAreaCode())) {
                sb.append("该区域不存在;");
                hasError = true;
            }
            if (resultResp.getCarCode() != null && !carPos.contains(resultResp.getCarCode())) {
                sb.append("该车辆编码不存在;");
                hasError = true;
            }
            if (resultResp.getWorkbinCode() != null && !workbinPos.contains(resultResp.getWorkbinCode())) {
                sb.append("该料箱号不存在;");
                hasError = true;
            }
            if (resultResp.getPalletCode() != null && !palletPos.contains(resultResp.getPalletCode())) {
                sb.append("该托盘号不存在;");
                hasError = true;
            }
            if (resultResp.getLocationCode() != null && !locationsPos.contains(resultResp.getLocationCode())) {
                sb.append("该库位不存在;");
                hasError = true;
            }
            resultResp.setErrorInfo(sb.toString());
        }

        if (hasError) {
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        } else {
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    @Override
    protected void afterProcess(ImportReturnDataInfo<StockImportResultResp> returnDataInfo) throws BizException {
        if (!CollectionUtils.isEmpty(returnDataInfo.getError())) {
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        } else {

            String bizType = BizTypeThreadHolder.getBizType();
            // 校验通过 保存入库
            InAndOutStockRequest request = new InAndOutStockRequest();
            request.setBusinessBillNo(bizType + System.currentTimeMillis());
            request.setIdempotentNo(bizType + System.currentTimeMillis());
            request.setTradeNo(request.getBusinessBillNo());
            request.setBusinessType(StockOperationType.INIT.getOperationType());
            request.setOperateTime(LocalDateTime.now());
            request.setOperateUser(UserUtil.getUserName());
            request.setOperationType(OperationType.ADD);
            List<InAndOutStockParam> params = new ArrayList<>();
            for (StockImportResultResp resultResp : returnDataInfo.getData()) {
                if (StringUtils.isBlank(resultResp.getMaterialStatus())) {
                    resultResp.setMaterialStatus(MaterialStockStatusEnum.S1.getDesc());
                }
                if (StringUtils.isBlank(resultResp.getMaterialSort())) {
                    resultResp.setMaterialSort(MaterialSortEnum.normal.getDesc());
                }
                request.setBizType(bizType);
                InAndOutStockParam param = BeanCopierUtil.copy(resultResp, InAndOutStockParam.class);
                param.setMaterialCode(resultResp.getMaterialNumber());
                param.setCaseNo(resultResp.getWorkbinCode());
                param.setSumQuantity(new BigDecimal(resultResp.getInQuantity()));
                param.setMaterialStatus(Integer.valueOf(commonService.getDictItemCode(DictEnum.MaterialStockStatus, resultResp.getMaterialStatus())));
                param.setMaterialSort(commonService.getDictItemCode(DictEnum.MaterialSort, resultResp.getMaterialSort()));
                param.setStockStatus(Integer.valueOf(commonService.getDictItemCode(DictEnum.StockStatus, resultResp.getStockStatus())));
                param.setPalletNo(resultResp.getPalletCode());
                param.setCaseNo(resultResp.getWorkbinCode());

                param.setPalletNo(resultResp.getPalletCode());
                param.setCaseNo(resultResp.getWorkbinCode());
                param.setSequenceNo(resultResp.getSequenceNo());
                if (ObjectUtil.isNotEmpty(resultResp.getInDate())) {
                    param.setAddDate(DateUtils.format(resultResp.getInDate(), DateUtils.STANDARD_DATE_FORMAT));
                }
                if (ObjectUtil.isNotEmpty(resultResp.getProductDate())) {
                    param.setProductDate(DateUtils.format(resultResp.getProductDate(), DateUtils.STANDARD_DATE_FORMAT));
                }
                if (ObjectUtil.isNotEmpty(resultResp.getExpireDate())) {
                    param.setExpireDate(DateUtils.format(resultResp.getExpireDate(), DateUtils.STANDARD_DATE_FORMAT));
                }
                params.add(param);
                request.setParams(params);


            }
            request.setStockSource(StockSource.SYS);
            BaseResult baseResult = stockService.putInStock(request);
            if (baseResult.isError()) {
                new RuntimeException(baseResult.getMessage());
            }else{
                stockInOrderService.insertIntoInOrder(request);
            }
        }
        returnDataInfo.setImportFlag(true);
    }

    private String createErrExcel(List<StockImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "零件主数据导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}", excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), StockImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet("失败列表").build();
            writer.write(error, writeSheet1);
        } catch (Exception e) {
            log.error("materialImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        } finally {
            if (writer != null) {
                writer.finish();
            }
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null) {
                throw new BizException("异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        } catch (Exception e) {
            log.error("materialImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if (excelFile.exists()) {
                boolean delete = excelFile.delete();
                log.info("库存初始化导入失败原因临时文件删除结果：{}", delete);
            }
        }
    }

}
