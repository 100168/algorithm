package com.jiduauto.sps.server.handler;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.converters.longconverter.LongStringConverter;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.server.Enum.BizTypeEnum;
import com.jiduauto.sps.server.Enum.MaterialStatus;
import com.jiduauto.sps.server.consts.BaseConstants;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.consts.MeasurementUnit;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.mapper.MaterialMapper;
import com.jiduauto.sps.server.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.server.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.server.pojo.po.MaterialPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.BosFileResult;
import com.jiduauto.sps.server.pojo.vo.resp.material.MaterialExportResp;
import com.jiduauto.sps.server.pojo.vo.resp.material.MaterialImportResultResp;
import com.jiduauto.sps.server.service.IBosService;
import com.jiduauto.sps.server.service.ICommonService;
import com.jiduauto.sps.server.threads.MaterialUpdateThread;
import com.jiduauto.sps.server.utils.BeanCopierUtil;
import com.jiduauto.sps.server.utils.BeanFillUtil;
import com.jiduauto.sps.server.utils.NumberUtil;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * 零件主数据导入
 */
@Service
@Slf4j
public class MaterialImportHandler extends BaseImportHandler<MaterialExportResp, MaterialImportResultResp>{

    @Autowired
    private MaterialMapper materialMapper;

    @Autowired
    private ICommonService commonService;

    @Autowired
    private IBosService bosService;

    private static ExecutorService executorService = Executors.newFixedThreadPool(8);
    private static final Integer MAX_LIMIT = 1000;
    private static final List<String> HEAD_VALUE_LIST =
            Arrays.asList("*零件编码",	"零件中文名称",	"零件英文名称",	"计量单位","零件类型代码","PMXU","规格代码","零件属性代码",	"状态",	"是否可维修",	"MOQ",	"*是否销售");
    @Override
    public List<ImportDataInfo<MaterialExportResp>> readFile(MultipartFile file) throws BizException {
        if(file.isEmpty()){
            throw new BizException("文件不能为空");
        }
        try(InputStream inputStream = file.getInputStream()){
            List<ImportDataInfo<MaterialExportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream,MaterialExportResp.class,new ReadListener(){
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if(headMap == null){
                        throw new BizException("模板不合规, 请检查！");
                    }
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    List<String> headList = readCellDataList.stream().map(s->s.getStringValue().replace("\n","")).collect(Collectors.toList());
                    if(!Objects.equals(headList,HEAD_VALUE_LIST)){
                        throw new BizException("模板不合规, 请检查！");
                    }
                }

                @Override
                public void invoke(Object o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if(rowNumber > BaseConstants.MAX_LIMIT_MATERIAL_IMPORT+1){
                        throw new BizException("单次导入最大数据量"+BaseConstants.MAX_LIMIT_MATERIAL_IMPORT+"行");

                    }

                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowNum = readRowHolder.getRowIndex() + 1;
                    try{
                        ImportDataInfo info = new ImportDataInfo();
                        MaterialExportResp data = (MaterialExportResp)o;
                        if(data != null && !StringUtils.isEmpty(data.getSalePartNum())){
                            info.setData(data);
                            importList.add(info);
                        }
                    }catch(Exception e){
                        log.error("第" + rowNum + "行,数据解析异常:{}", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().doRead();
            return importList;

        }catch(BizException e){
            log.error("零件主数据导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw e;
        }catch(Exception e){
            log.error("零件主数据导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "零件主数据导入解析异常,请检查文件格式");
        }
    }

    @Override
    protected ImportReturnDataInfo<MaterialImportResultResp> process(List<ImportDataInfo<MaterialExportResp>> list) throws BizException {
        ImportReturnDataInfo<MaterialImportResultResp> returnDataInfo = new ImportReturnDataInfo<>();
        List<String> salePartNums = new ArrayList<>();
        Map<String,String> infoMap = new HashMap<>();
        boolean hasError = false;
        List<MaterialImportResultResp> resultResps = new ArrayList<>();
         for(ImportDataInfo<MaterialExportResp> dataInfo:list){
            MaterialExportResp resp = dataInfo.getData();

            salePartNums.add(resp.getSalePartNum());
            MaterialImportResultResp resultResp = new MaterialImportResultResp();
            BeanUtils.copyProperties(resp, resultResp);
            StringBuilder sb = new StringBuilder();
            if(StringUtils.isEmpty(resp.getSalePartNum())){
                sb.append("零件编码不可以为空;");
                //文档中 写的零件编码  但是实际对应的是 售后件号 来做校验
                hasError = true;
            }else {
                // 去除字符串最前与最端段空格
                resultResp.setSalePartNum(StringUtils.deleteWhitespace(resp.getSalePartNum()));
            }
            if(StringUtils.isEmpty(resp.getMeasurementUnit())){
                sb.append("计量单位不可以为空;");
                hasError = true;
            }else if(commonService.getDictItemDesc(DictEnum.MaterialMeasureUnit,resp.getMeasurementUnit()) == null){
                sb.append("计量单位不存在;");
                hasError = true;
            }
             if (StringUtils.isNotBlank(resp.getPartTypeCode()) &&
                     !commonService.checkDictItem(DictEnum.MaterialType, resp.getPartTypeCode())) {
                 sb.append("零件类型代码不存在;");
                 hasError = true;
             }
             if (StringUtils.isNotBlank(resp.getPmxu()) &&
                     !commonService.checkDictItem(DictEnum.PMXU, resp.getPmxu())) {
                 sb.append("PMXU不存在;");
                 hasError = true;
             }
             if (StringUtils.isNotBlank(resp.getMaterialStandard()) &&
                     !commonService.checkDictItem(DictEnum.MaterialStandard, resp.getMaterialStandard())) {
                 sb.append("规格代码不存在;");
                 hasError = true;
             }
             if (StringUtils.isNotBlank(resp.getMaterialAttribute()) &&
                     !commonService.checkDictItem(DictEnum.MaterialAttribution, resp.getMaterialAttribute())) {
                 sb.append("零件属性代码不存在;");
                 hasError = true;
             }


            if(infoMap.containsKey(resp.getSalePartNum())){
                sb.append("零件编码重复了,请检查文件;");
                hasError = true;
            }else{
                infoMap.put(resp.getSalePartNum(),resp.getSalePartNum());
            }
             if(StringUtils.isNotBlank(resp.getState())){
                 if(!BaseConstants.MaterialStatus.OBSOLESCENCE_CN.equals(resp.getState()) &&
                         !BaseConstants.MaterialStatus.RELEASED_CN.equals(resp.getState()) ){
                     sb.append("状态填写 已发布/已废弃;");
                     hasError = true;
                 }else{
                     resultResp.setState(MaterialStatus.getCodeByDesc(resp.getState()));
                 }
             }else{
                 resultResp.setState(MaterialStatus.RELEASED.getCode());
             }
            if(StringUtils.isNotBlank(resp.getIsRepare()) &&( !"Y".equals(resp.getIsRepare()) &&  !"N".equals(resp.getIsRepare()) )){
                sb.append("是否可维修填写 Y/N;");
                hasError = true;
            }
            if(StringUtils.isNotBlank(resp.getIsSale()) ){
                if(( !"是".equals(resp.getIsSale()) &&  !"否".equals(resp.getIsSale()) )){
                    sb.append("是否可销售填写 是/否;");
                    hasError = true;
                }
            }else{
                sb.append("是否可销售不可以为空;");
                hasError = true;
            }

            if(StringUtils.isNotBlank(resp.getMoq()) && !NumberUtil.isNumeric(resp.getMoq())){
                sb.append("MOQ填写 数字;");
                hasError = true;
            }
            resultResp.setErrorInfo(sb.toString());
             resultResps.add(resultResp);
        }

//        List<String> duplicate = materialMapper.getBySalePartNums(String.valueOf(getThreadLocal().get()),salePartNums);
//        if(!CollectionUtils.isEmpty(duplicate)){
//            for(MaterialImportResultResp resultResp:resultResps){
//                if(duplicate.contains(resultResp.getSalePartNum())){
//                    if(StringUtils.isEmpty(resultResp.getErrorInfo())){
//                        resultResp.setErrorInfo("该售后件号已经存在;");
//                    }else{
//                        resultResp.setErrorInfo(resultResp.getErrorInfo()+"该售后件号已经存在;");
//                    }
//                }
//            }
//            hasError = true;
//        }
        if(hasError){
            returnDataInfo.setError(resultResps);
            returnDataInfo.setImportFlag(false);
        }else{
            returnDataInfo.setData(resultResps);
            returnDataInfo.setImportFlag(true);
        }
        return returnDataInfo;
    }

    @Override
    protected void afterProcess(ImportReturnDataInfo<MaterialImportResultResp> returnDataInfo) throws BizException {
        if(!CollectionUtils.isEmpty(returnDataInfo.getError())){
            String fileKey = createErrExcel(returnDataInfo.getError());
            returnDataInfo.setImportFlag(false);
            returnDataInfo.setFileUrl(fileKey);
            return;
        }else{
            List<MaterialPo> poList = new ArrayList<>();
            // 校验通过 保存入库
            Map<String, MaterialImportResultResp> resultRespMap = new HashMap<>();

            for(MaterialImportResultResp resultResp: returnDataInfo.getData()){
                resultRespMap.put(resultResp.getSalePartNum(),resultResp);
                MaterialPo po = new MaterialPo();
                if(StringUtils.isEmpty(resultResp.getState())){
                    resultResp.setState(BaseConstants.MaterialStatus.RELEASED);
                }
                if(StringUtils.isEmpty(resultResp.getIsRepare() )){
                    resultResp.setIsRepare("Y");
                }
                if(StringUtils.isEmpty(resultResp.getMoq() )){
                    resultResp.setMoq("1");
                }
                BeanFillUtil.fillNullStr(resultResp);
                BeanUtils.copyProperties(resultResp, po);
                po.setCreateUser(UserUtil.getUserName());
                po.setUpdateUser(UserUtil.getUserName());
                po.setBizType(returnDataInfo.getBizType());
                po.setMoq(Integer.valueOf(resultResp.getMoq()));
                //导入的时候  零件号码=售后件号
                po.setNumber(po.getSalePartNum());
                //数据来源 后台导入为 SPS
                po.setMaterialSource("SPS");
//                log.info("导入时零件参数 po {}:",po);
                log.info("导入时零件参数用户信息  {}:",UserUtil.getUserName());
                poList.add(po);
            }
            // 存在则更新字段，不存在则汇总后批量插入
            List<MaterialPo> insertList = new ArrayList<>();

            // 如果业务类型是JC或者SP，则同步到SS中
            List<MaterialPo> ssInsertList = new ArrayList<>();

            // 统一取出所有的 售后件号-零件 键值对
            String bizType = returnDataInfo.getBizType();
            List<String> salePartNums = poList.stream().map(MaterialPo::getSalePartNum).collect(Collectors.toList());
            List<MaterialPo> list = materialMapper.selectBySalePartNums(bizType, salePartNums);
            Map<String, MaterialPo> collect = list.stream().collect(Collectors.toMap(MaterialPo::getSalePartNum, MaterialPo -> MaterialPo));
            // 找到业务类型为SS的 售后件号-零件主数据键值对
            Map<String, MaterialPo> ssUpdateMap = materialMapper.selectBySalePartNums(BizTypeEnum.SS.getBizType(), salePartNums).stream()
                    .collect(Collectors.toMap(MaterialPo::getSalePartNum, MaterialPo -> MaterialPo));
            List<Future<BaseResult<String>>> futures = new ArrayList<>();

            for(MaterialPo e:poList){
                MaterialPo materialPo = collect.get(e.getSalePartNum());
                if(null == materialPo){
                    // 不存在走插入处理
                    e.setMaintenanceNote(com.jiduauto.sps.server.utils.StringUtils.defaultIfNull(e.getMaintenanceNote(),""));
                    insertList.add(e);
                    e.setMinPackage(StrUtil.nullToEmpty(e.getMinPackage()));
                    e.setSafeStock(StrUtil.nullToEmpty(e.getSafeStock()));
                    e.setStockTestFileName(StrUtil.nullToEmpty(e.getStockTestFileName()));
                    e.setStockTestFileUrl(StrUtil.nullToEmpty(e.getStockTestFileUrl()));
                    e.setLeftRightPart(StrUtil.nullToEmpty(e.getLeftRightPart()));

                    // 说明在SS中也不存在，走插入逻辑
                    if(bizType.equals(BizTypeEnum.JC.getBizType()) || bizType.equals(BizTypeEnum.SP.getBizType())){
                        // 业务类型是JC或者SP时插入到SS
                        MaterialPo ssInsert = BeanCopierUtil.copy(e, MaterialPo.class);
                        ssInsert.setBizType(BizTypeEnum.SS.getBizType());
                        ssInsertList.add(ssInsert);
                    }

                } else {
                    // 已经存在走更新处理
                    e.setId(materialPo.getId());
                    Integer moq = e.getMoq();
                    materialPo.setMoq(moq);
                    List<MaterialPo> updateList = new ArrayList<>();
                    updateList.add(e);
                    // 如果业务类型是JC则在SS中也更新 todo SP web端更新时不同步至SS下
                    if(bizType.equals(BizTypeEnum.JC.getBizType())) {
                        MaterialPo ssUpdateTemp = ssUpdateMap.get(e.getSalePartNum());
                        if(ssUpdateTemp != null){
                            MaterialPo ssUpdate = new MaterialPo();
                            BeanUtils.copyProperties(e,ssUpdate);
                            ssUpdate.setBizType(BizTypeEnum.SS.getBizType());
                            ssUpdate.setId(ssUpdateTemp.getId());
                            updateList.add(ssUpdate);
                        }
                    }

                    Future<BaseResult<String>> future = executorService.submit(new MaterialUpdateThread(materialMapper,updateList));
                    futures.add(future);
                }
            }

            boolean success = true;
            List<MaterialImportResultResp> errorList = new ArrayList<>();
            for(Future<BaseResult<String>> future:futures){
                try{
                    if(future.get().isError()){
                        MaterialImportResultResp resultResp = resultRespMap.get(future.get().getData());
                        resultResp.setErrorInfo("更新失败，请检查");
                        success = false;
                        errorList.add(resultResp);
                    }
                }catch (Exception e){
                    throw new BizException(-1,"导入失败请稍,后重试");
                }
            }
            if(!success){
                String fileKey = createErrExcel(errorList);
                returnDataInfo.setImportFlag(false);
                returnDataInfo.setFileUrl(fileKey);
                return;
            }

            if(!CollectionUtils.isEmpty(insertList)) {
                materialMapper.batchInsert(insertList);
                if(!CollectionUtils.isEmpty(ssInsertList)){
                    materialMapper.batchInsert(ssInsertList);
                }
            }
        }
        returnDataInfo.setImportFlag(true);
    }

    private String createErrExcel(List<MaterialImportResultResp> error) {
        File excelFile;
        ExcelWriter writer = null;
        try {
            for(MaterialImportResultResp resultResp:error){
                if(resultResp.getState() != null){
                    resultResp.setState(MaterialStatus.getDescByCode(resultResp.getState()));
                }
            }
            //创建临时文件
            excelFile = File.createTempFile(DateUtil.format(new DateTime(), DatePattern.PURE_DATE_PATTERN) + "零件主数据导入失败文件", BaseConstants.FileType.XLSX);
            log.info("导入生成异常原因文件失败临时文件地址：{}",excelFile.getAbsolutePath());
            writer = EasyExcel
                    .write(excelFile.getAbsoluteFile(), MaterialImportResultResp.class)
                    .registerConverter(new LongStringConverter())
                    .build();
            WriteSheet writeSheet1 = EasyExcel.writerSheet( "失败列表" ).build();
            writer.write(error,writeSheet1);
        }
        catch (Exception e) {
            log.error("materialImportHandler-createErrExcel-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件生成失败！");
        }finally {
            if(writer !=null){
                writer.finish();
            }
        }

        try(InputStream inputStream = Files.newInputStream(excelFile.toPath())){
            BosFileResult bosFileResult = bosService.putLowsObjInputStream(inputStream, "失败原因.xlsx");
            if (bosFileResult == null){
                throw new BizException( "异常原因文件上传BOS失败！");
            }
            return bosFileResult.getFileUrl();

        }catch (Exception e){
            log.error("materialImportHandler-createErrExcel-putLowsObjInputStream-error:{}", ExceptionUtils.getStackTrace(e));
            throw new BizException("异常原因文件上传BOS失败！");
        } finally {
            if(excelFile.exists()){
                boolean delete = excelFile.delete();
                log.info("零件主数据导入失败原因临时文件删除结果：{}",delete);
            }
        }
    }
}
