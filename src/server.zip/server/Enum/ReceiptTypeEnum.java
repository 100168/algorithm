package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @ClassName ReceiptTypeEnum
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/6/25 14:01
 */
@AllArgsConstructor
public enum ReceiptTypeEnum {
    L("L", "要货计划"),
    F("F", "采购申请");

    @Getter
    private final String code;

    @Getter
    private final String desc;

    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(ReceiptTypeEnum::getDesc).findFirst().orElse(null);
    }
    public static String getCode(String desc) {
        return Arrays.stream(values()).filter(item -> item.getDesc().equals(desc)).map(ReceiptTypeEnum::getCode).findFirst().orElse(null);
    }
}
