package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;

/**
 * 物料状态
 */
public enum MaterialStatus {
    RELEASED("RELEASED","已发布"),
    OBSOLESCENCE("OBSOLESCENCE","已废弃");
    private String code;
    private String desc;

    MaterialStatus(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static String getDescByCode(String code){
        if(StringUtils.isBlank(code)){
            return null;
        }
        for(MaterialStatus status:MaterialStatus.values()){
            if(status.code.equals(code)){
                return status.desc;
            }
        }
        return null;
    }public static String getCodeByDesc(String desc){
        if(StringUtils.isBlank(desc)){
            return null;
        }
        for(MaterialStatus status:MaterialStatus.values()){
            if(status.desc.equals(desc)){
                return status.code;
            }
        }
        return null;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
