package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum OrderPlanOperateEnum {

    EDIT("编辑");

    @Getter
    private final String desc;
}
