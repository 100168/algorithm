package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */

@AllArgsConstructor
@Getter
public enum ReceiveOrderStatus {

    /**/
    PUT("PUT_IN", "已收货"),
    CONFIRM("CONFIRM", "已确认"),
    PRINTED("PRINTED", "已打印");


    static final ReceiveOrderStatus[] CAN_CLOSE = {PUT, PRINTED};

    /**
     * 编码
     */
    private final String code;

    /**
     * 描述
     */
    private final String desc;

    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(ReceiveOrderStatus::getDesc).findFirst().orElse(null);
    }

    public static String getCode(String desc) {
        return Arrays.stream(values()).filter(item -> item.getDesc().equals(desc)).map(ReceiveOrderStatus::getCode).findFirst().orElse(null);
    }

    public static boolean canClose(String code) {
        return Arrays.stream(CAN_CLOSE).anyMatch(e -> e.getCode().equals(code));
    }
}
