package com.jiduauto.sps.server.Enum;

import lombok.Getter;

/**
 * 智子物流索赔接口报错枚举 contact 刘立峰
 */
@Getter
public enum ZhiZiClaimExceptionEnum {
    SO_NOT_EXIST(3001, "销售单不存在"),
    SO_All_PUT_IN(3002, "此SO已入库，无法索赔"),
    PARAM_ERROR(3003, "参数错误"),
    WHITELIST_NOT_EXIST(3004, "白名单不存在"),
    OPERATE_USER_NOT_EXIST(3005, "操作人不能为空"),
    WHITELIST_EXIST(3006, "该采购单已经创建过白名单"),
    ;

    private final int code;
    private final String desc;

    ZhiZiClaimExceptionEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
