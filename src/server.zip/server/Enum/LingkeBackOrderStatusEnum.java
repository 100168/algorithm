package com.jiduauto.sps.server.Enum;

import java.util.Objects;
import lombok.Getter;

/**
 * @ClassName LingkeBackOrderStatusEnum
 * @Description 领克订单状态枚举
 * @Author O_chaopeng.huang
 * @Date 2023/10/27 15:56
 */
@Getter
public enum LingkeBackOrderStatusEnum {
    ZERO(0, "待处理"),
    ONE(1, "处理中"),
    TWO(2, "已处理"),
    NINETY(90, "转换失败"),
    NINETY_ONE(91, "正在转换");

    private final int code;
    private final String desc;
    LingkeBackOrderStatusEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    /**
     * 根据编码获取desc
     */
    public static String getByCode(Integer code) {
        //判空
        if (Objects.isNull(code)) {
            return null;
        }
        //循环处理
        LingkeBackOrderStatusEnum[] values = LingkeBackOrderStatusEnum.values();
        for (LingkeBackOrderStatusEnum value : values) {
            if (value.getCode() == code) {
                return value.desc;
            }
        }
        return null;
    }
}
