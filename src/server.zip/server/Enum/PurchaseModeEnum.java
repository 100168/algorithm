package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
public enum PurchaseModeEnum {

    L("L", "要货计划模式"),
    F("F", "采购订单模式");

    @Getter
    private final String code;

    @Getter
    private final String desc;

    public static PurchaseModeEnum getByCode(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).findFirst().orElse(null);
    }
    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(PurchaseModeEnum::getDesc).findFirst().orElse(null);
    }
    public static String getCode(String desc) {
        return Arrays.stream(values()).filter(item -> item.getDesc().equals(desc)).map(PurchaseModeEnum::getCode).findFirst().orElse(null);
    }
}
