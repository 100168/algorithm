package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum SaleOrderStatusEnum {

    WAIT_ISSUED("WAIT_ISSUED","待处理","tag-wait-issued"),
    PENDING_DELIVERY("PENDING_DELIVERY", "待发货", "tag-pending-delivery"),
    DELIVERED("DELIVERED", "已发货", "tag-delivered"),
    PARTIALLY_RECEIVED("PARTIALLY_RECEIVED", "部分收货", "tag-partially-received"),
    FULLY_RECEIVED("FULLY_RECEIVED", "全部收货", "tag-fully-received"),
    CANCELED("CANCELED", "已取消", "tag-cancel");

    final private String code;

    final private String desc;

    final private String msgTag;

    final private static SaleOrderStatusEnum[] CAN_CANCEL = {WAIT_ISSUED, PENDING_DELIVERY};

    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(e -> e.getCode().equals(code)).map(SaleOrderStatusEnum::getDesc).findFirst().orElse(null);
    }

    public static String getMsgTag(String code) {
        return Arrays.stream(values()).filter(e -> e.getCode().equals(code)).map(SaleOrderStatusEnum::getMsgTag).findFirst().orElse(null);
    }

    public static boolean canCancel(String code){
        return Arrays.stream(CAN_CANCEL).anyMatch(e->e.getCode().equals(code));
    }

}
