package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ClassName HaveAndNotHave
 * @Description 有和无
 * @Author O_chaopeng.huang
 * @Date 2023/8/22 17:37
 */
@Getter
@AllArgsConstructor
public enum HaveAndNotHave {
        H("有"),
        NH("无")
        ;
        private final String name;
}
