package com.jiduauto.sps.server.Enum;

/**
 * SPS 公共返回码
 */
public enum SpsResponseCodeEnum {
    DUPLICATE_OPERATION(-1,"操作中，请稍后刷新"),
    START_AFTER_END_TIME(100001,"起始时间大于结束时间"),
    RECORD_EXIST(100002,"记录已经存在"),
    RECORD_NOT_EXIST(100003,"查询记录不存在"),
    RECORD_MAX_SIZE(100004,"单次请求最大1000条记录"),
    STOCK_CONFIG_NOT_EXIST(100005,"库存配置不存在，请在SPS后台添加处理"),
    OPERATE_TYPE_NOT_EXIST(100006,"接口的操作类型字段不符合预期"),
    QUANTITY_NOT_ENOUGH(100007,"数量不足，无法操作"),
    DUPLICATE_OPERATE(100008,"重复操作，请检查"),
    MATERIAL_NOT_EXIST(100009,"物料编码不存在，请检查"),
    WAREHOUSE_NOT_EXIST(100010,"仓库编码不存在，请检查"),
    AREA_NOT_EXIST(100011,"区域编码不存在，请检查"),
    LOCATION_NOT_EXIST(100012,"库位编码不存在，请检查"),
    BIZ_TYPE_NOT_EXIST(100013,"业务类型不存在，请检查"),
    SUPPLIER_NOT_EXIST(100014,"供应商不存在，请检查"),
    STOCK_ITEM_NOT_EXIST(100015,"库存不存在，请检查"),
    PARAMS_IS_EMPTY(100016,"参数为空，请检查"),
    PARAMS_HAS_DUPLICATE(100017,"参数中存在重复数据，请检查"),
    STOCK_NOT_EXIST(100018,"库存记录不存在，请检查"),
    EDIT_RECORD_NOT_EXIST(100019,"编辑记录不存在"),
    REQUEST_EXPIRE(100020,"请求过期，不处理"),
    COMPANY_NOT_EXIST(100021,"公司编码不存在"),
    SUPPLY_CYCLE_INVALID(100022,"供货周期不正确"),
    SUPPLY_TIME_INVALID(100023,"供货时间不正确"),
    OPERATE_NOT_SUPPORTED(100024, "不支持此操作"),
    DATA_UPDATED(100025, "数据已更新，请刷新"),
    PURCHASE_STATUS_ERROR(100026, "下发记录的状态不对"),
    PURCHASE_STATUS_DELETE_ERROR(100026, "下发记录的状态不对，只能删除待下发和下发失败记录"),
    SELECT_BY_ID(100024,"修改对象id不能为空"),
    WAREHOUSE_POSITION_NOT_EXIST(100025,"库位不存在"),
    PALLET_NOT_EXIST(100026,"托盘信息不存在"),
    PALLET_TYPE_NOT_EXIST(100027,"托盘类型不存在"),
    PALLET_TYPE_NOT_EXIST_ITEM(100028,"不存在该托盘类型的托盘"),
    BOX_TYPE_NOT_EXIST_ITEM(100029,"不存在该料箱类型"),
    BOX_SPRCIFICATIONS_NOT_EXIST_ITEM(100030,"不存在该料箱规格"),
    WORKBIN_NOT_EXIST_ITEM(100031,"料箱不存在"),
    WORKBIN_TYPE_NOT_EXIST_ITEM(100032,"该料箱类型或者料箱规格类型不存在"),
    WORKBIN_NAME_NOT_EXIST_ITEM(100033,"该料箱类型或者料箱规格类型未创建具体类型和规格"),
    CAR_NOT_EXIST(100034,"车辆号不存在"),
    CAR_TYPE_NOT_EXIST_ITEM(100035,"该项目类型或者项目阶段类型不存在"),
    CAR_NAME_NOT_EXIST_ITEM(100036,"该项目类型或者项目阶段类型未创建具体类型和阶段"),
    IN_ORDER_ITEM_NOT_EXIST(100037,"入库清单没有数据"),
    SUPPLIER_CONTACT_NOT_EXIST(100038,"供应商联系人不存在"),
    MATERIAL_NUM_NOT_EXIST(100039,"零件编码不存在"),
    SDATE_AND_EDATE(100040,"失效日期小于生产日期"),
    EDATE_AND_SDATE(100041,"生产日期大于失效日期"),
    SELLORDERCODE_NOT_EXIST(100042,"销售订单类型不存在"),
    TRANSPORTMODE_NOT_EXIST(100043,"运输方式配置不存在"),
    MATERIALATTRIBUTE_NOT_EXIST(100044,"零件销售属性不存在"),
    STORE_NOT_EXIST(100045,"该门店不存在"),
    WAREHOUSE_NOT(100046,"仓库编码不能重复，请检查"),
    BIZTYPE_NOT_CAN_NULL(100047,"业务类型不能为空"),
    STORECODE_NOT_CAN_NULL(100048,"门店编码不能为空"),
    STORECODE_NOT_EXIST(100049,"门店不存在"),
    GE_NOT_LE(100050,"库存调整数量不能大于已有库存数量"),
    CAN_DELETE(100051,"只能删除已输入数据"),
    ORDER_STATUS_PUT_IN(100052,"只能确认已输入的数据"),
    CANCEL_NOT_EXIST(100053,"取消记录不存在"),
    OPTIMISTIC_LOCK_EXCEPTION(100054,"系统繁忙，请稍后重试"),
    STORE_WAREHOUSE_CONFIG_NOT_EXIST(100055,"门店仓库配置不存在,请联系业务人员"),
    DUP_SALE_PART_NUM(100056,"售后件号重复"),
    QTY_NOT_MIN_PACKAGE_MUL(100057,"数量不是最小包装整数倍"),
    COMMIT_TIME_ERROR(100058,"请按订单日历时间提报订单"),
    SERIAL_MAX_ERROR(100059,"序列号超过最大限制"),

    MATERIAL_NOT_SALEABLE(100060,"不是有效的售后件号"),
    COMMIT_STATUS_ERROR(100061,"只有待提交和驳回才可以提交"),
    DELETE_STATUS_ERROR(100062,"只有待提交和驳回才可以删除"),

    SALE_PART_NUM_NOT_EXIST(100080,"售后件号不存在"),
    DETAIL_EMPTY(100081,"请添加数据"),
    AUDIT_STATUS_ERROR(100082,"当前状态不可以审批"),
    PRICE_TIME_ERROR(100082,"价格日期必须早于或等于当前日期"),
    SYNC_SAP_ERROR(100083,"同步sap失败"),
    SEND_MESSAGE_ERROR(100084,"发送消息失败"),
   ORDER_CALENDAR_ERROR(100085,"订单日历不存在，请联系业务配置订单日历"),
    APPLY_ORDER_ITEM_ERROR(100086,"领料单明细不能为空"),
    EDIT_NOT_CAN(100087,"只能编辑已输入状态订单"),
    LOCATION_ERROR(100088,"省市区请传code"),
    ENABLE_TEMP_ERROR(100089,"当前状态不可保存草稿"),
    EDIT_STATUS_ERROR(100082,"当前状态不可以编辑"),
    LOGISTICS_ALREADY_EXIST(100083,"运输时效数据已存在"),
    REPEAT_EDIT(100084,"请重新进入编辑页面"),
    ORDER_TYPE_NOT_EXIST(100085,"订单类型不存在"),
    //原为领用目的提示现改为领用用途提示
    APPLY_SAKE_NOT_EXIST(100086,"领用用途不存在"),
    DATE_NOT_NOT(100087,"日期不能为空"),
    APPLY_STATUS_NOT_EXIST(100088,"订单状态不存在"),
    EST_ARRIVAL_TIME_ERROR(100089,"预计到货日期不能早于当前日期"),
    VIN_CAN_NOT_BE_EMPTY(100090,"VIN号不能为空"),
    APPLY_TYPE_NOT_EXIST(100091,"取货方式不存在"),
    BACK_ORDER_CANCEL_ERROR(100092, "请检查缺件行的状态是否正确"),
    REFRESH_LIST(100093, "数据有更新，请刷新列表"),
    DFS_ORDER_CANCEL_ERROR(100093, "dfs订单不能取消"),
    SALE_ORDER_CANCEL_ERROR(100094, "当前状态不可取消"),
    CUSTOM_CAN_NOT_IS_DFS(100095,"定制件订单物料明细不能为DFS且必须是定制件"),
    QTY_IS_ONE(100096,"定制件订单每个物料明细数量必须是1"),
    CO_NOT_EDIT_DELETE(100097,"定制订单不支持修改与删除"),
    CO_ITEM_SIZE_ERROR(100098,"定制件订单明细只允许一条"),
    PICK_ERROR(100100,"只有已输入状态才可以拣货"),
    STOCK_ITEM_CONFIG_ERROR(100101,"未配置库存明细表配置"),
    MATERIAL_CANNOT_USE(100103,"存在物料被其他出库单占用"),
    CONFIRM_ERROR(100104,"当前状态不可以确认"),
    CANCEL_ERROR(100105,"当前状态不可以取消"),
    CAN_NOT_PRINT(100106,"当前状态不可以打印"),
    APPLY_PURPOSE_NOT_EXIST(100107,"领用目的不存在"),
    CAN_NOT_DEL(100108,"当前状态不可以删除"),
    SALE_UNUSABLE(100120, "售后件号不可用"),
    LOCATION_MODIFY_ERROR(100121, "请修改库位"),
    KIT_ORDER_STATUS_ERROR(100122,"当前订单状态不支持该操作"),
    KIT_ORDER_MATERIAL_CODE_ERROR(100123,"订单总成件code与接收值不等"),
    KIT_ORDER_QTY_ERROR(100124,"出入库数量大于订单数量"),
    WAREHOUSE_DISTRIBUTE_ORDER_ERROR(100130, "仓配订单明细更新实际出库数量出错"),
    WAREHOUSE_DISTRIBUTE_ORDER_NOT_ALLOWED_ERROR(100131, "商城仓配订单明细更新实际出库数量不允许部分出库"),
    ACTUAL_QTY_ERROR(100140, "实出数量不能大于应出数量"),
    LINE_NO_ERROR(100141, "行号不能重复"),
    PO_COMMIT_ERROR(100142, "只有待审核状态才能提交"),
    ADI_NOT_EXIST(100150, "该供应商下所选ASN对应发货信息不存在该零件"),
    ARI_NOT_EXIST(100151, "该供应商下所选ASN对应发货信息的零件未收货"),
    RETURN_QTY_LE_RECEIVED_QTY(100152, "申请退货数量小于等于可用收货数量"),

    OPTIMISTIC_LOCK_ERROR(1000153,"乐观锁异常"),
    ASN_NOT_EXIST(1000154,"绑定asn不存在"),
    REPEAL_ERROR(1000174,"当前状态不可以撤销"),
    FINISHED_ERROR(1000175,"当前状态不可以完成"),
    WAREHOUSE_DISTRIBUTE_ORDER_IN_ERROR(100130, "仓配订单明细更新实际入库数量出错"),
    SO_RECEIVE_NO_DFS_ERROR(1000201, "SO单收货只能是非DFS的物料"),



    ;

    /**
     * 编码
     */
    private Integer code;

    /**
     * 描述
     */
    private String desc;

    SpsResponseCodeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
