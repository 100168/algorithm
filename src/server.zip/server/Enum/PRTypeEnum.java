package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.handler.purchaseappplyorder.PRJobIndexEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */

@Getter
@AllArgsConstructor
public enum PRTypeEnum {


    /**
     * @see PRJobIndexEnum
     * 领克订单类型枚举
     * 1-常规订单；
     * 2-紧急订单；
     * 20-差异补单
     * 4-定制订单；
     * 9-DFS订单（动力电池）；
     * sap订单类型枚举
     * DFS：DFS
     * 定制件：CO
     * 常规订单：1
     * 紧急订单：2
     * 差异补单：20
     * DB子件订单：DB
     */
    FREE("FREE", "", -1, 1 | 1 << 1, "免费订单"),
    OUT_PLAN("OUT_PLAN", "", -1, 1 | 1 << 1, "计划外订单"),
    NORMAL("NORMAL", "1", 1, 1 << 3, "常规订单"),
    RO("RO", "2", 2, 1 << 3, "紧急订单"),
    DIFF("DIFF", "20", 20, 1 << 3, "差异补单"),
    DB_SUB("DB_SUB", "DB", -1, 1 << 3, "DB子件订单"),
    DB("DB", "D", -1, 1 << 2 | 1 << 3, "DB总成件订单"),
    DFS("DFS", "DFS", 9, 0, "DFS订单"),
    CO("CO", "CO", 4, 0, "定制订单"),

    ;

    private final String code;
    private final String sapCode;
    private final Integer lingkeCode;
    private final Integer jobIndex;

    @Getter
    private final String name;

    static final PRTypeEnum[] PUSH_TO_DHL = {FREE, OUT_PLAN};
    static final PRTypeEnum[] PUSH_TO_SAP = {NORMAL, RO, DIFF, DB_SUB, DB, CO, DFS};
    static final PRTypeEnum[] CO_AND_DFS = {CO, DFS};
    static final PRTypeEnum[] CANCEL_EXCLUDE = {DFS, OUT_PLAN,FREE};

    public static String getName(String value) {

        return Arrays.stream(values()).filter(e -> e.code.equals(value)).map(PRTypeEnum::getName).findFirst()
                .orElse("");
    }

    public static boolean needPushToDhl(String code) {
        return Arrays.stream(PUSH_TO_DHL).anyMatch(e -> e.getCode().equals(code));
    }

    public static boolean needPushToSap(String code) {
        return Arrays.stream(PUSH_TO_SAP).anyMatch(e -> e.getCode().equals(code));
    }

    public static PRTypeEnum getByCode(String code) {

        return Arrays.stream(values()).filter(e -> e.code.equals(code)).findFirst().orElse(null);
    }

    public static PRTypeEnum getByName(String name) {
        return Arrays.stream(values()).filter(e -> e.getName().equals(name)).findFirst().orElse(null);
    }

    /**
     * 是否是 co 或 dfs 类型
     */
    public static boolean isCoOrDfs(String code) {
        return Arrays.stream(CO_AND_DFS).anyMatch(e -> e.getCode().equals(code));
    }


    /**
     * 是否可以取消
     */
    public static boolean canCancel(String code) {
        return Arrays.stream(CANCEL_EXCLUDE).noneMatch(e -> e.getCode().equals(code));
    }


}
