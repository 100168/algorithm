package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import lombok.Getter;

/**
 * @author panjian
 */

public enum PurchaseOrderAttrEnum {
    /***/
    SELF("101", "售后自营"),
    AUTHORIZED("102", "售后授权");
    @Getter
    private final String code;
    @Getter
    private final String name;

    PurchaseOrderAttrEnum(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public static String getName(String code) {
        return Arrays.stream(values()).filter(v -> v.getCode().equals(code)).map(PurchaseOrderAttrEnum::getName).findFirst()
                .orElse(null);
    }
}
