package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
public enum OrderPlanStatusEnum {

    WAIT_COMMIT("OPS_WAIT_COMMIT", "待提交"),
    WAIT_AUDIT("OPS_WAIT_AUDIT", "待审核"),
    AUDITED("OPS_AUDITED", "已审核"),
    REJECTED("OPS_REJECTED", "驳回");

    @Getter
    private final String itemCode;

    @Getter
    private final String itemName;
    private final static OrderPlanStatusEnum[] ARRAY_COMMIT = {WAIT_COMMIT, REJECTED};
    private final static OrderPlanStatusEnum[] ARRAY_AUDIT = {WAIT_AUDIT};

    public static boolean canCommit(String itemCode){
        return Arrays.stream(ARRAY_COMMIT).anyMatch(item -> item.itemCode.equals(itemCode));
    }

    public static boolean canAudit(String itemCode){
        return Arrays.stream(ARRAY_AUDIT).anyMatch(item -> item.itemCode.equals(itemCode));
    }
}
