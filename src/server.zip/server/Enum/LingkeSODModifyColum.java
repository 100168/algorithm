package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.sdk.enums.LogType;
import com.jiduauto.sps.sdk.utils.log.GeneralModifyColum;
import lombok.Getter;

import static com.jiduauto.sps.sdk.enums.LogType.FIELD;

@Getter
public enum LingkeSODModifyColum implements GeneralModifyColum {

    prLineNo("prLineNo", "采购申请行号"),
    qty("qty", "数量"),
    vin("vin", "vin"),
    materialCode("materialCode", "售后件号"),
    lingkeMaterialCode("lingkeMaterialCode", "领克售后件号"),
    ;

    private final String value;
    private final String desc;
    private final LogType logType = FIELD;

    LingkeSODModifyColum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }


    @Override
    public String getOrderNoFieldName() {
        return "lingkeSaleOrderNo";
    }

    @Override
    public String getLogKey() {
        return LogKey.LINGKE_SALE_ORDER_DETAIL.getValue();
    }

    @Override
    public int getLogType() {
        return this.logType.getType();
    }
    /**
     * 获取中文变更描述
     */
    public static String getByDesc(String value) {
        for (LingkeSODModifyColum colum : LingkeSODModifyColum.values()) {
            if (colum.getValue().equals(value)){
                return colum.getDesc();
            }
        }
        return null;
    }
}
