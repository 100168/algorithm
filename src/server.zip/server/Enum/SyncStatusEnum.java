package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
public enum SyncStatusEnum {

    WAIT_SYNC("SS_WAIT_SYNC", "下发中"),
    SYNC_SUCCESS("SS_SYNC_SUCCESS", "下发成功"),
    SYNC_FAILED("SS_SYNC_FAILED", "下发失败");

    @Getter
    private final String itemCode;

    @Getter
    private final String itemName;

    private final static SyncStatusEnum[] ARRAY_PUSH = {WAIT_SYNC, SYNC_FAILED};

    public static boolean canPush(String itemCode){
        return Arrays.stream(ARRAY_PUSH).anyMatch(item -> item.itemCode.equals(itemCode));
    }

    public static String getItemNameByCode(String itemCode) {
        if (StringUtils.isEmpty(itemCode)) {
            return null;
        }
        return Arrays.stream(values())
                .filter(item -> item.itemCode.equals(itemCode))
                .map(SyncStatusEnum::getItemName)
                .findFirst().orElse(null);
    }
}
