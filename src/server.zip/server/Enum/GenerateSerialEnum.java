package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */
@AllArgsConstructor
@Getter
public enum GenerateSerialEnum {
    /**/
    RO(1L,"RO",4,9999L),
    PO(1L,"PO",5,99999L),
    SO(1L,"SO",5,99999L),
    BO(1L,"BO",6,999999L),
    CS(1L,"CS",3,999L),
    MS(1L,"MS",3,999L),
    PR(1L,"PR",4,9999L),
    KT(1L,"KT",4,9999L),
    JO(1L,"JO",5,99999L),
    JH(1L, "JH", 5, 99999L),
    SH(1L, "SH", 5, 99999L),
    SJ(1L, "SJ", 5, 99999L),
    QC(1L, "QC", 3, 999L),
    SC(1L, "SC", 3, 999L),
    CY(1L, "CY", 4, 9999L),
    ZC(1L, "ZC", 4, 9999L),
    SH_API(1L, "SH-API", 5, 99999L),
    IN_API(1L, "IN-API", 5, 99999L),
    POL(1L, "POL", 2, 99L),
    CSU(1L, "CSU", 4, 9999L),
    ;
    //开始号码
    private final Long start;
    //单号类型
    private final String type;
    //最大长度
    private final Integer maxLength;
    //最大序列号
    private final Long maxSerial;
}
