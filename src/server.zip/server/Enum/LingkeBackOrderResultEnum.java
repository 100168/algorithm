package com.jiduauto.sps.server.Enum;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @ClassName LingkeBackOrderEnum
 * @Description 领克缺件审批结果枚举
 * @Author O_chaopeng.huang
 * @Date 2023/10/27 15:24
 */
@Getter
public enum LingkeBackOrderResultEnum {
    NEW_BUILD(1, "新建"),
    WAIT_AUDIT(2, "待审核"),
    AUDIT_ADOPT(3, "审核通过"),
    ALREADY_REJECTED(4, "已驳回");

    private final Integer code;
    private final String desc;
    private  final static LingkeBackOrderResultEnum[] VIRTUAL_STOCK = {NEW_BUILD,WAIT_AUDIT,ALREADY_REJECTED};
    LingkeBackOrderResultEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    /**
     * 根据编码获取desc
     */
    public static String getByCode(Integer code) {
        //判空
        if (Objects.isNull(code)) {
            return null;
        }
        //循环处理
        LingkeBackOrderResultEnum[] values = LingkeBackOrderResultEnum.values();
        for (LingkeBackOrderResultEnum value : values) {
            if (Objects.equals(value.getCode(), code)) {
                return value.desc;
            }
        }
        return null;
    }
    /**
      * 新建,待审核,已驳回状态code
      */
    public static List<Integer> getStatusList() {
        return Arrays.stream(VIRTUAL_STOCK).map(LingkeBackOrderResultEnum::getCode)
                .collect(Collectors.toList());
    }
}
