package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @author panjian
 */
@Getter
@AllArgsConstructor
public enum PRDetailStatusEnum {

    /**/
    WAIT_AUDIT("WAIT_AUDIT", "取消申请中"),
    PASS("PASS", "取消审核通过"),
    REJECTED("REJECTED", "取消驳回"),
    ;
    private final String code;
    private final String name;


    public static PRDetailStatusEnum getByCode(String code) {
        return Arrays.stream(values()).filter(e -> e.code.equals(code)).findFirst().orElse(null);
    }

    public static PRDetailStatusEnum getByName(String name) {
        return Arrays.stream(values()).filter(e -> e.getName().equals(name)).findFirst().orElse(null);
    }
    public static String getCode(String code) {
        //判空
        if (Objects.isNull(code)) {
            return null;
        }
        //循环处理
        PRDetailStatusEnum[] values = PRDetailStatusEnum.values();
        for (PRDetailStatusEnum value : values) {
            if (value.getCode() .equals(code) ) {
                return value.name;
            }
        }
        return null;
    }
}
