package com.jiduauto.sps.server.Enum;

/**
 * 库存配置类型
 * @author tao.wang
 */
public enum ConfigTypeEnum {
    /**
     *
     */
    Stock_config(1,"库存配置"),
    stock_item_config(2,"库存类型配置");
    /**
     * 类型
     */
    private Integer type;
    /**
     * 注释
     */
    private String desc;

    public Integer getType() {
        return type;
    }

    ConfigTypeEnum(Integer type, String desc) {
        this.type = type;
        this.desc = desc;
    }
}
