package com.jiduauto.sps.server.Enum;

/**
 * 出库业务类型
 *
 * 20  能源公桩出库 ES20
 * 41：(家装)商城充电桩出库-Z01
 *
 * 21 内部领料出库 ：SP21、JC21
 *
 * 40 商城销售出库：JC23、SP23
 */
public enum PutOutBizType {
    ES20("ES20","20"),
    ES21("ES21","41"),
    ES24("ES24","41"),
    SP21("SP21","21"),
    SP24("SP24","70"),
    SP15("SP15","71"),
    JC15("JC15","71"),
    JC21("JC21","21"),
    JC24("JC24","70"),
    SP23("SP23","40"),
    JC23("JC23","40"),
    SM20("SM20","40"),
    SM11("SM11", "40"),
    SM12("SM12", "40"),
    SP16("SP16", "50"),
    SP26("SP26", "51"),
    CL16("CL16", "50"),
    CL26("CL26", "51"),
    CL21("CL21", "21"),
    JC16("JC16", "50"),
    JC26("JC26", "51"),
    ES16("ES16", "50"),
    ES26("ES26", "51"),
    SS18("SS18", "50"),
    SS28("SS28", "51"),
    ES23("ES23","21"),

    SP25("SP25", "60"),
    JC25("JC25", "60"),
    ES25("ES25", "60"),

    SP29("SP29", "90"),
    JC29("JC29", "90"),
    CL29("CL29", "90"),
    ES29("ES29", "90"),


    ;

    private String spsType;

    private String sapType;

    PutOutBizType(String spsType, String sapType) {
        this.spsType = spsType;
        this.sapType = sapType;
    }

    public static String getSapTypeBySpsType(String spsType){

        for(PutOutBizType bizType:PutOutBizType.values()){
            if(bizType.spsType.equals(spsType)){
                return bizType.sapType;
            }
        }
        return null;
    }

    public String getSpsType() {
        return spsType;
    }

    public String getSapType() {
        return sapType;
    }
}
