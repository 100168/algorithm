package com.jiduauto.sps.server.Enum;

/**
 * 零件主数据 字段对照
 */
public enum MaterialAttribute {

}
