package com.jiduauto.sps.server.Enum;


import com.jiduauto.sps.server.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum ClaimColumnEnum {
    RESPONSIBLE_PARTY("responsibleParty","责任方"),
    SECOND_RESPONSIBLE_PARTY("secondResponsibleParty","二次责任方"),
    ;
    private final String column;
    private final String desc;
    public static String getDesc(String code) {
        if (Objects.isNull(code)){
            return StringUtils.EMPTY;
        }
        return Arrays.stream(values()).filter(item -> item.getColumn().equals(code)).map(ClaimColumnEnum::getDesc).findFirst().orElse("");
    }
}
