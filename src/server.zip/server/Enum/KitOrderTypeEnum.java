package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */

@AllArgsConstructor
public enum KitOrderTypeEnum {

    /**/
    ASSEMBLE("ASSEMBLE", "组装"),
    //    ZSR1("ZSR1", "102","退货"),
    DISASSEMBLE("DISASSEMBLE", "拆解"),
    ;
    @Getter
    private final String code;
    @Getter
    private final String desc;


    public static String getCode(String code) {

        return Arrays.stream(values()).filter(o -> o.getCode().equals(code)).map(KitOrderTypeEnum::getCode)
                .findFirst().orElse(null);
    }

    public static KitOrderTypeEnum getByCode(String code) {
        return Arrays.stream(values()).filter(o -> o.getCode().equals(code))
                .findFirst().orElse(null);
    }

    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(v -> v.getCode().equals(code)).map(KitOrderTypeEnum::getDesc)
                .findFirst().orElse(null);
    }

}
