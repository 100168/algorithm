package com.jiduauto.sps.server.Enum;

/**
 * @author tao.wang
 * @date 2023/1/4
 * @description 操作类型枚举
 */
public enum OperateTypeEnum {
    /**
     * 新增修改删除
     */
    SAVE("SAVE","新增"),
    UPDATE("UPDATE","修改"),
    CANCEL("CANCEL","删除")

    ;

    /**
     * 操作类型
     */
    private String operateType;
    /**
     *
     */
    private String desc;



    OperateTypeEnum(String operateType, String desc) {
        this.operateType = operateType;
        this.desc = desc;
    }

    public String getOperateType() {
        return operateType;
    }

    public String getDesc() {
        return desc;
    }


    /**
     * 根据编码获取枚举类型
     *
     * @param code 编码
     * @return
     */
    public static OperateTypeEnum getByCode(String code) {
        //判空
        if (code == null) {
            return null;
        }
        //循环处理
        OperateTypeEnum[] values = OperateTypeEnum.values();
        for (OperateTypeEnum value : values) {
            if (value.getOperateType().equals(code)) {
                return value;
            }
        }
        return null;
    }
}
