package com.jiduauto.sps.server.Enum;

import lombok.Getter;

@Getter
public enum ApplyCarMaterialOrderStatusEnum {
    PUT_IN("PUT_IN"), //已输入
    CONFIRM("CONFIRM"), //已确认
    DONE("DONE"), //已出库
    PART("PART"), //部分出库
    ;
    private final String code;

    ApplyCarMaterialOrderStatusEnum(String code) {
        this.code = code;
    }
}
