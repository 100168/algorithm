package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@Getter
@AllArgsConstructor
public enum MaterialStatusEnum {
    /**/
    NORMAL("1","正常"),
    BAD("-1","破损");


    private final String value;
    private final String desc;

}
