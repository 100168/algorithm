package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum ColumnEnum {

    STATUS("状态"),
    DFS_STATUS("DFS状态"),
    CO_TRANSFER_STATUS("转采购申请状态"),
    ;


    @Getter
    private String desc;
}
