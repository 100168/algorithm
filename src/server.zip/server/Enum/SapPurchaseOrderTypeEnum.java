package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@AllArgsConstructor
public enum SapPurchaseOrderTypeEnum {

    /**/
    ZS01("ZS01", "102","正常销售"),
//    ZSR1("ZSR1", "102","退货"),
    NULL("", "101","空"),
    ;
    @Getter
    private final String value;
    @Getter
    private final String code;
    @Getter
    private final String desc;


    public static String getValue(String code) {

        return Arrays.stream(values()).filter(o -> o.getCode().equals(code)).map(SapPurchaseOrderTypeEnum::getValue)
                .findFirst().orElse(null);
    }


}
