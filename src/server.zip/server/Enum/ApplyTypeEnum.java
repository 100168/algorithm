package com.jiduauto.sps.server.Enum;


import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
public enum ApplyTypeEnum {
    EXP("EXP", "快递"),
    SPK("SPK", "自提");

    /**
     * 编码
     */
    private final String code;

    /**
     * 描述
     */
    private final String desc;

    ApplyTypeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    public  String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(ApplyTypeEnum::getDesc).findFirst().orElse(null);
    }
    public static String getCode(String desc) {
        return Arrays.stream(values()).filter(item -> item.getDesc().equals(desc)).map(ApplyTypeEnum::getCode).findFirst().orElse(null);
    }
}
