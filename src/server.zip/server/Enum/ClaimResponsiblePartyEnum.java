package com.jiduauto.sps.server.Enum;

import lombok.Getter;

/**
 * 物流索赔 责任方枚举
 */
@Getter
public enum ClaimResponsiblePartyEnum {

    BLANK(0,"空"), //不是实际的状态值，这个只针对索赔列表查询，传该值，查询所有索赔责任方值为 空的数据
    WRAP(1,"包装"),
    LOGISTICS(2,"物流"),
    WAREHOUSE(3,"仓库"),
    IQC(4,"IQC"),;

    private final int code;
    private final String desc;

    ClaimResponsiblePartyEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static ClaimResponsiblePartyEnum getByCode(int code){
        ClaimResponsiblePartyEnum[] values = ClaimResponsiblePartyEnum.values();
        for (ClaimResponsiblePartyEnum value : values) {
            if (value.getCode() == code) {
                return value;
            }
        }
        return null;
    }

    public static String getDesc(int code) {
        //循环处理
        ClaimResponsiblePartyEnum[] values = ClaimResponsiblePartyEnum.values();
        for (ClaimResponsiblePartyEnum value : values) {
            if (value.getCode() == code) {
                return value.getDesc();
            }
        }
        return null;
    }

}
