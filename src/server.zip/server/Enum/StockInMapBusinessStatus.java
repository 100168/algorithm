package com.jiduauto.sps.server.Enum;

import lombok.Getter;

@Getter
public enum StockInMapBusinessStatus {
    /**
     * 已上架
     */
    PUT_IN("PUT_IN"),
    /**
     * 已收货
     */
    RECEIVED("RECEIVED"),
    /**
     * 已到货
     */
    ARRIVAL("ARRIVAL"),
    /**
     * 已创建
     */
    CREATE("CREATE");
    /**
     * 编码
     */
    private final String code;

    StockInMapBusinessStatus(String code) {
        this.code = code;
    }
}
