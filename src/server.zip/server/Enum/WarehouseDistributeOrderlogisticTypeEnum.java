package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */
@AllArgsConstructor
@Getter
public enum WarehouseDistributeOrderlogisticTypeEnum {


    /**/
    PUT_IN(1, "入库"),
    PUT_OUT(2, "出库"),
    TRANSPORT_AND_PUT_IN(3, "运输+入库"),
    TRANSPORT_AND_PUT_OUT(4, "运输+出库"),
    TRANSPORT(5, "运输");

    private final Integer value;
    private final String desc;

    final static WarehouseDistributeOrderlogisticTypeEnum[] NEED_CHECK = {TRANSPORT_AND_PUT_IN,
            TRANSPORT_AND_PUT_OUT,
            TRANSPORT};

    public static boolean isExist(Integer value) {
        return Arrays.stream(values()).anyMatch(e -> e.value.equals(value));
    }

    public static boolean needCheck(Integer value) {
        return Arrays.stream(NEED_CHECK).anyMatch(e -> e.value.equals(value));
    }


}
