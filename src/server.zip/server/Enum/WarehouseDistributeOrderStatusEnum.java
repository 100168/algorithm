package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */
@AllArgsConstructor
@Getter
public enum WarehouseDistributeOrderStatusEnum {

    /**/
    WAIT_DELIVER("WAIT_DELIVER", "待下发"),
    DELIVERED("DELIVERED", "已下发"),
    SHIPPED("SHIPPED", "已发货"),
    CANCELED("CANCELED", "已取消"),
    ARRIVAL("ARRIVAL", "已到货"),
    OUT_STOCK_COMPLETED("OUT_STOCK_COMPLETED", "已出库"),
    OUT_STOCK_FAILED("OUT_STOCK_FAILED", "库存不足"),
    COMPLETED("COMPLETED", "已完成")
    ;
    private final String code;
    private final String desc;

    private static final WarehouseDistributeOrderStatusEnum[] CAN_CANCEL = {WAIT_DELIVER,DELIVERED};
    private static final WarehouseDistributeOrderStatusEnum[] CAN_RETRY = {OUT_STOCK_FAILED, WAIT_DELIVER};


    public static boolean canCancel(String code){

        return Arrays.stream(CAN_CANCEL).anyMatch(e->e.getCode().equals(code));
    }

    public static boolean canRetry(String code) {

        return Arrays.stream(CAN_RETRY).anyMatch(e -> e.getCode().equals(code));
    }


}
