package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */
@AllArgsConstructor
@Getter
public enum MaterialChangePackageEnum {

    /***/
    Y("Y", "翻包换标签"),
    X("X", "不翻包换标签"),
    N("N", "不翻包不换标签");
    private final String value;
    private final String desc;

    public static String getValueByDesc(String desc) {

        return Arrays.stream(values()).filter(o -> o.getDesc().equals(desc)).map(MaterialChangePackageEnum::getValue)
                .findFirst().orElse("");
    }

    public static String getDescByValue(String value) {

        return Arrays.stream(values()).filter(o -> o.getValue().equals(value)).map(MaterialChangePackageEnum::getDesc)
                .findFirst().orElse("");
    }

    public static boolean noneMatch(String desc){
        return Arrays.stream(values()).noneMatch(o-> o.getDesc().equals(desc));
    }
}
