package com.jiduauto.sps.server.Enum;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ClassName PRTypeStockTypeEnum
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/9/18 15:12
 */
@AllArgsConstructor
@Getter
public enum PRTypeStockTypeEnum {
    /***/
    //免费入库
    FREE("FREE", new String[]{"SP13", "JC13", "ES13"}),
    //计划外订单
    OUT_PLAN("OUT_PLAN", new String[]{"SP14"}),
    ;
    private final String purchaseOrderType;

    private final String[] codeStockType;

    public static List<String> purchaseOrderType(String purchaseOrderType) {
        PRTypeStockTypeEnum prTypeStockTypeEnum = Arrays.stream(values())
                .filter(e -> e.purchaseOrderType.equals(purchaseOrderType)).findFirst().orElse(null);
        if (prTypeStockTypeEnum == null){
            return new ArrayList<>();
        }
        return Arrays.stream(prTypeStockTypeEnum.getCodeStockType()).collect(Collectors.toList());
    }
}
