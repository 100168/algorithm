package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.sdk.enums.LogType;
import com.jiduauto.sps.sdk.utils.log.GeneralModifyColum;
import lombok.Getter;

import static com.jiduauto.sps.sdk.enums.LogType.FIELD;
import static com.jiduauto.sps.sdk.enums.LogType.STATUS;


@Getter
public enum LingkeBODModifyColum implements GeneralModifyColum {

    lineNo("lineNo", "行项目号"),
    prLineNo("prLineNo", "采购申请行号"),
    materialCode("materialCode", "售后件号"),
    lingkeMaterialCode("lingkeMaterialCode", "领克售后件号"),
    qty("qty", "缺件数量"),
    isCanceled("isCanceled", "是否取消"),
    approvalResult("approvalResult", "审批结果"),
    approvalTime("approvalTime", "审批时间"),
    fixTime("fixTime", "解决时间"),
    manualAllocationQty("manualAllocationQty", "手工分货数量"),
    processStatus("processStatus", "处理状态", STATUS),
    lingkeComment("lingkeComment", "领克审批原因"),
    spsStatus("spsStatus", "sps订单状态"),
    ;

    private final String value;
    private final String desc;
    private LogType logType = FIELD;

    LingkeBODModifyColum(String value, String desc) {
        this.value = value;
        this.desc = desc;

    }

    LingkeBODModifyColum(String value, String desc, LogType logType) {
        this.value = value;
        this.desc = desc;
        this.logType = logType;
    }

    @Override
    public String getOrderNoFieldName() {
        return "id";
    }

    @Override
    public String getLogKey() {
        return LogKey.LINGKE_BACK_ORDER_DETAIL.getValue();
    }

    @Override
    public int getLogType() {
        return this.logType.getType();
    }
    /**
     * 获取中文变更描述
     */
    public static String getByDesc(String value) {
        for (LingkeBODModifyColum colum : LingkeBODModifyColum.values()) {
            if (colum.getValue().equals(value)){
                return colum.getDesc();
            }
        }
        return null;
    }
}
