package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */
@Getter
@AllArgsConstructor
public enum StockChannelType {

    /**/
    IN("IN", "入库"),
    OUT("OUT", "出库");
    private final String code;
    private final String name;


    public static StockChannelType getByCode(String code) {
        return Arrays.stream(values()).filter(e -> e.code.equals(code)).findFirst().orElse(null);
    }

    public static StockChannelType getByName(String name) {
        return Arrays.stream(values()).filter(e -> e.getName().equals(name)).findFirst().orElse(null);
    }
}
