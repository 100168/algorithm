package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@AllArgsConstructor
@Getter
public enum ReceiveStrategyEnum {

    EMPTY_STOCK("EMPTY_STOCK", "存放空库位"),
    MAX_STOCK("MAX_STOCK", "库容率最大");

    /**
     * 编码
     */
    private final String code;

    /**
     * 描述
     */
    private final String desc;
}
