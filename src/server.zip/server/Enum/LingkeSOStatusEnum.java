package com.jiduauto.sps.server.Enum;

import lombok.Getter;

/**
 * 领克销售订单状态枚举
 */
@Getter
public enum LingkeSOStatusEnum {

    PENDING(0, "待处理"),
    PROCESSING(1, "处理中"),
    PART_DELIVERED(2, "部分发货"),
    DELIVERED(3, "已发货");

    private final int code;
    private final String desc;

    LingkeSOStatusEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    /**
     * 根据编码获取枚举类型
     */
    public static LingkeSOStatusEnum getByCode(Integer code) {
        //判空
        if (code == null) {
            return null;
        }
        //循环处理
        LingkeSOStatusEnum[] values = LingkeSOStatusEnum.values();
        for (LingkeSOStatusEnum value : values) {
            if (value.getCode() == code) {
                return value;
            }
        }
        return null;
    }
}
