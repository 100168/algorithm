package com.jiduauto.sps.server.Enum;

import lombok.Getter;

import java.util.Arrays;

/**
 * 领克销售订单类型枚举
 */
@Getter
public enum LingkeSOOrderTypeEnum {
    /** 常规订单 */
    COMMON_ORDER(1,"NORMAL"),
    /** 紧急订单 */
    URGENT_ORDER(2,"RO"),
    /** 定制订单 */
    CO_ORDER(4,"CO"),
    /** DFS订单 */
    DFS_ORDER(9,"DFS"),
    /** 差异补单 */
    DIFFERENCE_ORDER(20,"DIFF"),
    ;

    /**
     * 领克code
     */
    private final int code;
    /**
     * 对应 sps 类型
     */
    private final String value;

    private final static LingkeSOOrderTypeEnum[] BO_TYPE_ARR = {COMMON_ORDER, URGENT_ORDER, DFS_ORDER};

    LingkeSOOrderTypeEnum(int code, String value) {
        this.code = code;
        this.value = value;
    }

    public static LingkeSOOrderTypeEnum getByCode(Integer code){
        if (code == null){
            return null;
        }

        for (LingkeSOOrderTypeEnum e : LingkeSOOrderTypeEnum.values()) {
            if (e.getCode() == code) {
                return e;
            }
        }
        return null;
    }

    /**
     * 是否是 BO 缺件订单类型
     */
    public static boolean isBoType(Integer code){
        LingkeSOOrderTypeEnum byCode = getByCode(code);
        if (byCode == null) return false;
        return Arrays.asList(BO_TYPE_ARR).contains(byCode);
    }

    /**
     * 根据value 获取code
     */
    public static Integer getCodeByValue(String value) {
        for (LingkeSOOrderTypeEnum e : LingkeSOOrderTypeEnum.values()) {
            if (e.getValue().equals(value)) {
                return e.getCode();
            }
        }
        return null;
    }

}
