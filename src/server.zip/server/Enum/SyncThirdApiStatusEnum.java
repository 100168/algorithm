package com.jiduauto.sps.server.Enum;

import lombok.Getter;

/**
 * @author panjian
 */

public enum SyncThirdApiStatusEnum {

    /***/
    SUCCESS(0,"下发成功"),
    FAILED(1,"下发失败");
    @Getter
    private final int status;
    @Getter
    private final String desc;

    SyncThirdApiStatusEnum(int status, String desc) {
        this.status = status;
        this.desc = desc;
    }
}
