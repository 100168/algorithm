package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */
@AllArgsConstructor
@Getter
public enum WarehouseDistributeOrderTypeEnum {


    /*
    OCCUPY_STOCK(1<<0),
    GENERATE_PENDING_RECEIVE_ORDER(1<<1),
    SYNC_TO_TMS(1 << 2),
    INBOUND_COMMAND(1 << 3),*/
    SM20("SM20", "TOC", 1, "商城订单"),
    QE11("QE11", "RO", 1 << 1 | 1 << 2, "普返"),
    QE12("QE12", "STK", 1 << 2, "快返"),
    SP18("SP18", "STK", 1 << 2 | 1 << 3, "直营索赔回运"),
    SP19("SP19", "STK", 1 << 2 | 1 << 3, "授权索赔回运");


    private final String value;
    /***/
    private final String tmsOrderType;

    private final Integer jobIndex;
    private final String desc;

    final static WarehouseDistributeOrderTypeEnum[] SP_NEED_CHECK = {SP18, SP19};
    final static WarehouseDistributeOrderTypeEnum[] QE = {QE11, QE12};
    final static WarehouseDistributeOrderTypeEnum[] NEED_CHECK = {QE11, QE12, SP18, SP19};
    final static WarehouseDistributeOrderTypeEnum[] WRITE_SUPPLIER_CODE = {QE11, QE12};
    final static WarehouseDistributeOrderTypeEnum[] NEED_INIT_STATUS = {QE11, QE12, SP18, SP19};

    public static boolean isExist(String value) {
        return Arrays.stream(values()).anyMatch(e -> e.value.equals(value));
    }

    public static WarehouseDistributeOrderTypeEnum getByType(String type) {
        return Arrays.stream(values()).filter(e -> e.value.equals(type)).findFirst().orElse(null);
    }

    public static boolean needCheckSP(String value) {
        return Arrays.stream(SP_NEED_CHECK).anyMatch(e -> e.value.equals(value));
    }


    public static boolean needCheck(String value) {
        return Arrays.stream(NEED_CHECK).anyMatch(e -> e.value.equals(value));
    }

    public static boolean needWriteSupplierCode(String value) {
        return Arrays.stream(WRITE_SUPPLIER_CODE).anyMatch(e -> e.value.equals(value));
    }

    public static boolean needInitStatus(String value) {
        return Arrays.stream(NEED_INIT_STATUS).anyMatch(e -> e.value.equals(value));
    }

    public static boolean isQe(String value) {
        return Arrays.stream(QE).anyMatch(e -> e.value.equals(value));
    }

}
