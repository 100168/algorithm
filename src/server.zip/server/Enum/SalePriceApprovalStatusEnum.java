package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
public enum SalePriceApprovalStatusEnum {

    TEMP("SPA_TEMP", "临时数据，该状态对外不可见"),
    WAIT_COMMIT("SPA_WAIT_COMMIT", "待提交"),
    WAIT_AUDIT("SPA_WAIT_AUDIT", "待审核"),
    AUDITED("SPA_AUDITED", "审批通过"),
    REJECTED("SPA_REJECTED", "驳回");

    @Getter
    private final String itemCode;

    @Getter
    private final String itemName;

    private final static SalePriceApprovalStatusEnum[] ARRAY_DELETE = {TEMP, WAIT_COMMIT};
    private final static SalePriceApprovalStatusEnum[] ARRAY_EDIT = {TEMP, WAIT_COMMIT, REJECTED};
    private final static SalePriceApprovalStatusEnum[] ARRAY_COMMIT = {WAIT_COMMIT, REJECTED};

    public static boolean canDelete(String itemCode) {
        return Arrays.stream(ARRAY_DELETE).anyMatch(item -> item.itemCode.equals(itemCode));
    }

    public static boolean canEdit(String itemCode) {
        return Arrays.stream(ARRAY_EDIT).anyMatch(item -> item.itemCode.equals(itemCode));
    }

    public static boolean canCommit(String itemCode) {
        return Arrays.stream(ARRAY_COMMIT).anyMatch(item -> item.itemCode.equals(itemCode));
    }
}
