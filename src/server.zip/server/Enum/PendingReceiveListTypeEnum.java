package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */

@Getter
@AllArgsConstructor
public enum PendingReceiveListTypeEnum {

    /***/
    ASN("ASN", "ASN收货"),
    QE11("QE11", "质量普返"),
    QE12("QE12", "质量快返"),
    CGRK("CGRK", "采购入库"),
    ;
    private final String code;

    final static PendingReceiveListTypeEnum[] wdo = {QE11,QE12};
    @Getter
    private final String desc;
    public static String getDesc(String value) {

        return Arrays.stream(values()).filter(e -> e.code.equals(value)).map(PendingReceiveListTypeEnum::getDesc).findFirst()
                .orElse("");
    }
    public static boolean isWdo(String code){
        return Arrays.stream(wdo).anyMatch(e-> e.getCode().equals(code));
    }

}
