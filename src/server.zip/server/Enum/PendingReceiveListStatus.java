package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */

@AllArgsConstructor
@Getter
public enum PendingReceiveListStatus {

    /**/
    PUT("PUT_IN", "已输入"),
    RECEIVING("RECEIVING", "收货中"),
    RECEIVED("RECEIVED", "已收货"),
    CANCELED("CANCELED", "已取消收货"),
    INVALIDATED("INVALIDATED", "已作废");
    ;


    static final PendingReceiveListStatus[] CAN_CLOSE = {PUT, RECEIVING};
    static final PendingReceiveListStatus[] CAN_RECEIVE = {PUT, RECEIVING};
    static final PendingReceiveListStatus[] CAN_CANCEL = {PUT, CANCELED};


    /**
     * 编码
     */
    private final String code;

    /**
     * 描述
     */
    private final String desc;

    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(PendingReceiveListStatus::getDesc).findFirst().orElse(null);
    }

    public static String getCode(String desc) {
        return Arrays.stream(values()).filter(item -> item.getDesc().equals(desc)).map(PendingReceiveListStatus::getCode).findFirst().orElse(null);
    }

    public static boolean canClose(String code) {
        return Arrays.stream(CAN_CLOSE).anyMatch(e -> e.getCode().equals(code));
    }

    public static boolean canReceive(String code) {
        return Arrays.stream(CAN_RECEIVE).anyMatch(e -> e.getCode().equals(code));
    }

    /**
     * 校验订单状态为“已输入 ，已取消收货”，否则不支持删除
     */
    public static boolean canCancel(String code) {
        return Arrays.stream(CAN_CANCEL).anyMatch(e -> e.getCode().equals(code));
    }
}
