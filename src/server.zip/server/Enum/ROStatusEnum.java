package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */
@AllArgsConstructor
public enum ROStatusEnum {

    /**/
    WAIT_COMMIT("WAIT_COMMIT", "待提交"),
    WAIT_AUDIT("WAIT_AUDIT", "待审核"),
    AUDITED("AUDITED", "已审核"),
    REJECTED("REJECTED", "驳回"),
    TEMP("TEMP", "草稿");

    @Getter
    private final String itemCode;

    @Getter
    private final String itemName;
    private final static ROStatusEnum[] ARRAY_COMMIT = {WAIT_COMMIT, REJECTED,TEMP};
    private final static ROStatusEnum[] ARRAY_DELETE = {WAIT_COMMIT, REJECTED,TEMP};
    private final static ROStatusEnum[] ARRAY_EDIT = {WAIT_COMMIT, REJECTED,TEMP};
    private final static ROStatusEnum[] ARRAY_AUDIT = {WAIT_AUDIT};
    private final static ROStatusEnum[] ARRAY_TEMP = {WAIT_COMMIT,TEMP};

    public static boolean cannotCommit(String itemCode){
        return Arrays.stream(ARRAY_COMMIT).noneMatch(item -> item.itemCode.equals(itemCode));
    }

    public static boolean cannotEdit(String itemCode){
        return Arrays.stream(ARRAY_EDIT).noneMatch(item -> item.itemCode.equals(itemCode));
    }

    public static boolean cannotDelete(String itemCode){
        return Arrays.stream(ARRAY_DELETE).noneMatch(item -> item.itemCode.equals(itemCode));
    }
    public static boolean cannotAudit(String itemCode){
        return Arrays.stream(ARRAY_AUDIT).noneMatch(item -> item.itemCode.equals(itemCode));
    }

    public static boolean cannotEnableTemp(String itemCode){
        return Arrays.stream(ARRAY_TEMP).noneMatch(item -> item.itemCode.equals(itemCode));
    }

    public static String getName(String itemCode){

        return Arrays.stream(values()).filter(e-> e.itemCode.equals(itemCode)).map(ROStatusEnum::getItemName).findFirst().orElse("");
    }

    public static ROStatusEnum getByCode(String itemCode) {

        return Arrays.stream(values()).filter(e -> e.itemCode.equals(itemCode)).findFirst().orElse(null);
    }
}
