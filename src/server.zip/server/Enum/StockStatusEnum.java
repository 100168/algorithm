package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@AllArgsConstructor
@Getter
public enum StockStatusEnum {

    /**/
    NORMAL(1,"正常"),
    FROZEN(-1,"冻结"),
    WAIT_DELIVER(-2,"待发货冻结"),
    WAIT_RACK(2,"待上架"),
    OCCUPY(3,"占用"),
    IN_TRANSIT(4, "在途"),
    WAIT_OUTBOUND(5,"待出库"),
    PICKING_OCCUPY(6,"拣货占用"),
    RECEIVED(7, "已收货"),
    ES_IN_TRANSIT(11, "能源在途")
    ;
    private final Integer value;
    private final String desc;

}
