package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @author panjian
 */

@AllArgsConstructor
@Getter
public enum PRModifyActionEnum {

    /***/
    EDIT("EDIT", "编辑"),
    LINK_PASS("LINK_PASS", "领克取消审核通过"),
    BO_PASS("BO_PASS", "缺件取消审核通过");
    private final String value;
    private final String desc;

    public static String getDesc(String colum) {
        return Arrays.stream(values()).filter(e -> Objects.equals(e.getValue(), colum)).map(PRModifyActionEnum::getDesc).findFirst().orElse("");
    }

}
