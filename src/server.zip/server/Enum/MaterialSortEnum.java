package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@Getter
@AllArgsConstructor
public enum MaterialSortEnum {
    /**/
    COMMON("1", "普通件"),
    SPECIAL("2", "特殊件"),
    STANDARD("3", "标准件");


    private final String value;
    private final String desc;

}
