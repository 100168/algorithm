package com.jiduauto.sps.server.Enum;

import cn.hutool.core.util.StrUtil;
import lombok.Getter;

import java.util.Objects;

/**
 * 领克 bo 处理状态枚举
 */
@Getter
public enum LingkeBOProcessStatusEnum {
    WAIT(0, "待处理"),
    DONE(1, "已处理"),
    ;
    private final Integer code;
    private final String desc;
    LingkeBOProcessStatusEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    /**
     * 根据编码获取desc
     */
    public static String getByCode(Integer code) {
        //判空
        if (Objects.isNull(code)) {
            return null;
        }
        //循环处理
        LingkeBOProcessStatusEnum[] values = LingkeBOProcessStatusEnum.values();
        for (LingkeBOProcessStatusEnum value : values) {
            if (Objects.equals(value.getCode(), code)) {
                return value.desc;
            }
        }
        return null;
    }

    /**
     * 是否存在该code
     */
    public static boolean hasCode(String code) {
        //判空
        if (StrUtil.isBlank(code)) {
            return false;
        }
        //循环处理
        LingkeBOProcessStatusEnum[] values = LingkeBOProcessStatusEnum.values();
        for (LingkeBOProcessStatusEnum value : values) {
            if ((value.code.toString()).equals(code)) {
                return true;
            }
        }
        return false;
    }
}
