package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
@Getter
public enum PurchaseOrderStatusEnum {

    /**/
    PENDING_REVIEW("PENDING_REVIEW", "待审核", null),
    APPROVED("APPROVED", "已审核", "tag-approved"),
    TRANSFER_FAILED("TRANSFER_FAILED", "转单失败", "tag-transfer-failed"),
    TRANSFER_SUCCESSFUL("TRANSFER_SUCCESSFUL", "处理中", "tag-transfer-successful"),

    COMPLETED("COMPLETED", "已完成", null),
    CANCELED("CANCELED", "已取消", null),
    ;

    private final String code;

    private final String desc;

    private final String msgTag;

    private static PurchaseOrderStatusEnum[] ARRAY_TRANSFER = new PurchaseOrderStatusEnum[]{APPROVED, TRANSFER_FAILED};
    private static PurchaseOrderStatusEnum[] ARRAY_COMMIT = new PurchaseOrderStatusEnum[]{PENDING_REVIEW};

    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(v -> v.getCode().equals(code)).map(PurchaseOrderStatusEnum::getDesc)
                .findFirst().orElse(null);
    }

    public static boolean canTransfer(String code) {
        return Arrays.stream(ARRAY_TRANSFER).anyMatch(item -> item.getCode().equals(code));
    }

    public static boolean canCommit(String code) {
        return Arrays.stream(ARRAY_COMMIT).anyMatch(item -> item.getCode().equals(code));
    }

    /**
     * 根据编码获取枚举类型
     */
    public static PurchaseOrderStatusEnum getByCode(String code) {
        //判空
        if (code == null) {
            return null;
        }
        //循环处理
        PurchaseOrderStatusEnum[] values = PurchaseOrderStatusEnum.values();
        for (PurchaseOrderStatusEnum value : values) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        return null;
    }
}
