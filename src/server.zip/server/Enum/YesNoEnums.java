package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@AllArgsConstructor
public enum YesNoEnums {

    /****/
    YES("是"),
    NO("否"),
    Y("Y"),
    N("N");
    @Getter
    private final String value;

    private  final static YesNoEnums[] VIRTUAL_STOCK = {Y,N};
    public  static  boolean exit(String code){
        if (code == null) {
            return false;
        }
        return Arrays.stream(VIRTUAL_STOCK).anyMatch(e -> e.value.equals(code));
    }
}
