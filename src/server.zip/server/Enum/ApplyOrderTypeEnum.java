package com.jiduauto.sps.server.Enum;

import java.util.Arrays;

/**
 * 领料单 领用用途
 */
public enum ApplyOrderTypeEnum {
    AOT21("21","内部领料"),
    AOT23("23","商城销售"),
    AOT27("27","精品销售");
    /**
     * 编码
     */
    private String code;
    /**
     * 描述
     */
    private String desc;
    ApplyOrderTypeEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    public String getCode() {
        return code;
    }
    public String getDesc() {
        return desc;
    }
    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(ApplyOrderTypeEnum::getDesc).findFirst().orElse(null);
    }
    public static String getCode(String desc) {
        return Arrays.stream(values()).filter(item -> item.getDesc().equals(desc)).map(ApplyOrderTypeEnum::getCode).findFirst().orElse(null);
    }

    public static boolean isApplyOrder(String code){
        return Arrays.stream(values()).map(ApplyOrderTypeEnum::getCode).anyMatch(e->e.equals(code));
    }
}
