package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */
@AllArgsConstructor
@Getter
public enum KitOrderStatusEnum {

    /**
     * 待确认、已确认，出库中、已完成
     */

    WAIT_CONFIRM("WAIT_CONFIRM", "待确认"),
    CONFIRMED("CONFIRMED", "已确认"),
    IN_OUTBOUND("IN_OUTBOUND","出库中"),
    CANCELED("CANCELED", "已取消"),
    COMPLETED("COMPLETED", "已完成");

    final static KitOrderStatusEnum[] CAN_CONFIRM = {WAIT_CONFIRM};
    final static KitOrderStatusEnum[] CAN_NOT_DELETE = {CONFIRMED, CONFIRMED, IN_OUTBOUND};
    final static KitOrderStatusEnum[] CAN_OUTBOUND = {CONFIRMED};
    final static KitOrderStatusEnum[] CAN_PUT_IN_STOCK = {IN_OUTBOUND};

    private final String code;
    private final String desc;

    public static boolean canConfirm(String code) {
        return Arrays.stream(CAN_CONFIRM).anyMatch(e -> e.getCode().equals(code));
    }

    public static boolean cannotDelete(String code) {
        return Arrays.stream(CAN_NOT_DELETE).anyMatch(e -> e.getCode().equals(code));
    }

    public static boolean canOutBound(String code) {
        return Arrays.stream(CAN_OUTBOUND).anyMatch(e -> e.getCode().equals(code));
    }

    public static boolean canPutInStock(String code) {
        return Arrays.stream(CAN_PUT_IN_STOCK).anyMatch(e -> e.getCode().equals(code));
    }

    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(v -> v.getCode().equals(code)).map(KitOrderStatusEnum::getDesc)
                .findFirst().orElse(null);
    }


}
