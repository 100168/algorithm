package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;
import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ClassName YNEnums
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/6/21 9:44
 */
@AllArgsConstructor
@Getter
public enum YNEnums {
    /****/
    Y("是","Y"),
    N("否","N"),
    ZERO("是","0"),
    ONE("否","1")
    ;
    private final String value;
    private final String code;
    public  static  String getCode(String value){
        if (value == null) {
            return StringUtils.EMPTY;
        }
        for (YNEnums ynEnums : YNEnums.values()) {
            if (ynEnums.getValue().equals(value)){
                return ynEnums.getCode();
            }
        }
        return StringUtils.EMPTY;
    }
    public  static  String getValue(String code){
        if (code == null) {
            return StringUtils.EMPTY;
        }
        for (YNEnums ynEnums : YNEnums.values()) {
            if (ynEnums.getCode().equals(code)){
                return ynEnums.getValue();
            }
        }
        return StringUtils.EMPTY;
    }
}
