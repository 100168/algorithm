package com.jiduauto.sps.server.Enum;

import lombok.Getter;

import java.util.Arrays;

public enum WorkOrderStatusEnum {

    INIT(0, "初始化"),
    PROCESSING(1, "流程审批中"),
    APPROVED(2, "审批完成"),
    REFUSED(3, "审批拒绝"),
    CANCELLED(4, "已撤销");

    @Getter
    public int status;
    public String desc;

    WorkOrderStatusEnum(int status, String desc) {
        this.status = status;
        this.desc = desc;
    }

    private final static WorkOrderStatusEnum[] ARRAY_END_STATUS = {APPROVED, REFUSED, CANCELLED};


    public static boolean isEndStatus(WorkOrderStatusEnum workOrderStatusEnum) {
        return Arrays.asList(ARRAY_END_STATUS).contains(workOrderStatusEnum);
    }

    public static WorkOrderStatusEnum getByStatus(Integer status) {
        return Arrays.stream(WorkOrderStatusEnum.values()).filter(item -> Integer.valueOf(item.getStatus()).equals(status)).findFirst().orElse(null);
    }
}
