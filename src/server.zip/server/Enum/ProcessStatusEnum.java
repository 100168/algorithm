package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * @ClassName ProcessStatusEnum
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/10/30 14:23
 */
@Getter
public enum ProcessStatusEnum {
    ZERO(0, "待处理"),
    ALREADY_REJECTED(1, "已处理");

    private final int code;
    private final String desc;
    ProcessStatusEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    /**
     * 根据编码获取desc
     */
    public static String getByCode(Integer code) {
        //判空
        if (Objects.isNull(code)) {
            return null;
        }
        //循环处理
        ProcessStatusEnum[] values = ProcessStatusEnum.values();
        for (ProcessStatusEnum value : values) {
            if (value.getCode() == code) {
                return value.desc;
            }
        }
        return null;
    }
}
