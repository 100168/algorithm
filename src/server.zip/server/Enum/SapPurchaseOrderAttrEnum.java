package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@AllArgsConstructor
public enum SapPurchaseOrderAttrEnum {

    /**/
    Z1("Z1", "101"),
    Z2("Z2", "102"),
    ;
    @Getter
    private final String value;
    @Getter
    private final String code;

    public static String getValue(String code) {

        return Arrays.stream(values()).filter(o -> o.getCode().equals(code)).map(SapPurchaseOrderAttrEnum::getValue)
                .findFirst().orElse(null);
    }


}
