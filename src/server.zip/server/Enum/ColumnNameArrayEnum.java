package com.jiduauto.sps.server.Enum;

/**
 * @ClassName ColumnNameArrayEnum
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/6/20 11:17
 */
public enum ColumnNameArrayEnum {
    IN_ORDER_COLUMN(new String[] {"description", "remark", "inQuantity"}),
    IN_ORDER_IMPORT_COLUMN(new String[] {"description", "remark", "inQuantity", "remarkItem"}),
    OUT_ORDER_COLUMN(new String[] {"description", "remark", "outQuantity"}),
    OUT_ORDER_IMPORT_COLUMN(new String[] {"description", "remark", "outQuantity", "remarkItem"}),
    STOCK_UPDATE_ORDER_ITEM_IMPORT_COLUMN(new String[] {"remark", "updateSumQuantity"}),
    APPLY_ORDER_IMPORT_COLUMN(new String[] {"description", "remark", "applySum", "applyRealSum"}),
    WAREHOUSE_DISTRIBUTE_ORDER_IMPORT_COLUMN(new String[] {"description", "remark", "applySum", "applyRealSum"}),
    STOCK_MOVE_ORDER_IMPORT_COLUMN(new String[] {"stockMoveDate", "remark", "moveSumQuantity", "remarkItem"
            , "materialSortCode", "materialStatusCode", "stockStatusCode" }),
    STOCK_CHECK_ITEM_ORDER_IMPORT_COLUMN(new String[] {"materialStatus", "materialSort", "qty", "stockStatus"
            , "firstQty", "secondQty", "finalQty", "qtyReal", "stockCheckOrderNo" }),
    ;

    private String[] nicknames;
    ColumnNameArrayEnum(String[] nicknames) {
        this.nicknames = nicknames;
    }
    public String[] getCode() {
        return nicknames;
    }
}
