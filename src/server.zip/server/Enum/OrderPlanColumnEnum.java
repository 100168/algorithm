package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum OrderPlanColumnEnum {

    COL_QUANTITY("数量"),
    COL_DELIVERY_QTY("发货数量"),
    COL_RECEIVED_QTY("收货数量");

    @Getter
    private final String desc;
}
