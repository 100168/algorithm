package com.jiduauto.sps.server.Enum;

public enum StockBizTypeBean {

    ES("ES","stockESServiceImpl"),
    SP("SP","stockSPServiceImpl"),
    JC("JC","stockJCServiceImpl"),
    SS("SS","stockSSServiceImpl"),
    PK("PK","stockPKServiceImpl"),
    SM("SM","stockSMServiceImpl"),
    CL("CL","stockCLServiceImpl"),
    ;
    private String bizType;
    private String beanName;

    StockBizTypeBean(String bizType, String beanName) {
        this.bizType = bizType;
        this.beanName = beanName;
    }

    public static String getBeanNameByBizType(String bizType){
        for(StockBizTypeBean stockBizTypeBean: StockBizTypeBean.values()){
            if(stockBizTypeBean.bizType.equals(bizType)){
               return stockBizTypeBean.beanName;
            }
        }
        return null;
    }
}
