package com.jiduauto.sps.server.Enum;

import lombok.Getter;

/**
 * @author panjian
 */
public enum RoSyncStatusEnum {

    /**
     * 二进制11,下发index=1and2的接口,1代表待下发或者下发失败
     */
    ALL(3,"全部");

    @Getter
    private final long status;
    @Getter
    private final String desc;

    RoSyncStatusEnum(long status, String desc) {
        this.status = status;
        this.desc = desc;
    }
}
