package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ClassName NumberColumnEnum
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/7/17 16:43
 */
@AllArgsConstructor
public enum NumberColumnEnum {
    businessBillNo("businessBillNo","业务单号"),
    orderNo("orderNo","订单号"),
    logisticNo("logisticNo","运单号"),
    ;
    @Getter
    private String code;
    @Getter
    private String desc;

}
