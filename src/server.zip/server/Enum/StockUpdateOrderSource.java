package com.jiduauto.sps.server.Enum;

import lombok.Getter;

@Getter
public enum StockUpdateOrderSource {
    WEB_COMMIT("WEB_COMMIT","手动提交"),
    SYS_AUTO("SYS_AUTO","系统自动生成"),
    ;

    private final String code;
    private final String desc;

    StockUpdateOrderSource(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
}
