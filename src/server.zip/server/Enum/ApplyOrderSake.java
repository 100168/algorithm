package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;

/**
 * 领料单 领用用途
 */
public enum ApplyOrderSake {
    Z01("01","内部领用",null),
    Z19("Z19","市场活动领用","6601370801"),
    Z31("Z31","销售活动领用","6601370801"),
    Z221("221","研发部门领用","6601430101"),
    Z33("Z33","招待目的赠送外部人员","6601080101"),
    Z35("Z35","公司内部会议领用","6601070101"),
    Z37("Z37","人事相关目的领用-校园招聘活动","6601120501"),
    Z39("Z39","人事相关目的领用-社会招聘活动","6601120101"),
    Z41("Z41","人事相关目的领用-社团活动","6601010201"),
    Z45("Z45","人事相关目的领用-员工福利","6601010290"),
    Z47("Z47","人事相关目的领用-培训活动","6601150201"),
    ;

    public static ApplyOrderSake getByCode(String code){
        if(StringUtils.isBlank(code)){
            return null;
        }
        for(ApplyOrderSake sake:ApplyOrderSake.values()){
            if(sake.code.equals(code)){
                return sake;
            }
        }
        return null;
    }
    ApplyOrderSake(String code, String desc, String costAccount) {
        this.code = code;
        this.desc = desc;
        this.costAccount = costAccount;
    }

    /**
     * 编码
     */
    private String code;
    /**
     * 描述
     */
    private String desc;
    /**
     * 费用科目
     */
    private String costAccount;

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public String getCostAccount() {
        return costAccount;
    }
}
