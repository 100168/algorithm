package com.jiduauto.sps.server.Enum;


import lombok.Getter;

import java.util.Arrays;

@Getter
public enum ClaimStateEnum {
    //这些状态为 SPS 需要的状态, 写死在代码中
    WAIT_AUDIT(0,"待审核"),
    AUDITED(1,"已审核"),
    REJECTED(2,"审核不通过"),
    COMPLETED(3,"已完成"),
    CANCEL(4,"已取消"),

    //其他状态为字典页面维护, 由智子方定义并通知
    ;

    private final int code;
    private final String desc;

    private final static ClaimStateEnum[] IS_AUDIT = {AUDITED, REJECTED, CANCEL};

    ClaimStateEnum(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static ClaimStateEnum getByCode(int code) {
        //循环处理
        ClaimStateEnum[] values = ClaimStateEnum.values();
        for (ClaimStateEnum value : values) {
            if (value.getCode() == code) {
                return value;
            }
        }
        return null;
    }

    public static String getDesc(int code) {
        //循环处理
        ClaimStateEnum[] values = ClaimStateEnum.values();
        for (ClaimStateEnum value : values) {
            if (value.getCode() == code) {
                return value.getDesc();
            }
        }
        return null;
    }

    /**
     * 是否是审核状态
     */
    public static boolean isAudit(int code) {
        return Arrays.stream(IS_AUDIT).anyMatch(item -> item.code == code);
    }


}
