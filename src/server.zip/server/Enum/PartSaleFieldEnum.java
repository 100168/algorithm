package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum PartSaleFieldEnum {

    AIR_PROHIBITION("1", "航空禁运"),
    EXPRESS_PROHIBITION("2", "快递禁运"),
    AIR_AND_EXPRESS_PROHIBITION("3", "航空&快递禁运");

    private final String code;

    private final String name;

    public static PartSaleFieldEnum getByName(String name) {
        return Arrays.stream(values()).filter(item -> item.getName().equals(name)).findFirst().orElse(null);
    }
}
