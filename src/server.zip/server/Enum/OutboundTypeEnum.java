package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */
@Getter
@AllArgsConstructor
public enum OutboundTypeEnum {

    /***/
    VP21("VP21", "试制内领"),
    JADT21("VP21", "智驾内领"),
    JC25("JC25", "精品报废"),
    SP25("SP25", "附件报废"),
    VP25("VP25", "试制报废"),
    JADT25("JADT25", "智驾报废"),
    QE25("QE25", "质量报废"),

    ;

    private final String type;

    private final String desc;

    public static final OutboundTypeEnum[] WDO = {JC25,SP25,VP25,JADT25,QE25};
    public static final OutboundTypeEnum[] APPLY_ORDER = {VP21,JADT21};

    public static boolean isApplyOrder(String type){
        return Arrays.stream(APPLY_ORDER).anyMatch(e-> e.getType().equals(type));
    }
    public static boolean isWdo(String type){
        return Arrays.stream(WDO).anyMatch(e-> e.getType().equals(type));
    }
}
