package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum SaleOrderDfsStatusEnum {

    PENDING("PENDING", "待处理"),
    TRANSFER_FAILED("TRANSFER_FAILED", "转单失败"),
    TRANSFER_SUCCESSFUL("TRANSFER_SUCCESSFUL", "已处理");

    private String code;

    private String desc;

    private final static SaleOrderDfsStatusEnum[] ARRAY_TRANSFER = {PENDING, TRANSFER_FAILED};

    public static String getDesc(String code){

        return Arrays.stream(values()).filter(e-> e.getCode().equals(code)).map(SaleOrderDfsStatusEnum::getDesc).findFirst().orElse(null);
    }

    public static boolean canTransfer(String code) {
        return Arrays.stream(ARRAY_TRANSFER).anyMatch(item -> item.code.equals(code));
    }
}
