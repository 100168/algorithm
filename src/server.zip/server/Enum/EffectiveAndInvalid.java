package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ClassName EffectiveAndInvalid
 * @Description 销售价格状态使用 有效与失效
 * @Author O_chaopeng.huang
 * @Date 2023/11/13 15:24
 */
@Getter
@AllArgsConstructor
public enum EffectiveAndInvalid {
    /**
     *
     */
    Effective("Effective","有效"),
    Invalid("Invalid","失效"),
    ;
    /**
     * 编码
     */
    private final String code;
    /**
     * 注释
     */
    private final String desc;

    /**
      * 根据编码获取名称
      */
    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(v -> v.getCode().equals(code)).map(EffectiveAndInvalid::getDesc)
                .findFirst().orElse(null);
    }
}
