package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
@Getter
public enum PartCategoryEnum {
    SP(2, "SP"),
    JC(6, "JC"),
    ES(5, "ES"),
    VP(7, "VP"),;

    private final Integer code;

    private final String bizType;

    public static String getBizType(Integer code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(PartCategoryEnum::getBizType).findFirst().orElse(null);
    }
    public static Integer getBizCode(String bizType) {
        return Arrays.stream(values()).filter(item -> item.getBizType().equals(bizType)).map(PartCategoryEnum::getCode).findFirst().orElse(null);
    }
}
