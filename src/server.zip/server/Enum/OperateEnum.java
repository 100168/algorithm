package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
@Getter
public enum OperateEnum {

    COMMIT("提交"),
    AUTO_TRANSFER("系统转单"),
    MANUAL_TRANSFER("手动转单"),
    MANUAL_CANCEL_APPLY("手工取消申请"),
    MANUAL_CANCEL_APPROVAL("手工取消审批"),
    MANUAL_CANCEL_APPROVAL_REJECTED("手工取消审批驳回"),
    SCHEDULE_ISSUE_ORDER("系统定时下发订单"),
    DHL_DELIVERED("DHL发货"),
    ASN_DELIVERED("ASN发货"),
    ODIN_RECEIVED("门店收货"),
    ASN_RECEIVED("ASN收货"),
    AUTO_TRANSFER_ORDER_PLAN("系统转采购申请"),
    MANUAL_TRANSFER_ORDER_PLAN("手动转采购申请"),
    CANCEL("取消"),

    AUTO_ISSUE_ORDER("系统自动下发"),
    MANUAL_ISSUE_ORDER("手动下发"),
    //为采购订单结束的一个虚拟动作,
    //全部收货 or 全部取消 or 一部分收货一部分取消
    END("订单完成"),
    ;
    private final String desc;

    private static final OperateEnum[] SYS_OPT_ARR = {AUTO_TRANSFER, SCHEDULE_ISSUE_ORDER, AUTO_TRANSFER_ORDER_PLAN, AUTO_ISSUE_ORDER};

    /**
     * 是否是系统操作
     */
    public static boolean isSystemOpt(OperateEnum opt) {
        return Arrays.asList(SYS_OPT_ARR).contains(opt);
    }

    public static OperateEnum getByCode(String desc) {
        return Arrays.stream(values()).filter(o -> o.getDesc().equals(desc)).findFirst().orElse(null);
    }
}
