package com.jiduauto.sps.server.Enum;

import cn.hutool.core.util.StrUtil;
import com.google.common.collect.ImmutableList;
import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static com.jiduauto.sps.server.Enum.InOutOrder.*;

/**
 * 对应流程代码 & 标识流程订单流转顺序
 */
@Getter
public enum OrderProcessCode {
    P101("101", new InOutOrder[]{PENDING_RECEIVE_LIST, RECEIVE_ORDER, STOCK_IN_ORDER}),
    P102("102", new InOutOrder[]{PENDING_RECEIVE_LIST, STOCK_IN_ORDER}),
    P103("103", new InOutOrder[]{RECEIVE_ORDER, STOCK_IN_ORDER}),
    P104("104", new InOutOrder[]{STOCK_IN_ORDER}),

    P201("201", new InOutOrder[]{OUTBOUND_APPLY_ORDER, PICKING_ORDER, STOCK_OUT_ORDER}),
    P202("202", new InOutOrder[]{OUTBOUND_APPLY_ORDER, STOCK_OUT_ORDER}),
    P203("203", new InOutOrder[]{PICKING_ORDER, STOCK_OUT_ORDER}),
    P204("204", new InOutOrder[]{STOCK_OUT_ORDER}),
    ;

    /**
     * 正常出库流程
     */
    private static final List<InOutOrder> NORMAL_OUT_ORDER = ImmutableList.of(
            OUTBOUND_APPLY_ORDER,
            PICKING_ORDER,
            STOCK_OUT_ORDER
    );

    /**
     * 正常入库流程
     */
    private static final List<InOutOrder> NORMAL_IN_ORDER = ImmutableList.of(
            PENDING_RECEIVE_LIST,
            RECEIVE_ORDER,
            STOCK_IN_ORDER
    );


    private final String code;
    /**
     * 订单流转顺序
     */
    private final InOutOrder[] orderProcess;

    OrderProcessCode(String code, InOutOrder[] orderProcess) {
        this.code = code;
        this.orderProcess = orderProcess;
    }

    /**
     * 用户在页面 点击确认生成下一个订单时 当前流程  是否需要confirm 拣货订单走到下一个流程
     */
    public boolean needConfirmPick() {
        return !Arrays.asList(orderProcess).contains(InOutOrder.PICKING_ORDER);
    }

    /**
     * 用户在页面 点击确认生成下一个订单时 当前流程  是否需要confirm 收货单走到下一个流程
     */
    public boolean needConfirmRack() {
        return !Arrays.asList(orderProcess).contains(RECEIVE_ORDER);
    }

    public static OrderProcessCode getByCode(String code) {
        if (StrUtil.isBlank(code)) {
            return null;
        }
        for (OrderProcessCode orderProcessCode : OrderProcessCode.values()) {
            if (orderProcessCode.code.equals(code)) {
                return orderProcessCode;
            }
        }
        return null;
    }

    /**
     * 根据当前订单是什么  获取下一步要生成什么订单
     */
    public InOutOrder nextOrderByCurrentOrder(InOutOrder order) {
        if (order == null) {
            return orderProcess[0];
        }

        for (int i = 0; i < orderProcess.length; i++) {
            if (orderProcess[i].equals(order)) {
                if (i == orderProcess.length - 1) {
                    return null;
                }
                return orderProcess[i + 1];
            }
        }
        return null;
    }


    /**
     * 根据当前流程, 返回需要预生成的订单
     *
     * @param order 当前需要生成的订单
     * @return 需要提前预生成的订单
     */
    public List<InOutOrder> needPreOutCreateOrder(InOutOrder order) {
        if (order == null) {
            return null;
        }
        //需要生成的订单
        List<InOutOrder> collect = NORMAL_OUT_ORDER.stream().filter(o -> !Arrays.asList(orderProcess).contains(o)).collect(Collectors.toList());
        return collect.stream().filter(o -> o.getOrder() < order.getOrder()).collect(Collectors.toList());
    }

    /**
     * 根据当前流程, 返回需要预生成的订单
     *
     * @param order 当前需要生成的订单
     * @return 需要提前预生成的订单
     */
    public List<InOutOrder> needPreInCreateOrder(InOutOrder order) {
        if (order == null) {
            return null;
        }
        //需要生成的订单
        List<InOutOrder> collect = NORMAL_IN_ORDER.stream().filter(o -> !Arrays.asList(orderProcess).contains(o)).collect(Collectors.toList());
        return collect.stream().filter(o -> o.getOrder() < order.getOrder()).collect(Collectors.toList());
    }

}
