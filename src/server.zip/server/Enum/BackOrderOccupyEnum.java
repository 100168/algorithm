package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum BackOrderOccupyEnum {

    VOR("VOR", "vorBackOrderOccupy"),
    RO("RO", "roBackOrderOccupy"),
    CO("CO", "roBackOrderOccupy"),
    STK("STK", "stkBackOrderOccupy"),
    ;

    private String code;

    private String beanName;

    public static String getBeanNameByCode(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(BackOrderOccupyEnum::getBeanName).findFirst().orElse(null);
    }
}
