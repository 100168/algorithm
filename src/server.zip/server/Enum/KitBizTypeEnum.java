package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * @ClassName KitBizTypeEnum
 * @Description kit主数据业务类型
 * @Author O_chaopeng.huang
 * @Date 2023/7/21 9:15
 */
public enum KitBizTypeEnum {
    SP("备件", "SP"),
    JC("精品", "JC"),
   ;
    /**
     * 业务来源
     */
    private String biz;
    /**
     * 业务类型
     */
    private String bizType;

    KitBizTypeEnum(String biz, String bizType) {
        this.biz = biz;
        this.bizType = bizType;
    }
    private  final static KitBizTypeEnum[] VIRTUAL_STOCK = {SP,JC};
    public  static  boolean exit(String code){
        if (code == null) {
            return false;
        }
        return Arrays.stream(VIRTUAL_STOCK).anyMatch(e -> e.bizType.equals(code));
    }

    public String getBiz() {
        return biz;
    }

    public String getBizType() {
        return bizType;
    }


}
