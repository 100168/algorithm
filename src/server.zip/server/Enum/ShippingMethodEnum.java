package com.jiduauto.sps.server.Enum;


import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum ShippingMethodEnum {

    LTL_LAND("LTL", "零担陆运"),
    AIR("AIR", "空运"),
    EXPRESS("EXP", "快递"),
    SPK("SPK", "自提"),
    NT("NT", "Kit")
    ;

    private final String code;

    private final String method;

    public static String getDesc(String code){

        return Arrays.stream(values()).filter(e-> e.getCode().equals(code)).map(ShippingMethodEnum::getMethod).findFirst().orElse(null);
    }
}
