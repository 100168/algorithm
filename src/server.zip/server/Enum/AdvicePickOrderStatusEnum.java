package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@Getter
@AllArgsConstructor
public enum AdvicePickOrderStatusEnum {

    /***/
    ZERO("zero","库存为0"),
    SUCCESS("success","成功"),
    PART("part","部分可用")
    ;
    private final String code;
    private final  String desc;
}
