package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@AllArgsConstructor
public enum RequirementTypeEnum {

    /**
     * DFS：DFS
     * 定制件：CO
     * 常规订单：1
     * 紧急订单：2
     * 差异补单：20
     * DB子件订单：DB
     * DB总成订单：D
     */
    DFS("DFS", "DFS"),
    CO("CO", "定制订单"),
    NORMAL("1", "常规订单"),
    RO("2", "紧急订单"),
    DIFF("20", "差异补单"),
    DB_SUB("DB", "DB子件订单"),
    DB("D", "DB总成订单"),
    ;

    @Getter
    private final String code;

    @Getter
    private final String desc;

    public static RequirementTypeEnum getByCode(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).findFirst().orElse(null);
    }
    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(RequirementTypeEnum::getDesc).findFirst().orElse(null);
    }
    public static String getCode(String desc) {
        return Arrays.stream(values()).filter(item -> item.getDesc().equals(desc)).map(RequirementTypeEnum::getCode).findFirst().orElse(null);
    }
}
