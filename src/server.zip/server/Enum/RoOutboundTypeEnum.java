package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import lombok.Getter;

/**
 * @author panjian
 */
@Getter
public enum RoOutboundTypeEnum {

    /**SP22        备件采购退货出库
     JC22    精品采购退货出库
     ES22    能源采购退货出库*/
    SP("SP","SP22"),
    JC("JC","JC22"),
    ES("ES","ES22");

    private final String inType;

    private final String outType;

    RoOutboundTypeEnum(String inType, String outType) {
        this.inType = inType;
        this.outType = outType;
    }

    public static String getOutType(String inType){
        return Arrays.stream(values()).filter(o-> o.inType.equals(inType)).map(RoOutboundTypeEnum::getOutType).findFirst().orElse(null);
    }
}
