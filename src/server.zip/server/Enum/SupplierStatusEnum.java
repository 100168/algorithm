package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum SupplierStatusEnum {

    INITIAL("INITIAL", "注册供应商"),
    POTENTIAL("POTENTIAL", "潜在供应商"),
    NOMINATED("NOMINATED", "正式供应商"),
    PHASEOUT_IN("PHASEOUT-IN", "内部淘汰供应商"),
    PHASEOUT_OUT("PHASEOUT-OUT", "外部淘汰供应商");

    @Getter
    private String itemCode;

    @Getter
    private String itemName;


    public static String getDescByCode(String code){
        if(StringUtils.isBlank(code)){
            return  null;
        }
        for(SupplierStatusEnum status:SupplierStatusEnum.values()){
            if(status.itemCode.equals(code)){
                return status.itemName;
            }
        }
        return null;
    }
}
