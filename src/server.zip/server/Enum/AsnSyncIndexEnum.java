package com.jiduauto.sps.server.Enum;

import lombok.Getter;

/**
 * @author panjian
 */

public enum AsnSyncIndexEnum {


    /**
     * WMS
     */
    ES(0, "0位"),
    /**
     * ES
     */
    WMS(1, "1位");
    /**
     * 同步三方接口状态2进制位索引
     */
    @Getter
    private final int bitIndex;
    @Getter
    private final String desc;


    AsnSyncIndexEnum(int bitIndex, String desc) {
        this.bitIndex = bitIndex;
        this.desc = desc;
    }


}
