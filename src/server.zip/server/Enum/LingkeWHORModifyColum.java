package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;


@AllArgsConstructor
@Getter
public enum LingkeWHORModifyColum {

    /***/
    contractName("contractName", "联系人姓名",null),
    contractMobile("contractMobile", "联系人电话",null),
    reissueType("reissueType", "货损货差类型","WHROReissueType"),
    dealWay("dealWay", "处理方式","WHRODealWay"),
    materialCode("materialCode", "售后件号",null),
    wrongQuantity("wrongQuantity", "不良数量",null),
    wrongNo("wrongNo", "不良编号",null),
    wrongType("wrongType", "不良类型","WHROWrongType"),
    wrongReason("wrongReason", "不良原因",null),
    ;
    private final String value;
    private final String desc;
    private final String dictCode;

    public static String getDesc(String colum){
        return Arrays.stream(values()).filter(e-> Objects.equals(e.getValue(), colum)).map(LingkeWHORModifyColum::getDesc).findFirst().orElse("");
    }
    /**
      * 获取对应desc的DictEnum中的code
      */
    public static String selectDictCode(String desc){
        String s = Arrays.stream(values()).filter(e -> StringUtils.isNotBlank(e.getDictCode()) && e.getDesc().equals(desc))
                .map(LingkeWHORModifyColum::getDictCode).findFirst().orElse("");
        return s;
    }
}
