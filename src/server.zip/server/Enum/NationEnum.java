package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;

/**
 * @ClassName NationEnum
 * @AuThor O_chaopeng.huang
 * @Date 2023/5/6 9:46
 * @Version 5.0
 */
public enum NationEnum {
    CN("CN","中国");
    private String code;
    private String desc;

    NationEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static String getDescByCode(String code){
        if(StringUtils.isBlank(code)){
            return null;
        }
        for(NationEnum nationEnum:NationEnum.values()){
            if(nationEnum.code.equals(code)){
                return nationEnum.desc;
            }
        }
        return null;
    }public static String getCodeByDesc(String desc){
        if(StringUtils.isBlank(desc)){
            return null;
        }
        for(NationEnum nationEnum:NationEnum.values()){
            if(nationEnum.desc.equals(desc)){
                return nationEnum.code;
            }
        }
        return null;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
