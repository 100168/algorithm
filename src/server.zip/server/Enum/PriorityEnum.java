package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Objects;

@AllArgsConstructor
public enum PriorityEnum {

    P0_CRITICAL("P0_CRITICAL", "紧急"),
    P1_MAJOR("P1_MAJOR", "高"),
    P2_MEDIUM("P2_MEDIUM", "中"),
    P3_LOW("P3_LOW", "低");

    @Getter
    private final String itemCode;

    @Getter
    private final String itemName;

    public static String convert(Boolean urgent) {
        if (Objects.isNull(urgent)) {
            return null;
        }
        return urgent ? PriorityEnum.P1_MAJOR.getItemCode() : PriorityEnum.P2_MEDIUM.getItemCode();
    }

    public static Boolean convert(String itemCode) {
        if (StringUtils.isEmpty(itemCode)) {
            return null;
        }
        return PriorityEnum.P1_MAJOR.getItemCode().equals(itemCode);
    }
}
