package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum OperateUserEnum {

    SPS("SPS"),
    ODIN("门店"),
    DHL("DHL"),
    LINGKE("领克"),
    ;

    @Getter
    private String name;
}
