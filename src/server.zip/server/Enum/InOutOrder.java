package com.jiduauto.sps.server.Enum;

import lombok.Getter;

/**
 * 出入库相关订单枚举
 */
@Getter
public enum InOutOrder {
    OUTBOUND_APPLY_ORDER(1),
    PICKING_ORDER(2),
    STOCK_OUT_ORDER(3),

    PENDING_RECEIVE_LIST(1),
    RECEIVE_ORDER(2),
    STOCK_IN_ORDER(3);

    private final int order;

    InOutOrder(int order) {
        this.order = order;
    }
}
