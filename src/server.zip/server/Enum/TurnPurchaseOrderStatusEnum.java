package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * 转采购申请订单状态枚举
 * @ClassName TurnPurchaseOrderStatusEnum
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/6/21 10:52
 */
@AllArgsConstructor
@Getter
public enum TurnPurchaseOrderStatusEnum {
    /**/
    TREAT_HANDLE("TREAT_HANDLE", "待处理"),
    PROCESSED("APPROVED", "已处理"),
    TRANSFER_FAILED("TRANSFER_FAILED", "转单失败"),
    ;
    private String code;
    private String desc;
    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(v -> v.getCode().equals(code)).map(TurnPurchaseOrderStatusEnum::getDesc)
                .findFirst().orElse(null);
    }
    public static String getCode(String desc) {
        return Arrays.stream(values()).filter(v -> v.getDesc().equals(desc)).map(TurnPurchaseOrderStatusEnum::getCode)
                .findFirst().orElse(null);
    }

}
