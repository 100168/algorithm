package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;


/**
 * 库存操作日志 出入库类型
 */
@Getter
@AllArgsConstructor
public enum StockLogTransactionType {
    FIRST_PUT_IN("首次入库"),
    PUT_IN("入库"),
    PUT_OUT("出库"),
    ;
    private final String value;
}
