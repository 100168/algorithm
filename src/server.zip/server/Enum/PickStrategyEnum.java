package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@AllArgsConstructor
@Getter
public enum PickStrategyEnum {

    MAX_STOCK_RATE("MAX_STOCK_RATE", "库容率最高"),
    MAX_EFFICIENCY("MAX_EFFICIENCY", "拣货效率最快");

    /**
     * 编码
     */
    private final String code;

    /**
     * 描述
     */
    private final String desc;
}
