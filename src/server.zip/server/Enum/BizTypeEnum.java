package com.jiduauto.sps.server.Enum;

import java.util.Arrays;

/**
 * 业务方 和 业务类型的映射关系
 */
public enum BizTypeEnum {
    /**/
    SP("备件", "SP"),
    JC("精品", "JC"),
    VP("试制", "VP"),
    JADT("智驾", "JADT"),
    SS("备件门店", "SS"),
    PK("包材", "PK"),
    ES("能源", "ES"),
    QE("质量", "QE"),
    CL("工服", "CL"),
    SM("商城", "SM");
    /**
     * 业务来源
     */
    private String biz;
    /**
     * 业务类型
     */
    private String bizType;

    BizTypeEnum(String biz, String bizType) {
        this.biz = biz;
        this.bizType = bizType;
    }


    private  final static BizTypeEnum[] VIRTUAL_STOCK = {SS,SP};
    private  final static BizTypeEnum[] MATERIAL_STOCK_CYCLE_LIFE = {SS,VP,JADT,QE};

    public  static  boolean needVirtualWarehouse(String bizType){
        return Arrays.stream(VIRTUAL_STOCK).anyMatch(e-> e.getBizType().equals(bizType));
    }

    /**
     * 是否需要 计算 库龄
     * @param bizType
     * @return
     */
    public static boolean needMaterialStockCycleLife(String bizType){
        return Arrays.stream(MATERIAL_STOCK_CYCLE_LIFE).anyMatch(e-> e.getBizType().equals(bizType));

    }

    public static BizTypeEnum getByBizType(String bizType) {
        //判空
        if (bizType == null) {
            return null;
        }
        //循环处理
        BizTypeEnum[] values = BizTypeEnum.values();
        for (BizTypeEnum value : values) {
            if (value.getBizType().equals(bizType)) {
                return value;
            }
        }
        return null;
    }

    public String getBiz() {
        return biz;
    }

    public String getBizType() {
        return bizType;
    }

    public static String getNewBizType(String bizType) {

        String newBizType = Arrays.stream(values()).map(BizTypeEnum::getBizType).filter(e -> e.equals(bizType))
                .findFirst()
                .orElse("");
        return newBizType.equals(SP.getBizType()) ? SS.getBizType() : newBizType;


    }

    public static String getParentBizType(String bizType) {

        BizTypeEnum bizTypeEnum = getByBizType(bizType);
        switch (bizTypeEnum){
            case SS:
            case SM :
                return SP.getBizType();
            default:
                return bizType;
        }


    }
}
