package com.jiduauto.sps.server.Enum;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;

/**
 * log key 枚举，一般为记录业务的表名
 */
@Getter
public enum LogKey {
    LINGKE_BACK_ORDER("lingke_back_order"),
    LINGKE_BACK_ORDER_DETAIL("lingke_back_order_detail"),
    LINGKE_SALE_ORDER_DETAIL("lingke_sale_order_detail"),
    LINGKE_SALE_ORDER("lingke_sale_order"),
    FREIGHT_CLAIM("freight_claim"),
    ORDER_PROCESS_CONFIG("order_process_config"),
    ;

    private final String value;
    private  final static List<String> LING_KE_BACK_LOG = Arrays.asList(LINGKE_BACK_ORDER_DETAIL.value,LINGKE_BACK_ORDER.value);
    private  final static List<String> LING_KE_SALE_LOG = Arrays.asList(LINGKE_SALE_ORDER_DETAIL.value,LINGKE_SALE_ORDER.value);
    LogKey(String value) {
        this.value = value;
    }
    /**
      * 领克缺件订单日志key
      */
    public static List<String> getLingKeBackLog() {
        return LING_KE_BACK_LOG;
    }
    /**
     * 领克销售订单日志key
     */
    public static List<String> getLingKeSaleLog() {
        return LING_KE_SALE_LOG;
    }
}
