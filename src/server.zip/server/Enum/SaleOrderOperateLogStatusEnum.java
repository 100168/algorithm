package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */
@Getter
@AllArgsConstructor
public enum SaleOrderOperateLogStatusEnum {
    WAIT_ISSUE("WAIT_ISSUED", "待处理"),
    /*dfs Status*/
    PENDING("PENDING", "待处理"),
    TRANSFER_FAILED("TRANSFER_FAILED", "转单失败"),
    TRANSFER_SUCCESSFUL("TRANSFER_SUCCESSFUL", "已处理"),
    /*sale order Status*/
    PENDING_DELIVERY("PENDING_DELIVERY", "待发货"),
    DELIVERED("DELIVERED", "已发货"),
    PARTIALLY_RECEIVED("PARTIALLY_RECEIVED", "部分收货"),
    CANCELED("CANCELED", "已取消"),
    FULLY_RECEIVED("FULLY_RECEIVED", "全部收货");

    private final String code;

    private final String desc;

    public static String getDesc(String code) {

        return Arrays.stream(values()).filter(e -> e.getCode().equals(code)).map(SaleOrderOperateLogStatusEnum::getDesc)
                .findFirst().orElse(null);
    }
}
