package com.jiduauto.sps.server.Enum;

import com.jiduauto.sps.server.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum AsnSourceEnum {

    EXCEL("EXCEL", "导入创建"),
    API("API", "接口创建");

    @Getter
    private final String code;

    @Getter
    private final String desc;

    /**
     * 为了兼容历史数据，为空则认为是导入的数据
     * @param code
     * @return
     */
    public static boolean createByImport(String code) {
        return StringUtils.isEmpty(code) || AsnSourceEnum.EXCEL.getCode().equals(code);
    }
}
