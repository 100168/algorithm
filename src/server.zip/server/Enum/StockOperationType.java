package com.jiduauto.sps.server.Enum;

import lombok.Getter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 库存 相关操作类型 映射
 */
@Getter
public enum StockOperationType {
    SP_PUT_IN("SP10", "零备件入库"),
    SP_FREE_PUT_IN("SP13", "零备件免费入库"),
    SP18("SP18", "直营索赔回运"),
    SP19("SP19", "授权索赔回运"),
    JC_FREE_PUT_IN("JC13", "精品免费入库"),
    ES_FREE_PUT_IN("ES13", "能源免费入库"),
    SP_OUT_PLAN_PUT_IN("SP14", "计划外订单入库"),
    SP_15("SP15", "零附件KIT入库"),
    SS12_PUT_IN("SS12", "授权门店SO入库"),
    SS11_PUT_IN("SS11", "直营门店SO入库"),
    SS15("SS15", "直营门店反结算入库"),
    SS16("SS16", "授权门店反结算入库"),
    SS17("SS17", "质量旧件入库"),
    ES_PUT_IN("ES10", "能源入库"),
    VC_PUT_IN("VC10", "试制入库"),
    JC_PUT_IN("JC10", "精品入库"),
    JC15("JC15", "精品KIT入库"),


    SP20("SP20", "零备件出库"),
    SP21("SP21", "内部领料出库"),
    SP23("SP23", "商城备件出库"),
    SP_24("SP24", "零附件KIT出库"),
    ES_PUT_OUT("ES20", "能源出库（公桩）"),
    ES_PUT_OUT_1("ES21", "能源出库（家桩）"),
    ES24("ES24", "能源单桩销售出库"),
    CL21("CL21", "工服领料出库"),

    VC_PUT_OUT("VC20", "试制出库"),
    JC_PUT_OUT("JC20", "精品出库"),
    JC21("JC21", "内部领料出库"),
    SS20("SS20", "直营门店结算出库"),
    SS13("SS13", "dfs门店asn"),
    SS14("SS14", "dfs门店asn"),
    SS21("SS21", "授权门店出库"),
    SS23("SS23", "质量旧件出库"),
    SS25("SS25", "直营索赔出库"),
    SS26("SS26", "授权索赔出库"),
    SM20("SM20", "商城出库"),
    SP_UPDATE("SP30", "零备件调整库存"),
    ES_UPDATE("ES30", "能源调整库存"),
    CL_UPDATE("CL30", "能源调整库存"),
    VC_UPDATE("VC30", "试制调整库存"),
    JC_UPDATE("JC30", "精品调整库存"),
    SP22("SP22", "零附件采购退货出库"),
    ES22("ES22", "能源采购退货出库"),
    JC22("JC22", "精品采购退货出库"),
    JC24("JC24", "精品KIT出库"),
    DHL30("DHL30", "dhl调整库存"),
    SM11("SM11", "商场退货入库"),
    SM12("SM12", "一件代发退货入库"),
    JC11("JC11", "精品间采asn"),
    ES11("ES11", "能源间采asn"),
    SP11("SP11", "附件间采asn"),
    CL11("CL11", "工服间采asn"),

    SS18("SS18", "直营门店盘盈"),
    SS28("SS28", "直营门店盘亏"),
    SS19("SS19", "授权门店盘盈"),
    SS29("SS29", "授权门店盘亏"),
    SP16("SP16", "零附件盘盈"),
    SP26("SP26", "零附件盘亏"),
    JC16("JC16", "精品盘盈"),
    JC26("JC26", "精品盘亏"),
    ES16("ES16", "能源盘盈"),
    ES26("ES26", "能源盘亏"),
    ES23("ES23", "能源内领出库"),
    SS201("SS201", "直营门店调拨出库"),
    SS202("SS202", "授权门店调拨出库"),
    SS203("SS203", "直营门店应急调拨出库"),
    SS101("SS101", "直营门店调拨入库"),
    SS102("SS102", "授权门店调拨入库"),
    SS103("SS103", "直营门店应急调拨入库"),
    JC27("JC27", "精品销售出库"),

    SP25("SP25", "附件报废"),
    JC25("JC25", "精品报废"),
    ES25("ES25", "能源报废"),
    ES10("ES10", "能源间直采asn"),

    XNRK("XNRK", "试制虚拟入库"),
    XNCK("XNCK", "试制虚拟出库"),
    //目前只有试制用
    QXSHCK("QXSHCK", "取消收货出库"),

    VP27("VP27", "试制整车出库"),
    ES31("ES31", "能源调拨"),
    ES201("ES201", "能源调拨出库"),
    ES101("ES101", "能源调拨入库"),


    SPS41("SPS41", "库存属性调整"),
    SPS42("SPS42", "库存移动调整"),
    SPS43("SPS43", "后台系统导入"),
    SPS44("SPS44", "系统盘点"),
    SPS45("SPS45", "拣货更新"),
    SPS46("SPS46", "收货入库"),
    SPS47("SPS47", "仓配订单占用"),
    SPS48("SPS48", "上架入库"),
    SPS49("SPS49", "系统占用"),
    SPS50("SPS50", "渠道库存调整"),
    SPS51("SPS51", "短拣冻结"),
    ES42("ES42", "能源占库"),
    INIT("INIT","初始化库存"),

    SP29("SP29", "零附件索赔出库"),
    JC29("JC29", "精品索赔出库"),
    ES29("ES29", "能源索赔出库"),
    CL29("CL29", "工服索赔出库"),

    SP28("SP28", "零附件间采退货"),
    JC28("JC28", "精品间采退货"),
    ES28("ES28", "能源间采退货"),
    CL28("CL28", "工服间采退货"),

    ;
    private final String operationType;
    private final String desc;

    //门店收货需要释放在途库存
    private static final StockOperationType[] PUT_IN_NEED_TRANSMIT_STOCK = {SS11_PUT_IN, SS12_PUT_IN};
    //采购退货反写asn数量
    private static final StockOperationType[] WRITE_ASN_RETURN_QTY = {SP22, ES22, JC22};
    //出库需要新增在途库存
    private static final StockOperationType[] PUT_OUT_NEED_TRANSMIT_STOCK = {SP20, SM20};
    private static final StockOperationType[] PUT_OUT_NEED_APPLY_TRANSMIT_STOCK = {SP21, JC21, CL21, ES23, JC27};
    private static final StockOperationType[] KIT_ORDER_PUT_IN = {SP_15, JC15};
    private static final StockOperationType[] KIT_ORDER_PUT_OUT = {SP_24, JC24};
    private static final StockOperationType[] PUT_OUT_NEED_FROZEN_STOCK = {SP20, JC_PUT_OUT, SP21, JC21, ES23, JC27, CL21};
    //免费入库
    //SO单出库 KIT订单出库  领料出库  采购退货  仓配订单
    private static final StockOperationType[] PUT_OUT_NEED_MAP_BUSINESS_ORDER_STOCK = {SP20, JC_PUT_OUT, SP21, JC21, SP_24, JC24, SP22, JC22, ES22, SM20, JC27, SP29, CL29, JC29, ES29, SP28, ES28, JC28, CL28};
    private static final StockOperationType[] FREE_PUT_IN = {SP_FREE_PUT_IN, JC_FREE_PUT_IN, ES_FREE_PUT_IN};
    private static final StockOperationType[] CLAIM_PUT_IN = {SP18, SP19};
    //直采ASN的入库类型
    private static final StockOperationType[] DIRECT_PURCHASE_ASN = {SP_PUT_IN, JC_PUT_IN, ES_PUT_IN};
    //门店盘盈
    private static final StockOperationType[] STORE_CHECK_PUT_IN = {SS18, SS19};
    //门店盘亏
    private static final StockOperationType[] STORE_CHECK_PUT_OUT = {SS28, SS29};

    //门店调拨出库
    private static final StockOperationType[] STORE_TRANSFER_PUT_OUT = {SS201, SS202, SS203};
    //门店调拨入库
    private static final StockOperationType[] STORE_TRANSFER_PUT_IN = {SS101, SS102, SS103};
    //领料订单出库
    private static final StockOperationType[] APPLY_ORDER_PUT_OUT = {SP21, JC21, ES23, JC27, CL21};
    private static final StockOperationType[] WDO_PUT_OUT = {SM20, SP25, JC25, ES25, ES201, SP29, JC29, ES29, CL29, SP28, ES28, JC28, CL28};
    private static final StockOperationType[] ES_TRANSFER = {ES201, ES101};
    private static final StockOperationType[] TRANSIT_IN = {ES201, SP20, SS25, SS26, SS201, SS202, SM20, SS203};
    private static final StockOperationType[] TRANSIT_OUT = {ES101, SS11_PUT_IN, SS12_PUT_IN, SP18, SP19, SS101, SS102, SS103};
    //索赔出库
    private static final StockOperationType[] CLAIM_OUT = {SP29, JC29, ES29, CL29};
    //间采退货
    private static final StockOperationType[] ASN_RETURN_OUT = {SP28, ES28, JC28, CL28};

    //门店库存价值计算
    private static final StockOperationType[] STOCK_PRICE_COMPUTE_TYPE = {SS11_PUT_IN, SS12_PUT_IN, SS13, SS14, SS101, SS102, SS18, SS19, SS25, SS26, SS28, SS29, SS103};
    //门店库存 入库时间处理 用于计算 库龄
    private  static final StockOperationType[] STORE_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE = {SS11_PUT_IN, SS12_PUT_IN, SS13, SS14, SS101, SS102,  SS103, SS18, SS19};
    //门店库存 出库时间处理 用户计算 库龄
    private static final StockOperationType[] STORE_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE = {SS20, SS21, SS201, SS202,SS203};

    //可以多次出库
    private static final StockOperationType[] SPECIAL_OUT = {JC21, CL21, DHL30, SP20};


    StockOperationType(String operationType, String desc) {
        this.operationType = operationType;
        this.desc = desc;
    }

    private final static StockOperationType[] WAREHOUSE_DISTRIBUTE_OPERATION_TYPE = {SP18, SP19, SM11, ES11, JC11, SP11, CL11, ES101, SM12};
    private final static StockOperationType[] PURCHASE_APPLY_OPERATION_TYPE = {SP_FREE_PUT_IN, SP_OUT_PLAN_PUT_IN, JC_FREE_PUT_IN, ES_FREE_PUT_IN};

    /**
     * 间采asn
     **/
    private final static StockOperationType[] INDIRECT_ASN = {JC11, SP11, ES11, CL11, ES101};


    /**
     * 仓配预收货操作类型校验
     */
    public static boolean indirectAsn(String bizType) {
        return Arrays.stream(INDIRECT_ASN).anyMatch(e ->
                e.getOperationType().equals(bizType));
    }

    /**
     * 仓配预收货操作类型校验
     */
    private final static StockOperationType[] ASN_PUT_IN = {SP_PUT_IN, JC_PUT_IN, ES_PUT_IN};

    public static boolean warehouseDistributeOrderOperationType(String bizType) {
        return Arrays.stream(WAREHOUSE_DISTRIBUTE_OPERATION_TYPE).anyMatch(e ->
                e.getOperationType().equals(bizType));
    }

    public static boolean isAsnPutIn(String operationType) {
        return Arrays.stream(ASN_PUT_IN).anyMatch(e ->
                e.getOperationType().equals(operationType));
    }

    /**
     * 采购申请预收货操作类型校验
     */
    public static boolean purchaseApplyOperationType(String bizType) {
        return Arrays.stream(PURCHASE_APPLY_OPERATION_TYPE).anyMatch(e ->
                e.getOperationType().equals(bizType));
    }

    /**
     * 预收货操作类型存在性校验
     */
    public static String getOperationType(String operationType) {
        return Arrays.stream(values()).map(StockOperationType::getOperationType).filter(type -> type.equals(operationType))
                .findFirst().orElse(null);
    }

    public static String getDescByType(String type) {
        for (StockOperationType temp : StockOperationType.values()) {
            if (temp.getOperationType().equals(type)) {
                return temp.getDesc();
            }
        }
        return type;
    }

    public static StockOperationType getEnumByType(String type) {
        for (StockOperationType temp : StockOperationType.values()) {
            if (temp.getOperationType().equals(type)) {
                return temp;
            }
        }
        return null;
    }


    public String getOperationType() {
        return operationType;
    }

    public String getDesc() {
        return desc;
    }

    public static boolean needTransmitStockIfPutIn(String operationType) {
        return Arrays.stream(PUT_IN_NEED_TRANSMIT_STOCK).anyMatch(o -> o.operationType.equals(operationType));
    }

    public static boolean needTransmitStockIfPutOut(String operationType) {
        return Arrays.stream(PUT_OUT_NEED_TRANSMIT_STOCK).anyMatch(o -> o.operationType.equals(operationType));
    }

    public static boolean needWriteAsnReturnQty(String operationType) {
        return Arrays.stream(WRITE_ASN_RETURN_QTY).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 领料单回写运单号操作类型校验
     */
    public static boolean needWriteApplyLogistic(String operationType) {
        return Arrays.stream(PUT_OUT_NEED_APPLY_TRANSMIT_STOCK).anyMatch(o -> o.operationType.equals(operationType));
    }

    public static boolean isClaimPutIn(String operationType) {
        return Arrays.stream(CLAIM_PUT_IN).anyMatch(o -> o.operationType.equals(operationType));
    }

    public static boolean isStockTransferPutout(String operationType) {
        return Arrays.stream(STORE_TRANSFER_PUT_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }

    public static boolean isStockTransferPutIn(String operationType) {
        return Arrays.stream(STORE_TRANSFER_PUT_IN).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * Kit订单的类型
     *
     * @param operationType
     * @return
     */
    public static boolean kitOrderStock(String operationType) {
        return Arrays.stream(KIT_ORDER_PUT_IN).anyMatch(o -> o.operationType.equals(operationType))
                || Arrays.stream(KIT_ORDER_PUT_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }

    public static boolean kitOrderInStock(String operationType) {
        return Arrays.stream(KIT_ORDER_PUT_IN).anyMatch(o -> o.operationType.equals(operationType));
    }

    public static boolean kitOrderOutStock(String operationType) {
        return Arrays.stream(KIT_ORDER_PUT_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 需要处理短拣，冻结库存的
     */
    public static boolean needFrozenStock(String operationType) {
        return Arrays.stream(PUT_OUT_NEED_FROZEN_STOCK).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 需要总仓出库 关联订单 的出库类型
     *
     * @param operationType
     * @return
     */
    public static boolean needStockOutMapBusiness(String operationType) {
        return Arrays.stream(PUT_OUT_NEED_MAP_BUSINESS_ORDER_STOCK).anyMatch(o -> o.operationType.equals(operationType));
    }


    /**
     * 免费入库同步sap
     */
    public static boolean isFreePutIn(String operationType) {
        return Arrays.stream(FREE_PUT_IN).anyMatch(o -> o.operationType.equals(operationType));
    }


    /**
     * 直采ASN类型
     */
    public static boolean isDirectPurchaseASN(String operationType) {
        return Arrays.stream(DIRECT_PURCHASE_ASN).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 门店盘盈
     */
    public static boolean isStoreCheckPutIn(String operationType) {
        return Arrays.stream(STORE_CHECK_PUT_IN).anyMatch(o -> o.operationType.equals(operationType));
    }


    /**
     * 门店盘亏
     */
    public static boolean isStoreCheckPutOut(String operationType) {
        return Arrays.stream(STORE_CHECK_PUT_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 领料出库
     */
    public static boolean isApplyOrderPutOut(String operationType) {
        return Arrays.stream(APPLY_ORDER_PUT_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 仓配出库
     */
    public static boolean isWDOPutOut(String operationType) {
        return Arrays.stream(WDO_PUT_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 能源调拨
     */
    public static boolean isESTransfer(String operationType) {
        return Arrays.stream(ES_TRANSFER).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 在途库存创建
     */
    public static boolean needTransitIn(String operationType) {
        return Arrays.stream(TRANSIT_IN).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 在途库存出库
     */
    public static boolean needTransitOut(String operationType) {
        return Arrays.stream(TRANSIT_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }


    /**
     * 索赔出库
     */
    public static boolean isClaimOut(String operationType) {
        return Arrays.stream(CLAIM_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 间采退货出库
     */
    public static boolean isAsnReturnOut(String operationType) {
        return Arrays.stream(ASN_RETURN_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 库存价值计算
     */
    public static boolean isStockPriceCompute(String operationType) {
        return Arrays.stream(STOCK_PRICE_COMPUTE_TYPE).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 门店 库存生命周期计算-入库
     */
    public static boolean isStoreStockInLifeCycle(String operationType) {
        return Arrays.stream(STORE_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 门店 库存生命周期计算-出库
     */
    public static boolean isStoreStockOutLifeCycle(String operationType) {
        return Arrays.stream(STORE_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE).anyMatch(o -> o.operationType.equals(operationType));
    }

    /**
     * 可多次出库
     */
    public static boolean isSpecialOut(String operationType) {
        return Arrays.stream(SPECIAL_OUT).anyMatch(o -> o.operationType.equals(operationType));
    }

    public static List<String> arrayStoreStockOutLifeCycle() {
        List<String> list = new ArrayList<>();
        for(StockOperationType o : STORE_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE) {
            list.add(o.operationType);
        }
        return list;
    }

    public static List<String> arrayStoreStockInLifeCycle() {
        List<String> list = new ArrayList<>();
        for(StockOperationType o : STORE_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE) {
            list.add(o.operationType);
        }
        return list;
    }
}
