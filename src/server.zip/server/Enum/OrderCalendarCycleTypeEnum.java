package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

/**
 * @author panjian
 */
@AllArgsConstructor
public enum OrderCalendarCycleTypeEnum {
    /**/
    WEEK(0, "周"),
    MONTH(1, "月"),
    ;
    @Getter
    private final Integer value;
    @Getter
    private final String desc;

    public static OrderCalendarCycleTypeEnum getType(int type) {
        return Arrays.stream(values())
                .filter(orderCalendarCycleTypeEnum -> orderCalendarCycleTypeEnum.getValue() == type).findFirst()
                .orElse(null);
    }
}
