package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Getter
@AllArgsConstructor
public enum PutOutBusinessTypeEnum {
    LLCK("LLCK","领料出库-手工创建"),
    FXCK("FXCK","返修出库"),
    BFCK("BFCK","报废出库"),
    JYCK("JYCK","借用出库"),
    YCLL("YCLL","异常领料"),
    YKCK("YKCK","移库出库"),
    SYS_21("21","领料出库-系统生成"),
    VP25("VP25","报废出库"),
    XNCK("XNCK","虚拟出库"),
    VP27("VP27","整车拉料出库"),
    VP26("VP26","盘亏出库"),
    QE20("QE20","旧件出库-供应商"),
    QE21("QE21","旧件出库-吉利"),
    QE22("QE22","旧件出库-集度"),
    QE25("QE25","质量报废"),
    ;


    private final String type;
    private final String desc;
    //试制库存 出库时间处理 用户计算 库龄
    private static final PutOutBusinessTypeEnum[] VP_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE = {LLCK,FXCK,BFCK,JYCK,YCLL,YKCK,SYS_21,VP25,XNCK,VP27,VP26};
    //智驾库存 出库时间处理 用户计算 库龄
    private static final PutOutBusinessTypeEnum[] JADT_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE = {LLCK,FXCK,BFCK,JYCK,YCLL,YKCK,SYS_21};
    //质量库存 出库时间处理 用户计算 库龄
    private static final PutOutBusinessTypeEnum[] QE_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE = {BFCK,QE20,QE21,QE22};

    /**
     * 试制 库存生命周期计算-出库
     */
    public static boolean isVpStockOutLifeCycle(String type) {
        return Arrays.stream(VP_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE).anyMatch(o -> o.type.equals(type));
    }
    /**
     * 智驾 库存生命周期计算-出库
     */
    public static boolean isJADTStockOutLifeCycle(String type) {
        return Arrays.stream(JADT_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE).anyMatch(o -> o.type.equals(type));
    }
    /**
     * 质量 库存生命周期计算-出库
     */
    public static boolean isQEStockOutLifeCycle(String type) {
        return Arrays.stream(QE_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE).anyMatch(o -> o.type.equals(type));
    }



    public static List<String> arrayVpStockOutLifeCycle() {
        List<String> list = new ArrayList<>();
        for(PutOutBusinessTypeEnum o : VP_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE) {
            list.add(o.type);
        }
        return list;
    }


    public static List<String> arrayJADTStockOutLifeCycle() {
        List<String> list = new ArrayList<>();
        for(PutOutBusinessTypeEnum o : JADT_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE) {
            list.add(o.type);
        }
        return list;
    }

    public static List<String> arrayQEStockOutLifeCycle() {
        List<String> list = new ArrayList<>();
        for(PutOutBusinessTypeEnum o : QE_STOCK_OUT_LIFE_CYCLE_COMPUTE_TYPE) {
            list.add(o.type);
        }
        return list;
    }
}
