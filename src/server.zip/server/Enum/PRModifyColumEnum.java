package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

/**
 * @author panjian
 */

@AllArgsConstructor
@Getter
public enum PRModifyColumEnum {

    /***/
    QTY("qty","数量"),
    DELIVER_QTY("deliverQty","发货数量"),
    RECEIVE_QTY("receiveQty","收货数量"),
    EST_ARRIVAL_TIME("estArrivalTime","预计到货日期");
    private final String value;
    private final String desc;

    public static String getDesc(String colum){
        return Arrays.stream(values()).filter(e-> Objects.equals(e.getValue(), colum)).map(PRModifyColumEnum::getDesc).findFirst().orElse("");
    }

}
