package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * 采购订单类型
 * @author panjian
 */

@AllArgsConstructor
public enum PurchaseOrderTypeEnum {

    /***/
    STK("STK", 4),
    RO("RO", 2),
    //定制件
    CO("CO", 3),
    VOR("VOR", 1)
    ;

    @Getter
    private final String value;

    @Getter
    private final int priority;

    public static int covetPriority(String value) {
        return Arrays.stream(values()).filter(item -> item.getValue().equals(value)).map(PurchaseOrderTypeEnum::getPriority).findFirst().orElse(Integer.MAX_VALUE);
    }
}
