package com.jiduauto.sps.server.Enum;

/**
 * 入库单 的数据来源
 */
public enum StockInOrderSourceEnum {
    SYS("SYS","后台人工录入"),
    API("API","业务方调用API接口自动生成"),
    RO("RO","收货单自动生成")
    ;

    StockInOrderSourceEnum(String source, String desc) {
        this.source = source;
        this.desc = desc;
    }

    private String source;
    private String desc;

    public String getSource() {
        return source;
    }

    public String getDesc() {
        return desc;
    }
}
