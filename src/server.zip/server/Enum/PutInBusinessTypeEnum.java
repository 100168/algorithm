package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author panjian
 */
@Getter
@AllArgsConstructor
public enum PutInBusinessTypeEnum {

    /**业务入库类型*/
    SS12("SS12","SO收货"),
    CGRK("CGRK","采购入库"),
    FXRK("FXRK","返修入库"),
    THRK("THRK","退货入库"),
    LLRK("LLRK","领料入库"),
    JYRK("JYRK","借用入库"),
    YKRK("YKRK","移库入库"),
    GCSTG("GCSTG","工程师提供"),
    GYSTG("GYSTG","供应商免费提供"),
    SHLL("SHLL","售后领料"),
    XNRK("XNRK","虚拟入库"),
    ASN("ASN","ASN入库"),
    QE11("QE11","普返"),
    QE12("QE12","快返至仓库"),
    ;

    private final String type;
    private final String desc;

    private static final PutInBusinessTypeEnum[] NEED_TRANSMIT ={SS12};



    //试制库存 入库时间处理 用于计算 库龄
    private  static final PutInBusinessTypeEnum[] VP_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE = {CGRK,FXRK,THRK,LLRK,JYRK,YKRK,GCSTG,GYSTG,SHLL,XNRK,ASN};
     //智驾库存 入库时间处理 用于计算 库龄
    private  static final PutInBusinessTypeEnum[] JADT_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE = {CGRK,FXRK,THRK,LLRK,JYRK,YKRK};
      //质量库存 入库时间处理 用于计算 库龄
    private  static final PutInBusinessTypeEnum[] QE_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE = {QE12,QE11};


    /**
     * 试制 库存生命周期计算-入库
     */
    public static boolean isVpStockInLifeCycle(String type) {
        return Arrays.stream(VP_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE).anyMatch(o -> o.type.equals(type));
    }
    /**
     * 智驾 库存生命周期计算-入库
     */
    public static boolean isJADTStockInLifeCycle(String type) {
        return Arrays.stream(JADT_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE).anyMatch(o -> o.type.equals(type));
    }
    /**
     * 质量 库存生命周期计算-入库
     */
    public static boolean isQEStockInLifeCycle(String type) {
        return Arrays.stream(QE_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE).anyMatch(o -> o.type.equals(type));
    }

    public static List<String> arrayVpStockInLifeCycle() {
        List<String> list = new ArrayList<>();
        for(PutInBusinessTypeEnum o : VP_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE) {
            list.add(o.type);
        }
        return list;
    }


    public static List<String> arrayJADTStockInLifeCycle() {
        List<String> list = new ArrayList<>();
        for(PutInBusinessTypeEnum o : JADT_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE) {
            list.add(o.type);
        }
        return list;
    }

    public static List<String> arrayQEStockInLifeCycle() {
        List<String> list = new ArrayList<>();
        for(PutInBusinessTypeEnum o : QE_STOCK_IN_LIFE_CYCLE_COMPUTE_TYPE) {
            list.add(o.type);
        }
        return list;
    }
}
