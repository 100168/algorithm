package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

/**
 * @author panjian
 */

@AllArgsConstructor
@Getter
public enum OutApplyOrderStatus {

    /**/
    PUT("PUT_IN", "已输入"),
    CONFIRM("CONFIRM", "已确认"),
    PART_CONFIRM("PART_CONFIRM", "部分确认"),
    REPEALED("REPEALED", "已撤销");


    /**
     * 编码
     */
    private final String code;

    /**
     * 描述
     */
    private final String desc;

    static final OutApplyOrderStatus[] CAN_PICK = {PUT, PART_CONFIRM};
    static final OutApplyOrderStatus[] CAN_Repeal = {PUT};

    public static boolean cannotPick(String code){
        return Arrays.stream(CAN_PICK).noneMatch(e-> e.getCode().equals(code));
    }

    public static boolean cannotRepeal(String code){
        return Arrays.stream(CAN_PICK).noneMatch(e-> e.getCode().equals(code));
    }
    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(item -> item.getCode().equals(code)).map(OutApplyOrderStatus::getDesc).findFirst().orElse(null);
    }
    public static String getCode(String desc) {
        return Arrays.stream(values()).filter(item -> item.getDesc().equals(desc)).map(OutApplyOrderStatus::getCode).findFirst().orElse(null);
    }
}
