package com.jiduauto.sps.server.Enum;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */

@Getter
@AllArgsConstructor
public enum PickingOrderStatusEnum {


    /**/
    PUT_IN("PUT_IN", "已输入"),
    PICKED("PICKED", "已拣货"),
    CONFIRMED("CONFIRMED", "已确认"),
    CLOSED("CLOSED", "已关闭")
    ;

    static final PickingOrderStatusEnum[] CAN_CONFIRM = {PICKED};
    static final PickingOrderStatusEnum[] CAN_CANCEL = {PUT_IN,PICKED};
    static final PickingOrderStatusEnum[] CAN_PRINT = {PICKED,PUT_IN};
    static final PickingOrderStatusEnum[] CHANGE_VALUE = {PICKED,PUT_IN,CLOSED};
    /**
     * 编码
     */
    private final String code;

    /**
     * 描述
     */
    private final String desc;

    public static boolean canConfirm(String code){
        return Arrays.stream(CAN_CONFIRM).anyMatch(e-> e.getCode().equals(code));
    }
    public static boolean canCancel(String code){
        return Arrays.stream(CAN_CANCEL).anyMatch(e-> e.getCode().equals(code));
    }
    public static boolean canNotPrint(String code){
        return Arrays.stream(CAN_PRINT).noneMatch(e -> e.getCode().equals(code));
    }
    public static boolean changeValue(String code){
        return Arrays.stream(CHANGE_VALUE).anyMatch(e-> e.getCode().equals(code));
    }
}
