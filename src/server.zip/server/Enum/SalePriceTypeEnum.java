package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ClassName SalePriceTypeEnum
 * @Description 销售价格类型枚举
 * @Author O_chaopeng.huang
 * @Date 2023/8/22 17:29
 */
@Getter
@AllArgsConstructor
public enum SalePriceTypeEnum {
    B("B", "授权钣喷采购价"),
    M("M", "建议市场零售价"),
    J("J", "服务中心采购价")
    ;

    private final String code;

    private final String name;


}
