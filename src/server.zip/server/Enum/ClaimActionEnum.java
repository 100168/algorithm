package com.jiduauto.sps.server.Enum;


import com.jiduauto.sps.server.utils.StringUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
@AllArgsConstructor
public enum ClaimActionEnum {
    DEFINE_RESPONSIBILITY(11, "责任认定"),
    TWO_DEFINE_RESPONSIBILITY(12, "二次责任认定"),
    PASS(1, "通过"),
//    REJECT(2, "驳回"),
//    REFUSE(4, "拒绝"),
    ;
    private final int code;
    private final String desc;

    public static String getDesc(Integer code) {
        if (Objects.isNull(code)){
            return StringUtils.EMPTY;
        }
        return Arrays.stream(values()).filter(item -> item.getCode() == code).map(ClaimActionEnum::getDesc).findFirst().orElse("");
    }

}
