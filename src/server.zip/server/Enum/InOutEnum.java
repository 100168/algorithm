package com.jiduauto.sps.server.Enum;

import com.google.common.collect.ImmutableList;
import lombok.Getter;

import java.util.List;

/**
 * 出入库枚举
 */
@Getter
public enum InOutEnum {
    IN("入库"),
    OUT("出库");

    public static final List<String> OUT_CODE_LIST = ImmutableList.of(
            OrderProcessCode.P201.getCode(),
            OrderProcessCode.P202.getCode(),
            OrderProcessCode.P203.getCode(),
            OrderProcessCode.P204.getCode()
    );
    public static final List<String> IN_CODE_LIST = ImmutableList.of(
            OrderProcessCode.P101.getCode(),
            OrderProcessCode.P102.getCode(),
            OrderProcessCode.P103.getCode(),
            OrderProcessCode.P104.getCode()
    );
    private final String name;

    InOutEnum(String name) {
        this.name = name;
    }


    public static InOutEnum getByCode(String processCode) {
        if (OUT_CODE_LIST.contains(processCode)) {
            return OUT;
        } else {
            return IN;
        }
    }

    public List<String> getCodeList() {
        if (this.equals(IN)) {
            return IN_CODE_LIST;
        }
        return OUT_CODE_LIST;
    }
}
