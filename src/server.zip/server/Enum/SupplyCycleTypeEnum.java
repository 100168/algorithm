package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum SupplyCycleTypeEnum {

    WEEKLY("SCT_WEEKLY", "按周"),
    MONTHLY("SCT_MONTHLY", "按月");

    @Getter
    private final String itemCode;

    @Getter
    private final String itemName;
}
