package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author panjian
 */
@Getter
@AllArgsConstructor
public enum InboundTypeEnum {

    /***/
    KIT("15","kit入库"),
    ;

    private final String type;

    private final String desc;
}
