package com.jiduauto.sps.server.Enum;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum BackOrderStatusEnum {
    PENDING("PENDING", "待处理", "tag-pending"),
    CLOSED("CLOSED", "关闭", "tag-closed"),
    TRANSFER_FAILED("TRANSFER_FAILED", "转单失败", "tag-transfer-failed"),
    @Deprecated
    PROCESSING("PROCESSING", "处理中", "tag-processing"),
    CANCEL_PENDING("CANCEL_PENDING", "取消审批中", "tag-cancel-pending"),
    CANCELED("CANCELED", "已取消", "tag-canceled");

    private String code;

    private String desc;

    private String msgTag;

    private final static BackOrderStatusEnum[] ARRAY_CANCEL = {PENDING, TRANSFER_FAILED, PROCESSING};

    private final static BackOrderStatusEnum[] ARRAY_TRANSFER = {PENDING, TRANSFER_FAILED, PROCESSING};

    private final static BackOrderStatusEnum[] ARRAY_SHOW_BO_TIME = {PENDING, TRANSFER_FAILED, PROCESSING};

    public static boolean canCancel(String code) {
        return Arrays.stream(ARRAY_CANCEL).anyMatch(item -> item.code.equals(code));
    }

    public static boolean canTransfer(String code) {
        return Arrays.stream(ARRAY_TRANSFER).anyMatch(item -> item.code.equals(code));
    }

    public static String getDesc(String code) {
        return Arrays.stream(values()).filter(e -> e.getCode().equals(code)).map(BackOrderStatusEnum::getDesc).findFirst().orElse(null);
    }

    public static String getMsgTag(String code) {
        return Arrays.stream(values()).filter(e -> e.getCode().equals(code)).map(BackOrderStatusEnum::getMsgTag).findFirst().orElse(null);
    }
}
