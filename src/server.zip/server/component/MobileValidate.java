package com.jiduauto.sps.server.component;

import com.jiduauto.sps.server.annotation.MobileCheck;
import com.jiduauto.sps.server.utils.ParamCheckUtil;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * 联系方式校验
 */
public class MobileValidate implements ConstraintValidator<MobileCheck, String> {
    @Override
    public void initialize(MobileCheck constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return ParamCheckUtil.matchPhoneNumber(value);
    }
}
