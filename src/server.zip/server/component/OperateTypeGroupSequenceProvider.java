package com.jiduauto.sps.server.component;


import com.jiduauto.sps.server.Enum.OperateTypeEnum;
import com.jiduauto.sps.server.pojo.vo.req.SpsOperateReq;
import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author tao.wang
 * @date 2023/1/4
 * @description
 */
public class OperateTypeGroupSequenceProvider implements DefaultGroupSequenceProvider<SpsOperateReq> {

    @Override
    public List<Class<?>> getValidationGroups(SpsOperateReq req) {
        List<Class<?>> defaultGroupSequence = new ArrayList<>();
        defaultGroupSequence.add(SpsOperateReq.class);
        if (req != null) {
            String operateType = req.getOperateType();
            OperateTypeEnum operateTypeEnum = OperateTypeEnum.getByCode(operateType);
            if (Objects.isNull(operateTypeEnum)){
                return defaultGroupSequence;
            }
            switch (operateTypeEnum){
                case SAVE:
                    defaultGroupSequence.add(SpsOperateReq.SaveGroup.class);
                    break;
                case UPDATE:
                    defaultGroupSequence.add(SpsOperateReq.UpdateGroup.class);
                    break;
                case CANCEL:
                    defaultGroupSequence.add(SpsOperateReq.CancelGroup.class);
                    break;
                default:
                    break;
            }
        }
        return defaultGroupSequence;
    }
}
