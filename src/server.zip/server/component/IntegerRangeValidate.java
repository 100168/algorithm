package com.jiduauto.sps.server.component;

import com.jiduauto.sps.server.annotation.IntegerRange;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author jian.pan
 * @date 5/22/23 1:41 PM
 */
public class IntegerRangeValidate implements ConstraintValidator<IntegerRange,Integer> {

    private List<String> rangeList;

    @Override
    public void initialize(IntegerRange constraintAnnotation) {
     this.rangeList = Arrays.asList(constraintAnnotation.value());
    }

    @Override
    public boolean isValid(Integer s, ConstraintValidatorContext constraintValidatorContext) {
        if(s==null){
            return true;
        }
        return rangeList.contains(String.valueOf(s));
    }
}
