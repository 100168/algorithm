package com.jiduauto.sps.server.component;

import com.jiduauto.sps.server.Enum.ApplyTypeEnum;
import com.jiduauto.sps.server.pojo.vo.req.ApplyOrderAddWithExcelReq;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;

/**
 * @author panjian
 */
public class ApplyImportGroupSequenceProvider implements DefaultGroupSequenceProvider<ApplyOrderAddWithExcelReq> {

    @Override
    public List<Class<?>> getValidationGroups(ApplyOrderAddWithExcelReq bean) {
        List<Class<?>> defaultGroupSequence = new ArrayList<>();
        defaultGroupSequence.add(ApplyOrderAddWithExcelReq.class);
        // 这块判空请务必要做
        if (bean != null) {
            String type = bean.getApplyType();
            if (type.equals(ApplyTypeEnum.EXP.getCode())){
                    defaultGroupSequence.add(ApplyOrderAddWithExcelReq.ApplyType.class);
            }
        }
        return defaultGroupSequence;
    }
}
