package com.jiduauto.sps.server.component;

import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.server.annotation.BizCheck;
import com.jiduauto.sps.server.consts.DictEnum;
import com.jiduauto.sps.server.service.IDictService;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * @author tao.wang
 * @date 2022/8/2
 * @description 字典值校验 目前校验 bizType
 */
public class BizVaildate implements ConstraintValidator<BizCheck,String> {

    private DictEnum dictEnum;
    @Autowired
    private IDictService dictService;

    @Override
    public void initialize(BizCheck constraintAnnotation) {
        this.dictEnum =constraintAnnotation.biz();
    }

    /**
     * 目前只到 字典表校验，如需要可以加上到passport 校验
     * @param value
     * @param context
     * @return
     */
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if(StrUtil.isEmpty(value)){
            return true;
        }
        return dictService.isContained(value,dictEnum);
    }

}
