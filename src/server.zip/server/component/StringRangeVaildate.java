package com.jiduauto.sps.server.component;

import com.jiduauto.sps.server.annotation.StringRange;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Arrays;
import java.util.List;

/**
 * @author tao.wang
 */
public class StringRangeVaildate implements ConstraintValidator<StringRange,String> {

    private List<String> rangeList;

    @Override
    public void initialize(StringRange constraintAnnotation) {
     this.rangeList = Arrays.asList(constraintAnnotation.value());
    }

    @Override
    public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {
        if(s==null){
            return true;
        }
        return rangeList.contains(s);
    }
}
