package com.jiduauto.sps.server.aspect;

import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.po.InvokeLogPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.service.IInvokeLogService;
import com.jiduauto.sps.server.utils.FileUtil;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.util.concurrent.CompletableFuture;

/**
 * 请求日志存储
 */

@Aspect
@Component
@Slf4j
public class InvokeLogAspect {

    @Autowired
    private IInvokeLogService invokeLogService;

    @Resource
    private ThreadPoolTaskExecutor threadPoolTaskExecutor;

    @Pointcut("@annotation(com.jiduauto.sps.server.annotation.InvokeLog)")
    public void pointcut() {
    }

    @Around("pointcut()")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        InvokeLogPo invokeLogPo = new InvokeLogPo();
        String classname = pjp.getThis().getClass().getName();
        classname = classname.substring(35,classname.indexOf("$"));
        invokeLogPo.setClassName(classname);
        invokeLogPo.setMethodName(pjp.getSignature().getName());
        Object[] args = pjp.getArgs();
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < args.length; i++) {
            if (args[i] instanceof MultipartFile) {
                continue;
            }
            sb.append(JSON.toJSONString(args[i]));
        }
        invokeLogPo.setRequest(sb.toString());
        Object result = pjp.proceed();
        String resp = JSON.toJSONString(result);
        if(resp.length() > 1000){
            invokeLogPo.setResponse(resp.substring(0,1000));
        }else{
            invokeLogPo.setResponse(resp);
        }
        invokeLogPo.setCreateUser(UserUtil.getUserName());
        try{
            invokeLogService.save(invokeLogPo);
            for(int i = 0; i < args.length; i++){
                if(args[i] instanceof MultipartFile ){
                    MultipartFile file = (MultipartFile) args[i];
                    BaseResult<ImportResultResp> baseResult = (BaseResult)result;
                    if(baseResult.isSuccess() && baseResult.getData().getImportFlag()){
                        String fileName = System.currentTimeMillis()+file.getOriginalFilename();
                        File tempFile = FileUtil.saveFileToLocal(file.getInputStream(), fileName,FileUtil.SUFFIX);
                        CompletableFuture.runAsync(() -> {
                            invokeLogService.updateRequestUrl(invokeLogPo.getId(),fileName ,tempFile);
                        }, threadPoolTaskExecutor);
                    }
                }
            }
        }catch (Exception e){
            log.error("调用日志保存异常",e);
        }
        return result;
    }

}
