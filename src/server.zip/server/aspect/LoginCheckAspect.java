package com.jiduauto.sps.server.aspect;

import com.jiduauto.sps.server.annotation.LoginCheck;
import com.jiduauto.sps.server.utils.UserUtil;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * 登陆校验切面
 * @author tao.wang
 */
@Aspect
@Component
public class LoginCheckAspect {
    @Pointcut("@annotation(com.jiduauto.sps.server.annotation.LoginCheck)")
    public void pointcut() {
    }

    @Before("pointcut()")
    public void checkBefore(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        LoginCheck loginCheck = method.getAnnotation(LoginCheck.class);
        if (loginCheck.required()) {
            UserUtil.getLoginUserInfo();
        }
    }
}
