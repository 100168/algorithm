package com.jiduauto.sps.server.aspect;

import cn.hutool.json.JSONUtil;
import com.jiduauto.sps.server.pojo.BasePageParam;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdviceAdapter;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Objects;

/**
 * @author tao.wang
 * @date 2022/12/16
 * @description 由于前端不愿意将biztype 放到body 里面，更希望放到 header 里面，所以加个切面
 * 也可以使用 过滤器或者拦截器 实现
 */
@ControllerAdvice
@Slf4j
public class BizTypeRequestAdviceAdapter extends RequestBodyAdviceAdapter {

    private static final String BIZ ="bizType";

    @Override
    public boolean supports(MethodParameter methodParameter, Type targetType, Class<? extends HttpMessageConverter<?>> converterType) {
        // req 是spsBaseReq 或者 是basePageParam
        Class parameterType = methodParameter.getParameterType();
        Type type = methodParameter.getGenericParameterType();
        if (com.jiduauto.sps.server.pojo.vo.SpsBaseReq.class.isAssignableFrom(parameterType)||
                com.jiduauto.sps.sdk.pojo.req.SpsBaseReq.class.isAssignableFrom(parameterType)){
            return true;
        }

        if(type instanceof  ParameterizedType){
            ParameterizedType typeArgument = (ParameterizedType) methodParameter.getGenericParameterType();
            Class genericType = (Class) typeArgument.getActualTypeArguments()[0];
            if (com.jiduauto.sps.server.pojo.vo.SpsBaseReq.class.isAssignableFrom(genericType)||
                    com.jiduauto.sps.sdk.pojo.req.SpsBaseReq.class.isAssignableFrom(genericType)){
                return true;
            }
        }
        return false;
    }

    @Override
    public HttpInputMessage beforeBodyRead(HttpInputMessage inputMessage, MethodParameter parameter,
                                           Type targetType, Class<? extends HttpMessageConverter<?>> converterType) throws IOException {
        Class parameterType = parameter.getParameterType();
        return new HttpInputMessage() {
            @Override
            public InputStream getBody() throws IOException {
                HttpHeaders headers = inputMessage.getHeaders();
                if (Objects.isNull(headers.get(BIZ))) {
                    return inputMessage.getBody();
                }
                String bizType = headers.get(BIZ).get(0);
                String body = IOUtils.toString(inputMessage.getBody());
                //  Map paramMap = JSONUtil.toBean(body,Map.class);
                Object o;
                if (com.jiduauto.sps.server.pojo.vo.SpsBaseReq.class.isAssignableFrom(parameterType) ||
                        com.jiduauto.sps.sdk.pojo.req.SpsBaseReq.class.isAssignableFrom(parameterType)) {
                    Map spsBaseReq = JSONUtil.toBean(body, Map.class);
                    spsBaseReq.put(BIZ,bizType);
                    o=spsBaseReq;
                } else {
                    BasePageParam param = JSONUtil.toBean(body,BasePageParam.class);
                    Map data = (Map) param.getParam();
                    data.put(BIZ, bizType);
                    o=param;
                }
                return new ByteArrayInputStream(JSONUtil.toJsonStr(o).getBytes(StandardCharsets.UTF_8));
            }

            @Override
            public HttpHeaders getHeaders() {
                return inputMessage.getHeaders();
            }
        };
    }

}