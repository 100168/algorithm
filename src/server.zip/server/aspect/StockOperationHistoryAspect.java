package com.jiduauto.sps.server.aspect;

import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.server.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.server.pojo.po.InvokeLogPo;
import com.jiduauto.sps.server.pojo.po.StockOperationHistoryPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.service.IInvokeLogService;
import com.jiduauto.sps.server.service.IStockOperationHistoryService;
import com.jiduauto.sps.server.utils.FileUtil;
import com.jiduauto.sps.server.utils.UserUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.util.concurrent.CompletableFuture;

/**
 * 请求日志存储
 */

@Aspect
@Component
@Slf4j
public class StockOperationHistoryAspect {

    @Autowired
    private IStockOperationHistoryService stockOperationHistoryService;

    @Pointcut("@annotation(com.jiduauto.sps.server.annotation.StockOperationHistory)")
    public void pointcut() {
    }

    @Around("pointcut()")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        StockOperationHistoryPo invokeLogPo = new StockOperationHistoryPo();
        Object[] args = pjp.getArgs();
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < args.length; i++) {
            if (args[i] instanceof MultipartFile) {
                continue;
            }
            sb.append(JSON.toJSONString(args[i]));
        }
        invokeLogPo.setRequestJson(sb.toString());
        Object result = pjp.proceed();
        invokeLogPo.setResultResponse(JSON.toJSONString(result));
        try{
            stockOperationHistoryService.save(invokeLogPo);
        }catch (Exception e){
            log.error("调用日志保存异常",e);
        }
        return result;
    }
}
