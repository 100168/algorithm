package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderDetailPo;
import com.jiduauto.sps.server.pojo.vo.req.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 采购退货订单明细 服务类
 * </p>
 *
 * @author generate
 * @since 2023-05-04
 */
public interface IPurchaseReturnOrderDetailService extends IService<PurchaseReturnOrderDetailPo> {

    /**
     * 采购退货单明细列表
     * @param orderNoReq 参数
     * @return 返回*/
    List<PurchaseReturnOrderDetailDto> listByOrderNo(OrderAndSupplierReq  orderNoReq);

    /**
     * 采购退货单明细列表
     * @param orderNo 订单号
     * @param bizType 参数
     * @return 返回*/
    List<PurchaseReturnOrderDetailPo> listByOrderNo(String orderNo, String bizType);

    /**
     * 采购退货单明细添加
     * @param addReq 参数
     * @return 返回*/
    Boolean add(PurchaseReturnOrderDetailSaveReq addReq);

    /**
     * 采购退货单明细编辑
     * @param editReq 参数
     * @return 返回*/
    Boolean edit(PurchaseReturnOrderDetailEditReq editReq);

    /**
     * 采购退货单明细map
     * @param bizType 参数
     * @param orderNo 参数
     * @param salePartName 参数
     * @return 返回*/
    Map<String,PurchaseReturnOrderDetailPo> mapPurchaseReturnOrderDetailPo(String bizType, String orderNo,
            List<String> salePartName);
    /**
     * 数据库最大行号
     * @return int
     */
    Integer getNextLineNo(String orderNo);
    /**
     * 明细增加批量
     * @param addBatchReq 添加参数
     * @return bool
     */
    Boolean addBatch(PurchaseReturnOrderDetailBatchSaveReq addBatchReq);

}
