package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.kit.KitOrderDto;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderItemPo;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.pojo.vo.req.kit.KitOrderAddAndEditReq;
import com.jiduauto.sps.server.pojo.vo.req.kit.KitOrderReq;
import com.jiduauto.sps.server.pojo.vo.req.stock.IdIpage;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * KIT订单表 服务类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
public interface IKitOrderService extends IService<KitOrderPo> {

    /**
     * kit订单确认
     * @param req req
     * @return boolean
     */
    Boolean confirm(KitOrderAddAndEditReq req);

    /**
     *  kit 订单分页查询
     * @param pageParam
     * @return
     */
    BasePageData<KitOrderDto> pageSearch(BasePageParam<KitOrderReq> pageParam);

    /**
     *  删除订单
     * @param request
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    BaseResult<String> deleteById(IdReq request);

    /**
     *  保存草稿
     * @param request
     * @return
     */
    BaseResult<String> createDraft(KitOrderAddAndEditReq request);

    /**
     * 校验订单明细中的数量
     *
     * @param kitOrderNo
     * @param outQuantityList
     * @return
     */
    Map<String, BigDecimal> checkDeliverQty(String kitOrderNo, String operationType, List<KitOrderItemPo> outQuantityList);

    /**
     * 更新KIT订单的出入库状态和数量
     * @param request
     */
    void  updateDeliverQty(InAndOutStockRequest request);

    /**
     * 更新SAP 凭证号
     *
     * @param kitOrderNo
     * @param sapRequestNo
     * @return
     */
    boolean updateSapRequestOrder(String kitOrderNo , String sapRequestNo);


    /**
     * 出入库确认  创建SAP请求体
     * @param request
     * @return
     */
    List<Map<String, Object>> createSapMM033Item(InAndOutStockRequest request);

    /**
     *  查询订单详情
     * @param pageParam
     * @return
     */
    BaseResult<KitOrderDto> selectById(IdIpage pageParam);

    /**
     * kit 订单取消
     */
    Boolean cancel(@Valid IdReq req);
}
