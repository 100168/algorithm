package com.jiduauto.sps.server.service;

import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderOperateLogDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderStatusLogDto;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderStatusLogPo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderIdReq;

/**
 * <p>
 * 采购申请订单状态变更记录 服务类
 * </p>
 *
 * @author generate
 * @since 2023-06-08
 */
public interface IPurchaseApplyOrderStatusLogService extends IService<PurchaseApplyOrderStatusLogPo> {

    /**
     * 状态日志分页查询
     * @param pageSearchReq pageSearchReq
     * @return page
     */
    BasePageData<PurchaseApplyOrderStatusLogDto> pageSearch(BasePageParam<OrderIdReq> pageSearchReq);
}
