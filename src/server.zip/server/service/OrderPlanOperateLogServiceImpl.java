package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.server.Enum.OrderPlanColumnEnum;
import com.jiduauto.sps.server.Enum.OrderPlanOperateEnum;
import com.jiduauto.sps.server.mapper.OrderPlanOperateLogMapper;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.OrderPlanOperateLogDto;
import com.jiduauto.sps.server.pojo.po.OrderPlanOperateLogPo;
import com.jiduauto.sps.server.pojo.po.OrderPlanPo;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.stream.Collectors;

@Service
public class OrderPlanOperateLogServiceImpl extends ServiceImpl<OrderPlanOperateLogMapper, OrderPlanOperateLogPo> implements IOrderPlanOperateLogService {

    @Resource
    private OrderPlanOperateLogMapper operateLogMapper;

    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.NESTED)
    public void saveEditQuantityLog(OrderPlanPo old, Integer quantity) {
        try {
            OrderPlanOperateLogPo logPo = new OrderPlanOperateLogPo();
            logPo.setOrderPlanId(old.getId());
            logPo.setActionDesc(OrderPlanOperateEnum.EDIT.getDesc());
            logPo.setModifyColumn(OrderPlanColumnEnum.COL_QUANTITY.getDesc());
            logPo.setOldValue(old.getQuantity().toString());
            logPo.setNewValue(quantity.toString());
            operateLogMapper.insert(logPo);
        } catch (Exception e) {
            log.error(String.format("OrderPlanOperateLogServiceImpl#saveEditQuantityLog error, param: %s", old.getId()), e);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.NESTED)
    public void saveEditDeliveryQtyLog(OrderPlanPo old, Integer quantity, String createUser) {
        try {
            OrderPlanOperateLogPo logPo = new OrderPlanOperateLogPo();
            logPo.setOrderPlanId(old.getId());
            logPo.setActionDesc(OrderPlanOperateEnum.EDIT.getDesc());
            logPo.setModifyColumn(OrderPlanColumnEnum.COL_DELIVERY_QTY.getDesc());
            logPo.setOldValue(old.getDeliveryQty().toString());
            logPo.setNewValue(quantity.toString());
            logPo.setCreateUser(createUser);
            operateLogMapper.insert(logPo);
        } catch (Exception e) {
            log.error(String.format("OrderPlanOperateLogServiceImpl#saveEditDeliveryQtyLog error, param: %s", old.getId()), e);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.NESTED)
    public void saveEditReceivedQtyLog(OrderPlanPo old, Integer quantity, String createUser) {
        try {
            OrderPlanOperateLogPo logPo = new OrderPlanOperateLogPo();
            logPo.setOrderPlanId(old.getId());
            logPo.setActionDesc(OrderPlanOperateEnum.EDIT.getDesc());
            logPo.setModifyColumn(OrderPlanColumnEnum.COL_RECEIVED_QTY.getDesc());
            logPo.setOldValue(old.getReceivedQty().toString());
            logPo.setNewValue(quantity.toString());
            logPo.setCreateUser(createUser);
            operateLogMapper.insert(logPo);
        } catch (Exception e) {
            log.error(String.format("OrderPlanOperateLogServiceImpl#saveEditReceivedQtyLog error, param: %s", old.getId()), e);
        }
    }

    @Override
    public BasePageData<OrderPlanOperateLogDto> pageSearch(BasePageParam<IdReq> pageParam) {
        IPage<OrderPlanOperateLogPo> page = operateLogMapper.pageSearch(new Page<>(pageParam.getPage(), pageParam.getSize()), pageParam.getParam().getId());
        BasePageData<OrderPlanOperateLogDto> basePageData = new BasePageData<>(page);
        basePageData.setRecords(page.getRecords().stream().map(item -> {
            OrderPlanOperateLogDto orderPlanOperateLogDto = new OrderPlanOperateLogDto();
            BeanUtils.copyProperties(item, orderPlanOperateLogDto);
            return orderPlanOperateLogDto;
        }).collect(Collectors.toList()));
        return basePageData;
    }
}
