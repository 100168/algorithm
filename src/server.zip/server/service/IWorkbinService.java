package com.jiduauto.sps.server.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.baseData.WorkbinDto;
import com.jiduauto.sps.server.pojo.fileexport.WorkbinExportDto;
import com.jiduauto.sps.server.pojo.po.WorkbinPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.EditStatusCommonReq;
import com.jiduauto.sps.server.pojo.vo.req.baseData.DropDownReq;
import com.jiduauto.sps.server.pojo.vo.req.baseData.ExportReq;
import com.jiduauto.sps.server.pojo.vo.req.baseData.WorkbinDeleteReq;
import com.jiduauto.sps.server.pojo.vo.req.baseData.WorkbinEditAndSingleAddReq;
import com.jiduauto.sps.server.pojo.vo.req.baseData.WorkbinPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.resp.DropDownResp;

/**
 * <p>
 * 仓库主数据 服务类
 * </p>
 *
 * @author generate
 * @since 2023-02-23
 */
public interface IWorkbinService extends IService<WorkbinPo> {
    /*
     * @Author O_chaopeng.huang
     * @Description //   添加料箱
     * @Date 16:54 2023/2/23
     * @Param
     * @return
     **/
    BaseResult singleAdd(WorkbinEditAndSingleAddReq workbinEditAndSingleAddReq);

    /*
     * @Author O_chaopeng.huang
     * @Description //   料箱信息分页查询
     * @Date 11:32 2023/2/24
     * @Param
     * @return
     **/
    BasePageData<WorkbinDto> pageSearch(BasePageParam<WorkbinPageSearchReq> pageParam);

    /*
     * @Author O_chaopeng.huang
     * @Description //   根据id查询料箱
     * @Date 11:42 2023/2/24
     * @Param
     * @return
     **/
    BaseResult selectById(WorkbinPageSearchReq pageSearchReq);

    /*
     * @Author O_chaopeng.huang
     * @Description //   料箱信息xiugai
     * @Date 11:51 2023/2/24
     * @Param
     * @return
     **/
    BaseResult edit(WorkbinEditAndSingleAddReq workbinEditAndSingleAddReq);

    /*
     * @Author O_chaopeng.huang
     * @Description //   删除料想信息
     * @Date 11:57 2023/2/24
     * @Param
     * @return
     **/
    BaseResult deleteOne(WorkbinDeleteReq del);

    /*
     * @Author O_chaopeng.huang
     * @Description //   获取下拉列表
     * @Date 12:36 2023/2/24
     * @Param
     * @return
     **/
    BaseResult<List<DropDownResp>> dropList(DropDownReq dropDown);

    /*
     * @Author O_chaopeng.huang
     * @Description //   料想信息导出
     * @Date 14:53 2023/2/24
     * @Param
     * @return
     **/
    Collection<WorkbinExportDto> getExportDtoList(BasePageParam<ExportReq> pageParam);

    /**
     * 料箱信息状态修改
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    BaseResult editStatus(EditStatusCommonReq req);
    Map<String , WorkbinPo> mapWorkbinPo(String bizType, List<String> workCodes);
}

