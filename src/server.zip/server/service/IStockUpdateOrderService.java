package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderItemPo;
import com.jiduauto.sps.sdk.pojo.po.StockCheckOrderPo;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.dto.stock.StockAllDto;
import com.jiduauto.sps.server.pojo.dto.stock.StockUpdateOrderAllDto;
import com.jiduauto.sps.server.pojo.fileexport.StockUpdateOrderExportDto;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import com.jiduauto.sps.server.pojo.po.StockUpdateOrderPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.pojo.vo.req.UpdateStockRequest;
import com.jiduauto.sps.server.pojo.vo.req.baseData.DeleteBatchReq;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockSearch;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockUpdateOrderEditAndAddReq;
import com.jiduauto.sps.server.pojo.vo.req.stock.StockUpdateOrderPageSearch;

import java.util.Collection;
import java.util.List;

/**
 * <p>
 * 库存调整单 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-10
 */
public interface IStockUpdateOrderService extends IService<StockUpdateOrderPo> {


    /**
     * 分页查询
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    BasePageData<StockUpdateOrderAllDto> pageSearch(BasePageParam<StockUpdateOrderPageSearch> pageSearch);

    /**
     * 添加
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    BaseResult<String> add(StockUpdateOrderEditAndAddReq req);

    /**
     * 详情
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    BaseResult<StockUpdateOrderAllDto> selectById(Long id);

    /**
     * 修改
     *
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    BaseResult edit(StockUpdateOrderEditAndAddReq req);

    /**
     * 批量删除
     * @return
     * @Author O_chaopeng.huang
     * @Param
     **/
    BaseResult deleteBatch(DeleteBatchReq req);

    /**
     * 再次选择库存时根据已选择库存id排除已选
     * @Author O_chaopeng.huang
     * @Param
     * @return
     **/
    BaseResult<BasePageData<StockAllDto>> ridIdBatch(BasePageParam<StockSearch> pageParam);

    /**
     * 调整单确认  实际去 调整库存
     *
     * @param bizType
     * @param orderNumbers 单号
     * @return
     */
    BaseResult confirm(String bizType, List<String> orderNumbers);

    /**
     * 库存调整单 完成
     * @param bizType
     * @param orderNo
     * @return
     */
    BaseResult finished(String bizType, String orderNo);


    /**
     * 生成因短拣而冻结库存的库存调整单
     */
    void generateFrozenUpdateOrder(InAndOutStockRequest req, List<InAndOutStockParam> needFrozenStocks, List<StockItemPo> updateStockParams);

    /**
     * 盘点 盘亏 冻结库存的库存调整单
     */
    void generateFrozenUpdateOrderForStockCheck(UpdateStockRequest updateStockRequest, List<StockCheckOrderItemPo> needFrozen);

    /**
     * 取消
     */
    BaseResult<Boolean> cancel(IdReq req);

    void createByCheckOrder(StockCheckOrderPo orderPo, List<StockCheckOrderItemPo> itemPos);

    /**
     * 导出查询
     * @param search
     * @return
     */
    List<StockUpdateOrderExportDto> exportSearch(StockUpdateOrderPageSearch search);
}
