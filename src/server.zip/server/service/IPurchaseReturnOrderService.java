package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.AsnAllDto;
import com.jiduauto.sps.server.pojo.dto.PurchaseReturnOrderDto;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.po.PurchaseReturnOrderPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.*;

import java.util.List;

/**
 * <p>
 * 采购退货订单 服务类
 * </p>
 *
 * @author generate
 * @since 2023-05-04
 */
public interface IPurchaseReturnOrderService extends IService<PurchaseReturnOrderPo> {

    /**
     * 采购退货单临时添加
     * @param request 保存参数
     * @return 返回*/
    BaseResult<PurchaseReturnOrderDto> createTempRecord(PurchaseReturnOrderAddReq request);

    /**
     * 采购退货单删除
     * @param request 删除参数
     * @return 返回*/
    BaseResult<Boolean> deleteById(IdReq request);
    /**
     * 采购退货单分页查询
     * @param pageParam 参数
     * @return 返回*/
    BasePageData<PurchaseReturnOrderDto> pageSearch(BasePageParam<PurchaseReturnOrderSearchReq> pageParam);
    /**
     * 采购退货单保存草稿
     * @param request 参数
     * @return 返回*/
    BaseResult<Boolean> enableTempRecord(IdReq request);
    /**
     * 采购退货单提交审核(编辑)
     * @param request 参数
     * @return 返回*/
    BaseResult<Boolean> commit(IdReq request);

    /**
     * 采购退货单编辑
     * @param request 参数
     * @return 返回*/
    BaseResult<PurchaseReturnOrderDto> edit(PurchaseReturnOrderEditReq request);

    /**
     * 采购退货单审核
     * @param request 参数
     * @return 返回*/
    Boolean audit(PurchaseReturnOrderAuditReq request);
    /**
     * 采购退货单入库校验
     * @param request 参数 */
    void checkReceiveQtyAndSetPlanQty(InAndOutStockRequest request);

    /**
     * 根据已绑定ans采购的退货明细过滤已选asn
     * @author O_chaopeng.huang
     * @return BaseResult<BasePageData<AsnAllDto>>
     */
    BasePageData<AsnAllDto> pageList(BasePageParam<PurchaseReturnOrderAsnPageSearch> param);
    /**
     * 采购退货单反写退货数量
     * @param bizType  参数
     * @param tradeNo  参数
     * @param params  参数
     * */
    void updateReturnQty(String bizType, String tradeNo, List<InAndOutStockParam> params);
}
