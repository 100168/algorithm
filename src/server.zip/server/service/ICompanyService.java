package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.CompanyDropdownDto;
import com.jiduauto.sps.server.pojo.dto.CompanyDto;
import com.jiduauto.sps.server.pojo.po.CompanyPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.CompanyDropListReq;
import com.jiduauto.sps.server.pojo.vo.req.CompanyEnableReq;
import com.jiduauto.sps.server.pojo.vo.req.CompanyPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.CompanyReq;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 公司信息 服务类
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
public interface ICompanyService extends IService<CompanyPo> {

    /**
     * 新增公司
     * @param request
     * @return
     */
    BaseResult add(CompanyReq request);

    /**
     * 编辑公司
     * @param request
     * @return
     */
    BaseResult edit(CompanyReq request);

    /**
     * 启用/禁用公司
     * @param request
     * @return
     */
    BaseResult enable(CompanyEnableReq request);

    /**
     * 条件查询搜索
     * @param pageParam
     * @return
     */
    BasePageData<CompanyDto> pageSearch(BasePageParam<CompanyPageSearchReq> pageParam);

    /**
     * 获取下拉列表
     * @param req
     * @return
     */
    List<CompanyDropdownDto> dropdownList(CompanyDropListReq req);

    /**
     * 获取公司名称映射关系
     * @param bizType
     * @param companyCodes
     * @return
     */
    Map<String, String> getCodeAndNameMap(String bizType, List<String> companyCodes);

    /**
     * 从SAP 获取
     * @return
     */
    BaseResult syncFromSAP();
    /**
     * 公司主数据获取
     */
    Map<String, CompanyPo> getCompanyPoMap(String bizType, List<String> companyCodes);
}
