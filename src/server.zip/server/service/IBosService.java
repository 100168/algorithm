package com.jiduauto.sps.server.service;



import com.jiduauto.sps.server.pojo.vo.BosFileResult;

import java.io.InputStream;

/**
 * @Author xKun
 * @Date 2022/1/26 16:20
 * @Version 1.0
 * @Desc BOS文件处理
 */
public interface IBosService {
    /**
     * 上传
     * @param inputStream
     * @param fileName
     * @return
     */
    BosFileResult putObjInputStream(InputStream inputStream, String fileName);

    /**
     * 上传到 SPS 私有桶
     * @param inputStream
     * @param fileName
     * @return
     */
    BosFileResult uploadFile(InputStream inputStream, String fileName);

    /**
     * 低频存储
     * @param inputStream
     * @param fileName
     * @return
     */
    BosFileResult putLowsObjInputStream(InputStream inputStream, String fileName);

    /**
     *  根据文件id 查询 文件网络访问地址
     * @param fileKey  文件key
     * @param validateTimeOut  有效期时间
     * @return
     */
    String getFileUrlByKey(String fileKey, int validateTimeOut);

    String getFileUrlByKey2(String fileKey, int validateTimeOut);
}
