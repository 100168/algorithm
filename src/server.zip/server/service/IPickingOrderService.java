package com.jiduauto.sps.server.service;

import cn.hutool.json.JSONObject;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.Enum.PickingOrderStatusEnum;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.*;
import com.jiduauto.sps.server.pojo.po.PickingOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.BatchIdReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;
import com.jiduauto.sps.server.pojo.vo.req.PickingOrderPageSearch;
import com.jiduauto.sps.server.pojo.vo.req.PickingOrderPartCancelReq;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 拣货单 服务类
 * </p>
 *
 * @author generate
 * @since 2023-06-27
 */
public interface IPickingOrderService extends IService<PickingOrderPo> {

    /**
     * 保存拣货单
     * @param advicePickOrderContext list
     */
    void save(AdvicePickOrderContext advicePickOrderContext);
    /**
     * 拣货单分页
     * @author O_chaopeng.huang
     * @param  req
     * @return BaseResult<BasePageData<PickingOrderDto>>
     */
    BasePageData<PickingOrderDto> pageSearch(BasePageParam<PickingOrderPageSearch> req);
    /**
     * 使数据生效
     * @param bizType bizType
     * @param  orderNo orderNo
     * @return boolean
     */
    boolean enableRecord(String bizType,String orderNo);

    JSONObject printPick(String number, String bizType);

    PickingOrderPrintDto newPrintPick(String number, String bizType);

    /**
     *拣货单确认
     * @param batchIdReq bizType
     * @return boolean
     */
    Boolean confirm(BatchIdReq batchIdReq);
    /**
     *更新实拣数量
     * @param bizType bizType
     * @param orderNo orderNo
     * @param diffQty  diffQty
     * @param status status
     * @return boolean
     */
    boolean updateActualQtyAndStatus(String bizType, String orderNo, BigDecimal diffQty, PickingOrderStatusEnum status);
    /**
     * 打印拣货单明细
     *
     * @author O_chaopeng.huang
     * @return BaseResult<BasePageData<PickingOrderDto>>
     */
    JSONObject printPickItem(String number, String bizType);


    /**
     *更新占用库存
     * @param dtoList dtoList
     * @param bizType bizType
     * @param key key
     **/
    void occupyStock(List<PickingOrderDetailUpdateDto> dtoList, String bizType, String key);

    /**
     *部分取消
     * @param pickingOrderPartCancelReq idReq
     */
    void cancel(PickingOrderPartCancelReq pickingOrderPartCancelReq);
    /**
     *拣货单领料明细
     * @param orderNoReq orderNoReq
     * @return list
     */
    List<PickingApplyDetailDto> pickingApplyDetail(OrderNoReq orderNoReq);
}
