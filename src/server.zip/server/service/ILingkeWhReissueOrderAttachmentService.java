package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.dto.AttachmentDto;
import com.jiduauto.sps.sdk.pojo.po.LingkeWhReissueOrderAttachmentPo;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.server.client.req.LingkeWhReissueOrderAttachmentReq;
import com.jiduauto.sps.server.client.req.LingkeWhReissueOrderAuditResultReq;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * <p>
 * 领克仓补差异订单附件 服务类
 * </p>
 *
 * @author generate
 * @since 2023-12-11
 */
public interface ILingkeWhReissueOrderAttachmentService extends IService<LingkeWhReissueOrderAttachmentPo> {
    /**
     * 查询 带有 有效期的 附件地址
     * @param fileIdList
     * @return
     */
    List<LingkeWhReissueOrderAttachmentReq> whReissueOrderFileList(List<String> fileIdList);

    /**
     * 接收审核结果
     * @param req
     */
    void whReissueOrderAuditResult(LingkeWhReissueOrderAuditResultReq req);
    /**
     * 获取附件列表
     * @param req
     */
    List<AttachmentDto> attachmentList(OrderNoReq req);
}
