package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.po.StoreTransferOrderDetailPo;

/**
 * <p>
 * 门店调拨单明细 服务类
 * </p>
 *
 * @author generate
 * @since 2024-01-12
 */
public interface IStoreTransferOrderDetailService extends IService<StoreTransferOrderDetailPo> {

}
