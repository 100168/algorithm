package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.SupplierCalendarSyncDto;
import com.jiduauto.sps.server.pojo.dto.SupplierCalendarDto;
import com.jiduauto.sps.server.pojo.fileexport.SupplierCalendarExportDto;
import com.jiduauto.sps.server.pojo.po.SupplierCalendarPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.SupplierCalendarPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.SupplierCalendarReq;
import com.jiduauto.sps.server.pojo.vo.req.SupplierCalendarSyncPageSearchReq;

import java.util.List;

public interface ISupplierCalendarService extends IService<SupplierCalendarPo> {

    /**
     * 新增供应商日历
     * @param request
     * @return
     */
    BaseResult add(SupplierCalendarReq request);

    /**
     * 编辑供应商日历
     * @param request
     * @return
     */
    BaseResult edit(SupplierCalendarReq request);

    /**
     * 删除供应商日历
     * @param request
     * @return
     */
    BaseResult delete(IdReq request);

    /**
     * 条件查询搜索
     * @param pageParam
     * @return
     */
    BasePageData<SupplierCalendarDto> pageSearch(BasePageParam<SupplierCalendarPageSearchReq> pageParam);

    /**
     * 同步数据分页查询
     * @param pageParam
     * @return
     */
    BasePageData<SupplierCalendarSyncDto> syncPageSearch(BasePageParam<SupplierCalendarSyncPageSearchReq> pageParam);

    /**
     * 获取导出的数据
     * @param pageParam
     * @return
     */
    List<SupplierCalendarExportDto> getExportDtoList(BasePageParam<SupplierCalendarPageSearchReq> pageParam);
}

