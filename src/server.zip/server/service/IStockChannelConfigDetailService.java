package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.dto.StockChannelConfigDetailDto;
import com.jiduauto.sps.server.pojo.po.StockChannelConfigDetailPo;
import com.jiduauto.sps.server.pojo.vo.req.IdReq;
import com.jiduauto.sps.server.pojo.vo.req.StockChannelConfigDetailReq;
import com.jiduauto.sps.server.pojo.vo.req.StockChannelConfigDetailSaveReq;

import java.util.List;

/**
 * <p>
 * 库存渠道配置明细表 服务类
 * </p>
 *
 * @author generate
 * @since 2024-09-26
 */
public interface IStockChannelConfigDetailService extends IService<StockChannelConfigDetailPo> {

    List<StockChannelConfigDetailDto> selectList(StockChannelConfigDetailReq req);

    void save(StockChannelConfigDetailSaveReq req);

    void delete(IdReq req);
}
