package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.StockInMapBusinessDto;
import com.jiduauto.sps.server.pojo.fileexport.StockInMapBusinessExportResp;
import com.jiduauto.sps.server.pojo.po.AsnBasicPo;
import com.jiduauto.sps.server.pojo.po.AsnDeliverInfoPo;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderPo;
import com.jiduauto.sps.server.pojo.po.StockInMapBusinessPo;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderItemPo;
import com.jiduauto.sps.server.pojo.po.kit.KitOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.StockInMapBusinessPageSearchReq;

import java.util.List;

/**
 * <p>
 * 入库订单 服务类
 * </p>
 *
 * @author generate
 * @since 2024-05-29
 */
public interface IStockInMapBusinessService extends IService<StockInMapBusinessPo> {

    /**
     * 更新订单到货时间
     */
    void updateActualArrivalTime(String orderNo, String bizType, String operateTime);

    /**
     * 分页查询
     */
    BasePageData<StockInMapBusinessDto> pageSearch(BasePageParam<StockInMapBusinessPageSearchReq> pageParam);

    /**
     * 保存asn订单信息
     */
    void saveAsn(AsnBasicPo asnBasicPo, List<AsnDeliverInfoPo> asnDeliverInfoPos);

    /**
     * 保存采购申请订单信息
     */
    void savePr(PurchaseApplyOrderPo purchaseApplyOrderPo);

    /**
     * kit订单入库记录保存
     */
    void saveKitIn(KitOrderPo kitOrderPo, List<KitOrderItemPo> kitOrderItemPos);
    /**
     * 导出
     */
    List<StockInMapBusinessExportResp> export(BasePageParam<StockInMapBusinessPageSearchReq> param);

    void create(com.jiduauto.sps.sdk.pojo.dto.StockInMapBusinessDto request);
}
