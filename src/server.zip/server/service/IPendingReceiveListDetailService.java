package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PendingReceiveListDetailDto;
import com.jiduauto.sps.server.pojo.po.PendingReceiveListDetailPo;
import com.jiduauto.sps.server.pojo.vo.req.OrderNoReq;

import java.util.List;

/**
 * <p>
 * 待收货列表明细 服务类
 * </p>
 *
 * @author generate
 * @since 2023-08-22
 */
public interface IPendingReceiveListDetailService extends IService<PendingReceiveListDetailPo> {

    /**
     * 待收货明细分页查询
     * @param req req
     * @return page
     */
    BasePageData<PendingReceiveListDetailDto> pageSearch(BasePageParam<OrderNoReq> req);

    /**
     * 待收货和关单列表
     *
     * @param req req
     * @return page
     */
    List<PendingReceiveListDetailDto> waitReceiveList(OrderNoReq req);

}
