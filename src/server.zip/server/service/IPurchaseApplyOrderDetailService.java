package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PurchaseApplyOrderDetailDto;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderDetailPo;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderOperateLogPo;
import com.jiduauto.sps.server.pojo.po.PurchaseApplyOrderPo;
import com.jiduauto.sps.server.pojo.vo.req.*;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 采购申请订单明细 服务类
 * </p>
 *
 * @author generate
 * @since 2023-06-08
 */
public interface IPurchaseApplyOrderDetailService extends IService<PurchaseApplyOrderDetailPo> {

    /**
     * 明细分页查询
     * @param pageSearchReq pageSearchReq
     * @return PurchaseApplyOrderDetailDto
     */
    BasePageData<PurchaseApplyOrderDetailDto> pageSearch(BasePageParam<PRDetailSearchReq> pageSearchReq);

    /**
     * 明细增加
     * @param addReq 添加参数
     * @return bool
     */
    Boolean add(PurchaseApplyOrderDetailAddReq addReq);

    void checkContract(PurchaseApplyOrderDetailPo detailPo, PurchaseApplyOrderPo po);

    /**
     * 数据库最大行号
     * @param orderId 添加参数
     * @return int
     */
    PurchaseApplyOrderDetailPo getLastDetailPo(Long orderId);

    /**
     * 明细编辑
     * @param editReq 编辑参数
     * @return bool
     */
    Boolean edit(PurchaseApplyOrderDetailEditReq editReq);

    void checkAndInitEstArrivalTime(PurchaseApplyOrderDetailPo detailPo, PurchaseApplyOrderPo orderPo);

    /**
     * 常规订单，紧急订单，差异补单，：必填，按供应商日历向前取值（无供应商日历取导入日期），按供应商日历向前取值，取到历史时间丢弃，取录入的预计到货日期
     *
     * @param estArrivalTime 输入日期
     * @param orderPo        orderPo
     * @return string
     */
    String getEstArrivalTime(String estArrivalTime, PurchaseApplyOrderPo orderPo, String pattern);

    /**
     * 明细删除
     * @param id id
     * @return bool
     */
    Boolean deleteById(Long id);

    Map<String, PurchaseApplyOrderDetailPo> mapPurchaseApplyOrderDetailPo(String bizType, Long orderId,
            List<String> salePartNums);

    /**
     * 根据采购申请id查明细
     *
     * @param orderId orderId
     * @return list
     */
    List<PurchaseApplyOrderDetailPo> listByOrderId(Long orderId);

    /**
     * 根据采购申请id查明细
     *
     * @param idReq orderId
     * @return list
     */
    List<PurchaseApplyOrderDetailDto> list(OrderIdReq idReq);

    /**
     * 根据明细id取消
     *
     * @param req req
     * @return true||false
     */
    Boolean cancel(IdReq req);

    /**
     * 操作日志记录构建
     *
     * @param before before
     * @param after after
     * @return list
     */
    List<PurchaseApplyOrderOperateLogPo> buildOperateLogs(PurchaseApplyOrderDetailPo before,
                                                          PurchaseApplyOrderDetailPo after);
}

