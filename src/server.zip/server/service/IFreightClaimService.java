package com.jiduauto.sps.server.service;

import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.ClaimDto;
import com.jiduauto.sps.server.pojo.fileexport.ClaimExportResp;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.ChangeClaimStateReq;
import com.jiduauto.sps.server.pojo.vo.req.ClaimNoReq;
import com.jiduauto.sps.server.pojo.vo.req.ClaimPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.ClaimResponsiblePartyUpdateReq;

import java.util.List;
import java.util.Map;

/**
 * 物流索赔 服务类
 */
public interface IFreightClaimService {

    /**
     * 物流索赔列表分页查询
     */
    BasePageData<ClaimDto> pageSearch(BasePageParam<ClaimPageSearchReq> pageParam);

    /**
     *  物流索赔单详情
     */
    BaseResult<ClaimDto> detail(ClaimNoReq claimNoReq);

    /**
     *  索赔单审核
     */
    BaseResult<String> changeClaimState(ChangeClaimStateReq req);

    /**
     *  索赔单责任方认定 批量
     */
    BaseResult<String> changeResponsibleParty(ClaimResponsiblePartyUpdateReq req);

    /**
     * 旧件处理选择索赔单分页查询
     *
     */
    BasePageData<ClaimDto> oldPartsClaimPageSearch(BasePageParam<ClaimPageSearchReq> pageParam);

    /**
     * 根据索赔单号查询 SO单号
     * @param claimNos
     * @return
     */
    Map<String, String> listSoOrderPo(List<String> claimNos);

    List<ClaimExportResp> export(BasePageParam<ClaimPageSearchReq> param);
    /**
     *  索赔单二次责任方认定 批量
     */
    BaseResult<String> secondChangeResponsibleParty(ClaimResponsiblePartyUpdateReq req);
}
