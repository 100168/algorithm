package com.jiduauto.sps.server.service;

import com.jiduauto.sps.server.Enum.SpsResponseCodeEnum;
import com.jiduauto.sps.server.caches.WarehouseCache;
import com.jiduauto.sps.server.exception.BizException;
import com.jiduauto.sps.server.pojo.dto.param.InAndOutStockParam;
import com.jiduauto.sps.server.pojo.po.StockConfigPo;
import com.jiduauto.sps.server.pojo.po.StockItemPo;
import com.jiduauto.sps.server.pojo.po.StockOperateLogPo;
import com.jiduauto.sps.server.pojo.po.StockPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;
import com.jiduauto.sps.server.utils.BeanCopierUtil;
import com.jiduauto.sps.server.utils.MD5Util;
import com.jiduauto.sps.server.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.*;

/**
 * 公共 库存方法
 */
@Component
@Slf4j
public abstract class BaseStockService {

    @Autowired
    private IStockService stockService;


    @Autowired
    private IStockConfigService stockConfigService;
    @Autowired
    private IStockOperateLogService stockOperateLogService;
    @Autowired
    private WarehouseCache warehouseCache;


    /**
     * 入库
     * @param request
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public BaseResult putInStock(InAndOutStockRequest request){
        //幂等判断
        checkIdempotent(request);
        //asn前置校验
        checkASNParam(request);
        //更新asn
        updateASN(request);
        Map<String, InAndOutStockParam> stockItemMap =  getStockItemRequestMap(request);
        Map<String, InAndOutStockParam> stockMap =  getStockRequestMap(request);
        //更新库存
        putInUpdateStock(request,stockMap,stockItemMap);

        sendToSAP(request);
        return BaseResult.OK();
    }

    /**
     * 出库
     * @param request
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public BaseResult putOutStock(InAndOutStockRequest request){
        //幂等判断
        checkIdempotent(request);
        Map<String, InAndOutStockParam> stockItemMap =  getStockItemRequestMap(request);
        Map<String, InAndOutStockParam> stockMap =  getStockRequestMap(request);
        //更新库存
        putOutUpdateStock(request,stockMap,stockItemMap);
        sendStockUpdateToSAP(request);
        return BaseResult.OK();
    }

    /**
     * 库存调整
     * @param request
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public BaseResult updateStock(InAndOutStockRequest request){
        //幂等判断
        checkIdempotent(request);
        Map<String, InAndOutStockParam> stockItemMap =  getStockItemRequestMap(request);
        Map<String, InAndOutStockParam> stockMap =  getStockRequestMap(request);
        //更新库存
        changeUpdateStock(request,stockMap,stockItemMap);
        return BaseResult.OK();
    }

    private void checkIdempotent(InAndOutStockRequest request) {
        String key =initIdempotentNo(request);
        StockOperateLogPo po = stockOperateLogService.getByBizTypeAndIdempotentNo(request.getBizType(), key);
        if(po != null){
            //幂等判断
            throw  new BizException(SpsResponseCodeEnum.DUPLICATE_OPERATE.getCode(),SpsResponseCodeEnum.DUPLICATE_OPERATE.getDesc());
        }
    }


    /**
     * 发送收货数据到SAP
     * @param request
     */
    protected abstract  void sendToSAP(InAndOutStockRequest request)throws BizException;

    /**
     * 库存更新数据 推送到SAP
     * @param request
     */
    protected abstract  void sendStockUpdateToSAP(InAndOutStockRequest request)throws BizException;


    /**
     * 同步数据到ASN
     * @param request
     */
    protected abstract  void updateASN(InAndOutStockRequest request)throws BizException;


    /**
     * 校验ASN 相关参数
     * @param request
     */
    protected abstract  void checkASNParam(InAndOutStockRequest request)throws BizException;

    /**
     * 入库  库存表 更新
     */
    protected abstract  void putInUpdateStock(InAndOutStockRequest request, Map<String, InAndOutStockParam> stockMap, Map<String, InAndOutStockParam> stockItemMap)throws BizException;

    /**
     * 出库  库存表 更新
     */
    protected abstract  void putOutUpdateStock(InAndOutStockRequest request, Map<String, InAndOutStockParam> stockMap, Map<String, InAndOutStockParam> stockItemMap)throws BizException;

    /**
     * 库存调整  库存表 更新
     */
    protected abstract  void changeUpdateStock(InAndOutStockRequest request, Map<String, InAndOutStockParam> stockMap, Map<String, InAndOutStockParam> stockItemMap)throws BizException;



    /**
     * 库存表的 操作参数
     *
     * @return
     */
    public Map<String, InAndOutStockParam> getStockRequestMap(InAndOutStockRequest request) {
        List<InAndOutStockParam> params = request.getParams();
        //业务主键 配置查询
        List<String> stockKeys =  new ArrayList<>();
        StockConfigPo stockConfigPo1 = stockConfigService.getByBizTypeAndConfigType(request.getBizType(), 1);
        Map<String, InAndOutStockParam> stockMap = new HashMap<>();

        for(InAndOutStockParam param:params){
            if(stockConfigPo1 != null){
                String key = getStockKeyByParam(stockConfigPo1.getField(),request.getBizType(), param);
                stockKeys.add(key);
                if(stockMap. containsKey(key)){
                    //重复物料 入参 ， 累加
                    InAndOutStockParam temp = stockMap.get(key);
                    temp.setSumQuantity(temp.getSumQuantity().add(param.getSumQuantity()));
                    stockMap.put(key, temp);
                }else{
                    stockMap.put(key, BeanCopierUtil.copy(param,InAndOutStockParam.class));
                }
            }
        }
        return stockMap;
    }

    /**
     * 库存明细表的操作参数
     *
     * @return
     */
    public Map<String, InAndOutStockParam> getStockItemRequestMap(InAndOutStockRequest request) {
        List<InAndOutStockParam> params = request.getParams();

        //业务主键 配置查询
        List<String> stockItemKeys = new ArrayList<>();
        StockConfigPo stockConfigPo2 = stockConfigService.getByBizTypeAndConfigType(request.getBizType(), 2);
        Map<String, InAndOutStockParam> stockItemMap = new HashMap<>();
        //重复物料信息 合并
        for(InAndOutStockParam param:params){
            String itemKey = getStockKeyByParam(stockConfigPo2.getField(),request.getBizType(), param);
            stockItemKeys.add(itemKey);
            if(stockItemMap.containsKey(itemKey)){
                //存在重复物料数据
                InAndOutStockParam temp = stockItemMap.get(itemKey);
                temp.setSumQuantity(temp.getSumQuantity().add(param.getSumQuantity()));
                stockItemMap.put(itemKey, temp);
            }else{
                stockItemMap.put(itemKey, BeanCopierUtil.copy(param,InAndOutStockParam.class));
            }
        }
        return stockItemMap;
    }


    /**
     * 解析配置的字段 唯一键值
     * 如果选中了某个字段，但是参数里为空， 那么就按""空字符串处理。
     * @return
     */
    private String getStockKeyByParam(String field,String bizType, InAndOutStockParam request){
        if(StringUtils.isBlank(field)){
            return null;
        }
        String[] fields = field.split(",");
        Field[] obejctFields = getAllFields(InAndOutStockParam.class);
        Map<String,String> map = new HashMap<>();
        map.put("bizType",bizType);
        for(Field f:obejctFields){
            try{
                f.setAccessible(true);
                Object o =   f.get(request);
                if(o == null){
                    map.put(f.getName(), "");
                }else{
                    map.put(f.getName(), o.toString());
                }
            }catch (Exception e){
                log.error("拼接库存唯一字段组合值异常",e);
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(bizType);
        for(String name:fields){
            sb.append(map.get(name));
        }
        return MD5Util.encodeString(sb.toString());
    }


    /**
     * 获取本类及其父类的属性的方法
     * @param clazz 当前类对象
     * @return 字段数组
     */
    private static Field[] getAllFields(Class<?> clazz) {
        List<Field> fieldList = new ArrayList<>();
        while (clazz != null){
            fieldList.addAll(new ArrayList<>(Arrays.asList(clazz.getDeclaredFields())));
            clazz = clazz.getSuperclass();
        }
        Field[] fields = new Field[fieldList.size()];
        return fieldList.toArray(fields);
    }

    protected StockOperateLogPo saveOperateLog(StockItemPo stockItemPo, StockPo stockPo,
                                             StockItemPo updateStockItem, StockPo updateStock,
                                             InAndOutStockRequest request, InAndOutStockParam param, String transactionType){
        //操作数量
        BigDecimal operateQuantity = (param.getSumQuantity() == null) ? param.getOccupyQuantity():param.getOccupyQuantity();
        //源占用数量
        BigDecimal sourceOccupyQuantity = null;
        //目标占用数量
        BigDecimal targetOccupyQuantity= null;
        //源库存数量
        BigDecimal sourceSumQuantity= null;
        //目标库存数量
        BigDecimal targetSumQuantity= null;
        //源库存状态
        Integer sourceStockStatus = null;
        //目标库存状态
        Integer targetStockStatus= null;
        //源物料状态
        Integer sourceMaterialStatus= null;
        //目标物料状态
        Integer targetMaterialStatus= null;
        StockOperateLogPo stockOperateLogPo = new StockOperateLogPo();

        if(stockItemPo != null){
            BeanUtils.copyProperties(stockItemPo,stockOperateLogPo);
            stockOperateLogPo.setStockItemKey(stockItemPo.getBizConfigField());
            sourceSumQuantity= stockItemPo.getSumQuantity();
            targetSumQuantity= updateStockItem.getSumQuantity();
            sourceStockStatus = stockItemPo.getStockStatus();
            targetStockStatus= updateStockItem.getStockStatus();
            sourceMaterialStatus= stockItemPo.getMaterialStatus();
            targetMaterialStatus= updateStockItem.getMaterialStatus();
        }else if(stockPo != null){
            BeanUtils.copyProperties(stockPo,stockOperateLogPo);
            stockOperateLogPo.setStockKey(stockPo.getBizConfigField());
            sourceOccupyQuantity =  stockPo.getOccupyQuantity();
            targetOccupyQuantity= updateStock.getOccupyQuantity();
            sourceSumQuantity= stockPo.getSumQuantity();
            targetSumQuantity= updateStock.getSumQuantity();
            sourceStockStatus = stockPo.getStockStatus();
            targetStockStatus= updateStock.getStockStatus();
            sourceMaterialStatus= stockPo.getMaterialStatus();
            targetMaterialStatus= updateStock.getMaterialStatus();
        }

        stockOperateLogPo.setIdempotentNo(request.getBusinessBillNo()+request.getOperationType().getType());
        stockOperateLogPo.setTransactionType(transactionType);
        stockOperateLogPo.setOperateType(request.getOperationType().getType());
        stockOperateLogPo.setBusinessBillNo(request.getBusinessBillNo());
        stockOperateLogPo.setBusinessType(request.getBusinessType());
        stockOperateLogPo.setBizType(request.getBizType());
        stockOperateLogPo.setTargetStockStatus(targetStockStatus);
        stockOperateLogPo.setTargetMaterialStatus(targetMaterialStatus);
        stockOperateLogPo.setTargetSumQuantity(targetSumQuantity);
        stockOperateLogPo.setTargetOccupyQuantity(targetOccupyQuantity);

        stockOperateLogPo.setSourceStockStatus(sourceStockStatus);
        stockOperateLogPo.setSourceMaterialStatus(sourceMaterialStatus);
        stockOperateLogPo.setSourceOccupyQuantity(sourceOccupyQuantity);
        stockOperateLogPo.setSourceSumQuantity(sourceSumQuantity);

        stockOperateLogPo.setOperateQuantity(operateQuantity);
        stockOperateLogPo.setOrganizationCode(warehouseCache.getByBizAndCode(request.getBizType(), stockOperateLogPo.getWarehouseCode()).getOrganizationCode());
        List<StockConfigPo> stockConfigPo = stockConfigService.getByBizType(request.getBizType());
        for(StockConfigPo configPo:stockConfigPo){
            if(configPo.getConfigType() == 1){
                stockOperateLogPo.setConfigId(configPo.getId());
            }if(configPo.getConfigType() == 2){
                stockOperateLogPo.setConfigItemId(configPo.getId());
            }
        }
        stockOperateLogPo.setOperateTime(request.getOperateTime());
        stockOperateLogPo.setOperateUser(request.getOperateUser());
        return stockOperateLogPo;
    }

    private String initIdempotentNo(InAndOutStockRequest request){
        return  request.getIdempotentNo()+request.getOperationType().getType();
    }
}
