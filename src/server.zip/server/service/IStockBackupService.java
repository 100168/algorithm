package com.jiduauto.sps.server.service;

import com.jiduauto.sps.server.pojo.po.StockBackupPo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 库存备份表 服务类
 * </p>
 *
 * @author generate
 * @since 2024-10-23
 */
public interface IStockBackupService extends IService<StockBackupPo> {

   void  backUpStockByDay();

}
