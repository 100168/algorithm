package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.req.AreaCheckReq;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.baseData.AreasDto;
import com.jiduauto.sps.server.pojo.dto.param.AreaOperateParam;
import com.jiduauto.sps.server.pojo.fileexport.AreaExportDto;
import com.jiduauto.sps.server.pojo.po.AreasPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.baseData.*;
import com.jiduauto.sps.server.pojo.vo.resp.AreaDropDownResp;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 库存的区域信息 服务类
 * </p>
 *
 * @author generate
 * @since 2022-12-30
 */
public interface IAreasService extends IService<AreasPo> {

    /**
     * 增删改
     * @param areaOperateParam
     */
    BaseResult operate(AreaOperateParam areaOperateParam);


     /*
      * @Author O_chaopeng.huang
      * @Description //    区域信息查询hcp
      * @Date 10:40 2023/2/17
      * @Param
      * @return
      **/
    BasePageData<AreasDto>pageSearch(BasePageParam<AreasPageSearchReq> pageParam);


     /*
      * @Author O_chaopeng.huang
      * @Description //    添加区域信息hcp
      * @Date 15:07 2023/2/17
      * @Param
      * @return
      **/
    BaseResult singleAdd(AreasEditAndSingleAddReq areasEditAndSingleAddReq);


     /*
      * @Author O_chaopeng.huang
      * @Description //    修改区域信息
      * @Date 15:31 2023/2/17
      * @Param
      * @return
      **/
    BaseResult edit(AreasEditAndSingleAddReq areasEditAndSingleAddReq);

    /*
     * @Author O_chaopeng.huang
     * @Description //    删除一个逻辑hcp
     * @Date 15:41 2023/2/17
     * @Param
     * @return
     **/
    BaseResult deleteOne(AreasDeleteReq areasDeleteReq);

    /*
     * @Author O_chaopeng.huang
     * @Description //    根据区域唯一id查询
     * @Date 8:46 2023/2/20
     * @Param
     * @return
     **/
    BaseResult selectById(AreasByIdReq req);


     /*
      * @Author O_chaopeng.huang
      * @Description //   获取区域下拉列表
      * @Date 13:30 2023/2/20
      * @Param
      * @return
      **/
    BaseResult<List<AreaDropDownResp>>  dropAreaList(AreaDropDownReq areaDropDownReq);

    Collection<AreaExportDto> getExportDtoList(BasePageParam<AreasPageSearchReq> pageParam);

    Map<String ,AreasPo> mapAreasPo(String bizType, List<String> areasCodes);
    /**
      * 同一业务下以仓库编码与区域编码作为唯一键
      * @author O_chaopeng.huang
      */
    Map<String ,AreasPo> mapWarehouseCodeAndAreaCodeKey(String bizType, List<String> areasCodes);
    /**
      * 区域主数据存在性校验
      */
    Map<String,AreasPo> getAreasPoMap(String bizType, List<AreaCheckReq> areaCheckReqs);

}
