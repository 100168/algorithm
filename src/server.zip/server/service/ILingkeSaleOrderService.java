package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.LingkeSaleOrderDetailDto;
import com.jiduauto.sps.server.pojo.dto.LingkeSaleOrderDto;
import com.jiduauto.sps.server.pojo.po.LingkeSaleOrderPo;
import com.jiduauto.sps.server.pojo.vo.BaseResult;
import com.jiduauto.sps.server.pojo.vo.req.ExternalLingkeSynSOReq;
import com.jiduauto.sps.server.pojo.vo.req.LingkeSaleOrderPageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.OrderIdReq;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 领克销售订单 服务类
 */
public interface ILingkeSaleOrderService extends IService<LingkeSaleOrderPo> {

    /**
     * 同步领克销售订单
     */
    BaseResult<String> synSaleOrder(ExternalLingkeSynSOReq req);
    /**
      * 领克销售分页查询
      */
    BasePageData<LingkeSaleOrderDto> pageSearch(BasePageParam<LingkeSaleOrderPageSearchReq> req);
    /**
     * 领克销售详情
     */
    BasePageData<LingkeSaleOrderDetailDto> selectById(BasePageParam<OrderIdReq> req);
    /**
     * 领克销售订单导出
     */
    Collection<?> export(BasePageParam<LingkeSaleOrderPageSearchReq> pageParam);

    /**
     * 采购申请是否存在关联销售订单
     * purchaseApplyNo 采购申请订单号
     */
    Boolean isExist(String purchaseApplyNo);

    /**
     * 领克销售订单数量
     * 返回值 采购申请单号+采购申请单行号为key
     */
    Map<String, BigDecimal> mapQtyByPurchaseApplyNo(String bizType, List<String> purchaseApplyOrderNo);
}
