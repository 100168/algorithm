package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.dto.AsnAllDto;
import com.jiduauto.sps.server.pojo.dto.param.AsnReceiveParam;
import com.jiduauto.sps.server.pojo.po.AsnReceiveInfoPo;
import com.jiduauto.sps.server.pojo.vo.req.InAndOutStockRequest;

import java.util.List;

/**
 * <p>
 * 外部系统收货信息 服务类
 * </p>
 *
 * @author generate
 * @since 2022-12-14
 */
public interface IAsnReceiveInfoService extends IService<AsnReceiveInfoPo> {

    /**
     * ASN收货后， 更新ASN的状态和数量回写
     * @param asnReceiveParam
     */
    void receive(AsnReceiveParam asnReceiveParam);

    /**
     * 收货时，校验ASN订单的状态和数量
     * @param asnReceiveParam
     */
    void receiveValidate(AsnReceiveParam asnReceiveParam);

    /**
     * DHL收货后，入库确认，同步收货信息到SAP（接口:SRMJL/MM027）
     */
    void receivePushToSAP(InAndOutStockRequest request);

    /**
     * asn收货数量
     *
     * @param allDto allDto
     * @return list
     */
    List<AsnReceiveInfoPo> getAsnReceiveInfoPos(AsnAllDto allDto);
}
