package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.Enum.SalePriceTypeEnum;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.SalePriceDto;
import com.jiduauto.sps.server.pojo.dto.SalePriceSyncDto;
import com.jiduauto.sps.server.pojo.po.SalePriceApprovalDetailPo;
import com.jiduauto.sps.server.pojo.po.SalePricePo;
import com.jiduauto.sps.server.pojo.vo.req.SalePricePageSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.SalePriceSearchReq;
import com.jiduauto.sps.server.pojo.vo.req.SalePriceSyncPageSearchReq;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface ISalePriceService extends IService<SalePricePo> {

    void insertOrUpdate(List<SalePriceApprovalDetailPo> salePriceApprovalDetailPos);

    BasePageData<SalePriceDto> pageSearch(BasePageParam<SalePricePageSearchReq> pageParam);

    BasePageData<SalePriceSyncDto> syncPageSearch(BasePageParam<SalePriceSyncPageSearchReq> pageParam);

    List<SalePriceSyncDto> listEffectivePrice(SalePriceSearchReq searchReq);
    /**
      * 售后件号 ,价格类型 ,有效开始日期 ,业务类型四个字段确定唯一性
      * @author O_chaopeng.huang
      */
    Map<Long,SalePricePo> getSalePriceMap(String bizType , List<String> salePartNums);

    /**
     * 根据业务类型,零件编码,价格类型校验获取销售价格有效日期的开始日期早于或等于当前日期
     * 只获取该零件有无对应销售价格类型,并不获取对应零件的所有销售价格
     * 以零件售后件号为key,SalePricePo为value,存在则新value替换原value
     * @author O_chaopeng.huang
     */
    Map<String, SalePricePo> getSalePriceMap(String bizType , List<String> salePartNums, List<String> salePriceTypeCodes);

    /**
     * 导出
     * @author O_chaopeng.huang
     */
    Collection<?> export(BasePageParam<SalePricePageSearchReq> pageParam);
    /**
     * 价格查询给零件编码只校验存不存在价格,未校验有效期及是否为对应价格类型
     * @author O_chaopeng.huang
     */
    List<SalePricePo> getSalePricePoList(String bizType , List<String> salePartNums);
    /**
      * 定时自动更新销售价格状态
      */
    void updateStatus();

    /**
     * 初始化价格查询状态
     */
    void salePriceInitStatus();
}
