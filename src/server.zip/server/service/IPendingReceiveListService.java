package com.jiduauto.sps.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.server.pojo.BasePageData;
import com.jiduauto.sps.server.pojo.BasePageParam;
import com.jiduauto.sps.server.pojo.dto.PendingReceiveListDto;
import com.jiduauto.sps.server.pojo.fileexport.PendingReceiveExportDto;
import com.jiduauto.sps.server.pojo.po.PendingReceiveListPo;
import com.jiduauto.sps.server.pojo.vo.req.*;

import java.util.Collection;

/**
 * <p>
 * 待收货列表 服务类
 * </p>
 *
 * @author generate
 * @since 2023-08-22
 */
public interface IPendingReceiveListService extends IService<PendingReceiveListPo> {

    /**
     * 保存vp 试制试验 asn数据
     */
    void saveVpAsnData(InternalAsnAddReq req);

    /**
     * 待收货列表分页查询
     * @param req req
     * @return BasePageData<PendingReceiveListDto>
     */
    BasePageData<PendingReceiveListDto> pageSearch(BasePageParam<PendingReceiveListPageSearch> req);

    /**
     * 关单
     *
     * @param req req
     * @return boolean
     */
    Boolean close(PendingReceiveListCloseReq req);

    /**
     * 收货
     *
     * @param req req
     * @return boolean
     */
    Boolean receive(PendingReceiveListReceiveReq req);

    /**
     * 收货列表创建
     *
     * @param req req
     * @return boolean
     */
    String create(PendingReceiveListCreateReq req);

    /**
     * 异地收货
     */
    Boolean remotePlaceReceive(PendingReceiveListReceiveReq req);

    /**
     * 导出
     */
    Collection<PendingReceiveExportDto> exportSearch(BasePageParam<PendingReceiveListPageSearch> req);

    /**
     * 删单
     */
    void delete(IdReq req);
}
