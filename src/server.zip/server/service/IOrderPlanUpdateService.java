package com.jiduauto.sps.server.service;

import com.jiduauto.sps.server.pojo.AsnReceiveContextDto;
import com.jiduauto.sps.server.pojo.dto.AsnPartReceiveInfoDto;
import com.jiduauto.sps.server.pojo.dto.param.AsnReceivePartParam;
import com.jiduauto.sps.server.pojo.po.AsnBasicPo;
import com.jiduauto.sps.server.pojo.po.AsnDeliverInfoPo;

public interface IOrderPlanUpdateService {

    /**
     * 创建ASN更新发货数量
     *
     * @param asnBasicPo
     * @param asnDeliverInfoPo
     */
    void increaseDeliveryQty(AsnBasicPo asnBasicPo, AsnDeliverInfoPo asnDeliverInfoPo);

    /**
     * 删除ASN更新发货数量
     *
     * @param asnBasicPo
     * @param asnDeliverInfoPo
     */
    void decreaseDeliveryQty(AsnBasicPo asnBasicPo, AsnDeliverInfoPo asnDeliverInfoPo);

    /**
     * ASN收货更新收货数量
     *
     * @param asnBasicPo
     * @param asnDeliverInfoPo
     * @param asnReceivePartParam
     */
    void increaseReceivedQty(AsnBasicPo asnBasicPo, AsnDeliverInfoPo asnDeliverInfoPo, AsnReceivePartParam asnReceivePartParam);

    /**
     * ASN欠收更新发货数量
     *
     * @param asnBasicPo
     * @param asnDeliverInfoPo
     * @param asnPartReceiveInfoDto
     */
    void decreaseDeliveryQty(AsnBasicPo asnBasicPo, AsnDeliverInfoPo asnDeliverInfoPo, AsnPartReceiveInfoDto asnPartReceiveInfoDto);
}
