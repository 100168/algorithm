package com.jiduauto.sps.stock.server.controller.internal;

import cn.hutool.extra.spring.SpringUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.OperationType;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.stock.server.pojo.vo.InternalStockResp;
import com.jiduauto.sps.stock.server.pojo.vo.StockRequest;
import com.jiduauto.sps.stock.server.pojo.vo.StockSearchReq;
import com.jiduauto.sps.stock.server.service.IStockService;
import com.jiduauto.sps.stock.server.service.impl.AbstractStockOperate;
import com.jiduauto.sps.stock.server.service.impl.OccupyStock;
import com.jiduauto.sps.stock.server.service.impl.UnOccupyStock;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/internal/stock")
public class InternalStockController implements InitializingBean {

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private IStockService stockService;

    public static final Map<OperationType, AbstractStockOperate> STRATEGY_MAP = new HashMap<>();

    /**
     * 库存主数据查询
     */
    @PostMapping("/search")
    public BaseResult<List<InternalStockResp>> search(@RequestBody @Valid StockSearchReq req) {
        return stockService.search(req);
    }

    /**
     * 库存占用 or 取消占用操作
     */
    @PostMapping("/occupy")
    public BaseResult<String> occupyStock(@RequestBody @Valid StockRequest req) {
        if (req.getOperationType() != OperationType.OCCUPY && req.getOperationType() != OperationType.UN_OCCUPY) {
            return BaseResult.error("不支持的操作类型");
        }
        String lockKey = String.format(BaseConstants.RedisKey.STOCK_LOCK_KEY, req.getBizType(), req.getIdempotentNo());
        RLock rLock = redissonClient.getLock(lockKey);
        try {
            rLock.lock();
            return STRATEGY_MAP.get(req.getOperationType()).operateStock(req);
        } catch (BizException e) {
            return BaseResult.error(e.getErrCode(), e.getErrMessage());
        } finally {
            rLock.unlock();
        }
    }

    @Override
    public void afterPropertiesSet() {
        STRATEGY_MAP.put(OperationType.OCCUPY, SpringUtil.getBean(OccupyStock.class));
        STRATEGY_MAP.put(OperationType.UN_OCCUPY, SpringUtil.getBean(UnOccupyStock.class));
    }
}
