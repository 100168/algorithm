package com.jiduauto.sps.stock.server.pojo.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.jiduauto.sps.sdk.annotation.BizTypeCheck;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;


/**
 * 查询库存
 */
@Data
public class StockSearchReq {

    /**
     * 渠道code
     */
    @NotBlank(message = "channelCode 不能为空")
    private String channelCode;

    /**
     * 物料状态
     * 1：正常  默认
     * -1：破损
     */
    private Integer materialStatus = 1;

    /**
     * 库存状态
     * 1 正常
     * 2 待上架
     * 3 占用
     * -1 冻结
     * -2  待发货冻结
     */
    private Integer stockStatus = 1;

    /**
     * 仓库编码
     */
    private String warehouseCode = "G59";

    /**
     * 供应商编码
     */
    private String supplierCode;

    /**
     * 批次号
     */
    private String batchNo;

    /**
     * 序列号
     */
    private String sequenceNo;

    /**
     * 零件条码
     */
    private String materialBarCode;

    /**
     * 零件种类
     */
    private String materialSort;

    /**
     * 车辆号
     */
    private String carCode;


    /**
     * 入库日期 yyyy-MM-dd
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private String addDate;

    /**
     * 生产日期 yyyy-MM-dd
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private String productDate;

    /**
     * 失效日期 yyyy-MM-dd
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private String expireDate;

    /**
     * 箱号
     */
    private String caseNo;

    /**
     * 托盘号
     */
    private String palletNo;

    /**
     * 项目
     */
    private String projectCode;

    /**
     * 阶段
     */
    private String stageCode;

    /**
     * WBS编号
     */
    private String wbsCode;

    /**
     * 业务单号
     */
    private String purchaseOrderNo;

    /**
     * 行项目号
     */
    private String columnProjectNo;

    /**
     * 样件状态
     */
    private String samplePartStatus;

    @Valid
    @NotNull(message = "查询条件不能为空;")
    @Size(min = 1, message = "params size min 1;")
    private List<Param> params;

    @Data
    public static class Param {
        /**
         * 零件code
         */
        @NotBlank(message = "零件code不能为空")
        private String materialCode;
        /**
         * 所属零件的业务类型。
         */
        @NotBlank(message = "所属零件的业务类型不能为空")
        @BizTypeCheck
        private String bizType;
    }

    public String getWarehouseCode() {
        return warehouseCode == null ? "G59" : warehouseCode;
    }

    public Integer getStockStatus() {
        return stockStatus == null ? 1 : stockStatus;
    }

    public Integer getMaterialStatus() {
        return materialStatus == null ? 1 : materialStatus;
    }
}


