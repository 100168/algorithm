package com.jiduauto.sps.stock.server.pojo.vo;

import lombok.Data;


@Data
public class InternalStockResp {
    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 零件号
     */
    private String materialCode;

    /**
     * 可用数量
     */
    private Integer sumQuantity;
}
