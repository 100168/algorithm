package com.jiduauto.sps.stock.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.stock.server.pojo.vo.InternalStockResp;
import com.jiduauto.sps.stock.server.pojo.vo.StockSearchReq;

import java.util.Collection;
import java.util.List;

/**
 * 库存表 服务类
 */
public interface IStockService extends IService<StockPo> {

    /**
     * 查询库存主数据  支持跨业务
     */
    BaseResult<List<InternalStockResp>> search(StockSearchReq pageParam);

    List<StockPo> getByBizConfigFieldsAll(Collection<String> bizConfigFields);

    List<StockItemPo> getItemByBizConfigFieldsAll(Collection<String> bizConfigFields);
}
