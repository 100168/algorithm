package com.jiduauto.sps.stock.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.StockOperateRecordPo;

/**
 * 库存交易记录表 Mapper 接口
 */
public interface StockOperateRecordMapper extends BaseMapper<StockOperateRecordPo> {

    /**
     * 查询幂等性字段 防止重复提交
     */
    Long getByBizTypeAndIdempotentNo(String bizType, String idempotentNo);
}
