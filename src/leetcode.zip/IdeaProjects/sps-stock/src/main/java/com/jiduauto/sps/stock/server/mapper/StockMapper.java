package com.jiduauto.sps.stock.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.StockItemPo;
import com.jiduauto.sps.sdk.pojo.po.StockPo;
import org.apache.ibatis.annotations.Param;

import java.util.Collection;
import java.util.List;

public interface StockMapper extends BaseMapper<StockPo> {

    /**
     * 后台配置的唯一字段组合key  查询库存记录  批量
     */
    List<StockPo> getByBizConfigFields(@Param("bizConfigFields") Collection<String> bizConfigFields);

    /**
     * 后台配置的唯一字段组合key  查询库存记录  完整字段
     */
    List<StockPo> getByBizConfigFieldsAll(@Param("bizConfigFields") Collection<String> bizConfigFields);

    /**
     * 后台配置的唯一字段组合key  查询库存明细记录  完整字段
     */
    List<StockItemPo> getItemByBizConfigFieldsAll(@Param("bizConfigFields") Collection<String> bizConfigFields);

    /**
     * 增加占用数量
     */
    int occupyQuantityById(@Param("id") Long stockId, @Param("qty") Integer qty);

    /**
     * 减少占用数量
     */
    int unOccupyQuantityById(@Param("id") Long stockId, @Param("qty") Integer qty);
}
