package com.jiduauto.sps.stock.server.pojo.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;


/**
 * 需要和 stock 表字段保持一致
 */
@Data
public class StockParam implements Serializable {

    /**
     * 渠道code
     */
    @NotBlank(message = "channelCode 不能为空")
    private String channelCode;

    /**
     * 操作数量
     */
    @NotNull(message = "操作数量不能为空;")
    @Min(value = 1, message = "操作数量必须大于0;")
    private Integer qty;

    /**
     * 行号
     */
    private String columnNo;

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 物料编码
     */
    @NotBlank(message = "物料编码不能为空;")
    private String materialCode;

    /**
     * 供应商编码
     */
    private String supplierCode;

    /**
     * 批次号
     */
    private String batchNo;

    /**
     * 序列号
     */
    private String sequenceNo;

    /**
     * 零件条码
     */
    private String materialBarCode;

    /**
     * 物料状态
     * 1：正常  默认
     * -1：破损
     */
    private Integer materialStatus;

    /**
     * 零件种类
     */
    private String materialSort;

    /**
     * 车辆号
     */
    private String carCode;

    /**
     * 库存状态
     * 1 正常
     * 2 待上架
     * 3 占用
     * -1 冻结
     * -2  待发货冻结
     */
    private Integer stockStatus;

    /**
     * 入库日期
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private String addDate;

    /**
     * 生产日期
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private String productDate;

    /**
     * 失效日期
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private String expireDate;

    /**
     * 箱号
     */
    private String caseNo;

    /**
     * 托盘号
     */
    private String palletNo;

    /**
     * 项目
     */
    private String projectCode;

    /**
     * 阶段
     */
    private String stageCode;

    /**
     * WBS编号
     */
    private String wbsCode;

    /**
     * 业务单号
     */
    private String purchaseOrderNo;

    /**
     * 行项目号
     */
    private String columnProjectNo;

    /**
     * 样件状态
     */
    private String samplePartStatus;

    /**
     * 仓库代码
     */
    private String warehouseCode;
}
