package com.jiduauto.sps.stock.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.sdk.enums.MaterialStockStatusEnum;
import com.jiduauto.sps.sdk.enums.OperationType;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.enums.StockStatusEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.pojo.po.StockConfigPo;
import com.jiduauto.sps.sdk.pojo.po.StockItemPo;
import com.jiduauto.sps.sdk.pojo.po.StockOperateRecordPo;
import com.jiduauto.sps.sdk.pojo.po.StockPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.StockUtils;
import com.jiduauto.sps.stock.server.cache.StockChannelConfigCache;
import com.jiduauto.sps.stock.server.pojo.vo.StockRequest;
import com.jiduauto.sps.stock.server.service.IStockConfigService;
import com.jiduauto.sps.stock.server.service.IStockOperateRecordService;
import com.jiduauto.sps.stock.server.service.IStockService;
import org.springframework.aop.framework.AopContext;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum.QUANTITY_NOT_ENOUGH;

/**
 * 库存操作
 */
@EnableAspectJAutoProxy(proxyTargetClass = true, exposeProxy = true)
public abstract class AbstractStockOperate {
    protected static final String ERR_STR = QUANTITY_NOT_ENOUGH.getDesc() + "物料:%s";

    protected final IStockConfigService stockConfigService;
    protected final IStockService stockService;
    protected final IStockOperateRecordService stockOperateRecordService;
    protected final StockChannelConfigCache stockChannelConfigCache;


    protected AbstractStockOperate(IStockConfigService stockConfigService,
                                   IStockService stockService,
                                   IStockOperateRecordService stockOperateRecordService,
                                   StockChannelConfigCache stockChannelConfigCache) {
        this.stockConfigService = stockConfigService;
        this.stockService = stockService;
        this.stockOperateRecordService = stockOperateRecordService;
        this.stockChannelConfigCache = stockChannelConfigCache;
    }

    /**
     * 操作库存
     */
    public BaseResult<String> operateStock(StockRequest req) {
        //检查幂等
        if (stockOperateRecordService.checkIdempotent(req)) {
            return BaseResult.OK();
        }

        //构建参数
        Map<String, InAndOutStockParam> stockMap = handleStockParam(req);
        Map<String, InAndOutStockParam> stockItemMap = handleStockItemParam(req);

        Set<String> stockKeys = stockMap.keySet();
        Set<String> stockItemKeys = stockItemMap.keySet();

        //数量校验
        List<StockPo> stockPos = stockService.getByBizConfigFieldsAll(stockKeys);
        checkStockPoList(stockMap, stockPos);

        List<StockItemPo> stockItemPos = stockService.getItemByBizConfigFieldsAll(stockItemKeys);
        checkStockItemPoList(stockItemMap, stockItemPos);

        //更新库存
        ((AbstractStockOperate) (AopContext.currentProxy())).updateStock(req, stockMap, stockItemMap, stockPos, stockItemPos);
        return BaseResult.OK();
    }

    /**
     * 检查库存主数据
     */
    protected void checkStockPoList(Map<String, InAndOutStockParam> stockMap, List<StockPo> stockPos) {
        if (stockMap.keySet().size() != stockPos.size()) {
            //有物料不存在库存记录
            throw new BizException(SpsResponseCodeEnum.STOCK_NOT_EXIST);
        }
        for (StockPo stockPo : stockPos) {
            checkQty(stockPo, stockMap.get(stockPo.getBizConfigField()));
        }
    }

    /**
     * 检查库存明细数据
     */
    protected void checkStockItemPoList(Map<String, InAndOutStockParam> stockItemMap, List<StockItemPo> stockItemPos) {
        if (stockItemMap.keySet().size() != stockItemPos.size()) {
            //有物料不存在库存记录
            throw new BizException(SpsResponseCodeEnum.STOCK_NOT_EXIST);
        }
        for (StockItemPo stockItemPo : stockItemPos) {
            checkQty(stockItemPo, stockItemMap.get(stockItemPo.getBizConfigField()));
        }
    }

    /**
     * 处理请求参数 生成要处理的库存主数据
     *
     * @param req 请求参数
     * @return <stock Key, 操作参数>
     */
    public Map<String, InAndOutStockParam> handleStockParam(StockRequest req) {

        Map<String, String> materialChannelMap = new HashMap<>();
        if (req.getOperationType() == OperationType.UN_OCCUPY) {
            List<StockOperateRecordPo> list = stockOperateRecordService.list(
                    Wrappers.lambdaQuery(StockOperateRecordPo.class)
                            .eq(StockOperateRecordPo::getBizType, req.getBizType())
                            .eq(StockOperateRecordPo::getOccupyNo, req.getBusinessBillNo())
                            .eq(StockOperateRecordPo::getOperateType, OperationType.OCCUPY.toString())
                            .ne(StockOperateRecordPo::getStockKey, "")
            );
            if (CollUtil.isEmpty(list)) {
                throw new BizException("该订单未发生占用");
            }
            List<StockPo> stockPo = stockService.getByBizConfigFieldsAll(list.stream().map(StockOperateRecordPo::getStockKey).collect(Collectors.toList()));
            materialChannelMap = stockPo.stream().collect(Collectors.toMap(StockPo::getMaterialCode, StockPo::getChannelCode, (v1, v2) -> v2));
        }

        Map<String, String> finalMaterialChannelMap = materialChannelMap;
        List<InAndOutStockParam> params = req.getParams().stream().map(param -> {
            InAndOutStockParam target = new InAndOutStockParam();
            target.setAddDate(param.getAddDate());
            target.setBatchNo(param.getBatchNo());
            target.setBizType(param.getBizType());
            target.setCarCode(param.getCarCode());
            target.setCaseNo(param.getCaseNo());
            target.setColumnNo(param.getColumnNo());
            target.setColumnProjectNo(param.getColumnProjectNo());
            target.setExpireDate(param.getExpireDate());
            target.setMaterialBarCode(param.getMaterialBarCode());
            target.setMaterialCode(param.getMaterialCode());
            target.setMaterialSort(param.getMaterialSort());
            target.setPalletNo(param.getPalletNo());
            target.setProductDate(param.getProductDate());
            target.setProjectCode(param.getProjectCode());
            target.setPurchaseOrderNo(param.getPurchaseOrderNo());
            target.setSamplePartStatus(param.getSamplePartStatus());
            target.setSequenceNo(param.getSequenceNo());
            target.setStageCode(param.getStageCode());
            target.setSupplierCode(param.getSupplierCode());
            target.setWbsCode(param.getWbsCode());
            target.setSumQuantity(new BigDecimal(param.getQty()));
            target.setOccupyQuantity(new BigDecimal(param.getQty()));
            if (req.getOperationType() == OperationType.UN_OCCUPY) {
                target.setChannelCode(finalMaterialChannelMap.getOrDefault(param.getMaterialCode(), ""));
            } else {
                target.setChannelCode(stockChannelConfigCache.getByBizType(param.getBizType()));
            }
            target.setMaterialStatus(param.getMaterialStatus() == null ? MaterialStockStatusEnum.S1.getCode() : param.getMaterialStatus());
            target.setStockStatus(param.getStockStatus() == null ? StockStatusEnum.NORMAL.getValue() : param.getStockStatus());
            target.setWarehouseCode(param.getWarehouseCode() == null ? "G59" : param.getWarehouseCode());
            return target;
        }).collect(Collectors.toList());


        //业务主键 配置查询
        Map<String, InAndOutStockParam> stockMap = new HashMap<>(1 << 4);
        //重复物料信息 合并
        for (InAndOutStockParam param : params) {
            if (param.getSumQuantity() != null && param.getSumQuantity().compareTo(BigDecimal.ZERO) == 0) {
                continue;
            }
            StockConfigPo stockConfigPo1 = stockConfigService.main(param.getBizType());

            if (stockConfigPo1 == null) {
                //占用和取消占用 必须 库存表配置
                throw new BizException(SpsResponseCodeEnum.STOCK_CONFIG_NOT_EXIST);
            }
            String key = StockUtils.getStockKeyByParam(stockConfigPo1.getField(), param.getBizType(), param);

            if (stockMap.containsKey(key)) {
                //重复物料 入参 ， 累加
                InAndOutStockParam temp = stockMap.get(key);
                if (temp.getSumQuantity() != null && param.getSumQuantity() != null) {
                    temp.setSumQuantity(temp.getSumQuantity().add(param.getSumQuantity()));
                }
                if (temp.getOccupyQuantity() != null && param.getOccupyQuantity() != null) {
                    temp.setOccupyQuantity(temp.getOccupyQuantity().add(param.getOccupyQuantity()));
                }
                stockMap.put(key, temp);
            } else {
                stockMap.put(key, copy(param));
            }
        }
        return stockMap;
    }

    private InAndOutStockParam copy(InAndOutStockParam param) {
        InAndOutStockParam target = new InAndOutStockParam();
        target.setAddDate(param.getAddDate());
        target.setAreaCode(param.getAreaCode());
        target.setAsset(param.getAsset());
        target.setBatchNo(param.getBatchNo());
        target.setBizType(param.getBizType());
        target.setBrokenQuantity(param.getBrokenQuantity());
        target.setCarCode(param.getCarCode());
        target.setCaseNo(param.getCaseNo());
        target.setColumnNo(param.getColumnNo());
        target.setColumnProjectNo(param.getColumnProjectNo());
        target.setCompanyCode(param.getCompanyCode());
        target.setCostCenter(param.getCostCenter());
        target.setExpireDate(param.getExpireDate());
        target.setIncorrectQuantity(param.getIncorrectQuantity());
        target.setLocationCode(param.getLocationCode());
        target.setMaterialBarCode(param.getMaterialBarCode());
        target.setMaterialCode(param.getMaterialCode());
        target.setMaterialSort(param.getMaterialSort());
        target.setMaterialStatus(param.getMaterialStatus());
        target.setOccupyQuantity(param.getOccupyQuantity());
        target.setPalletNo(param.getPalletNo());
        target.setPlanQuantity(param.getPlanQuantity());
        target.setProductDate(param.getProductDate());
        target.setProjectCode(param.getProjectCode());
        target.setPurchaseOrderNo(param.getPurchaseOrderNo());
        target.setRemark(param.getRemark());
        target.setSamplePartStatus(param.getSamplePartStatus());
        target.setSequenceNo(param.getSequenceNo());
        target.setSettlementType(param.getSettlementType());
        target.setStageCode(param.getStageCode());
        target.setStockStatus(param.getStockStatus());
        target.setSumQuantity(param.getSumQuantity());
        target.setSupplierCode(param.getSupplierCode());
        target.setUnderTakeCompany(param.getUnderTakeCompany());
        target.setWarehouseCode(param.getWarehouseCode());
        target.setWbsCode(param.getWbsCode());
        return target;
    }


    /**
     * 处理请求参数 生成要操作的库存明细
     *
     * @param req 请求参数
     * @return <stockItem Key, 操作参数>
     */
    public Map<String, InAndOutStockParam> handleStockItemParam(StockRequest req) {
        return new HashMap<>();
    }

    /**
     * 检查库存主数据相关 数量是否满足
     *
     * @param stockPo    库存主数据
     * @param stockParam 操作参数
     */
    abstract public void checkQty(StockPo stockPo, InAndOutStockParam stockParam);

    /**
     * 检查库存明细数据相关 数量是否满足
     *
     * @param stockItemPo 库存明细数据
     * @param stockParam  操作参数
     */
    abstract public void checkQty(StockItemPo stockItemPo, InAndOutStockParam stockParam);

    /**
     * 更新  主库存 & 库存明细 数据
     *
     * @param req          库存变动请求
     * @param stockMap     处理后的库存参数 合并重复零件
     * @param stockPos     要操作的库存主数据  不允许为空
     * @param stockItemPos 要操作的库存明细   可以为空
     */
    @Transactional(rollbackFor = Exception.class)
    public void updateStock(StockRequest req,
                            Map<String, InAndOutStockParam> stockMap,
                            Map<String, InAndOutStockParam> stockItemMap,
                            @Nonnull List<StockPo> stockPos,
                            List<StockItemPo> stockItemPos) {
        for (StockPo stockPo : stockPos) {
            updateStock(stockPo.getId(), stockMap.get(stockPo.getBizConfigField()).getSumQuantity().intValue(), stockPo.getMaterialCode());
        }
        if (CollUtil.isNotEmpty(stockItemPos) && CollUtil.isNotEmpty(stockItemMap.keySet())) {
            for (StockItemPo stockItemPo : stockItemPos) {
                updateStockItem(stockItemPo.getId(), stockItemMap.get(stockItemPo.getBizConfigField()).getSumQuantity().intValue(), stockItemPo.getMaterialCode());
            }
        }
        saveLog(req, stockMap, stockItemMap, stockPos, stockItemPos);
    }

    /**
     * 更新 库存 原子操作
     */
    abstract public void updateStock(Long id, Integer qty, String materialCode);

    /**
     * 更新 库存明细 原子操作
     */
    abstract public void updateStockItem(Long id, Integer qty, String materialCode);

    /**
     * 保存操作日志
     */
    abstract public void saveLog(StockRequest req,
                                 Map<String, InAndOutStockParam> stockMap,
                                 Map<String, InAndOutStockParam> stockItemMap,
                                 @Nonnull List<StockPo> stockPos,
                                 List<StockItemPo> stockItemPos);

}
