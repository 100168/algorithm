package com.jiduauto.sps.stock.server.cache;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.jiduauto.sps.sdk.pojo.po.StockChannelConfigDetailPo;
import com.jiduauto.sps.stock.server.mapper.StockChannelConfigDetailMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.enums.StockOperationType.SM20;

@Component
@Slf4j
public class StockChannelConfigCache implements InitializingBean {

    @Resource
    private StockChannelConfigDetailMapper stockChannelConfigDetailMapper;

    private final LoadingCache<String, String> cache = Caffeine.newBuilder()
            .refreshAfterWrite(15, TimeUnit.MINUTES)
            .build(this::queryByBizType);

    public String getByBizType(String bizType) {
        try {
            return Objects.requireNonNull(cache.get(bizType));
        } catch (Exception e) {
            log.error("查询库存业务配置缓存异常", e);
            return queryByBizType(bizType);
        }
    }


    public String queryByBizType(String bizType) {
        StockChannelConfigDetailPo configDetailPo = stockChannelConfigDetailMapper.selectOne(Wrappers.lambdaQuery(StockChannelConfigDetailPo.class)
                .eq(StockChannelConfigDetailPo::getBusinessType, SM20.getOperationType())
                .eq(StockChannelConfigDetailPo::getOrderType, "OUT")
                .eq(StockChannelConfigDetailPo::getBizType, bizType)
        );
        if (configDetailPo == null) {
            return "";
        }
        return configDetailPo.getChannelCode();
    }

    /**
     * 根据业务类型删缓存
     */
    public void remove(String bizType) {
        cache.invalidate(bizType);
    }

    @Override
    public void afterPropertiesSet() {
        List<StockChannelConfigDetailPo> detailPos = stockChannelConfigDetailMapper.selectList(Wrappers.lambdaQuery(StockChannelConfigDetailPo.class)
                .eq(StockChannelConfigDetailPo::getBusinessType, SM20.getOperationType())
                .eq(StockChannelConfigDetailPo::getOrderType, "OUT")
        );
        Map<String, StockChannelConfigDetailPo> bizTypeAndBussTypeMap =
                detailPos.stream().collect(Collectors.toMap(StockChannelConfigDetailPo::getBizType, v -> v, (v1, v2) -> v2));
        bizTypeAndBussTypeMap.forEach((key, value) -> cache.put(key, value.getChannelCode()));
    }
}
