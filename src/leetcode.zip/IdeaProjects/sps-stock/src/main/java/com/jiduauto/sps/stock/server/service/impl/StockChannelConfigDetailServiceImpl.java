package com.jiduauto.sps.stock.server.service.impl;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.sdk.pojo.po.StockChannelConfigDetailPo;
import com.jiduauto.sps.stock.server.mapper.StockChannelConfigDetailMapper;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 库存渠道配置明细表 服务实现类
 * </p>
 *
 * @author generate
 * @since 2024-09-26
 */
@Service
public class StockChannelConfigDetailServiceImpl extends ServiceImpl<StockChannelConfigDetailMapper, StockChannelConfigDetailPo> implements IService<StockChannelConfigDetailPo> {


}
