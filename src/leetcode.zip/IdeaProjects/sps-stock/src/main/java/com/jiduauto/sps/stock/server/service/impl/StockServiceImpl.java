package com.jiduauto.sps.stock.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.sdk.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.pojo.po.StockConfigPo;
import com.jiduauto.sps.sdk.pojo.po.StockItemPo;
import com.jiduauto.sps.sdk.pojo.po.StockPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.StockUtils;
import com.jiduauto.sps.stock.server.cache.StockChannelConfigCache;
import com.jiduauto.sps.stock.server.mapper.StockMapper;
import com.jiduauto.sps.stock.server.pojo.vo.InternalStockResp;
import com.jiduauto.sps.stock.server.pojo.vo.StockSearchReq;
import com.jiduauto.sps.stock.server.service.IStockConfigService;
import com.jiduauto.sps.stock.server.service.IStockService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;


/**
 * 库存表 服务实现类
 */
@Service
public class StockServiceImpl extends ServiceImpl<StockMapper, StockPo> implements IStockService {

    @Resource
    private StockMapper stockMapper;

    @Resource
    private IStockConfigService stockConfigService;

    @Resource
    private StockChannelConfigCache stockChannelConfigCache;

    /**
     * 查询库存主数据  支持跨业务
     */
    @Override
    public BaseResult<List<InternalStockResp>> search(StockSearchReq req) {
        Set<String> stockKey = getStockKey(req);
        List<StockPo> list = stockMapper.getByBizConfigFields(stockKey);
        if (CollUtil.isEmpty(list)) {
            return BaseResult.OK(new ArrayList<>());
        }
        List<InternalStockResp> ret = list.stream().map(stockPo -> {
            InternalStockResp resp = new InternalStockResp();
            resp.setBizType(stockPo.getBizType());
            resp.setMaterialCode(stockPo.getMaterialCode());
            resp.setSumQuantity(stockPo.getSumQuantity().subtract(stockPo.getOccupyQuantity()).intValue());
            return resp;
        }).collect(Collectors.toList());
        return BaseResult.OK(ret);
    }

    private Set<String> getStockKey(StockSearchReq req) {
        return req.getParams().stream()
                .map(param -> {
                    InAndOutStockParam target = new InAndOutStockParam();
                    target.setAddDate(req.getAddDate());
                    target.setBatchNo(req.getBatchNo());
                    target.setCarCode(req.getCarCode());
                    target.setCaseNo(req.getCaseNo());
                    target.setColumnProjectNo(req.getColumnProjectNo());
                    target.setExpireDate(req.getExpireDate());
                    target.setMaterialBarCode(req.getMaterialBarCode());
                    target.setMaterialSort(req.getMaterialSort());
                    target.setMaterialStatus(req.getMaterialStatus());
                    target.setPalletNo(req.getPalletNo());
                    target.setProductDate(req.getProductDate());
                    target.setProjectCode(req.getProjectCode());
                    target.setPurchaseOrderNo(req.getPurchaseOrderNo());
                    target.setSamplePartStatus(req.getSamplePartStatus());
                    target.setSequenceNo(req.getSequenceNo());
                    target.setStageCode(req.getStageCode());
                    target.setStockStatus(req.getStockStatus());
                    target.setSupplierCode(req.getSupplierCode());
                    target.setWarehouseCode(req.getWarehouseCode());
                    target.setWbsCode(req.getWbsCode());
                    target.setMaterialCode(param.getMaterialCode());
                    target.setChannelCode(stockChannelConfigCache.getByBizType(param.getBizType()));
                    StockConfigPo main = stockConfigService.main(param.getBizType());
                    return StockUtils.getStockKeyByParam(main == null ? "" : main.getField(), param.getBizType(), target);
                }).collect(Collectors.toSet());
    }


    /**
     * 后台配置的唯一字段组合key  查询库存记录  完整字段
     */
    @Override
    public List<StockPo> getByBizConfigFieldsAll(Collection<String> bizConfigFields) {
        return stockMapper.getByBizConfigFieldsAll(bizConfigFields);
    }

    /**
     * 后台配置的唯一字段组合key  查询库存明细记录  完整字段
     */
    @Override
    public List<StockItemPo> getItemByBizConfigFieldsAll(Collection<String> bizConfigFields) {
        if (CollUtil.isEmpty(bizConfigFields)) {
            return new ArrayList<>();
        }
        return stockMapper.getItemByBizConfigFieldsAll(bizConfigFields);
    }
}