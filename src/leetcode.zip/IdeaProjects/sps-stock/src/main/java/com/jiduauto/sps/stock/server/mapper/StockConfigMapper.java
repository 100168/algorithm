package com.jiduauto.sps.stock.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.StockConfigPo;

import java.util.List;

public interface StockConfigMapper extends BaseMapper<StockConfigPo> {

    /**
     * 查询 业务配置的 字段集合
     */
    List<StockConfigPo> getByBizType(String bizType);
}
