package com.jiduauto.sps.stock.server.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.po.StockConfigPo;

/**
 * 库存业务配置表 服务类
 */
public interface IStockConfigService extends IService<StockConfigPo> {

    /**
     * 查询 业务配置 库存主数据配置
     */
    StockConfigPo main(String bizType);
}
