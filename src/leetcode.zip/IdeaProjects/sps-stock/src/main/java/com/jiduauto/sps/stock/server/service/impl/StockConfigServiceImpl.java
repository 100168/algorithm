package com.jiduauto.sps.stock.server.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.sdk.pojo.po.StockConfigPo;
import com.jiduauto.sps.stock.server.cache.StockConfigCache;
import com.jiduauto.sps.stock.server.mapper.StockConfigMapper;
import com.jiduauto.sps.stock.server.service.IStockConfigService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

@Service
public class StockConfigServiceImpl extends ServiceImpl<StockConfigMapper, StockConfigPo> implements IStockConfigService {

    @Resource
    private StockConfigCache stockConfigCache;

    /**
     * 查询 业务配置 库存主数据配置
     */
    @Override
    public StockConfigPo main(String bizType) {
        List<StockConfigPo> stockConfigPos = stockConfigCache.getByBizType(bizType);
        for (StockConfigPo po : stockConfigPos) {
            if (Objects.equals(po.getConfigType(), 1)) {
                return po;
            }
        }
        return null;
    }

}
