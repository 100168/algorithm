package com.jiduauto.sps.stock.server.pojo.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.jiduauto.sps.sdk.enums.OperationType;
import com.jiduauto.sps.sdk.pojo.req.SpsBaseReq;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class StockRequest extends SpsBaseReq {

    /**
     * 操作类型
     * OCCUPY    占用,
     * UN_OCCUPY 取消占用
     */
    @NotNull(message = "操作类型不能为空;")
    private OperationType operationType;

    /**
     * 业务单号
     */
    @NotBlank(message = "业务单号不能为空;")
    private String businessBillNo;

    /**
     * 幂等操作流水号 需要保证唯一
     */
    @NotBlank(message = "幂等操作流水号不能为空;")
    private String idempotentNo;

    /**
     * 操作人
     */
    @NotBlank(message = "操作人不能为空")
    private String operateUser;

    /**
     * 操作时间
     */
    @NotNull(message = "操作时间不能为空")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime operateTime;

    /**
     * 批量物料
     */
    @Valid
    @NotNull(message = "物料不能为空;")
    @Size(min = 1, max = 200, message = "params size min 1, max 200;")
    private List<StockParam> params;
}
