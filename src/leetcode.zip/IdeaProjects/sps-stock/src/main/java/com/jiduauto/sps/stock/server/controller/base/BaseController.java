package com.jiduauto.sps.stock.server.controller.base;

import com.jiduauto.javakit.common.biz.Result;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zhaojl
 */
@RestController
public class BaseController {

    @RequestMapping("/misc/ping")
    @ResponseBody
    public Result<String> ping() {
        return Result.ofSuccess("success");
    }
}

