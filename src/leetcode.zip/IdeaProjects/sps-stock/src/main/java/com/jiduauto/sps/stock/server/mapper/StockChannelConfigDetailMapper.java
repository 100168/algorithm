package com.jiduauto.sps.stock.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.StockChannelConfigDetailPo;

/**
 * <p>
 * 库存渠道配置明细表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-09-26
 */
public interface StockChannelConfigDetailMapper extends BaseMapper<StockChannelConfigDetailPo> {

}
