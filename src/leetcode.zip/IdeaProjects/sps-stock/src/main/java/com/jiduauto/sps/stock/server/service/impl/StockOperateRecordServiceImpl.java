package com.jiduauto.sps.stock.server.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.sdk.pojo.po.StockOperateRecordPo;
import com.jiduauto.sps.stock.server.mapper.StockOperateRecordMapper;
import com.jiduauto.sps.stock.server.pojo.vo.StockRequest;
import com.jiduauto.sps.stock.server.service.IStockOperateRecordService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


/**
 * 库存交易记录表 服务实现类
 */
@Service
public class StockOperateRecordServiceImpl extends ServiceImpl<StockOperateRecordMapper, StockOperateRecordPo> implements IStockOperateRecordService {

    @Resource
    private StockOperateRecordMapper stockOperateRecordMapper;

    /**
     * 判断 幂等 是否已经处理过
     */
    @Override
    public boolean checkIdempotent(StockRequest request) {
        return stockOperateRecordMapper.getByBizTypeAndIdempotentNo(request.getBizType(),
                request.getIdempotentNo() + request.getOperationType().getType()) != null;
    }
}
