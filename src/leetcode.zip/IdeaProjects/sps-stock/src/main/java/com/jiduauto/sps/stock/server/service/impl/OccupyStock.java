package com.jiduauto.sps.stock.server.service.impl;

import com.jiduauto.sps.sdk.enums.StockOperationType;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.pojo.po.StockItemPo;
import com.jiduauto.sps.sdk.pojo.po.StockOperateRecordPo;
import com.jiduauto.sps.sdk.pojo.po.StockPo;
import com.jiduauto.sps.stock.server.cache.StockChannelConfigCache;
import com.jiduauto.sps.stock.server.mapper.StockMapper;
import com.jiduauto.sps.stock.server.pojo.vo.StockRequest;
import com.jiduauto.sps.stock.server.service.IStockConfigService;
import com.jiduauto.sps.stock.server.service.IStockOperateRecordService;
import com.jiduauto.sps.stock.server.service.IStockService;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum.QUANTITY_NOT_ENOUGH;
import static java.util.stream.Collectors.toMap;

@Component
public class OccupyStock extends AbstractStockOperate {

    @Resource
    private StockMapper stockMapper;

    @Resource
    private IStockOperateRecordService stockOperateRecordService;

    protected OccupyStock(IStockConfigService stockConfigService,
                          IStockService stockService,
                          IStockOperateRecordService stockOperateRecordService,
                          StockChannelConfigCache stockChannelConfigCache
    ) {
        super(stockConfigService, stockService, stockOperateRecordService, stockChannelConfigCache);
    }


    /**
     * 重写检查库存明细方法
     * 因为占用不操作库存明细数据
     */
    @Override
    public void checkStockItemPoList(Map<String, InAndOutStockParam> stockItemMap, List<StockItemPo> stockItemPos) {
    }


    /**
     * 检查库存主数据相关 数量是否满足
     *
     * @param stockPo    库存主数据
     * @param stockParam 操作参数
     */
    @Override
    public void checkQty(StockPo stockPo, InAndOutStockParam stockParam) {
        //占用  只针对 库存表
        if (stockPo.getSumQuantity().compareTo(stockParam.getOccupyQuantity().add(stockPo.getOccupyQuantity())) < 0) {
            //请求占用 和 已经占用的  大于 库存量
            throw new BizException(QUANTITY_NOT_ENOUGH.getCode(), String.format(ERR_STR, stockParam.getMaterialCode()));
        }
    }

    /**
     * 占用库存不检查明细
     * 忽略
     */
    @Override
    public void checkQty(StockItemPo stockItemPo, InAndOutStockParam stockParam) {
    }

    /**
     * 更新 库存 原子操作
     */
    @Override
    public void updateStock(Long id, Integer qty, String materialCode) {
        int result = stockMapper.occupyQuantityById(id, qty);
        if (result <= 0) {
            throw new BizException(QUANTITY_NOT_ENOUGH.getCode(), String.format(ERR_STR, materialCode));
        }
    }

    /**
     * 更新 库存明细 原子操作
     */
    @Override
    public void updateStockItem(Long id, Integer qty, String materialCode) {

    }

    /**
     * 保存操作日志
     */
    @Override
    public void saveLog(StockRequest req,
                        Map<String, InAndOutStockParam> stockMap,
                        Map<String, InAndOutStockParam> stockItemMap,
                        @Nonnull List<StockPo> stockPos,
                        List<StockItemPo> stockItemPos) {
        List<String> stockKeys = stockPos.stream().map(StockPo::getBizConfigField).collect(Collectors.toList());
        List<StockOperateRecordPo> stockOperateRecordPos = generateStockOperateRecord(stockKeys, stockMap, req);
        stockOperateRecordService.saveBatch(stockOperateRecordPos);
    }


    /**
     * 根据 stockKeys 查询最新数据 配合操作数量反推流水
     */
    private List<StockOperateRecordPo> generateStockOperateRecord(List<String> stockKeys,
                                                                  Map<String, InAndOutStockParam> stockMap,
                                                                  StockRequest req) {
        Map<String, StockPo> stockPoMap = stockMapper.getByBizConfigFieldsAll(stockKeys).stream().collect(toMap(StockPo::getBizConfigField, Function.identity()));
        List<StockOperateRecordPo> logPos = new ArrayList<>();
        for (String key : stockMap.keySet()) {
            InAndOutStockParam stockParam = stockMap.get(key);
            StockPo stockPo = stockPoMap.get(key);

            StockOperateRecordPo recordPo = new StockOperateRecordPo();
            recordPo.setBizType(req.getBizType());
            recordPo.setBusinessBillNo(req.getBusinessBillNo());
            recordPo.setOccupyNo(req.getBusinessBillNo());
            recordPo.setOperateUser(req.getOperateUser());

            recordPo.setIdempotentNo(req.getIdempotentNo() + req.getOperationType().getType());
            recordPo.setCreateUser(req.getOperateUser());
            recordPo.setOperateTime(req.getOperateTime());
            recordPo.setOperateType(req.getOperationType().toString());
            recordPo.setOperateType(req.getOperationType().toString());
            recordPo.setOperateQuantity(stockParam.getSumQuantity());
            recordPo.setConfigId(stockConfigService.main(stockParam.getBizType()).getId());
            recordPo.setStockKey(key);

            recordPo.setBusinessType(StockOperationType.SPS49.getOperationType());
            recordPo.setSourceOccupyQuantity(stockPo.getOccupyQuantity().subtract(stockParam.getOccupyQuantity()));
            recordPo.setTargetOccupyQuantity(stockPo.getOccupyQuantity());

            recordPo.setTargetSumQuantity(stockPo.getSumQuantity());
            recordPo.setSourceSumQuantity(stockPo.getSumQuantity());
            logPos.add(recordPo);
        }
        return logPos;
    }


}
