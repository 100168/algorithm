package com.jiduauto.sps.stock.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.po.StockOperateRecordPo;
import com.jiduauto.sps.stock.server.pojo.vo.StockRequest;


/**
 * 库存交易记录表 服务类
 */
public interface IStockOperateRecordService extends IService<StockOperateRecordPo> {

    /**
     * 判断 幂等 是否已经处理过
     */
    boolean checkIdempotent(StockRequest request);

}
