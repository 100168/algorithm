package com.jiduauto.sps.stock.server.cache;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import com.jiduauto.sps.sdk.pojo.po.StockConfigPo;
import com.jiduauto.sps.stock.server.mapper.StockConfigMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static java.util.stream.Collectors.groupingBy;

@Component
@Slf4j
public class StockConfigCache implements InitializingBean {

    @Resource
    private StockConfigMapper stockConfigMapper;

    //目前里面只存了库存配置主数据
    private final LoadingCache<String, Optional<List<StockConfigPo>>> cache = Caffeine.newBuilder()
            .refreshAfterWrite(15, TimeUnit.MINUTES)
            .build(this::get);

    private Optional<List<StockConfigPo>> get(String bizType) {
        return Optional.ofNullable(stockConfigMapper.getByBizType(bizType));
    }

    public List<StockConfigPo> getByBizType(String bizType) {
        try {
            return Objects.requireNonNull(cache.get(bizType)).orElse(new ArrayList<>());
        } catch (Exception e) {
            log.error("查询库存业务配置缓存异常", e);
            return stockConfigMapper.getByBizType(bizType);
        }
    }

    /**
     * 根据业务类型删缓存
     */
    public void remove(String bizType) {
        cache.invalidate(bizType);
    }

    @Override
    public void afterPropertiesSet() {
        List<StockConfigPo> stockConfigPos = stockConfigMapper.selectList(Wrappers.lambdaQuery(StockConfigPo.class)
                .eq(StockConfigPo::getIsUsed, true)
                .eq(StockConfigPo::getIsDel, false)
                .eq(StockConfigPo::getConfigType, 1)
        );
        Map<String, List<StockConfigPo>> collect = stockConfigPos.stream().collect(groupingBy(StockConfigPo::getBizType));
        collect.forEach((key, value) -> cache.put(key, Optional.ofNullable(value)));
    }
}
