package com.jiduauto.sps.order.test

import cn.hutool.json.JSONUtil
import com.jiduauto.javakit.common.util.JsonUtil
import com.jiduauto.sps.order.Common
import com.jiduauto.sps.order.server.client.WorkOrderClient
import com.jiduauto.sps.order.server.client.req.WorkOrderAddReq
import com.jiduauto.sps.sdk.pojo.vo.BaseResult
import spock.lang.Ignore

import javax.annotation.Resource

class workOrder extends Common {

    @Resource
    private WorkOrderClient workOrderClient

    @Ignore
    def "work-order test"() {
        when: ""
        1 == 1
        then: ""
        String a = """
{
    "userName": "shaofei.xie",
    "formTemplateId": 200,
    "extBizNo": "1894",
    "formContent": null,
    "variables": null
}
"""
        String b = """
{
        "approvalNo": "240515002",
        "createUser": "谢少飞",
        "createTime": "2024-05-15 10:20:13",
        "detail": [
            {
                "id": 1,
                "name": "销售价格审批价格明细.xlsx",
                "size": 3963,
                "url": "https://bj.bcebos.com/jtest/sps/dev/66441c01e4b089b95a7f33c8_销售价格审批价格明细.xlsx"
            }
        ],
        "attachments": []
    }
"""
        Object o = JSONUtil.parseObj(b)
        WorkOrderAddReq req = JsonUtil.fromJsonStr(a, WorkOrderAddReq.class)
        req.setFormContent(o)
        BaseResult<List<String>> baseResult = workOrderClient.addOrder(req)
        print(baseResult)
    }
}
