package com.jiduauto.sps.order

import com.jiduauto.sps.order.pojo.Stock

/**
 * 库存工具类
 */
class StockUtil {
    static def sql = Common.spsSql

    // 自动化测试专用零件
    public static def S110010001 = "S110010001"
    public static def S170030035 = "S170030035"
    public static def S170010004 = "S170010004"
    public static def S170010005 = "S170010005"

    public static String Batch_NO = "1001"
    public static String Batch_NO2 = "1002"
    public static String warehouseCode = "G59"
    public static String supplierCode = "1100000785"
    public static String expireDate = "2025-12-01"

    public static def STOCK_LIST = [S170030035, S110010001, S170010004, S170010005]

    //零件映射
    static Map<String, String> STOCK_MAP = new HashMap<>()

    static Map<String, String> STOCK_ITEM_MAP = new HashMap<>()

    //多批次明细库存
    static Map<String, String> STOCK_ITEM_MAP2 = new HashMap<>()
    //在途库存
    static Map<String, String> V_STOCK_MAP = new HashMap<>()
    static Map<String, String> V_STOCK_ITEM_MAP = new HashMap<>()

    static {
        STOCK_MAP.put("S170030035", "f73e26a1bf9c369d5d65e2e06503b3e2")
        STOCK_MAP.put("S110010001", "6e92d8dbade97cbf7c2b3cbc4fe92ab1")
        STOCK_MAP.put("S170010004", "70d54233cdb6bdd796d06815b1bf87b0")
        STOCK_MAP.put("S170010005", "749b90182a0a88f171a31c3a9b561c9d")
        //商城订单特用
        STOCK_MAP.put("J99L01003A", "93b7ef87d5d8a4ef8b7b7928da277981")
        STOCK_MAP.put("J99L01002A", "75f54e3b5970641fe2df5d739cdceeec")
    }

    //默认  供应商code 1100000785 , 批次号 1001  仓库 G59 , 过期时间 2025-12-01
    static {
        STOCK_ITEM_MAP.put("S170030035", "d7574e868eb38117e0c9ff9273e30dc5")
        STOCK_ITEM_MAP.put("S110010001", "b11a7f1d946c72a79c8ac63e902f2376")
        STOCK_ITEM_MAP.put("S170010004", "dd8c7f9e6a86e881404a66fbd6db7f01")
        STOCK_ITEM_MAP.put("S170010005", "1f1d2bf2cc8175c8f087d4136b792fd0")
        //商城订单特用
        STOCK_ITEM_MAP.put("J99L01003A", "93b7ef87d5d8a4ef8b7b7928da277981")
        STOCK_ITEM_MAP.put("J99L01002A", "4a8ba985c91493db9835322935a9099e")
    }

    //默认  供应商code 1100000785 , 批次号 1002  仓库 G59 , 过期时间 2025-12-01
    static {
        STOCK_ITEM_MAP2.put("S170030035", "776ab13381bbea8eed227a332ae73e6e")
        STOCK_ITEM_MAP2.put("S110010001", "cca775053570ee3fdb4de39417bc169d")
        STOCK_ITEM_MAP2.put("S170010004", "482f1b84eaabba9f639bd83aa1d69416")
        STOCK_ITEM_MAP2.put("S170010005", "9c825b1843062cdfddc4d81131c92325")
    }

    static {
        V_STOCK_MAP.put("J99L01003A", "90824c8096b604d242cd49e77d5f2eba")
        V_STOCK_MAP.put("J99L01002A", "5253c25394806e7b14e88c560536a441")

    }
    static {
        V_STOCK_ITEM_MAP.put("J99L01003A", "90824c8096b604d242cd49e77d5f2eba")
        V_STOCK_ITEM_MAP.put("J99L01002A", "77c761087b611b0e5bd323ec33d5f5a5")
    }

    /**
     * 满足 BO 生成条件
     * 传入零件code, 此零件将会没有库存
     */
    static def createBoStock(String salePartNum) {
        def bizConfigField = STOCK_MAP.get(salePartNum)
        def itemBizConfigField = STOCK_ITEM_MAP.get(salePartNum)
        assert bizConfigField != null
        assert itemBizConfigField != null

        def sqlStr = "UPDATE stock SET sum_quantity = 100.0000, occupy_quantity = 100.00 WHERE biz_config_field = ?;"
        def itemSqlStr = "UPDATE stock_item SET sum_quantity = 100.0000 WHERE biz_config_field = ?;"
        //清除其他 不同批次的零件 库存明细
        def cleanSqlStr = """
UPDATE stock_item SET sum_quantity = 0 WHERE biz_type = 'SP' 
and stock_status = 1 and material_status = 1 and warehouse_code = 'G59' and material_code = '${salePartNum}'
and biz_config_field != '${itemBizConfigField}';
"""
        sql.execute(cleanSqlStr)
        sql.execute(sqlStr, [bizConfigField])
        sql.execute(itemSqlStr, [itemBizConfigField])
        true
    }

    /**
     * 满足 SO 生成条件
     * 传入零件code, 传入数量 该零件会增加对应库存
     */
    static def createSoStock(String salePartNum, Integer qty = 100) {
        def bizConfigField = STOCK_MAP.get(salePartNum)
        def itemBizConfigField = STOCK_ITEM_MAP.get(salePartNum)
        def itemBizConfigField2 = STOCK_ITEM_MAP2.get(salePartNum)
        assert bizConfigField != null
        assert itemBizConfigField != null
        assert itemBizConfigField2 != null
        //清除其他 不同批次的零件 库存明细
        def cleanSqlStr = """
UPDATE stock_item SET sum_quantity = 0 WHERE biz_type = 'SP' 
and stock_status = 1 and material_status = 1 and warehouse_code = 'G59' and material_code = '${salePartNum}'
and biz_config_field != '${itemBizConfigField}';
"""
        // 保留一些占用
        int item1_qty = qty <= 20 ? qty : (qty - 20)
        int item2_qty = qty <= 20 ? 0 : 20
        def sqlStr = "UPDATE stock SET sum_quantity = ${qty}, occupy_quantity = 0.00 WHERE biz_config_field = ?;"
        def itemSqlStr = "UPDATE stock_item SET sum_quantity = ${item1_qty} WHERE biz_config_field = ?;"
        def item2SqlStr = "UPDATE stock_item SET sum_quantity = ${item2_qty} WHERE biz_config_field = ?;"
        sql.execute(cleanSqlStr)
        sql.execute(sqlStr, [bizConfigField])
        sql.execute(itemSqlStr, [itemBizConfigField])
        sql.execute(item2SqlStr, [itemBizConfigField2])
        true
    }

    /**
     * 传入零件code, 获取零件主数据 库存数量 & 占用数量 & 在途库存数量
     */
    static Stock stockQty(String salePartNum) {
        def bizConfigField = STOCK_MAP.get(salePartNum)
        assert bizConfigField != null
        def ret = sql.firstRow("select * from stock where biz_config_field = '${bizConfigField}';")
        assert ret != null
        int vQty = 0
        new Stock(new BigDecimal(ret.sum_quantity).intValue(), new BigDecimal(ret.occupy_quantity).intValue(), vQty)
    }

    /**
     * 传入零件code, 获取零件明细数据 库存数量 & 在途库存数量
     */
    static Stock stockItemQty(String salePartNum, String batchNo = Batch_NO) {
        def itemBizConfigField = STOCK_ITEM_MAP.get(salePartNum)
        assert itemBizConfigField != null
        def itemRet = sql.firstRow("select * from stock_item where biz_config_field = '${itemBizConfigField}';")
        def itemRetV = sql.firstRow("""
select *
from stock_item
where biz_type = 'SP'
  and is_del = false
  and warehouse_code = 'V_G59'
  and stock_status = 4
  and supplier_code = '${supplierCode}'
  and batch_no = '${batchNo}'
  and expire_date = '${expireDate}'
  and material_code = '${salePartNum}';
""")
        assert itemRet != null
        int vQty = 0
        new Stock(new BigDecimal(itemRet.sum_quantity).intValue(), vQty)
    }


    /**
     * 传入零件code, 传入数量 该零件会增加对应库存
     * 仓配订单专用，在途库存默认设置为0
     */
    static def createWdoStock(String salePartNum, Integer qty = 100) {
        def bizConfigField = STOCK_MAP.get(salePartNum)
        def itemBizConfigField = STOCK_ITEM_MAP.get(salePartNum)
        def vmsBizConfigField = V_STOCK_MAP.get(salePartNum)
        def vItemsBizConfigField = V_STOCK_ITEM_MAP.get(salePartNum)
        assert bizConfigField != null
        assert itemBizConfigField != null
        def sqlStr = "UPDATE stock SET sum_quantity = ${{ qty }}, occupy_quantity = 0.00 WHERE biz_config_field = ?;"
        def itemSqlStr = "UPDATE stock_item SET sum_quantity = ${{ qty }} WHERE biz_config_field = ?;"
        def vSqlStr = "UPDATE stock SET sum_quantity = 0.00 WHERE biz_config_field = ?;"
        def vItemSqlStr = "UPDATE stock_item SET sum_quantity = 0.00 WHERE biz_config_field = ?;"

        sql.execute(sqlStr, [bizConfigField])
        sql.execute(itemSqlStr, [itemBizConfigField])
        sql.execute(vSqlStr, [vmsBizConfigField])
        sql.execute(vItemSqlStr, [vItemsBizConfigField])
        true
    }

    /**
     * 传入零件code, 获取零件主数据 库存数量 & 占用数量 & 在途库存数量
     */
    static Stock getStockQty(String salePartNum) {
        def bizConfigField = STOCK_MAP.get(salePartNum)
        def vBizConfigField = V_STOCK_MAP.get(salePartNum)
        assert bizConfigField != null
        def ret = sql.firstRow("select * from stock where biz_config_field = '${bizConfigField}';")
        def retV = sql.firstRow("select * from stock where biz_config_field = '${vBizConfigField}';")
        assert ret != null
        int vQty = 0
        if (retV != null) {
            vQty = new BigDecimal(retV.sum_quantity).intValue()
        }
        new Stock(new BigDecimal(ret.sum_quantity).intValue(), new BigDecimal(ret.occupy_quantity).intValue(), vQty)
    }
}
