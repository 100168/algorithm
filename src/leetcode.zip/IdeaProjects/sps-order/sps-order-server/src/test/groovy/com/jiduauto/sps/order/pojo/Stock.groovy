package com.jiduauto.sps.order.pojo

/**
 * test 使用的简化版 stock
 */
class Stock {
    // 对应库存表 sum_quantity
    int sumQty
    // 对应库存表 occupy_quantity
    int occupyQty
    // 在途库存
    int vQty

    Stock(int sumQty, int occupyQty, int vQty) {
        this.sumQty = sumQty
        this.occupyQty = occupyQty
        this.vQty = vQty
    }

    Stock(int sumQty, int vQty) {
        this.sumQty = sumQty
        this.vQty = vQty
    }
}
