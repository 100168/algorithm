package com.jiduauto.sps.order

import cn.hutool.core.util.IdUtil
import cn.hutool.json.JSONUtil
import groovy.json.JsonSlurper

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class Req {
    static def jsonParse = new JsonSlurper()

    /**
     * qty 不传值则设置为 1- 5 的int随机数
     */
    static def addPoReq(List<String> salePartNums, String poType = "RO", Integer qty = 0) {
        def timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss"))
        def timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def vinStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmm"))
        def jsonStr = """
    {
    "bizType": "SP",
    "tradeNo": "${{ timestamp }}",
    "purchaseOrderAttr": "101",
    "purchaseOrderType": "${{ poType }}",
    "commitTime": "${{ timeStr }}",
    "storeCode": "JDs00002",
    "receiveWarehouseCode": "Service00002",
    "receiver": "少飞-autoTest",
    "receiverPhone": "15512341234",
    "receiverProvince": "110000",
    "receiverCity": "110100",
    "receiverDistrict": "110101",
    "receiverAddress": "少飞的自动化测试收货地址",
    "vin": "VIN${{ vinStr }}",
    "operateUser": "少飞-autoTest",
    "headRemark": "少飞-headRemark",
    "itemList": []
}
"""
        def itemList
        if (qty > 0) {
            itemList = salePartNums.collect {
                new Item(it, qty)
            }
        } else {
            Random r = new Random()
            itemList = salePartNums.collect {
                new Item(it, r.nextInt(5) + 1)
            }
        }

        def json = jsonParse.parseText(jsonStr)
        json.itemList.addAll(itemList)
        return JSONUtil.toJsonStr(json)
    }


    static def putOutStockReq(List<PutOutItem> putOutItems, soNo) {
        def timestamp = System.currentTimeMillis()
        def timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def jsonStr = """
{
    "bizType": "SP",
    "businessBillNo": "DHL-${{ timestamp }}",
    "businessType": "SP20",
    "idempotentNo": "DHL-${{ timestamp }}",
    "operateTime": "${{ timeStr }}",
    "operateUser": "少飞-autoTest",
    "operationType": "UN_OCCUPY_SUBTRACT",
    "params": [],
    "tradeNo": "${{ soNo }}"
}
"""
        def json = jsonParse.parseText(jsonStr)
        json.params.addAll(putOutItems)
        return JSONUtil.toJsonStr(json)
    }

    //ss11 门店so
    //ss13 dfs
    static def soPutInStockSS11Req(List<PutInItem> putInItems, soNo) {
        def timestamp = System.currentTimeMillis()
        def timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def jsonStr = """
{
    "bizType": "SS",
    "businessBillNo": "${{ timestamp }}",
    "businessType": "SS11",
    "idempotentNo": "${{ timestamp }}",
    "operateTime": "${{ timeStr }}",
    "operateUser": "少飞-autoTest",
    "operationType": "ADD",
    "params": [],
    "tradeNo": "${{ soNo }}"
}
"""
        def json = jsonParse.parseText(jsonStr)
        json.params.addAll(putInItems)
        return JSONUtil.toJsonStr(json)
    }

    static def dfsPutInStockSS13Req(List<PutInItem> putOutItems, asnCode) {
        def timestamp = System.currentTimeMillis()
        def timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def jsonStr = """
{
    "bizType": "SS",
    "businessBillNo": "${{ timestamp }}",
    "businessType": "SS13",
    "idempotentNo": "${{ timestamp }}",
    "operateTime": "${{ timeStr }}",
    "operateUser": "少飞-autoTest",
    "operationType": "ADD",
    "params": [],
    "tradeNo": "${{ asnCode }}"
}
"""
        def json = jsonParse.parseText(jsonStr)
        json.params.addAll(putOutItems)
        return JSONUtil.toJsonStr(json)
    }

    static def asnCOPutInStockSP10Req(String supplierCode, String materialCode, String asnNo) {
        def timestamp = System.currentTimeMillis()
        def timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def jsonStr = """
{
    "bizType": "SP",
    "businessBillNo": "${{ timestamp }}",
    "businessType": "SP10",
    "idempotentNo": "${{ timestamp }}",
    "operateTime": "${{ timeStr }}",
    "operateUser": "少飞-autoTest",
    "operationType": "ADD",
    "params": [
        {
            "columnNo": "10",
            "brokenQuantity": 0,
            "batchNo": "${{ asnNo }}",
            "supplierCode": "${{ supplierCode }}",
            "materialCode": "${{ materialCode }}",
            "materialStatus": 1,
            "stockStatus": 1,
            "sumQuantity": 1.000,
            "warehouseCode": "G59"
        }
    ],
    "tradeNo": "${{ asnNo }}"
}
"""
        def json = jsonParse.parseText(jsonStr)
        return JSONUtil.toJsonStr(json)
    }

    static def asnAddReq(String asnCode, List<AsnItem> asnItemList, String type = "CO", String receiveWarehouseCode = "G59") {
        def timeStr1 = LocalDateTime.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def timeStr2 = LocalDateTime.now().plusDays(2).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def jsonStr = """
{
    "partCategory": "2",
    "asnCode": "${{ asnCode }}",
    "asnType": "F",
    "receiveWarehouseCode": "${receiveWarehouseCode}",
    "deliveryTime": "${{ timeStr1 }}",
    "estArrivalTime": "${{ timeStr2 }}",
    "supplierSapCode": "${StockUtil.supplierCode}",
    "requirementType": "${{ type }}",
    "remark": "少飞-autoTest",
    "deliverInfos": []
}
"""
        def json = jsonParse.parseText(jsonStr)
        json.deliverInfos.addAll(asnItemList)
        return JSONUtil.toJsonStr(json)
    }


    static class AsnItem {
        def orderPlanNo
        def asnLineNo
        def sapContractNo
        def contractLineNo
        def saleOrderNo
        def salePartNum
        def materialNum = salePartNum
        def purchaseOrderNo
        def deliveryQty
        def unit = "EA"
        def plantCode = "6000"
        def standardPackQty = 1
        def batchNo
        def productTime = LocalDateTime.now().minusDays(2).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def expireTime = LocalDateTime.now().plusMonths(4).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        List<AsnPackage> packageInfos

        AsnItem(def orderPlanNo,
                def asnLineNo,
                def sapContractNo,
                def contractLineNo,
                def salePartNum,
                def purchaseOrderNo,
                def deliveryQty,
                def batchNo
        ) {
            this.orderPlanNo = orderPlanNo
            this.asnLineNo = asnLineNo
            this.sapContractNo = sapContractNo
            this.contractLineNo = contractLineNo
            this.salePartNum = salePartNum
            this.purchaseOrderNo = purchaseOrderNo
            this.deliveryQty = deliveryQty
            this.batchNo = batchNo
            this.packageInfos = [
                    new AsnPackage(salePartNum),
            ]
        }

        AsnItem(def orderPlanNo,
                def asnLineNo,
                def sapContractNo,
                def contractLineNo,
                def salePartNum,
                def purchaseOrderNo,
                def deliveryQty,
                def batchNo,
                def saleOrderNo
        ) {
            this.orderPlanNo = orderPlanNo
            this.asnLineNo = asnLineNo
            this.sapContractNo = sapContractNo
            this.contractLineNo = contractLineNo
            this.salePartNum = salePartNum
            this.purchaseOrderNo = purchaseOrderNo
            this.deliveryQty = deliveryQty
            this.batchNo = batchNo
            this.saleOrderNo = saleOrderNo
            this.packageInfos = [
                    new AsnPackage(salePartNum),
            ]
        }
    }

    static class AsnPackage {
        def serialNo = "123"
        def salePartNum
        def packNo = "123"
        def standardPackQty = 1
        def actualPackQty = 1

        AsnPackage(String salePartNum) {
            this.salePartNum = salePartNum
        }
    }

    static class Item {
        def salePartNum
        def discountUnitPrice = 1.2
        def qty
        def lineAmount = 1.3
        def vin = "item-vin"
        def storeRemark = "storeRemark"

        Item(String salePartNum, Integer qty) {
            this.salePartNum = salePartNum
            this.qty = qty
        }
    }

    static class PutOutItem {
        def materialStatus = 1
        def stockStatus = 1
        def warehouseCode = "G59"
        def materialCode
        def supplierCode
        def batchNo
        def sumQuantity
        def columnNo
        def brokenQuantity = 0

        PutOutItem(String materialCode, Integer sumQuantity, String supplierCode = StockUtil.supplierCode, String batchNo = StockUtil.Batch_NO, String lineNo = "10") {
            this.materialCode = materialCode
            this.supplierCode = supplierCode
            this.batchNo = batchNo
            this.sumQuantity = sumQuantity
            this.columnNo = lineNo
        }
    }

    static class PutInItem {
        def areaCode = "Region00001"
        def locationCode = "00001"
        def materialStatus = 1
        def stockStatus = 1
        def warehouseCode = "Service00002"
        def materialCode
        def sumQuantity
        def expireDate = StockUtil.expireDate
        def columnNo
        def brokenQuantity = 0
        def batchNo

        PutInItem(String materialCode, Integer sumQuantity) {
            this.materialCode = materialCode
            this.sumQuantity = sumQuantity
        }

        PutInItem(String materialCode,
                  Integer sumQuantity,
                  String columnNo,
                  String batchNo
        ) {
            this.materialCode = materialCode
            this.sumQuantity = sumQuantity
            this.columnNo = columnNo
            this.batchNo = batchNo
        }
    }

    static def wdoAddReq() {
        def idStr = IdUtil.getSnowflake(0).nextIdStr()
        def addReq = """
{
    "head": {
        "bizType": "SM",
        "orderTime": "2023-11-23 00:00:00",
        "businessBillNo": "${{ idStr }}",
        "orderType": "SM20",
        "logisticType": 2,
        "sourceSystem": "集度商城",
        "remark": "呃呃呃"
    },
    "logistic": {
        "shippingMethod": "EXP",
        "deliverWarehouseCode": "G59",
        "receiver": "jian",
        "receiverContact": "17336327334",
        "receiveProvinceCode": "",
        "receiveCityCode": "",
        "receiveDistrictCode": "",
        "receiveProvinceName": "北京市",
        "receiveCityName": "北京市",
        "receiveDistrictName": "朝阳区",
        "receiveAddress": "叶辰路1688号"
    },
    "items": [
         {
            "bizType": "SP",
            "materialLineNo": "1",
            "materialCode": "J99L01003A",
            "qty": "1",
            "volume": "20",
            "weight": "20",
            "materialStatus": "1",
            "stockStatus": "1",
            "remark": "111"
        },
        {
            "bizType": "JC",
            "materialLineNo": "2",
            "materialCode": "J99L01002A",
            "qty": "1",
            "volume": "20",
            "weight": "20",
            "materialStatus": "1",
            "stockStatus": "1",
            "remark": "111",
            "batchNo" :"SP202309250003",
            "supplierCode" : "5100000010",
        }
    ]
}
"""
        def json = jsonParse.parseText(addReq)
        return JSONUtil.toJsonStr(json)
    }

    static def sm20PutOutStockReq(List<PutOutItem> putOutItems, wdoNo) {
        def timestamp = System.currentTimeMillis()
        def timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def jsonStr = """
{
    "bizType": "SM",
    "businessBillNo": "DHL-${{ timestamp }}",
    "businessType": "SM20",
    "idempotentNo": "DHL-${{ timestamp }}",
    "operateTime": "${{ timeStr }}",
    "operateUser": "jian.pan-autoTest",
    "operationType": "UN_OCCUPY_SUBTRACT",
    "params": [],
    "tradeNo": "${{ wdoNo }}"
}
"""
        def json = jsonParse.parseText(jsonStr)
        json.params.addAll(putOutItems)
        return JSONUtil.toJsonStr(json)
    }


    /**
     * qty 不传值则设置为 1- 5 的int随机数
     * 调拨单创建请求体
     */
    static def addSTOReq(List<String> salePartNums, Integer qty = 0) {
        def timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss"))
        def timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
        def jsonStr = """
    {
    "bizType": "SS",
    "idempotentNo": "${timestamp}",
    "orderAttr": "101",
    "commitTime": "${timeStr}",
    "transferInOrganizationCode": "JDs00002",
    "transferInWarehouseCode": "Service00002",
    "transferInAddress": "上海嘉定测试调入地址",
    "transferInContactName": "少飞测试调入人",
    "transferInContactMobile": "15543214321",
    "transferOutOrganizationCode": "JDs00063",
    "transferOutWarehouseCode": "G59",
    "transferOutAddress": "上海嘉定测试调出地址",
    "transferOutContactName": "少飞测试调出人",
    "transferOutContactMobile": "15512341234",
    "remark": "shaofei-remark",
    "operateUser": "少飞-autoTest",
    "itemList": []
}
"""
        def itemList
        if (qty > 0) {
            itemList = salePartNums.collect {
                new StoItem(it, qty)
            }
        } else {
            Random r = new Random()
            itemList = salePartNums.collect {
                new StoItem(it, r.nextInt(5) + 1)
            }
        }

        def json = jsonParse.parseText(jsonStr)
        json.itemList.addAll(itemList)
        return JSONUtil.toJsonStr(json)
    }

    static class StoItem {
        def materialCode
        def discountUnitPrice = 1.5
        def qty

        StoItem(String materialCode, Integer qty) {
            this.materialCode = materialCode
            this.qty = qty
        }
    }


}
