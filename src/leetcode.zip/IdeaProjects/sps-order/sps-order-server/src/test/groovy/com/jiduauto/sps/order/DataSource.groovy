package com.jiduauto.sps.order

import groovy.sql.Sql


/**
 * DataSource 负责数据库的连接
 */
class DataSource {

    Sql spsOrderSql

    Sql spsSql

    Sql getSpsSql() {
        if (!spsSql) {
            def mysqlDB = [
                    driver  : 'com.mysql.jdbc.Driver',
                    url     : 'jdbc:mysql://mysql.jidudev.com:3306/jidu_sps?zeroDateTimeBehavior=convertToNull&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai',
                    user    : 'sps_wr',          //这里写入安装mysql是设置的用户名
                    password: 'qL5cO4fG7x'     //这里写入安装mysql时设置的密码
            ]
            spsSql = Sql.newInstance(mysqlDB.url, mysqlDB.user, mysqlDB.password, mysqlDB.driver)
            // 连接mysql数据库固定写法
        }
        spsSql
    }


    Sql getSpsOrderSql() {
        if (!spsOrderSql) {
            def mysqlDB = [
                    driver  : 'com.mysql.jdbc.Driver',
                    url     : 'jdbc:mysql://mysql.jidudev.com:3306/jidu_sps_order?zeroDateTimeBehavior=convertToNull&useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai',
                    user    : 'sps_order_wr',          //这里写入安装mysql是设置的用户名
                    password: 'jdG1yglZzc'             //这里写入安装mysql时设置的密码
            ]
            spsOrderSql = Sql.newInstance(mysqlDB.url, mysqlDB.user, mysqlDB.password, mysqlDB.driver)
            // 连接mysql数据库固定写法
        }
        spsOrderSql
    }

}
