package com.jiduauto.sps.order.test

import cn.hutool.json.JSONUtil
import com.jiduauto.sps.order.*
import com.jiduauto.sps.order.server.pojo.BackOrderTransferDto
import com.jiduauto.sps.order.server.service.IBackOrderService
import com.jiduauto.sps.order.server.service.IPurchaseOrderService
import com.jiduauto.sps.sdk.enums.BackOrderStatusEnum
import com.jiduauto.sps.sdk.enums.SaleOrderStatusEnum
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo

import javax.annotation.Resource
import static com.jiduauto.sps.order.StockUtil.*

class XxlJobTest extends Common {

    @Resource
    IBackOrderService backOrderService

    @Resource
    IPurchaseOrderService purchaseOrderService

    def "BO 自动转单job测试"() {
        //1. 构建 缺件零件
        createBoStock(S170030035)
        //2. 更改零件属性
        MaterialUtil.update(S170030035, true, false, false, false)

        when: "创建 PO"
        int qty = 4
        def poReq = Req.addPoReq([S170030035], "VOR", 4)
        def poNo = ReqUtil.post("/internal/purchaseOrder/add", poReq)
        //等待异步执行
        //mybatis plus & groovy 语法冲突, 直接查数据库
        PurchaseOrderPo po = JSONUtil.toBean(JSONUtil.toJsonStr(spsOrderSql.firstRow("select * from purchase_order where purchase_order_no = '${poNo}'"))
                , PurchaseOrderPo.class)
        then: "BO 分页数据 对应 po 单号应该有一单 BO & 进行 BO job 转单"
        def data2 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'backOrderStatus', BackOrderStatusEnum.PENDING.getCode())
        assert data2.records[0].restBackQty == 4
        def boRestQty = data2.records[0].restBackQty
        //autoTransferOrder 方法实际只使用了 purchaseOrderNo 和 purchaseOrderPo
        def dto = new BackOrderTransferDto()
        dto.setPurchaseOrderNo(poNo)
        dto.setPurchaseOrderPo(po)
        backOrderService.autoTransferOrder(dto)
        Thread.sleep(2000)
        then: "库存不足, 进行自动转单没有变化"
        def data3 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'backOrderStatus', BackOrderStatusEnum.PENDING.getCode())
        assert data3.records[0].restBackQty == boRestQty
        then: "补充 3 个库存, 会生成一个 SO, BO 剩余转单数量会剩 1个"
        int addStockNum = 3
        createSoStock(S170030035, addStockNum)
        backOrderService.autoTransferOrder(dto)
        Thread.sleep(3000)
        def data4 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        assert new BigDecimal(data4.records[0].restBackQty).intValue() == (qty - addStockNum)
        assert data4.records[0].backOrderStatus == BackOrderStatusEnum.PENDING.getCode()

        def data5 = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        assert data5.records.size() == 1
        assert data5.records[0].saleOrderStatusCode == SaleOrderStatusEnum.PENDING_DELIVERY.getCode()

        def data6 = ReqUtil.post("/spsInternal/so/detail/pageSearch", [param: [bizType    : 'SP',
                                                                               saleOrderNo: data5.records[0].saleOrderNo,
                                                                               salePartNum: S170030035]])
        assert data6.records.size() == 1
        assert data6.records[0].qty == addStockNum
        then: "再补充一个库存, 将 BO 全部转单, 此时 BO 状态为 已关闭 & 剩余转单数量为 0"
        createSoStock(S170030035, 1)
        backOrderService.autoTransferOrder(dto)
        Thread.sleep(3000)
        def data7 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        assert new BigDecimal(data7.records[0].restBackQty).intValue() == 0
        assert data7.records[0].backOrderStatus == BackOrderStatusEnum.CLOSED.getCode()
    }

}
