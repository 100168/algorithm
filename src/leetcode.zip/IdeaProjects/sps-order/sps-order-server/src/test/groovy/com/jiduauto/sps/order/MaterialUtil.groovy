package com.jiduauto.sps.order

class MaterialUtil {

    static def sql = Common.spsSql

    /**
     * 更新零件属性
     */
    static def update(String materialCode,
                      boolean boTransfer,
                      boolean isDfs,
                      boolean isCustom,
                      boolean isControl) {
        String boTransferStr = boTransfer ? "是" : "否"
        String isDfsStr = isDfs ? "Y" : "N"
        String isControlStr = isControl ? "Y" : "N"
        String isCustomStr = isCustom ? "Y" : "N"
        def str = """
update material set 
is_custom = '${{ isCustomStr }}', 
bo_transfer = '${{ boTransferStr }}', 
is_dfs = '${{ isDfsStr }}' ,
is_control = '${{ isControlStr }}'
where is_del = false and sale_part_num = '${materialCode}' and (biz_type = 'SP' or biz_type = 'SS');
"""
        sql.execute(str)
        true
    }


    /**
     * 更新零件属性
     */
    static def updateList(List<String> materialCodeList,
                          boolean boTransfer,
                          boolean isDfs,
                          boolean isCustom,
                          boolean isControl) {
        String boTransferStr = boTransfer ? "是" : "否"
        String isDfsStr = isDfs ? "Y" : "N"
        String isControlStr = isControl ? "Y" : "N"
        String isCustomStr = isCustom ? "Y" : "N"
        materialCodeList.each {
            {
                def str = """
update material set 
is_custom = '${{ isCustomStr }}', 
bo_transfer = '${{ boTransferStr }}', 
is_dfs = '${{ isDfsStr }}' ,
is_control = '${{ isControlStr }}'
where is_del = false and sale_part_num = '${it}' and (biz_type = 'SP' or biz_type = 'SS');
"""
                sql.execute(str)
            }
        }
        true
    }


}
