package com.jiduauto.sps.order.test

import cn.hutool.core.collection.CollUtil
import com.jiduauto.sps.order.*
import com.jiduauto.sps.sdk.enums.BackOrderStatusEnum
import com.jiduauto.sps.sdk.enums.POTurnControlStatus
import com.jiduauto.sps.sdk.enums.PurchaseOrderStatusEnum
import com.jiduauto.sps.sdk.enums.SaleOrderStatusEnum

import static com.jiduauto.sps.order.StockUtil.*

/**
 * PO 功能测试
 */
class PoTest extends Common {

    def "SO 短拣 & BO 智子申请BO取消 & BO 取消审核 & 库存 check"() {
        MaterialUtil.update(S170010004, false, false, false, false)
        MaterialUtil.update(S170010005, false, false, false, false)

        createSoStock(S170010004)
        createSoStock(S170010005)

        when: "创建 PO"
        int qty = 4
        def poReq = Req.addPoReq([S170010004, S170010005], "RO", qty)
        def poNo = ReqUtil.post("/internal/purchaseOrder/add", poReq)
        //等待异步执行
        then: "零件充足, 生成一单 SO 有两条明细, SO 状态为待发货 & 检查库存主数据占用情况"

        def data2 = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]],
                'saleOrderStatusCode', SaleOrderStatusEnum.PENDING_DELIVERY.getCode())
        def soNo = data2.records[0].saleOrderNo
        def data3 = ReqUtil.post("/spsInternal/so/detail/pageSearch", [param: [bizType: 'SP', saleOrderNo: soNo]])
        assert data3.records.size() == 2

        then: "此时库存占用为 占用 4 个, "

        def S170010004_STOCK = stockQty(S170010004)
        def S170010004_STOCK_ITEM = stockItemQty(S170010004)
        assert S170010004_STOCK.sumQty == 100
        assert S170010004_STOCK.occupyQty == qty

        then: "MOCK DHL 发货, SO 状态变为已发货, SO发货数量 & PO发货数量对应变更, DHL 少发, 触发短拣"
        int boQty = 2
        int dhlS170010004_qty = qty - boQty   //dhl S170010004零件 实际出库数量   触发短拣
        def itemList = [
                new Req.PutOutItem(S170010004, dhlS170010004_qty),
                new Req.PutOutItem(S170010005, qty),
        ]
        def req = Req.putOutStockReq(itemList, soNo)
        ReqUtil.spsPost("/external/stock/putOutStock", req)
        Thread.sleep(3000)

        def data4 = ReqUtil.post("/spsInternal/so/pageSearch",
                [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'saleOrderStatusCode', SaleOrderStatusEnum.DELIVERED.getCode())
        def data5 = ReqUtil.post("/spsInternal/so/detail/pageSearch", [param: [bizType: 'SP', saleOrderNo: soNo]])
        data5.records.each {
            if (it.salePartNum == S170010004) {
                assert new BigDecimal(it.deliverQty).intValue() == dhlS170010004_qty
            }
        }

        then: "触发短拣, 库存全部冻结, 同时生成一个BO单 & 检查库存主数据 & 在途库存数量是否正确"
        Thread.sleep(4000)
        def S170010004_STOCK2 = stockQty(S170010004)
        assert S170010004_STOCK2.sumQty == 0

        def data11 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        assert data11.records.size() == 1
        assert new BigDecimal(data11.records[0].restBackQty).intValue() == boQty


        def data6 = ReqUtil.post("/spsInternal/po/detail/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        data6.records.each {
            if (it.salePartNum == S170010004) {
                assert new BigDecimal(it.deliverQty).intValue() == dhlS170010004_qty
            }
        }
        then: "门店收货, PO状态还是为处理中"

        def putInItemList = [
                new Req.PutInItem(S170010004, dhlS170010004_qty),
                new Req.PutInItem(S170010005, qty),
        ]
        def putInReq = Req.soPutInStockSS11Req(putInItemList, soNo)
        ReqUtil.spsPost("/internal/stock/putInStock", putInReq)

        def data7 = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'saleOrderStatusCode', SaleOrderStatusEnum.FULLY_RECEIVED.getCode())
        def data8 = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'purchaseOrderStatusCode', PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL.getCode())

        then: "MOCK 智子取消因缺件产生的 BO 单,  BO单取消审批后, BO单状态为已取消  PO 状态变为已完成, 对应零件取消数量 == BO 单的缺件数量 同时生成库存调整单"

        ReqUtil.post("/internal/backOrder/cancelApply", [backOrderNo: data11.records[0].backOrderNo, operateUser: "少飞-autoTest"])
        def data12 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP', backOrderNo: data11.records[0].backOrderNo]])
        assert data12.records[0].backOrderStatus == BackOrderStatusEnum.CANCEL_PENDING.getCode()

        ReqUtil.post("/spsInternal/bo/cancelApproval?backOrderNo=${data11.records[0].backOrderNo}", "")
        def data13 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP', backOrderNo: "${data11.records[0].backOrderNo}"]])
        assert data13.records[0].backOrderStatus == BackOrderStatusEnum.CANCELED.getCode()

        def data14 = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        assert data14.records[0].purchaseOrderStatusCode == PurchaseOrderStatusEnum.COMPLETED.getCode()

        def data15 = ReqUtil.post("/spsInternal/po/detail/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo, salePartNum: S170010004]])
        assert new BigDecimal(data15.records[0].cancelQty).intValue() == boQty

        def data16 = ReqUtil.spsPost("/stockUpdateOrder/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo, salePartNum: S170010004]])
        assert data16.records[0].remark.contains(data7.records[0].saleOrderNo)

        then: "最后库存主数据 & 库存明细  sumQty 减少了 DHL实际出库的个数, 在途库存数量恢复到一开始的数量"
        def S170010004_STOCK3 = stockQty(S170010004)
        def S170010004_STOCK3_ITEM = stockItemQty(S170010004)
    }

    def "RO SO 流程"() {
        MaterialUtil.update(S170010004, false, false, false, false)
        MaterialUtil.update(S170010005, false, false, false, false)

        createSoStock(S170010004)
        createSoStock(S170010005)

        when: "创建 PO"
        int qty = 4
        def poReq = Req.addPoReq([S170010004, S170010005], "RO", qty)
        def poNo = ReqUtil.post("/internal/purchaseOrder/add", poReq)
        //等待异步执行

        then: "零件充足, 生成一单 SO 有两条明细,  SO 状态为待发货"
        def data2 = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'saleOrderStatusCode', SaleOrderStatusEnum.PENDING_DELIVERY.getCode())
        def soNo = data2.records[0].saleOrderNo
        def data3 = ReqUtil.post("/spsInternal/so/detail/pageSearch", [param: [bizType: 'SP', saleOrderNo: soNo]])
        assert data3.records.size() == 2

        then: "MOCK DHL 多批次发货, SO 状态变为已发货, SO发货数量 & PO发货数量对应变更"
        def itemList = [
                new Req.PutOutItem(S170010004, qty - 2, supplierCode, Batch_NO, '10'),
                new Req.PutOutItem(S170010004, 2, supplierCode, Batch_NO2, '10'),
                new Req.PutOutItem(S170010005, qty - 2, supplierCode, Batch_NO, '20'),
                new Req.PutOutItem(S170010005, 2, supplierCode, Batch_NO2, '20'),
        ]
        def req = Req.putOutStockReq(itemList, soNo)
        ReqUtil.spsPost("/external/stock/putOutStock", req)

        def data4 = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'saleOrderStatusCode', SaleOrderStatusEnum.DELIVERED.getCode())
        def data5 = ReqUtil.post("/spsInternal/so/detail/pageSearch", [param: [bizType: 'SP', saleOrderNo: soNo]])
        data5.records.each {
            assert new BigDecimal(it.deliverQty).intValue() == qty
            assert new BigDecimal(it.qty).intValue() == qty
        }

        def data6 = ReqUtil.post("/spsInternal/po/detail/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        data6.records.each {
            assert new BigDecimal(it.deliverQty).intValue() == qty
        }
        then: "门店收货, PO状态变为已完成, SO 为全部收货, PO SO 收货数量也同步更新"

        def putInItemList = [
                new Req.PutInItem(S170010004, qty),
                new Req.PutInItem(S170010005, qty),
        ]
        def putInReq = Req.soPutInStockSS11Req(putInItemList, soNo)
        ReqUtil.spsPost("/internal/stock/putInStock", putInReq)

        def data7 = ReqUtil.post("/spsInternal/so/pageSearch",
                [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'saleOrderStatusCode', SaleOrderStatusEnum.FULLY_RECEIVED.getCode())
        def data8 = ReqUtil.post("/spsInternal/po/pageSearch",
                [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'purchaseOrderStatusCode', PurchaseOrderStatusEnum.COMPLETED.getCode())
        def data9 = ReqUtil.post("/spsInternal/so/detail/pageSearch", [param: [bizType: 'SP', saleOrderNo: soNo]])
        data9.records.each {
            assert new BigDecimal(it.receiveQty).intValue() == qty
        }
        def data10 = ReqUtil.post("/spsInternal/po/detail/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        data10.records.each {
            assert new BigDecimal(it.receiveQty).intValue() == qty
        }
    }

    def "管控件转单全流程测试"() {
        // 1. 准备零件
        MaterialUtil.update(S170030035, false, false, false, true)
        MaterialUtil.update(S110010001, false, false, false, true)
        MaterialUtil.update(S170010004, false, false, false, true)
        MaterialUtil.update(S170010005, false, false, false, true)
        // 2. 准备库存
        createBoStock(S170030035)
        createBoStock(S110010001)

        createSoStock(S170010004)
        createSoStock(S170010005)

        when: "创建 PO"
        def poReq = Req.addPoReq(STOCK_LIST)
        def poNo = ReqUtil.post("/internal/purchaseOrder/add", poReq)
        //等待异步执行
        then: "po单正常情况应创建成功 查询分页接口第一个 po 单号应该等于创建po接口返回单号"

        def data = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]],
                'purchaseOrderStatusCode', PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL.getCode())

        then: "所有零件为管控件, 不应该有 SO & BO 生成"
        def data2 = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        assert data2.records.size() == 0

        def data3 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        assert data3.records.size() == 0
        then: "手动管控件转单"
        def data4 = ReqUtil.post("/spsInternal/po/detail/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        assert data4.records.size() != 0

        def detailId = data4.records[0].detailId
        def turnSalePartNum = data4.records[0].salePartNum
        def qty = data4.records[0].qty
        def turnedControlQty = data4.records[0].turnedControlQty
        int canTurnQyt = new BigDecimal(qty).subtract(new BigDecimal(turnedControlQty)).intValue()
        assert canTurnQyt >= 0
        //随机转单数量
        int randomQty = TestUtil.getRandomInt(canTurnQyt)
        ReqUtil.post("/spsInternal/po/controlTransfer", [bizType: 'SP', detailId: detailId, qty: randomQty])
        //等待异步执行
        Thread.sleep(3000)
        then: "此时只生成 一个 so 或 bo 或者两个一起"
        def data6 = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])

        def data7 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])

        assert (data6.records.size() + data7.records.size()) == 1 || (data6.records.size() + data7.records.size()) == 2
        def data8

        int soQty = 0
        int boQty = 0
        if (CollUtil.isNotEmpty(data6.records)) {
            assert data6.records[0].purchaseOrderNo == poNo
            //SO 为待发货
            assert data6.records[0].saleOrderStatusCode == SaleOrderStatusEnum.PENDING_DELIVERY.getCode()
            data8 = ReqUtil.post("/spsInternal/so/detail/pageSearch", [param: [bizType: 'SP', saleOrderNo: data6.records[0].saleOrderNo, salePartNum: turnSalePartNum]])
            assert data8.records[0].salePartNum == turnSalePartNum
            soQty = data8.records[0].qty
        }
        if (CollUtil.isNotEmpty(data7.records)) {
            assert data7.records[0].purchaseOrderNo == poNo
            assert data7.records[0].salePartNum == turnSalePartNum
            boQty = data7.records[0].backQty
        }
        def totalQty = soQty + boQty
        //转单数量要等于 SO qty + BO qty
        assert totalQty == randomQty

        then: "这个时候po管控件状态应该为 部分处理"
        def data9 = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]],
                'turnControlStatus', POTurnControlStatus.PART_TRANSFER.getCode())

        then: "将剩余的 po 单明细全部转单, po 单状态应变更为 全部处理"
        def data10 = ReqUtil.post("/spsInternal/po/detail/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]])
        data10.records.each {
            def tempQty = new BigDecimal(it.qty).subtract(new BigDecimal(it.turnedControlQty)).intValue()
            if (tempQty == 0) {
                return
            }
            ReqUtil.post("/spsInternal/po/controlTransfer", [bizType: 'SP', detailId: it.detailId, qty: tempQty])
        }
        def data11 = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'turnControlStatus', POTurnControlStatus.ALL_DONE.getCode())
    }

    def "管控件转单 状态测试, 不走全流程"() {
        MaterialUtil.update(S170010004, false, false, false, false)
        MaterialUtil.update(S170010005, false, false, false, true)

        when: "创建 PO"
        def poReq = Req.addPoReq([S170010004, S170010005])
        def poNo = ReqUtil.post("/internal/purchaseOrder/add", poReq)

        then: "PO 单管控件状态应该为 待处理"
        def data3 = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]],
                'purchaseOrderStatusCode', PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL.getCode())
        def data = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'turnControlStatus', POTurnControlStatus.PENDING.getCode())

        then: "S170010005 全部转单, po 管控件状态应该更为 全部处理"
        def data1 = ReqUtil.post("/spsInternal/po/detail/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo, salePartNum: S170010005]])
        ReqUtil.post("/spsInternal/po/controlTransfer", [bizType: 'SP', detailId: data1.records[0].detailId, qty: data1.records[0].qty])
        def data2 = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'turnControlStatus', POTurnControlStatus.ALL_DONE.getCode())
    }

    def "管控件转单 测试零件同时 dfs & 管控件"() {
        MaterialUtil.update(S170010004, false, true, false, true)
        MaterialUtil.update(S170010005, false, false, false, true)

        when: "创建 PO"
        def poReq = Req.addPoReq([S170010004, S170010005])
        def poNo = ReqUtil.post("/internal/purchaseOrder/add", poReq)

        then: "PO 单管控件状态应该为 待处理"
        def data = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]], 'turnControlStatus', POTurnControlStatus.PENDING.getCode())

        then: "S170010004 是 dfs 也是管控件，po单明细里管控件为 '' "
        def data1 = ReqUtil.post("/spsInternal/po/detail/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo, salePartNum: S170010004]])
        data1.records[0].isControl == ''
    }

}
