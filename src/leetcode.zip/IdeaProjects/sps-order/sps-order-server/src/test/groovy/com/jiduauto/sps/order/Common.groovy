package com.jiduauto.sps.order

import cn.hutool.core.date.DateUtil
import com.jiduauto.sps.order.server.App
import com.jiduauto.sps.order.server.utils.RedisUtil
import com.jiduauto.sps.sdk.consts.BaseConstants
import com.jiduauto.sps.sdk.utils.DateUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.annotation.DirtiesContext
import spock.lang.Specification

import javax.annotation.Resource
import java.time.LocalDate
import java.time.format.DateTimeFormatter

//当想要一次跑完所有测的测试, 请让下面注释的注解生效, 它的作用是强迫每个 test 类运行完后完全的重启服务, 保证各种资源释放后再重新获取
//没有这个注解, 对于可以使用相同上下文的test类服务不会重启, 是正常的, 但当执行到使用到 @mock or @mockBean or @SpyBean 等test 类时,
//服务会重启, 但是没有释放上一次服务获取的各种资源, 会导致各种报错 如 "The producer group[pg-dit-sps-order] has been created before, specify another name please."
// 解决方法 1. 加上这个注解就可以解决这个问题, 一次跑完所有测试, 但是效率会很低
// 2. 单独执行 使用到 mock 功能的 test 类
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
@SpringBootTest(classes = App.class, webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
class Common extends Specification {

    static final Logger log = LoggerFactory.getLogger(Common.class)

    @Resource
    RedisUtil redisUtil

    static def dataSource = new DataSource()
    static def spsSql = dataSource.spsSql
    static def spsOrderSql = dataSource.spsOrderSql

    // setupSpec == junit beforeClass
    def setupSpec() {
        System.setProperty("apollo.meta", "http://config.jidudev.com:8080")
    }

    //查看单号是否增加过没有增加  防止影响 test 环境
    //setup == junit before
    def setup() {
        def po = spsOrderSql.firstRow("select * from purchase_order where is_del = false order by create_time desc limit 1")
        if (po.purchase_order_no.substring(2, 8) != LocalDate.now().format(DateTimeFormatter.ofPattern("yyMMdd"))) {
            addNo()
            ReqUtil.spsPost("/test/addRedisNo", "")
        }
    }

    def addNo() {
        String redisKeyPO = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "PO",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "SP")

        Long serialNo = redisUtil.incrAndExpire(redisKeyPO, 1000L,
                24 * 60 * 60)
        if (serialNo > 1000) {
            return
        }

        String redisKeySO = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "SO",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "SP")

        Long serialNoSO = redisUtil.incrAndExpire(redisKeySO, 1000L,
                24 * 60 * 60)

        String redisKeyBO = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "BO",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "SP")

        Long serialNoBO = redisUtil.incrAndExpire(redisKeyBO, 1000L,
                24 * 60 * 60)

        String redisKeySTO = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "TR",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "SS")

        Long serialNoSTO = redisUtil.incrAndExpire(redisKeySTO, 1000L,
                24 * 60 * 60)
    }

}