package com.jiduauto.sps.order.test

import cn.hutool.json.JSONUtil
import com.jiduauto.dit.outbox.OutboxMessageService
import com.jiduauto.sps.order.Common
import com.jiduauto.sps.order.Req
import com.jiduauto.sps.order.ReqUtil
import com.jiduauto.sps.order.StockUtil
import com.jiduauto.sps.order.server.convertor.NoticedDtoConvertor
import com.jiduauto.sps.order.server.facade.WarehouseDistributeOrderFacadeService
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderAddReq
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderCancelReq
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService
import com.jiduauto.sps.order.server.utils.WebhookUtil
import com.jiduauto.sps.order.server.xxljobs.OldDataUpdateHandler
import com.jiduauto.sps.sdk.consts.BaseConstants
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderStatusEnum
import com.jiduauto.sps.sdk.exception.BizException
import spock.lang.Ignore

import javax.annotation.Resource

class WdoTest extends Common {

    @Resource
    private WarehouseDistributeOrderFacadeService warehouseDistributeOrderFacadeService

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService

    @Resource
    WebhookUtil webhookUtil;

    @Resource
    private NoticedDtoConvertor noticedDtoConvertor

    @Resource
    private OldDataUpdateHandler oldDataUpdateHandler;

    @Resource
    private OutboxMessageService outboxMessageService


    def "商城订单创建流程"() {
        given: "初始化库存 默认100"
        StockUtil.createWdoStock("J99L01003A")
        StockUtil.createWdoStock("J99L01002A")
        def addReq = Req.wdoAddReq()

        when: "商城物流订单创建 默认数量是1"
        WarehouseDistributeOrderAddReq wdoReq = JSONUtil.toBean(addReq, WarehouseDistributeOrderAddReq.class)
        def addResp = warehouseDistributeOrderFacadeService.add(wdoReq)
        Thread.sleep(3000)
        then: "订单状态为已下发"
        int cnt1 = 10
        def orderPo1 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        while (cnt1 > 0 && orderPo1.getOrderStatus() != WarehouseDistributeOrderStatusEnum.DELIVERED.code) {
            Thread.sleep(1000)
            orderPo1 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
            cnt1--
        }
        assert orderPo1.getOrderStatus() == WarehouseDistributeOrderStatusEnum.DELIVERED.code

        def stock1 = StockUtil.getStockQty("J99L01003A")
        def stock2 = StockUtil.getStockQty("J99L01002A")
        assert stock1.occupyQty == 1
        assert stock2.occupyQty == 1


        when: "mock dhl 出库"
        def itemList = [
                new Req.PutOutItem("J99L01003A", 1, "", "", "1"),
                new Req.PutOutItem("J99L01002A", 1, "", "", "2"),
        ]
        def req = Req.sm20PutOutStockReq(itemList, addResp.orderNo)
        ReqUtil.spsPost("/external/stock/putOutStock", req)

        then: "订单状态为已出库"
        def cnt2 = 10
        def orderPo2 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        while (cnt2 > 0 && orderPo2.getOrderStatus() != WarehouseDistributeOrderStatusEnum.OUT_STOCK_COMPLETED.code) {
            orderPo2 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
            Thread.sleep(1000)
            cnt2--
        }
        assert orderPo2.getOrderStatus() == WarehouseDistributeOrderStatusEnum.OUT_STOCK_COMPLETED.code

        Thread.sleep(3000)
        and: "此时库存应该减少1, 占用数量应该是0,在途数量是1"
        def resp2 = StockUtil.getStockQty("J99L01003A")
        def resp3 = StockUtil.getStockQty("J99L01002A")
        with(resp2) {
            occupyQty == 0
            vQty == 1
            sumQty == 99
        }
        with(resp3) {
            occupyQty == 0
            vQty == 1
            sumQty == 99
        }
    }

    def "商城订单异常流程测试"() {
        when: "初始化库存 默认100"
        StockUtil.createWdoStock("J99L01003A")
        StockUtil.createWdoStock("J99L01002A")
        def addReq = Req.wdoAddReq()

        then: "商城物流订单创建"
        WarehouseDistributeOrderAddReq wdoReq = JSONUtil.toBean(addReq, WarehouseDistributeOrderAddReq.class)
        def addResp = warehouseDistributeOrderFacadeService.add(wdoReq)

        then: "订单状态为已下发"
        def cnt1 = 100
        def orderPo1 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        while (cnt1 > 0 && orderPo1.getOrderStatus() != WarehouseDistributeOrderStatusEnum.DELIVERED.code) {
            Thread.sleep(1000)
            cnt1--
            orderPo1 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        }
        assert orderPo1.getOrderStatus() == WarehouseDistributeOrderStatusEnum.DELIVERED.code
        then: "占用数量应该是1"
        def J99L01003AStock = StockUtil.getStockQty("J99L01003A")
        def J99L01002AStock = StockUtil.getStockQty("J99L01002A")
        assert J99L01003AStock.occupyQty == 1
        assert J99L01002AStock.occupyQty == 1

        then: "模拟商城订单履约完成，特殊标记改为true"
        orderPo1.setIsSpecial(true)
        warehouseDistributeOrderService.updateById(orderPo1)

        when: "mock dhl 出库"
        def itemList = [
                new Req.PutOutItem("J99L01003A", 1, "", "", "1"),
                new Req.PutOutItem("J99L01002A", 1, "", "", "2"),
        ]
        def req = Req.sm20PutOutStockReq(itemList, addResp.orderNo)
        ReqUtil.spsPost("/external/stock/putOutStock", req)

        then: "订单状态为已完成"
        def cnt2 = 100
        def orderPo2 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        while (cnt2 > 0 && orderPo2.getOrderStatus() != WarehouseDistributeOrderStatusEnum.COMPLETED.code) {
            Thread.sleep(1000)
            cnt2--
            orderPo2 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        }
        assert orderPo2.getOrderStatus() == WarehouseDistributeOrderStatusEnum.COMPLETED.code

        and: "此时库存应该减少1, 占用数量应该是0,在途数量是跟出库之前保存一致"
        def resp = StockUtil.getStockQty("J99L01003A")
        def resp2 = StockUtil.getStockQty("J99L01002A")
        with(resp) {
            sumQty == 99
            occupyQty == 0
            vQty == 0
        }
        with(resp2) {
            sumQty == 99
            occupyQty == 0
            vQty == 0
        }

    }

    def "商城订单取消测试"() {
        when: "初始化库存 默认100"
        StockUtil.createWdoStock("J99L01003A")
        StockUtil.createWdoStock("J99L01002A")
        def addReq = Req.wdoAddReq()

        then: "商城物流订单创建"
        WarehouseDistributeOrderAddReq wdoReq = JSONUtil.toBean(addReq, WarehouseDistributeOrderAddReq.class)
        def addResp = warehouseDistributeOrderFacadeService.add(wdoReq)


        then: "订单状态为已下发"
        def cnt1 = 10
        def orderPo1 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        while (cnt1 > 0 && orderPo1.getOrderStatus() != WarehouseDistributeOrderStatusEnum.DELIVERED.code) {
            Thread.sleep(1000)
            cnt1--
            orderPo1 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        }
        then: "占用数量应该是1"
        def occupyStock = StockUtil.stockQty("J99L01003A")
        def occupyStock2 = StockUtil.stockQty("J99L01002A")
        assert occupyStock.occupyQty == 1
        assert occupyStock2.occupyQty == 1

        when: "更新订单状态为已发货"
        orderPo1.setOrderStatus(WarehouseDistributeOrderStatusEnum.SHIPPED.code)
        warehouseDistributeOrderService.updateById(orderPo1)

        and: "取消订单"
        def cancelReq = new WarehouseDistributeOrderCancelReq()
        cancelReq.setBizType("SM")
        cancelReq.setOrderNo(addResp.orderNo)
        warehouseDistributeOrderService.cancel(cancelReq)

        then: "抛出异常"
        thrown(BizException)
        Map<String, String> msgMap = webhookUtil.buildMsgMap(
                noticedDtoConvertor.buildNoticedDto(orderPo1, "仓配订单异常消息测试",
                        BaseConstants.MessageTitle.WD_NOT_OUT_STOCK));
        webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap),
                BaseConstants.MessageTitle.WD_NOT_OUT_STOCK);

        when: "更新订单状态为已下发"
        orderPo1.setOrderStatus(WarehouseDistributeOrderStatusEnum.DELIVERED.code)
        warehouseDistributeOrderService.updateById(orderPo1)

        and: "取消订单"
        def cancelReq2 = new WarehouseDistributeOrderCancelReq()
        cancelReq2.setBizType("SM")
        cancelReq2.setOrderNo(addResp.orderNo)
        warehouseDistributeOrderService.cancel(cancelReq2)

        then: "订单状态为已取消"
        def cnt2 = 10
        def orderPo2 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        while (cnt2 > 0 && orderPo2.getOrderStatus() != WarehouseDistributeOrderStatusEnum.CANCELED.code) {
            Thread.sleep(1000)
            cnt2--
            orderPo2 = warehouseDistributeOrderService.getByOrderNo("SM", addResp.orderNo)
        }
        assert orderPo2.getOrderStatus() == WarehouseDistributeOrderStatusEnum.CANCELED.code

        then: "此时库存100, 占用数量应该是0,在途数量是跟出库之前保存一致"
        def resp1 = StockUtil.stockQty("J99L01003A")
        def resp2 = StockUtil.stockQty("J99L01002A")
        with(resp1) {
            sumQty == 100
            occupyQty == 0
            vQty == 0
        }
        with(resp2) {
            sumQty == 100
            occupyQty == 0
            vQty == 0
        }
    }

    def "仓配订单入库类型和调拨类型旧数据迁移入库订单"() {
        when: "执行job"
        oldDataUpdateHandler.oldToInOrder("")
        then: "自己看数据库"
    }


    def "内领出库下发srm"() {
        when: "根据id执行"
        outboxMessageService.doHandleMessageById(3436)
        then: "看结果"
    }

    def "在途库存出库"(){
        when: "执行job"
        oldDataUpdateHandler.outOfVmStock("SM-JO13000070624")
        then: "自己看数据库"
    }
}
