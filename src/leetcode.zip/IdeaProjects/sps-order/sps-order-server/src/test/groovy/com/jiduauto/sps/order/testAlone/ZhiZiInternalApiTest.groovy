package com.jiduauto.sps.order.testAlone

import com.jiduauto.sps.order.*
import com.jiduauto.sps.order.server.facade.PurchaseOrderFacadeService
import com.jiduauto.sps.sdk.client.SAPRestAdapterClient
import com.jiduauto.sps.sdk.client.resp.PurchaseOrderSyncResp
import com.jiduauto.sps.sdk.enums.BackOrderStatusEnum
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum
import com.jiduauto.sps.sdk.enums.StoreTransferOrderStatus
import org.mockito.Mockito
import org.springframework.boot.test.mock.mockito.SpyBean

import javax.annotation.Resource

/**
 * 提供给智子的接口功能测试
 * 这个test类需要单独执行, 因为使用了 @SpyBean 详情请看  Common 类注释
 * 不能和别的测试一起执行
 * 或者放开 Common 类的注释
 */
class ZhiZiInternalApiTest extends Common {

    @Resource
    PurchaseOrderFacadeService purchaseOrderFacadeService

    @SpyBean
    @Resource
    SAPRestAdapterClient sapRestAdapterClient

    //=============================     PO 相关 API  ==============================
    // po 创建 测试在 poTest

    def "internal_purchaseOrder_commit 测试"() {
        def resp = new PurchaseOrderSyncResp()
        def body = new PurchaseOrderSyncResp.ClassMessageBody()
        PurchaseOrderSyncResp.ClassMessageBodyHeader header = new PurchaseOrderSyncResp.ClassMessageBodyHeader()
        header.setMessage_Text("少飞-autoTest, 模拟 SAP 同步采购订单失败")
        body.setHeader(header)
        resp.setMessageBody([body])

        // MOCK syncPurchaseOrder 方法, 使其下次调用时返回失败
        Mockito.doReturn(resp).when(sapRestAdapterClient).syncPurchaseOrder(Mockito.any())
        when: "请求 po internal api mock了 sap 失败"

        def poReq = Req.addPoReq([StockUtil.S170010004, StockUtil.S170010005], "VOR", 4)
        def poNo = ReqUtil.post("/internal/purchaseOrder/add", poReq, GlobalCodeEnum.GL_FAIL_10000.getCode())
        //清除 mock 行为, 不影响其他 po 创建
        Mockito.reset(sapRestAdapterClient)
        then:
        def poNo2 = ReqUtil.post("/internal/purchaseOrder/commit", [bizType: 'SP', purchaseOrderNo: poNo, operateUser: "少飞-autoTest"])
    }


    def "internal_purchaseOrder_pageSearch 测试"() {
        def data = ReqUtil.post("/internal/purchaseOrder/pageSearch", [param: [bizType: 'SP']])
        expect:
        data.records.size() == 10
    }

    def "internal_purchaseOrder_list 测试"() {
        def data = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP']])
        def arr = data.records.collect { it.purchaseOrderNo }
        expect:
        def data1 = ReqUtil.post("/internal/purchaseOrder/list", [bizType: 'SP', purchaseOrderNos: arr])
        data1.each { arr.contains(it.purchaseOrderNo) }
    }


    //==============================     BO 相关 API   ==============================
    // BO 取消申请接口在 PoTest 类测试

    def "internal_backOrder_pageSearch 测试"() {
        def data1 = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP']])
        //获取一条最新的
        def poNo = data1.records[0].purchaseOrderNo

        when: "请求 bo internal api"
        def data = ReqUtil.post("/internal/backOrder/pageSearch",
                [param: [
                        bizType        : 'SP',
                        purchaseOrderNo: poNo
                ]])
        then:
        data.records.each {
            it.purchaseOrderNo == poNo
        }
        then:
        def data3 = ReqUtil.post("/internal/backOrder/pageSearch",
                [param: [
                        bizType        : 'SP',
                        backOrderStatus: BackOrderStatusEnum.PENDING.getCode()
                ]])
        data3.records.each {
            it.backOrderStatus == BackOrderStatusEnum.PENDING.getCode()
        }
    }

    def "internal_backOrder_list 测试"() {
        def data = ReqUtil.post("/spsInternal/bo/pageSearch", [param: [bizType: 'SP']])
        //获取一条最新的
        def arr = [
                data.records[0].backOrderNo,
                data.records[1].backOrderNo,
                data.records[2].backOrderNo
        ]

        when: "请求 bo internal api"
        def data1 = ReqUtil.post("/internal/backOrder/list",
                [
                        bizType     : 'SP',
                        backOrderNos: arr
                ])
        then:
        data1.size() == arr.size()
        data1.each {
            arr.contains(it.backOrderNo)
        }
    }

    //==============================     SO 相关 API   ==============================

    def "internal_saleOrder_detail_pageSearch 测试"() {
        when: "请求 so internal api"
        def data1 = ReqUtil.post("/internal/saleOrder/pageSearch", [param: [bizType: 'SP']])
        then:
        def data2 = ReqUtil.post("/internal/saleOrder/detail/pageSearch",
                [param: [bizType: 'SP', saleOrderNo: data1.records[0].saleOrderNo]])
    }

    def "internal_saleOrder_pageSearch  & internal_saleOrder_list 测试"() {
        def data1 = ReqUtil.post("/internal/saleOrder/pageSearch", [param: [bizType: 'SP']])
        def arr = data1.records.collect { it.saleOrderNo }
        when: "请求 so internal api"
        def data2 = ReqUtil.post("/internal/saleOrder/list", [bizType: 'SP', saleOrderNos: arr])
        then:
        data2.each { arr.contains(it.saleOrderNo) }
    }


    def "internal_saleOrder_listDetailByPo 测试"() {
        def data1 = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP']])
        def arr = data1.records.collect { it.purchaseOrderNo }
        when: "请求 so internal api"
        def data2 = ReqUtil.post("/internal/saleOrder/listDetailByPo", [bizType: 'SP', purchaseOrderNos: arr])
        then:
        data2.each { arr.contains(it.purchaseOrderNo) }
    }


    //=============================     调拨订单 相关 API  ==============================
    def "storeTransferOrder_add & commit & pageSearch 测试"() {
        def resp = new PurchaseOrderSyncResp()
        def body = new PurchaseOrderSyncResp.ClassMessageBody()
        PurchaseOrderSyncResp.ClassMessageBodyHeader header = new PurchaseOrderSyncResp.ClassMessageBodyHeader()
        header.setMessage_Text("少飞-autoTest, 模拟 SAP 同步调拨订单失败")
        body.setHeader(header)
        resp.setMessageBody([body])

        // MOCK syncPurchaseOrder 方法, 使其下次调用时返回失败
        Mockito.doReturn(resp).when(sapRestAdapterClient).syncPurchaseOrder(Mockito.any())
        when: "请求调拨单 internal api mock了 sap 失败"

        def stoReq = Req.addSTOReq([StockUtil.S170010004, StockUtil.S170010005], 4)
        def stoNo = ReqUtil.post("/internal/storeTransferOrder/add", stoReq, GlobalCodeEnum.GL_FAIL_10000.getCode())
        //清除 mock 行为, 不影响其他 po 创建
        Mockito.reset(sapRestAdapterClient)
        then:
        ReqUtil.post("/internal/storeTransferOrder/commit", [bizType: 'SS', orderNo: stoNo, operateUser: "少飞-autoTest"])
        ReqUtil.post("/internal/storeTransferOrder/pageSearch", [param: [bizType: 'SS', orderNo: stoNo]], 'orderStatus', StoreTransferOrderStatus.COMMITTED.getValue())
    }

    def "storeTransferOrder_cancel 测试"() {
        when: "调拨单创建"
        def stoReq = Req.addSTOReq([StockUtil.S170010004, StockUtil.S170010005], 4)
        def stoNo = ReqUtil.post("/internal/storeTransferOrder/add", stoReq)
        then:
        ReqUtil.post("/internal/storeTransferOrder/pageSearch", [param: [bizType: 'SS', orderNo: stoNo]], 'orderStatus', StoreTransferOrderStatus.COMMITTED.getValue())

        then: "取消调拨单"
        ReqUtil.post("/internal/storeTransferOrder/cancel", [bizType: 'SS', orderNo: stoNo, operateUser: "少飞-autoTest"])
        ReqUtil.post("/internal/storeTransferOrder/pageSearch", [param: [bizType: 'SS', orderNo: stoNo]], 'orderStatus', StoreTransferOrderStatus.CANCELED.getValue())
    }

    def "storeTransferOrder_update & confirm & detailPageSearch 测试"() {
        when: "调拨单创建"
        int qty = 4
        def stoReq = Req.addSTOReq([StockUtil.S170010004, StockUtil.S170010005], qty)
        def stoNo = ReqUtil.post("/internal/storeTransferOrder/add", stoReq)
        then:
        ReqUtil.post("/internal/storeTransferOrder/pageSearch", [param: [bizType: 'SS', orderNo: stoNo]], 'orderStatus', StoreTransferOrderStatus.COMMITTED.getValue())

        then: "更新调拨单"
        def address = "上海嘉定集度汽车招贤路1688"
        ReqUtil.post("/internal/storeTransferOrder/update", """
{
  "orderNo": "${stoNo}",
  "transferOutWarehouseCode": "G59",
  "transferOutAddress": "${address}",
  "transferOutContactName": "shaofei",
  "transferOutContactMobile": "15512341234",
  "logisticsNo": "123123123",
  "logisticsCompany": "顺丰",
  "remark": "this is remark",
  "operateUser": "shaofei-AutoTest",
  "bizType": "SS"
}
"""
        )
        then: "查看字段是否更新"
        ReqUtil.post("/internal/storeTransferOrder/pageSearch", [param: [bizType: 'SS', orderNo: stoNo]], 'transferOutAddress', address)

        then: "确认调拨单"
        ReqUtil.post("/internal/storeTransferOrder/confirm", [bizType: 'SS', orderNo: stoNo, operateUser: "少飞-autoTest"])
        ReqUtil.post("/internal/storeTransferOrder/pageSearch", [param: [bizType: 'SS', orderNo: stoNo]], 'orderStatus', StoreTransferOrderStatus.CONFIRM.getValue())
        def data = ReqUtil.post("/internal/storeTransferOrder/detail/pageSearch", [param: [bizType: 'SS', orderNo: stoNo]])
        data.records.size == 2
    }


}
