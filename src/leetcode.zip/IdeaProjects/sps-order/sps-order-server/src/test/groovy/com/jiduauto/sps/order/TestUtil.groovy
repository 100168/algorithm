package com.jiduauto.sps.order

class TestUtil {

    /**
     * 生成一个 从 1 到 qty(包含) 的随机数
     */
    static int getRandomInt(int qty) {
        int randInt = new Random().nextInt(qty + 1)
        randInt == 0 ? 1 : randInt
    }
}
