package com.jiduauto.sps.order

import cn.hutool.json.JSONUtil
import groovy.json.JsonSlurper
import org.springframework.boot.test.web.client.TestRestTemplate
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType

class ReqUtil {
    static def test = new TestRestTemplate()
    static String spsOrderBasicUrl = "http://127.0.0.1:8080/sps-order"
    static String spsBasicUrl = "https://sps.jidudev.com/api/sps"
    static def jsonParse = new JsonSlurper()
    static String token = "bpb43067f22fd78273bea1394aecc021"
    static HttpHeaders headers;

    static {
        headers = new HttpHeaders();
        // 设置请求头的方式，根据需要设置
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("accesstoken", token)
        headers.set("Authorization", "Basic dGVzdDp0ZXN0")
    }


    /**
     * post 请求
     * 返回 data
     * @param shortUrl 路径
     * @param body json 请求字符串 & 对象参数都支持, 对象参数传入后会序列化成字符串json再进行请求
     * @param code 期望的返回结果的code  默认为 0
     */
    static def post(String shortUrl, body, int code = 0) {
        if (!(body instanceof String)) {
            body = JSONUtil.toJsonStr(body)
        }
        def returnRet = postCodeEqual(spsOrderBasicUrl, shortUrl, body, code).data
        returnRet == "" ? "true" : returnRet
    }

    /**
     * post 请求 sps dev 接口 返回code == 0
     * 返回 data
     */
    static def spsPost(String shortUrl, body) {
        if (!(body instanceof String)) {
            body = JSONUtil.toJsonStr(body)
        }
        def returnRet = postCodeEqual(spsBasicUrl, shortUrl, body, 0).data
        returnRet == "" ? "true" : returnRet
    }


    /**
     * post 判断 code 是否相等
     */
    static def postCodeEqual(String baseUrl, String shortUrl, String body, Integer code) {
        def retStr = test.postForEntity(baseUrl + shortUrl, new HttpEntity<>(body, headers), String.class)
        def retObj = retStr.with {
            //http 状态
            assert it.statusCode == HttpStatus.OK
            def ret = jsonParse.parseText(it.body)
            assert ret.code == code
            ret
        }
        retObj
    }

    /**
     *
     * 该方法用于有些异步接口执行后一直在执行,查询分页接口如 so, po的时候  不知道 po, so 的订单状态什么时候才能进行变更
     * 此方法将会循环 4 次请求, 请求发现状态值不对后 Thread.sleep 4 s
     * 超过 4 次 后该次 test 失败
     *
     * post 请求 要求返回code == 0
     * return data
     * @param shortUrl 路径
     * @param body json 请求字符串 & 对象参数都支持, 对象参数传入后会序列化成字符串json再进行请求
     * @param fieldName 状态值的字段名称 比如 SO 查询结果里的 saleOrderStatus
     * @param statusValue 期望的状态值  如 SaleOrderStatusEnum.FULLY_RECEIVED.getCode()
     */
    static def post(String shortUrl, Object body, String fieldName, String statusValue) {
        if (!(body instanceof String)) {
            body = JSONUtil.toJsonStr(body)
        }
        def returnRet
        int runNum = 0
        while (true) {
            returnRet = postCodeEqual(spsOrderBasicUrl, shortUrl, body.toString(), 0).data
            //默认分页查询的数据 只有一条
            if (returnRet.records.size() == 1 && returnRet.records[0]."${fieldName}" == statusValue) {
                break
            }
            Thread.sleep(4000)
            runNum++
            assert runNum <= 3
        }
        returnRet
    }

    /**
     *
     * 该方法用于有些异步接口执行后一直在执行,查询分页接口如 so, po的时候  不知道 po, so 的订单状态什么时候才能进行变更
     * 此方法将会循环 4 次请求, 请求发现状态值不对后 Thread.sleep 4 s
     * 超过 4 次 后该次 test 失败
     *
     * post 请求 要求返回code == 0
     * return data
     * @param shortUrl 路径
     * @param body json 请求字符串 & 对象参数都支持, 对象参数传入后会序列化成字符串json再进行请求
     * @param fieldName 状态值的字段名称 比如 SO 查询结果里的 saleOrderStatus
     * @param statusValue 期望的状态值  如 SaleOrderStatusEnum.FULLY_RECEIVED.getCode()
     */
    static def spsPost(String shortUrl, Object body, String fieldName, String statusValue) {
        if (!(body instanceof String)) {
            body = JSONUtil.toJsonStr(body)
        }
        def returnRet
        int runNum = 0
        while (true) {
            returnRet = postCodeEqual(spsBasicUrl, shortUrl, body.toString(), 0).data
            //默认分页查询的数据 只有一条
            if (returnRet.records.size() == 1 && returnRet.records[0]."${fieldName}".toString() == statusValue) {
                break
            }
            Thread.sleep(4000)
            runNum++
            assert runNum <= 3
        }
        returnRet
    }
}
