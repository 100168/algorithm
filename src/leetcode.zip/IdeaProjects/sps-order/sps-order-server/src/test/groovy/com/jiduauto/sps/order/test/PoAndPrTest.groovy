package com.jiduauto.sps.order.test

import com.jiduauto.sps.order.Common
import com.jiduauto.sps.order.MaterialUtil
import com.jiduauto.sps.order.Req
import com.jiduauto.sps.order.ReqUtil
import com.jiduauto.sps.sdk.enums.*

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import static com.jiduauto.sps.order.StockUtil.*

/**
 * po & 采购申请 & asn 关联测试
 */
class PoAndPrTest extends Common {


    def "co定制件 po & 采购申请 & asn 关联测试"() {
        given: "初始化库存 指定零件为定制件"
        MaterialUtil.update(S110010001, false, false, true, false)

        when: "创建PO"
        def poReq = Req.addPoReq([S110010001], "CO", 1)
        def poNo = ReqUtil.post("/internal/purchaseOrder/add", poReq)
        then: "生成一单 PO 类型为 CO, 状态为已审核"
        def data = ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]],
                'purchaseOrderStatusCode', PurchaseOrderStatusEnum.APPROVED.getCode())
        ReqUtil.post("/spsInternal/po/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]],
                'turnPurchaseOrderStatus', TurnPurchaseOrderStatusEnum.PROCESSED.getCode())
        then: "生成采购申请"
        def detail = spsSql.firstRow("select * from purchase_apply_order_detail where purchase_order_no = '${poNo}'")
        def main = spsSql.firstRow("select * from purchase_apply_order where id = '${detail.order_id}'")
        def cnt = 5
        while (cnt > 0 && main.sap_order_no == null) {
            Thread.sleep(2000)
            cnt--
        }
        then: "mock asn 下发"
        def asnCode = "ASN" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss"))
        def prNo = main.order_no
        def asnReq = Req.asnAddReq(asnCode, [new Req.AsnItem(
                prNo,
                detail.line_no,
                main.sap_order_no,
                detail.line_no,
                detail.sale_part_num,
                detail.purchase_order_no,
                1,
                asnCode
        )])
        ReqUtil.spsPost("/internal/asn/add", asnReq)
        then: "检查 ASN 收货 & 采购申请发货"
        ReqUtil.spsPost("/asn/basic/list", [param: [bizType: 'SP', asnCode: asnCode]], 'state', AsnStatusEnum.Delivered.getItemName())
        ReqUtil.spsPost("/asn/deliver/list", [param: [bizType: 'SP', asnNo: asnCode]], 'deliveryQty', '1')

        then: "mock dhl asn 入库 G59, asn 状态变为已收货，收货数量为 1"
        def req = Req.asnCOPutInStockSP10Req(main.supplier_code, S110010001, asnCode)
        ReqUtil.spsPost('/external/stock/putInStock', req)
        ReqUtil.spsPost("/asn/basic/list", [param: [bizType: 'SP', asnCode: asnCode]], 'state', AsnStatusEnum.AllReceived.getItemName())
        ReqUtil.spsPost("/asn/deliver/list", [param: [bizType: 'SP', asnNo: asnCode]], 'receiveQty', '1')

        then: "手动转销售订单"
        ReqUtil.post("/spsInternal/po/transferOrder", [bizType: 'SP', id: data.records[0].id])
        def data2 = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]],
                'saleOrderStatusCode', SaleOrderStatusEnum.PENDING_DELIVERY.getCode())
        def soNo = data2.records[0].saleOrderNo
        then: "mock dhl 发货销售订单"

        def itemList = [
                new Req.PutOutItem(
                        S110010001,
                        1,
                        main.supplier_code.toString(),
                        asnCode,
                        '10'
                ),
        ]
        def req2 = Req.putOutStockReq(itemList, soNo)
        ReqUtil.spsPost("/external/stock/putOutStock", req2)

        def data3 = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', saleOrderNo: soNo]],
                'saleOrderStatusCode', SaleOrderStatusEnum.DELIVERED.getCode())

        then: "mock 门店收货"
        def putInItemList = [
                new Req.PutInItem(S110010001, 1),
        ]
        def putInReq = Req.soPutInStockSS11Req(putInItemList, soNo)
        ReqUtil.spsPost("/internal/stock/putInStock", putInReq)
        ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', saleOrderNo: soNo]],
                'saleOrderStatusCode', SaleOrderStatusEnum.FULLY_RECEIVED.getCode())

    }

    def "dfs so po & 采购申请 & asn 关联测试"() {
        given: "初始化库存 指定零件为定制件"
        MaterialUtil.update(S170030035, false, true, false, false)
        MaterialUtil.update(S110010001, false, true, false, false)
        int qty = 2
        when: "创建PO"
        def poReq = Req.addPoReq([S110010001, S170030035], "RO", qty)
        def poNo = ReqUtil.post("/internal/purchaseOrder/add", poReq)
        then: "生成一单 PO 类型为 RO, 状态为已审核"
        def data = ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', purchaseOrderNo: poNo]],
                'dfsStatusCode', SaleOrderDfsStatusEnum.TRANSFER_SUCCESSFUL.code)
        then: "生成采购申请"
        def detailList = spsSql.rows("select * from purchase_apply_order_detail where purchase_order_no = '${poNo}'")
        def main = spsSql.firstRow("select * from purchase_apply_order where id = '${detailList[0].order_id}'")
        def cnt = 5
        while (cnt > 0 && main.sap_order_no == null) {
            Thread.sleep(2000)
            cnt--
        }
        then: "mock asn 下发"
        def asnCode = "ASN" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss"))
        def prNo = main.order_no
        def soNo = detailList[0].sale_order_no
        def asnReq = Req.asnAddReq(asnCode,
                detailList.collect {
                    new Req.AsnItem(prNo, it.line_no, main.sap_order_no, it.line_no, it.sale_part_num, it.purchase_order_no, 2, asnCode, it.sale_order_no)
                },
                RequirementTypeEnum.DFS.code,
                'Service00002'
        )
        ReqUtil.spsPost("/internal/asn/add", asnReq)

        then: "检查 ASN 收货 & 采购申请发货"
        ReqUtil.spsPost("/asn/basic/list", [param: [bizType: 'SP', asnCode: asnCode]], 'state', AsnStatusEnum.Delivered.getItemName())
        def data2 = ReqUtil.spsPost("/asn/deliver/list", [param: [bizType: 'SP', asnNo: asnCode]])
        data2.records.each { assert it.deliveryQty == qty }

        then: "mock 门店收货 asn 入库 , asn 状态变为已收货，收货数量为 10 & 销售订单状态变全部收货"
        def putInItemList = [
                new Req.PutInItem(S170030035, qty, detailList.find { (it.sale_part_num == S170030035) }.line_no.toString(), asnCode),
                new Req.PutInItem(S110010001, qty, detailList.find { (it.sale_part_num == S110010001) }.line_no.toString(), asnCode),
        ]

        def putInReq = Req.dfsPutInStockSS13Req(putInItemList, asnCode)
        ReqUtil.spsPost("/internal/stock/putInStock", putInReq)
        ReqUtil.spsPost("/asn/basic/list", [param: [bizType: 'SP', asnCode: asnCode]], 'state', AsnStatusEnum.AllReceived.getItemName())
        def data3 = ReqUtil.spsPost("/asn/deliver/list", [param: [bizType: 'SP', asnNo: asnCode]])

        data3.records.each { assert it.receiveQty == qty }
        ReqUtil.post("/spsInternal/so/pageSearch", [param: [bizType: 'SP', saleOrderNo: soNo]],
                'saleOrderStatusCode', SaleOrderStatusEnum.FULLY_RECEIVED.getCode())

    }
}
