package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.StoreRecommendationListDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListPageReq;
import com.jiduauto.sps.order.server.service.IStoreRecommendationListService;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 门店推荐清单 前端控制器
 */
@RestController
@RequestMapping("/storeRecommendationList")
public class StoreRecommendationListController {

    @Resource
    private IStoreRecommendationListService storeRecommendationListService;

    /**
     * 分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StoreRecommendationListDto>> pageSearch(@RequestBody @Valid BasePageParam<StandardRecommendationListPageReq> pageParam) {
        return BaseResult.OK(storeRecommendationListService.pageSearch(pageParam));
    }

}
