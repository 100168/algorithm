package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.mapper.WarehouseDistributeAttachMapper;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeAttachService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeAttachDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeAttachPo;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 仓配订单附属信息 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
@Service
public class WarehouseDistributeAttachServiceImpl extends ServiceImpl<WarehouseDistributeAttachMapper, WarehouseDistributeAttachPo> implements IWarehouseDistributeAttachService {


    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private BaseDataQuery baseDataQuery;


    @Override
    public WarehouseDistributeAttachDto selectWarehouseDistributeAttach(String bizType, String orderNo) {
        WarehouseDistributeAttachPo attachPo = baseMapper.selectOne(Wrappers
                .lambdaQuery(WarehouseDistributeAttachPo.class)
                .eq(WarehouseDistributeAttachPo::getBizType, bizType)
                .eq(WarehouseDistributeAttachPo::getWarehouseDistributeOrderNo, orderNo));
        return BeanCopierUtil.copy(attachPo,WarehouseDistributeAttachDto.class);
    }


    @Override
    public List<WarehouseDistributeAttachDto> getDto(String bizType, List<String> orderNo){

        List<WarehouseDistributeAttachPo> attachPos = baseMapper.selectList(Wrappers
                .lambdaQuery(WarehouseDistributeAttachPo.class)
                .eq(WarehouseDistributeAttachPo::getBizType, bizType)
                .in(WarehouseDistributeAttachPo::getWarehouseDistributeOrderNo, orderNo));

        List<WarehouseDistributeAttachDto> dtoList = BeanCopierUtil.copyList(attachPos, WarehouseDistributeAttachDto.class);
        List<String> list = new ArrayList<>();
        list.add(DictEnum.ApplyPurpose.getDictCode());
        list.add(DictEnum.ApplySake.getDictCode());

        Map<String, Map<String, String>> map = warehouseDistributeOrderService.getStringMapMap(bizType, list);
        Map<String, String> applyAim = map.getOrDefault(DictEnum.ApplyPurpose.getDictCode(), new HashMap<>());
        Map<String, String> applyPurpose= map.getOrDefault(DictEnum.ApplySake.getDictCode(), new HashMap<>());
        if (CollUtil.isEmpty(dtoList)){
            return CollUtil.newArrayList();
        }
        for (WarehouseDistributeAttachDto attachDto : dtoList) {
            attachDto.setApplyAim(applyAim.get(attachDto.getApplyAim()));
            attachDto.setApplyPurpose(applyPurpose.get(attachDto.getApplyPurpose()));
            Map<String, String> mapCompanyPo = baseDataQuery.mapCompanyPo(attachDto.getBizType(), CollUtil.toList(attachDto.getApplyCompany(), attachDto.getBeAppliedCompany()));
            attachDto.setApplyCompany(mapCompanyPo.get(attachDto.getApplyCompany()));
            attachDto.setBeAppliedCompany(mapCompanyPo.get(attachDto.getBeAppliedCompany()));
        }
        return dtoList;
    }
}
