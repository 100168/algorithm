package com.jiduauto.sps.order.server.controller.internal;


import com.jiduauto.sps.order.server.pojo.req.SapSynInvoiceReq;
import com.jiduauto.sps.order.server.pojo.resp.SapInvoiceResp;
import com.jiduauto.sps.order.server.service.ISapInvoiceInfoService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

@Slf4j
@RestController
@RequestMapping("/internal/sap")
public class InternalSapController {

    @Resource
    private ISapInvoiceInfoService sapInvoiceInfoService;

    @Resource
    private RedissonClient redissonClient;

    @PostMapping("/synInvoice")
    public SapInvoiceResp synInvoice(@RequestBody @Valid SapSynInvoiceReq req) {
        String invoiceNo = req.getMessageBody().get(0).getHeader().getInvoiceNo();
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_SYN_INVOICE_KEY, invoiceNo);
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            sapInvoiceInfoService.synInvoice(req);
        } catch (Exception e) {
            log.error("SAP 同步发票异常", e);
            return SapInvoiceResp.failedResp(e.getMessage(), invoiceNo);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
        return SapInvoiceResp.success(invoiceNo);
    }
}
