package com.jiduauto.sps.order.server.service;

public interface IBackOrderTransferService {

    /**
     * 批量自动转单
     */
    void batchAutoTransferOrder();
}
