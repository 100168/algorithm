package com.jiduauto.sps.order.server.mq.consumer;

import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.StockOperationType;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.dto.StockPutInResultMessage;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;

/**
 * @author panjian
 */
@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_ORDER_STOCK_PUT_IN_RESULT,
        topic = BaseConstants.RocketMqTopic.STOCK_PUT_IN_RESULT,
        consumeThreadMax = 10)
public class StockPutInResultConsumer implements RocketMQListener<MessageExt> {
    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private IStoreTransferOrderService storeTransferOrderService;


    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("StockPutInResultConsumer#onMessage messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
        String tag = message.getTags();
        //旧件索赔回运
        if (StockOperationType.SP18.getOperationType().equals(tag) ||
                StockOperationType.SP19.getOperationType().equals(tag)) {
            InAndOutStockRequest msg = JSON.parseObject(body, InAndOutStockRequest.class);
            warehouseDistributeOrderService.updateRealInQty(msg);
            //商城入库
        }else if (StockOperationType.isWDOPutIn(tag)) {
            InAndOutStockRequest msg = JSON.parseObject(body, InAndOutStockRequest.class);
            StockPutInResultMessage resultMessage = new StockPutInResultMessage();
            resultMessage.setBizType(msg.getBizType());
            resultMessage.setStockParams(msg.getParams());
            resultMessage.setTradeNo(msg.getTradeNo());
            resultMessage.setBusinessType(msg.getBusinessType());
            warehouseDistributeOrderService.updateRealInQty(resultMessage);
        }
        //门店调拨入库
        if (StockOperationType.isStockTransferPutIn(tag)){
            com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest request = JSONUtil.toBean(body, com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest.class);
            storeTransferOrderService.updateTransferInQty(request);

        }

    }

}
