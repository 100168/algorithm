package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.mapper.SaleOrderInvoiceRelationMapper;
import com.jiduauto.sps.order.server.service.ISaleOrderInvoiceRelationService;
import com.jiduauto.sps.order.server.service.ISapInvoiceInfoService;
import com.jiduauto.sps.sdk.enums.BizTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderInvoiceRelationPo;
import com.jiduauto.sps.sdk.pojo.po.SapInvoiceInfoPo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p>
 * 销售订单发票关联表 服务实现类
 * </p>
 *
 * @author generate
 * @since 2024-03-25
 */
@Service
public class SaleOrderInvoiceRelationServiceImpl extends ServiceImpl<SaleOrderInvoiceRelationMapper, SaleOrderInvoiceRelationPo> implements ISaleOrderInvoiceRelationService {

    @Resource
    private ISapInvoiceInfoService sapInvoiceInfoService;

    /**
     * 获取销售订单对应发票信息
     * key 销售订单  value 该销售订单所有的发票信息
     *
     * @param saleOrderNos
     */
    @Override
    public Map<String, List<SapInvoiceInfoPo>> mapSapInvoiceInfoPoList(List<String> saleOrderNos) {
        List<SaleOrderInvoiceRelationPo> list = list(Wrappers.lambdaQuery(SaleOrderInvoiceRelationPo.class)
                .eq(SaleOrderInvoiceRelationPo::getBizType, BizTypeEnum.SP.getBizType())
                .in(SaleOrderInvoiceRelationPo::getSaleOrderNo, saleOrderNos)
        );

        if (CollUtil.isEmpty(list)) {
            return new HashMap<>();
        }

        List<SapInvoiceInfoPo> invoiceInfoList = sapInvoiceInfoService.list(Wrappers.lambdaQuery(SapInvoiceInfoPo.class)
                .in(SapInvoiceInfoPo::getInvoiceNo, list.stream().map(SaleOrderInvoiceRelationPo::getInvoiceNo).collect(Collectors.toList()))
        );

        if (CollUtil.isEmpty(invoiceInfoList)) {
            return new HashMap<>();
        }
        Map<String, SapInvoiceInfoPo> collect = invoiceInfoList.stream().collect(Collectors.toMap(SapInvoiceInfoPo::getInvoiceNo, Function.identity(), (p, n) -> n));
        Map<String, List<SapInvoiceInfoPo>> retMap = new HashMap<>();
        for (SaleOrderInvoiceRelationPo po : list) {
            if (retMap.containsKey(po.getSaleOrderNo())) {
                retMap.get(po.getSaleOrderNo()).add(collect.get(po.getInvoiceNo()));
            } else {
                List<SapInvoiceInfoPo> temp = new ArrayList<>();
                temp.add(collect.get(po.getInvoiceNo()));
                retMap.put(po.getSaleOrderNo(), temp);
            }
        }
        return retMap;
    }

}
