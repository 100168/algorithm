package com.jiduauto.sps.order.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeOrderItemExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.NumberNoReq;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.WarehouseDistributeOrderPageSearchReq;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeItemService;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeOrderItemDto;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import com.jiduauto.sps.sdk.utils.ExcelUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 仓配订单零件信息 前端控制器
 *
 * @author generate
 * @since 2023-07-12
 */
@RestController
@RequestMapping("/warehouseDistributeItem")
public class WarehouseDistributeItemController {
    @Autowired
    private IWarehouseDistributeItemService warehouseDistributeItemService;

    /**
     * 仓配基本信息分页查询
     *
     * @author O_chaopeng.huang
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<WarehouseDistributeOrderItemDto>> pageSearch(@RequestBody @Valid BasePageParam<NumberNoReq> req) {
        return warehouseDistributeItemService.pageSearch(req);
    }

    /**
     * 查询所有明细数据
     *
     * @author
     */
    @PostMapping("/listAll")
    @ResponseBody
    public BaseResult<List<WarehouseDistributeOrderItemDto>> listAll(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(warehouseDistributeItemService.listAll(req));
    }

    /**
     * 仓配订单明细导出
     **/
    @RequestMapping("/export")
    public void export(HttpServletResponse response, @RequestBody BasePageParam<WarehouseDistributeOrderPageSearchReq> req) {
        try {
            ExcelUtils.exportXlsxResponse(response, "仓配订单明细信息");
            EasyExcel.write(response.getOutputStream(), WarehouseDistributeOrderItemExportDto.class).sheet("仓配明细信息").doWrite(warehouseDistributeItemService.getExportDtoList(req));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }
}
