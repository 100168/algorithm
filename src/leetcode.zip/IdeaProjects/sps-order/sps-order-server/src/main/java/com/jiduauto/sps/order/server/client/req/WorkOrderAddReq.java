package com.jiduauto.sps.order.server.client.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class WorkOrderAddReq {

    /**
     * 用户唯一标识（例：xiaokun.liu）
     */
    private String userName;

    /**
     * 表单模板id，传特定值
     */
    private Integer formTemplateId;
    /**
     * 外部系统业务编号，建议唯一
     */
    private String extBizNo;

    /**
     * 表单动态字段
     */
    private Object formContent;

    /**
     * 流程变量Map,Key为流程变量名,Value为流程变量值
     */
    private Map<String, Object> variables;
}
