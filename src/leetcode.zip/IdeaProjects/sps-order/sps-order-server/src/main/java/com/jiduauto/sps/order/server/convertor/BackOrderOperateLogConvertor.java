package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.dto.BackOrderOperateLogDto;
import com.jiduauto.sps.sdk.pojo.po.BackOrderOperateLogPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface BackOrderOperateLogConvertor {

    /**
     * toDto
     * @param boOperateLogPo
     * @return dto*/
    @Mapping(target = "newValue", expression = "java(com.jiduauto.sps.sdk.enums.BackOrderStatusEnum.getDesc(boOperateLogPo.getNewValue()))")
    BackOrderOperateLogDto toDto(BackOrderOperateLogPo boOperateLogPo);
    /**
     * toDto
     * @param boOperateLogPoList
     * @return dto*/
    List<BackOrderOperateLogDto> toDtoList(List<BackOrderOperateLogPo> boOperateLogPoList);

}
