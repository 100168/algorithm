package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.PurchaseOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderCoStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderOperateLogDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderDetailSearchReq;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderOperateLogPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

/**
 * <p>
 * 采购订单操作记录 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface IPurchaseOrderOperateLogService extends IService<PurchaseOrderOperateLogPo> {

    /**操作状态跟踪查询
     * @param pageSearchReq
     * @return  */
    BasePageData<PurchaseOrderOperateLogDto> pageSearch(BasePageParam<PurchaseOrderDetailSearchReq> pageSearchReq);

    /**
     * 保存状态变更记录
     *
     * @param changeDto
     */
    void saveStatusChangeLog(PurchaseOrderStatusChangeDto changeDto);

    /**
     * 保存状态变更记录
     *
     * @param changeDto
     */
    void saveStatusChangeLog(PurchaseOrderCoStatusChangeDto changeDto);
}
