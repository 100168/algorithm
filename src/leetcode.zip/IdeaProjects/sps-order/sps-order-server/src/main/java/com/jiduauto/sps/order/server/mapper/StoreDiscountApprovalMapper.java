package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalPo;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 门店折扣审批表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
public interface StoreDiscountApprovalMapper extends BaseMapper<StoreDiscountApprovalPo> {

    int enableTempRecord(@Param("id") Long id, @Param("bizType") String bizType);

    StoreDiscountApprovalPo getById(@Param("id") Long id, @Param("bizType") String bizType);

    int updateDetailQty(@Param("id") Long id, @Param("detailQty") Integer detailQty, @Param("updateUser") String updateUser);

    int updateAttachmentQty(@Param("id") Long id, @Param("attachmentQty") Integer attachmentQty, @Param("updateUser") String updateUser);
}
