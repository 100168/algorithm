package com.jiduauto.sps.order.server.client.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * @ClassName AddressResp
 * @AuThor O_chaopeng.huang
 * @Date 2023/5/6 16:05
 * @Version 5.0
 */
@Data
public class IndirectTokenResp {
    //token
    @JsonProperty("access_token")
    private String access_token;
    //类型
    @JsonProperty("token_type")
    private String token_type;

    //
    @JsonProperty("expires_in")
    private String expires_in;

    private String scope;

    private String error;

    private String error_description;

    public static IndirectTokenResp failedResp(String message) {
        IndirectTokenResp resp = new IndirectTokenResp();
        resp.setError(message);
        return resp;
    }

}
