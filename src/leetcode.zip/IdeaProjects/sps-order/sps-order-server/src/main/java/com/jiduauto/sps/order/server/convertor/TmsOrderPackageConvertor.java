package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPackagePo;
import com.jiduauto.tms.api.pojo.req.SpsOrderPackageItemReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface TmsOrderPackageConvertor {
    @Mapping(target = "packageWidth", source = "packingWidth")
    @Mapping(target = "packageWeight", source = "packingWeight")
    @Mapping(target = "packageVolume", source = "packingVolume")
    @Mapping(target = "packageUnit", source = "packingUnit")
    @Mapping(target = "packageLength", source = "packingLength")
    @Mapping(target = "packageHigh", source = "packingHeight")
    @Mapping(target = "packageCode", source = "packingCode")
    SpsOrderPackageItemReq toReq(WarehouseDistributeItemPackagePo packagePo);

    List<SpsOrderPackageItemReq> toReq(List<WarehouseDistributeItemPackagePo> packagePos);
}
