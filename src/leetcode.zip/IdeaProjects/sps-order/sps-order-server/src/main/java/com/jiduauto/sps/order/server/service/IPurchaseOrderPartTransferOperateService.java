package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.PurchaseOrderStatusChangeDto;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPartTransferOperatePo;

import java.math.BigDecimal;

/**
 * <p>
 * 采购订单部分转单操作表 服务类
 * </p>
 *
 * @author generate
 * @since 2023-12-15
 */
public interface IPurchaseOrderPartTransferOperateService extends IService<PurchaseOrderPartTransferOperatePo> {


    /**
     * 采购订单部分转单操作表 新增
     * @param turnType 转单类型    !!!!  该字段目前无作用,保留扩展性, 只为 SO
     * SO 模式, 根据转单数量, 正常转 so, 库存不足的时候转BO  目前只有 SO 模式,
     * BO 模式, 无视库存数量, 全部转单成 BO
     */
    PurchaseOrderPartTransferOperatePo saveNewPartTransferOperate(BigDecimal qty, Long prDetailId, String turnType);

    /**
     * 更新转单状态
     */
    void updateState(PurchaseOrderStatusChangeDto changeDto);
}
