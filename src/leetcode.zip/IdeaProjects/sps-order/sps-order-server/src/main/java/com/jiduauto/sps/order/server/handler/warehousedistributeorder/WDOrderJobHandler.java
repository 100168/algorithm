package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

public interface WDOrderJobHandler {
    void process(WarehouseDistributeOrderAllPo WarehouseDistributeOrderAllPo);
}
