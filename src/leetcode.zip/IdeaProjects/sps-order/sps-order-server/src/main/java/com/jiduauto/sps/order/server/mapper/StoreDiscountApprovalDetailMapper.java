package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.order.server.pojo.param.StoreDiscountApprovalDetailQueryParam;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalDetailPo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 门店折扣审批明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
public interface StoreDiscountApprovalDetailMapper extends BaseMapper<StoreDiscountApprovalDetailPo> {

    int deleteById(@Param("id") Long id);

    int deleteByApprovalId(@Param("approvalId") Long approvalId);

    List<StoreDiscountApprovalDetailPo> listApprovalDetailPo(@Param("queryParam") StoreDiscountApprovalDetailQueryParam queryParam);
}
