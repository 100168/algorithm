package com.jiduauto.sps.order.server.convertor;


import cn.hutool.core.util.BooleanUtil;
import com.google.common.collect.Lists;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.WarehouseDistributeOrderAllPo;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.client.req.ApplyOrderToEsReq;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.enums.EsMaterialSortEnum;
import com.jiduauto.sps.sdk.pojo.po.*;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class ApplyOrderToEsReqConvertor {


    @Resource
    private TransferToEsConvertor transferToEsConvertor;

    @Resource
    private BaseDataQuery baseDataQuery;


    public ApplyOrderToEsReq applyOrderToEsReq(WarehouseDistributeOrderAllPo allPo) {

        ApplyOrderToEsReq req = new ApplyOrderToEsReq();

        WarehouseDistributeLogisticPo logisticPo = allPo.getWarehouseDistributeLogisticPo();
        WarehouseDistributeOrderPo orderPo = allPo.getWarehouseDistributeOrderPo();
        WarehouseDistributeAttachPo attachPo = allPo.getWarehouseDistributeAttachPo();


        List<WarehouseDistributeItemPo> items = allPo.getItems();
        List<WarehouseDistributeItemAttachPo> itemAttaches = allPo.getItemAttaches();

        req.setApplyer(attachPo.getApplier());
        req.setApplyCompany(attachPo.getApplyCompany());
        req.setApplyContact(attachPo.getApplierContact());
        req.setApplyDate(attachPo.getApplyDate());
        req.setApplyPurpose(attachPo.getApplyAim());
        req.setNeedCompany(attachPo.getBeAppliedCompany());
        req.setApplyType(logisticPo.getShippingMethod());
        req.setOrderType(orderPo.getOrderType());
        req.setReceiver(logisticPo.getReceiver());
        req.setReceiverContact(logisticPo.getReceiverContact());
        req.setReceiverAddress(logisticPo.getReceiveProvinceName() + logisticPo.getReceiveCityName() + logisticPo.getDeliverDistrictName() + logisticPo.getReceiveAddress());
        req.setWorkOrderNo(orderPo.getOrderNo());
        Map<String, String> purposeMap = baseDataQuery.getCodeAndNameMap(DictEnum.ApplyPurpose.getDictCode());
        Map<String, String> mapCompanyPo = baseDataQuery.mapCompanyPo(orderPo.getBizType(), Lists.newArrayList(req.getApplyCompany(), req.getNeedCompany()));
        req.setApplyCompany(mapCompanyPo.get(req.getApplyCompany()));
        req.setApplyPurpose(purposeMap.get(req.getApplyPurpose()));
        req.setNeedCompany(mapCompanyPo.get(req.getNeedCompany()));
        req.setApplySum(items.stream().map(WarehouseDistributeItemPo::getQty).reduce(BigDecimal.ZERO,BigDecimal::add).intValue());
        buildApplyToEsReqItems(items, itemAttaches, req, orderPo.getBizType(),logisticPo);
        return req;
    }

    private void buildApplyToEsReqItems(List<WarehouseDistributeItemPo> items, List<WarehouseDistributeItemAttachPo> itemAttaches, ApplyOrderToEsReq req, String bizType,WarehouseDistributeLogisticPo logisticPo) {
        List<String> materialCodes = items.stream().map(WarehouseDistributeItemPo::getMaterialCode).collect(Collectors.toList());
        Map<String, MaterialPo> poMap = baseDataQuery.mapMaterialPo(bizType, materialCodes);
        Map<String, String> applySake = baseDataQuery.getCodeAndNameMap(DictEnum.ApplySake.getDictCode());
        List<ApplyOrderToEsReq.ApplyOrderToEsReqItem> reqItems = new ArrayList<>();
        Map<String, WarehouseDistributeItemAttachPo> attachPoMap = itemAttaches.stream().collect(Collectors.toMap(WarehouseDistributeItemAttachPo::getMaterialLineNo, Function.identity()));
        for (WarehouseDistributeItemPo item : items) {
            ApplyOrderToEsReq.ApplyOrderToEsReqItem applyItemReq = transferToEsConvertor.toApplyItemReq(item);
            MaterialPo materialPo = poMap.get(item.getMaterialCode());
            applyItemReq.setWarehouseCode(logisticPo.getDeliverWarehouseCode());
            applyItemReq.setMaterialName(materialPo.getMaterialName());
            if (BooleanUtil.toBoolean(materialPo.getAccurateTrace())) {
                applyItemReq.setTraceStatus("1");
            } else {
                applyItemReq.setTraceStatus("2");
            }
            applyItemReq.setMaterialSort(EsMaterialSortEnum.getEsCode(item.getMaterialSort()));
            WarehouseDistributeItemAttachPo itemAttachPo = attachPoMap.get(item.getMaterialLineNo());
            if (itemAttachPo != null) {
                applyItemReq.setIsApply(String.valueOf(itemAttachPo.getPlanApplyFlag() ? 1 : 0));
                applyItemReq.setCostCenter(itemAttachPo.getCostCenter());
                applyItemReq.setWbs(itemAttachPo.getWbsCode());
                applyItemReq.setApplySake(applySake.get(itemAttachPo.getApplyPurpose()));
            }
            reqItems.add(applyItemReq);
        }
        req.setItemReqList(reqItems);
    }
}
