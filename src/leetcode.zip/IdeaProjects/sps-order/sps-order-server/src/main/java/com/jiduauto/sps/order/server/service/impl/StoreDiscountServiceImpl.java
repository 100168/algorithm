package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.mapper.StoreDiscountMapper;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountDto;
import com.jiduauto.sps.order.server.pojo.fileexport.StoreDiscountExportDto;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalDetailPo;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountPo;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreDiscountListReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountPageReq;
import com.jiduauto.sps.order.server.service.IStoreDiscountService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.consts.BaseConstants.ImportExport.PAGE_START_AT;

/**
 * <p>
 * 门店折扣表 服务实现类
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
@Service
public class StoreDiscountServiceImpl extends ServiceImpl<StoreDiscountMapper, StoreDiscountPo> implements IStoreDiscountService {

    @Value("${MAX_SIZE_10000:10000}")
    private Integer maxSize;


    @Resource
    private StoreDiscountMapper storeDiscountMapper;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Override
    public void insertOrUpdate(List<StoreDiscountApprovalDetailPo> detailPoList) {
        if (CollUtil.isEmpty(detailPoList)) {
            return;
        }
        detailPoList.stream().map(item -> {
            StoreDiscountPo discountPo = new StoreDiscountPo();
            BeanUtils.copyProperties(item, discountPo, "id", "delUniqueKey", "isDel", "createTime", "createUser", "updateTime", "updateUser");
            discountPo.setUpdateTime(LocalDateTime.now());
            return discountPo;
        }).forEach(item -> {
            StoreDiscountPo discountPo = getStoreDiscountPo(item);
            if (Objects.nonNull(discountPo)) {
                updateStoreDiscountPo(item);
            } else {
                try {
                    save(item);
                } catch (DuplicateKeyException e) {
                    updateStoreDiscountPo(item);
                }
            }
        });
    }

    @Override
    public BasePageData<StoreDiscountDto> pageSearch(BasePageParam<StoreDiscountPageReq> pageParam) {
        pageParam.getParam().setCurDate(LocalDateTime.now());

        IPage<StoreDiscountDto> discountDtoIPage = storeDiscountMapper.pageSearch(new Page<>(pageParam.getPage(), pageParam.getSize()), pageParam.getParam());
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(pageParam.getParam().getBizType(), discountDtoIPage.getRecords().stream()
                .map(StoreDiscountDto::getStoreCode).distinct().collect(Collectors.toList()), false);
        for (StoreDiscountDto record : discountDtoIPage.getRecords()) {
            record.setStoreName(storePoMap.getOrDefault(record.getStoreCode(), new StorePo()).getStoreName());
        }
        return new BasePageData<>(discountDtoIPage);
    }

    @Override
    public List<StoreDiscountExportDto> export(BasePageParam<StoreDiscountPageReq> pageParam) {
        List<StoreDiscountDto> cur;
        List<StoreDiscountDto> all = new ArrayList<>();
        pageParam.setSize(2000);
        //限制导出最大1万条
        int count = PAGE_START_AT;
        while (all.size() < maxSize && !(cur = pageSearch(pageParam).getRecords()).isEmpty()) {
            pageParam.setPage(++count);
            all.addAll(cur);
        }
        if (CollUtil.isEmpty(all)) {
            return new ArrayList<>();
        }
        return convertToExport(all);
    }

    /**
     * 查询有效门店折扣
     */
    @Override
    public List<StoreDiscountDto> listEffectiveDiscount(InternalStoreDiscountListReq req) {
        return storeDiscountMapper.listEffectiveDiscount(req, req.getDiscountDate().atTime(LocalTime.MIN));
    }

    private List<StoreDiscountExportDto> convertToExport(List<StoreDiscountDto> all) {
        return all.stream().map(item -> {
            StoreDiscountExportDto exportDto = new StoreDiscountExportDto();
            BeanUtils.copyProperties(item, exportDto);
            exportDto.setEffectiveStartDate(item.getEffectiveStartTime());
            return exportDto;
        }).collect(Collectors.toList());
    }

    private StoreDiscountPo getStoreDiscountPo(StoreDiscountPo discountPo) {
        return getOne(Wrappers.lambdaQuery(StoreDiscountPo.class)
                .eq(StoreDiscountPo::getBizType, discountPo.getBizType())
                .eq(StoreDiscountPo::getMaterialCode, discountPo.getMaterialCode())
                .eq(StoreDiscountPo::getStoreCode, discountPo.getStoreCode())
                .eq(StoreDiscountPo::getOrderType, discountPo.getOrderType())
                .eq(StoreDiscountPo::getEffectiveStartTime, discountPo.getEffectiveStartTime()));
    }

    private void updateStoreDiscountPo(StoreDiscountPo discountPo) {
        update(discountPo, Wrappers.lambdaQuery(StoreDiscountPo.class)
                .eq(StoreDiscountPo::getBizType, discountPo.getBizType())
                .eq(StoreDiscountPo::getMaterialCode, discountPo.getMaterialCode())
                .eq(StoreDiscountPo::getStoreCode, discountPo.getStoreCode())
                .eq(StoreDiscountPo::getOrderType, discountPo.getOrderType())
                .eq(StoreDiscountPo::getEffectiveStartTime, discountPo.getEffectiveStartTime()));
    }
}
