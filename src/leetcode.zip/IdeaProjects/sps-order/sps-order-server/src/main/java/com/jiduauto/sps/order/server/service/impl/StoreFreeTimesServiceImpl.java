package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.enums.LogKey;
import com.jiduauto.sps.order.server.enums.StoreFreeTimesModifyColum;
import com.jiduauto.sps.order.server.enums.StoreTransferOrderDetailModifyColum;
import com.jiduauto.sps.order.server.excel.StoreFreeTimesImportHandler;
import com.jiduauto.sps.order.server.mapper.StoreFreeTimesMapper;
import com.jiduauto.sps.order.server.pojo.dto.StoreFreeTimesDto;
import com.jiduauto.sps.order.server.pojo.po.StoreFreeTimesPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreFreeTimesAddAndEditReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreFreeTimesImportReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreFreeTimesPageReq;
import com.jiduauto.sps.order.server.service.ICommonLogService;
import com.jiduauto.sps.order.server.service.IStoreFreeTimesService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.sdk.enums.LogType;
import com.jiduauto.sps.sdk.enums.PurchaseOrderTypeEnum;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.CommonLogDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.sdk.pojo.po.CommonLogPo;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.StringUtils;
import com.jiduauto.sps.sdk.utils.log.CommonFieldLogService;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * <p>
 * 门店免费次数配置 服务实现类
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
@Service
public class StoreFreeTimesServiceImpl extends ServiceImpl<StoreFreeTimesMapper, StoreFreeTimesPo> implements IStoreFreeTimesService {

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private StoreFreeTimesImportHandler storeFreeTimesImportHandler;

    public static final CommonFieldLogService<StoreFreeTimesPo, StoreFreeTimesModifyColum> LOG_SERVICE = new CommonFieldLogService<>();

    @Resource
    private ICommonLogService commonLogService;

    /**
     * 编辑
     */
    @Override
    public void edit(StoreFreeTimesAddAndEditReq req) {
        if (req.getId() == null) {
            throw new BizException("id 不能为空");
        }
        StoreFreeTimesPo po = getById(req.getId());
        StoreFreeTimesPo oldPo = BeanUtil.copyProperties(po, StoreFreeTimesPo.class);
        if (po == null) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        checkAddOrEditReq(req);
        BeanUtil.copyProperties(req, po);
        po.setUpdateTime(LocalDateTime.now());
        po.setUpdateUser(UserUtil.getUserName());
        try {
            updateById(po);
            List<CommonLogPo> commonLogPos = LOG_SERVICE.buildOperateLogs(oldPo, po, StoreFreeTimesModifyColum.class, UserUtil.getUserName());
            if (CollUtil.isNotEmpty(commonLogPos)) {
                commonLogService.saveBatch(commonLogPos);
            }
        } catch (DuplicateKeyException e) {
            //业务类型+门店code+订单类型 主键不重复
            throw new BizException(String.format("门店:[%s] 订单类型:[%s]免费配置已存在", req.getStoreCode(), req.getOrderType()));
        }
    }

    /**
     * 新增
     */
    @Override
    public void add(StoreFreeTimesAddAndEditReq req) {
        checkAddOrEditReq(req);
        StoreFreeTimesPo po = new StoreFreeTimesPo();
        BeanUtil.copyProperties(req, po);
        try {
            save(po);
        } catch (DuplicateKeyException e) {
            //业务类型+门店code+订单类型 主键不重复
            throw new BizException(String.format("门店:[%s] 订单类型:[%s]免费配置已存在", req.getStoreCode(), req.getOrderType()));
        }
    }

    /**
     * 分页查询
     */
    @Override
    public BasePageData<StoreFreeTimesDto> pageSearch(BasePageParam<StoreFreeTimesPageReq> req) {
        StoreFreeTimesPageReq param = req.getParam();
        IPage<StoreFreeTimesPo> page = page(new Page<>(req.getPage(), req.getSize()),
                Wrappers.lambdaQuery(StoreFreeTimesPo.class)
                        .eq(StoreFreeTimesPo::getBizType, param.getBizType())
                        .eq(StrUtil.isNotBlank(param.getOrderType()), StoreFreeTimesPo::getOrderType, param.getOrderType())
                        .eq(StrUtil.isNotBlank(param.getStoreCode()), StoreFreeTimesPo::getStoreCode, param.getStoreCode())
                        .orderByDesc(StoreFreeTimesPo::getId)
        );
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(param.getBizType(),
                page.getRecords().stream().map(StoreFreeTimesPo::getStoreCode).collect(Collectors.toList()));
        BasePageData<StoreFreeTimesDto> pageData = new BasePageData<>(page);
        pageData.setRecords(page.getRecords().stream().map(item -> {
            StoreFreeTimesDto dto = BeanCopierUtil.copy(item, StoreFreeTimesDto.class);
            dto.setStoreName(storePoMap.getOrDefault(item.getStoreCode(), new StorePo()).getStoreName());
            return dto;
        }).collect(Collectors.toList()));
        return pageData;
    }

    /**
     * 检验请求参数
     */
    private void checkAddOrEditReq(StoreFreeTimesAddAndEditReq req) {
        baseDataQuery.getStorePo(req.getBizType(), req.getStoreCode(), true);
        if (!PurchaseOrderTypeEnum.hasValue(req.getOrderType())) {
            throw new BizException("订单类型不正确");
        }
    }

    /**
     * 删除配置
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(IdReq req) {
        StoreFreeTimesPo po = getById(req.getId());
        if (po == null) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        po.setDelUniqueKey(po.getId());
        updateById(po);
        removeById(req.getId());
    }

    /**
     * 详情
     */
    @Override
    public StoreFreeTimesDto detail(IdReq req) {
        StoreFreeTimesPo po = getById(req.getId());
        if (po == null) {
            return null;
        }
        StoreFreeTimesDto dto = BeanCopierUtil.copy(po, StoreFreeTimesDto.class);
        Optional<StorePo> optionalStorePo = baseDataQuery.getStorePo(po.getBizType(), po.getStoreCode());
        optionalStorePo.ifPresent(storePo -> dto.setStoreName(storePo.getStoreName()));
        return dto;
    }

    /**
     * 导入 折扣配置
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ImportResultResp importExcel(String bizType, MultipartFile file) {

        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        ImportReturnDataInfo<ExtendExportDto<StoreFreeTimesImportReq>> resp = storeFreeTimesImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return resultResp;
    }

    /**
     * 日志查询
     */
    @Override
    public BasePageData<CommonLogDto> logPageSearch(BasePageParam<IdReq> req) {
        IPage<CommonLogPo> page = commonLogService.page(new Page<>(req.getPage(), req.getSize()),
                Wrappers.lambdaQuery(CommonLogPo.class)
                        .eq(CommonLogPo::getBizType, req.getParam().getBizType())
                        .eq(CommonLogPo::getLogType, LogType.FIELD.getType())
                        .eq(CommonLogPo::getOrderNo, req.getParam().getId())
                        .in(CommonLogPo::getLogKey, LogKey.store_free_times.getValue())
                        .orderByDesc(CommonLogPo::getId)
        );
        List<CommonLogPo> records = page.getRecords();
        BasePageData<CommonLogDto> pageData = new BasePageData<>(page);
        pageData.setRecords(records.stream().map(item -> {
            CommonLogDto dto = BeanCopierUtil.copy(item, CommonLogDto.class);
            String byDesc = StoreFreeTimesModifyColum.getByDesc(item.getModifyColumn());
            dto.setModifyColumn(StringUtils.defaultIfNull(
                    byDesc == null ? StoreTransferOrderDetailModifyColum.getByDesc(
                            item.getModifyColumn()) : byDesc, item.getModifyColumn()));
            return dto;
        }).collect(Collectors.toList()));
        return pageData;
    }
}
