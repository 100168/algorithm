package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.StandardRecommendationListDto;
import com.jiduauto.sps.order.server.pojo.po.StandardRecommendationListPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListEditReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListPageReq;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.req.IdBatchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 标准推荐清单 服务类
 */
public interface IStandardRecommendationListService extends IService<StandardRecommendationListPo> {

    /**
     * 分页查询
     */
    BasePageData<StandardRecommendationListDto> pageSearch(BasePageParam<StandardRecommendationListPageReq> pageParam);

    /**
     * 删除
     */
    void delete(IdBatchReq request);

    /**
     * 清空
     */
    void clear(StandardRecommendationListPageReq request);

    /**
     * 新增
     */
    void add(StandardRecommendationListAddReq req);

    /**
     * 编辑
     */
    void edit(StandardRecommendationListEditReq req);

    /**
     * 导入
     */
    ImportResultResp importExcel(String bizType, MultipartFile file);

    /**
     * 保存或更新
     */
    void insertOrUpdate(List<StandardRecommendationListPo> list);

    /**
     * 检查零件和门店是否存在
     */
    void checkMaterialAndStore(String bizType, String storeCode, String materialCode);
}
