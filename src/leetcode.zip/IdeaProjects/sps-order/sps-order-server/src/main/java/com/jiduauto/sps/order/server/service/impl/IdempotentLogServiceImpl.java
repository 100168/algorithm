package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.aspect.IdempotentAspect;
import com.jiduauto.sps.order.server.mapper.IdempotentLogMapper;
import com.jiduauto.sps.order.server.pojo.po.IdempotentLogPo;
import com.jiduauto.sps.order.server.service.IIdempotentLogService;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 接口幂等记录表 服务实现类
 * </p>
 */
@Service
@Slf4j
public class IdempotentLogServiceImpl extends ServiceImpl<IdempotentLogMapper, IdempotentLogPo> implements IIdempotentLogService {

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Object proceedAndSaveIdLog(ProceedingJoinPoint pjp, String idNo) throws Throwable {
        try {
            saveLog();
        } catch (DuplicateKeyException e) {
            //由数据库唯一索引兜底
            log.warn("幂等号[{}]重复提交", idNo);
            return BaseResult.OK();
        }
        return pjp.proceed();
    }


    @Override
    public boolean isExist(String idNo, String requestURI) {
        requestURI = requestURI.length() > 200 ? requestURI.substring(0, 200) : requestURI;
        idNo = idNo.length() > 32 ? idNo.substring(0, 32) : idNo;

        return count(Wrappers.lambdaQuery(IdempotentLogPo.class)
                .eq(IdempotentLogPo::getIdempotentNo, idNo)
                .eq(IdempotentLogPo::getApiUrl, requestURI)) > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.MANDATORY)
    public void saveLog() {
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (servletRequestAttributes == null) {
            // Impossible ignore
            throw new BizException("无法获取请求上下文");
        }
        HttpServletRequest request = servletRequestAttributes.getRequest();
        String idNo = request.getHeader(IdempotentAspect.IDEMPOTENT_NO);

        //没有强制要求传 幂等号, 没有传则忽略, 让客户端自行抉择
        if (StrUtil.isBlank(idNo)) {
            return;
        }
        String requestURI = request.getRequestURI();
        //防止过长
        requestURI = requestURI.length() > 200 ? requestURI.substring(0, 200) : requestURI;
        idNo = idNo.length() > 32 ? idNo.substring(0, 32) : idNo;
        save(new IdempotentLogPo(idNo, requestURI));
    }
}
