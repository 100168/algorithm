package com.jiduauto.sps.order.server.service;

import com.jiduauto.sps.order.server.pojo.dto.FileDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountApprovalDetailDto;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalDetailPo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailEditReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailPageSearchReq;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.ItemIdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * 门店折扣审批明细 服务类
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
public interface IStoreDiscountApprovalDetailService extends IService<StoreDiscountApprovalDetailPo> {

    FileDto generateExcel(IdReq request);
    /**
     * 新增明细
     */
    void add(StoreDiscountApprovalDetailAddReq request);
    /**
     * 清空
     */
    void deleteAll(IdReq approvalIdReq);
    /**
     * 删除明细
     */
    void delete(ItemIdReq request);
    /**
     * 分页查询明细
     */
    BasePageData<StoreDiscountApprovalDetailDto> pageSearch(BasePageParam<StoreDiscountApprovalDetailPageSearchReq> pageSearchReq);
    /**
     * 导入明细
     */
    ImportResultResp importDetail(String bizType, Long approvalId, MultipartFile file);

    /**
     * 编辑
     */
    void edit(StoreDiscountApprovalDetailEditReq request);
}
