package com.jiduauto.sps.order.server.client;

import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.order.server.client.resp.TisReplacePartsResp;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;


@FeignClient(name = "cn.pe.bpp.tis-search.mixed", contextId = "tisClient", fallbackFactory = TisClient.TisClientFallbackFactory.class)
public interface TisClient {

    /**
     * 查询tis替换件接口
     * 批量零件售后件号，一次性最多查询100个，以逗号分隔
     */
    @GetMapping("/part/batchReplaceParts/search")
    ResultResp<List<TisReplacePartsResp>> batchReplaceParts(@RequestParam("salePartNums") String salePartNums);

    @Slf4j
    @Component
    class TisClientFallbackFactory implements FallbackFactory<TisClient> {

        @Override
        public TisClient create(Throwable throwable) {
            return asnAddSyncReq -> null;
        }
    }

}
