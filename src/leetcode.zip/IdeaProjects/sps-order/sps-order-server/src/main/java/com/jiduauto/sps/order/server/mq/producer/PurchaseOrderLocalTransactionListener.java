package com.jiduauto.sps.order.server.mq.producer;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.mapper.PurchaseOrderMapper;
import com.jiduauto.sps.order.server.pojo.PurchaseOrderStatusChangeDto;
import com.jiduauto.sps.order.server.service.IPurchaseOrderOperateLogService;
import com.jiduauto.sps.order.server.service.IPurchaseOrderPartTransferOperateService;
import com.jiduauto.sps.order.server.service.IPurchaseOrderService;
import com.jiduauto.sps.sdk.enums.PoPartTurnStatus;
import com.jiduauto.sps.sdk.enums.PurchaseOrderStatusEnum;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPartTransferOperatePo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.annotation.RocketMQTransactionListener;
import org.apache.rocketmq.spring.core.RocketMQLocalTransactionListener;
import org.apache.rocketmq.spring.core.RocketMQLocalTransactionState;
import org.springframework.messaging.Message;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Objects;


@Slf4j
@RocketMQTransactionListener(rocketMQTemplateBeanName = "rocketMQTemplate")
public class PurchaseOrderLocalTransactionListener implements RocketMQLocalTransactionListener {

    @Resource
    private PurchaseOrderMapper purchaseOrderMapper;

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @Resource
    private IPurchaseOrderOperateLogService purchaseOrderOperateLogService;

    @Resource
    private IPurchaseOrderPartTransferOperateService purchaseOrderPartTransferOperateService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RocketMQLocalTransactionState executeLocalTransaction(Message msg, Object arg) {
        try {
            PurchaseOrderStatusChangeDto changeDto = (PurchaseOrderStatusChangeDto) arg;

            if (PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL.equals(changeDto.getNewOrderStatus())) {
                purchaseOrderService.doTransferOrder(changeDto.getTransferContextDto());
            }

            purchaseOrderMapper.update(null, Wrappers.lambdaUpdate(PurchaseOrderPo.class)
                    .set(PurchaseOrderPo::getPurchaseOrderStatus, changeDto.getNewOrderStatus().getCode())
                    .set(PurchaseOrderPo::getRemark, StringUtils.defaultIfNull(changeDto.getRemark()))
                    .set(PurchaseOrderPo::getUpdateUser, StringUtils.defaultIfNull(changeDto.getOperateUser()))
                    .eq(PurchaseOrderPo::getId, changeDto.getPurchaseOrderPo().getId()));
            purchaseOrderOperateLogService.saveStatusChangeLog(changeDto);
            purchaseOrderPartTransferOperateService.updateState(changeDto);
            log.info("PurchaseOrderLocalTransactionListener#checkLocalTransaction commit, message: {}", JsonUtil.ObjectToJson(msg));
        } catch (Exception exception) {
            log.error(String.format("PurchaseOrderLocalTransactionListener#checkLocalTransaction error, message: %s", JsonUtil.ObjectToJson(msg)), exception);
            throw exception;
        }
        return RocketMQLocalTransactionState.COMMIT;
    }

    @Override
    public RocketMQLocalTransactionState checkLocalTransaction(Message msg) {
        String purchaseOrderNo = msg.getHeaders().get("purchaseOrderNo", String.class);
        String purchaseOrderNewStatus = msg.getHeaders().get("purchaseOrderNewStatus", String.class);
        Boolean isControlTurnOrder = msg.getHeaders().get("isControlTurnOrder", Boolean.class);
        Long poDetailId = msg.getHeaders().get("poPartTransferOperateId", Long.class);

        PurchaseOrderPo purchaseOrderPo = purchaseOrderMapper.selectOne(Wrappers.lambdaQuery(PurchaseOrderPo.class).eq(PurchaseOrderPo::getPurchaseOrderNo, purchaseOrderNo));
        if (Boolean.TRUE.equals(isControlTurnOrder)) {

            PurchaseOrderPartTransferOperatePo one = purchaseOrderPartTransferOperateService.getById(poDetailId);
            if (Objects.nonNull(one) && Objects.equals(one.getTurnStatus(), PoPartTurnStatus.TRANSFER_SUCCESSFUL.getCode())) {
                //操作成功
                return RocketMQLocalTransactionState.COMMIT;
            } else {
                //操作失败
                return RocketMQLocalTransactionState.ROLLBACK;
            }
        }

        if (Objects.nonNull(purchaseOrderPo) && Objects.equals(purchaseOrderNewStatus, purchaseOrderPo.getPurchaseOrderStatus())) {
            log.info("PurchaseOrderLocalTransactionListener#checkLocalTransaction commit, message: {}", JsonUtil.ObjectToJson(msg));
            return RocketMQLocalTransactionState.COMMIT;
        } else {
            log.info("PurchaseOrderLocalTransactionListener#checkLocalTransaction rollback, message: {}", JsonUtil.ObjectToJson(msg));
            return RocketMQLocalTransactionState.ROLLBACK;
        }
    }
}
