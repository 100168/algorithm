package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountApprovalDetailDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailEditReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailPageSearchReq;
import com.jiduauto.sps.order.server.service.IStoreDiscountApprovalDetailService;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.ItemIdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * <p>
 * 门店折扣审批明细 前端控制器
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
@RestController
@RequestMapping("/storeDiscountApproval/detail")
public class StoreDiscountApprovalDetailController {

    @Resource
    private IStoreDiscountApprovalDetailService storeDiscountApprovalDetailService;

    /**
     * 新增
     */
    @PostMapping("/add")
    public BaseResult<String> add(@RequestBody @Valid StoreDiscountApprovalDetailAddReq request) {
        storeDiscountApprovalDetailService.add(request);
        return BaseResult.OK();
    }

    /**
     * 编辑
     */
    @PostMapping("/edit")
    public BaseResult<String> edit(@RequestBody @Valid StoreDiscountApprovalDetailEditReq request) {
        storeDiscountApprovalDetailService.edit(request);
        return BaseResult.OK();
    }

    /**
     * 删除
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid ItemIdReq request) {
        storeDiscountApprovalDetailService.delete(request);
        return BaseResult.OK();
    }

    /**
     * 清空
     */
    @PostMapping("/deleteAll")
    public BaseResult<String> deleteAll(@RequestBody @Valid IdReq approvalIdReq) {
        storeDiscountApprovalDetailService.deleteAll(approvalIdReq);
        return BaseResult.OK();
    }

    /**
     * 条件查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StoreDiscountApprovalDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<StoreDiscountApprovalDetailPageSearchReq> pageSearchReq) {
        return BaseResult.OK(storeDiscountApprovalDetailService.pageSearch(pageSearchReq));
    }

    /**
     * 导入
     */
    @PostMapping("/import")
    public BaseResult<ImportResultResp> importDetail(@RequestHeader("bizType") String bizType,
                                                     @RequestParam("approvalId") Long approvalId,
                                                     @RequestPart("file") MultipartFile file) {
        return BaseResult.OK(storeDiscountApprovalDetailService.importDetail(bizType, approvalId, file));
    }
}
