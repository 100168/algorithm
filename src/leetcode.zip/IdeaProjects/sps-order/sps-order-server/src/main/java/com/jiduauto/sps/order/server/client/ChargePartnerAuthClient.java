package com.jiduauto.sps.order.server.client;

import com.jiduauto.sps.order.server.client.config.ChargePartnerFeignAuthConfig;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.sdk.client.req.*;

import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 能源平台api  需要basic auth 鉴权
 */

@FeignClient(contextId ="esClient" ,name = "cn.pe.vi.charge-portal.mixed",configuration = ChargePartnerFeignAuthConfig.class, fallbackFactory = ChargePartnerAuthClient.ChargePartnerAuthClientFallbackFactory.class)
public interface ChargePartnerAuthClient {



    /**
     * 能源调拨出库指令
     */
    @PostMapping("/v1/inner/supply/createOutboundOrder")
    ResultResp<Object> createTransferOutWorkOrder(@RequestBody TransferOutToEsReq req);

    /**
     * 能源调拨出库指令
     */
    @PostMapping("/v1/inner/supply/createInboundOrder")
    ResultResp<Object> createTransferInWorkOrder(@RequestBody TransferInToEsReq req);

    /**
     * 能源调拨取消
     */
    @PostMapping("/v1/inner/supply/cancelOrder")
    ResultResp<Object> cancelTransferWorkOrder(@RequestBody TransferToEsCancelReq req);


    /**
     * 能源接收领料订单
     * @param
     * @return
     */
    @PostMapping("/v1/inner/apply/workOrderCreate")
    ResultResp<Object> receiveApplyOrder(@RequestBody ApplyOrderToEsReq req);


    /**
     * 能源接收领料订单
     */
    @PostMapping("/v1/inner/apply/workOrderCancel")
    ResultResp<Object> cancel(@RequestBody ApplyOrderToEsCancelReq req);



    @Slf4j
    @Component
    class ChargePartnerAuthClientFallbackFactory implements FallbackFactory <ChargePartnerAuthClient>{

        @Override
        public ChargePartnerAuthClient create(Throwable throwable) {
            return new ChargePartnerAuthClient() {

                @Override
                public ResultResp<Object> createTransferOutWorkOrder(TransferOutToEsReq req) {
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public ResultResp<Object> createTransferInWorkOrder(TransferInToEsReq req) {
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public ResultResp<Object> cancelTransferWorkOrder(TransferToEsCancelReq req) {
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public ResultResp<Object> receiveApplyOrder(ApplyOrderToEsReq req) {
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public ResultResp<Object> cancel(ApplyOrderToEsCancelReq req) {
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }
            };
        }
    }
}
