package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderReq;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeOrderDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;

import java.util.List;


/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface WarehouseDistributeOrderConvertor {

    /**
     * to po
     * @param req req
     * @return WarehouseDistributeOrderPo
     */
    @Mapping(target = "isSpecial", ignore = true)
    @Mapping(target = "isApi", ignore = true)
    @Mapping(target = "actualArrivalTime", ignore = true)
    @Mapping(target = "reason", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "orderStatus", ignore = true)
    @Mapping(target = "orderNo", source = "orderNo")
    @Mapping(target = "logisticNo", ignore = true)
    @Mapping(target = "isDel", expression = "java(false)")
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "orderTime",ignore = true)
    WarehouseDistributeOrderPo toPo(WarehouseDistributeOrderReq req);
    @Mapping(target = "totalWeight", ignore = true)
    @Mapping(target = "totalVolume", ignore = true)
    @Mapping(target = "totalRealOutQty", ignore = true)
    @Mapping(target = "totalRealInQty", ignore = true)
    @Mapping(target = "totalQty", ignore = true)
    @Mapping(target = "totalPackingWeight", ignore = true)
    @Mapping(target = "totalPackingVolume", ignore = true)
    @Mapping(target = "totalPackingQty", ignore = true)
    @Mapping(target = "shippingMethodName", ignore = true)
    @Mapping(target = "receiveWarehouseCode", ignore = true)
    @Mapping(target = "receiveUni", ignore = true)
    @Mapping(target = "orderTypeName", ignore = true)
    @Mapping(target = "orderStatusName", ignore = true)
    @Mapping(target = "logisticTypeName", ignore = true)
    @Mapping(target = "estPickTime", ignore = true)
    @Mapping(target = "estArrivalTime", ignore = true)
    @Mapping(target = "deliverWarehouseCode", ignore = true)
    @Mapping(target = "deliverUni", ignore = true)
    @Mapping(target = "bizTypeName", ignore = true)
    WarehouseDistributeOrderDto toDto(WarehouseDistributeOrderPo po);


    List<WarehouseDistributeOrderDto> toDto(List<WarehouseDistributeOrderPo> pos);
}
