package com.jiduauto.sps.order.server.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeAttachPo;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeAttachDto;

import java.util.List;

/**
 * <p>
 * 仓配订单附属信息 服务类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
public interface IWarehouseDistributeAttachService extends IService<WarehouseDistributeAttachPo> {

    /**
     * 获取附属信息
     * @author O_chaopeng.huang
     * @param  bizType 业务类型 orderNo 仓配订单号
     */
    WarehouseDistributeAttachDto selectWarehouseDistributeAttach(String bizType, String orderNo);

    /**
     * 获取dto*/
    List<WarehouseDistributeAttachDto> getDto(String bizType, List<String> orderNo);
}
