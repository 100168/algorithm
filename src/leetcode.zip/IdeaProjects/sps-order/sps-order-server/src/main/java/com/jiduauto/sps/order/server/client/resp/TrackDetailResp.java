package com.jiduauto.sps.order.server.client.resp;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@NoArgsConstructor
@Data
public class TrackDetailResp {

    /**
     * billList
     */
    private List<BillListDTO> billList;

    /**
     * BillListDTO
     */
    @NoArgsConstructor
    @Data
    public static class BillListDTO {
        /**
         * billNo
         */
        private String billNo;
        /**
         * itemList
         */
        private List<ItemListDTO> itemList;

        /**
         * ItemListDTO
         */
        @NoArgsConstructor
        @Data
        public static class ItemListDTO {
            /**
             * 行为code
             */
            private String actionCode;

            /**
             * 行为描述
             */
            private String actionDescription;

            /**
             * 轨迹状态码
             */
            private String personCode;
            /**
             * 轨迹状态码名称
             */
            private String personName;
            /**
             * 描述
             */
            private String personDes;

            /**
             * 轨迹时间
             */
            private LocalDateTime actionTime;

            /**
             * 当前所在地
             */
            private String address;

            /**
             * 当前所在国家
             */
            private String country;

            /**
             * 当前所在省份
             */
            private String province;

            /**
             * 当前所在城市
             */
            private String city;

            /**
             * 当前所在区县
             */
            private String area;

            /**
             * 承运商
             */
            private String supplier;

            /**
             * 承运商编码
             */
            private String supplierCode;

            /**
             * 预计提货时间
             */
            private LocalDateTime takeGoodsTime;

            /**
             * 预计到达时间
             */
            private LocalDateTime eta;

            /**
             * 车牌号
             */
            private String carNo;

            /**
             * 驾驶员姓名
             */
            private String driverName;

            /**
             * 驾驶员电话
             */
            private String driverPhone;

            /**
             * 经度
             */
            private String lng;

            /**
             * 纬度
             */
            private String lat;

            /**
             * 行驶速度
             */
            private String speed;

            /**
             * 操作人
             */
            private String operatorName;

            /**
             * 操作人电话
             */
            private String operatorPhone;
        }
    }
}
