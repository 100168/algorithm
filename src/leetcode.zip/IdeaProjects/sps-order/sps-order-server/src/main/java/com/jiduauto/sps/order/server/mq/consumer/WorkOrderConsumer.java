package com.jiduauto.sps.order.server.mq.consumer;

import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.service.IStoreDiscountApprovalService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.pojo.dto.WorkOrderCallBackDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.annotation.SelectorType;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * 工单
 */
@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_ORDER_8,
        topic = BaseConstants.RocketMqTopic.WORK_ORDER_CALLBACK,
        selectorType = SelectorType.TAG,
        selectorExpression = "tc-dit-work-order-callback_tag_sps",
        consumeThreadMax = 10)
public class WorkOrderConsumer implements RocketMQListener<MessageExt> {

    @Value("${approval.store-discount.formTemplateId:200}")
    private Integer storeDiscountFormTemplateId;

    @Resource
    private IStoreDiscountApprovalService storeDiscountApprovalService;

    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("WorkOrderConsumer#onMessage messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
        WorkOrderCallBackDto workOrderCallBackDto = JsonUtil.fromJsonStr(body, WorkOrderCallBackDto.class);
        if (Objects.equals(storeDiscountFormTemplateId, workOrderCallBackDto.getFormTemplateId())) {
            storeDiscountApprovalService.workOrderCallBack(workOrderCallBackDto);
        }
    }
}
