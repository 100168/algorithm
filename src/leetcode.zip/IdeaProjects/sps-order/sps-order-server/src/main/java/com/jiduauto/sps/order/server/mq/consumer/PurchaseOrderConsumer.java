package com.jiduauto.sps.order.server.mq.consumer;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderMessageDto;
import com.jiduauto.sps.order.server.service.IPurchaseOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.PurchaseOrderStatusEnum;
import com.jiduauto.sps.sdk.enums.PurchaseOrderTypeEnum;
import com.jiduauto.sps.sdk.enums.TurnPurchaseOrderStatusEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * 采购订单创建成功
 */
@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_3,
        topic = BaseConstants.RocketMqTopic.PURCHASE_ORDER,
        consumeThreadMax = 10)
public class PurchaseOrderConsumer implements RocketMQListener<MessageExt> {

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("PurchaseOrderConsumer#onMessage messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
        PurchaseOrderMessageDto purchaseOrderMessageDto = JsonUtil.toObject(body, PurchaseOrderMessageDto.class);
        if (Objects.equals(message.getTags(), PurchaseOrderStatusEnum.APPROVED.getMsgTag())) {

            if (PurchaseOrderTypeEnum.CO.getValue().equals(purchaseOrderMessageDto.getPurchaseOrderType())) {
                // 如过修改状态为已审核状态及同步sap成功且为定制订单则修改转采购申请状态为待处理
                purchaseOrderService.update(null, Wrappers.lambdaUpdate(PurchaseOrderPo.class)
                        .set(PurchaseOrderPo::getTurnPurchaseOrderStatus, TurnPurchaseOrderStatusEnum.TREAT_HANDLE.getCode())
                        .eq(PurchaseOrderPo::getId, purchaseOrderMessageDto.getId()));
                try {
                    purchaseOrderService.transferPurchaseApply(OperateEnum.AUTO_TRANSFER_ORDER_PLAN, purchaseOrderMessageDto.getId());
                } catch (BizException e) {
                    log.warn("PurchaseOrderConsumer#onMessage transferPurchaseApply error, messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
                }
            } else {
                try {
                    purchaseOrderService.transferOrder(OperateEnum.AUTO_TRANSFER, purchaseOrderMessageDto.getId());
                } catch (BizException e) {
                    log.warn("PurchaseOrderConsumer#onMessage transferOrder error, messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
                }
            }
        } else if (Objects.equals(message.getTags(), PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL.getMsgTag())) {
            purchaseOrderService.transferSuccessSendMessage(purchaseOrderMessageDto);
        }
    }
}
