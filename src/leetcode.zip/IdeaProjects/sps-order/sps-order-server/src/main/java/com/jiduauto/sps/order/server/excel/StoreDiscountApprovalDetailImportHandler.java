package com.jiduauto.sps.order.server.excel;

import com.jiduauto.sps.order.server.mapper.StoreDiscountApprovalMapper;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalDetailPo;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailImportReq;
import com.jiduauto.sps.order.server.service.IStoreDiscountApprovalDetailService;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.handler.ExcelThreadLocalHolder;
import com.jiduauto.sps.sdk.handler.ExtendImportHandler;
import com.jiduauto.sps.sdk.service.impl.BosServiceImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class StoreDiscountApprovalDetailImportHandler extends ExtendImportHandler<StoreDiscountApprovalDetailImportReq> {

    public final static String KEY_MATERIAL_MAP = "KEY_MATERIAL_MAP";
    public final static String KEY_STORE_DISCOUNT_APPROVAL = "KEY_STORE_DISCOUNT_APPROVAL";

    @Resource
    private StoreDiscountApprovalMapper storeDiscountApprovalMapper;

    @Resource
    private IStoreDiscountApprovalDetailService storeDiscountApprovalDetailService;

    public StoreDiscountApprovalDetailImportHandler(List<BatchPreCheck<StoreDiscountApprovalDetailImportReq>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchPreChecks;
        super.eClass = StoreDiscountApprovalDetailImportReq.class;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveData(List<ExtendExportDto<StoreDiscountApprovalDetailImportReq>> extendExportDto) {
        StoreDiscountApprovalPo approvalPo = ExcelThreadLocalHolder.getObject(KEY_STORE_DISCOUNT_APPROVAL, StoreDiscountApprovalPo.class);
        List<StoreDiscountApprovalDetailPo> approvalDetailPos = extendExportDto.stream().map(ExtendExportDto::getT).map(item -> {
            StoreDiscountApprovalDetailPo save = new StoreDiscountApprovalDetailPo();
            BeanUtils.copyProperties(item, save);
            save.setBizType(BizTypeThreadHolder.getBizType());
            save.setApprovalId(approvalPo.getId());
            LocalDateTime effectiveStartTime = LocalDate.parse(item.getEffectiveStartDateStr(), DateTimeFormatter.ofPattern(BaseConstants.DatePattern.NONE_DATE)).atTime(LocalTime.MIN);
            save.setEffectiveStartTime(effectiveStartTime);
            save.setDiscountRate(new BigDecimal(item.getDiscountRate()));
            return save;
        }).collect(Collectors.toList());

        storeDiscountApprovalDetailService.saveBatch(approvalDetailPos);
        storeDiscountApprovalMapper.updateDetailQty(approvalPo.getId(), approvalPo.getDetailQuantity() + approvalDetailPos.size(), UserUtil.getUserName());
    }
}
