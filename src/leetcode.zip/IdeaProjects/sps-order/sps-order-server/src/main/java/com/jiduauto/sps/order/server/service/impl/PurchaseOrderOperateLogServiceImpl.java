package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.mapper.PurchaseOrderOperateLogMapper;
import com.jiduauto.sps.order.server.pojo.PurchaseOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderCoStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderOperateLogDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderDetailSearchReq;
import com.jiduauto.sps.order.server.service.IPurchaseOrderOperateLogService;
import com.jiduauto.sps.sdk.enums.ColumnEnum;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.PurchaseOrderStatusEnum;
import com.jiduauto.sps.sdk.enums.TurnPurchaseOrderStatusEnum;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderOperateLogPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 * 采购订单操作记录 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Service
public class PurchaseOrderOperateLogServiceImpl extends
        ServiceImpl<PurchaseOrderOperateLogMapper, PurchaseOrderOperateLogPo> implements
        IPurchaseOrderOperateLogService {

    @Override
    public BasePageData<PurchaseOrderOperateLogDto> pageSearch(
            BasePageParam<PurchaseOrderDetailSearchReq> pageSearchReq) {
        PurchaseOrderDetailSearchReq param = pageSearchReq.getParam();
        Page<PurchaseOrderOperateLogPo> orderOperateLogPoPage = page(
                new Page<>(pageSearchReq.getPage(), pageSearchReq.getSize()),
                Wrappers.<PurchaseOrderOperateLogPo>lambdaQuery()
                        .eq(PurchaseOrderOperateLogPo::getBizType, param.getBizType())
                        .eq(PurchaseOrderOperateLogPo::getPurchaseOrderNo, param.getPurchaseOrderNo())
                        .orderByDesc(PurchaseOrderOperateLogPo::getId)
        );
        BasePageData<PurchaseOrderOperateLogDto> res = new BasePageData<>(orderOperateLogPoPage);
        res.setRecords(orderOperateLogPoPage.getRecords().stream().map(item -> {
            PurchaseOrderOperateLogDto purchaseOrderOperateLogDto = BeanCopierUtil.copy(item, PurchaseOrderOperateLogDto.class);
            if (ColumnEnum.CO_TRANSFER_STATUS.getDesc().equals(item.getModifyColumn())) {
                purchaseOrderOperateLogDto.setNewValue(TurnPurchaseOrderStatusEnum.getDesc(item.getNewValue()));
            } else {
                purchaseOrderOperateLogDto.setNewValue(PurchaseOrderStatusEnum.getDesc(item.getNewValue()));
            }
            return purchaseOrderOperateLogDto;
        }).collect(Collectors.toList()));
        return res;
    }

    @Override
    public void saveStatusChangeLog(PurchaseOrderStatusChangeDto changeDto) {
        PurchaseOrderOperateLogPo purchaseOrderOperateLogPo = new PurchaseOrderOperateLogPo();
        purchaseOrderOperateLogPo.setBizType(changeDto.getPurchaseOrderPo().getBizType());
        purchaseOrderOperateLogPo.setPurchaseOrderNo(changeDto.getPurchaseOrderPo().getPurchaseOrderNo());
        purchaseOrderOperateLogPo.setActionDesc(changeDto.getOperateEnum().getDesc());
        purchaseOrderOperateLogPo.setModifyColumn(ColumnEnum.STATUS.getDesc());
        purchaseOrderOperateLogPo.setOldValue(changeDto.getPurchaseOrderPo().getPurchaseOrderStatus());
        purchaseOrderOperateLogPo.setNewValue(changeDto.getNewOrderStatus().getCode());
        purchaseOrderOperateLogPo.setCreateUser(changeDto.getOperateUser());
        purchaseOrderOperateLogPo.setRemark(changeDto.getRemark());
        if (changeDto.getOperateEnum() == OperateEnum.MANUAL_PART_TURN_ORDER && changeDto.getTransferContextDto() != null) {
            String remark = StrUtil.isBlank(changeDto.getRemark()) ? "" : " || " + changeDto.getRemark();
            List<PurchaseOrderDetailPo> detailList = changeDto.getTransferContextDto().getOtherPurchaseOrderDetails();
            String detailStr = CollUtil.isEmpty(detailList) ? "" :
                    String.format("转单零件[%s] ，数量[%s]", detailList.get(0).getSalePartNum(), detailList.get(0).getQty());
            purchaseOrderOperateLogPo.setRemark(detailStr + remark);
        }
        baseMapper.insert(purchaseOrderOperateLogPo);
    }

    @Override
    public void saveStatusChangeLog(PurchaseOrderCoStatusChangeDto changeDto) {
        PurchaseOrderOperateLogPo purchaseOrderOperateLogPo = new PurchaseOrderOperateLogPo();
        purchaseOrderOperateLogPo.setBizType(changeDto.getPurchaseOrderPo().getBizType());
        purchaseOrderOperateLogPo.setPurchaseOrderNo(changeDto.getPurchaseOrderPo().getPurchaseOrderNo());
        purchaseOrderOperateLogPo.setActionDesc(changeDto.getOperateEnum().getDesc());
        purchaseOrderOperateLogPo.setModifyColumn(ColumnEnum.CO_TRANSFER_STATUS.getDesc());
        purchaseOrderOperateLogPo.setOldValue(changeDto.getPurchaseOrderPo().getPurchaseOrderStatus());
        purchaseOrderOperateLogPo.setNewValue(changeDto.getNewOrderStatus().getCode());
        purchaseOrderOperateLogPo.setCreateUser(changeDto.getOperateUser());
        purchaseOrderOperateLogPo.setRemark(changeDto.getRemark());
        baseMapper.insert(purchaseOrderOperateLogPo);
    }

}
