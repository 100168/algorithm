package com.jiduauto.sps.order.server.client.resp;

import lombok.Data;

@Data
public class IndirectSrmWDCloseResp {

    private String orderCode;
    /**
     * success   error
     */
    private String resultCode;

    private String resultMessage;

    public  boolean isSuccess() {
        return this.resultCode != null && this.resultCode.equalsIgnoreCase("success");
    }


    public static IndirectSrmWDCloseResp failure(String message) {
        IndirectSrmWDCloseResp resp = new IndirectSrmWDCloseResp();
        resp.setResultMessage(message);
        resp.setResultCode("error");
        return resp;
    }
}
