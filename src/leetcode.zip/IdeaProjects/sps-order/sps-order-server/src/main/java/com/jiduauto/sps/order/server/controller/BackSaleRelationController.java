package com.jiduauto.sps.order.server.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 缺件订单跟销售订单的关系 前端控制器
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@RestController
@RequestMapping("/backSaleRelation")
public class BackSaleRelationController {

}
