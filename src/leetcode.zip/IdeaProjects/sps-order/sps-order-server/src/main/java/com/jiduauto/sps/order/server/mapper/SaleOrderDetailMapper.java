package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderDetailPo;

/**
 * <p>
 * 采购订单明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface SaleOrderDetailMapper extends BaseMapper<SaleOrderDetailPo> {

    /**
     * 销售订单明细分页查询
     * @author dong.li
     * @date 4/17/23 3:05 PM
     */
    IPage<SaleOrderDetailDto> pageSearch(Page<SaleOrderDetailDto> page, SaleOrderDetailByIdReq param);
}
