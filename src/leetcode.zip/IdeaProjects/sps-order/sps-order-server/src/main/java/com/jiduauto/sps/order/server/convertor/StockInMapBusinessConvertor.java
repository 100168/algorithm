package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.sdk.pojo.dto.StockInMapBusinessDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface StockInMapBusinessConvertor {


    @Mapping(target = "orderCreateTime", expression = "java(cn.hutool.core.date.DateUtil.formatLocalDateTime( po.getOrderTime()))")
    @Mapping(target = "logisticsNo", source = "po.logisticNo")
    @Mapping(target = "details", ignore = true)
    StockInMapBusinessDto toDto(WarehouseDistributeOrderPo po);

    @Mapping(target = "orderNo", source = "warehouseDistributeOrderNo")
    @Mapping(target = "orderLineNo", source = "materialLineNo")
    @Mapping(target = "expectQty", source = "qty")
    StockInMapBusinessDto.StockInMapBusinessItemDto toItemDto(WarehouseDistributeItemPo po);

    List<StockInMapBusinessDto.StockInMapBusinessItemDto> toItemDto(List<WarehouseDistributeItemPo> po);
}
