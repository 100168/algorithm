package com.jiduauto.sps.order.server.config;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Strings;
import com.jiduauto.sps.order.server.handler.WDOrderAddThreadLocalHolder;
import com.jiduauto.sps.order.server.pojo.resp.SapInvoiceResp;
import com.jiduauto.sps.order.server.utils.OnlineDutyUtil;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.validation.BindException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.Objects;
import java.util.stream.Collectors;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
    private final String ERROR_FORMAT = "code:[%s]，message:[%s]";

    /**
     * 发生系统异常时，研发告警群
     * 生产环境接入到 研发小组群
     * 测试环境和其他告警 都同步到测试群
     */
    @Value("${sps.coder.webhook.url:https://open.feishu.cn/open-apis/bot/v2/hook/4f25bf1d-90c2-41a6-92ce-9a088e1e8213}")
    private String coderWebhookUrl;

    @Autowired
    WebhookUtil webhookUtil;

    @Autowired
    private OnlineDutyUtil onlineDutyUtil;

    @Value("${spring.profiles.active}")
    private String active;

    /**
     * 处理其他异常
     *
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public BaseResult exceptionHandler(HttpServletRequest req, Exception e) {
        log.info("req log:{}", reqLogStr(req));
        log.error("未知异常！原因是:", e);
        if (!active.equals("local") && !active.equals("dev")) {
            webhookUtil.sendErrorMsg("系统异常！URL：" + req.getServletPath(), -1, e.getMessage(), BaseConstants.WebhookUtilLevel.P0, coderWebhookUrl);
        }
        WDOrderAddThreadLocalHolder.remove();
        return BaseResult.systemException(GlobalCodeEnum.GL_FAIL_DEFAULT);
    }

    /**
     * 处理请求方式异常
     *
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
    @ResponseBody
    public BaseResult HttpRequestMethodNotSupportedException(HttpServletRequest req, Exception e) {
        log.info("req log:{}", reqLogStr(req));
        log.error("请求异常HttpRequestMethodNotSupportedException:", e);
        return BaseResult.systemException(GlobalCodeEnum.GL_FAIL_9996);
    }


    /**
     * 处理验证参数异常
     *
     * @param req
     * @param e
     * @return
     */
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    @ResponseBody
    public Object MethodArgumentNotValidExceptionHandler(HttpServletRequest req, MethodArgumentNotValidException e) {
        String message = e.getBindingResult().getAllErrors().stream().map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.joining());
        log.info("req log:{}", reqLogStr(req));
        //error 告警级别关注 /external  /internal  /spsInternal  外部使用接口参数校验异常
        if (req.getServletPath().startsWith("/external") ||
                req.getServletPath().startsWith("/internal") ||
                req.getServletPath().startsWith("/spsInternal")
        ) {
            log.error("MethodArgumentNotValidException:", e);
        } else {
            log.warn("MethodArgumentNotValidException:", e);
        }
        WDOrderAddThreadLocalHolder.remove();
        if (req.getServletPath().startsWith("/internal/sap/synInvoice")) {
            return SapInvoiceResp.failedResp(message, null);
        }
        return BaseResult.systemException(GlobalCodeEnum.GL_FAIL_9998, message);
    }

    /**
     * 处理参数校验的BindException异常
     */
    @ExceptionHandler(value = BindException.class)
    @ResponseBody
    public BaseResult bindExceptionHandler(HttpServletRequest req, BindException e) {
        String message = e.getBindingResult().getAllErrors().stream().map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.joining());
        log.info("req log:{}", reqLogStr(req));
        log.error("BindException:", e);
        return BaseResult.systemException(GlobalCodeEnum.GL_FAIL_9998, message);
    }


    /**
     * 处理 BizException 异常
     *
     * @param httpServletRequest httpServletRequest
     * @param e                  异常
     * @return
     */
    @ResponseBody
    @ExceptionHandler(value = BizException.class)
    public BaseResult businessExceptionHandler(HttpServletRequest httpServletRequest, BizException e) {
        if (!active.equals("local") && !active.equals("dev")) {
            if (Objects.equals(e.getErrCode(), GlobalCodeEnum.GL_FAIL_10000.getCode())) {
                //业务异常统一处理 只有返回10000 ，才表示需要告警，且需要人工干预 ps:同步SAP异常等
                webhookUtil.sendMarkdownMessageV3(BaseConstants.WebhookUtilLevel.P1, e.getErrCode(), e.getErrMessage(), httpServletRequest.getServletPath(), UserUtil.getUserName());
            }
        }
        log.error("业务异常：code:[{}]，message:[{}]", e.getErrCode(), e.getErrMessage(), e);
        WDOrderAddThreadLocalHolder.remove();
        return BaseResult.systemException(e.getErrCode(), e.getErrMessage(), e.getLogRelId());
    }


    private String reqLogStr(HttpServletRequest req) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('\n').append("==>  RequestUrl: ").append(req.getServletPath()).append('\n');
        if (StrUtil.isNotBlank(req.getQueryString())) {
            stringBuilder.append("==>  QueryParam: ").append(req.getQueryString()).append('\n');
        }
        stringBuilder.append("==>  HeaderParam: ").append(headStr(req)).append('\n');
        return stringBuilder.toString();
    }

    private String headStr(HttpServletRequest req) {
        Enumeration<String> headerNames = req.getHeaderNames();
        if (Objects.isNull(headerNames)) {
            return "";
        }
        JSONObject header = new JSONObject();
        while (headerNames.hasMoreElements()) {
            String headerName = headerNames.nextElement();
            if (!Strings.isNullOrEmpty(headerName)) {
                header.put(headerName, req.getHeader(headerName));
            }
        }
        return header.toString();
    }
}
