package com.jiduauto.sps.order.server.handler;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.dit.outbox.anno.MessageHandle;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.pojo.Result;
import com.jiduauto.sps.order.server.client.IndirectSrmClient;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.client.WmsClient;
import com.jiduauto.sps.order.server.client.req.IndirectWDApplyOrderPutOutReq;
import com.jiduauto.sps.order.server.client.resp.IndirectSrmWDResp;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.order.server.convertor.InboundReqConvertor;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.WarehouseDistributeOrderAllPo;
import com.jiduauto.sps.order.server.pojo.BackOrderBatchCancelResp;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreTransferOrderOperateReq;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.sdk.client.SAPRestAdapterClient;
import com.jiduauto.sps.sdk.client.req.BackOrderCancelSyncReq;
import com.jiduauto.sps.sdk.client.req.SapSD019;
import com.jiduauto.sps.sdk.client.req.StockOutMapBusinessDto;
import com.jiduauto.sps.sdk.client.resp.BackOrderCancelSyncResp;
import com.jiduauto.sps.sdk.enums.StoreTransferOrderOperate;
import com.jiduauto.sps.sdk.enums.StoreTransferOrderStatus;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeAttachDto;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.AsnAddSyncReq;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import com.jiduauto.sps.sdk.pojo.req.SMCompleteSyncSapReq;
import com.jiduauto.sps.sdk.pojo.resp.SapResp;
import com.jiduauto.sps.sdk.pojo.resp.SapRespList;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

import static com.jiduauto.sps.sdk.consts.OutboxConst.MessageType.*;


/**
 * @author panjian
 */
@Component
@Slf4j
public class OutboxMessageHandlers {

    @Resource
    private InboundReqConvertor inboundReqConvertor;
    @Resource
    private WmsClient wmsClient;

    @Resource
    private SAPRestAdapterClient sapRestAdapterClient;

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @Resource
    private ISaleOrderDetailService saleOrderDetailService;

    @Resource
    private IBackOrderService backOrderService;

    @Resource
    private SpsClient spsClient;
    
    @Resource
    private IStoreTransferOrderService storeTransferOrderService;

    @Resource
    private IStoreTransferOrderDetailService storeTransferOrderDetailService;

    @Resource
    private IWarehouseDistributeItemService warehouseDistributeItemService;

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;
    @Resource
    private IWarehouseDistributeAttachService warehouseDistributeAttachService;
    @Resource
    private IndirectSrmClient indirectSrmClient;

    /**
     * 履约完成同步sap
     */
    @MessageHandle(msgType = SM_ORDER_RECEIVE_TO_SAP)
    public Result smReceiveToSapHandle(OutboxMessage outboxMessage) {
        WarehouseDistributeOrderPo po = JSONUtil.toBean(outboxMessage.getContent(), WarehouseDistributeOrderPo.class);
        SMCompleteSyncSapReq smCompleteSyncSapReq = SMCompleteSyncSapReq.newInstance();
        smCompleteSyncSapReq.setBodyHead(po);
        SapResp sapResp = sapRestAdapterClient.smOrderCompleteSync(smCompleteSyncSapReq);
        return SapResp.success(sapResp) ? Result.success() : Result.error(JSONUtil.toJsonStr(sapResp));
    }

    /**
     * 一件代发履约完成同步sap
     */
    @MessageHandle(msgType = SM30_RECEIVE_TO_SAP)
    public Result sm30ReceiveToSapHandle(OutboxMessage outboxMessage) {
        WarehouseDistributeOrderPo po = JSONUtil.toBean(outboxMessage.getContent(), WarehouseDistributeOrderPo.class);
        List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.selectList(po.getOrderNo());
        SapSD019 sapSD019 = SapSD019.newInstance();
        sapSD019.setWdo(po);
        sapSD019.setDetail(po,itemPos);
        SapRespList sapResp = sapRestAdapterClient.pushToSD019(sapSD019);
        return SapRespList.success(sapResp) ? Result.success() : Result.error(JSONUtil.toJsonStr(sapResp));
    }

    @MessageHandle(msgType = WD_ORDER_TO_DHL)
    public Result wdOrderToDhlInbound(OutboxMessage outboxMessage) {
        WarehouseDistributeOrderAllPo allPo = JSONUtil.toBean(outboxMessage.getContent(), WarehouseDistributeOrderAllPo.class);
        AsnAddSyncReq inBoundReq = inboundReqConvertor.toInBoundReq(allPo);
        ResultResp<Object> BaseResult = wmsClient.pushAsn(inBoundReq);
        log.info("OutboxMessageHandler#wdOrderToDhlInbound, param: {}, result: {}", JsonUtil.toJsonString(inBoundReq),
                JsonUtil.toJsonString(BaseResult));
        return BaseResult.isSuccess() ? Result.success() : Result.error(BaseResult.getMsg());
    }



    /**
     * 销售订单批量取消同步sap
     */
    @MessageHandle(msgType = SALE_ORDER_CANCEL)
    public Result saleOrderCancelToSap(OutboxMessage outboxMessage) {
        SaleOrderPo saleOrderPo = JsonUtil.toObject(outboxMessage.getContent(), SaleOrderPo.class);
        PurchaseOrderPo purchaseOrderPo = purchaseOrderService.getOne(Wrappers.lambdaQuery(PurchaseOrderPo.class)
                .eq(PurchaseOrderPo::getPurchaseOrderNo, saleOrderPo.getPurchaseOrderNo()));
        List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailService.list(Wrappers.<SaleOrderDetailPo>lambdaQuery()
                .eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderPo.getSaleOrderNo()));
        BackOrderCancelSyncReq backOrderCancelSyncReq = BackOrderCancelSyncReq
                .newInstance()
                .setPurchaseOrder(purchaseOrderPo)
                .setSaleOrder(saleOrderPo)
                .buildItem(saleOrderDetailPos);
        BackOrderCancelSyncResp backOrderCancelSyncResp = sapRestAdapterClient.backOrderCancelSync(
                backOrderCancelSyncReq);
        log.info("OutboxMessageHandler#backOrderCancelToSap, param: {}, result: {}",
                JsonUtil.toJsonString(backOrderCancelSyncReq),
                JsonUtil.toJsonString(backOrderCancelSyncResp));

        if (!BackOrderCancelSyncResp.success(backOrderCancelSyncResp)) {
            return Result.error(JSONUtil.toJsonStr(backOrderCancelSyncResp));
        }
        return Result.success();
    }

    /**
     * 缺件订单批量取消同步sap
     */
    @MessageHandle(msgType = BACK_ORDER_CANCEL)
    public Result backOrderCancelToSap(OutboxMessage outboxMessage) {
        List<Long> backOrderIds = JsonUtil.toArray(outboxMessage.getContent(), Long.class);
        List<BackOrderPo> backOrderPos = backOrderService.listByIds(backOrderIds);
        BackOrderBatchCancelResp backOrderBatchCancelResp = new BackOrderBatchCancelResp();
        backOrderBatchCancelResp.setBizType(backOrderPos.get(0).getBizType());
        ArrayList<BackOrderBatchCancelResp.RespInfo> respInfos = new ArrayList<>();
        //一个个同步,同一个采购订单的缺件号要等上一个同步完才能操作
        for (BackOrderPo backOrderPo : backOrderPos) {
            PurchaseOrderPo purchaseOrderPo = purchaseOrderService.getOne(Wrappers.lambdaQuery(PurchaseOrderPo.class)
                    .eq(PurchaseOrderPo::getPurchaseOrderNo, backOrderPo.getPurchaseOrderNo()));
            BackOrderCancelSyncReq backOrderCancelSyncReq = BackOrderCancelSyncReq
                    .newInstance()
                    .setPurchaseOrder(purchaseOrderPo)
                    .setBackOrder(backOrderPo);
            BackOrderCancelSyncResp backOrderCancelSyncResp = sapRestAdapterClient.backOrderCancelSync(
                    backOrderCancelSyncReq);
            log.info("OutboxMessageHandler#backOrderCancelToSap, param: {}, result: {}",
                    JsonUtil.toJsonString(backOrderCancelSyncReq),
                    JsonUtil.toJsonString(backOrderCancelSyncResp));
            if (!BackOrderCancelSyncResp.success(backOrderCancelSyncResp)) {
                BackOrderBatchCancelResp.RespInfo respInfo = new BackOrderBatchCancelResp.RespInfo();
                respInfo.setBackOrderNo(backOrderPo.getBackOrderNo());
                String errorMessage = backOrderCancelSyncResp.getMessageBody().get(0).getItem().get(0)
                        .getMessage_Text();
                respInfo.setMsg(errorMessage);
                respInfos.add(respInfo);
            }
        }
        backOrderBatchCancelResp.setRespInfos(respInfos);
        if (CollUtil.isNotEmpty(respInfos)) {
            return Result.error(JSONUtil.toJsonStr(backOrderBatchCancelResp));
        }
        return Result.success();
    }


    /**
     * sps-order 发送 出库关联订单的请求到SPS 失败可重试
     * @param outboxMessage
     * @return
     */
    @MessageHandle(STOCK_OUT_MAP_BUSINESS_TO_SPS)
    public Result stockOutMapBusinessHandle(OutboxMessage outboxMessage) {
        StockOutMapBusinessDto dto = JsonUtil.toObject(outboxMessage.getContent(), StockOutMapBusinessDto.class);
        BaseResult<Boolean> baseResult = spsClient.stockOutMapBusiness(dto);
        log.info("SaleOrderServiceImpl#stockOutMapBusinessHandle, param: {}, result: {}", JsonUtil.toJsonString(dto), JsonUtil.toJsonString(baseResult));
        return baseResult.isSuccess() ? Result.success() : Result.error(baseResult.getMessage());
    }

    /**
     * 调拨单取消
     */
    @MessageHandle(STORE_TRANSFER_ORDER_CANCEL_TO_SAP)
    public Result storeTransferOrderCancelToSap(OutboxMessage outboxMessage) {
        InternalStoreTransferOrderOperateReq req = JsonUtil.toObject(outboxMessage.getContent(), InternalStoreTransferOrderOperateReq.class);
        StoreTransferOrderPo po = storeTransferOrderService.getOne(Wrappers.lambdaQuery(StoreTransferOrderPo.class)
                .eq(StoreTransferOrderPo::getOrderNo, req.getOrderNo()));

        List<StoreTransferOrderDetailPo> details = storeTransferOrderDetailService.list(Wrappers.lambdaQuery(StoreTransferOrderDetailPo.class)
                .eq(StoreTransferOrderDetailPo::getOrderNo, req.getOrderNo()));

        BackOrderCancelSyncReq cancelSyncReq = BackOrderCancelSyncReq.newInstance().setStoreTransferOrder(po).buildStoreTransferOrderItem(details);

        BackOrderCancelSyncResp resp = sapRestAdapterClient.backOrderCancelSync(cancelSyncReq);
        if (!BackOrderCancelSyncResp.success(resp)) {
            return Result.error(JSONUtil.toJsonStr(resp));
        }
        //取消成功，更新状态
        storeTransferOrderService.updateStatusAndLog(req.getOrderNo(), StoreTransferOrderStatus.CANCELED, req.getOperateUser(), StoreTransferOrderOperate.CANCEL);
        return Result.success();
    }

    /**
     * 仓配订单-领料订单-出库结果同步SRM
     * @param outboxMessage
     * @return
     */
    @MessageHandle(WD_APPLY_ORDER_PUT_OUT_TO_SRM)
    public Result syncWDApplyOrderPutOutToSRM(OutboxMessage outboxMessage) {
        InAndOutStockRequest msg = JSONUtil.toBean(outboxMessage.getContent(), InAndOutStockRequest.class);
        IndirectWDApplyOrderPutOutReq putOutReq = IndirectWDApplyOrderPutOutReq.newInstance();
        WarehouseDistributeOrderPo po = warehouseDistributeOrderService.getByOrderNo(msg.getBizType(), msg.getTradeNo());
        if(po == null){
            return Result.success();
        }
        WarehouseDistributeAttachDto attachPo = warehouseDistributeAttachService.selectWarehouseDistributeAttach(po.getBizType(), po.getOrderNo() );
        putOutReq = putOutReq.setHeaderContent(po, attachPo);
        putOutReq.setItemList(msg);

        if (po.getIsChild()) {
            WarehouseDistributeOrderPo parentPo = warehouseDistributeOrderService.getByOrderNo(po.getBizType(), po.getAssociateBillNo());
            putOutReq.getData().setOrderCode(parentPo.getBusinessBillNo());
        }
        List<IndirectSrmWDResp> indirectSrmResp =  indirectSrmClient.syncWDApplyOrderPutOut(putOutReq);
        if(!indirectSrmResp.get(0).isSuccess()){
            return Result.error(JSONUtil.toJsonStr(indirectSrmResp));
        }
        return Result.success();

    }
}
