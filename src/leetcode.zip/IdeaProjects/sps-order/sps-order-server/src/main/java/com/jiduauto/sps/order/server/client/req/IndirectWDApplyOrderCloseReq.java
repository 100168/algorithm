package com.jiduauto.sps.order.server.client.req;

import lombok.Data;

import java.io.Serializable;
@Data

public class IndirectWDApplyOrderCloseReq implements Serializable {



    private IndirectWDApplyOrderCloseReqItem data;


    @Data
    public static class IndirectWDApplyOrderCloseReqItem implements Serializable {

        /**
         *SRM内领订单号
         */
        private String orderCode;
        /**
         * 精品传JC
         * 能源传ES
         * 零附件传SP
         * 工服传CL
         */
        private String businessType;
        /**
         * 默认传Y
         */
        private String closeFlag;
    }
}
