package com.jiduauto.sps.order.server.convertor;

import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.handler.WDOrderAddThreadLocalHolder;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.WarehouseDistributeOrderAllPo;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.client.req.AsnDeliverPushReq;
import com.jiduauto.sps.sdk.client.req.AsnPushReq;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderStatusEnum;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.utils.DateUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class AsnConvertor {

    @Resource
    private BaseDataQuery baseDataQuery;

    public AsnPushReq toAsnPushReq(WarehouseDistributeOrderAllPo allPo) {
        SupplierPo supplierPo = WDOrderAddThreadLocalHolder.getObject(WDOrderAddThreadLocalHolder.SUPPLIER, SupplierPo.class);
        if (supplierPo == null) {
            supplierPo = new SupplierPo();
        }
        AsnPushReq asnPushReq = new AsnPushReq();
        WarehouseDistributeOrderPo orderPo = allPo.getWarehouseDistributeOrderPo();
        WarehouseDistributeLogisticPo logisticPo = allPo.getWarehouseDistributeLogisticPo();
        List<WarehouseDistributeItemPo> items = allPo.getItems();
        asnPushReq.setAsnCode(orderPo.getBusinessBillNo());
        asnPushReq.setBusinessType(orderPo.getOrderType());
        asnPushReq.setDeliverTime(DateUtils.format(LocalDateTime.now(), BaseConstants.DatePattern.DATE));
        if (StrUtil.isNotBlank(logisticPo.getEstArrivalTime())){
            asnPushReq.setEstArrivalTime(DateUtil.parse(logisticPo.getEstArrivalTime(), DatePattern.NORM_DATE_FORMAT).toDateStr());
        }
        asnPushReq.setStatus(orderPo.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.CANCELED.getCode()) ? -1 : 1);
        asnPushReq.setReceiveWarehouseCode(logisticPo.getReceiveWarehouseCode());
        asnPushReq.setRemake(orderPo.getRemark());
        asnPushReq.setSuppierSapCode(supplierPo.getSapCode());
        asnPushReq.setSuppierName(supplierPo.getSupplierName());
        List<AsnDeliverPushReq> deliverPushReqs = getDeliverPushReqs(items, orderPo);
        asnPushReq.setAsnDeliverList(deliverPushReqs);
        return asnPushReq;
    }

    private List<AsnDeliverPushReq> getDeliverPushReqs(List<WarehouseDistributeItemPo> items, WarehouseDistributeOrderPo orderPo) {
        List<AsnDeliverPushReq> deliverPushReqs = new ArrayList<>();
        List<String> materialCodes = items.stream().map(WarehouseDistributeItemPo::getMaterialCode).collect(Collectors.toList());
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(orderPo.getBizType(), materialCodes);
        for (WarehouseDistributeItemPo item : items) {
            AsnDeliverPushReq pushReq = new AsnDeliverPushReq();
            MaterialPo materialPo = materialPoMap.get(item.getMaterialCode());
            pushReq.setAsnLineNo(item.getMaterialLineNo());
            pushReq.setSalePartNum(item.getMaterialCode());
            pushReq.setPartsName(materialPo.getMaterialName());
            if (BooleanUtil.toBoolean(materialPo.getAccurateTrace())) {
                pushReq.setTraceStatus(1);
            } else {
                pushReq.setTraceStatus(2);
            }
            pushReq.setDeliveryQty(item.getQty().intValue());
            pushReq.setBatchNo(item.getBatchNo());
            pushReq.setProductTime(item.getProductDate());
            pushReq.setExpireTime(item.getExpireDate());
            pushReq.setExpressNo(orderPo.getLogisticNo());
            pushReq.setSequenceNo(item.getSequenceNo());
            pushReq.setUnit(materialPo.getOrderUnit());
            deliverPushReqs.add(pushReq);
        }
        return deliverPushReqs;
    }
}
