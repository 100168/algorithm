package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.dto.StoreTransferOrderDetailDto;
import com.jiduauto.sps.sdk.pojo.po.StoreTransferOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

import java.util.List;

/**
 * <p>
 * 门店调拨单明细 服务类
 * </p>
 */
public interface IStoreTransferOrderDetailService extends IService<StoreTransferOrderDetailPo> {

    BasePageData<StoreTransferOrderDetailDto> pageSearch(BasePageParam<OrderNoReq> pageParam);

    /**
     * 根据调拨单号查询明细*/
    List<StoreTransferOrderDetailPo> listByOrderNo(String orderNo);
}
