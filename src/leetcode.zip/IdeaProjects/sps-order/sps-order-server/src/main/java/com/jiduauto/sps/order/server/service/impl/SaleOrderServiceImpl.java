package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jiduauto.dit.outbox.OutboxMessageService;
import com.jiduauto.dit.outbox.anno.MessageHandle;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.pojo.Result;
import com.jiduauto.spare.parts.api.model.rpc.request.claim.ClaimWhitelistCancelRequest;
import com.jiduauto.spare.parts.api.model.rpc.request.claim.ClaimWhitelistCreateRequest;
import com.jiduauto.spare.parts.api.service.ClaimRpcService;
import com.jiduauto.sps.order.server.client.PdpClient;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.client.TrackClient;
import com.jiduauto.sps.order.server.client.req.TrackDetailReq;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.order.server.client.resp.TrackDetailResp;
import com.jiduauto.sps.order.server.convertor.NoticedDtoConvertor;
import com.jiduauto.sps.order.server.mapper.BackSaleRelationMapper;
import com.jiduauto.sps.order.server.mapper.SaleOrderDetailMapper;
import com.jiduauto.sps.order.server.mapper.SaleOrderMapper;
import com.jiduauto.sps.order.server.pojo.dto.*;
import com.jiduauto.sps.order.server.pojo.fileexport.SaleOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.GenerateSerialNoUtil;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.client.req.*;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.CreatePrOrderReq;
import com.jiduauto.sps.sdk.pojo.req.DHLOutboundReq;
import com.jiduauto.sps.sdk.pojo.req.IdBatchReq;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.jiduauto.sps.sdk.consts.OutboxConst.MessageType.*;
import static com.jiduauto.sps.sdk.enums.GlobalCodeEnum.GL_FAIL_DEFAULT;
import static com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum.DUPLICATE_OPERATE;
import static com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum.SALE_ORDER_CANCEL_ERROR;
import static java.util.stream.Collectors.toMap;


/**
 * <p>
 * 销售订单 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Slf4j
@Service
public class SaleOrderServiceImpl extends ServiceImpl<SaleOrderMapper, SaleOrderPo> implements ISaleOrderService {

    private final static int BATCH_SIZE = 100000;

    private final static int STORE_BATCH_SIZE = 1000;

    @Value("${MAX_SIZE_10000:10000}")
    private Integer maxSize;

    @Value("${so.ro-co.issue-time:00:00-15:00}")
    private String issueTime;

    @Resource
    private SpsClient spsClient;

    @Resource
    private SaleOrderMapper saleOrderMapper;

    @Resource
    private SaleOrderDetailMapper saleOrderDetailMapper;

    @Resource
    private GenerateSerialNoUtil generateSerialNoUtil;

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private ISaleOrderOperateLogService saleOrderOperateLogService;

    @Resource
    private BackSaleRelationMapper backSaleRelationMapper;

    @Resource
    private IBackOrderService backOrderService;

    @Resource
    private OutboxMessageService outboxMessageService;

    @Resource
    private RocketMQTemplate rocketMQTemplate;

    @Resource
    private PdpClient pdpClient;

    @Resource
    private WebhookUtil webhookUtil;

    @Resource
    private TrackClient trackClient;

    @Resource
    private NoticedDtoConvertor noticedDtoConvertor;

    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;

    @Resource
    private OrderCalendarService orderCalendarService;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private ClaimRpcService claimRpcService;

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private ISaleOrderInvoiceRelationService saleOrderInvoiceRelationService;

    /**
     * 销售订单分页查询
     *
     * @author dong.li
     * @date 4/14/23 2:19 PM
     */
    @Override
    public BasePageData<SaleOrderDto> pageSearch(BasePageParam<SaleOrderPageSearchReq> pageParam) {
        SaleOrderPageSearchReq param = pageParam.getParam();
        if(StringUtils.isBlank(param.getInvoiceNo())){
            param.setInvoiceNo(null);
        }
        if(StringUtils.isBlank(param.getRedInvoiceNo())){
            param.setRedInvoiceNo(null);
        }
        Page<SaleOrderDto> page = new Page<>(pageParam.getPage(), pageParam.getSize());
        IPage<SaleOrderDto> pageSearchList = saleOrderMapper.pageSearch(page, param);
        BasePageData<SaleOrderDto> res = new BasePageData<>(pageSearchList);
        Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(
                DictEnum.MapLocationDistrict.getDictCode());
        // 获取门店名称map
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(param.getBizType(),
                pageSearchList.getRecords().stream().map(SaleOrderDto::getStoreCode).distinct().collect(Collectors.toList()));
        // 获取收货仓库名称map
        Map<String, WarehousePo> receiveWarehousePoMap = baseDataQuery.mapWarehousePo(BizTypeEnum.getNewBizType(param.getBizType()),
                pageSearchList.getRecords().stream().map(SaleOrderDto::getReceiveWarehouseCode).distinct().collect(Collectors.toList()));
        // 获取发货仓库名称map
        Map<String, WarehousePo> deliverWarehousePoMap = baseDataQuery.mapWarehousePo(param.getBizType(),
                pageSearchList.getRecords().stream().map(SaleOrderDto::getDeliverWarehouseCode).distinct().collect(Collectors.toList()));
        Map<String, List<SapInvoiceInfoPo>> saleOrderNoMap = saleOrderInvoiceRelationService.mapSapInvoiceInfoPoList(pageSearchList.getRecords().stream().map(SaleOrderDto::getSaleOrderNo).collect(Collectors.toList()));

        res.setRecords(res.getRecords().stream().peek(e -> {
            // 设置门店名称
            StorePo curStore = storePoMap.getOrDefault(e.getStoreCode(), new StorePo());
            e.setStoreName(curStore.getStoreName());
            String provinceName = codeAndNameMap.getOrDefault(e.getReceiverProvince(), "");
            String cityName = codeAndNameMap.getOrDefault(e.getReceiverCity(), "");
            String districtName = codeAndNameMap.getOrDefault(e.getReceiverDistrict(), "");
            // 设置收货仓库名称
            WarehousePo curReceiveWareHouse = receiveWarehousePoMap.getOrDefault(e.getReceiveWarehouseCode(), new WarehousePo());
            e.setReceiveWarehouseName(curReceiveWareHouse.getName());
            // 设置发货仓库名称
            WarehousePo curDeliverWareHouse = deliverWarehousePoMap.getOrDefault(e.getDeliverWarehouseCode(), new WarehousePo());
            e.setTransferAdvice(ShippingMethodEnum.getDesc(e.getTransferAdvice()));
            e.setSaleOrderStatusCode(e.getSaleOrderStatus());
            e.setSaleOrderStatus(SaleOrderStatusEnum.getDesc(e.getSaleOrderStatus()));
            e.setDfsStatusCode(e.getDfsStatus());
            e.setDfsStatus(SaleOrderDfsStatusEnum.getDesc(e.getDfsStatus()));
            e.setDeliverWarehouseName(curDeliverWareHouse.getName());
            e.setReceiverAddress(provinceName.concat(cityName)
                    .concat(districtName).concat(e.getReceiverAddress()));
            e.setInvoiceNo(ISaleOrderInvoiceRelationService.getInvoiceInfo(e.getSaleOrderNo(), saleOrderNoMap).getInvoiceNo());
            e.setInvoiceUrl(ISaleOrderInvoiceRelationService.getInvoiceInfo(e.getSaleOrderNo(), saleOrderNoMap).getInvoiceUrl());
            e.setInvoiceAmount(ISaleOrderInvoiceRelationService.getInvoiceInfo(e.getSaleOrderNo(), saleOrderNoMap).getInvoiceAmount());
            e.setInvoiceDate(ISaleOrderInvoiceRelationService.getInvoiceInfo(e.getSaleOrderNo(), saleOrderNoMap).getInvoiceDate());
            e.setRedInvoiceList(BeanUtil.copyToList(ISaleOrderInvoiceRelationService.getRedInvoiceInfoList(e.getSaleOrderNo(), saleOrderNoMap), SaleOrderDto.RedInvoice.class));
        }).collect(Collectors.toList()));
        return res;
    }

    /**
     * 销售订单所有明细查询  关键字 PO单单号集合
     *
     * @param pageParam
     * @return
     */
    @Override
    public List<SaleOrderByPoDto> pageSearchByPos(BasePageParam<SaleOrderPageSearchReq> pageParam) {
        SaleOrderPageSearchReq param = pageParam.getParam();
        List<SaleOrderByPoDto> poDtos = saleOrderMapper.pageSearchByPo(param.getBizType(), param.getPurchaseOrderNos(), pageParam.getSize());

        Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(
                DictEnum.MapLocationDistrict.getDictCode());
        // 获取门店名称map
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(param.getBizType(),
                poDtos.stream().map(SaleOrderByPoDto::getStoreCode).distinct().collect(Collectors.toList()));
        // 获取收货仓库名称map

        Map<String, WarehousePo> receiveWarehousePoMap = baseDataQuery.mapWarehousePo(BizTypeEnum.getNewBizType(param.getBizType()),
                poDtos.stream().map(SaleOrderByPoDto::getReceiveWarehouseCode).distinct().collect(Collectors.toList()));
        // 获取发货仓库名称map
        Map<String, WarehousePo> deliverWarehousePoMap = baseDataQuery.mapWarehousePo(param.getBizType(),
                poDtos.stream().map(SaleOrderByPoDto::getDeliverWarehouseCode).distinct().collect(Collectors.toList()));
        // 获取零件信息
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(param.getBizType(),
                poDtos.stream().map(SaleOrderByPoDto::getSalePartNum).distinct().collect(Collectors.toList()));

        return poDtos.stream().peek(e -> {
            // 设置门店名称
            StorePo curStore = storePoMap.getOrDefault(e.getStoreCode(), new StorePo());
            e.setStoreName(curStore.getStoreName());
            String provinceName = codeAndNameMap.getOrDefault(e.getReceiverProvince(), "");
            String cityName = codeAndNameMap.getOrDefault(e.getReceiverCity(), "");
            String districtName = codeAndNameMap.getOrDefault(e.getReceiverDistrict(), "");
            // 设置收货仓库名称
            WarehousePo curReceiveWareHouse = receiveWarehousePoMap.getOrDefault(e.getReceiveWarehouseCode(), new WarehousePo());
            e.setReceiveWarehouseName(curReceiveWareHouse.getName());
            // 设置发货仓库名称
            WarehousePo curDeliverWareHouse = deliverWarehousePoMap.getOrDefault(e.getDeliverWarehouseCode(), new WarehousePo());
            e.setTransferAdvice(ShippingMethodEnum.getDesc(e.getTransferAdvice()));
            e.setSaleOrderStatusCode(e.getSaleOrderStatus());
            e.setSaleOrderStatus(SaleOrderStatusEnum.getDesc(e.getSaleOrderStatus()));
            e.setDfsStatusCode(e.getDfsStatus());
            e.setDfsStatus(SaleOrderDfsStatusEnum.getDesc(e.getDfsStatus()));
            e.setDeliverWarehouseName(curDeliverWareHouse.getName());
            e.setReceiverAddress(provinceName.concat(cityName)
                    .concat(districtName).concat(e.getReceiverAddress()));

            MaterialPo curMaterial = materialPoMap.getOrDefault(e.getSalePartNum(), new MaterialPo());
            e.setSalePartName(curMaterial.getMaterialName());
            // 设置零件销售属性
            e.setPartSaleField(curMaterial.getPartSaleField());
            // 设置最小包装
            e.setMinPackage(curMaterial.getMinPackage());
        }).collect(Collectors.toList());
    }

    @Override
    public void builderDfsSaleOrderPo(PurchaseOrderTransferContextDto contextDto) {
        if (CollectionUtils.isEmpty(contextDto.getDfsPurchaseOrderDetails())) {
            return;
        }

        Map<String, PurchaseOrderDetailPo> detailMap =
                contextDto.getPurchaseOrderDetails().stream().collect(toMap(PurchaseOrderDetailPo::getSalePartNum, item -> item));

        PurchaseOrderPo purchaseOrderPo = contextDto.getPurchaseOrder();
        SaleOrderPo saleOrderPo = new SaleOrderPo();
        saleOrderPo.setBizType(purchaseOrderPo.getBizType());
        saleOrderPo.setPurchaseOrderNo(purchaseOrderPo.getPurchaseOrderNo());
        saleOrderPo.setSaleOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.SO, purchaseOrderPo.getBizType()));
        saleOrderPo.setIsDfs(Boolean.TRUE);
        saleOrderPo.setDeliverWarehouseCode(null);
        saleOrderPo.setDfsStatus(SaleOrderDfsStatusEnum.PENDING.getCode());
        saleOrderPo.setSaleOrderStatus(SaleOrderStatusEnum.PENDING_DELIVERY.getCode());
        saleOrderPo.setSaleOrderType(purchaseOrderPo.getPurchaseOrderType());
        saleOrderPo.setTransferAdvice(null);
        saleOrderPo.setStoreCode(purchaseOrderPo.getStoreCode());
        saleOrderPo.setReceiveWarehouseCode(purchaseOrderPo.getReceiveWarehouseCode());
        saleOrderPo.setReceiver(purchaseOrderPo.getReceiver());
        saleOrderPo.setReceiverPhone(purchaseOrderPo.getReceiverPhone());
        saleOrderPo.setReceiverProvince(purchaseOrderPo.getReceiverProvince());
        saleOrderPo.setReceiverCity(purchaseOrderPo.getReceiverCity());
        saleOrderPo.setReceiverDistrict(purchaseOrderPo.getReceiverDistrict());
        saleOrderPo.setReceiverAddress(purchaseOrderPo.getReceiverAddress());
        saleOrderPo.setCreateUser(OperateUserEnum.SPS.getName());

        List<SaleOrderDetailPo> dfsSaleOrderDetailPos = contextDto.getDfsPurchaseOrderDetails().stream().map(item -> {
            SaleOrderDetailPo saleOrderDetailPo = new SaleOrderDetailPo();
            saleOrderDetailPo.setBizType(saleOrderPo.getBizType());
            saleOrderDetailPo.setSaleOrderNo(saleOrderPo.getSaleOrderNo());
            saleOrderDetailPo.setSalePartNum(item.getSalePartNum());
            saleOrderDetailPo.setQty(item.getQty());
            saleOrderDetailPo.setDeliverQty(BigDecimal.ZERO);
            saleOrderDetailPo.setReceiveQty(BigDecimal.ZERO);
            saleOrderDetailPo.setCancelQty(BigDecimal.ZERO);
            saleOrderDetailPo.setCreateUser(OperateUserEnum.SPS.getName());
            saleOrderDetailPo.setRemark(item.getStoreRemark());
            return saleOrderDetailPo;
        }).collect(Collectors.toList());
        BigDecimal saleOrderAmount = dfsSaleOrderDetailPos.stream()
                .map(item -> detailMap.get(item.getSalePartNum()).getDiscountUnitPrice().multiply(item.getQty()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        saleOrderPo.setSaleOrderAmount(saleOrderAmount);
        contextDto.getSaleOrders().add(saleOrderPo);
        contextDto.getSaleOrderDetails().addAll(dfsSaleOrderDetailPos);
    }

    @Override
    public void builderSaleOrderPos(PurchaseOrderTransferContextDto contextDto) {
        if (CollectionUtils.isEmpty(contextDto.getOccupyDetails())) {
            return;
        }

        PurchaseOrderPo purchaseOrderPo = contextDto.getPurchaseOrder();
        contextDto.getOccupyDetails().stream()
                .collect(Collectors.groupingBy(item -> item.getDeliverWarehouseCode().concat(item.getTransferAdvice())))
                .values()
                .forEach(occupyDetailDtos -> {
                    if (CollectionUtils.isEmpty(occupyDetailDtos)) {
                        return;
                    }
                    String orderType = purchaseOrderPo.getPurchaseOrderType();
                    SaleOrderPo saleOrderPo = new SaleOrderPo();
                    saleOrderPo.setBizType(purchaseOrderPo.getBizType());
                    saleOrderPo.setPurchaseOrderNo(purchaseOrderPo.getPurchaseOrderNo());
                    saleOrderPo.setSaleOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.SO, purchaseOrderPo.getBizType()));
                    saleOrderPo.setIsDfs(Boolean.FALSE);
                    saleOrderPo.setDfsStatus(null);
                    saleOrderPo.setSaleOrderType(orderType);
                    saleOrderPo.setDeliverWarehouseCode(occupyDetailDtos.get(0).getDeliverWarehouseCode());
                    saleOrderPo.setTransferAdvice(occupyDetailDtos.get(0).getTransferAdvice());
                    saleOrderPo.setStoreCode(purchaseOrderPo.getStoreCode());
                    saleOrderPo.setReceiveWarehouseCode(purchaseOrderPo.getReceiveWarehouseCode());
                    saleOrderPo.setReceiver(purchaseOrderPo.getReceiver());
                    saleOrderPo.setReceiverPhone(purchaseOrderPo.getReceiverPhone());
                    saleOrderPo.setReceiverProvince(purchaseOrderPo.getReceiverProvince());
                    saleOrderPo.setReceiverCity(purchaseOrderPo.getReceiverCity());
                    saleOrderPo.setReceiverDistrict(purchaseOrderPo.getReceiverDistrict());
                    saleOrderPo.setReceiverAddress(purchaseOrderPo.getReceiverAddress());
                    saleOrderPo.setCreateUser(OperateUserEnum.SPS.getName());
                    saleOrderPo.setSaleOrderStatus(SaleOrderStatusEnum.WAIT_ISSUED.getCode());

                    if (PurchaseOrderTypeEnum.STK.getValue().equals(orderType)) {

                        // 获取门店订单日历生成最近一个下发时间
                        Optional<LocalDateTime> localDateTimeOpt = orderCalendarService.recentlyIssueTime(purchaseOrderPo.getBizType(), purchaseOrderPo.getStoreCode());
                        String recentlyPlanTime = localDateTimeOpt.map(dateTime -> DateUtils.getLocalDateTimeStr(dateTime, DateUtils.STANDARD_TIME_FORMAT)).orElse("");
                        saleOrderPo.setPlanIssueTime(recentlyPlanTime);
                    }

                    Map<String, PurchaseOrderDetailPo> detailMap =
                            contextDto.getPurchaseOrderDetails().stream().collect(toMap(PurchaseOrderDetailPo::getSalePartNum, item -> item));

                    List<SaleOrderDetailPo> saleOrderDetailPos = occupyDetailDtos.stream().map(item -> {
                        SaleOrderDetailPo saleOrderDetailPo = new SaleOrderDetailPo();
                        saleOrderDetailPo.setBizType(saleOrderPo.getBizType());
                        saleOrderDetailPo.setSaleOrderNo(saleOrderPo.getSaleOrderNo());
                        saleOrderDetailPo.setSalePartNum(item.getSalePartNum());
                        saleOrderDetailPo.setQty(item.getQuantity());
                        saleOrderDetailPo.setDeliverQty(BigDecimal.ZERO);
                        saleOrderDetailPo.setReceiveQty(BigDecimal.ZERO);
                        saleOrderDetailPo.setCreateUser(OperateUserEnum.SPS.getName());
                        return saleOrderDetailPo;
                    }).collect(Collectors.toList());

                    BigDecimal saleOrderAmount = saleOrderDetailPos.stream()
                            .map(item -> detailMap.get(item.getSalePartNum()).getDiscountUnitPrice().multiply(item.getQty()))
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
                    saleOrderPo.setSaleOrderAmount(saleOrderAmount);
                    contextDto.getSaleOrders().add(saleOrderPo);

                    //特殊处理 定制件 销售订单明细备注需要附带采购订单明细备注
                    if (PurchaseOrderTypeEnum.CO.getValue().equals(orderType)) {
                        //采购订单明细只会有一条
                        List<PurchaseOrderDetailPo> list = purchaseOrderDetailService.list(Wrappers.<PurchaseOrderDetailPo>lambdaQuery()
                                .eq(PurchaseOrderDetailPo::getBizType, purchaseOrderPo.getBizType())
                                .eq(PurchaseOrderDetailPo::getPurchaseOrderNo, purchaseOrderPo.getPurchaseOrderNo())
                        );

                        //防止不止一条或无数据
                        if (CollUtil.isNotEmpty(list)) {
                            SaleOrderDetailPo saleOrderDetailPo = saleOrderDetailPos.get(0);
                            saleOrderDetailPo.setRemark(list.get(0).getStoreRemark());
                        }
                    }

                    contextDto.getSaleOrderDetails().addAll(saleOrderDetailPos);
                });
    }


    @Override
    public void batchInsertSaleOrder(PurchaseOrderTransferContextDto contextDto) {
        contextDto.getSaleOrders().forEach(item -> baseMapper.insert(item));
        contextDto.getSaleOrderDetails().forEach(item -> saleOrderDetailMapper.insert(item));
    }

    @Override
    public List<SaleOrderPo> listSaleOrderPo(String purchaseOrderNo) {
        return baseMapper.selectList(Wrappers.lambdaQuery(SaleOrderPo.class)
                .eq(SaleOrderPo::getPurchaseOrderNo, purchaseOrderNo));
    }

    @Override
    public void transferOrder(OperateEnum operateEnum, Long saleOrderId) {
        SaleOrderPo saleOrderPo = baseMapper.selectById(saleOrderId);
        if (!Boolean.TRUE.equals(saleOrderPo.getIsDfs())) {
            throw new BizException(SpsResponseCodeEnum.OPERATE_NOT_SUPPORTED);
        }

        String redisKey = String.format(BaseConstants.RedisKey.SALE_ORDER_TRANSFER_KEY, saleOrderId);
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            if (!SaleOrderDfsStatusEnum.canTransfer(saleOrderPo.getDfsStatus())) {
                throw new BizException(SpsResponseCodeEnum.OPERATE_NOT_SUPPORTED);
            }
            createDfsOrderPlan(operateEnum, saleOrderPo);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void dhlOutBound(Long saleOrderId) {
        SaleOrderPo saleOrderPo = baseMapper.selectById(saleOrderId);
        if (Boolean.TRUE.equals(saleOrderPo.getIsDfs())) {
            throw new BizException(SpsResponseCodeEnum.OPERATE_NOT_SUPPORTED);
        }
        spsClient.getLogisticsPo(saleOrderPo); // 只为触发检查，不存在则发送消息通知
        outboxMessageService.saveMessage(SALE_ORDER_DHL_OUT_BOUND, JsonUtil.toJsonString(saleOrderPo));
        //出库关联清单
        outboxMessageService.saveMessage(STOCK_OUT_MAP_BUSINESS_TO_SPS, JsonUtil.toJsonString(createStockOutMapBusinessDto(saleOrderPo)));
    }

    @Override
    public Map<String, SaleOrderPo> mapSaleOrderPo(List<String> saleOrderNos) {
        if (CollectionUtils.isEmpty(saleOrderNos)) {
            return Maps.newHashMap();
        }
        return saleOrderMapper.selectList(Wrappers.lambdaQuery(SaleOrderPo.class)
                        .in(SaleOrderPo::getSaleOrderNo, saleOrderNos))
                .stream().collect(toMap(SaleOrderPo::getSaleOrderNo, Function.identity(), (p, n) -> n));
    }

    @Override
    public void builderSaleOrderPos(BackOrderTransferContextDto contextDto) {
        if (CollectionUtils.isEmpty(contextDto.getOccupyDetails())) {
            return;
        }

        PurchaseOrderPo purchaseOrderPo = contextDto.getPurchaseOrder();
        // BO 转单都是 同一个PO 下的
        contextDto.getOccupyDetails().stream()
                .collect(Collectors.groupingBy(item -> item.getDeliverWarehouseCode().concat(item.getTransferAdvice())))
                .values()
                .forEach(occupyDetailDtos -> {
                    if (CollectionUtils.isEmpty(occupyDetailDtos)) {
                        return;
                    }
                    //存在 po 管控件转单 一个 po 下有多个 相同零件的bo 单 一起转单的情况


                    SaleOrderPo saleOrderPo = new SaleOrderPo();
                    saleOrderPo.setBizType(purchaseOrderPo.getBizType());
                    saleOrderPo.setPurchaseOrderNo(purchaseOrderPo.getPurchaseOrderNo());
                    saleOrderPo.setSaleOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.SO, purchaseOrderPo.getBizType()));
                    saleOrderPo.setIsDfs(Boolean.FALSE);
                    saleOrderPo.setDfsStatus(null);
                    saleOrderPo.setSaleOrderStatus(SaleOrderStatusEnum.WAIT_ISSUED.getCode());
                    saleOrderPo.setSaleOrderType(purchaseOrderPo.getPurchaseOrderType());
                    saleOrderPo.setDeliverWarehouseCode(occupyDetailDtos.get(0).getDeliverWarehouseCode());
                    saleOrderPo.setTransferAdvice(occupyDetailDtos.get(0).getTransferAdvice());
                    saleOrderPo.setStoreCode(purchaseOrderPo.getStoreCode());
                    saleOrderPo.setReceiveWarehouseCode(purchaseOrderPo.getReceiveWarehouseCode());
                    saleOrderPo.setReceiver(purchaseOrderPo.getReceiver());
                    saleOrderPo.setReceiverPhone(purchaseOrderPo.getReceiverPhone());
                    saleOrderPo.setReceiverProvince(purchaseOrderPo.getReceiverProvince());
                    saleOrderPo.setReceiverCity(purchaseOrderPo.getReceiverCity());
                    saleOrderPo.setReceiverDistrict(purchaseOrderPo.getReceiverDistrict());
                    saleOrderPo.setReceiverAddress(purchaseOrderPo.getReceiverAddress());
                    saleOrderPo.setCreateUser(OperateUserEnum.SPS.getName());

                    if (PurchaseOrderTypeEnum.STK.getValue().equals(purchaseOrderPo.getPurchaseOrderType())) {

                        // 获取门店订单日历生成最近一个下发时间
                        Optional<LocalDateTime> localDateTimeOpt = orderCalendarService.recentlyIssueTime(purchaseOrderPo.getBizType(), purchaseOrderPo.getStoreCode());
                        String recentlyPlanTime = localDateTimeOpt.map(dateTime -> DateUtils.getLocalDateTimeStr(dateTime, DateUtils.STANDARD_TIME_FORMAT)).orElse("");
                        saleOrderPo.setPlanIssueTime(recentlyPlanTime);
                    }

                    Map<String, PurchaseOrderDetailPo> poDetailMap = purchaseOrderDetailService.mapPurchaseOrderDetail(purchaseOrderPo.getPurchaseOrderNo());

                    List<SaleOrderDetailPo> saleOrderDetailPos = new ArrayList<>(occupyDetailDtos.stream().map(item -> {
                        SaleOrderDetailPo saleOrderDetailPo = new SaleOrderDetailPo();
                        saleOrderDetailPo.setBizType(saleOrderPo.getBizType());
                        saleOrderDetailPo.setSaleOrderNo(saleOrderPo.getSaleOrderNo());
                        saleOrderDetailPo.setSalePartNum(item.getSalePartNum());
                        saleOrderDetailPo.setQty(item.getQuantity());
                        saleOrderDetailPo.setDeliverQty(BigDecimal.ZERO);
                        saleOrderDetailPo.setReceiveQty(BigDecimal.ZERO);
                        saleOrderDetailPo.setCreateUser(OperateUserEnum.SPS.getName());
                        return saleOrderDetailPo;
                    }).collect(toMap(SaleOrderDetailPo::getSalePartNum, Function.identity(), (p, n) -> {
                        p.setQty(p.getQty().add(n.getQty()));
                        return p;
                    })).values());

                    BigDecimal saleOrderAmount = saleOrderDetailPos.stream()
                            .map(item -> poDetailMap.get(item.getSalePartNum()).getDiscountUnitPrice().multiply(item.getQty()))
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
                    saleOrderPo.setSaleOrderAmount(saleOrderAmount);
                    contextDto.getSaleOrders().add(saleOrderPo);

                    contextDto.getSaleOrderDetails().addAll(saleOrderDetailPos);

                    List<BackSaleRelationPo> backSaleRelationPos = occupyDetailDtos.stream().map(item -> {
                        BackSaleRelationPo backSaleRelationPo = new BackSaleRelationPo();
                        backSaleRelationPo.setBizType(saleOrderPo.getBizType());
                        backSaleRelationPo.setBackOrderNo(item.getBackOrderNo());
                        backSaleRelationPo.setSaleOrderNo(saleOrderPo.getSaleOrderNo());
                        backSaleRelationPo.setCreateUser(OperateUserEnum.SPS.getName());
                        return backSaleRelationPo;
                    }).collect(Collectors.toList());
                    contextDto.getBackSaleRelationPos().addAll(backSaleRelationPos);
                });
    }

    @Override
    public void batchInsertSaleOrder(BackOrderTransferContextDto contextDto) {
        contextDto.getSaleOrders().forEach(item -> {
            baseMapper.insert(item);
            SaleOrderMessageDto saleOrderMessageDto = BeanCopierUtil.copy(item, SaleOrderMessageDto.class);
            outboxMessageService.saveMessage(SALE_ORDER_STATUS_CHANGE, JsonUtil.toJsonString(saleOrderMessageDto));
        });
        contextDto.getSaleOrderDetails().forEach(item -> saleOrderDetailMapper.insert(item));
        contextDto.getBackSaleRelationPos().forEach(item -> backSaleRelationMapper.insert(item));
    }


    @Override
    public boolean updateStockOutTime(String saleOrderNo, LocalDateTime stockOutTime) {
        log.info("SaleOrderServiceImpl#updateStockOutTime saleOrderNo: {}, stockOutTime: {}", saleOrderNo, stockOutTime);
        SaleOrderPo saleOrderPo = baseMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class).eq(SaleOrderPo::getSaleOrderNo, saleOrderNo));
        if (saleOrderPo == null) {
            return false;
        }
        String stockOutTimeStr = DateUtils.format(stockOutTime, DateUtils.STANDARD_TIME_FORMAT);
        saleOrderPo.setStockOutTime(stockOutTimeStr);
        String estArrivalTime = getEstArrivalTime(saleOrderPo);
        int row = baseMapper.update(null, Wrappers.lambdaUpdate(SaleOrderPo.class)
                .set(StringUtils.isNotEmpty(estArrivalTime), SaleOrderPo::getEstArrivalTime, estArrivalTime)
                .set(SaleOrderPo::getStockOutTime, stockOutTimeStr)
                .eq(SaleOrderPo::getId, saleOrderPo.getId()));
        return row > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateLogisticsNo(String saleOrderNo, String logisticsNo, String transportType) {
        log.info("SaleOrderServiceImpl#updateLogisticsNo saleOrderNo: {}, logisticsNo: {}", saleOrderNo, logisticsNo);
        SaleOrderPo saleOrderPo = baseMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class).eq(SaleOrderPo::getSaleOrderNo, saleOrderNo));
        if (saleOrderPo == null) {
            return false;
        }
        int row = baseMapper.update(null, Wrappers.lambdaUpdate(SaleOrderPo.class)
                .set(SaleOrderPo::getLogisticsNo, StringUtils.defaultIfNull(logisticsNo))
                .set(SaleOrderPo::getTransportType, StringUtils.defaultIfNull(transportType))
                .eq(SaleOrderPo::getSaleOrderNo, saleOrderNo));
        return row > 0;
    }

    @Override
    public Map<String, BigDecimal> checkDeliverQty(String saleOrderNo, List<StockOutItemQuantityDto> outQuantityList) {
        log.info("SaleOrderServiceImpl#checkDeliverQty saleOrderNo: {}, outQuantityList: {}", saleOrderNo, JsonUtil.toJsonString(outQuantityList));
        SaleOrderPo saleOrderPo = baseMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class).eq(SaleOrderPo::getSaleOrderNo, saleOrderNo));
        if (saleOrderPo == null) {
            throw new BizException("销售订单不存在" + saleOrderNo);
        }
        if (!SaleOrderStatusEnum.PENDING_DELIVERY.getCode().equals(saleOrderPo.getSaleOrderStatus())) {
            throw new BizException("销售订单状态不支持收货操作" + saleOrderNo);
        }
        List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                .eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderPo.getSaleOrderNo()));
        if (CollectionUtils.isEmpty(saleOrderDetailPos)) {
            throw new BizException("销售订单明细不存在" + saleOrderNo);
        }
        Map<String, BigDecimal> orderQtyMap = saleOrderDetailPos.stream().collect(toMap(SaleOrderDetailPo::getSalePartNum, SaleOrderDetailPo::getQty, BigDecimal::add));
        Map<String, BigDecimal> deliverQtyMap = Optional.ofNullable(outQuantityList).map(Collection::stream).orElse(Stream.empty())
                .filter(item -> Objects.nonNull(item.getSalePartNum()) && Objects.nonNull(item.getQuantity()))
                .collect(toMap(StockOutItemQuantityDto::getSalePartNum, StockOutItemQuantityDto::getQuantity, BigDecimal::add));
        for (Map.Entry<String, BigDecimal> deliverQtyEntry : deliverQtyMap.entrySet()) {
            BigDecimal orderQty = orderQtyMap.get(deliverQtyEntry.getKey());
            if (orderQty == null) {
                throw new BizException("出库物料不在订单明细内" + deliverQtyEntry.getKey());
            } else if (orderQty.compareTo(deliverQtyEntry.getValue()) < 0) {
                throw new BizException("出库物料数量大于订单数量" + deliverQtyEntry.getKey());
            }
        }
        return orderQtyMap;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateDeliverQty(String saleOrderNo, List<StockOutItemQuantityDto> outQuantityList) {
        log.info("SaleOrderServiceImpl#updateDeliverQty saleOrderNo: {}, outQuantityList: {}", saleOrderNo, JsonUtil.toJsonString(outQuantityList));

        String redisKey = String.format(BaseConstants.RedisKey.SALE_ORDER_UPDATE_DELIVER_QTY, saleOrderNo);
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            SaleOrderPo saleOrderPo = baseMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class).eq(SaleOrderPo::getSaleOrderNo, saleOrderNo));
            if (saleOrderPo == null) {
                return false;
            }
            if (SaleOrderStatusEnum.DELIVERED.getCode().equals(saleOrderPo.getSaleOrderStatus())) {
                return true;
            }
            List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                    .eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderPo.getSaleOrderNo()));
            if (CollectionUtils.isEmpty(saleOrderDetailPos)) {
                return false;
            }
            updateStatusAndSendMessage(SaleOrderStatusChangeDto.builder()
                    .saleOrderPo(saleOrderPo)
                    .newStatusEnum(SaleOrderStatusEnum.DELIVERED)
                    .operateEnum(OperateEnum.DHL_DELIVERED)
                    .operateUser(OperateUserEnum.DHL.getName())
                    .build());

            Map<String, BigDecimal> deliverQtyMap = Optional.ofNullable(outQuantityList).map(Collection::stream).orElse(Stream.empty())
                    .filter(item -> Objects.nonNull(item.getSalePartNum()) && Objects.nonNull(item.getQuantity()))
                    .collect(toMap(StockOutItemQuantityDto::getSalePartNum, StockOutItemQuantityDto::getQuantity, BigDecimal::add));
            // 管控件数据以当时采购订单明细里的为准
            Map<String, PurchaseOrderDetailPo> partMap = purchaseOrderDetailService.list(Wrappers.lambdaQuery(PurchaseOrderDetailPo.class)
                            .eq(PurchaseOrderDetailPo::getPurchaseOrderNo, saleOrderPo.getPurchaseOrderNo()))
                    .stream().collect(toMap(PurchaseOrderDetailPo::getSalePartNum, Function.identity()));
            for (SaleOrderDetailPo saleOrderDetailPo : saleOrderDetailPos) {
                BigDecimal deliverQty = deliverQtyMap.getOrDefault(saleOrderDetailPo.getSalePartNum(), BigDecimal.ZERO);
                saleOrderDetailPo.setDeliverQty(deliverQty);

                BackOrderPo backOrderPo = null;
                if (deliverQty.compareTo(saleOrderDetailPo.getQty()) < 0) {
                    backOrderPo = backOrderService.builderAndSaveBackOrderPo(saleOrderPo, saleOrderDetailPo, partMap);
                }

                saleOrderDetailMapper.update(null, Wrappers.lambdaUpdate(SaleOrderDetailPo.class)
                        .set(SaleOrderDetailPo::getDeliverQty, deliverQty)
                        .set(Objects.nonNull(backOrderPo), SaleOrderDetailPo::getRemark, Objects.nonNull(backOrderPo) ? backOrderPo.getBackOrderNo() : StringUtils.EMPTY)
                        .set(SaleOrderDetailPo::getUpdateUser, OperateUserEnum.DHL.getName())
                        .eq(SaleOrderDetailPo::getId, saleOrderDetailPo.getId()));
            }
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
        return true;
    }

    @Override
    public void batchUpdateEstArrivalTime() {
        List<SaleOrderPo> saleOrderPos = baseMapper.selectList(Wrappers.lambdaQuery(SaleOrderPo.class)
                .eq(SaleOrderPo::getIsDfs, Boolean.FALSE)
                .ne(SaleOrderPo::getStockOutTime, StringUtils.EMPTY_STRING)
                .eq(SaleOrderPo::getEstArrivalTime, StringUtils.EMPTY_STRING)
                .last(String.format("limit %d", BATCH_SIZE)));
        for (SaleOrderPo saleOrderPo : saleOrderPos) {
            String estArrivalTime = getEstArrivalTime(saleOrderPo);
            if (StringUtils.isEmpty(estArrivalTime)) {
                continue;
            }
            baseMapper.update(null, Wrappers.lambdaUpdate(SaleOrderPo.class)
                    .set(SaleOrderPo::getEstArrivalTime, estArrivalTime)
                    .eq(SaleOrderPo::getId, saleOrderPo.getId()));
        }
    }

    @MessageHandle(SALE_ORDER_STATUS_CHANGE)
    public Result sendSaleOrderStatusChangeMessage(OutboxMessage outboxMessage) {
        SaleOrderMessageDto messageDto = JsonUtil.toObject(outboxMessage.getContent(), SaleOrderMessageDto.class);
        String msgTag = SaleOrderStatusEnum.getMsgTag(messageDto.getSaleOrderStatus());
        if (StringUtils.isEmpty(msgTag)) {
            throw new BizException("消息tag未设置");
        }
        rocketMQTemplate.syncSend(BaseConstants.RocketMqTopic.SALE_ORDER.concat(":").concat(msgTag), messageDto);
        return Result.success();
    }

    @MessageHandle(SALE_ORDER_DHL_OUT_BOUND)
    public Result dhlOutBoundHandle(OutboxMessage outboxMessage) {
        SaleOrderPo saleOrderPo = JsonUtil.toObject(outboxMessage.getContent(), SaleOrderPo.class);
        DHLOutboundReq dhlOutboundReq = buildDhlOutBoundReq(saleOrderPo, BaseConstants.OperateType.ADD);
        ResultResp<Object> BaseResult = pdpClient.outbound(dhlOutboundReq);
        log.info("SaleOrderServiceImpl#dhlOutBoundHandle outbound, param: {}, result: {}", JsonUtil.toJsonString(dhlOutboundReq), JsonUtil.toJsonString(BaseResult));
        if (Objects.equals(500, BaseResult.getCode())) {
            // pdp 网关报错 code == 500
            log.error("SaleOrderServiceImpl#dhlOutBoundHandle outbound error, param: {}, result: {}", JsonUtil.toJsonString(dhlOutboundReq), JsonUtil.toJsonString(BaseResult));
        }
        return BaseResult.isSuccess() ? Result.success() : Result.error(JsonUtil.toJsonString(BaseResult));
    }


    /**
     * 构建 出库关联订单请求体
     *
     * @param po
     * @return
     */
    private StockOutMapBusinessDto createStockOutMapBusinessDto(SaleOrderPo po) {
        List<StockOutMapBusinessItemDto> itemDtos = new ArrayList<>();
        StockOutMapBusinessDto dto = new StockOutMapBusinessDto();
        dto.setBizType(po.getBizType());
        dto.setOrderNo(po.getSaleOrderNo());
        dto.setOperateType(OperateTypeEnum.SAVE);
        dto.setBusinessNo(po.getPurchaseOrderNo());
        dto.setOutType(StockOperationType.SP20.getOperationType());
        dto.setOrderType(po.getSaleOrderType());
        dto.setStoreCode(po.getStoreCode());
        dto.setTargetCity(po.getReceiverCity());
        dto.setTargetAddress(po.getReceiverAddress());
        dto.setRemark(po.getRemark());
        dto.setShippingMethod(po.getTransferAdvice());
        dto.setOrderDate(DateUtils.getLocalDateTimeStr(po.getCreateTime(), DateUtils.STANDARD_TIME_FORMAT));
        List<SaleOrderDetailPo> itemPos = saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                .eq(SaleOrderDetailPo::getSaleOrderNo, po.getSaleOrderNo())
                .eq(SaleOrderDetailPo::getBizType, po.getBizType()));
        for (SaleOrderDetailPo itemPo : itemPos) {
            StockOutMapBusinessItemDto itemDto = new StockOutMapBusinessItemDto();
            itemDto.setBizType(itemPo.getBizType());
            itemDto.setOrderNo(po.getSaleOrderNo());
            itemDto.setWarehouseCode(po.getDeliverWarehouseCode());
            itemDto.setMaterialCode(itemPo.getSalePartNum());
            itemDto.setPlanQuantity(itemPo.getQty());
            itemDto.setRemark(itemPo.getRemark());
            itemDtos.add(itemDto);
        }
        dto.setDtos(itemDtos);
        return dto;
    }

    /**
     * 构建 取消 出库关联订单请求体
     *
     * @param po
     * @return
     */
    private StockOutMapBusinessDto cancelStockOutMapBusinessDto(SaleOrderPo po) {
        List<StockOutMapBusinessItemDto> itemDtos = new ArrayList<>();
        StockOutMapBusinessDto dto = new StockOutMapBusinessDto();
        dto.setOrderNo(po.getSaleOrderNo());
        dto.setOperateType(OperateTypeEnum.CANCEL);
        dto.setDtos(itemDtos);
        return dto;
    }


    @SuppressWarnings("OptionalGetWithoutIsPresent")
    @Override
    public DHLOutboundReq buildDhlOutBoundReq(SaleOrderPo saleOrderPo, String type) {
        List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class).eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderPo.getSaleOrderNo()));
        Map<String, PurchaseOrderDetailPo> purchaseOrderDetailPoMap = purchaseOrderDetailService.mapPurchaseOrderDetail(saleOrderPo.getPurchaseOrderNo());

        StorePo storePo = baseDataQuery.getStorePo(saleOrderPo.getBizType(), saleOrderPo.getStoreCode()).get();
        WarehousePo warehousePo = baseDataQuery.getWarehousePo(BizTypeEnum.getNewBizType(saleOrderPo.getBizType()), saleOrderPo.getReceiveWarehouseCode()).get();
        Map<String, String> mapLocationMap = baseDataQuery.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());

        DHLOutboundReq req = new DHLOutboundReq();
        req.setBizType(saleOrderPo.getBizType());
        req.setOutboundBillNo(saleOrderPo.getSaleOrderNo());
        req.setRelatedOrderNo(saleOrderPo.getPurchaseOrderNo());
        req.setOutboundType(saleOrderPo.getBizType().concat("20"));
        req.setOrderTime(saleOrderPo.getCreateTime());
        req.setOperateType(type);
        req.setOrderType(saleOrderPo.getSaleOrderType());
        req.setTransferAdvice(saleOrderPo.getTransferAdvice());
        req.setDeliverWarehouseCode(saleOrderPo.getDeliverWarehouseCode());
        req.setStoreCode(saleOrderPo.getStoreCode());
        if (Objects.nonNull(storePo)) {
            req.setStoreName(storePo.getStoreName());
        }
        if (Objects.nonNull(warehousePo)) {
            req.setReceiveWarehouseName(warehousePo.getName());
        }
        req.setReceiver(saleOrderPo.getReceiver());
        req.setReceiverPhone(saleOrderPo.getReceiverPhone());
        req.setReceiverProvince(mapLocationMap.get(saleOrderPo.getReceiverProvince()));
        req.setReceiverCity(mapLocationMap.get(saleOrderPo.getReceiverCity()));
        req.setReceiverDistrict(mapLocationMap.get(saleOrderPo.getReceiverDistrict()));
        req.setReceiverAddress(saleOrderPo.getReceiverAddress());
        List<DHLOutboundReq.Detail> details = saleOrderDetailPos.stream().map(item -> {
            DHLOutboundReq.Detail detail = new DHLOutboundReq.Detail();
            detail.setLineNo(item.getId().toString());
            detail.setSalePartNum(item.getSalePartNum());
            if (PurchaseOrderTypeEnum.CO.getValue().equals(saleOrderPo.getSaleOrderType())) {
                PurchaseOrderDetailPo purchaseOrderDetailPo = purchaseOrderDetailPoMap.get(item.getSalePartNum());
                if (Objects.nonNull(purchaseOrderDetailPo)) {
                    detail.setVin(purchaseOrderDetailPo.getVin());
                }
            }
            detail.setQuantity(item.getQty());
            detail.setMaterialStatus(MaterialStatusEnum.NORMAL.getValue());
            detail.setStockStatus(BaseConstants.StockStatus.NORMAL);
            return detail;
        }).collect(Collectors.toList());
        req.setDetailList(details);
        return req;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createPrOrder(CreatePrOrderReq req, OperateEnum operateEnum, SaleOrderPo saleOrderPo) {
        saleOrderMapper.update(null, Wrappers.lambdaUpdate(SaleOrderPo.class)
                .set(SaleOrderPo::getDfsStatus, SaleOrderDfsStatusEnum.TRANSFER_SUCCESSFUL.getCode())
                .set(BasePo::getRemark, StringUtils.EMPTY)
                .eq(SaleOrderPo::getId, saleOrderPo.getId()));

        saleOrderOperateLogService.saveStatusChangeLog(SaleOrderDfsStatusChangeDto.builder()
                .operateEnum(operateEnum)
                .saleOrderPo(saleOrderPo)
                .newDfsStatusEnum(SaleOrderDfsStatusEnum.TRANSFER_SUCCESSFUL)
                .operateUser(getOperateUser(operateEnum))
                .build());
        spsClient.createPurchaseApply(req).check();
    }

    //todo 临时更改方法名称
    private void createDfsOrderPlan(OperateEnum operateEnum, SaleOrderPo saleOrderPo) {
        PurchaseOrderPo poOne = purchaseOrderService.getOne(Wrappers.<PurchaseOrderPo>lambdaQuery()
                .eq(PurchaseOrderPo::getPurchaseOrderNo, saleOrderPo.getPurchaseOrderNo())
        );

        List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                .eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderPo.getSaleOrderNo())
        );

        try {
            CreatePrOrderReq req = new CreatePrOrderReq();
            req.setPurchaseOrderPo(poOne);
            req.setOperateEnumDesc(operateEnum.getDesc());
            req.setSaleOrderDetailPos(saleOrderDetailPos);
            req.setSaleOrderPo(saleOrderPo);
            req.setPrType(PRTypeEnum.DFS.getCode());
            saleOrderService.createPrOrder(req, operateEnum, saleOrderPo);
        } catch (Exception e) {
            String remark = StringUtils.cutString(e.getMessage(), 500);

            saleOrderMapper.update(null, Wrappers.lambdaUpdate(SaleOrderPo.class)
                    .set(SaleOrderPo::getDfsStatus, SaleOrderDfsStatusEnum.TRANSFER_FAILED.getCode())
                    .set(SaleOrderPo::getRemark, StringUtils.defaultIfNull(remark))
                    .eq(SaleOrderPo::getId, saleOrderPo.getId()));

            saleOrderOperateLogService.saveStatusChangeLog(SaleOrderDfsStatusChangeDto.builder()
                    .operateEnum(operateEnum)
                    .saleOrderPo(saleOrderPo)
                    .remark(remark)
                    .newDfsStatusEnum(SaleOrderDfsStatusEnum.TRANSFER_FAILED)
                    .operateUser(getOperateUser(operateEnum))
                    .build());

            throw new BizException(remark);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStatusAndSendMessage(SaleOrderStatusChangeDto statusChangeDto) {
        if (!statusChangeDto.getNewStatusEnum().getCode().equals(statusChangeDto.getSaleOrderPo().getSaleOrderStatus())) {
            saleOrderOperateLogService.saveStatusChangeLog(statusChangeDto);
            saleOrderMapper.update(null, Wrappers.lambdaUpdate(SaleOrderPo.class)
                    .set(SaleOrderPo::getSaleOrderStatus, statusChangeDto.getNewStatusEnum().getCode())
                    .set(statusChangeDto.getNewStatusEnum() == SaleOrderStatusEnum.PENDING_DELIVERY,
                            SaleOrderPo::getIssuedTime,
                            DateUtils.format(LocalDateTime.now(), DateUtils.STANDARD_TIME_FORMAT)
                    )
                    .set(SaleOrderPo::getUpdateUser, StringUtils.defaultIfNull(statusChangeDto.getOperateUser()))
                    .eq(SaleOrderPo::getId, statusChangeDto.getSaleOrderPo().getId()));
            SaleOrderMessageDto saleOrderMessageDto = BeanCopierUtil.copy(statusChangeDto.getSaleOrderPo(), SaleOrderMessageDto.class);
            saleOrderMessageDto.setSaleOrderStatus(statusChangeDto.getNewStatusEnum().getCode());
            outboxMessageService.saveMessage(SALE_ORDER_STATUS_CHANGE, JsonUtil.toJsonString(saleOrderMessageDto));
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateReceiveQty(String saleOrderNo, List<StockInItemQuantityDto> inQuantityList) {
        log.info("SaleOrderServiceImpl#updateReceiveQty saleOrderNo: {}, outQuantityList: {}", saleOrderNo, JsonUtil.toJsonString(inQuantityList));

        String redisKey = String.format(BaseConstants.RedisKey.SALE_ORDER_UPDATE_RECEIVE_QTY, saleOrderNo);
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            SaleOrderPo saleOrderPo = baseMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class).eq(SaleOrderPo::getSaleOrderNo, saleOrderNo));
            if (saleOrderPo == null) {
                throw new BizException("销售订单不存在：" + saleOrderNo);
            }
            if (SaleOrderStatusEnum.PARTIALLY_RECEIVED.getCode().equals(saleOrderPo.getSaleOrderStatus())
                    || SaleOrderStatusEnum.FULLY_RECEIVED.getCode().equals(saleOrderPo.getSaleOrderStatus())) {
                throw new BizException(DUPLICATE_OPERATE);
            }
            List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                    .eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderPo.getSaleOrderNo()));
            if (CollectionUtils.isEmpty(saleOrderDetailPos)) {
                throw new BizException("销售订单明细不存在：" + saleOrderNo);
            }

            Map<String, BigDecimal> receiveQtyMap = Optional.ofNullable(inQuantityList).map(Collection::stream).orElse(Stream.empty())
                    .filter(item -> Objects.nonNull(item.getSalePartNum()) && Objects.nonNull(item.getQuantity()))
                    .collect(toMap(StockInItemQuantityDto::getSalePartNum, StockInItemQuantityDto::getQuantity, BigDecimal::add));

            SaleOrderStatusEnum saleOrderStatusEnum = SaleOrderStatusEnum.FULLY_RECEIVED;
            for (SaleOrderDetailPo saleOrderDetailPo : saleOrderDetailPos) {
                BigDecimal receiveQty = receiveQtyMap.getOrDefault(saleOrderDetailPo.getSalePartNum(), BigDecimal.ZERO);
                if (receiveQty.compareTo(saleOrderDetailPo.getDeliverQty()) > 0) {
                    throw new BizException("销售订单收货数量大于发货数量：" + saleOrderNo);
                }
                if (receiveQty.compareTo(saleOrderDetailPo.getDeliverQty()) < 0) {
                    saleOrderStatusEnum = SaleOrderStatusEnum.PARTIALLY_RECEIVED;
                }

                saleOrderDetailMapper.update(null, Wrappers.lambdaUpdate(SaleOrderDetailPo.class)
                        .set(SaleOrderDetailPo::getReceiveQty, receiveQty)
                        .set(SaleOrderDetailPo::getUpdateUser, OperateUserEnum.ODIN.getName())
                        .eq(SaleOrderDetailPo::getId, saleOrderDetailPo.getId()));
            }

            //更新采购订单状态
            purchaseOrderService.updateStateByReceiveQtyAndCancelQty(saleOrderPo.getPurchaseOrderNo(), saleOrderPo.getBizType());

            updateStatusAndSendMessage(SaleOrderStatusChangeDto.builder()
                    .saleOrderPo(saleOrderPo)
                    .newStatusEnum(saleOrderStatusEnum)
                    .operateEnum(OperateEnum.ODIN_RECEIVED)
                    .operateUser(OperateUserEnum.ODIN.getName())
                    .build());
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    /**
     * 待发货订单取消
     */
    private void pendingDeliveryCancel(SaleOrderPo saleOrderPo) {
        //dfs 取消不走 dhl
        if (!saleOrderPo.getIsDfs()) {
            DHLOutboundReq dhlOutboundReq = buildDhlOutBoundReq(saleOrderPo, BaseConstants.OperateType.CANCEL);
            ResultResp<Object> BaseResult = pdpClient.outbound(dhlOutboundReq);
            if (!BaseResult.isSuccess()) {
                Map<String, String> msgMap = webhookUtil.buildMsgMap(
                        noticedDtoConvertor.buildNoticedDto(saleOrderPo, BaseResult.getMsg(),
                                BaseConstants.MessageTitle.SALE_ORDER_CANCEL_PUSH_DHL));
                webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap),
                        BaseConstants.MessageTitle.SALE_ORDER_CANCEL_PUSH_DHL);
                throw new BizException("取消失败");
            }
            //出库关联清单
            outboxMessageService.saveMessage(STOCK_OUT_MAP_BUSINESS_TO_SPS, JsonUtil.toJsonString(cancelStockOutMapBusinessDto(saleOrderPo)));
        }

        sendCancelMessage(saleOrderPo);
    }

    private void sendCancelMessage(SaleOrderPo saleOrderPo) {
        saleOrderPo.setSaleOrderStatus(SaleOrderStatusEnum.CANCELED.getCode());
        SaleOrderMessageDto messageDto = BeanCopierUtil.copy(saleOrderPo, SaleOrderMessageDto.class);
        String msgTag = SaleOrderStatusEnum.getMsgTag(messageDto.getSaleOrderStatus());
        saleOrderOperateLogService.saveStatusChangeLog(SaleOrderStatusChangeDto.builder()
                .operateEnum(OperateEnum.CANCEL)
                .saleOrderPo(saleOrderPo)
                .newStatusEnum(SaleOrderStatusEnum.CANCELED)
                .operateUser(getOperateUser(OperateEnum.CANCEL))
                .build());
        rocketMQTemplate.syncSend(BaseConstants.RocketMqTopic.SALE_ORDER.concat(":").concat(msgTag), messageDto);
        outboxMessageService.saveMessage(SALE_ORDER_CANCEL, JsonUtil.toJsonString(saleOrderPo));
    }


    @Override
    public Set<String> getAllSktBlankPlanIssueTimeStore() {
        List<SaleOrderPo> list = list(Wrappers.<SaleOrderPo>lambdaQuery()
                .eq(SaleOrderPo::getIsDel, false)
                .eq(SaleOrderPo::getPlanIssueTime, StringUtils.EMPTY_STRING)
                .eq(SaleOrderPo::getSaleOrderType, PurchaseOrderTypeEnum.STK.getValue())
                .eq(SaleOrderPo::getSaleOrderStatus, SaleOrderStatusEnum.WAIT_ISSUED.getCode())
                .last(String.format("limit %d", STORE_BATCH_SIZE))
        );

        if (CollUtil.isEmpty(list)) {
            return new HashSet<>();
        }

        return list.stream().map(o -> o.getBizType() + "+" + o.getStoreCode()).collect(Collectors.toSet());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void stkSaleOrderIssue() {
        List<SaleOrderPo> list = list(Wrappers.<SaleOrderPo>lambdaQuery()
                .eq(SaleOrderPo::getIsDel, false)
                .ne(SaleOrderPo::getPlanIssueTime, StringUtils.EMPTY_STRING)
                .le(SaleOrderPo::getPlanIssueTime, DateUtils.format(LocalDateTime.now(), DateUtils.STANDARD_TIME_FORMAT))
                .eq(SaleOrderPo::getSaleOrderType, PurchaseOrderTypeEnum.STK.getValue())
                .eq(SaleOrderPo::getSaleOrderStatus, SaleOrderStatusEnum.WAIT_ISSUED.getCode())
                .last(String.format("limit %d", BATCH_SIZE))
        );

        if (CollUtil.isEmpty(list)) {
            return;
        }

        for (SaleOrderPo po : list) {

            updateStatusAndSendMessage(SaleOrderStatusChangeDto.builder()
                    .operateEnum(OperateEnum.SCHEDULE_ISSUE_ORDER)
                    .saleOrderPo(po)
                    .newStatusEnum(SaleOrderStatusEnum.PENDING_DELIVERY)
                    .operateUser(OperateUserEnum.SPS.getName())
                    .build());
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStkOrderPlanIssueTime() {
        List<SaleOrderPo> list = list(Wrappers.<SaleOrderPo>lambdaQuery()
                .eq(SaleOrderPo::getIsDel, false)
                .eq(SaleOrderPo::getPlanIssueTime, StringUtils.EMPTY_STRING)
                .eq(SaleOrderPo::getSaleOrderType, PurchaseOrderTypeEnum.STK.getValue())
                .eq(SaleOrderPo::getSaleOrderStatus, SaleOrderStatusEnum.WAIT_ISSUED.getCode())
                .last(String.format("limit %d", BATCH_SIZE))
        );

        if (CollUtil.isEmpty(list)) return;

        List<SaleOrderPo> collect = list.stream().peek(saleOrderPo -> {
            String bizType = saleOrderPo.getBizType();
            String storeCode = saleOrderPo.getStoreCode();
            Optional<LocalDateTime> localDateTimeOpt = orderCalendarService.recentlyIssueTime(bizType, storeCode);
            String recentlyPlanTime = localDateTimeOpt.map(dateTime -> DateUtils.getLocalDateTimeStr(dateTime, DateUtils.STANDARD_TIME_FORMAT)).orElse("");
            saleOrderPo.setPlanIssueTime(recentlyPlanTime);
        }).collect(Collectors.toList());

        updateBatchById(collect);
    }

    /**
     * 当前时间是否可以下发 ro & co 订单
     */
    private boolean canIssueRoAndCoSaleOrder() {
        String[] split = issueTime.split("-");
        String dayStr = DateUtils.getLocalDateTimeStr(LocalDateTime.now(), DateUtils.STANDARD_DATE_FORMAT);
        LocalDateTime beginTime = DateUtils.parse(dayStr + " " + split[0] + ":00", DateUtils.STANDARD_TIME_FORMAT);
        LocalDateTime endTime = DateUtils.parse(dayStr + " " + split[1] + ":00", DateUtils.STANDARD_TIME_FORMAT);
        LocalDateTime now = LocalDateTime.now();
        return now.isAfter(beginTime) && now.isBefore(endTime);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void roAndCoSaleOrderIssueHandler() {
        if (!canIssueRoAndCoSaleOrder()) {
            return;
        }

        List<SaleOrderPo> list = saleOrderMapper.getNeedIssueRoAndCoSaleOrder(PurchaseOrderTypeEnum.RO.getValue(),
                PurchaseOrderTypeEnum.CO.getValue(),
                SaleOrderStatusEnum.WAIT_ISSUED.getCode());

        if (CollUtil.isEmpty(list)) {
            return;
        }

        list.forEach(i ->
                updateStatusAndSendMessage(SaleOrderStatusChangeDto.builder()
                        .operateEnum(OperateEnum.SCHEDULE_ISSUE_ORDER)
                        .saleOrderPo(i)
                        .newStatusEnum(SaleOrderStatusEnum.PENDING_DELIVERY)
                        .operateUser(OperateUserEnum.SPS.getName())
                        .build())
        );
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void issueOrder(Long saleOrderId) {
        //WAIT_ISSUED 订单都为 非dfs类型
        SaleOrderPo po = getById(saleOrderId);
        if (Objects.isNull(po)) {
            return;
        }
        String orderType = po.getSaleOrderType();

        if (PurchaseOrderTypeEnum.RO.getValue().equals(orderType) || PurchaseOrderTypeEnum.CO.getValue().equals(orderType)) {
            //ro & co 订单是否在 issueTime 内，是则立即下发，否则等待定时任务下发
            if (!canIssueRoAndCoSaleOrder()) {
                return;
            }
            updateOrderPendingDeliverAndSendMsg(po, OperateEnum.AUTO_ISSUE_ORDER);

        } else if (PurchaseOrderTypeEnum.VOR.getValue().equals(orderType)) {
            //vor 立即下发
            updateOrderPendingDeliverAndSendMsg(po, OperateEnum.AUTO_ISSUE_ORDER);
        }
        //stk -》 等待定时任务定时下发

    }

    @Transactional(rollbackFor = Exception.class)
    public void changeClaimWhitelist(SaleOrderNoAndClaimReq req) {
        if (!BizTypeEnum.SP.getBizType().equals(req.getBizType())) {
            throw new BizException(SpsResponseCodeEnum.OPERATE_NOT_SUPPORTED);
        }

        SaleOrderPo one = getOne(Wrappers.<SaleOrderPo>lambdaQuery()
                .eq(SaleOrderPo::getSaleOrderNo, req.getSaleOrderNo())
                .eq(SaleOrderPo::getBizType, req.getBizType())
        );

        if (one == null) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }

        //索赔白名单只支持全部收货的销售订单
        if (!SaleOrderStatusEnum.FULLY_RECEIVED.getCode().equals(one.getSaleOrderStatus())) {
            throw new BizException("索赔白名单设置只支持状态为全部收货的销售订单");
        }

        if (one.getIsClaimWhitelist() == req.getIsClaimWhitelist()) {
            return;
        }
        ClaimWhitelistCreateRequest claimWhitelistCreateRequest = new ClaimWhitelistCreateRequest();
        claimWhitelistCreateRequest.setSaleOrderNo(req.getSaleOrderNo());
        claimWhitelistCreateRequest.setOperateUser(UserUtil.getUserName());
        claimWhitelistCreateRequest.setStoreCode(one.getStoreCode());
        claimWhitelistCreateRequest.setWarehouseCode(one.getReceiveWarehouseCode());
        com.jiduauto.javakit.common.biz.Result<String> ret;

        if (req.getIsClaimWhitelist()) {
            ret = claimRpcService.createWhitelist(claimWhitelistCreateRequest);
        } else {
            ret = claimRpcService.cancelWhitelist(BeanUtil.copyProperties(claimWhitelistCreateRequest, ClaimWhitelistCancelRequest.class));
        }

        if (GlobalCodeEnum.GL_SUCC_0.getCode() != ret.getCode()) {
            //门店上架货物，不能设置白名单
            if (ZhiZiClaimExceptionEnum.SO_All_PUT_IN.getCode() == ret.getCode()) {
                throw new BizException(ZhiZiClaimExceptionEnum.SO_All_PUT_IN.getDesc());
            }

            log.warn("claimRpcService#createWhitelist error, param: {}，result: {}",
                    com.jiduauto.javakit.common.util.JsonUtil.ObjectToJson(claimWhitelistCreateRequest),
                    com.jiduauto.javakit.common.util.JsonUtil.ObjectToJson(ret));
            throw new BizException(GL_FAIL_DEFAULT.getCode(), ret.getMsg());
        }

        update(Wrappers.<SaleOrderPo>lambdaUpdate()
                .eq(SaleOrderPo::getBizType, req.getBizType())
                .eq(SaleOrderPo::getSaleOrderNo, req.getSaleOrderNo())
                .set(SaleOrderPo::getIsClaimWhitelist, req.getIsClaimWhitelist())
        );
    }

    /**
     * 待下发订单取消
     */
    private void waitIssuedCancel(SaleOrderPo saleOrderPo) {
        //状态变更发送mq
        sendCancelMessage(saleOrderPo);
    }


    @Override
    public PoOccupyStockReq buildPoOccupyStockReq(SaleOrderPo saleOrderPo) {
        List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailMapper.selectList(
                Wrappers.<SaleOrderDetailPo>lambdaQuery()
                        .eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderPo.getSaleOrderNo()));
        PoOccupyStockReq poOccupyStockReq = new PoOccupyStockReq();
        poOccupyStockReq.setBizType(saleOrderPo.getBizType());
        poOccupyStockReq.setBusinessNo(saleOrderPo.getSaleOrderNo());
        poOccupyStockReq.setOccupyNo(saleOrderPo.getPurchaseOrderNo());
        poOccupyStockReq.setWarehouseCode(saleOrderPo.getDeliverWarehouseCode());
        List<PoOccupyStockReq.PoOccupyStockInfo> occupyStockInfos = saleOrderDetailPos.stream()
                .map(e -> new PoOccupyStockReq.PoOccupyStockInfo(e.getSalePartNum(), e.getQty())).collect(Collectors.toList());
        poOccupyStockReq.setInfos(occupyStockInfos);
        return poOccupyStockReq;
    }


    @Transactional(rollbackFor = Exception.class)
    @Override
    public void cancel(Long id) {

        SaleOrderPo saleOrderPo = getById(id);
        if (!SaleOrderStatusEnum.canCancel(saleOrderPo.getSaleOrderStatus())) {
            throw new BizException(SALE_ORDER_CANCEL_ERROR);
        }

        //dfs取消 不用校验库存占用
        if (!saleOrderPo.getIsDfs()) {
            PoOccupyStockReq poOccupyStockReq = buildPoOccupyStockReq(saleOrderPo);
            BaseResult<String> baseResult = spsClient.checkPoOccupy(poOccupyStockReq);
            if (baseResult.isError()) {
                throw new BizException(baseResult.getMessage());
            }
        }

        //更新明细取消数量
        List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailMapper.selectList(Wrappers.<SaleOrderDetailPo>lambdaQuery()
                .eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderPo.getSaleOrderNo())
                .eq(SaleOrderDetailPo::getBizType, saleOrderPo.getBizType())
        );

        if (CollUtil.isNotEmpty(saleOrderDetailPos)) {
            for (SaleOrderDetailPo detail : saleOrderDetailPos) {
                detail.setCancelQty(detail.getQty());
                saleOrderDetailMapper.updateById(detail);
            }
        }

        // 待下发 & 待发货订单取消
        if (SaleOrderStatusEnum.WAIT_ISSUED.getCode().equals(saleOrderPo.getSaleOrderStatus())) {
            waitIssuedCancel(saleOrderPo);
        } else {
            pendingDeliveryCancel(saleOrderPo);
        }

        saleOrderPo.setSaleOrderStatus(SaleOrderStatusEnum.CANCELED.getCode());
        updateById(saleOrderPo);

        //更新采购订单状态
        purchaseOrderService.updateStateByReceiveQtyAndCancelQty(saleOrderPo.getPurchaseOrderNo(), saleOrderPo.getBizType());
    }

    @Override
    public List<TrackDetailItemResp> trackDetail(SaleOrderNoReq request) {
        SaleOrderPo saleOrderPo = saleOrderMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class)
                .eq(SaleOrderPo::getSaleOrderNo, request.getSaleOrderNo()));
        if (Objects.isNull(saleOrderPo)) {
            throw new BizException("销售订单不存在");
        }
        if (StringUtils.isEmpty(saleOrderPo.getLogisticsNo())) {
            return Lists.newArrayList();
        }
        TrackDetailReq trackDetailReq = TrackDetailReq.builder()
                .businessTypeCode(saleOrderPo.getBizType())
                .billNo(saleOrderPo.getLogisticsNo())
                .build();
        BaseResult<TrackDetailResp> baseResult = trackClient.trackDetail(trackDetailReq);
        log.info("SaleOrderServiceImpl#trackDetail param: {}, result {}", JsonUtil.toJsonString(trackDetailReq), JsonUtil.toJsonString(baseResult));
        if (Objects.isNull(baseResult) || baseResult.isError()) {
            throw new BizException("物料轨迹查询失败，请稍后再试");
        }
        if (Objects.isNull(baseResult.getData())
                || CollectionUtils.isEmpty(baseResult.getData().getBillList())
                || CollectionUtils.isEmpty(baseResult.getData().getBillList().get(0).getItemList())) {
            return Lists.newArrayList();
        }
        return baseResult.getData().getBillList().get(0).getItemList().stream()
                .map(item -> BeanCopierUtil.copy(item, TrackDetailItemResp.class))
                .sorted(Comparator.comparing(TrackDetailItemResp::getActionTime, Comparator.reverseOrder()))
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public BaseResult<String> manualDownSend(IdReq idReq) {
        SaleOrderPo saleOrderPo = saleOrderMapper.selectById(idReq.getId());
        if (saleOrderPo == null) {
            return BaseResult.error(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        if (!SaleOrderStatusEnum.WAIT_ISSUED.getCode().equals(saleOrderPo.getSaleOrderStatus())) {
            throw new BizException("只能手工下发待处理状态销售订单" + saleOrderPo.getBizType() + "(" + saleOrderPo.getSaleOrderNo() + ")");
        }
        //处理需要发送消息的数据
        updateOrderPendingDeliverAndSendMsg(saleOrderPo, OperateEnum.MANUAL_ISSUE_ORDER);
        return BaseResult.OK();
    }


    @Override
    public List<SaleOrderExportDto> exportSearch(SaleOrderPageSearchReq pageParam) {
        if(StringUtils.isBlank(pageParam.getInvoiceNo())){
            pageParam.setInvoiceNo(null);
        }
        if(StringUtils.isBlank(pageParam.getRedInvoiceNo())){
            pageParam.setRedInvoiceNo(null);
        }
        String bizType = pageParam.getBizType();
        List<SaleOrderExportDto> saleOrderExportDtoList = saleOrderMapper.exportSearch(pageParam, maxSize);

        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(bizType,
                saleOrderExportDtoList.stream().map(SaleOrderExportDto::getSalePartNum).distinct().collect(Collectors.toList()));
        Map<String, PurchaseOrderDetailPo> detailPoMap = purchaseOrderDetailService.getDetailPoByPos(
                saleOrderExportDtoList.stream().map(SaleOrderExportDto::getPurchaseOrderNo).collect(
                        Collectors.toList()));
        Map<String, WarehousePo> deliverWarehouseCodeMap = baseDataQuery.mapWarehousePo(bizType, saleOrderExportDtoList.stream()
                .map(SaleOrderExportDto::getDeliverWarehouseCode).distinct().collect(Collectors.toList()));
        Map<String, WarehousePo> receiveWarehouseMap = baseDataQuery.mapWarehousePo(BizTypeEnum.SS.getBizType(), saleOrderExportDtoList.stream()
                .map(SaleOrderExportDto::getReceiveWarehouseCode).distinct().collect(Collectors.toList()));
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(bizType,
                saleOrderExportDtoList.stream().map(SaleOrderExportDto::getStoreCode).collect(
                        Collectors.toList()));
        Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(
                DictEnum.MapLocationDistrict.getDictCode());
        Map<String, List<SapInvoiceInfoPo>> saleOrderNoMap = saleOrderInvoiceRelationService.mapSapInvoiceInfoPoList(saleOrderExportDtoList.stream().map(SaleOrderExportDto::getSaleOrderNo).collect(Collectors.toList()));


        for (SaleOrderExportDto saleOrderExportDto : saleOrderExportDtoList) {
            if (Objects.nonNull(saleOrderExportDto)) {
                StorePo storePo = storePoMap.getOrDefault(saleOrderExportDto.getStoreCode(), new StorePo());
                saleOrderExportDto.setStoreName(storePo.getStoreName());
            }
            if (materialPoMap.containsKey(saleOrderExportDto.getSalePartNum())) {
                saleOrderExportDto.setMaterialName(materialPoMap.get(saleOrderExportDto.getSalePartNum()).getMaterialName());
                saleOrderExportDto.setMaterialAttribute(materialPoMap.get(saleOrderExportDto.getSalePartNum()).getMaterialAttribute());
                saleOrderExportDto.setMinPackage(materialPoMap.get(saleOrderExportDto.getSalePartNum()).getMinPackage());
            }
            if (StrUtil.isNotEmpty(saleOrderExportDto.getDeliverWarehouseCode())) {
                saleOrderExportDto.setDeliverWarehouseName(deliverWarehouseCodeMap.getOrDefault(saleOrderExportDto.getDeliverWarehouseCode(), new WarehousePo()).getName());

            }
            if (StrUtil.isNotEmpty(saleOrderExportDto.getReceiveWarehouseCode())) {
                saleOrderExportDto.setReceiveWarehouseName(receiveWarehouseMap.getOrDefault(saleOrderExportDto.getReceiveWarehouseCode(), new WarehousePo()).getName());
            }
            PurchaseOrderDetailPo detailPo = detailPoMap.getOrDefault(saleOrderExportDto.getPurchaseOrderNo() + saleOrderExportDto.getSalePartNum(), new PurchaseOrderDetailPo());

            saleOrderExportDto.setDiscountUnitPrice(detailPo.getDiscountUnitPrice().toString());
            saleOrderExportDto.setStandardPriceExcludeTax(SaleOrderDetailServiceImpl.getStandardPriceExcludeTax(detailPo));
            saleOrderExportDto.setStandardPriceIncludeTax(SaleOrderDetailServiceImpl.getStandardPriceIncludeTax(detailPo));
            saleOrderExportDto.setDfsStatus(SaleOrderDfsStatusEnum.getDesc(saleOrderExportDto.getDfsStatus()));
            saleOrderExportDto.setSaleOrderStatus(SaleOrderStatusEnum.getDesc(saleOrderExportDto.getSaleOrderStatus()));
            saleOrderExportDto.setIsDfs(BooleanUtil.oneOrZeroToChinese(saleOrderExportDto.getIsDfs()));
            saleOrderExportDto.setIsClaimWhitelist(BooleanUtil.oneOrZeroToChinese(saleOrderExportDto.getIsClaimWhitelist()));

            saleOrderExportDto.setInvoiceNo(ISaleOrderInvoiceRelationService.getInvoiceInfo(saleOrderExportDto.getSaleOrderNo(), saleOrderNoMap).getInvoiceNo());
            saleOrderExportDto.setRedInvoiceNo(String.join(",",ISaleOrderInvoiceRelationService.getRedInvoiceNoList(saleOrderExportDto.getSaleOrderNo(), saleOrderNoMap)));

            String provinceName = codeAndNameMap.getOrDefault(saleOrderExportDto.getReceiverProvince(), "");
            String cityName = codeAndNameMap.getOrDefault(saleOrderExportDto.getReceiverCity(), "");
            String districtName = codeAndNameMap.getOrDefault(saleOrderExportDto.getReceiverDistrict(), "");
            saleOrderExportDto.setReceiverAddress(provinceName.concat(cityName)
                    .concat(districtName).concat(saleOrderExportDto.getReceiverAddress()));
        }
        return saleOrderExportDtoList;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStockOutTimeAndDeliverQty(SOStockOutTimeAndDeliverQtyReq req) {
        String saleOrderNo = req.getSaleOrderNo();
        LocalDateTime stockOutTime = req.getStockOutTime();
        log.info("SaleOrderServiceImpl#updateStockOutTime saleOrderNo: {}, stockOutTime: {}", saleOrderNo, stockOutTime);
        SaleOrderPo saleOrderPo = baseMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class).eq(SaleOrderPo::getSaleOrderNo, saleOrderNo));
        String stockOutTimeStr = DateUtils.format(stockOutTime, DateUtils.STANDARD_TIME_FORMAT);
        saleOrderPo.setStockOutTime(stockOutTimeStr);
        String estArrivalTime = getEstArrivalTime(saleOrderPo);
        baseMapper.update(null, Wrappers.lambdaUpdate(SaleOrderPo.class)
                .set(StringUtils.isNotEmpty(estArrivalTime), SaleOrderPo::getEstArrivalTime, estArrivalTime)
                .set(SaleOrderPo::getStockOutTime, stockOutTimeStr)
                .eq(SaleOrderPo::getId, saleOrderPo.getId()));

        updateDeliverQty(saleOrderNo, req.getOutQuantityList());
    }

    private void updateOrderPendingDeliverAndSendMsg(SaleOrderPo po, OperateEnum opt) {
        updateStatusAndSendMessage(SaleOrderStatusChangeDto.builder()
                .saleOrderPo(po)
                .newStatusEnum(SaleOrderStatusEnum.PENDING_DELIVERY)
                .operateEnum(opt)
                .operateUser(getOperateUser(opt))
                .build());
    }

    private String getOperateUser(OperateEnum operateEnum) {
        if (OperateEnum.isSystemOpt(operateEnum)) {
            return OperateUserEnum.SPS.getName();
        } else {
            if (StrUtil.isBlank(UserUtil.getUserName())) {
                return UserUtil.getUserNameByRequest();
            }
            return UserUtil.getUserName();
        }
    }

    private String getEstArrivalTime(SaleOrderPo saleOrderPo) {
        if (saleOrderPo == null) {
            return null;
        }
        LocalDateTime stockOutTime = DateUtils.parse(saleOrderPo.getStockOutTime(), DateUtils.STANDARD_TIME_FORMAT);
        if (stockOutTime == null) {
            return null;
        }
        LogisticsPo logisticsPo = spsClient.getLogisticsPo(saleOrderPo).getData();
        if (logisticsPo == null || logisticsPo.getLogisticsAging() == null) {
            return null;
        }

        LocalDateTime estArrivalTime = stockOutTime.plusMinutes(logisticsPo.getLogisticsAging().multiply(new BigDecimal(24 * 60)).intValue());
        return DateUtils.format(estArrivalTime, DateUtils.STANDARD_DATE_FORMAT);
    }

    /**
     * SO 门店收货时 校验订单信息
     *
     * @param saleOrderNo
     * @param inQuantityList
     */
    @Override
    public void checkReceiveQty(String saleOrderNo, List<StockInItemQuantityDto> inQuantityList) {
        log.info("SaleOrderServiceImpl#checkReceiveQty saleOrderNo: {}, outQuantityList: {}", saleOrderNo, JsonUtil.toJsonString(inQuantityList));

        String redisKey = String.format(BaseConstants.RedisKey.SALE_ORDER_UPDATE_RECEIVE_QTY, saleOrderNo);
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            SaleOrderPo saleOrderPo = baseMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class).eq(SaleOrderPo::getSaleOrderNo, saleOrderNo));
            if (saleOrderPo == null) {
                throw new BizException("销售订单不存在：" + saleOrderNo);
            }
            if (saleOrderPo.getIsDfs()) {
                //SO单收货只能是非DFS的物料
                throw new BizException(SpsResponseCodeEnum.SO_RECEIVE_NO_DFS_ERROR);
            }
            if (SaleOrderStatusEnum.PARTIALLY_RECEIVED.getCode().equals(saleOrderPo.getSaleOrderStatus())
                    || SaleOrderStatusEnum.FULLY_RECEIVED.getCode().equals(saleOrderPo.getSaleOrderStatus())) {
                throw new BizException(DUPLICATE_OPERATE);
            }
            List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                    .eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderPo.getSaleOrderNo()));
            if (CollectionUtils.isEmpty(saleOrderDetailPos)) {
                throw new BizException("销售订单明细不存在：" + saleOrderNo);
            }

            Map<String, BigDecimal> receiveQtyMap = Optional.ofNullable(inQuantityList).map(Collection::stream).orElse(Stream.empty())
                    .filter(item -> Objects.nonNull(item.getSalePartNum()) && Objects.nonNull(item.getQuantity()))
                    .collect(toMap(StockInItemQuantityDto::getSalePartNum, StockInItemQuantityDto::getQuantity, BigDecimal::add));

            for (SaleOrderDetailPo saleOrderDetailPo : saleOrderDetailPos) {
                BigDecimal receiveQty = receiveQtyMap.getOrDefault(saleOrderDetailPo.getSalePartNum(), BigDecimal.ZERO);
                if (receiveQty.compareTo(saleOrderDetailPo.getDeliverQty()) > 0) {
                    throw new BizException("销售订单收货数量大于发货数量：" + saleOrderNo);
                }
            }
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    @Override
    public void stkSaleOrderIssueByAmountHandler() {
        //1. orderCalendarPos 是订单金额不为空的数据 获取 运出下发时间
        List<SaleOrderPo> list = list(Wrappers.<SaleOrderPo>lambdaQuery()
                .eq(SaleOrderPo::getBizType, BizTypeEnum.SP.getBizType())
                .eq(SaleOrderPo::getSaleOrderType, PurchaseOrderTypeEnum.STK.getValue())
                .eq(SaleOrderPo::getSaleOrderStatus, SaleOrderStatusEnum.WAIT_ISSUED.getCode())
                .eq(SaleOrderPo::getIsDfs, false)
        );

        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        Map<String, SaleOrderPo> saleOrderPoMap = list.stream().collect(toMap(SaleOrderPo::getStoreCode, v -> v, (v1, v2) -> {
            v1.setSaleOrderAmount(v1.getSaleOrderAmount().add(v2.getSaleOrderAmount()));
            return v1;
        }));
        List<String> storeCodeList = list.stream().map(SaleOrderPo::getStoreCode).distinct().collect(Collectors.toList());
        IdBatchReq req = new IdBatchReq();
        req.setIdList(storeCodeList);
        req.setBizType(BizTypeEnum.SP.getBizType());

        List<OrderCalendarPo> orderCalendarPos = spsClient.queryConfigAmountOrderCalendar(req).check().getData();

        if (CollUtil.isEmpty(orderCalendarPos)) {
            return;
        }
        Map<String, OrderCalendarPo> storeCodeMap = orderCalendarPos.stream()
                .collect(toMap(OrderCalendarPo::getStoreCode, v -> v, (v1, v2) -> v2));

        List<String> shouldIssueStoresList = new ArrayList<>();

        for (SaleOrderPo so : saleOrderPoMap.values()) {
            OrderCalendarPo orderCalendarPo = storeCodeMap.get(so.getStoreCode());
            if (orderCalendarPo == null) {
                continue;
            }

            if (so.getSaleOrderAmount().compareTo(orderCalendarPo.getIssueAmount()) >= 0
                    && LocalTime.now().isAfter(orderCalendarPo.getStoreReportDeadline().toLocalTime())
                    && LocalTime.now().isBefore(orderCalendarPo.getStoreReportDeadline().toLocalTime().plusMinutes(15))
            ) {
                shouldIssueStoresList.add(so.getStoreCode());
            }
        }

        if (CollUtil.isEmpty(shouldIssueStoresList)) {
            return;
        }

        for (String storeCode : shouldIssueStoresList) {
            List<SaleOrderPo> collect = list.stream().filter(so -> so.getStoreCode().equals(storeCode)).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(collect)) {
                continue;
            }
            for (SaleOrderPo saleOrderPo : collect) {
                saleOrderService.updateStatusAndSendMessage(SaleOrderStatusChangeDto.builder()
                        .operateEnum(OperateEnum.SCHEDULE_ISSUE_ORDER_BY_AMOUNT)
                        .saleOrderPo(saleOrderPo)
                        .newStatusEnum(SaleOrderStatusEnum.PENDING_DELIVERY)
                        .operateUser(OperateUserEnum.SPS.getName())
                        .build());
            }
        }
    }
}
