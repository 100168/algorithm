package com.jiduauto.sps.order.server.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.BackOrderTransferDto;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderTransferContextDto;
import com.jiduauto.sps.order.server.pojo.fileexport.BackOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderPageSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.ControlTransferReq;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.BackOrderBatchCancelReq;
import com.jiduauto.sps.sdk.pojo.req.IdBatchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * 缺件订单 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface IBackOrderService extends IService<BackOrderPo> {

    /**
     * 缺件订单条件查询
     *
     * @author dong.li
     * @date 4/13/23 10:28 AM
     */
    BasePageData<BackOrderDto> pageSearch(BasePageParam<BackOrderPageSearchReq> pageParam);

    /**
     * 构建缺件订单
     *
     * @param contextDto
     */
    void builderBackOrderPos(PurchaseOrderTransferContextDto contextDto);

    /**
     * 批量保存缺件订单
     *
     * @param contextDto
     */
    void batchInsertBackOrder(PurchaseOrderTransferContextDto contextDto);

    /**
     * 查询缺件订单列表
     *
     * @param purchaseOrderNo
     * @return
     */
    List<BackOrderPo> listBackOrderPo(String purchaseOrderNo);

    /**
     * 更新缺件订单状态
     *
     * @param changeDto
     */
    void updateStatusAndSendMessage(BackOrderStatusChangeDto changeDto);


    /**
     * 缺件map
     *
     * @param backOrderNos
     */
    Map<String,BackOrderPo> mapBackOrderPo(List<String> backOrderNos);


    /**
     * 构建缺货订单
     *
     * @param saleOrderPo
     * @param saleOrderDetailPo
     * @return
     */
    BackOrderPo builderAndSaveBackOrderPo(SaleOrderPo saleOrderPo, SaleOrderDetailPo saleOrderDetailPo, Map<String, PurchaseOrderDetailPo> partMap);

    /**
     * 缺件订单自动转单
     * @param backOrderTransferDto
     */
    void autoTransferOrder(BackOrderTransferDto backOrderTransferDto);

    /**
     * 检查相关配置条件是否满足
     * 开始尝试 BO 转单
     */
    BaseResult<String> tryTransferOrder(List<BackOrderPo> backOrderPoList, PurchaseOrderPo purchaseOrderPo, OperateEnum operate);

    /**
     * 批量更新 Bo的预计到货时间
     * @param backOrderPos
     */
    BaseResult<String> updateByBoNo(List<com.jiduauto.sps.sdk.pojo.po.BackOrderPo> backOrderPos);


    /**
     * 取消审批
     *
     * @param backOrderNo
     */
    BaseResult<String> cancelApproval(String backOrderNo);


    /**
     * 批量取消审批
     * @param backOrderNos
     */
    void batchCancelApproval(BackOrderBatchCancelReq backOrderNos);


    /**
     * 批量取消驳回
     */
    void batchCancelApprovalRejected(BackOrderBatchCancelReq req);


    /**
     * 缺件订单手动转单
     */
    BaseResult<String> manualTransferOrder(Long id, String operationUser);

    /**
     * 缺件订单批量手动转单
     */
    BaseResult<String> manualBatchTransferOrder(IdBatchReq idBatchReq);

    /**
     * 缺件订单导出
     */
    List<BackOrderExportDto> getExportDtoList(BasePageParam<BackOrderPageSearchReq> pageParam);

    /**
     * 管控件转单
     */
    BaseResult<String> controlTransfer(ControlTransferReq idReq);
}
