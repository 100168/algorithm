package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class PendingReceiveListDto {
    /**
     * 主键
     */
    private Long id;

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 外部系统单号
     */
    private String outOrderNo;

    /**
     * 订单类型
     */
    private String orderType;

    /**
     * 订单状态
     */
    private String orderStatus;
    /**
     * 订单状态code
     */
    private String orderStatusCode;
    /**
     * 零件数量
     */
    private BigDecimal materialQty;

    /**
     * 应收总数
     */
    private BigDecimal expectQty;

    /**
     * 实收总数
     */
    private BigDecimal actualQty;

    /**
     * 收货仓库
     */
    private String warehouseCode;

    /**
     * 预计到货日期
     */
    private String estArrivalTime;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 更新者
     */
    private String updateUser;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 发货人
     */
    private String shipper;
    /**
     * 发货人联系方式
     */
    private String shipperContact;
    /**
     * 流程代码
     */
    private String processCode;
}
