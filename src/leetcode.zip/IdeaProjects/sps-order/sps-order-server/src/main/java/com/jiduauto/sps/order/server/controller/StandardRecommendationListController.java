package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.StandardRecommendationListDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListEditReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListPageReq;
import com.jiduauto.sps.order.server.service.IStandardRecommendationListService;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.req.IdBatchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 标准推荐清单 前端控制器
 */
@RestController
@RequestMapping("/standardRecommendationList")
public class StandardRecommendationListController {

    @Resource
    private IStandardRecommendationListService standardRecommendationListService;

    /**
     * 分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StandardRecommendationListDto>> pageSearch(@RequestBody @Valid BasePageParam<StandardRecommendationListPageReq> pageParam) {
        return BaseResult.OK(standardRecommendationListService.pageSearch(pageParam));
    }

    /**
     * 删除
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid IdBatchReq request) {
        standardRecommendationListService.delete(request);
        return BaseResult.OK();
    }

    /**
     * 清空 根据查询条件删除
     */
    @PostMapping("/clear")
    public BaseResult<String> clear(@RequestBody @Valid StandardRecommendationListPageReq request) {
        standardRecommendationListService.clear(request);
        return BaseResult.OK();
    }

    /**
     * 新建
     */
    @PostMapping("/add")
    public BaseResult<String> add(@RequestBody @Valid StandardRecommendationListAddReq req) {
        standardRecommendationListService.add(req);
        return BaseResult.OK();
    }

    /**
     * 编辑
     */
    @PostMapping("/edit")
    public BaseResult<String> edit(@RequestBody @Valid StandardRecommendationListEditReq req) {
        standardRecommendationListService.edit(req);
        return BaseResult.OK();
    }

    /**
     * 导入
     */
    @PostMapping("/import")
    public BaseResult<ImportResultResp> importExcel(@RequestHeader("bizType") String bizType, @RequestPart("file") MultipartFile file) {
        return BaseResult.OK(standardRecommendationListService.importExcel(bizType, file));
    }
}
