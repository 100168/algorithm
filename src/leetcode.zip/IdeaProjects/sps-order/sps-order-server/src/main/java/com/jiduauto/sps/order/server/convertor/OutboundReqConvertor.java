package com.jiduauto.sps.order.server.convertor;

import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;

import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.pojo.req.DHLOutboundReq;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * @author panjian
 */
@Component
public class OutboundReqConvertor {

    @Resource
    private BaseDataQuery baseDataQuery;

    public DHLOutboundReq toDhlOutBoundReq(WarehouseDistributeOrderPo distributeOrderPo,
                                           List<WarehouseDistributeItemPo> detailPos,
                                           WarehouseDistributeLogisticPo logisticPo,
                                           String operateType) {
        Map<String, String> mapLocationMap = baseDataQuery.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());

        WarehouseDistributeOrderTypeEnum typeEnum = WarehouseDistributeOrderTypeEnum.getByType(distributeOrderPo.getOrderType());
        DHLOutboundReq req = new DHLOutboundReq();
        req.setBizType(distributeOrderPo.getBizType());
        req.setOrderTime(distributeOrderPo.getOrderTime());
        req.setOrderType(typeEnum.getTmsOrderType());
        req.setOutboundBillNo(distributeOrderPo.getOrderNo());
        req.setOutboundType(typeEnum.getValue());
        req.setOperateType(operateType);
        req.setTransferAdvice(logisticPo.getShippingMethod());
        req.setDeliverWarehouseCode(logisticPo.getDeliverWarehouseCode());
        req.setReceiver(logisticPo.getReceiver());
        req.setReceiverProvince(logisticPo.getReceiveProvinceName());
        req.setReceiverCity(logisticPo.getReceiveCityName());
        req.setReceiverDistrict(logisticPo.getReceiveDistrictName());
        req.setReceiverAddress(logisticPo.getReceiveAddress());
        req.setReceiverPhone(logisticPo.getReceiverContact());
        if (StrUtil.isEmpty(req.getReceiverCity())){
            req.setReceiverCity(mapLocationMap.get(logisticPo.getReceiveCityCode()));
        }
        if (StrUtil.isEmpty(req.getReceiverProvince())){
            req.setReceiverProvince(mapLocationMap.get(logisticPo.getReceiveProvinceCode()));
        }
        if (StrUtil.isEmpty(req.getReceiverDistrict())){
            req.setReceiverDistrict(mapLocationMap.get(logisticPo.getReceiveDistrictCode()));
        }
        if (StrUtil.isEmpty(req.getReceiverCity())){
            req.setReceiverCity(logisticPo.getDeliverCityName());
        }
        if (StrUtil.isEmpty(req.getReceiverProvince())){
            req.setReceiverProvince((logisticPo.getDeliverProvinceName()));
        }
        if (StrUtil.isEmpty(req.getReceiverDistrict())){
            req.setReceiverDistrict(logisticPo.getDeliverDistrictName());
        }
        if (StrUtil.isEmpty(req.getReceiverAddress())){
            req.setReceiverAddress(logisticPo.getDeliverAddress());
        }

        List<com.jiduauto.sps.sdk.pojo.req.DHLOutboundReq.Detail> details = detailPos.stream().map(item -> {
            com.jiduauto.sps.sdk.pojo.req.DHLOutboundReq.Detail detail = new com.jiduauto.sps.sdk.pojo.req.DHLOutboundReq.Detail();
            detail.setLineNo(item.getMaterialLineNo());
            detail.setSalePartNum(item.getMaterialCode());
            detail.setQuantity(item.getQty());
            detail.setMaterialStatus(String.valueOf(item.getMaterialStatus()));
            detail.setStockStatus(String.valueOf(item.getStockStatus()));
            detail.setRemark(distributeOrderPo.getResponsibleParty());
            return detail;
        }).collect(Collectors.toList());
        req.setDetailList(details);
        return req;
    }

}
