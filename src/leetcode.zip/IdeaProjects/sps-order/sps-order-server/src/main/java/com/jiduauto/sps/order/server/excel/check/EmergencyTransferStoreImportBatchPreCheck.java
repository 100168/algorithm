package com.jiduauto.sps.order.server.excel.check;

import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.pojo.vo.req.EmergencyTransferStoreImportReq;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.SapPurchaseOrderAttrEnum;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toList;

@Component
public class EmergencyTransferStoreImportBatchPreCheck implements BatchPreCheck<EmergencyTransferStoreImportReq> {

    @Resource
    private BaseDataQuery baseDataQuery;

    @Override
    public void invoke(List<ExtendExportDto<EmergencyTransferStoreImportReq>> extendExportDtos) {
        String bizType = BizTypeThreadHolder.getBizType();
        List<String> storeCodes = extendExportDtos.stream().map(ExtendExportDto::getT).map(EmergencyTransferStoreImportReq::getStoreCode).distinct().collect(toList());
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(bizType, storeCodes, false);

        for (ExtendExportDto<EmergencyTransferStoreImportReq> extendExportDto : extendExportDtos) {
            EmergencyTransferStoreImportReq importReq = extendExportDto.getT();
            StringBuilder errors = new StringBuilder();

            if (StrUtil.isBlank(importReq.getStoreCode())) {
                errors.append("门店code为空;");
            } else if (!storePoMap.containsKey(importReq.getStoreCode())) {
                errors.append("门店code不存在;");
            } else if (!SapPurchaseOrderAttrEnum.Z1.getCode().equals(storePoMap.get(importReq.getStoreCode()).getStoreType())) {
                errors.append("门店类型需要为直营门店;");
            }
            extendExportDto.setCheckResult(errors.toString());
        }
    }
}
