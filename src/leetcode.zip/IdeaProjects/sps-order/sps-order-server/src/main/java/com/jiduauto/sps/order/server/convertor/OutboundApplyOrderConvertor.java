package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.sdk.pojo.po.OutboundApplyOrderPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface OutboundApplyOrderConvertor {

    @Mapping(target = "expectQty", ignore = true)
    @Mapping(target = "applyUser", source = "createUser")
    @Mapping(target = "applyOrderNo", source = "orderNo")
    @Mapping(target = "actualQty", ignore = true)
    @Mapping(target = "orderStatus",ignore = true)
    @Mapping(target = "processCode", source = "outProcessCode")
    @Mapping(target = "id", ignore = true)
    OutboundApplyOrderPo toDto(WarehouseDistributeOrderPo po);
}
