package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.dto.CommonLogDto;
import com.jiduauto.sps.sdk.pojo.po.CommonLogPo;
import com.jiduauto.sps.sdk.pojo.req.CommonLogReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

/**
 * <p>
 * 通用日志记录 服务类
 * </p>
 *
 * @author generate
 * @since 2024-01-11
 */
public interface ICommonLogService extends IService<CommonLogPo> {

    /**
     * 通用记录状态变更方法
     */
    void saveStatusLog(String newStatus,
                       String no,
                       String bizType,
                       String logKey,
                       String user,
                       String column,
                       String remark
    );

    /**
     * 通用记录状态变更方法
     */
    void saveStatusLog(String newStatus,
                       String actionName,
                       String no,
                       String bizType,
                       String logKey,
                       String user,
                       String column,
                       String remark
    );
    /**
     * 调拨单日志分页查询
     */
    BasePageData<CommonLogDto> pageSearchStoreTransferLog(BasePageParam<CommonLogReq> req);
}
