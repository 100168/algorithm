package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author panjian
 */
@Data
public class PurchaseOrderDto implements Serializable {

    /**采购单id*/
    private Long id;
    /**
     * 采购单号
     */
    private String purchaseOrderNo;

    /**
     * SAP单号
     */
    private String sapOrderNo;

    /**
     * 采购订单归属
     */
    private String purchaseOrderAttr;

    /**
     * 采购订单类型
     */
    private String purchaseOrderType;

    /**
     * 门店编码
     */
    private String storeCode;
    /**
     * 门店名称
     */
    private String storeName;

    /**
     * 收货仓库编码
     */
    private String receiveWarehouseCode;
    /**
     * 收货仓库名称
     */
    private String receiveWarehouseName;

    /**
     * 提交时间
     */
    private LocalDateTime commitTime;
    /**
     * 订单总金额
     */
    private String purchaseOrderAmount;

    /**
     * 订单状态name
     */
    private String purchaseOrderStatus;
    /**
     * 订单状态code
     */
    private String purchaseOrderStatusCode;
    /**
     * 收件人
     */
    private String receiver;

    /**
     * 收件人电话
     */
    private String receiverPhone;

    /**
     * 收货地址
     */
    private String receiverAddress;

    /**
     * vin
     */
    private String vin;
    /**
     * 转单备注
     */
    private String remark;

    /**
     * 创建者
     */
    private String createUser;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新者
     */
    private String updateUser;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;
    /**
     * 转采购申请订单状态
     */
    private String turnPurchaseOrderStatus;
    /**
     * 转采购申请订单状态name
     */
    private String turnPurchaseOrderStatusName;

    /**
     * 管控件转单状态
     */
    private String turnControlStatus;

    /**
     * 管控件转单状态名称
     */
    private String turnControlStatusName;

    /**
     * 订单主数据备注
     */
    private String headRemark;
}
