package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.sdk.pojo.po.*;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class WarehouseDistributeOrderAllPo {

    /*
     * 仓配订单基本信息
     */
    private WarehouseDistributeOrderPo warehouseDistributeOrderPo;
    /*
     * 仓配订单附属信息
     */
    private WarehouseDistributeAttachPo warehouseDistributeAttachPo;
    /*
     * 仓配订单物流信息
     */
    private WarehouseDistributeLogisticPo warehouseDistributeLogisticPo;

    private List<WarehouseDistributeItemPo> items;

    private List<WarehouseDistributeItemAttachPo> itemAttaches;

    private List<WarehouseDistributeItemPackagePo> ItemPackages;
}
