package com.jiduauto.sps.order.server.convertor;

import cn.hutool.json.JSONUtil;
import com.jiduauto.sps.order.server.pojo.BackOrderBatchCancelResp;
import com.jiduauto.sps.order.server.pojo.dto.NoticedDto;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author panjian
 */
@Component
public class NoticedDtoConvertor {

    @Value("${spring.profiles.active}")
    private String env;

    public NoticedDto buildNoticedDto(String no, String bizType, String msg, String title) {
        return NoticedDto
                .builder()
                .bizType(bizType)
                .key(no)
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(SaleOrderPo saleOrderPo, String msg, String title) {
        return NoticedDto
                .builder()
                .bizType(saleOrderPo.getBizType())
                .key(saleOrderPo.getSaleOrderNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(PurchaseOrderPo po, String msg, String title) {
        return NoticedDto
                .builder()
                .bizType(po.getBizType())
                .key(po.getPurchaseOrderNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildBoCacelNoticedDto(String message,String bizType, String taskId, String title) {
        return NoticedDto
                .builder()
                .bizType(bizType)
                .key(taskId)
                .env(env)
                .title(title)
                .result(message)
                .build();
    }


    public NoticedDto buildNoticedDto(WarehouseDistributeOrderPo po, String msg, String title) {
        return NoticedDto
                .builder()
                .bizType(po.getBizType())
                .key(po.getOrderNo())
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

    public NoticedDto buildNoticedDto(List<WarehouseDistributeOrderPo> po, String msg, String title) {
        return NoticedDto
                .builder()
                .bizType("")
                .key("")
                .env(env)
                .title(title)
                .result(msg)
                .build();
    }

}
