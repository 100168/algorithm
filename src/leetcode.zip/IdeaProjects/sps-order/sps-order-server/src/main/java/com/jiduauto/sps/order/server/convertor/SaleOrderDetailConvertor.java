package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDetailDto;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderDetailPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface SaleOrderDetailConvertor {

    /**po转dto
     * @param saleOrderDetailPo po
     * @return dto*/
    @Mapping(target = "salePartName", ignore = true)
    @Mapping(target = "partSaleField", ignore = true)
    @Mapping(target = "minPackage", ignore = true)
    SaleOrderDetailDto toDetailDto(SaleOrderDetailPo saleOrderDetailPo);


}
