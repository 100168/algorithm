package com.jiduauto.sps.order.server.utils;

import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;

@Component
@Slf4j
public class OnlineDutyUtil {

    @Value("${sps.online.duty.mobile}")
    private String dutyUsers;

    @Resource
    private RedisUtil redisUtil;

    public String  getMobile()  {
        Object indexObj = redisUtil.get(BaseConstants.RedisKey.ONLINE_DUTY_USER_INDEX);
        int index;
        if(indexObj == null){
            index = 0;
            redisUtil.set(BaseConstants.RedisKey.ONLINE_DUTY_USER_INDEX, Integer.toString(index));
        }else{
            index = Integer.parseInt(indexObj.toString());
        }

        if(StringUtils.isNotBlank(dutyUsers)){
            List<String> mobiles = JSON.parseArray(dutyUsers,String.class);
            LocalDateTime now = LocalDateTime.now();
            if(now.getDayOfWeek() == DayOfWeek.MONDAY){
                index++;
                if(index == mobiles.size()){
                    index = 0;
                }
                redisUtil.set(BaseConstants.RedisKey.ONLINE_DUTY_USER_INDEX, Integer.toString(index));
            }
            return mobiles.get(index);
        }

        return "";
    }
}
