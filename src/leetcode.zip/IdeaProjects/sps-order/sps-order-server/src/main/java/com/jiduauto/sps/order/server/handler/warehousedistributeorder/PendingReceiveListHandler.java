package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.convertor.PendingReceiveListConvertor;
import com.jiduauto.sps.order.server.convertor.PendingReceiveListDetailPoConvertor;
import com.jiduauto.sps.order.server.pojo.dto.PendingReceiveListDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.PendingReceiveListDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PendingReceiveListCreateReq;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;

/*
 * 生成待收货列表*/
@Component
public class PendingReceiveListHandler implements WDOrderJobHandler, InitializingBean {

    @Resource
    private WDOrderJobContext wdOrderJobContext;
    @Resource
    private SpsClient spsClient;

    @Resource
    private PendingReceiveListConvertor pendingReceiveListConvertor;

    @Resource
    private PendingReceiveListDetailPoConvertor pendingReceiveListDetailPoConvertor;
    /**
     * 生成待收货列表
     */
    @Override
    public void process(WarehouseDistributeOrderAllPo allPo) {
        PendingReceiveListDto dto = pendingReceiveListConvertor.toDto(allPo.getWarehouseDistributeOrderPo());
        dto.setEstArrivalTime(allPo.getWarehouseDistributeLogisticPo().getEstArrivalTime());
        dto.setWarehouseCode(allPo.getWarehouseDistributeLogisticPo().getReceiveWarehouseCode());
        dto.setShipper(allPo.getWarehouseDistributeLogisticPo().getShipper());
        dto.setShipperContact(allPo.getWarehouseDistributeLogisticPo().getShipperContact());
        ArrayList<PendingReceiveListDetailDto> dtoList = new ArrayList<>();
        for (WarehouseDistributeItemPo item : allPo.getItems()) {
            PendingReceiveListDetailDto detailDto = pendingReceiveListDetailPoConvertor.toDto(item);
            detailDto.setOutOrderNo(allPo.getWarehouseDistributeOrderPo().getBusinessBillNo());
            dtoList.add(detailDto);
        }
        BaseResult<String> resp = spsClient.createPendingReceiveOrder(PendingReceiveListCreateReq.builder().head(dto).items(dtoList).build());
        if (!resp.isSuccess()){
            throw new BizException(resp.getMessage());
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.GENERATE_PENDING_RECEIVE_ORDER.getBitIndex(), this);
    }
}
