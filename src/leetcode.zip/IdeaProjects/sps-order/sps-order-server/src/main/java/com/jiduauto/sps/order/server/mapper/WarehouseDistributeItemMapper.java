package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 仓配订单零件信息 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
@Mapper
public interface WarehouseDistributeItemMapper extends BaseMapper<WarehouseDistributeItemPo> {

}
