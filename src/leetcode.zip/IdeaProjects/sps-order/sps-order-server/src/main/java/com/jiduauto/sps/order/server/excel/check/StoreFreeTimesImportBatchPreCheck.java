package com.jiduauto.sps.order.server.excel.check;

import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.mapper.StoreFreeTimesMapper;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreFreeTimesImportReq;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.PurchaseOrderTypeEnum;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.utils.NumberUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toList;

@Component
public class StoreFreeTimesImportBatchPreCheck implements BatchPreCheck<StoreFreeTimesImportReq> {

    @Resource
    private BaseDataQuery baseDataQuery;
    @Override
    public void invoke(List<ExtendExportDto<StoreFreeTimesImportReq>> extendExportDtos) {

        String bizType = BizTypeThreadHolder.getBizType();

        List<String> storeCodes = extendExportDtos.stream().map(ExtendExportDto::getT).map(StoreFreeTimesImportReq::getStoreCode).distinct().collect(toList());
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(bizType, storeCodes, false);
        Map<String, String> map = new HashMap<>();

        for(ExtendExportDto<StoreFreeTimesImportReq> extendExportDto:extendExportDtos) {
            StoreFreeTimesImportReq importReq = extendExportDto.getT();
            StringBuilder errors = new StringBuilder();

            String key = importReq.getStoreCode() + "_" + importReq.getOrderType();
            if(map.containsKey(key)) {
                errors.append("门店code和订单类型不能重复;");
            } else {
                map.put(key, "");
            }
            if (StrUtil.isBlank(importReq.getStoreCode())) {
                errors.append("门店code为空;");
            } else if (!storePoMap.containsKey(importReq.getStoreCode())) {
                errors.append("门店code不存在;");
            }


            if (StrUtil.isBlank(importReq.getOrderType())) {
                errors.append("订单类型为空;");
            } else if (!PurchaseOrderTypeEnum.hasValue(importReq.getOrderType())) {
                errors.append("订单类型不存在;");
            }

            if (!NumberUtil.isNumeric(importReq.getFreeTimes())) {
                errors.append("次数不正确;");
            }
            extendExportDto.setCheckResult(errors.toString());
        }

    }
}
