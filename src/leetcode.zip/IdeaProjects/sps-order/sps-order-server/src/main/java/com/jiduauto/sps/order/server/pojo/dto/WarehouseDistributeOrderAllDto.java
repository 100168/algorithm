package com.jiduauto.sps.order.server.pojo.dto;

import com.jiduauto.sps.sdk.pojo.dto.CommonFileAttachmentDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeLogisticDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeOrderDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeOrderItemDto;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * <p>
 * 仓配订单
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
@Data
@Builder
public class WarehouseDistributeOrderAllDto implements Serializable {

    //订单表头信息
    private WarehouseDistributeOrderDto head;
    //订单物流信息
    private WarehouseDistributeLogisticDto logistic;
    //物料信息
    private List<WarehouseDistributeOrderItemDto> items;
    //物料附属信息
    private List<WarehouseDistributeItemAttachDto> itemAttaches;
    //物料包装信息
    private List<WarehouseDistributeItemPackageDto> itemPackages;
    /**
     * 附件
     */
    private List<CommonFileAttachmentDto> attachments;

}


