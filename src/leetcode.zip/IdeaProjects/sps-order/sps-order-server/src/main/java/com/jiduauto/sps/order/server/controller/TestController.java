package com.jiduauto.sps.order.server.controller;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.jiduauto.javakit.common.biz.Result;
import com.jiduauto.sps.order.server.annotation.IdempotentCheck;
import com.jiduauto.sps.order.server.client.IndirectSrmTokenClient;
import com.jiduauto.sps.order.server.client.resp.IndirectTokenResp;
import com.jiduauto.sps.order.server.service.ITestService;
import com.jiduauto.sps.order.server.utils.RedisUtil;
import com.jiduauto.sps.order.server.xxljobs.OldDataUpdateHandler;
import com.jiduauto.sps.sdk.annotation.InvokeLog;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.service.IInvokeLogService;
import com.jiduauto.sps.sdk.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

@RestController
@Slf4j
@RequestMapping("/test")
public class TestController {

    @Autowired
    private RedisUtil redisUtil;
    @Resource
    private IInvokeLogService iInvokeLogService;

    @Resource
    private OldDataUpdateHandler oldDataUpdateHandler;

    @IdempotentCheck
    @PostMapping("/sleep")
    public BaseResult<String> sleepTest() throws InterruptedException {
        Thread.sleep(2000L);
        //int i = 1 / 0;
        return BaseResult.OK("123");
    }


    @PostMapping("/addNoNumber")
    public void testNo(){
        String redisKeyPO = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "PO",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "SP");

        Long serialNo = redisUtil.incrAndExpire(redisKeyPO, 1000L,
                24 * 60 * 60);

        String redisKeySO = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "SO",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "SP");

        Long serialNoSO = redisUtil.incrAndExpire(redisKeySO, 1000L,
                24 * 60 * 60);

        String redisKeyBO = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "BO",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "SP");

        Long serialNoBO = redisUtil.incrAndExpire(redisKeyBO, 1000L,
                24 * 60 * 60);

        String redisKeyWdoSM = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "JO",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "SM");
        Long serialNoWdoSM = redisUtil.incrAndExpire(redisKeyWdoSM, 1000L,
                24 * 60 * 60);

        String redisKeyWdoQE = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "JO",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "QE");
        Long serialNoWdoQE = redisUtil.incrAndExpire(redisKeyWdoQE, 1000L,
                24 * 60 * 60);

        String redisKeyWdoSP = String.format(BaseConstants.RedisKey.ORDER_SERIAL_NO_KEY,
                "JO",
                DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2),
                "SP");
        Long serialNoWdoSP = redisUtil.incrAndExpire(redisKeyWdoSP, 1000L,
                24 * 60 * 60);

    }

    @PostMapping("testRedis")
    @InvokeLog
    public void testRedis(){
        System.out.println(iInvokeLogService);
//        redisUtil.set("test","test");
//        System.out.println(redisUtil.get("test"));
//        redisUtil.del("test");
    }

    @PostMapping("testRetry")
    @InvokeLog
    public BaseResult testRetry(){
        log.info("testRetry:"+System.currentTimeMillis());
        try {
            Thread.sleep(10000);
        }catch (Exception e){
            log.error(e.getMessage(),e);
        }
        return BaseResult.OK();
    }


    @Value("DB_URL")
    String DB_URL ;
    @Value("DB_USER")
    String DB_USER ;
    @Value("DB_PASSWORD")
    String DB_PASSWORD ;
 /*   //    @Value("DB_URL")
    String DB_URL_TARGET = "jdbc:mysql://mysql.jidudev.com:3306/jidu_sps_order";
    //    @Value("DB_USER")
    String DB_USER_TARGET = "sps_order_wr";
    //    @Value("DB_PASSWORD")
    String DB_PASSWORD_TARGET = "jdG1yglZzc";*/
 @Resource
 private ITestService testService;

    /**
     * 临时后续删除
     */
    @RequestMapping("/addMore")
    @ResponseBody
    @Transactional
    public BaseResult addMore() throws SQLException {
        Connection source = null;
        Statement sourceStatement = null;
        try {
            source = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            sourceStatement = source.createStatement();
            testService.insertWDO(sourceStatement);
            testService.insertLP(sourceStatement);
            testService.insertP(sourceStatement);
            testService.insertIA(sourceStatement);
            testService.insertIP(sourceStatement);
            testService.insertA(sourceStatement);
            testService.insertPO(sourceStatement);
            testService.insertPOD(sourceStatement);
            testService.insertPOOL(sourceStatement);
            testService.insertSO(sourceStatement);
            testService.insertSOD(sourceStatement);
            testService.insertSOOL(sourceStatement);
            testService.insertBO(sourceStatement);
            testService.insertBOD(sourceStatement);
            testService.insertBOOL(sourceStatement);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if (sourceStatement != null) {
                sourceStatement.close();
            }
            if (source != null) {
                source.close();
            }
        }
        return BaseResult.OK();
    }

    @RequestMapping("wdo/fix")
    public Result<String> fixWdo(String param) {
        oldDataUpdateHandler.smWdOrderErrorStatusDataFixHandler(param);
        return Result.ofSuccess("success");
    }

    @RequestMapping("wdo/fixWdoOldData")
    public Result<String> fixWdoOldData(String param) {
        oldDataUpdateHandler.updateSMOldDataStatus(param);
        return Result.ofSuccess("success");
    }
    @Value("${feign.url.indirect.grantType}")
    private String grant_type;
    @Value("${feign.url.indirect.clientId}")
    private String client_id;
    @Value("${feign.url.indirect.clientSecret}")
    private String client_secret;
    @Value("${feign.url.indirect.scope}")
    private String scope;
    @Resource
    private IndirectSrmTokenClient indirectSrmTokenClient;
    @RequestMapping("testToken")
    public Result<String> testToken() {
        IndirectTokenResp resp = indirectSrmTokenClient.getToken(grant_type, client_id, client_secret, scope);
        log.info(JSON.toJSONString(resp));
        return Result.ofSuccess("success");
    }



}
