package com.jiduauto.sps.order.server.excel;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.pojo.po.EmergencyTransferStorePo;
import com.jiduauto.sps.order.server.pojo.vo.req.EmergencyTransferStoreImportReq;
import com.jiduauto.sps.order.server.service.IEmergencyTransferStoreService;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.handler.ExtendImportHandler;
import com.jiduauto.sps.sdk.service.impl.BosServiceImpl;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class EmergencyTransferStoreImportHandler extends ExtendImportHandler<EmergencyTransferStoreImportReq> {

    @Resource
    private IEmergencyTransferStoreService emergencyTransferStoreService;


    public EmergencyTransferStoreImportHandler(List<BatchPreCheck<EmergencyTransferStoreImportReq>> batchChecks,
                                               BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchChecks;
        super.eClass = EmergencyTransferStoreImportReq.class;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveData(List<ExtendExportDto<EmergencyTransferStoreImportReq>> extendExportDto) {
        String bizType = BizTypeThreadHolder.getBizType();

        List<String> storeCodes = extendExportDto.stream().map(ExtendExportDto::getT).map(EmergencyTransferStoreImportReq::getStoreCode).distinct().collect(Collectors.toList());
        emergencyTransferStoreService.remove(Wrappers.lambdaQuery(EmergencyTransferStorePo.class)
                .in(EmergencyTransferStorePo::getStoreCode, storeCodes)
                .eq(EmergencyTransferStorePo::getBizType, bizType)
        );
        emergencyTransferStoreService.saveBatch(storeCodes.stream().map(o -> {
            EmergencyTransferStorePo po = new EmergencyTransferStorePo();
            po.setBizType(bizType);
            po.setStoreCode(o);
            return po;
        }).collect(Collectors.toList()));
    }
}
