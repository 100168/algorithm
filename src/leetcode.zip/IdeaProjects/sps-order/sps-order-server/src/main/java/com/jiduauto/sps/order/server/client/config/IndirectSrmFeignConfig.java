package com.jiduauto.sps.order.server.client.config;

import com.jiduauto.sps.order.server.client.IndirectSrmTokenClient;
import com.jiduauto.sps.order.server.client.req.GetInSrmTokenReq;
import com.jiduauto.sps.order.server.client.resp.IndirectTokenResp;
import feign.RequestInterceptor;
import feign.codec.Decoder;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import java.util.Arrays;

/**
 * @author panjian
 */


public class IndirectSrmFeignConfig {

    @Bean
    public RequestInterceptor requestInterceptor(IndirectSrmTokenClient indirectSrmClient,GetInSrmTokenReq getInSrmTokenReq) {

        return template -> {
            GetInSrmTokenReq req = new GetInSrmTokenReq();
            req.setClient_id(getInSrmTokenReq.getClient_id());
            req.setScope(getInSrmTokenReq.getScope());
            req.setClient_secret(getInSrmTokenReq.getClient_secret());
            req.setGrant_type(getInSrmTokenReq.getGrant_type());
            IndirectTokenResp token = indirectSrmClient.getToken(req.getGrant_type(),req.getClient_id(),req.getClient_secret(),req.getScope());
            template.header("Authorization", token.getToken_type() + " " + token.getAccess_token());
        };
    }

    @Bean
    public Decoder feignDecoder() {
        return new ResponseEntityDecoder(new SpringDecoder(feignMessageConverters()));
    }

    @Bean
    public ObjectFactory<HttpMessageConverters> feignMessageConverters() {

        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setSupportedMediaTypes(Arrays.asList(
                MediaType.APPLICATION_JSON,
                MediaType.APPLICATION_JSON_UTF8,
                MediaType.APPLICATION_FORM_URLENCODED,
                MediaType.TEXT_PLAIN,
                MediaType.TEXT_HTML));

        HttpMessageConverters httpMessageConverters = new HttpMessageConverters(converter);

        return () -> httpMessageConverters;
    }
}
