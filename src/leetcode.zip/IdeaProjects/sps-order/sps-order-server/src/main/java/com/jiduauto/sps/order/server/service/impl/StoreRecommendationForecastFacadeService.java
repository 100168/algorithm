package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.client.TisClient;
import com.jiduauto.sps.order.server.client.resp.ReplacePartsItem;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.order.server.client.resp.TisReplacePartsResp;
import com.jiduauto.sps.order.server.mapper.PurchaseOrderMapper;
import com.jiduauto.sps.order.server.mapper.StoreTransferOrderMapper;
import com.jiduauto.sps.order.server.pojo.dto.InternalStoreRecommendationForecastDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreRecommendationForecastDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreRecommendationForecastExportDto;
import com.jiduauto.sps.order.server.pojo.dto.VirtualQtyDto;
import com.jiduauto.sps.order.server.pojo.fileexport.PurchaseOrderExportDto;
import com.jiduauto.sps.order.server.pojo.po.StandardRecommendationListPo;
import com.jiduauto.sps.order.server.pojo.po.StoreRecommendationListPo;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreRecommendationForecastSearchReq;
import com.jiduauto.sps.order.server.service.IStandardRecommendationListService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.client.req.StockSearchForSS;
import com.jiduauto.sps.sdk.client.resp.StockSearchForSSResp;
import com.jiduauto.sps.sdk.enums.BizTypeEnum;
import com.jiduauto.sps.sdk.enums.PurchaseOrderStatusEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.utils.NumberUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.consts.BaseConstants.ImportExport.PAGE_START_AT;
import static java.util.stream.Collectors.toMap;

@Service
public class StoreRecommendationForecastFacadeService {

    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(4);

    @Resource
    private IStandardRecommendationListService standardRecommendationListService;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private SpsClient spsClient;

    @Resource
    private StoreTransferOrderMapper storeTransferOrderMapper;

    @Value("${MAX_SIZE_10000:10000}")
    private Integer maxSize;

    @Resource
    private PurchaseOrderMapper purchaseOrderMapper;

    @Resource
    private TisClient tisClient;

    public static List<List<String>> splitList(List<String> originalList, int chunkSize) {
        List<List<String>> listOfChunks = new ArrayList<>();

        for (int i = 0; i < originalList.size(); i += chunkSize) {
            int end = Math.min(originalList.size(), i + chunkSize);
            listOfChunks.add(new ArrayList<>(originalList.subList(i, end)));
        }
        return listOfChunks;
    }

    /**
     * 分页查询
     */
    public BasePageData<StoreRecommendationForecastDto> pageSearch(BasePageParam<StoreRecommendationForecastSearchReq> pageParam) {
        StoreRecommendationForecastSearchReq param = pageParam.getParam();
        if (param == null || StrUtil.isBlank(param.getStoreCode())) {
            return BasePageData.empty();
        }
        List<StoreRecommendationListPo> ret;
        BasePageData<StoreRecommendationForecastDto> pageData;
        boolean containStandardRecommendations = isContainStandardRecommendations(param.getBizType(), param.getStoreCode());
        if (!containStandardRecommendations) {
            throw new BizException("该门店，无推荐清单");
        }

        IPage<StandardRecommendationListPo> page = standardRecommendationListService.page(new Page<>(pageParam.getPage(), pageParam.getSize()),
                Wrappers.lambdaQuery(StandardRecommendationListPo.class)
                        .eq(StandardRecommendationListPo::getBizType, param.getBizType())
                        .eq(StandardRecommendationListPo::getStoreCode, param.getStoreCode())
                        .in(CollUtil.isNotEmpty(param.getMaterialCodeList()), StandardRecommendationListPo::getMaterialCode, param.getMaterialCodeList())
        );
        pageData = new BasePageData<>(page);
        ret = page.getRecords().stream().map(o -> BeanUtil.copyProperties(o, StoreRecommendationListPo.class)).collect(Collectors.toList());
        List<String> materialCodeList = ret.stream().map(StoreRecommendationListPo::getMaterialCode).distinct().collect(Collectors.toList());
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(param.getBizType(), materialCodeList, false);

        //按照 100 分割 materialCodeList 成List
        List<List<String>> splitList = splitList(materialCodeList, 100);

        List<CompletableFuture<List<TisReplacePartsResp>>> futures = splitList.stream()
                .map(sublist -> CompletableFuture.supplyAsync(() -> getPartsResps(sublist), EXECUTOR))
                .collect(Collectors.toList());

        CompletableFuture<Void> allOf = CompletableFuture.allOf(
                futures.toArray(new CompletableFuture[0])
        );

        CompletableFuture<List<TisReplacePartsResp>> finalResult = allOf.thenApply(v ->
                futures.stream()
                        .map(CompletableFuture::join)
                        .reduce(new CopyOnWriteArrayList<>(), (l1, l2) -> {
                            l1.addAll(l2);
                            return l1;
                        })
        );
        List<TisReplacePartsResp> data = finalResult.join();

        // 零件+车型 map 存在多个则忽略
        List<TisReplacePartsResp> validData = data.stream().filter(o ->
                Objects.equals(o.getCode(), 0) && CollUtil.isNotEmpty(o.getReplacePartList())
        ).collect(Collectors.toList());


        Set<String> validRepartCodeSet = new HashSet<>();
        Map<String, List<TisReplacePartsResp>> repartCodeMap = validData.stream().collect(Collectors.groupingBy(TisReplacePartsResp::getSalePartNum));

        for (Map.Entry<String, List<TisReplacePartsResp>> entry : repartCodeMap.entrySet()) {
            //    - 如果返回的替换关系有多个车型，零件完全一致，取返回的值
            //    - 如果返回的替换关系有多个车型，零件不一致，忽略，认为没有替换关系
            List<TisReplacePartsResp> value = entry.getValue();
            TisReplacePartsResp first = value.get(0);
            if (value.size() != 1) {
                String calcStr = first.getReplacePartList().stream().map(ReplacePartsItem::getSalePartNum).sorted().collect(Collectors.joining());
                boolean isValid = value.stream().allMatch(o -> o.getReplacePartList().stream().map(ReplacePartsItem::getSalePartNum).sorted().collect(Collectors.joining()).equals(calcStr));
                if (!isValid) {
                    continue;
                }
            }
            validRepartCodeSet.add(first.getSalePartNum());
            List<String> collect = first.getReplacePartList().stream().map(ReplacePartsItem::getSalePartNum).filter(o -> !o.equals(first.getSalePartNum())).collect(Collectors.toList());
            materialCodeList.addAll(collect);
        }


        //根据门店获取对应仓库code,
        Map<String, StockSearchForSSResp> stockMap = new HashMap<>();
        if (CollUtil.isNotEmpty(materialCodeList)) {
            StockSearchForSS req = new StockSearchForSS();
            req.setBizType(BizTypeEnum.SS.getBizType());
            req.setMaterialCodes(materialCodeList);
            req.setStoreCode(param.getStoreCode());
            List<StockSearchForSSResp> stockData = spsClient.ssStockSearch(req).check().getData();
            stockMap = stockData.stream().collect(toMap(StockSearchForSSResp::getMaterialCode, Function.identity(), (k, v) -> v));
        }
        Map<String, VirtualQtyDto> saleMap = saleOrderVirtualQty(param.getBizType(), param.getStoreCode());
        Map<String, VirtualQtyDto> transferQty = transferOrderVirtualQty(BizTypeEnum.SS.getBizType(), param.getStoreCode());

        Map<String, StockSearchForSSResp> finalStockMap = stockMap;
        pageData.setRecords(ret.stream().map(o -> {
            StoreRecommendationForecastDto dto = BeanUtil.copyProperties(o, StoreRecommendationForecastDto.class);
            if (finalStockMap.containsKey(dto.getMaterialCode())) {
                dto.setStoreStockQty(finalStockMap.get(dto.getMaterialCode()).getSumQuantity());
            }
            if (saleMap.containsKey(dto.getMaterialCode())) {
                dto.setInSaleQty(saleMap.get(dto.getMaterialCode()).getQty());
            }
            if (transferQty.containsKey(dto.getMaterialCode())) {
                dto.setInTransferQty(transferQty.get(dto.getMaterialCode()).getQty());
            }
            dto.setMinPackage(materialPoMap.getOrDefault(dto.getMaterialCode(), new MaterialPo()).getMinPackage());
            dto.setMaterialName(materialPoMap.getOrDefault(dto.getMaterialCode(), new MaterialPo()).getMaterialName());
            if (dto.getMinPackage() == null) {
                dto.setMinPackage("1");
            }

            if (validRepartCodeSet.contains(dto.getMaterialCode())) {
                List<ReplacePartsItem> replacePartList = repartCodeMap.get(dto.getMaterialCode()).get(0).getReplacePartList().stream().filter(s -> !s.getSalePartNum().equals(dto.getMaterialCode())).collect(Collectors.toList());

                dto.setReplaceParts(replacePartList.stream().sorted(Comparator.comparing(ReplacePartsItem::getSortNum, Comparator.reverseOrder()))
                        .map(ReplacePartsItem::getSalePartNum)
                        .collect(Collectors.joining(",")));

                //计算替换关系 库存 . 数量 . 在途
                BigDecimal replacePartsStockQty = replacePartList.stream().map(
                        r -> {
                            if (finalStockMap.containsKey(r.getSalePartNum())) {
                                return finalStockMap.get(r.getSalePartNum()).getSumQuantity();
                            }
                            return BigDecimal.ZERO;
                        }
                ).reduce(BigDecimal.ZERO, BigDecimal::add);

                dto.setReplacePartsStockQty(replacePartsStockQty);

                BigDecimal replacePartsInSaleQty = replacePartList.stream().map(
                        r -> {
                            if (saleMap.containsKey(r.getSalePartNum())) {
                                return saleMap.get(r.getSalePartNum()).getQty();
                            }
                            return BigDecimal.ZERO;
                        }
                ).reduce(BigDecimal.ZERO, BigDecimal::add);

                dto.setReplacePartsInSaleQty(replacePartsInSaleQty);

                BigDecimal replacePartsInTransferQty = replacePartList.stream().map(
                        r -> {
                            if (transferQty.containsKey(r.getSalePartNum())) {
                                return transferQty.get(r.getSalePartNum()).getQty();
                            }
                            return BigDecimal.ZERO;
                        }
                ).reduce(BigDecimal.ZERO, BigDecimal::add);

                dto.setReplacePartsInTransferQty(replacePartsInTransferQty);
            }

            dto.setAdviceQty(calcAdviceQty(dto));
            return dto;
        }).sorted(Comparator.comparing(StoreRecommendationForecastDto::getAdviceQty, Comparator.reverseOrder())).collect(Collectors.toList()));
        return pageData;
    }

    private List<TisReplacePartsResp> getPartsResps(List<String> materialCodeList) {
        ResultResp<List<TisReplacePartsResp>> replacePartsResp = tisClient.batchReplaceParts(String.join(",", materialCodeList));
        if (!replacePartsResp.isSuccess()) {
            throw new BizException(replacePartsResp.getMsg());
        }
        return replacePartsResp.getData();
    }

    /**
     * 是否存在标准推荐清单
     */
    private boolean isContainStandardRecommendations(String bizType, String storeCode) {
        return standardRecommendationListService.count(Wrappers.lambdaQuery(StandardRecommendationListPo.class)
                .eq(StandardRecommendationListPo::getBizType, bizType)
                .eq(StandardRecommendationListPo::getStoreCode, storeCode)) > 0;
    }

    private Map<String, VirtualQtyDto> saleOrderVirtualQty(String bizType, String storeCode) {
        Page<PurchaseOrderPo> pageObj = new Page<>(1, Integer.MAX_VALUE);
        pageObj.setOptimizeCountSql(false);
        PurchaseOrderSearchReq req = new PurchaseOrderSearchReq();
        req.setStoreCode(storeCode);
        req.setBizType(bizType);
        req.setPurchaseOrderStatusList(Arrays.asList(
                PurchaseOrderStatusEnum.APPROVED.getCode(),
                PurchaseOrderStatusEnum.TRANSFER_FAILED.getCode(),
                PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL.getCode()
        ));
        IPage<PurchaseOrderExportDto> qtyPage = purchaseOrderMapper.qtySearch(pageObj, req);
        List<PurchaseOrderExportDto> records = qtyPage.getRecords();
        if (CollUtil.isEmpty(records)) {
            return new HashMap<>();
        }
        return records.stream().map(o -> {
            VirtualQtyDto dto = new VirtualQtyDto();
            dto.setMaterialCode(o.getSalePartNum());
            BigDecimal vQty = new BigDecimal(o.getQty()).subtract(new BigDecimal(o.getCancelQty())).subtract(new BigDecimal(o.getReceiveQty()));
            dto.setQty(vQty);
            return dto;
        }).collect(toMap(VirtualQtyDto::getMaterialCode, Function.identity(), (k, v) -> {
            k.setQty(k.getQty().add(v.getQty()));
            return k;
        }));
    }

    private Map<String, VirtualQtyDto> transferOrderVirtualQty(String bizType, String storeCode) {
        return getVirtualQtyMap(storeTransferOrderMapper.queryVirtualQty(bizType, storeCode));
    }

    private Map<String, VirtualQtyDto> getVirtualQtyMap(List<VirtualQtyDto> dtoList) {
        if (CollUtil.isEmpty(dtoList)) {
            return new HashMap<>();
        }
        return dtoList.stream().collect(toMap(VirtualQtyDto::getMaterialCode, Function.identity(), (k, v) -> v));
    }

    /**
     * 计算推荐数量
     */
    private BigDecimal calcAdviceQty(StoreRecommendationForecastDto dto) {
        //  当门店可用库存+销售入库在途+调拨入库在途>MIN，不计算推荐数量，显示为-
        BigDecimal total = dto.getStoreStockQty()
                .add(dto.getInSaleQty())
                .add(dto.getInTransferQty())
                .add(dto.getReplacePartsInSaleQty())
                .add(dto.getReplacePartsInTransferQty())
                .add(dto.getReplacePartsStockQty());
        BigDecimal minPackage = getMinPackage(dto.getMinPackage());
        if (total.compareTo(new BigDecimal(dto.getMinQty())) > 0) {
            return BigDecimal.ZERO;
        } else {
            BigDecimal temp = new BigDecimal(dto.getMaxQty()).subtract(total);
            BigDecimal remainder = temp.remainder(minPackage);
            if (remainder.compareTo(BigDecimal.ZERO) == 0) {
                return temp;
            } else {
                return temp.subtract(remainder).add(minPackage);
            }
        }
    }

    private BigDecimal getMinPackage(String minPackage) {
        if (StrUtil.isBlank(minPackage) || !NumberUtil.isPositiveInteger(minPackage)) {
            return BigDecimal.ONE; // 默认值
        } else {
            return BigDecimal.valueOf(Integer.parseInt(minPackage));
        }
    }

    public BasePageData<InternalStoreRecommendationForecastDto> internalPageSearch(BasePageParam<StoreRecommendationForecastSearchReq> pageParam) {
        if (pageParam.getParam() == null || StrUtil.isBlank(pageParam.getParam().getStoreCode())) {
            throw new BizException("门店编码不能为空");
        }

        BasePageData<StoreRecommendationForecastDto> ret = pageSearch(pageParam);
        List<InternalStoreRecommendationForecastDto> collect =
                ret.getRecords().stream().map(o -> BeanUtil.copyProperties(o, InternalStoreRecommendationForecastDto.class)).collect(Collectors.toList());
        return new BasePageData<>(ret.getTotal(), ret.getSize(), ret.getCurrent(), ret.getPages(), collect);
    }

    /**
     * 导出
     */
    public List<StoreRecommendationForecastExportDto> export(BasePageParam<StoreRecommendationForecastSearchReq> pageParam) {
        List<StoreRecommendationForecastDto> cur;
        List<StoreRecommendationForecastDto> all = new ArrayList<>();
        pageParam.setSize(2000);
        //限制导出最大1万条
        int count = PAGE_START_AT;
        while (all.size() < maxSize && !(cur = pageSearch(pageParam).getRecords()).isEmpty()) {
            pageParam.setPage(++count);
            all.addAll(cur);
        }
        if (CollUtil.isEmpty(all)) {
            return new ArrayList<>();
        }
        return convertToExport(all);
    }

    private List<StoreRecommendationForecastExportDto> convertToExport(List<StoreRecommendationForecastDto> all) {
        return all.stream().map(item -> BeanUtil.copyProperties(item, StoreRecommendationForecastExportDto.class)).collect(Collectors.toList());
    }


}
