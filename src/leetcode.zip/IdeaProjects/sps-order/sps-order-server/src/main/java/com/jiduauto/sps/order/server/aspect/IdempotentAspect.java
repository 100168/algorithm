package com.jiduauto.sps.order.server.aspect;

import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.annotation.IdempotentCheck;
import com.jiduauto.sps.order.server.service.IIdempotentLogService;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;

/**
 * 幂等切面
 */
@Aspect
@Component
@Slf4j
public class IdempotentAspect {

    @Resource
    private IIdempotentLogService idempotentLogService;

    @Resource
    private RedissonClient redissonClient;

    public static final String IDEMPOTENT_NO = "idempotentNo";

    public static final String SPS_ORDER_IDEMPOTENT_CHECK_KEY = "SPS_ORDER:IDEMPOTENT_CHECK_KEY:%s";

    @Pointcut("@annotation(com.jiduauto.sps.order.server.annotation.IdempotentCheck)")
    public void pointcut() {
    }

    @Around("pointcut()")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (servletRequestAttributes == null) {
            // Impossible ignore
            throw new BizException("无法获取请求上下文");
        }
        HttpServletRequest request = servletRequestAttributes.getRequest();
        String idNo = request.getHeader(IDEMPOTENT_NO);

        MethodSignature signature = (MethodSignature) pjp.getSignature();
        Method method = signature.getMethod();
        IdempotentCheck check = method.getAnnotation(IdempotentCheck.class);
        if (check.forceCheck() && StrUtil.isBlank(idNo)) {
            throw new BizException("请求头中 idempotentNo 不能为空");
        }

        // forceCheck == false 则不幂等
        if (StrUtil.isBlank(idNo)) {
            return pjp.proceed();
        } else {
            if (idNo.length() <= 16) {
                // idNo 长度不易过短 容易重复
                throw new BizException("idempotentNo 长度不能小于 16");
            }
        }

        if (idempotentLogService.isExist(idNo, request.getRequestURI())) {
            return BaseResult.OK();
        } else {
            //极小概率存在一种场景   两个相同幂等号请求
            //有一个请求保存幂等log正在提交事务,但是另外一个请求 isExist 结果查询已经为不存在幂等log,
            //则会进入到该逻辑分支, 导致幂等log重复提交
            //不将 isExist 方法放入 redis lock中是因为 大部分请求都是没有重复请求的,
            //只是处理小概率问题, 不应该所有的请求判断幂等都去获取redis锁 浪费性能, 所以由数据库唯一索引兜底即可
            String redisKey = String.format(SPS_ORDER_IDEMPOTENT_CHECK_KEY, idNo);
            RLock rLock = redissonClient.getLock(redisKey);
            try {
                rLock.lock();
                return idempotentLogService.proceedAndSaveIdLog(pjp, idNo);
            } finally {
                if (rLock.isLocked()) {
                    rLock.unlock();
                }
            }
        }
    }

}
