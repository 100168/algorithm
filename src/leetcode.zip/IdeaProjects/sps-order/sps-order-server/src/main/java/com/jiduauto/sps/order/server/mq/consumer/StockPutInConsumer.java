//package com.jiduauto.sps.order.server.mq.consumer;
//
//import com.alibaba.fastjson.JSON;
//import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
//import com.jiduauto.sps.sdk.consts.BaseConstants;
//import com.jiduauto.sps.sdk.enums.StockOperationType;
//import com.jiduauto.sps.sdk.pojo.dto.StockPutInResultMessage;
//import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.rocketmq.common.message.MessageExt;
//import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
//import org.apache.rocketmq.spring.core.RocketMQListener;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.Resource;
//import java.nio.charset.StandardCharsets;
//
//@Slf4j
//@Component
//@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_ORDER_7,
//        topic = BaseConstants.RocketMqTopic.STOCK_PUT_IN,
//        consumeThreadMax = 10)
//public class StockPutInConsumer implements RocketMQListener<MessageExt> {
//
//    @Resource
//    private IWarehouseDistributeOrderService warehouseDistributeOrderService;
//
//    @Override
//    public void onMessage(MessageExt message) {
//        String body = new String(message.getBody(), StandardCharsets.UTF_8);
//        log.info("入库异步处理业务订单:"+body);
//        StockPutInResultMessage resultMessage = JSON.parseObject(body,StockPutInResultMessage.class);
//        if(StockOperationType.SM11.getOperationType().equals(resultMessage.getBusinessType())){
//            //ASN 入库
//            warehouseDistributeOrderService.updateRealInQty(resultMessage);
//        }else if (StockOperationType.SP18.getOperationType().equals(resultMessage.getBusinessType())||
//                StockOperationType.SP19.getOperationType().equals(resultMessage.getBusinessType())){
//            InAndOutStockRequest request = new InAndOutStockRequest();
//            request.setTradeNo(resultMessage.getTradeNo());
//            request.setBizType(resultMessage.getBizType());
//            request.setParams(resultMessage.getStockParams());
//            warehouseDistributeOrderService.updateRealInQty(request);
//        }
//    }
//}
