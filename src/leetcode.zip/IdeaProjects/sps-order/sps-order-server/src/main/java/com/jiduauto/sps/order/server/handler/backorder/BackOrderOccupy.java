package com.jiduauto.sps.order.server.handler.backorder;


import cn.hutool.core.bean.BeanUtil;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderOccupyDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderTransferContextDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PoOccupyStockReq;
import com.jiduauto.sps.order.server.pojo.vo.resp.PoOccupyStockResult;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.pojo.po.BackOrderPo;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.StoreWarehouseConfigPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import com.jiduauto.sps.sdk.utils.MD5Util;
import com.jiduauto.sps.sdk.utils.NumberUtil;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
public abstract class BackOrderOccupy {


    @Resource
    private SpsClient spsClient;

    /**
     * 占用库存
     *
     * @param contextDto
     */
    public void occupy(BackOrderTransferContextDto contextDto) {
        occupyPartStock(contextDto);
    }

    /**
     * 获取运输建议
     *
     * @param materialPo
     * @return
     */
    public abstract String getShippingMethod(MaterialPo materialPo);

    /**
     * 部分占用
     *
     * @param contextDto
     */
    protected void occupyPartStock(BackOrderTransferContextDto contextDto) {
        if (CollectionUtils.isEmpty(contextDto.getBackOrderPos())) {
            return;
        }

        //Map<String, String> salePartNumBackOrderPoMap = contextDto.getBackOrderPos().stream().collect(Collectors.toMap(BackOrderPo::getSalePartNum, BackOrderPo::getBackOrderNo, (p, n) -> n));
        Map<String, List<BoDto>> salePartNumBackOrderPoMap = contextDto.getBackOrderPos().stream()
                .map(o -> BeanUtil.copyProperties(o, BoDto.class))
                .collect(Collectors.groupingBy(BoDto::getSalePartNum));


        // 逐个仓库尝试占用库存
        log.info("PurchaseOrderOccupy#occupyPartStock contextDto param: {}", JsonUtil.toJsonString(contextDto));
        PoOccupyStockReq poOccupyStockReq = convertPoOccupyStockReq(contextDto);
        for (StoreWarehouseConfigPo storeWarehouseConfig : contextDto.getStoreWarehouseConfigs()) {
            if (CollectionUtils.isEmpty(poOccupyStockReq.getInfos())) {
                break;
            }
            poOccupyStockReq.setOccupyNo(contextDto.getPurchaseOrder().getPurchaseOrderNo());
            poOccupyStockReq.setBusinessNo(generateBusinessNo(contextDto, poOccupyStockReq.getInfos()));
            poOccupyStockReq.setWarehouseCode(storeWarehouseConfig.getWarehouseCode());
            BaseResult<Map<String, PoOccupyStockResult>> baseResult;
            try {
                baseResult = spsClient.poOccupyPartStock(poOccupyStockReq);
                log.info("PurchaseOrderOccupy#occupyPartStock param: {}, result: {}", JsonUtil.toJsonString(poOccupyStockReq), JsonUtil.toJsonString(baseResult));
            } catch (Exception e) {
                log.warn(String.format("PurchaseOrderOccupy#occupyPartStock param: %s", JsonUtil.toJsonString(poOccupyStockReq)), e);
                throw e;
            }
            if (baseResult.isSuccess() || baseResult.getCode().equals(SpsResponseCodeEnum.DUPLICATE_OPERATE.getCode())) {
                Map<String, PoOccupyStockResult> poOccupyStockResultMap = baseResult.getData();
                if (MapUtils.isNotEmpty(poOccupyStockResultMap)) {
                    poOccupyStockResultMap = poOccupyStockResultMap.entrySet().stream().filter(item -> item.getValue().getOccupyQuantity().compareTo(BigDecimal.ZERO) > 0).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
                }
                if (MapUtils.isEmpty(poOccupyStockResultMap)) {
                    continue;
                }

                // 添加库存占用情况
                processBoOccupyStockResult(contextDto,
                        poOccupyStockResultMap,
                        salePartNumBackOrderPoMap,
                        storeWarehouseConfig.getWarehouseCode()
                );

                // 取出已占用的数量
                Iterator<PoOccupyStockReq.PoOccupyStockInfo> iterator = poOccupyStockReq.getInfos().iterator();
                while (iterator.hasNext()) {
                    PoOccupyStockReq.PoOccupyStockInfo poOccupyStockInfo = iterator.next();
                    if (poOccupyStockResultMap.containsKey(poOccupyStockInfo.getMaterialCode())) {
                        poOccupyStockInfo.setOccupyQuantity(poOccupyStockInfo.getOccupyQuantity().subtract(poOccupyStockResultMap.get(poOccupyStockInfo.getMaterialCode()).getOccupyQuantity()));
                    }
                    if (poOccupyStockInfo.getOccupyQuantity().compareTo(BigDecimal.ZERO) <= 0) {
                        iterator.remove();
                    }
                }
            }
        }
    }

    private PoOccupyStockReq convertPoOccupyStockReq(BackOrderTransferContextDto contextDto) {
        PoOccupyStockReq poOccupyStockReq = new PoOccupyStockReq();
        poOccupyStockReq.setBizType(contextDto.getPurchaseOrder().getBizType());
        poOccupyStockReq.setInfos(
                new ArrayList<>(contextDto.getBackOrderPos().stream().map(backOrderPo -> {
                    PoOccupyStockReq.PoOccupyStockInfo poOccupyStockInfo = new PoOccupyStockReq.PoOccupyStockInfo();
                    poOccupyStockInfo.setMaterialCode(backOrderPo.getSalePartNum());
                    poOccupyStockInfo.setOccupyQuantity(backOrderPo.getRestBackQty());
                    poOccupyStockInfo.setMinPackage(getMinPackage(contextDto.getMaterialMap().get(backOrderPo.getSalePartNum())));
                    return poOccupyStockInfo;
                }).collect(Collectors.toMap(PoOccupyStockReq.PoOccupyStockInfo::getMaterialCode, Function.identity(), (o1, o2) -> {
                    o1.setOccupyQuantity(o1.getOccupyQuantity().add(o2.getOccupyQuantity()));
                    return o1;
                })).values())
        );
        return poOccupyStockReq;
    }

    private Integer getMinPackage(MaterialPo materialPo) {
        if (Objects.isNull(materialPo) || !NumberUtil.isPositiveInteger(materialPo.getMinPackage())) {
            return 1; // 默认值
        } else {
            return Integer.valueOf(materialPo.getMinPackage());
        }
    }

    private String generateBusinessNo(BackOrderTransferContextDto contextDto,
                                      List<PoOccupyStockReq.PoOccupyStockInfo> infos
    ) {
        List<BackOrderPo> backOrderPos = contextDto.getBackOrderPos();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(contextDto.getPurchaseOrder().getPurchaseOrderNo());
        backOrderPos.stream().sorted(Comparator.comparingLong(BackOrderPo::getId)).forEach(item -> stringBuilder.append(item.getBackOrderNo()));
        infos.stream().sorted(Comparator.comparing(PoOccupyStockReq.PoOccupyStockInfo::getMaterialCode)).forEach(item ->
                stringBuilder.append(item.getOccupyQuantity()).append(item.getMaterialCode())
        );
        if (contextDto.getOperateEnum() == OperateEnum.MANUAL_PART_TURN_ORDER) {
            //管控件 bo 同一个bo单号可能会重复占库, 相同数量, 为保持区分, 加上 RestBackQty 则是唯一的,
            return "BO" + MD5Util.encodeString(stringBuilder.toString()) + "#" + contextDto.getRestBackQty();
        }
        return "BO" + MD5Util.encodeString(stringBuilder.toString());
    }

    private void processBoOccupyStockResult(BackOrderTransferContextDto contextDto,
                                            Map<String, PoOccupyStockResult> poOccupyStockResultMap,
                                            Map<String, List<BoDto>> salePartNumBackOrderPoMap,
                                            String warehouseCode
    ) {
        List<BackOrderOccupyDetailDto> collect = poOccupyStockResultMap.entrySet().stream().map(item -> {
            List<BackOrderOccupyDetailDto> ret = new ArrayList<>();
            List<BoDto> boDtos = salePartNumBackOrderPoMap.get(item.getKey());
            BigDecimal qty = item.getValue().getOccupyQuantity();
            if (boDtos.size() == 1) {
                String boNo = boDtos.get(0).getBackOrderNo();
                ret.add(getBoOccupyDetailDto(boNo, warehouseCode, item.getKey(), qty, getShippingMethod(contextDto.getMaterialMap().get(item.getKey()))));
                return ret;
            } else {
                // 存在重复零件 BO, 按顺序赋值
                //相同零件总需求数量
                Iterator<BoDto> iterator = boDtos.iterator();
                while (iterator.hasNext()) {
                    BoDto boDto = iterator.next();
                    if (qty.compareTo(boDto.getRestBackQty()) >= 0) {
                        ret.add(getBoOccupyDetailDto(boDto.getBackOrderNo(), warehouseCode, item.getKey(), boDto.getRestBackQty(), getShippingMethod(contextDto.getMaterialMap().get(item.getKey()))));
                        qty = qty.subtract(boDto.getRestBackQty());
                        iterator.remove();
                    } else {
                        if (qty.compareTo(BigDecimal.ZERO) == 0) {
                            break;
                        }
                        ret.add(getBoOccupyDetailDto(boDto.getBackOrderNo(), warehouseCode, item.getKey(), qty, getShippingMethod(contextDto.getMaterialMap().get(item.getKey()))));
                        break;
                    }
                }
            }
            return ret;
        }).flatMap(List::stream).collect(Collectors.toList());
        contextDto.getOccupyDetails().addAll(collect);
    }

    private BackOrderOccupyDetailDto getBoOccupyDetailDto(
            String boNo,
            String warehouseCode,
            String salePartNum,
            BigDecimal qty,
            String transferAdvice
    ) {
        BackOrderOccupyDetailDto detailDto = new BackOrderOccupyDetailDto();
        detailDto.setBackOrderNo(boNo);
        detailDto.setDeliverWarehouseCode(warehouseCode);
        detailDto.setTransferAdvice(transferAdvice);
        detailDto.setSalePartNum(salePartNum);
        detailDto.setQuantity(qty);
        return detailDto;
    }

    @Data
    public static class BoDto{
        private String backOrderNo;

        /**
         * 售后件号
         */
        private String salePartNum;

        /**
         * 尝试占用数量
         */
        private BigDecimal occupyQty = BigDecimal.ZERO;

        /**
         * 需要转单的数量
         */
        private BigDecimal restBackQty;
    }

}
