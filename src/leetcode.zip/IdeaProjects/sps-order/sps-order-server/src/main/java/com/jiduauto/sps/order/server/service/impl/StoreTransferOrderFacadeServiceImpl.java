package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Lists;
import com.jiduauto.sps.order.server.convertor.NoticedDtoConvertor;
import com.jiduauto.sps.order.server.pojo.dto.InternalStoreTransferOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalStoreTransferOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreTransferOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderDetailService;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderFacadeService;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.GenerateSerialNoUtil;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.client.SAPRestAdapterClient;
import com.jiduauto.sps.sdk.client.req.PurchaseOrderSyncReq;
import com.jiduauto.sps.sdk.client.resp.PurchaseOrderSyncResp;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.StoreTransferOrderDetailDto;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.pojo.po.StoreTransferOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.StoreTransferOrderPo;
import com.jiduauto.sps.sdk.pojo.po.WarehousePo;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class StoreTransferOrderFacadeServiceImpl implements IStoreTransferOrderFacadeService {

    @Resource
    private IStoreTransferOrderService storeTransferOrderService;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private GenerateSerialNoUtil generateSerialNoUtil;

    @Resource
    private WebhookUtil webhookUtil;

    @Resource
    private NoticedDtoConvertor noticedDtoConvertor;

    @Resource
    private SAPRestAdapterClient sapRestAdapterClient;

    @Resource
    private IStoreTransferOrderFacadeService storeTransferOrderFacadeService;

    @Resource
    private IStoreTransferOrderDetailService storeTransferOrderDetailService;

    @Override
    public BaseResult<String> add(InternalStoreTransferOrderAddReq req) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_TRANSFER_ORDER_IDEMPOTENT_KEY, req.getIdempotentNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            //1. 检查幂等
            StoreTransferOrderPo one = storeTransferOrderService.getOne(Wrappers.<StoreTransferOrderPo>lambdaQuery()
                    .eq(StoreTransferOrderPo::getIdempotentNo, req.getIdempotentNo())
                    .eq(StoreTransferOrderPo::getBizType, req.getBizType())
            );

            if (one != null) {
                return BaseResult.OK(one.getOrderNo());
            }

            //2. checkParam
            checkReq(req);

            //3 save
            StoreTransferOrderPo orderPo = buildPo(req);
            List<StoreTransferOrderDetailPo> detailList = buildDetailPo(req, orderPo.getOrderNo());
            storeTransferOrderService.savePoAndDetail(orderPo, detailList);
            return synSapAndUpdateStatus(orderPo, detailList);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    /**
     * 更新调拨单信息
     */
    @Override
    public BaseResult<String> updateOrder(InternalStoreTransferOrderUpdateReq req) {
        //check data
        StoreTransferOrderPo orderPo = checkUpdateReq(req);

        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_TRANSFER_ORDER_UPDATE_KEY, req.getOrderNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            storeTransferOrderFacadeService.updateOrderInfo(req, orderPo);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
        return BaseResult.OK();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateOrderInfo(InternalStoreTransferOrderUpdateReq req, StoreTransferOrderPo orderPo) {

        StoreTransferOrderPo oldPo = BeanUtil.copyProperties(orderPo, StoreTransferOrderPo.class);

        orderPo.setTransferOutWarehouseCode(req.getTransferOutWarehouseCode());
        orderPo.setTransferOutAddress(req.getTransferOutAddress());
        orderPo.setTransferOutContactName(req.getTransferOutContactName());
        orderPo.setTransferOutContactMobile(req.getTransferOutContactMobile());
        orderPo.setLogisticsNo(req.getLogisticsNo());
        orderPo.setLogisticsCompany(req.getLogisticsCompany());
        orderPo.setRemark(req.getRemark());
        orderPo.setUpdateUser(req.getOperateUser());

        storeTransferOrderService.updateById(orderPo);
        storeTransferOrderService.fieldLog(oldPo, orderPo, req.getOperateUser());
    }

    /**
     * 调拨单取消
     */
    @Override
    public BaseResult<String> cancelOrder(InternalStoreTransferOrderOperateReq req) {
        checkCancelReq(req);
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_TRANSFER_ORDER_UPDATE_KEY, req.getOrderNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            storeTransferOrderService.cancelOrder(req);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
        return BaseResult.OK();
    }

    /**
     * 调拨单提交
     */
    @Override
    public BaseResult<String> internalCommit(InternalStoreTransferOrderOperateReq req) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_TRANSFER_ORDER_UPDATE_KEY, req.getOrderNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            StoreTransferOrderPo orderPo = checkBizTypAndExist(req.getOrderNo(), req.getBizType());

            if (!StoreTransferOrderStatus.WAIT_COMMIT.getValue().equals(orderPo.getOrderStatus())) {
                throw new BizException("当前状态不允许提交");
            }
            List<StoreTransferOrderDetailPo> detailList = storeTransferOrderDetailService.list(Wrappers.lambdaQuery(StoreTransferOrderDetailPo.class)
                    .eq(StoreTransferOrderDetailPo::getOrderNo, req.getOrderNo()));
            orderPo.setUpdateUser(req.getOperateUser());
            return synSapAndUpdateStatus(orderPo, detailList);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    /**
     * 调拨单确认
     */
    @Override
    public BaseResult<String> internalConfirm(InternalStoreTransferOrderOperateReq req) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_TRANSFER_ORDER_UPDATE_KEY, req.getOrderNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            StoreTransferOrderPo orderPo = checkBizTypAndExist(req.getOrderNo(), req.getBizType());

            if (!StoreTransferOrderStatus.COMMITTED.getValue().equals(orderPo.getOrderStatus())) {
                throw new BizException("当前状态不允许确认");
            }

            storeTransferOrderService.updateStatusAndLog(
                    orderPo.getOrderNo(),
                    StoreTransferOrderStatus.CONFIRM,
                    req.getOperateUser(),
                    StoreTransferOrderOperate.CONFIRM
            );
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
        return BaseResult.OK();
    }

    /**
     * 调拨单分页查询
     */
    @Override
    public BasePageData<InternalStoreTransferOrderDto> pageSearch(BasePageParam<InternalStoreTransferOrderReq> pageParam) {
        InternalStoreTransferOrderReq poSearchReq = pageParam.getParam();
        StoreTransferOrderReq searchReq = BeanUtil.copyProperties(poSearchReq, StoreTransferOrderReq.class);

        BasePageParam<StoreTransferOrderReq> basePageParam = new BasePageParam<>();
        BeanUtils.copyProperties(pageParam, basePageParam);
        basePageParam.setParam(searchReq);
        BasePageData<StoreTransferOrderDto> ret = storeTransferOrderService.pageSearch(basePageParam);
        List<InternalStoreTransferOrderDto> collect =
                ret.getRecords().stream().map(o -> BeanUtil.copyProperties(o, InternalStoreTransferOrderDto.class)).collect(Collectors.toList());
        return new BasePageData<>(ret.getTotal(), ret.getSize(), ret.getCurrent(), ret.getPages(), collect);
    }

    /**
     * 调拨单详情分页查询
     */
    @Override
    public BasePageData<InternalStoreTransferOrderDetailDto> internalDetailPageSearch(BasePageParam<InternalStoreTransferOrderDetailSearchReq> pageSearchReq) {
        InternalStoreTransferOrderDetailSearchReq poSearchReq = pageSearchReq.getParam();
        OrderNoReq searchReq = BeanUtil.copyProperties(poSearchReq, OrderNoReq.class);

        BasePageParam<OrderNoReq> basePageParam = new BasePageParam<>();
        BeanUtils.copyProperties(pageSearchReq, basePageParam);
        basePageParam.setParam(searchReq);
        BasePageData<StoreTransferOrderDetailDto> ret = storeTransferOrderDetailService.pageSearch(basePageParam);
        List<InternalStoreTransferOrderDetailDto> collect =
                ret.getRecords().stream().map(o -> BeanUtil.copyProperties(o, InternalStoreTransferOrderDetailDto.class)).collect(Collectors.toList());
        return new BasePageData<>(ret.getTotal(), ret.getSize(), ret.getCurrent(), ret.getPages(), collect);
    }

    private StoreTransferOrderPo checkUpdateReq(InternalStoreTransferOrderUpdateReq req) {
        String bizType = req.getBizType();
        StoreTransferOrderPo orderPo = checkBizTypAndExist(req.getOrderNo(), bizType);
        if (!StoreTransferOrderStatus.canUpdate(orderPo.getOrderStatus())) {
            throw new BizException("当前状态不允许更新");
        }

        baseDataQuery.mapWarehousePo(bizType, Lists.newArrayList(req.getTransferOutWarehouseCode()));
        return orderPo;
    }

    private StoreTransferOrderPo checkBizTypAndExist(String no, String bizType) {
        if (!BizTypeEnum.SS.getBizType().equals(bizType)) {
            throw new BizException(SpsResponseCodeEnum.OPERATE_NOT_SUPPORTED);
        }

        StoreTransferOrderPo po = storeTransferOrderService.getOne(Wrappers.lambdaQuery(StoreTransferOrderPo.class)
                .eq(StoreTransferOrderPo::getOrderNo, no));
        if (po == null) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        return po;
    }

    private void checkCancelReq(InternalStoreTransferOrderOperateReq req) {
        StoreTransferOrderPo po = checkBizTypAndExist(req.getOrderNo(), req.getBizType());
        if (!StoreTransferOrderStatus.canCancel(po.getOrderStatus())) {
            throw new BizException("当前状态不支持取消");
        }
    }

    private BaseResult<String> synSapAndUpdateStatus(StoreTransferOrderPo orderPo, List<StoreTransferOrderDetailPo> detailPos) {
        // 102 不同步SAP 其他同步
        if (StoreTransferOrderAttrEnum.Z2.getCode().equals(orderPo.getOrderAttr())) {
            return BaseResult.OK(orderPo.getOrderNo());
        }

        PurchaseOrderSyncResp purchaseOrderSyncResp = synSap(orderPo, detailPos);
        if (!PurchaseOrderSyncResp.success(purchaseOrderSyncResp)) {
            storeTransferOrderService.statusLog(
                    StoreTransferOrderStatus.WAIT_COMMIT,
                    StoreTransferOrderOperate.SAP_FAIL,
                    orderPo.getOrderNo(),
                    orderPo.getBizType(),
                    orderPo.getUpdateUser()
            );
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo.getOrderNo(), orderPo.getBizType(), JSONUtil.toJsonStr(purchaseOrderSyncResp),
                            BaseConstants.MessageTitle.STO_CREATE_PUSH_SAP));
            webhookUtil.sendMarkdownMessage2Business(webhookUtil.fillNoticed(msgMap), BaseConstants.MessageTitle.STO_CREATE_PUSH_SAP);
            return BaseResult.error(GlobalCodeEnum.GL_FAIL_10000.getCode(),
                    JSONUtil.toJsonStr(purchaseOrderSyncResp.getMessageBody()), orderPo.getOrderNo());
        }

        orderPo.setSapOrderNo(purchaseOrderSyncResp.getMessageBody().get(0).getHeader().getVBELN());
        orderPo.setSapOrderCreateTime(purchaseOrderSyncResp.getMessageBody().get(0).getHeader().getCreateDate());
        boolean update = storeTransferOrderService.update(Wrappers.lambdaUpdate(StoreTransferOrderPo.class)
                .eq(StoreTransferOrderPo::getOrderNo, orderPo.getOrderNo())
                .eq(StoreTransferOrderPo::getBizType, orderPo.getBizType())
                .eq(StoreTransferOrderPo::getOrderStatus, StoreTransferOrderStatus.WAIT_COMMIT.getValue())
                .set(StoreTransferOrderPo::getSapOrderNo, orderPo.getSapOrderNo())
                .set(StoreTransferOrderPo::getSapOrderCreateTime, orderPo.getSapOrderCreateTime())
                .set(StoreTransferOrderPo::getOrderStatus, StoreTransferOrderStatus.COMMITTED.getValue())
                .set(StoreTransferOrderPo::getUpdateUser, orderPo.getUpdateUser())
        );
        if (!update) {
            return BaseResult.error(SpsResponseCodeEnum.DUPLICATE_OPERATE, orderPo.getOrderNo());
        }

        storeTransferOrderService.statusLog(
                StoreTransferOrderStatus.COMMITTED,
                StoreTransferOrderOperate.SAP_APPROVAL,
                orderPo.getOrderNo(),
                orderPo.getBizType(),
                orderPo.getUpdateUser()
        );
        return BaseResult.OK(orderPo.getOrderNo());
    }

    public PurchaseOrderSyncResp synSap(StoreTransferOrderPo orderPo, List<StoreTransferOrderDetailPo> detailPos) {
        PurchaseOrderSyncReq req = PurchaseOrderSyncReq.newInstance();
        req.setStoreTransferOrder(orderPo);
        req.setSTODetail(detailPos);
        Map<String, WarehousePo> warehouseMap = baseDataQuery.mapWarehousePo(BizTypeEnum.getNewBizType(orderPo.getBizType()), Lists.newArrayList(orderPo.getTransferInWarehouseCode(),
                orderPo.getTransferOutWarehouseCode()));
        req.setStoreTransferOrderWarehouse(warehouseMap.get(orderPo.getTransferInWarehouseCode()),
                warehouseMap.get(orderPo.getTransferOutWarehouseCode()),
                StoreTransferOrderAttrEnum.getValue(orderPo.getOrderAttr()));
        return sapRestAdapterClient.syncPurchaseOrder(req);
    }

    private StoreTransferOrderPo buildPo(InternalStoreTransferOrderAddReq req) {
        BigDecimal totalAmount = req.getItemList().stream().map(o ->
                o.getQty().multiply(o.getDiscountUnitPrice())
        ).reduce(BigDecimal.ZERO, BigDecimal::add);

        //非直营的初始状态为已提交
        String status = StoreTransferOrderAttrEnum.Z2.getCode().equals(req.getOrderAttr()) ?
                StoreTransferOrderStatus.COMMITTED.getValue() : StoreTransferOrderStatus.WAIT_COMMIT.getValue();
        StoreTransferOrderPo orderPo = new StoreTransferOrderPo();
        BeanUtil.copyProperties(req, orderPo);
        orderPo.setOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.TR, req.getBizType()));
        orderPo.setOrderAmount(totalAmount);
        orderPo.setCommitTime(req.getCommitTime());
        orderPo.setOrderStatus(status);
        orderPo.setCreateUser(req.getOperateUser());
        orderPo.setUpdateUser(req.getOperateUser());
        return orderPo;
    }

    private List<StoreTransferOrderDetailPo> buildDetailPo(InternalStoreTransferOrderAddReq req, String no) {
        return req.getItemList().stream().map(o -> {
            StoreTransferOrderDetailPo detailPo = new StoreTransferOrderDetailPo();
            detailPo.setBizType(req.getBizType());
            detailPo.setOrderNo(no);
            detailPo.setMaterialCode(o.getMaterialCode());
            detailPo.setQty(o.getQty());
            detailPo.setDiscountUnitPrice(o.getDiscountUnitPrice());
            detailPo.setLineAmount(o.getDiscountUnitPrice().multiply(o.getQty()));
            detailPo.setCreateUser(req.getOperateUser());
            detailPo.setUpdateUser(req.getOperateUser());
            return detailPo;
        }).collect(Collectors.toList());
    }


    private void checkReq(InternalStoreTransferOrderAddReq req) {
        String bizType = req.getBizType();
        if (!BizTypeEnum.SS.getBizType().equals(bizType)) {
            throw new BizException(SpsResponseCodeEnum.OPERATE_NOT_SUPPORTED);
        }
        StoreTransferOrderAttrEnum orderAttrEnum = StoreTransferOrderAttrEnum.getValue(req.getOrderAttr());
        if (orderAttrEnum == null) {
            throw new BizException("orderAttr 订单归属不存在");
        }

        if (req.getTransferInOrganizationCode().equals(req.getTransferOutOrganizationCode())) {
            throw new BizException("调拨组织不能与调出组织一致");
        }

        //check data exist
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(BizTypeEnum.SP.getBizType(), Lists.newArrayList(req.getTransferInOrganizationCode(),
                req.getTransferOutOrganizationCode()));
        if (orderAttrEnum != StoreTransferOrderAttrEnum.ZS01 && storePoMap.values().stream().map(StorePo::getStoreType).distinct().count() != 1) {
            throw new BizException("非 103 订单类型 -- 不同类型下的组织不允许创建调拨单");
        }
        baseDataQuery.mapWarehousePo(bizType, Lists.newArrayList(req.getTransferInWarehouseCode(), req.getTransferOutWarehouseCode()));
        baseDataQuery.mapMaterialPo(bizType,
                req.getItemList().stream()
                        .map(InternalStoreTransferOrderAddReq.Item::getMaterialCode)
                        .distinct().collect(Collectors.toList()));

        Set<String> existCodes = new HashSet<>();
        for (InternalStoreTransferOrderAddReq.Item item : req.getItemList()) {
            if (existCodes.contains(item.getMaterialCode())) {
                throw new BizException(String.format("明细中零件号[%s]重复", item.getMaterialCode()));
            }
            existCodes.add(item.getMaterialCode());
        }
    }
}
