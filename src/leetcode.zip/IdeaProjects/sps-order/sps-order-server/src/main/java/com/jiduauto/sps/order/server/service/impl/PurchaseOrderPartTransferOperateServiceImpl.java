package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.mapper.PurchaseOrderPartTransferOperateMapper;
import com.jiduauto.sps.order.server.pojo.PurchaseOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderTransferContextDto;
import com.jiduauto.sps.order.server.service.IPurchaseOrderPartTransferOperateService;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.PoPartTurnStatus;
import com.jiduauto.sps.sdk.enums.PurchaseOrderStatusEnum;
import com.jiduauto.sps.sdk.pojo.po.BackOrderPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPartTransferOperatePo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 采购订单部分转单操作表 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-12-15
 */
@Service
public class PurchaseOrderPartTransferOperateServiceImpl extends ServiceImpl<PurchaseOrderPartTransferOperateMapper, PurchaseOrderPartTransferOperatePo> implements IPurchaseOrderPartTransferOperateService {

    @Override
    public PurchaseOrderPartTransferOperatePo saveNewPartTransferOperate(BigDecimal qty, Long prDetailId, String turnType) {
        PurchaseOrderPartTransferOperatePo po = new PurchaseOrderPartTransferOperatePo();
        po.setQty(qty);
        po.setPurchaseOrderDetailId(prDetailId);
        po.setCreateUser(UserUtil.getUserName());
        po.setTurnType(turnType);
        po.setTurnStatus(PoPartTurnStatus.PENDING.getCode());
        save(po);
        return po;
    }

    @Override
    public void updateState(PurchaseOrderStatusChangeDto changeDto) {
        if (!changeDto.getNewOrderStatus().equals(PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL)) {
            return;
         }
        if (changeDto.getOperateEnum() != OperateEnum.MANUAL_PART_TURN_ORDER) {
            return;
        }
        PurchaseOrderTransferContextDto context = changeDto.getTransferContextDto();
        if (context != null && CollUtil.isNotEmpty(context.getOtherPurchaseOrderDetails()) && context.getPoPartTransferOperateId() != null) {
            PurchaseOrderPartTransferOperatePo po = new PurchaseOrderPartTransferOperatePo();
            po.setId(context.getPoPartTransferOperateId());
            po.setTurnStatus(PoPartTurnStatus.TRANSFER_SUCCESSFUL.getCode());
            po.setUpdateUser(changeDto.getOperateUser());
            //手动转单, 只会生成 一个 SO 或者 BO
            List<SaleOrderPo> saleOrders = context.getSaleOrders();
            List<BackOrderPo> backOrders = context.getBackOrders();
            po.setSaleOrderNo(CollUtil.isEmpty(saleOrders) ? "" : saleOrders.get(0).getSaleOrderNo());
            po.setBackOrderNo(CollUtil.isEmpty(backOrders) ? "" : backOrders.get(0).getBackOrderNo());
            updateById(po);
        }
    }
}
