package com.jiduauto.sps.order.server.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.jiduauto.sps.order.server.annotation.IdempotentCheck;
import com.jiduauto.sps.order.server.pojo.vo.req.ExternalBeforehandReceiveReq;
import com.jiduauto.sps.order.server.pojo.vo.req.IdIpage;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.NumberNoReq;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.sdk.client.common.AggregateQuery;
import com.jiduauto.sps.sdk.client.req.AsnUpdateReq;
import com.jiduauto.sps.sdk.client.req.SOStockOutTimeAndDeliverQtyReq;
import com.jiduauto.sps.sdk.client.req.SOUpdateLogisticsNoReq;
import com.jiduauto.sps.sdk.client.req.SOUpdateReceiveQtyReq;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.*;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.AggregateQueryUtil;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * sps 需要调用的相关接口
 */
@RestController
@RequestMapping("/spsInternal")
public class SpsInternalController {

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private ISaleOrderDetailService saleOrderDetailService;

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;


    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private IWarehouseDistributeItemPackageService warehouseDistributeItemPackageService;

    @Resource
    private IWarehouseDistributeItemAttachService warehouseDistributeItemAttachService;

    @Resource
    private IWarehouseDistributeItemService warehouseDistributeItemService;

    @Resource
    private IWarehouseDistributeLogisticService warehouseDistributeLogisticService;


    @Resource
    private ISaleOrderUpdateService saleOrderUpdateService;

    /**
     * SO 根据条件查询集合
     * @param req 入参
     */
    @PostMapping("/saleOrder/search")
    public BaseResult<List<SaleOrderPo>> searchSaleOrder(@RequestBody AggregateQuery<SaleOrderPo> req) {
        QueryWrapper<SaleOrderPo> wrapper = AggregateQueryUtil.splicingAggregateQueries(new QueryWrapper<>(), req);
        List<SaleOrderPo> records = saleOrderService.list(wrapper);
        return BaseResult.OK(records);
    }

    /**
     * SO detail 根据条件查询集合
     * @param req 入参
     */
    @PostMapping("/saleOrderDetail/search")
    public BaseResult<List<SaleOrderDetailPo>> searchSaleOrderDetail(@RequestBody AggregateQuery<SaleOrderDetailPo> req) {
        QueryWrapper<SaleOrderDetailPo> wrapper = AggregateQueryUtil.splicingAggregateQueries(new QueryWrapper<>(), req);
        List<SaleOrderDetailPo> records = saleOrderDetailService.list(wrapper);
        return BaseResult.OK(records);
    }

    /**
     * PO  根据条件查询集合
     * @param req 入参
     */
    @PostMapping("/purchaseOrder/search")
    public BaseResult<List<PurchaseOrderPo>> searchPurchaseOrder(@RequestBody AggregateQuery<PurchaseOrderPo> req) {
        QueryWrapper<PurchaseOrderPo> wrapper = AggregateQueryUtil.splicingAggregateQueries(new QueryWrapper<>(), req);
        List<PurchaseOrderPo> records = purchaseOrderService.list(wrapper);
        return BaseResult.OK(records);
    }

    /**
     * PO detail  根据条件查询集合
     * @param req 入参
     */
    @PostMapping("/purchaseOrderDetail/search")
    public BaseResult<List<PurchaseOrderDetailPo>> searchPurchaseOrderDetail(@RequestBody AggregateQuery<PurchaseOrderDetailPo> req) {
        QueryWrapper<PurchaseOrderDetailPo> wrapper = AggregateQueryUtil.splicingAggregateQueries(new QueryWrapper<>(), req);
        List<PurchaseOrderDetailPo> records = purchaseOrderDetailService.list(wrapper);
        return BaseResult.OK(records);
    }

    /**
     * 根据业务单号查仓配订单
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrder/getByBusinessNo")
    @ResponseBody
    public BaseResult<WarehouseDistributeOrderPo> wdOrderGetByBusinessNo(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(warehouseDistributeOrderService.getByBusinessBillOrderNo(req.getBizType(),req.getOrderNo()));
    }

    /**
     * 根据订单号查仓配订单
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrder/getByOrderNo")
    @ResponseBody
    public BaseResult<WarehouseDistributeOrderPo> wdOrderGetByOrderNo(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(warehouseDistributeOrderService.getByOrderNo(req.getBizType(),req.getOrderNo()));
    }

    /**
     * 详情表头脱敏信息
     * 只查基础数据，需要转化code跟name
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrder/selectById")
    @ResponseBody
    public BaseResult<WarehouseDistributeAllDto> wdOrderSelectById(@RequestBody @Valid IdIpage req) {
        return warehouseDistributeOrderService.selectById(req);
    }

    /**
     * 仓配订单预收货
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrder/preReceive")
    @ResponseBody
    public BaseResult<WarehouseDistributeOrderPo> wdOrderPreReceive(@RequestBody @Valid ExternalBeforehandReceiveReq req) {
        return warehouseDistributeOrderService.updateStatus(req);
    }
    /**
     * 仓配订单出库校验
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrder/putOutCheck")
    @ResponseBody
    public BaseResult<List<WarehouseDistributeItemPo>> wdOrderPutOutCheck(@RequestBody @Valid InAndOutStockRequest request) {
        return BaseResult.OK(warehouseDistributeOrderService.checkDeliverQty(request));
    }

    /**
     * 仓配订单入库校验
     */
    @PostMapping("/wdOrder/putInCheck")
    @ResponseBody
    public BaseResult<List<WarehouseDistributeItemPo>> wdOrderPutInCheck(@RequestBody @Valid InAndOutStockRequest request) {
        return BaseResult.OK(warehouseDistributeOrderService.checkReceiveQty(request));
    }

    /**
     * 分页查询
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrderItemPackage/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<WarehouseDistributePackageItemDto>> pageSearchWdPackage(@RequestBody @Valid BasePageParam<NumberNoReq> req) {
        return warehouseDistributeItemPackageService.pageSearch(req);
    }

    /**
     * 仓配零件附属信息分页查询
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrderItemAttach/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<WarehouseDistributeAttachItemDto>> pageSearchItemWdAttach(@RequestBody @Valid BasePageParam<NumberNoReq> req) {
        return warehouseDistributeItemAttachService.pageSearch(req);
    }

    /**
     * 仓配基本信息分页查询
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrderItem/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<WarehouseDistributeOrderItemDto>> pageSearchWdItem(@RequestBody @Valid BasePageParam<NumberNoReq> req) {
        return warehouseDistributeItemService.pageSearch(req);
    }

    /**
     * 仓配基本信息分页查询
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrderItem/list")
    @ResponseBody
    public BaseResult<List<WarehouseDistributeItemPo>> getWdItemList(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(warehouseDistributeItemService.selectList(req.getOrderNo()));
    }


    /**
     * 仓配基本信息分页查询
     * @author O_chaopeng.huang
     */
    @PostMapping("/wdOrderLogistic/getByOrderNo")
    @ResponseBody
    public BaseResult<WarehouseDistributeLogisticDto> getWdOrderLogistic(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(warehouseDistributeLogisticService.selectWarehouseDistributeLogistic(req.getBizType(),req.getOrderNo()));
    }

    /**
     * 根据采购订单明细的收货,取消数量计算是否更新采购订单状态
     * 对于涉及 SO, BO 收货数量变更 & 取消的地方,都需要调用该方法
     * @see <a href="https://wiki.jiduauto.com/pages/viewpage.action?pageId=702735548">需求文档</>
     */
    @PostMapping("/updateStateByReceiveQtyAndCancelQty")
    public BaseResult<String> updateStateByReceiveQtyAndCancelQty(String poNo, String bizType) {
        purchaseOrderService.updateStateByReceiveQtyAndCancelQty(poNo, bizType);
        return BaseResult.OK();
    }

    /**
     * 销售订单 更新出库时间结果 & 更新出库数量结果
     */
    @Deprecated
    @IdempotentCheck
    @PostMapping("/updateStockOutTimeAndDeliverQty")
    public BaseResult<String> updateStockOutTimeAndDeliverQty(@RequestBody SOStockOutTimeAndDeliverQtyReq req) {
        saleOrderService.updateStockOutTimeAndDeliverQty(req);
        return BaseResult.OK();
    }


    /**
     * ASN欠收更新发货数量 更新 so , po 发收货数量 & 状态
     */
    @IdempotentCheck
    @PostMapping("/updateReceiveInfoByASN")
    public BaseResult<String> updateReceiveInfoByASN(@RequestBody AsnUpdateReq req) {
        saleOrderUpdateService.updateReceiveInfoByASN(req);
        return BaseResult.OK();
    }

    /**
     * 删除ASN更新发货数量
     */
    @IdempotentCheck
    @PostMapping("/decreaseDeliveryQtyForDfs")
    BaseResult<String> decreaseDeliveryQtyForDfs(@RequestBody AsnUpdateReq req) {
        saleOrderUpdateService.decreaseDeliveryQtyForDfs(req.getAsnBasicPo(), req.getAsnDeliverInfoPos());
        return BaseResult.OK();
    }

    /**
     * 创建ASN更新发货数量
     */
    @IdempotentCheck
    @PostMapping("/increaseDeliveryQtyForDfs")
    public BaseResult<String> increaseDeliveryQtyForDfs(@RequestBody AsnUpdateReq req) {
        saleOrderUpdateService.increaseDeliveryQtyForDfs(req.getAsnBasicPo(), req.getAsnDeliverInfoPos());
        return BaseResult.OK();
    }

    /**
     * 销售订单更新收货数量
     */
    @IdempotentCheck
    @PostMapping("/updateReceiveQty")
    public BaseResult<String> updateReceiveQty(@RequestBody SOUpdateReceiveQtyReq req) {
        saleOrderService.updateReceiveQty(req.getSaleOrderNo(), req.getInQuantityList());
        return BaseResult.OK();
    }


    /**
     * 更新销售订单物流信息
     */
    @IdempotentCheck
    @PostMapping("/updateLogisticsNo")
    BaseResult<String> updateLogisticsNo(@RequestBody SOUpdateLogisticsNoReq req) {
        saleOrderService.updateLogisticsNo(req.getSaleOrderNo(), req.getLogisticsNo(), req.getTransportType());
        return BaseResult.OK();
    }


    /**
     * 仓配订单撤销
     */
    @PostMapping("/repealWdo")
    BaseResult<String> repealWdo(@RequestBody OrderNoReq req) {
        warehouseDistributeOrderService.repeal(req);
        return BaseResult.OK();
    }


}
