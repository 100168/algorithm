package com.jiduauto.sps.order.server.controller;

import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderDto;
import com.jiduauto.sps.order.server.pojo.fileexport.PurchaseOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.ControlTransferReq;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderSearchReq;
import com.jiduauto.sps.order.server.service.IPurchaseOrderService;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.ExcelUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 *  采购订单页面接口
 */
@RestController
@RequestMapping("/spsInternal/po")
public class SpsInternalPOController {


    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<PurchaseOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<PurchaseOrderSearchReq> pageParam) {
        return BaseResult.OK(purchaseOrderService.pageSearch(pageParam));
    }

    /**
     * 手工转单
     *
     * @param idReq
     * @return
     */
    @PostMapping("/transferOrder")
    public BaseResult<String> transferOrder(@RequestBody @Valid IdReq idReq) {
        purchaseOrderService.transferOrder(OperateEnum.MANUAL_TRANSFER, idReq.getId());
        return BaseResult.OK();
    }

    /**
     * 手工转采购申请
     *
     * @param idReq
     * @return
     */
    @PostMapping("/transferPurchaseApply")
    public BaseResult<String> transferPurchaseApply(@RequestBody @Valid IdReq idReq) {
        purchaseOrderService.transferPurchaseApply(OperateEnum.MANUAL_TRANSFER_ORDER_PLAN, idReq.getId());
        return BaseResult.OK();
    }

    /**
     * 导出
     **/
    @RequestMapping("/export")
    public void export(HttpServletResponse response, @RequestBody @Valid BasePageParam<PurchaseOrderSearchReq> pageParam){
        try {
            ExcelUtils.exportXlsxResponse(response, "门店采购订单查询结果");
            EasyExcel.write(response.getOutputStream(), PurchaseOrderExportDto.class)
                    .sheet("门店采购订单查询结果").doWrite(purchaseOrderService.exportSearch(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

    /**
     * 管控件转单
     */
    @PostMapping("/controlTransfer")
    public BaseResult<String> controlTransfer(@RequestBody @Valid ControlTransferReq idReq) {
        purchaseOrderService.controlTransfer(idReq);
        return BaseResult.OK();
    }
}
