package com.jiduauto.sps.order.server.config;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.sdk.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * 自动填充创建人修改人
 *
 * @author HuangKun
 * @date 2022/10/9
 */
@Slf4j
public class CustomMetaObjectHandler implements MetaObjectHandler {

    private static final String CREATE_USER = "createUser";
    private static final String UPDATE_USER = "updateUser";
    private static final String UPDATE_TIME = "updateTime";

    /**
     * 插入元对象字段填充（用于插入时对公共字段的填充）
     *
     * @param metaObject 元对象
     */
    @Override
    public void insertFill(MetaObject metaObject) {
        String userName = UserUtil.getUserName();
        strictInsertFill(metaObject, CREATE_USER, String.class, userName);
    }

    /**
     * 更新元对象字段填充（用于更新时对公共字段的填充）
     *
     * @param metaObject 元对象
     */
    @Override
    public void updateFill(MetaObject metaObject) {
        if (StrUtil.isNotEmpty((String) metaObject.getValue(UPDATE_USER))) {
            return;
        }
        strictUpdateFill(metaObject, UPDATE_TIME, LocalDateTime.class, LocalDateTime.now());
        String userName = UserUtil.getUserName();
        if (Objects.nonNull(userName)) {
            strictUpdateFill(metaObject, UPDATE_USER, String.class, userName);
        }else {
            strictUpdateFill(metaObject, UPDATE_USER, String.class, StringUtils.EMPTY);
        }
    }

    /**
     * 重写源码,源码是默认有值不覆盖,如果提供的值为null也不填充
     * @param metaObject
     * @param fieldName
     * @param fieldVal
     * @return
     */
    @Override
    public MetaObjectHandler strictFillStrategy(MetaObject metaObject, String fieldName, Supplier<?> fieldVal) {
        if (UPDATE_USER.equals(fieldName)) {
            if (Objects.nonNull(fieldVal)) {
                metaObject.setValue(fieldName, fieldVal.get());
            }
        } else if (getFieldValByName(fieldName, metaObject) == null) {
            setFieldValByName(fieldName, fieldVal.get(), metaObject);
        }
        return this;
    }

}
