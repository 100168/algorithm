package com.jiduauto.sps.order.server.mq.consumer;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.OutboundTypeEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderStatusEnum;
import com.jiduauto.sps.sdk.pojo.dto.OutboundApplyOrderMsg;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_ORDER_OUTBOUND_APPLY_ORDER_STATUS_CHANGE,
        topic = BaseConstants.RocketMqTopic.OUT_BOUND_APPLY_ORDER_STATUS_CHANGE,
        consumeThreadMax = 10)
public class OutboundApplyOrderConsumer implements RocketMQListener<MessageExt> {

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("OutboundApplyOrderConsumer#onMessage messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
        String tag = message.getTags();

        OutboundApplyOrderMsg msg = JSONUtil.toBean(body, OutboundApplyOrderMsg.class);
        if (Objects.equals(tag, BaseConstants.OutboundApplyOrderOperate.REPEAL)) {
            warehouseDistributeOrderService.update(Wrappers.<WarehouseDistributeOrderPo>lambdaUpdate()
                    .eq(WarehouseDistributeOrderPo::getOrderNo, msg.getOrderNo())
                    .set(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.CREATED.getCode())
            );
            return;
        }
        if (Objects.equals(tag, BaseConstants.OutboundApplyOrderOperate.COMPLETE)) {
            warehouseDistributeOrderService.updateRealOutForPickOrder(msg);
            return;
        }
        if (Objects.equals(tag, BaseConstants.OutboundApplyOrderOperate.PICKED)) {
            warehouseDistributeOrderService.updateStatus(msg, WarehouseDistributeOrderStatusEnum.PICKED.getCode());
        }
        if (Objects.equals(tag, BaseConstants.OutboundApplyOrderOperate.CANCEL)) {
            warehouseDistributeOrderService.updateStatus(msg, WarehouseDistributeOrderStatusEnum.DELIVERED.getCode());
        }
    }
}
