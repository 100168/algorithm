package com.jiduauto.sps.order.server.mapper;

import com.jiduauto.sps.order.server.pojo.po.EmergencyTransferStorePo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 应急调拨门店 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-11-04
 */
public interface EmergencyTransferStoreMapper extends BaseMapper<EmergencyTransferStorePo> {

}
