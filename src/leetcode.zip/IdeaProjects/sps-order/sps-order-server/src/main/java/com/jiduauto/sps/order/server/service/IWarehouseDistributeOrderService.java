package com.jiduauto.sps.order.server.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.client.resp.IndirectSrmWDCloseResp;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.WarehouseDistributeOrderAllPo;
import com.jiduauto.sps.order.server.pojo.dto.StockPutOutResultMessage;
import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeOrderAllDto;
import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.WarehouseDistributeOrderPageSearchReq;
import com.jiduauto.sps.sdk.client.req.StockOutMapBusinessDto;
import com.jiduauto.sps.sdk.pojo.dto.CommonFileAttachmentDto;
import com.jiduauto.sps.sdk.pojo.dto.OutboundApplyOrderMsg;
import com.jiduauto.sps.sdk.pojo.dto.StockPutInResultMessage;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeAllDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeOrderDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.*;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 仓配订单 服务类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
public interface IWarehouseDistributeOrderService extends IService<WarehouseDistributeOrderPo> {

    /**
     * 更新 仓配订单的 物流单号
     * @param id 订单Id
     * @param logisticsNo 物流单号
     */
    void updateLogisticsNo(Long id, String logisticsNo);

    /**
     * 更新 仓配订单的 物流单号 和订单状态
     *
     * @param id          订单Id
     * @param logisticsNo 物流单号
     */
    void updateLogisticsNoAndStatus(Long id, String logisticsNo);


    StockOutMapBusinessDto createStockOutMapBusinessDto(WarehouseDistributeOrderPo po, WarehouseDistributeLogisticPo logisticPo);

    /**
     * 仓配订单取消
     * @param request request
     * @return rest
     */
    Boolean cancel(WarehouseDistributeOrderCancelReq request, boolean isApi);

    /**
     * 仓配订单取消
     */
    Boolean cancel(IdReq req);

    /**
     * 仓配订单创建
     * @param request request
     * @return orderNo 订单号
     */
    WarehouseDistributeOrderAllPo add(WarehouseDistributeOrderAddReq request,boolean isApi);

    WarehouseDistributeOrderPo getByBusinessBillOrderNo(String bizType, String businessBillNo);

    List<WarehouseDistributeOrderPo> getByBusinessBillOrderNoList(String bizType, List<String> businessBillNoList);
    /**
     * 根据 订单号 找仓配订单
     *
     * @param bizType        bizType
     * @param orderNo orderNo
     * @return WarehouseDistributeOrderPo
     */
    WarehouseDistributeOrderPo getByOrderNo(String bizType, String orderNo);

    /**
     * 仓配订单修改订单状态并同步给sap
     *
     * @param warehouseDistributeOrderPo warehouseDistributeOrderPo
     */
    void pushToSap(WarehouseDistributeOrderPo warehouseDistributeOrderPo);
    /**
     * 占库
     */
    void occupyStock(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo);

    /**
     * 更新库存状态并同步dhl
     * @param msg request
     */
    void updateStatusAndSyncDhlIfSuccess(StockPutOutResultMessage msg);
    /**
     * 仓配订单占库重试
     */
    void reOccupy();
    /**
     * 仓配订单分页查询
     */
    BaseResult<BasePageData<WarehouseDistributeOrderDto>> pageSearch(BasePageParam<WarehouseDistributeOrderPageSearchReq> req);

    /**
     *
     * 设置name*/
    List<WarehouseDistributeOrderDto> getWarehouseDistributeOrderDtoList(List<WarehouseDistributeOrderPo> records, String bizType);

    Map<String, Map<String, String>> getStringMapMap(String bizType, List<String> list);

    BaseResult<WarehouseDistributeAllDto> selectById(IdIpage req);

    /**
     * 导出
     */
    List<WarehouseDistributeOrderExportDto> getExportDtoList(BasePageParam<WarehouseDistributeOrderPageSearchReq> pageParam);

    /**
     * 仓配订单预收货结果同步状态变更
     * @author O_chaopeng.huang
     */
    BaseResult<WarehouseDistributeOrderPo> updateStatus(ExternalBeforehandReceiveReq receive);

    /**
     * 仓配订单撤销
     * @author O_chaopeng.huang
     */
    void repeal(OrderNoReq orderNoReq);

    /**
     * 仓配订单修改实际入库数量
     * @author O_chaopeng.huang
     */
    void updateRealInQty(ReceiveReq req);

    /**
     * 更新入库数量
     *
     * @param request 单号
     */
    void updateRealInQty(InAndOutStockRequest request);

    /**
     * 更新入库数量
     *
     * @param resultMessage 单号
     */
    void updateRealInQty(StockPutInResultMessage resultMessage);

    /**
     * 校验出库数量
     *
     * @param request  赋值字段：  bizType materialLineNo materialCode qty
     * @return Map<String, InAndOutStockParam>
     */
    List<WarehouseDistributeItemPo> checkDeliverQty(InAndOutStockRequest request);
    /**
     * 更新实出数量
     *
     * @param orderNo 单号
     * @param outQuantityList  赋值字段：  bizType materialLineNo materialCode qty
     */
    void updateDeliverQty(String orderNo, String expressNo, Map<String, WarehouseDistributeItemPo> outQuantityList);
    /**
     * 详情表头未脱敏
     * @author O_chaopeng.huang
     */
    BaseResult<WarehouseDistributeAllDto> selectNoHide(IdIpage req);
    /**
     * 物流轨迹查询
     * @author O_chaopeng.huang
     */
    List<TrackDetailItemResp> trackDetail(OrderNoReq req);

    WarehouseDistributeOrderAllPo buildAllPo(WarehouseDistributeOrderPo orderPo);

    /**
     *校验间采入库数量*/
    List<WarehouseDistributeItemPo> checkReceiveQty(InAndOutStockRequest request);

    /**
     * 仓配订单删除*/
    void deleteByIds(IdBatchReq req);

    /**
     * 仓配订单确认*/
    Boolean confirm(IdReq req);

    /**
     * 仓配订单修改*/
    void edit(WarehouseDistributeOrderAddReq req);

    List<CommonFileAttachmentDto> upload(String bizType, MultipartFile[] files);

    /**
     * 根据单号查询附件
     */
    List<CommonFileAttachmentDto> attachmentFile(NoReq req);

    /**
     * 导入订单
     */
    ImportResultResp createOrderByImport(String bizType, MultipartFile file);

    /**
     * 反写实际出库数量
     */
    void updateRealOutForPickOrder(OutboundApplyOrderMsg msg);

    /**
     * 更改状态为已拣货
     */
    void updateStatus(OutboundApplyOrderMsg msg,String status);

    WarehouseDistributeOrderAllDto detail(OrderNoReq orderNoReq);

    boolean isSpecialWarehouse(String bizType,String warehouseCode);

    Boolean updateLogistic(WarehouseDistributeOrderAddReq request);

    Boolean close(IdReq req);

    void fork(WarehouseDistributeOrderAddReq req, List<WarehouseDistributeItemPo> warehouseDistributeItemPos,WarehouseDistributeOrderPo po);


    /**
     * 内领订单关闭 同步结果到SRM
     * @param orderPo
     * @return
     */
    IndirectSrmWDCloseResp syncWDApplyOrderCloseTOSrm(WarehouseDistributeOrderPo orderPo);

    /**
     * 内领订单 出库结果同步到SRM
     * @param message
     */
    void syncWDApplyOrderPutOutTOSrm(String message);

    void delete(@Valid IdReq req);

    List<WarehouseDistributeOrderDto> listChild(OrderNoReq req);
}
