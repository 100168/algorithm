package com.jiduauto.sps.order.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.order.server.facade.WarehouseDistributeOrderFacadeService;
import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeOrderAllDto;
import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.IdIpage;
import com.jiduauto.sps.order.server.pojo.vo.req.TrackDetailItemResp;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.WarehouseDistributeOrderPageSearchReq;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.CommonFileAttachmentDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeAllDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeOrderDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.req.IdBatchReq;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.NoReq;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * 仓配订单 前端控制器
 *
 * @author generate
 * @since 2023-07-12
 */
@Slf4j
@RestController
@RequestMapping("/warehouseDistributeOrder")
public class WarehouseDistributeOrderController {
    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private WarehouseDistributeOrderFacadeService warehouseDistributeOrderFacadeService;

    /**
     * 分页查询
     *
     * @author O_chaopeng.huang
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<WarehouseDistributeOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<WarehouseDistributeOrderPageSearchReq> req) {
        return warehouseDistributeOrderService.pageSearch(req);
    }

    /**
     * 详情表头脱敏信息
     *
     * @author O_chaopeng.huang
     */
    @PostMapping("/selectById")
    @ResponseBody
    public BaseResult<WarehouseDistributeAllDto> selectById(@RequestBody @Valid IdIpage req) {
        return warehouseDistributeOrderService.selectById(req);
    }

    /**
     * 详情表头不脱敏信息
     *
     * @author O_chaopeng.huang
     */
    @PostMapping("/selectNoHide")
    @ResponseBody
    public BaseResult<WarehouseDistributeAllDto> selectNoHide(@RequestBody @Valid IdIpage req) {
        return warehouseDistributeOrderService.selectNoHide(req);
    }

    /**
     * 物流轨迹
     *
     * @param req 运单号
     * @author O_chaopeng.huang
     */
    @PostMapping("/trackDetail")
    public BaseResult<List<TrackDetailItemResp>> trackDetail(@RequestBody OrderNoReq req) {
        return BaseResult.OK(warehouseDistributeOrderService.trackDetail(req));
    }

    /**
     * 仓配订单导出
     **/
    @RequestMapping("/export")
    public void export(HttpServletResponse response, @RequestBody @Valid BasePageParam<WarehouseDistributeOrderPageSearchReq> pageParam) {
        try {
            ExcelUtils.exportXlsxResponse(response, "仓配信息");
            EasyExcel.write(response.getOutputStream(), WarehouseDistributeOrderExportDto.class).sheet("仓配信息").doWrite(warehouseDistributeOrderService.getExportDtoList(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

    /**
     * 仓配订单新建
     *
     * @author jian.pan
     */
    @PostMapping("/create")
    @ResponseBody
    public BaseResult<String> create(@RequestBody @Valid WarehouseDistributeOrderAddReq req) {
        warehouseDistributeOrderFacadeService.create(req);
        return BaseResult.OK();
    }

    /**
     * 仓配订单编辑
     *
     * @author jian.pan
     */
    @PostMapping("/edit")
    @ResponseBody
    public BaseResult<String> edit(@RequestBody @Validated(WarehouseDistributeOrderAddReq.Edit.class) WarehouseDistributeOrderAddReq req) {
        warehouseDistributeOrderService.edit(req);
        return BaseResult.OK();
    }


    /**
     * 仓配订单删除
     *
     * @author jian.pan
     */
    @PostMapping("/delete")
    @ResponseBody
    public BaseResult<String> delete(@RequestBody @Valid IdBatchReq req) {
        warehouseDistributeOrderService.deleteByIds(req);
        return BaseResult.OK();
    }

    /**
     * 仓配订单确认
     *
     * @author jian.pan
     */
    @PostMapping("/confirm")
    public BaseResult<Boolean> confirm(@RequestBody @Valid IdReq req) {
        return BaseResult.OK(warehouseDistributeOrderService.confirm(req));
    }

    /**
     * 仓配取消
     *
     * @author jian.pan
     */
    @PostMapping("/cancel")
    public BaseResult<Boolean> cancel(@RequestBody @Valid IdReq req) {
        return BaseResult.OK(warehouseDistributeOrderService.cancel(req));
    }

    /**
     * 仓配关闭
     *
     * @author jian.pan
     */
    @PostMapping("/close")
    public BaseResult<Boolean> close(@RequestBody @Valid IdReq req) {
        return BaseResult.OK(warehouseDistributeOrderService.close(req));
    }

    /**
     * 仓配订单附件文件上传
     */
    @PostMapping("/upload")
    public BaseResult<List<CommonFileAttachmentDto>> upload(@RequestHeader("bizType") String bizType, @RequestPart("files") MultipartFile[] files) {
        return BaseResult.OK(warehouseDistributeOrderService.upload(bizType, files));
    }

    /**
     * 仓配订单附件文件查询
     */
    @PostMapping("/attachmentFile")
    public BaseResult<List<CommonFileAttachmentDto>> attachmentFile(@RequestBody @Valid NoReq req) {
        return BaseResult.OK(warehouseDistributeOrderService.attachmentFile(req));
    }

    /**
     * 仓配订单导入
     */
    @PostMapping("/import")
    public BaseResult<ImportResultResp> createOrderByImport(@RequestHeader("bizType") String bizType, @RequestPart("file") MultipartFile file) {
        return BaseResult.OK(warehouseDistributeOrderService.createOrderByImport(bizType, file));
    }

    /**
     * 仓配订单详情数据回显
     * @author jian.pan
     */
    @PostMapping("/detail")
    public BaseResult<WarehouseDistributeOrderAllDto> detail(@RequestBody @Valid OrderNoReq orderNoReq) {
        return BaseResult.OK(warehouseDistributeOrderService.detail(orderNoReq));
    }

    /**
     * 仓配订单拆单
     *
     * @author jian.pan
     */
    @PostMapping("/fork")
    @ResponseBody
    public BaseResult<String> fork(@RequestBody @Valid WarehouseDistributeOrderAddReq req) {
        warehouseDistributeOrderFacadeService.fork(req);
        return BaseResult.OK();
    }

    /**
     * 内领子单删除
     * @author jian.pan
     */
    @PostMapping("/deleteChild")
    public BaseResult<String> delete(@RequestBody @Valid IdReq req) {
        warehouseDistributeOrderService.delete(req);
        return BaseResult.OK();
    }

    /**
     * 内领子单
     * @author jian.pan
     */
    @PostMapping("/listChild")
    public BaseResult<List<WarehouseDistributeOrderDto>> listChild(@RequestBody @Valid OrderNoReq req) {
        return BaseResult.OK(warehouseDistributeOrderService.listChild(req));
    }

}
