package com.jiduauto.sps.order.server.client.config;

import feign.Util;
import feign.auth.BasicAuthRequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

public class SpsFeignConfig {

    @Value("${feign.url.sps.username}")
    private String username;

    @Value("${feign.url.sps.password}")
    private String password;

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password, Util.UTF_8);
    }
}
