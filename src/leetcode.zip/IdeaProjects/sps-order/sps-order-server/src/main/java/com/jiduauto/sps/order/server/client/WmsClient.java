package com.jiduauto.sps.order.server.client;

import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.pojo.req.AsnAddSyncReq;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author panjian
 */
@FeignClient(name = "wms-partner",url = "${sps.wms.pushAsn.url}", fallbackFactory = WmsClient.WmsClientFallbackFactory.class)
public interface WmsClient {


    /**
     * wsm接收asn 推送
     * @param asnAddSyncReq
     * @return
     */
    @PostMapping("/JIDU/asn")
    ResultResp<Object> pushAsn(AsnAddSyncReq asnAddSyncReq);

    @Slf4j
    @Component
    class WmsClientFallbackFactory implements FallbackFactory<WmsClient>{

        @Override
        public WmsClient create(Throwable throwable) {
            return new WmsClient() {
                @Override
                public ResultResp<Object> pushAsn(AsnAddSyncReq asnAddSyncReq) {
                    log.warn(String.format("SyncWmsClient#pushAsn error, param: %s", JsonUtil.ObjectToJson(asnAddSyncReq)), throwable);
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }
            };
        }
    }

}
