package com.jiduauto.sps.order.server.mq;

import com.jiduauto.sps.order.server.pojo.PurchaseOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderMessageDto;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import com.jiduauto.sps.sdk.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.producer.LocalTransactionState;
import org.apache.rocketmq.client.producer.SendStatus;
import org.apache.rocketmq.client.producer.TransactionSendResult;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

import static com.jiduauto.sps.sdk.enums.OperateEnum.MANUAL_PART_TURN_ORDER;

@Slf4j
@Component
public class RocketMqTxProducer {

    @Resource
    private RocketMQTemplate rocketMQTemplate;

    /**
     * 发送采购订单状态变更消息
     *
     * @param changeDto
     * @return
     */
    public boolean sendPurchaseOrderStatusChangeMessage(PurchaseOrderStatusChangeDto changeDto) {
        if (StringUtils.isEmpty(changeDto.getNewOrderStatus().getMsgTag())) {
            return false;
        }

        PurchaseOrderMessageDto messageDto = BeanCopierUtil.copy(changeDto.getPurchaseOrderPo(), PurchaseOrderMessageDto.class);
        Long poPartTransferOperateId = null;
        if (changeDto.getTransferContextDto() != null && changeDto.getOperateEnum() == MANUAL_PART_TURN_ORDER) {
            poPartTransferOperateId = changeDto.getTransferContextDto().getPoPartTransferOperateId();
            messageDto.setPartTransferOperateId(poPartTransferOperateId);
        }
        messageDto.setPurchaseOrderStatus(changeDto.getNewOrderStatus().getCode());
        messageDto.setIsControlTurn(changeDto.getOperateEnum() == MANUAL_PART_TURN_ORDER);

        String message = JsonUtil.toJsonString(messageDto);
        String destination = BaseConstants.RocketMqTopic.PURCHASE_ORDER.concat(":").concat(changeDto.getNewOrderStatus().getMsgTag());
        try {
            TransactionSendResult sendResult = rocketMQTemplate.sendMessageInTransaction(destination, MessageBuilder
                    .withPayload(message)
                    .setHeader("purchaseOrderNo", changeDto.getPurchaseOrderPo().getPurchaseOrderNo())
                    .setHeader("purchaseOrderNewStatus", changeDto.getNewOrderStatus().getCode())
                    //是否是管控件转单
                    .setHeader("isControlTurnOrder", changeDto.getOperateEnum() == MANUAL_PART_TURN_ORDER)
                    .setHeader("poPartTransferOperateId", poPartTransferOperateId)
                    .build(), changeDto);
            if (sendResult != null
                    && SendStatus.SEND_OK == sendResult.getSendStatus()
                    && LocalTransactionState.COMMIT_MESSAGE.equals(sendResult.getLocalTransactionState())) {
                log.info("sendPurchaseOrderStatusMessage success, destination: {}, message: {}, sendResult: {}", destination, message, JsonUtil.toJsonString(sendResult));
                return true;
            }
            log.error("sendPurchaseOrderStatusMessage failed, destination: {}, message: {}", destination, message);
            return false;
        } catch (Exception e) {
            log.error(String.format("sendPurchaseOrderStatusMessage failed, destination: %s, message: %s", destination, message), e);
            return false;
        }
    }
}
