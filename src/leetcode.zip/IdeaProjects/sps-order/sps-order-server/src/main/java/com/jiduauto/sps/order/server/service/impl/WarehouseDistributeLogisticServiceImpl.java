package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.caches.WarehouseCache;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.mapper.WarehouseDistributeLogisticMapper;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeLogisticService;
import com.jiduauto.sps.order.server.utils.AESUtil;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.BizTypeEnum;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.pojo.dto.DictItemClientDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeLogisticDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehousePo;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.service.ICommonService;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import com.jiduauto.sps.sdk.utils.DataMaskingUtils;
import com.jiduauto.sps.sdk.utils.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 仓配订单物流信息 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
@Service
@Slf4j
public class WarehouseDistributeLogisticServiceImpl extends
        ServiceImpl<WarehouseDistributeLogisticMapper, WarehouseDistributeLogisticPo> implements
        IWarehouseDistributeLogisticService {

    @Resource
    private AESUtil aesUtil;
    @Resource
    private SpsClient spsClient;
    @Resource
    private ICommonService commonService;
    @Resource
    private BaseDataQuery baseDataQuery;
    //总仓
    private final String headWarehouseCode = "G59";


    @Resource
    private WarehouseCache warehouseCache;
    @Override
    public WarehouseDistributeLogisticDto selectOne(String bizType, String orderNo) {
        WarehouseDistributeLogisticPo logisticPo = getWarehouseDistributeLogisticPo(bizType, orderNo);
        aesUtil.decode(logisticPo);
        WarehouseDistributeLogisticPo po = getWarehouseDistributeLogisticDtoList(logisticPo);
        Map<String, Map<String, String>> map = getDictItemMap(bizType);
        WarehouseDistributeLogisticDto dto = BeanCopierUtil.copy(po, WarehouseDistributeLogisticDto.class);
        Map<String, String> addressMap = map.getOrDefault(DictEnum.MapLocationDistrict.getDictCode(), new HashMap<>());
        Map<String, String> shippingMethodMap = map.getOrDefault(DictEnum.ShippingMethod.getDictCode(),
                new HashMap<>());
        getDto(logisticPo, addressMap, dto, shippingMethodMap, true);
        return dto;
    }

    // 设置物流信息加密脱敏
    private WarehouseDistributeLogisticPo getWarehouseDistributeLogisticDtoList(
            WarehouseDistributeLogisticPo logisticPo) {
        logisticPo.setShipper(DataMaskingUtils.maskName(logisticPo.getShipper()));
        logisticPo.setShipperContact(DataMaskingUtils.maskPhoneNumber(logisticPo.getShipperContact()));
        logisticPo.setDeliverAddress(DataMaskingUtils.maskAddress(logisticPo.getDeliverAddress()));
        logisticPo.setReceiver(DataMaskingUtils.maskName(logisticPo.getReceiver()));
        logisticPo.setReceiverContact(DataMaskingUtils.maskPhoneNumber(logisticPo.getReceiverContact()));
        logisticPo.setReceiveAddress(DataMaskingUtils.maskAddress(logisticPo.getReceiveAddress()));
        return logisticPo;
    }

    private WarehouseDistributeLogisticPo getWarehouseDistributeLogisticPo(String bizType, String orderNo) {
        return baseMapper.selectOne(Wrappers
                .lambdaQuery(WarehouseDistributeLogisticPo.class)
                .eq(WarehouseDistributeLogisticPo::getBizType, bizType)
                .eq(WarehouseDistributeLogisticPo::getWarehouseDistributeOrderNo, orderNo));
    }


    private List<WarehouseDistributeLogisticPo> getWarehouseDistributeLogisticPos(String bizType,
                                                                                  List<String> orderNos) {
        return list(Wrappers
                .lambdaQuery(WarehouseDistributeLogisticPo.class)
                .eq(WarehouseDistributeLogisticPo::getBizType, bizType)
                .in(WarehouseDistributeLogisticPo::getWarehouseDistributeOrderNo, orderNos));
    }

    @Override
    public List<WarehouseDistributeLogisticDto> selectWarehouseDistributeLogisticList(String bizType, List<String> orderNos) {
        List<WarehouseDistributeLogisticPo> list = getWarehouseDistributeLogisticPos(bizType, orderNos);
        if (CollectionUtils.isEmpty(list)){
            return new ArrayList<>();
        }
        Map<String, Map<String, String>> map = getDictItemMap(bizType);
        Map<String, String> shippingMethodMap = map.getOrDefault(DictEnum.ShippingMethod.getDictCode(),new HashMap<>());
        Map<String, String> addressMap = map.getOrDefault(DictEnum.MapLocationDistrict.getDictCode(), new HashMap<>());
        return list.stream().map(item -> {
            WarehouseDistributeLogisticDto logisticDto = BeanCopierUtil.copy(item,
                    WarehouseDistributeLogisticDto.class);
            getDto(item, addressMap, logisticDto, shippingMethodMap,true);
            return commonService.changeNull(logisticDto);
        }).collect(Collectors.toList());
    }
    @Override
    public WarehouseDistributeLogisticDto selectWarehouseDistributeLogistic(String bizType, String orderNo) {
        WarehouseDistributeLogisticPo logisticPo = getWarehouseDistributeLogisticPo(bizType,
                orderNo);
        Map<String, Map<String, String>> map = getDictItemMap(bizType);
        Map<String, String> addressMap = map.getOrDefault(DictEnum.MapLocationDistrict.getDictCode(), new HashMap<>());
        Map<String, String> shippingMethodMap = map.getOrDefault(DictEnum.ShippingMethod.getDictCode(),
                new HashMap<>());
        aesUtil.decode(logisticPo);
        WarehouseDistributeLogisticDto logisticDto = BeanCopierUtil.copy(logisticPo,
                WarehouseDistributeLogisticDto.class);
        if (Objects.isNull(logisticDto)) {
            return new WarehouseDistributeLogisticDto();
        }
        getDto(logisticPo, addressMap, logisticDto, shippingMethodMap, false);
        return commonService.changeNull(logisticDto);
    }

    @Override
    public WarehouseDistributeLogisticPo getByOrderNo(String orderNo) {
        return getOne(Wrappers.<WarehouseDistributeLogisticPo>lambdaQuery()
               .eq(WarehouseDistributeLogisticPo::getWarehouseDistributeOrderNo,orderNo));
    }

    private Map<String, Map<String, String>> getDictItemMap(String bizType) {
        List<String> list = new ArrayList<>();
        list.add(DictEnum.MapLocationDistrict.getDictCode());
        list.add(DictEnum.ShippingMethod.getDictCode());
        BaseDataReq req = new BaseDataReq();
        req.setBizType(bizType);
        req.setDictCodes(list);
        BaseResult<BaseDataResp> resp = spsClient.searchBaseData(req);
        List<DictItemClientDto> dictItemClientDtos = resp.getData().getDictItemClientDtos();
        return baseDataQuery.getDictItemName(dictItemClientDtos);
    }

    private void getDto(WarehouseDistributeLogisticPo logisticPo, Map<String, String> addressMap,
            WarehouseDistributeLogisticDto logisticDto, Map<String, String> shippingMethodMap, boolean maskFlag) {

        String deliverUni = "";
        //如果发省货份不是空
        if (StringUtils.isNotBlank(logisticPo.getDeliverProvinceName())) {
            deliverUni = deliverUni + logisticPo.getDeliverProvinceName();
        }
        //如果发货市不是空
        if (StringUtils.isNotBlank(logisticPo.getDeliverCityName())) {
            if (StringUtils.isBlank(deliverUni)) {
                deliverUni = deliverUni +logisticPo.getDeliverCityName();
            } else {
                deliverUni = deliverUni + "/" + logisticPo.getDeliverCityName();
            }
        }
        if (StringUtils.isNotBlank(logisticPo.getDeliverDistrictName())) {
            if (StringUtils.isBlank(deliverUni)) {
                deliverUni = deliverUni + logisticPo.getDeliverDistrictName();
            } else {
                deliverUni = deliverUni + "/" + logisticPo.getDeliverDistrictName();
            }
        }
        logisticDto.setDeliverUni(deliverUni);
        String receiveUni = "";
        //如果收货省份值取具体名称
        //收货地址存储的是具体地址不是编码值
        //如果收货份不是空
        if (StringUtils.isNotBlank(logisticPo.getReceiveProvinceName())) {
            receiveUni = receiveUni + logisticPo.getReceiveProvinceName();
        }
        //如果收货市不是空
        if (StringUtils.isNotBlank(logisticPo.getReceiveCityName())) {
            if (StringUtils.isBlank(receiveUni)) {
                receiveUni = receiveUni + logisticPo.getReceiveCityName();
            } else {
                receiveUni = receiveUni + "/" + logisticPo.getReceiveCityName();
            }
        }
        if (StringUtils.isNotBlank(logisticPo.getReceiveDistrictName())) {
            if (StringUtils.isBlank(receiveUni)) {
                receiveUni = receiveUni + logisticPo.getReceiveDistrictName();
            } else {
                receiveUni = receiveUni + "/" +logisticPo.getReceiveDistrictName();
            }
        }
        logisticDto.setReceiveUni(receiveUni);
        logisticDto.setShippingMethodName(shippingMethodMap.get(logisticPo.getShippingMethod()));

        if(headWarehouseCode.equals(logisticDto.getDeliverWarehouseCode())){
            WarehousePo warehousePo = getHeadWarehouseCode();
            logisticDto.setDeliverUni(getHeadCompanyUni(warehousePo));
            if(maskFlag){
                logisticDto.setDeliverAddress(DataMaskingUtils.maskAddress(getHeadAddress(warehousePo)));
                logisticDto.setShipper(DataMaskingUtils.maskName(warehousePo.getContact()));
                logisticDto.setShipperContact(DataMaskingUtils.maskPhoneNumber(warehousePo.getPhoneNumber()));
            }else{
                logisticDto.setDeliverAddress(getHeadAddress(warehousePo));
                logisticDto.setShipper(warehousePo.getContact());
                logisticDto.setShipperContact(warehousePo.getPhoneNumber());
            }

        }
        if(headWarehouseCode.equals(logisticDto.getReceiveWarehouseCode())){
            WarehousePo warehousePo = getHeadWarehouseCode();
            logisticDto.setReceiveUni(getHeadCompanyUni(warehousePo));
            if(maskFlag){
                logisticDto.setReceiveAddress(DataMaskingUtils.maskAddress(getHeadAddress(warehousePo)));
                logisticDto.setReceiver(DataMaskingUtils.maskName(warehousePo.getContact()));
                logisticDto.setReceiverContact(DataMaskingUtils.maskPhoneNumber(warehousePo.getPhoneNumber()));
            }else{
                logisticDto.setReceiveAddress(getHeadAddress(warehousePo));
                logisticDto.setReceiver(warehousePo.getContact());
                logisticDto.setReceiverContact(warehousePo.getPhoneNumber());
            }
        }
    }

    private WarehousePo getHeadWarehouseCode() {
        return warehouseCache.getByBizAndCode(BizTypeEnum.SP.getBizType(),headWarehouseCode);
    }

    /**
     * 获取总仓的 省市区
     * @return
     */
    private String getHeadCompanyUni(WarehousePo warehousePo){
        if(warehousePo != null){
            Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(
                    DictEnum.MapLocationDistrict.getDictCode());
           return  codeAndNameMap.get(warehousePo.getProvinceCode())+"/"+codeAndNameMap.get(warehousePo.getCityCode())+"/"+codeAndNameMap.get(warehousePo.getDistrictCode());
        }
        return null;
    }

    /**
     * 获取总仓地址
     * @param warehousePo
     * @return
     */
    private String getHeadAddress(WarehousePo warehousePo){
        if(warehousePo != null){
            return warehousePo.getAddress();
        }
        return null;
    }
}
