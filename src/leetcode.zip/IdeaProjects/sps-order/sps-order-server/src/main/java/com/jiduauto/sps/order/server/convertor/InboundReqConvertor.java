package com.jiduauto.sps.order.server.convertor;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.WarehouseDistributeOrderAllPo;
import com.jiduauto.sps.order.server.service.IBaseDataRespCheckService;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderStatusEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.SupplierPo;
import com.jiduauto.sps.sdk.pojo.req.AsnAddSyncReq;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;


/**
 * @author panjian
 */
@Component
public class InboundReqConvertor {


    @Resource
    private SpsClient spsClient;
    @Resource
    private IBaseDataRespCheckService baseDataRespCheckService;

    public AsnAddSyncReq toInBoundReq(WarehouseDistributeOrderAllPo allPo) {
        WarehouseDistributeOrderPo warehouseDistributeOrderPo = allPo.getWarehouseDistributeOrderPo();
        WarehouseDistributeLogisticPo warehouseDistributeLogisticPo = allPo.getWarehouseDistributeLogisticPo();
        List<WarehouseDistributeItemAttachPo> itemAttaches = allPo.getItemAttaches();
        List<WarehouseDistributeItemPackagePo> itemPackages = allPo.getItemPackages();
        Map<String, WarehouseDistributeItemAttachPo> attachPoMap = itemAttaches.stream()
                .collect(Collectors.toMap(WarehouseDistributeItemAttachPo::getMaterialLineNo, Function.identity()));
        Map<String, List<WarehouseDistributeItemPackagePo>> packMap = itemPackages.stream()
                .collect(Collectors.groupingBy(WarehouseDistributeItemPackagePo::getPackingCode));
        Map<String, WarehouseDistributeItemPo> itemPoMap = allPo.getItems().stream().collect(Collectors.toMap(e -> e.getMaterialCode() + e.getBatchNo(), Function.identity(), (e1, e2) -> {
            e1.setQty(e1.getQty().add(e2.getQty()));
            return e1;
        }));


        List<WarehouseDistributeItemPo> itemPos = new ArrayList<>(itemPoMap.values());
        AsnAddSyncReq asnAddSyncReq = new AsnAddSyncReq();
        asnAddSyncReq.setOperationType(Objects.equals(warehouseDistributeOrderPo.getOrderStatus(), WarehouseDistributeOrderStatusEnum.CANCELED.getCode()) ? "cancel" : "add");
        asnAddSyncReq.setAsnCode(warehouseDistributeOrderPo.getBusinessBillNo());
        asnAddSyncReq.setBizType(warehouseDistributeOrderPo.getBizType());
        asnAddSyncReq.setDeliveryTime(DateUtil.formatLocalDateTime(LocalDateTime.now()));
        asnAddSyncReq.setInboundType(warehouseDistributeOrderPo.getOrderType());
        asnAddSyncReq.setReceiveWarehouseCode(warehouseDistributeLogisticPo.getReceiveWarehouseCode());
        asnAddSyncReq.setLogisticsNo(warehouseDistributeOrderPo.getLogisticNo());

        Map<String, List<WarehouseDistributeItemPo>> map = itemPos.stream().collect(Collectors.groupingBy(WarehouseDistributeItemPo::getBizType));

        List<SupplierPo> supplierPos = new ArrayList<>();
        List<MaterialPo> materialPos = new ArrayList<>();

        for (Map.Entry<String, List<WarehouseDistributeItemPo>> entry : map.entrySet()) {
            BaseDataReq baseDataReq = new BaseDataReq();
            List<String> curSupplierCode = entry.getValue().stream().map(WarehouseDistributeItemPo::getSupplierCode).collect(Collectors.toList());
            List<String> curMaterialCode = entry.getValue().stream().map(WarehouseDistributeItemPo::getMaterialCode).collect(Collectors.toList());
            baseDataReq.setSupplierCodes(curSupplierCode);
            baseDataReq.setMaterialCodes(curMaterialCode);
            baseDataReq.setBizType(entry.getKey());
            BaseResult<BaseDataResp> baseData = spsClient.searchBaseData(baseDataReq);
            if (CollUtil.isNotEmpty(baseData.getData().getSupplierPos())) {
                supplierPos.addAll(baseData.getData().getSupplierPos());
            }
            if (CollUtil.isNotEmpty(baseData.getData().getMaterials())) {
                materialPos.addAll(baseData.getData().getMaterials());
            }

        }

        Map<String, SupplierPo> supplierPoMap = supplierPos.stream().collect(Collectors.toMap(e -> e.getBizType() + e.getSapCode(), Function.identity()));
        Map<String, MaterialPo> materialPoMap = materialPos.stream().collect(Collectors.toMap((v -> v.getBizType() + v.getSalePartNum()), Function.identity()));
        List<AsnAddSyncReq.DeliverInfo> deliverInfos = itemPos.stream().map(e -> {
            AsnAddSyncReq.DeliverInfo deliverInfo = new AsnAddSyncReq.DeliverInfo();
            deliverInfo.setAsnLineNo(e.getMaterialLineNo());
            deliverInfo.setDeliveryQty(e.getQty());
            deliverInfo.setSalePartNum(e.getMaterialCode());
            deliverInfo.setSupplierSapCode(e.getSupplierCode());
            MaterialPo materialPo = materialPoMap.getOrDefault(e.getMaterialCode(), new MaterialPo());
            deliverInfo.setUnit(materialPo.getOrderUnit());
            deliverInfo.setBatchNo(e.getBatchNo());
            SupplierPo supplierPo = supplierPoMap.getOrDefault(e.getBizType() + e.getSupplierCode(), new SupplierPo());
            deliverInfo.setSupplierName(supplierPo.getSupplierName());
            deliverInfo.setSupplierAddress(supplierPo.getAddress());
            if (StrUtil.isEmpty(materialPo.getOrderUnit())) {
                deliverInfo.setUnit(materialPo.getMeasurementUnit());
            }
            WarehouseDistributeItemAttachPo attachPo = attachPoMap.getOrDefault(e.getMaterialLineNo(), new WarehouseDistributeItemAttachPo());
            deliverInfo.setResponsibleParty(attachPo.getResponsibleParty());
            deliverInfo.setReturnReason(attachPo.getRemark());
            if (CollUtil.isNotEmpty(itemPackages) && WarehouseDistributeOrderTypeEnum.needCheckSP(warehouseDistributeOrderPo.getOrderType())) {
                List<WarehouseDistributeItemPackagePo> itemPackagePos = packMap.get(e.getPackingCode());
                List<AsnAddSyncReq.PackageInfo> packageInfos = itemPackagePos.stream().map(v -> {
                    AsnAddSyncReq.PackageInfo packageInfo = new AsnAddSyncReq.PackageInfo();
                    packageInfo.setPackNo(v.getPackingCode());
                    packageInfo.setActualPackQty(BigDecimal.ONE);
                    return packageInfo;
                }).collect(Collectors.toList());
                deliverInfo.setPackageInfos(packageInfos);
            }
            //间采传包装数量信息
            if (WarehouseDistributeOrderTypeEnum.isDirAsn(warehouseDistributeOrderPo.getOrderType())) {
                AsnAddSyncReq.PackageInfo packageInfo = new AsnAddSyncReq.PackageInfo();
                packageInfo.setPackNo(e.getPackingCode());
                packageInfo.setStandardPackQty(e.getStandardPackingQty());
                deliverInfo.setPackageInfos(Lists.newArrayList(packageInfo));
            }
            return deliverInfo;
        }).collect(Collectors.toList());
        asnAddSyncReq.setDeliverInfos(deliverInfos);
        return asnAddSyncReq;
    }

}
