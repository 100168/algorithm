package com.jiduauto.sps.order.server.mapper;

import com.jiduauto.sps.order.server.pojo.po.StoreRecommendationListPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 门店推荐清单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-06-17
 */
public interface StoreRecommendationListMapper extends BaseMapper<StoreRecommendationListPo> {

}
