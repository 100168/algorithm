package com.jiduauto.sps.order.server.excel;

import cn.hutool.core.bean.BeanUtil;
import com.jiduauto.sps.order.server.pojo.po.StandardRecommendationListPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListImportReq;
import com.jiduauto.sps.order.server.service.IStandardRecommendationListService;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.handler.ExtendImportHandler;
import com.jiduauto.sps.sdk.service.impl.BosServiceImpl;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class StandardRecommendationListImportHandler extends ExtendImportHandler<StandardRecommendationListImportReq> {

    @Resource
    private IStandardRecommendationListService standardRecommendationListService;


    public StandardRecommendationListImportHandler(List<BatchPreCheck<StandardRecommendationListImportReq>> batchChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchChecks;
        super.eClass = StandardRecommendationListImportReq.class;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveData(List<ExtendExportDto<StandardRecommendationListImportReq>> extendExportDto) {
        List<StandardRecommendationListImportReq> list = extendExportDto.stream().map(ExtendExportDto::getT).collect(Collectors.toList());
        standardRecommendationListService.insertOrUpdate(list.stream().map(o -> {
            StandardRecommendationListPo po = BeanUtil.copyProperties(o, StandardRecommendationListPo.class);
            po.setBizType(BizTypeThreadHolder.getBizType());
            return po;
        }).collect(Collectors.toList()));
    }

}
