package com.jiduauto.sps.order.server.facade.proxy;

import com.jiduauto.javakit.mysql.DS;
import com.jiduauto.sps.order.server.mapper.TestSpsMaterialMapper;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@DS(name = "cn.dit.dad.mysql-sps.mysql")
public class TestSpsMaterialMapperProxy {

    @Resource
    private TestSpsMaterialMapper testSpsMaterialMapper;

    public  int countMaterial(){
        return testSpsMaterialMapper.countMaterial();
    }

}
