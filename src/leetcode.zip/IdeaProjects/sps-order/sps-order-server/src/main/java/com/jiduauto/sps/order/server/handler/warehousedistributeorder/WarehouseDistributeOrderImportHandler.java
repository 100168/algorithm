package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.read.metadata.holder.ReadRowHolder;
import com.alibaba.fastjson.JSONObject;
import com.jiduauto.sps.order.server.excel.check.WarehouseDistributeOrderBatchPreCheck;
import com.jiduauto.sps.order.server.pojo.fileimport.WarehouseDistributeOrderImportExportResp;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeItemReq;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeLogisticReq;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderReq;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.GenerateSerialNoUtil;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.enums.GenerateSerialEnum;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.handler.ExcelThreadLocalHolder;
import com.jiduauto.sps.sdk.handler.ExtendImportHandler;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportDataInfo;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.service.impl.BosServiceImpl;
import com.jiduauto.sps.sdk.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static com.jiduauto.sps.order.server.excel.check.WarehouseDistributeOrderBatchPreCheck.DATE_FORMATTER;
import static com.jiduauto.sps.order.server.excel.check.WarehouseDistributeOrderBatchPreCheck.TIME_FORMATTER;

/**
 * 仓配订单数据导入
 */
@Service
@Slf4j
public class WarehouseDistributeOrderImportHandler extends ExtendImportHandler<WarehouseDistributeOrderImportExportResp> {


    public WarehouseDistributeOrderImportHandler(List<BatchPreCheck<WarehouseDistributeOrderImportExportResp>> batchPreChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchPreChecks;
        super.eClass = WarehouseDistributeOrderImportExportResp.class;
    }

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private GenerateSerialNoUtil generateSerialNoUtil;

    @Resource
    private BaseDataQuery baseDataQuery;

    //private final static ExecutorService executorService = Executors.newFixedThreadPool(8);

    @Override
    public List<ImportDataInfo<WarehouseDistributeOrderImportExportResp>> readFile(MultipartFile file) throws BizException {
        if (file.isEmpty()) {
            throw new BizException("文件不能为空");
        }
        try (InputStream inputStream = file.getInputStream()) {
            List<ImportDataInfo<WarehouseDistributeOrderImportExportResp>> importList = new ArrayList<>();
            EasyExcel.read(inputStream, WarehouseDistributeOrderImportExportResp.class, new ReadListener<WarehouseDistributeOrderImportExportResp>() {
                @Override
                public void invokeHead(Map headMap, AnalysisContext context) {
                    log.info("表头信息：{}", JSONObject.toJSONString(headMap));
                    if (headMap == null) {
                        throw new BizException("模板不合规, 请检查！");
                    }
                    ReadRowHolder readRowHolder = context.readRowHolder();
                    Integer rowIndex = readRowHolder.getRowIndex();
                    List<ReadCellData> readCellDataList = new ArrayList<>(headMap.values());
                    if (rowIndex == 1) {
                        headList.forEach(item -> {
                            if (!headList.contains(item)) {
                                throw new BizException("模板不合规, 请检查！");
                            }
                        });
                    }
                }

                @Override
                public void invoke(WarehouseDistributeOrderImportExportResp o, AnalysisContext context) {
                    Integer rowNumber = context.readSheetHolder().getApproximateTotalRowNumber();
                    if (rowNumber > 1000) {
                        throw new BizException("单次导入最大数据量不能超过 1000 行");
                    }
                    ReadRowHolder readRowHolder = context.readRowHolder();
                    int rowNum = readRowHolder.getRowIndex() + 2;

                    try {
                        ImportDataInfo<WarehouseDistributeOrderImportExportResp> info = new ImportDataInfo<>();
                        if (o != null) {
                            info.setData(o);
                            importList.add(info);
                        }
                    } catch (Exception e) {
                        log.error("第" + rowNum + "行,数据解析异常", e);
                    }
                }

                @Override
                public void doAfterAllAnalysed(AnalysisContext context) {//所有数据解析完成了 会来调用
                    log.info("解析完成！");
                }
            }).sheet().headRowNumber(2).doRead();
            return importList;

        } catch (BizException e) {
            log.error("仓配数据导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw e;
        } catch (Exception e) {
            log.error("仓配数据导入解析异常：{}", ExceptionUtils.getStackTrace(e));
            throw new BizException(-1, "仓配数据导入解析异常,请检查文件格式");
        }
    }


    @SuppressWarnings({"unchecked", "OptionalGetWithoutIsPresent"})
    @Override
    protected void saveData(List<ExtendExportDto<WarehouseDistributeOrderImportExportResp>> extendExportDto) {

        Map<String, Map<String, String>> dictNameMap = (Map<String, Map<String, String>>) ExcelThreadLocalHolder.get("dictNameMap");
        BaseDataResp data = (BaseDataResp) ExcelThreadLocalHolder.get("data");

        //根据 orderNumber 分组
        Map<Integer, List<ExtendExportDto<WarehouseDistributeOrderImportExportResp>>> collectMap = extendExportDto.stream()
                .peek(o -> {
                    WarehouseDistributeOrderImportExportResp importExportResp = o.getT();
                    importExportResp.setLogisticType(dictNameMap.get(DictEnum.LogisticType.getDictCode()).get(importExportResp.getLogisticType()));
                    importExportResp.setMaterialStatus(dictNameMap.get(DictEnum.MaterialStatus.getDictCode()).get(importExportResp.getMaterialStatus()));
                    importExportResp.setMaterialSort(dictNameMap.get(DictEnum.MaterialSort.getDictCode()).get(importExportResp.getMaterialSort()));
                    importExportResp.setStockStatus(dictNameMap.get(DictEnum.StockStatus.getDictCode()).get(importExportResp.getStockStatus()));
                })
                .collect(Collectors.groupingBy(
                        o -> o.getT().getOrderNumber()
                ));


        for (List<ExtendExportDto<WarehouseDistributeOrderImportExportResp>> list : collectMap.values()) {
            ExtendExportDto<WarehouseDistributeOrderImportExportResp> req = list.stream().filter(o -> !WarehouseDistributeOrderBatchPreCheck.basicFiledIsEmpty(o.getT())).findFirst().get();
            WarehouseDistributeOrderImportExportResp importExportResp = req.getT();
            warehouseDistributeOrderService.add(convertAddReq(importExportResp, list), false);
        }
    }

    private WarehouseDistributeOrderAddReq convertAddReq(WarehouseDistributeOrderImportExportResp importReq, List<ExtendExportDto<WarehouseDistributeOrderImportExportResp>> list) {
        String bizType = BizTypeThreadHolder.getBizType();
        WarehouseDistributeOrderAddReq addReq = new WarehouseDistributeOrderAddReq();
        WarehouseDistributeOrderReq head = BeanUtil.copyProperties(importReq, WarehouseDistributeOrderReq.class);
        WarehouseDistributeLogisticReq logistic = BeanUtil.copyProperties(importReq, WarehouseDistributeLogisticReq.class);
        head.setBizType(bizType);
        head.setOrderNo(generateSerialNoUtil.generateEncodeOrderNoPreBiz(GenerateSerialEnum.JO, head.getBizType()));
        head.setSourceSystem("SPS");
        Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(
                DictEnum.MapLocationDistrict.getDictCode());

        //订单日期
        head.setOrderTime(DateUtils.format(LocalDateTime.now(), DateUtils.STANDARD_TIME_FORMAT));

        if (StrUtil.isNotBlank(importReq.getEstPickTime())) {
            LocalDate date = LocalDate.parse(importReq.getEstPickTime(), TIME_FORMATTER);
            LocalDateTime localDateTime = date.atTime(0, 0, 0);
            logistic.setEstPickTime(DateUtils.format(localDateTime, DateUtils.STANDARD_TIME_FORMAT));
        }

        if (StrUtil.isNotBlank(importReq.getEstArrivalTime())) {
            LocalDate date = LocalDate.parse(importReq.getEstArrivalTime(), TIME_FORMATTER);
            LocalDateTime localDateTime = date.atTime(0, 0, 0);
            logistic.setEstArrivalTime(DateUtils.format(localDateTime, DateUtils.STANDARD_TIME_FORMAT));
        }

        if (StrUtil.isNotBlank(logistic.getReceiveCityCode()) && StrUtil.isNotBlank(logistic.getReceiveProvinceCode())) {
            logistic.setReceiveCityCode(baseDataQuery.getCityCodeByName(logistic.getReceiveCityCode()));
            logistic.setReceiveProvinceCode(baseDataQuery.getProvinceCodeByName(logistic.getReceiveProvinceCode()));
            if (StrUtil.isNotBlank(logistic.getReceiveDistrictCode())) {
                logistic.setReceiveDistrictCode(baseDataQuery.getDistrictCodeByName(logistic.getReceiveDistrictCode()));
            }
        }

        if (StrUtil.isNotBlank(logistic.getDeliverCityCode()) && StrUtil.isNotBlank(logistic.getDeliverProvinceCode())) {
            logistic.setDeliverCityCode(baseDataQuery.getCityCodeByName(logistic.getDeliverCityCode()));
            logistic.setDeliverProvinceCode(baseDataQuery.getProvinceCodeByName(logistic.getDeliverProvinceCode()));
            if (StrUtil.isNotBlank(logistic.getDeliverDistrictCode())) {
                logistic.setDeliverDistrictCode(baseDataQuery.getDistrictCodeByName(logistic.getDeliverDistrictCode()));
            }
        }
        addReq.setHead(head);

        AtomicInteger newIndex = new AtomicInteger(1);
        addReq.setItems(
                list.stream().map(o -> {
                    WarehouseDistributeOrderImportExportResp req = o.getT();
                    WarehouseDistributeItemReq item = BeanUtil.copyProperties(req, WarehouseDistributeItemReq.class, "remark");
                    item.setBizType(bizType);
                    item.setMaterialLineNo(String.valueOf(newIndex.getAndIncrement()));
                    item.setQty(new BigDecimal(req.getQty()));

                    if (StrUtil.isNotEmpty(req.getAddDate())) {
                        LocalDate date = LocalDate.parse(req.getAddDate(), DATE_FORMATTER);
                        LocalDateTime localDateTime = date.atTime(0, 0, 0);
                        item.setAddDate(DateUtils.format(localDateTime, DateUtils.STANDARD_TIME_FORMAT));
                    }

                    if (StrUtil.isNotEmpty(req.getProductDate())) {
                        LocalDate date = LocalDate.parse(req.getProductDate(), DATE_FORMATTER);
                        LocalDateTime localDateTime = date.atTime(0, 0, 0);
                        item.setProductDate(DateUtils.format(localDateTime, DateUtils.STANDARD_TIME_FORMAT));
                    }

                    if (StrUtil.isNotEmpty(req.getExpireDate())) {
                        LocalDate date = LocalDate.parse(req.getExpireDate(), DATE_FORMATTER);
                        LocalDateTime localDateTime = date.atTime(0, 0, 0);
                        item.setExpireDate(DateUtils.format(localDateTime, DateUtils.STANDARD_TIME_FORMAT));
                    }
                    return item;
                }).collect(Collectors.toList())
        );
        addReq.setLogistic(logistic);
        return addReq;
    }
}
