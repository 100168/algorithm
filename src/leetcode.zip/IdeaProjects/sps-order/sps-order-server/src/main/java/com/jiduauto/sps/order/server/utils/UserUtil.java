package com.jiduauto.sps.order.server.utils;

import cn.hutool.core.util.StrUtil;
import com.jiduauto.passport.conf.UserInfoThreadHolder;
import com.jiduauto.passport.pojo.dto.UserInfo;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.BaseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;

/**
 * 用户信息工具类
 *
 * @author HuangKun
 * @date 2022/10/9
 */
public class UserUtil {

    private final static int NAME_LENGTH_LIMIT = 32;

    private UserUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static UserInfo getLoginUserInfo() {
        UserInfo user = UserInfoThreadHolder.getCurrentUser();
        if (user == null || StringUtils.isEmpty(user.getUsername())) {
            throw new BizException("用户登录信息异常");
        }
        return user;
    }

    public static String getUserName() {
        UserInfo user = UserInfoThreadHolder.getCurrentUser();
        if (user == null || StringUtils.isEmpty(user.getUsername())) {
            return getUserNameByRequest();
        }
        return formatName(user.getName());
    }

    public static String getUserNameByRequest(){
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        // 消息队列中不会有中请求, 默认返回空字符串
        if (servletRequestAttributes == null) {
            return StrUtil.EMPTY;
        }
        HttpServletRequest request = servletRequestAttributes.getRequest();
        String username = request.getHeader("username");
        return formatName(username);
    }

    public static <T extends BaseEntity> void fillCreateOrUpdateInfo(T po, boolean isCreated){
        if (isCreated){
            po.setCreateTime(LocalDateTime.now());
            po.setCreateUser(getUserName());
        }
        po.setUpdateUser(getUserName());
        po.setUpdateTime(LocalDateTime.now());
    }



    /**
     * 格式化名称，超长则截取
     */
    public static String formatName(String name) {
        if (StrUtil.isEmpty(name)) {
            return StrUtil.EMPTY;
        }

        if (name.contains(" ") && name.contains("(")) {
            name = name.substring(0, name.indexOf(" ")).concat(name.substring(name.indexOf("(")));
        }
        return name.length() > NAME_LENGTH_LIMIT ? name.substring(0, NAME_LENGTH_LIMIT) : name;
    }

    public static void removeUserInfo() {
        UserInfoThreadHolder.remove();
    }
}
