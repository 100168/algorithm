
package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.sps.order.server.facade.WarehouseDistributeOrderFacadeService;
import com.jiduauto.sps.order.server.handler.WDOrderAddThreadLocalHolder;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderCancelReq;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderReq;
import com.jiduauto.sps.order.server.pojo.vo.resp.WarehouseDistributeOrderAddResp;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 提供商城物流订单接口
 *
 * @author panjian
 */
@Slf4j
@RestController
@RequestMapping("/internal/warehouseDistributeOrder")
public class InternalWarehouseDistributeOrderController {

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private WarehouseDistributeOrderFacadeService warehouseDistributeOrderFacadeService;

    @Resource
    private RedissonClient redissonClient;


    /**
     * 物流订单创建 商城特用、后续会废弃
     *
     * @param request request
     * @return rest
     */
    @PostMapping("/add")
    public BaseResult<Object> add(@RequestBody @Valid WarehouseDistributeOrderAddReq request) {
        try {
            WarehouseDistributeOrderAddResp resp = warehouseDistributeOrderFacadeService.add(request);
            if (request.getHead().getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM20.getValue())) {
                return BaseResult.OK(resp.getOrderNo());
            }
            return BaseResult.OK(resp);
        } catch (BizException e) {
            log.warn("商城订单创建业务异常", e);
            return BaseResult.error(e.getErrCode(), e.getErrMessage(), e.getLogRelId());
        }
    }

    /**
     * 物流订单创建 通用
     *
     * @param request request
     * @return rest
     */
    @PostMapping("/create")
    public BaseResult<WarehouseDistributeOrderAddResp> create(@RequestBody @Valid WarehouseDistributeOrderAddReq request) {


        WarehouseDistributeOrderReq head = request.getHead();
        //用业务单号跟业务类型获取锁
        String redisKey = String.format(BaseConstants.RedisKey.WAREHOUSE_DISTRIBUTE_ORDER_CREATE_KEY, head.getBizType(), head.getBusinessBillNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            return BaseResult.OK(warehouseDistributeOrderFacadeService.add(request));
        } catch (Exception e){
            log.warn("仓配订单创建异常", e);
            throw e;
        }finally {
            if (rLock.isHeldByCurrentThread()) {
                rLock.unlock();
            }
            //移除threadLocal缓存
            WDOrderAddThreadLocalHolder.remove();
        }

    }

    /**
     * 商城物流订单取消
     *
     * @param request request
     * @return rest
     */

    @PostMapping("/cancel")
    public BaseResult<Boolean> cancel(@RequestBody @Valid WarehouseDistributeOrderCancelReq request) {
        return BaseResult.OK(warehouseDistributeOrderService.cancel(request,true));
    }


    /**
     * 更新物流单号&同步tms更新轨迹
     *
     * @param request request
     * @return rest
     */
    @PostMapping("/update")
    public BaseResult<Boolean> update(@RequestBody @Validated(WarehouseDistributeOrderAddReq.Update.class) WarehouseDistributeOrderAddReq request) {
        return BaseResult.OK(warehouseDistributeOrderService.updateLogistic(request));
    }


}
