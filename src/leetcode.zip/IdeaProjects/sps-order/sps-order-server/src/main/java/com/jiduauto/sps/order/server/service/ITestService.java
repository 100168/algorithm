package com.jiduauto.sps.order.server.service;

import java.sql.SQLException;
import java.sql.Statement;

/**
 * @ClassName ITestService
 * @Description  临时后续删除
 * @Author O_chaopeng.huang
 * @Date 2023/11/21 17:05
 */
public interface ITestService {

    void insertWDO(Statement sourceStatement)throws SQLException;

    void insertLP(Statement sourceStatement)throws SQLException;

    void insertP(Statement sourceStatement)throws SQLException;

    void insertIA(Statement sourceStatement)throws SQLException;

    void insertIP(Statement sourceStatement)throws SQLException;

    void insertA(Statement sourceStatement)throws SQLException;

    void insertPO(Statement sourceStatement)throws SQLException;

    void insertPOD(Statement sourceStatement)throws SQLException;

    void insertPOOL(Statement sourceStatement)throws SQLException;

    void insertSO(Statement sourceStatement)throws SQLException;

    void insertSOD(Statement sourceStatement)throws SQLException;

    void insertSOOL(Statement sourceStatement)throws SQLException;

    void insertBO(Statement sourceStatement)throws SQLException;

    void insertBOD(Statement sourceStatement)throws SQLException;

    void insertBOOL(Statement sourceStatement)throws SQLException;
}
