package com.jiduauto.sps.order.server.convertor;


import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.track.api.vo.req.BillDetailReq;
import com.jiduauto.track.api.vo.req.BillIntoReq;
import com.jiduauto.track.api.vo.req.GoodsInfoReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface BillIntoItemReqConvertor {

    @Mapping(target = "goodsWeight", source = "item.weight")
    @Mapping(target = "goodsVolume", source = "item.volume")
    @Mapping(target = "goodsQuantity", source = "item.qty")
    @Mapping(target = "goodsName", source = "item.materialCode")
    GoodsInfoReq toReq(WarehouseDistributeItemPo item);
    List<GoodsInfoReq> toReq(List<WarehouseDistributeItemPo> item);



}
