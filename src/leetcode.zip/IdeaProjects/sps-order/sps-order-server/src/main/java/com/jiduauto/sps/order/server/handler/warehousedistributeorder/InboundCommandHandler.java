package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import cn.hutool.json.JSONUtil;
import com.jiduauto.dit.outbox.OutboxMessageService;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.sdk.consts.OutboxConst;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.DictItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/*
 * 下发dhl入库指令*/
@Component
public class InboundCommandHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private OutboxMessageService outboxMessageService;

    @Resource
    private SpsClient spsClient;

    /*异步发送dhl入库*/
    @Override
    public void process(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {
        WarehouseDistributeLogisticPo logisticPo = warehouseDistributeOrderAllPo.getWarehouseDistributeLogisticPo();
        WarehouseDistributeOrderPo orderPo = warehouseDistributeOrderAllPo.getWarehouseDistributeOrderPo();
        //判断是否是G59仓库
        BaseResult<List<DictItemPo>> specialWarehouse = spsClient.getSpecialWarehouse(logisticPo.getBizType());
        if (orderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.ES11.getValue()) && specialWarehouse.getData().stream().noneMatch(dictItemPo -> dictItemPo.getItemCode().equals(logisticPo.getReceiveWarehouseCode()))) {
            return;
        }
        outboxMessageService.saveMessage(OutboxConst.MessageType.WD_ORDER_TO_DHL, JSONUtil.toJsonStr(warehouseDistributeOrderAllPo));
    }

    /*
     * 注册单前handler*/
    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.INBOUND_COMMAND.getBitIndex(), this);
    }
}
