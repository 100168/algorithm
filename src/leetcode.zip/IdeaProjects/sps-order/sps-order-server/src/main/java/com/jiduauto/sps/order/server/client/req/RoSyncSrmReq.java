package com.jiduauto.sps.order.server.client.req;

import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.google.common.collect.Lists;
import com.jiduauto.sps.sdk.enums.PartCategoryEnum;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.order.server.pojo.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * @author panjian
 */
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class RoSyncSrmReq {
    private final static DateTimeFormatter NONE_DATE_FORMATTER = DateTimeFormatter.ofPattern(
            BaseConstants.DatePattern.NONE_DATE);
    private final static DateTimeFormatter NONE_TIME_FORMATTER = DateTimeFormatter.ofPattern(
            BaseConstants.DatePattern.NONE_TIME);

    private ClassMessageHeader MessageHeader;
    private List<ClassMessageBody> MessageBody;


    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageHeader {

        private String Sender;
        private Long SerialNum;
        private String InterfaceID;
        private String SendDate;
        private String SendTime;
        private String Reserve1;
        private String Reserve2;
        private String Reserve3;
        private String Reserve4;

    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBody {

        private ClassMessageBodyHeader Header;
        private List<ClassMessageBodyItem> Item1;
    }


    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyHeader {

        /*采购订单号*/
        private String purchaseorder;
        /*订单类型*/
        private String ordertype;
        /*制造供应商代码*/
        private String sapvendor;
        /*发票供应商代码*/
        private String invoicebp;
        /*采购组织*/
        private String purchaseorg;
        /**
         * 公司代码 todo
         */
        private String company;
        /**
         * 发货地代码
         */
        private String shipfromcode;
        private String shipfromname;
        /**
         * 订单时间
         */
        private String releasedate;
        /**
         * 币种
         */
        private String reserve1;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyItem {

        /**
         * 门店PO号
         */
        private String storepono;
        /**
         * 是否退货 (是)
         */
        private String returnflag;
        /**
         * 采购订单行项目
         */
        private String poitem;

        /**
         * 零件号
         */
        private String materialid;
        /**
         * 零件名称(中文)
         */
        private String materialdescp;
        /**
         * 退货数量
         */
        private String poqty;
        /**
         * 订货单位，取自零件主数据，无则取计量单位
         */
        private String unit;
        /**
         * 根据发货仓库取公司代码
         */
        private String plant;
        /**
         * 发货仓库对应的库存地点
         */
        private String storageloc;
        /**
         *
         * 供应商地址，可为空
         */
        private String receiptaddress;
        /**
         *
         * 供应商人，可为空
         */
        private String receiptperson;
        /**
         * 供应商联系方式，可为空
         */
        private String receiptcontact;
        /**
         * 创建人
         */
        private String purchasename;

        /**
         * 供应商代码
         */
        private String shiptocode;

        /**
         * 仅退货单：1-UX量产件/UX Series Parts，3-UX样件/UX Sample Parts； 采购订单&退货单：2-售后件/Service Parts，5-能源件/ES Parts，6-精品件/JC
         * Parts，7-试制件/Sample Parts
         */
        private String reserve2;
        private String reserve4;
        private String reserve5;

    }


    public static RoSyncSrmReq newInstance() {
        RoSyncSrmReq roSyncSrmReq = new RoSyncSrmReq();
        roSyncSrmReq.setMessageHeader(new ClassMessageHeader());
        ClassMessageBody messageBody = new ClassMessageBody();
        messageBody.setHeader(new ClassMessageBodyHeader());
        messageBody.setItem1(Lists.newArrayList());
        ArrayList<ClassMessageBody> messageBodies = new ArrayList<>();
        messageBodies.add(messageBody);
        roSyncSrmReq.setMessageBody(messageBodies);
        roSyncSrmReq.messageHeader();
        return roSyncSrmReq;
    }

    public void messageHeader() {
        LocalDateTime now = LocalDateTime.now();
        MessageHeader.Sender = "SPS";
        MessageHeader.InterfaceID = "MM_018";
        MessageHeader.SendDate = now.format(NONE_DATE_FORMATTER);
        MessageHeader.SendTime = now.format(NONE_TIME_FORMATTER);
    }
//
//    public void setPurchaseReturnOrder(PurchaseReturnOrderDto purchaseReturnOrderDto) {
//        MessageBody.get(0).Header.purchaseorder = purchaseReturnOrderDto.getOrderNo();
//        MessageBody.get(0).Header.ordertype = "ZRE";
//        MessageBody.get(0).Header.sapvendor = purchaseReturnOrderDto.getSupplierSapCode();
//        MessageBody.get(0).Header.invoicebp = purchaseReturnOrderDto.getSupplierSapCode();
//        MessageBody.get(0).Header.shipfromcode = purchaseReturnOrderDto.getWarehouseCode();
//        MessageBody.get(0).Header.releasedate = purchaseReturnOrderDto.getAuditTime().format(NONE_DATE_FORMATTER);
//        MessageBody.get(0).Header.reserve1 = "CNY";
//        MessageBody.get(0).Header.purchaseorg = purchaseReturnOrderDto.getSupplierSapCode();
//
//    }
//
//    public void setDetail(WarehousePo warehouse,PurchaseReturnOrderDto purchaseReturnOrderDto,List<PurchaseReturnOrderDetailDto> orderDetailDtoList) throws BizException {
//        getMessageBody().get(0).getHeader().setCompany(warehouse.getCompanyCode());
//        getMessageBody().get(0).getHeader().setShipfromname(warehouse.getName());
//        orderDetailDtoList.forEach(item -> {
//            ClassMessageBodyItem bodyItem = new ClassMessageBodyItem();
//            bodyItem.setReturnflag("X");
//            //不传行号
//            bodyItem.setPoitem(String.valueOf(item.getLineNo()));
//            bodyItem.setMaterialid(item.getSalePartNum());
//            bodyItem.setMaterialdescp(item.getSalePartName());
//            bodyItem.setPoqty(item.getQty());
//            bodyItem.setUnit(
//                    StrUtil.isNotEmpty(item.getOrderUnit()) ? item.getOrderUnit() : item.getMeasurementUnit());
//            bodyItem.setShiptocode(MessageBody.get(0).Header.shipfromcode);
//            bodyItem.setReserve2(String.valueOf(PartCategoryEnum.getBizCode(item.getBizType())));
//            bodyItem.setPlant(warehouse.getCompanyCode());
//            bodyItem.setStorageloc(warehouse.getStockLocation());
//            bodyItem.setShiptocode(purchaseReturnOrderDto.getSupplierSapCode());
//            bodyItem.setReserve4(item.getAsnCode());
//            bodyItem.setReserve5(item.getAsnLineNo());
//            getMessageBody().get(0).getItem1().add(bodyItem);
//        });
//    }
}
