package com.jiduauto.sps.order.server.client.req;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TrackDetailReq {

    private String businessTypeCode;

    private String businessNo;

    private String billNo;
}
