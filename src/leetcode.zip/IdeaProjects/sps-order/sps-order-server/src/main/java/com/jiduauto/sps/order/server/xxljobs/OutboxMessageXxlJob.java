package com.jiduauto.sps.order.server.xxljobs;

import cn.hutool.core.util.StrUtil;
import com.jiduauto.dit.outbox.OutboxMessageService;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;

@Component
@Slf4j
public class OutboxMessageXxlJob {

    @Resource
    private OutboxMessageService outboxMessageService;

    @Resource
    private JdbcTemplate jdbcTemplate;


    /**
     * 删除异常发件箱信息
     * @param msgId 对应表 msg id
     */
    @XxlJob("delErrorOutboxMessage")
    public ReturnT<String> delErrorOutboxMessage(String msgId) {
        if (StrUtil.isBlank(msgId)) {
            return ReturnT.SUCCESS;
        }
        this.jdbcTemplate.update("delete from t_outbox_message where msg_id = ?", msgId);
        return ReturnT.SUCCESS;
    }


    /**
     * 删除异常发件箱信息
     * @param msgIds 对应表 msg id
     */
    @XxlJob("delErrorOutboxMessageByMsgIds")
    public ReturnT<String> delErrorOutboxMessageByMsgIds(String msgIds) {
        if (StrUtil.isBlank(msgIds)) {
            return ReturnT.SUCCESS;
        }
        String[] msgIdArr = msgIds.split(",");
        for (String msgId : msgIdArr) {
            this.jdbcTemplate.update("delete from t_outbox_message where msg_id = ?", msgId);
        }
        return ReturnT.SUCCESS;
    }



    @XxlJob("handleLastHourOutboxMessage")
    public ReturnT<String> handleLastHourOutboxMessage(String param) throws Exception {
        LocalDateTime endTime = LocalDateTime.now().plusMinutes(-1);
        outboxMessageService.handleMessages(endTime.plusHours(-1), endTime);
        return ReturnT.SUCCESS;
    }

    @XxlJob("handleLastHourOutboxMessageSpsOrder")
    public ReturnT<String> handleLastHourOutboxMessageSpsOrder(String param) throws Exception {
        LocalDateTime endTime = LocalDateTime.now().plusMinutes(-1);
        outboxMessageService.handleMessages(endTime.plusHours(-1), endTime);
        return ReturnT.SUCCESS;
    }

    @XxlJob("handleLastDayOutboxMessage")
    public ReturnT<String> handleLastDayOutboxMessage(String param) throws Exception {
        LocalDateTime endTime = LocalDateTime.now().plusHours(-1).plusMinutes(-1);
        outboxMessageService.handleMessages(endTime.plusDays(-1), endTime);
        return ReturnT.SUCCESS;
    }

    @XxlJob("handleLastWeekOutboxMessage")
    public ReturnT<String> handleLastWeekOutboxMessage(String param) throws Exception {
        LocalDateTime endTime = LocalDateTime.now().plusDays(-1).plusHours(-1).plusMinutes(-1);
        outboxMessageService.handleMessages(endTime.plusDays(-6), endTime);
        return ReturnT.SUCCESS;
    }

    @XxlJob("handleLastWeekOutboxMessageSpsOrder")
    public ReturnT<String> handleLastWeekOutboxMessageSpsOrder(String param) throws Exception {
        LocalDateTime endTime = LocalDateTime.now().plusHours(-1).plusMinutes(-1);
        outboxMessageService.handleMessages(endTime.plusDays(-7), endTime);
        return ReturnT.SUCCESS;
    }

    @XxlJob("handleAllOutboxMessage")
    public ReturnT<String> handleAllOutboxMessage(String param) throws Exception {
        LocalDateTime startTime = LocalDateTime.of(2023, 5, 1, 0, 0, 0);
        LocalDateTime endTime = LocalDateTime.now().plusMinutes(-1);
        outboxMessageService.handleMessages(startTime, endTime);
        return ReturnT.SUCCESS;
    }
}
