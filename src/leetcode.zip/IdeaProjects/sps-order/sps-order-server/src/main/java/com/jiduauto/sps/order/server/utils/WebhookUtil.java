package com.jiduauto.sps.order.server.utils;

import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.jiduauto.sps.order.server.pojo.dto.NoticedDto;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.pojo.http.HttpBaseResponse;
import com.jiduauto.sps.sdk.utils.HttpUtil;
import com.jiduauto.sps.sdk.utils.StringUtils;
import io.opentelemetry.api.trace.Span;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.text.StrSubstitutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * 业务微信发送消息
 */
@Slf4j
@Component
public class WebhookUtil {

    public final static String sysName = "sps-order";

    public final String ERROR_FORMAT = "code:[%s]，message:[%s]";

    @Value("${spring.profiles.active}")
    private String active;
    /**
     * 默认webhook地址
     */
    @Value("${sps.feishu.webhookUrl:https://open.feishu.cn/open-apis/bot/v2/hook/4f25bf1d-90c2-41a6-92ce-9a088e1e8213}")
    private String defaultWebhookUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/4f25bf1d-90c2-41a6-92ce-9a088e1e8213";



    @Value("${logistics.notice.webhookUrl:}")
    private String businessWebhookUrl;

    @Async
    public void sendMarkdownMessageV3(String level, Integer code, String message, String title, String operateUser) {
        if (StringUtils.isBlank(level)) {
            level = BaseConstants.WebhookUtilLevel.P1;
        }
        sendMarkdownMessageToChat(null, builderErrorMessage(code, message, title, level, operateUser), title);
    }

    /**
     * 构建告警信息
     *
     * @param code
     * @param message
     * @param path
     * @param level
     * @return
     */
    public String builderErrorMessage(Integer code, String message, String path, String level, String operateUser) {
        Span currentSpan = Span.current();
        String traceId = currentSpan.getSpanContext().getTraceId();
        NoticedDto noticedDto = NoticedDto
                .builder()
                .env(active)
                .operateUser(operateUser)
                .traceUrl(initTraceUrl(active, traceId))
                .logUrl(initLogUrl(active, traceId))
                .title(path)
                .level(level)
                .result(String.format(ERROR_FORMAT, code, message))
                .build();
        return fillNoticed(noticedDto);
    }

    /**
     * 发送Markdown信息
     *
     * @param webhookUrl 通知群的webhook地址， 缺失的情况下 默认使用sps沟通群
     * @param message
     */
    private void sendMarkdownMessageToChat(String webhookUrl, String message, String title) {
        Map<String, Object> params = new HashMap<>();

        params.put("msg_type", "interactive");

        params.put("card", new Card(title, message, active));
        log.info(JSONUtil.toJsonStr(params));
        if (StringUtils.isBlank(webhookUrl)) {
            webhookUrl = defaultWebhookUrl;
        }

        try {
            HttpBaseResponse response = HttpUtil.doPost(webhookUrl, JSONUtil.toJsonStr(params));
            log.info(JSON.toJSONString(response));
            if (!response.isSuccess()) {
                log.warn("sendMarkdownMessageToChat fail plz check, req:{}, ret:{}", JSONUtil.toJsonStr(params), JSONUtil.toJsonStr(response));
            }
        } catch (Exception e) {
            log.error("sendMarkdownMessageToChat fail plz check, req:{}", JSONUtil.toJsonStr(params), e);
        }
    }


    public void sendXXlJobFailMessage(String title) {
        Map<String, String> strMap = new HashMap<>();
        strMap.put("title", title + "执行失败");
        strMap.put("bizType", "");
        strMap.put("key", "");
        strMap.put("result", "");
        sendMarkdownMessage(null, fillNoticed(strMap), BaseConstants.MessageTitle.XXL_JOB_FAILED);
    }

    /**
     * 发送Markdown信息
     *
     * @param webhookUrl 通知群的webhook地址， 缺失的情况下 默认使用sps沟通群
     * @param message
     */
    @Async
    @Deprecated
    public void sendMarkdownMessage(String webhookUrl, String message) {
        sendMarkdownMessageToChat(webhookUrl, message, "业务失败提示");
    }

    @Async
    public void sendMarkdownMessage(String webhookUrl, String message, String title) {
        sendMarkdownMessageToChat(webhookUrl, message, title);
    }

    /**
     * 发送给 系统业务人员的 飞书通知
     * @param message
     * @param title
     */
    @Async
    public void sendMarkdownMessage2Business(String message, String title) {
        sendMarkdownMessageToChat(businessWebhookUrl, message, title);
    }

    /**
     * 异常告警信息发送
     *
     * @param title
     * @param errorCode
     * @param errorMsg
     * @param level
     * @param webhookUrl
     * @return
     */
    public void sendErrorMsg(String title, Integer errorCode, String errorMsg,
                                String level, String webhookUrl) {
        String markdownContent = builderErrorMessage(errorCode, errorMsg, title, level, "");
        sendMarkdownMessageToChat(webhookUrl, markdownContent, title);
    }

    /**
     * 创建消息
     *
     * @param noticedDto 消息内容
     * @return map
     */
    public Map<String, String> buildMsgMap(NoticedDto noticedDto) {
        Map<String, String> contentMap = new HashMap<>();
        contentMap.put("bizType", noticedDto.getBizType());
        contentMap.put("operateUser", StringUtils.isBlank(noticedDto.getOperateUser()) ? "API" : noticedDto.getOperateUser());
        contentMap.put("title", noticedDto.getTitle());
        contentMap.put("key", noticedDto.getKey());
        contentMap.put("result", noticedDto.getResult());
        contentMap.put("traceUrl", noticedDto.getTraceUrl());
        contentMap.put("logUrl", noticedDto.getLogUrl());
        contentMap.put("env", noticedDto.getEnv());
        contentMap.put("level", noticedDto.getLevel());
        contentMap.put("levelColor", BaseConstants.WebhookUtilLevel.getColorByLevel(noticedDto.getLevel()));
        return contentMap;
    }

    /**
     * 创建消息
     *
     * @param contentMap 环境
     * @return string
     */
    public String fillNoticed(Map<String, String> contentMap) {
        String content = "**${title}**\n" +
                "**业务类型:   <font color='comment'>${bizType}</font> **\n" +
                "**业务号：    <font color='comment'>${key}</font> **\n" +
                "**详细结果:   <font color='comment'>${result}</font> **";
        return new StrSubstitutor(contentMap).replace(content);
    }

    public String fillNoticed(NoticedDto noticedDto) {
        Map<String, String> contentMap = buildMsgMap(noticedDto);
        String content = "**${title} **\n" +
                "**级别: <font color='${levelColor}'>${level}</font> **      **环境: <font color='warning'>${env}</font> **        **操作人: <font>${operateUser}</font> **\n" +
                "**[链路](${traceUrl}) **\n" +
                "**[日志](${logUrl}) **\n" +
                "**详细结果: <font color='comment'>${result}</font> ** \n";
        if (noticedDto.getLevel().equals(BaseConstants.WebhookUtilLevel.P0) && ("prod".equals(active) || "staging".equals(active))) {
            content = content + "<at id=all></at>";
        }
        return new StrSubstitutor(contentMap).replace(content);
    }

    private String initTraceUrl(String active, String traceId) {
        if ("prod".equals(active) || "staging".equals(active)) {
            return "https://trace.jiduprod.com/trace/" + traceId;
        } else {
            return "https://trace.jidudev.com/trace/" + traceId;
        }
    }

    private String initLogUrl(String active, String traceId) {
        String url = "http://log.jidudev.com/app/discover";
        if ("staging".equals(active)) {
            url = "http://log.jiduStaging.com/app/discover";
        } else if ("prod".equals(active)) {
            url = "http://log.jiduprod.com/app/discover";
        }

        return url + "#/?_g=(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:now-100m,to:now))" +
                "&_a=(columns:!(_source),filters:!(),index:jidulogapp-" +
                active + "-sps-serverlog,interval:auto,query:(language:kuery,query:'" + traceId + "'),sort:!())";
    }


    @Data
    static class Card {
        private Map<String, Object> config = new HashMap<String, Object>() {{
            put("wide_screen_mode", true);
        }};
        private CardHeader header;
        private List<CardElement> elements;

        public Card(String title, String content, String active) {
            this.header = new CardHeader(title);
            this.elements = Lists.newArrayList(new CardElement(active), new CardElement("markdown", content));
        }
    }

    @Data
    static class CardHeader {
        private Map<String, String> title;
        private String template = "red";

        public CardHeader(String title) {
            this.title = new HashMap<String, String>() {{
                put("tag", "plain_text");
                put("content", title);
            }};
        }
    }

    @Data
    static class CardElement {
        private String tag = "div";
        private List<Field> fields;
        private String content;

        public CardElement(String tag, String content) {
            this.tag = tag;
            this.content = content;
        }

        public CardElement(String active) {
            List<Field> list = Lists.newArrayList();
            Field sys = new Field("**系统**\n" + sysName);
            Field timeField = new Field("**时间**\n" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            Field env = new Field("**环境**\n" + active);
            list.add(sys);
            list.add(timeField);
            list.add(env);
            fields = list;
        }
    }

    @Data
    static class Field {
        private boolean is_short = true;
        private Map<String, String> text;

        public Field(String content) {
            this.text = new HashMap<String, String>() {{
                put("content", content);
                put("tag", "lark_md");
            }};
        }
    }

}
