package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.dit.outbox.OutboxMessageService;
import com.jiduauto.sps.order.server.client.PdpClient;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.order.server.convertor.OutboundReqConvertor;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.DictItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.DHLOutboundReq;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

import static com.jiduauto.sps.sdk.consts.OutboxConst.MessageType.STOCK_OUT_MAP_BUSINESS_TO_SPS;

/*
 * 下发dhl入库指令*/
@Component
public class OutboundCommandHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private SpsClient spsClient;
    @Resource
    private OutboundReqConvertor outboundReqConvertor;

    @Resource
    private PdpClient pdpClient;


    @Resource
    private OutboxMessageService outboxMessageService;

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;
    /*异步发送dhl入库*/
    @Override
    public void process(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {
        WarehouseDistributeOrderPo orderPo = warehouseDistributeOrderAllPo.getWarehouseDistributeOrderPo();
        // 商城订单需要占库先不出库，占库成功后再出库
        if (orderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM20.getValue()) && orderPo.getIsSpecial()) {
            return;
        }
        WarehouseDistributeLogisticPo logisticPo = warehouseDistributeOrderAllPo.getWarehouseDistributeLogisticPo();
        List<WarehouseDistributeItemPo> items = warehouseDistributeOrderAllPo.getItems();
        BaseResult<List<DictItemPo>> specialWarehouse = spsClient.getSpecialWarehouse(logisticPo.getBizType());
        //只有G59仓库才下发dhl出库
        if (specialWarehouse.getData().stream().noneMatch(dictItemPo -> dictItemPo.getItemCode().equals(logisticPo.getDeliverWarehouseCode()))) {
            return;
        }
        DHLOutboundReq dhlOutBoundReq = outboundReqConvertor.toDhlOutBoundReq(orderPo, items, logisticPo, BaseConstants.OperateType.ADD);
        ResultResp<Object> outbound = pdpClient.outbound(dhlOutBoundReq);
        if (!outbound.isSuccess()) {
            throw new BizException(outbound.getMsg());
        }
        outboxMessageService.saveMessage(STOCK_OUT_MAP_BUSINESS_TO_SPS, JsonUtil.toJsonString(warehouseDistributeOrderService.createStockOutMapBusinessDto(orderPo, logisticPo)));
    }

    /*
     * 注册单前handler*/
    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.OUTBOUND_COMMAND.getBitIndex(), this);
    }
}
