package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.NumberNoReq;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeItemPackageService;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributePackageItemDto;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * 仓配订单零件包装信息 前端控制器
 *
 * @author generate
 * @since 2023-07-12
 */
@RestController
@RequestMapping("/warehouseDistributeItemPackage")
public class WarehouseDistributeItemPackageController {
    @Autowired
    private IWarehouseDistributeItemPackageService warehouseDistributeItemPackageService;
    /**
     * 分页查询
     * @author O_chaopeng.huang
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<WarehouseDistributePackageItemDto>> pageSearch(@RequestBody @Valid BasePageParam<NumberNoReq> req) {
        return warehouseDistributeItemPackageService.pageSearch(req);
    }
}
