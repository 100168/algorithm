package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

/**
 * <p>
 * 采购订单明细 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface ISaleOrderDetailService extends IService<SaleOrderDetailPo> {

    BasePageData<SaleOrderDetailDto> pageSearch(BasePageParam<SaleOrderDetailByIdReq> pageParam);
}
