package com.jiduauto.sps.order.server.client;

import com.jiduauto.dit.sps.logging.common.StringUtils;
import com.jiduauto.sps.order.server.client.req.GetInSrmTokenReq;
import com.jiduauto.sps.order.server.client.resp.IndirectTokenResp;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 间采asn srm 接口
 *
 * @author panjian
 */

@FeignClient(name = "indirectSrmToken", url = "${feign.url.indirect.srm}", fallbackFactory = IndirectSrmTokenClient.SrmClientFallbackFactory.class)
public interface IndirectSrmTokenClient {

    @PostMapping(value = "/oauth/oauth/token", consumes = "application/x-www-form-urlencoded")
    IndirectTokenResp getToken(@RequestParam("grant_type") String grant_type,
                                @RequestParam("client_id") String client_id,
                                @RequestParam("client_secret") String client_secret,
                                @RequestParam("scope") String scope);

    @Slf4j
    @Component
    class SrmClientFallbackFactory implements FallbackFactory<IndirectSrmTokenClient> {

        @Override
        public IndirectSrmTokenClient create(Throwable cause) {

            return new IndirectSrmTokenClient() {

                @Override
                public IndirectTokenResp getToken(String grant_type, String client_id, String client_secret, String scope) {
                    log.warn(String.format("IndirectSrmClient#syncAsn error, param : %s %s %s %s ", grant_type,client_id,client_secret,scope), cause);
                    return IndirectTokenResp.failedResp(StringUtils.cutString(cause.toString(), 150)) ;
                }
            };
        }
    }
}
