package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.sps.order.server.facade.impl.StoreDiscountFacadeService;
import com.jiduauto.sps.order.server.pojo.dto.InternalStoreDiscountDto;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreDiscountListReq;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 门店折扣查询
 */
@RestController
@RequestMapping("/internal/storeDiscount")
public class InternalStoreDiscountController {

    @Resource
    private StoreDiscountFacadeService storeDiscountFacadeService;

    /**
     * 门店折扣查询
     */
    @PostMapping("/listEffectiveDiscount")
    public BaseResult<List<InternalStoreDiscountDto>> listEffectiveDiscount(@RequestBody @Valid InternalStoreDiscountListReq req) {
        return BaseResult.OK(storeDiscountFacadeService.listEffectiveDiscount(req));
    }

}
