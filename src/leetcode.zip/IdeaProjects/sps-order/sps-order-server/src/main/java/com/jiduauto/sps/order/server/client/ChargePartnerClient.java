package com.jiduauto.sps.order.server.client;

import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.client.config.ChargePartnerFeignConfig;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.sdk.client.req.AsnPushReq;
import com.jiduauto.sps.sdk.client.req.TransferInToEsReq;
import com.jiduauto.sps.sdk.client.req.TransferOutToEsReq;
import com.jiduauto.sps.sdk.client.req.TransferToEsCancelReq;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 能源平台api
 */

@FeignClient(name = "cn.pe.vi.charge-portal.mixed",configuration = ChargePartnerFeignConfig.class, fallbackFactory = ChargePartnerClient.ChargePartnerClientFallbackFactory.class)
public interface ChargePartnerClient {

    /**
     * 能源接收asn 推送
     * @param
     * @return
     */
    @PostMapping("/v1/asn/basic/push")
    BaseResult<Object> receiveAsn(@RequestBody AsnPushReq asnPushReq);


    /**
     * 能源调拨出库指令
     */
    @PostMapping("/v1/inner/supply/createOutboundOrder")
    ResultResp<Object> createTransferOutWorkOrder(@RequestBody TransferOutToEsReq req);

    /**
     * 能源调拨出库指令
     */
    @PostMapping("/v1/inner/supply/createInboundOrder")
    ResultResp<Object> createTransferInWorkOrder(@RequestBody TransferInToEsReq req);

    /**
     * 能源调拨取消
     */
    @PostMapping("/v1/inner/supply/cancelOrder")
    ResultResp<Object> cancelTransferWorkOrder(@RequestBody TransferToEsCancelReq req);

    @Slf4j
    @Component
    class ChargePartnerClientFallbackFactory implements FallbackFactory <ChargePartnerClient>{

        @Override
        public ChargePartnerClient create(Throwable throwable) {
            return new ChargePartnerClient() {
                @Override
                public BaseResult<Object> receiveAsn(AsnPushReq asnPushReq) {
                    log.warn(String.format("ChargePartnerClient#receiveAsn error, param: %s", JsonUtil.ObjectToJson(asnPushReq)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public ResultResp<Object> createTransferOutWorkOrder(TransferOutToEsReq req) {
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public ResultResp<Object> createTransferInWorkOrder(TransferInToEsReq req) {
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public ResultResp<Object> cancelTransferWorkOrder(TransferToEsCancelReq req) {
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }
            };
        }
    }
}
