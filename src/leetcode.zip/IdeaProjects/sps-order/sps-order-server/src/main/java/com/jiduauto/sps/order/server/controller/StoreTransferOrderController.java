package com.jiduauto.sps.order.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.order.server.pojo.dto.StoreTransferOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreTransferOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreTransferOrderReq;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderService;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.ExcelUtils;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 门店调拨单 前端控制器
 *
 * @author generate
 * @since 2024-01-12
 */
@RestController
@RequestMapping("/storeTransferOrder")
public class StoreTransferOrderController {
    @Resource
    private IStoreTransferOrderService storeTransferOrderService;
    /**
     * 门店调拨单条件查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StoreTransferOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<StoreTransferOrderReq> pageParam) {
        return BaseResult.OK(storeTransferOrderService.pageSearch(pageParam));
    }

    /**
     * 调拨单导出
     *
     **/
    @RequestMapping("/export")
    public void export(
            HttpServletResponse response, @RequestBody @Valid BasePageParam<StoreTransferOrderReq> pageParam) {
        try {
            ExcelUtils.exportXlsxResponse(response, "调拨单");
            EasyExcel.write(response.getOutputStream(), StoreTransferOrderExportDto.class).sheet("调拨单").doWrite(storeTransferOrderService.export(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }
}

