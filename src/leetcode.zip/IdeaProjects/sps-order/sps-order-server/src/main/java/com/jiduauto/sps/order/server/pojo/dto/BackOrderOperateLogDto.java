package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author panjian
 */
@Data
public class BackOrderOperateLogDto implements Serializable {

    private Long id;

    private String actionDesc;

    private String newValue;

    private String remark;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;



}
