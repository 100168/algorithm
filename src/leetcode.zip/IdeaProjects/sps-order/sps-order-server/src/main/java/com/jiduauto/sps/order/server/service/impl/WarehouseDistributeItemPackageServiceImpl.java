package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.mapper.WarehouseDistributeItemPackageMapper;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.NumberNoReq;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeItemPackageService;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.pojo.dto.DictItemClientDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributePackageItemDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPackagePo;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 仓配订单零件包装信息 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
@Service
public class WarehouseDistributeItemPackageServiceImpl extends ServiceImpl<WarehouseDistributeItemPackageMapper, WarehouseDistributeItemPackagePo> implements IWarehouseDistributeItemPackageService {
    @Resource
    private SpsClient spsClient;

    /**
     * 仓配零件包装信息分页查询
     *
     * @author O_chaopeng.huang
     */
    @Override
    public BaseResult<BasePageData<WarehouseDistributePackageItemDto>> pageSearch(BasePageParam<NumberNoReq> req) {
        NumberNoReq param = req.getParam();
        String numberNo = param.getNumberNo();
        IPage<WarehouseDistributeItemPackagePo> iPage = new Page<>(req.getPage(), req.getSize());
        iPage = baseMapper.selectPage(iPage,
                Wrappers.lambdaQuery(WarehouseDistributeItemPackagePo.class)
                        .eq(WarehouseDistributeItemPackagePo::getWarehouseDistributeOrderNo, numberNo)
                        .orderByDesc(WarehouseDistributeItemPackagePo::getId));
        BasePageData<WarehouseDistributePackageItemDto> pageData = new BasePageData<>(iPage);
        BaseDataReq baseDataReq = new BaseDataReq();
        List<String> dictCode = new ArrayList<>();
        dictCode.add(DictEnum.MaterialMeasureUnit.getDictCode());
        baseDataReq.setDictCodes(dictCode);
        baseDataReq.setBizType(param.getBizType());
        BaseResult<BaseDataResp> baseDataRespBaseResult = spsClient.searchBaseData(baseDataReq);
        Map<String, String> map = baseDataRespBaseResult.getData().getDictItemClientDtos().stream()
                .collect(Collectors.toMap(DictItemClientDto::getItemCode, DictItemClientDto::getItemName));
        List<WarehouseDistributePackageItemDto> collect = iPage.getRecords().stream()
                .map(e -> BeanCopierUtil.copy(e, WarehouseDistributePackageItemDto.class)).peek((e) -> {
                    e.setPackingUnitName(map.get(e.getPackingUnit()));
                }).collect(Collectors.toList());
        pageData.setRecords(collect);
        return BaseResult.OK(pageData);
    }

    @Override
    public List<WarehouseDistributeItemPackagePo> getByOrderNo(String orderNo) {
        return list(Wrappers.<WarehouseDistributeItemPackagePo>lambdaQuery().eq(WarehouseDistributeItemPackagePo::getWarehouseDistributeOrderNo,orderNo));
    }
}
