package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderByPoDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.VirtualQtyDto;
import com.jiduauto.sps.order.server.pojo.fileexport.SaleOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderPageSearchReq;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 销售订单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Mapper
public interface SaleOrderMapper extends BaseMapper<SaleOrderPo> {

    /**
     * 销售订单分页查询
     *
     * @author dong.li
     * @date 4/14/23 3:08 PM
     */
    IPage<SaleOrderDto> pageSearch(Page<SaleOrderDto> page, SaleOrderPageSearchReq param);

    /**
     * 获取待下发的 RO 非 dfs & co 订单
     */
    List<SaleOrderPo>  getNeedIssueRoAndCoSaleOrder(@Param("ro") String ro,@Param("co") String co,@Param("status") String status);

    /**
     * 销售订单导出查询
     */
    List<SaleOrderExportDto> exportSearch(@Param("param") SaleOrderPageSearchReq param, @Param("size") int size);

    /**
     * 销售订单所有明细查询  关键字 PO单单号集合
     * @return
     */
    List<SaleOrderByPoDto> pageSearchByPo(@Param("bizType")String bizType, @Param("purchaseOrderNos") List<String> purchaseOrderNos, @Param("size") int size);

    /**
     * 根据门店查询在途数量
     */
    List<VirtualQtyDto> queryVirtualQty(@Param("bizType") String bizType, @Param("storeCode") String storeCode);
}