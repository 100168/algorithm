package com.jiduauto.sps.order.server.client.resp;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import lombok.Data;

import java.util.Objects;

@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class SapResp {

    private ClassMessageBody MessageBody;

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBody {
        private ClassMessageBodyHeader Header;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyHeader {
        private String Receiver;
        private String Header_Key;
        private String receivenote;
        private String Message_Status;
        private String Message_Text;
    }

    public static boolean success(SapResp resp) {
        if (Objects.isNull(resp)) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody())) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody().getHeader())) {
            return false;
        } else {
            return "S".equals(resp.getMessageBody().getHeader().getMessage_Status());
        }
    }

    public static SapResp failedResp(String message) {
        SapResp resp = new SapResp();
        resp.setMessageBody(new ClassMessageBody());
        resp.getMessageBody().setHeader(new ClassMessageBodyHeader());
        resp.getMessageBody().getHeader().setMessage_Status("fallback");
        resp.getMessageBody().getHeader().setMessage_Text(message);
        return resp;
    }

    public static String errorMessage(String desc) {
        if (desc == null || !desc.startsWith("{\"MessageBody\"")) {
            return desc;
        }
        try {
            SapResp resp = JsonUtil.toObject(desc, SapResp.class);
            return resp.getMessageBody().getHeader().getMessage_Text();
        } catch (Exception e) {
            return desc;
        }
    }
}
