package com.jiduauto.sps.order.server.component;


import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeItemPackageReq;
import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;

import java.util.ArrayList;
import java.util.List;

import static com.jiduauto.sps.order.server.component.WDOrderItemGroupSequenceProvider.getClasses;


/**
 * @author panjian
 */
public class WDOrderItemPackageGroupSequenceProvider implements DefaultGroupSequenceProvider<WarehouseDistributeItemPackageReq> {


    @Override
    public List<Class<?>> getValidationGroups(WarehouseDistributeItemPackageReq bean) {
        List<Class<?>> defaultGroupSequence = new ArrayList<>();
        defaultGroupSequence.add(WarehouseDistributeItemPackageReq.class);
        // 这块判空请务必要做
        return getClasses(defaultGroupSequence, bean != null);
    }
}
