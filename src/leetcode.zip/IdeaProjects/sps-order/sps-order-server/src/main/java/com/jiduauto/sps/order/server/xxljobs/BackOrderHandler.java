package com.jiduauto.sps.order.server.xxljobs;

import com.jiduauto.sps.order.server.service.IBackOrderTransferService;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Slf4j
@Component
public class BackOrderHandler {

    @Resource
    private WebhookUtil webhookUtil;

    @Resource
    private IBackOrderTransferService backOrderTransferService;

    @XxlJob("boAutoTransferHandler")
    public ReturnT<String> boAutoTransferHandler(String param) throws Exception {
        try {
            log.info("boAutoTransferHandler start, param: {}", param);
            backOrderTransferService.batchAutoTransferOrder();
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("boAutoTransferHandler");
            log.error("boAutoTransferHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }
}
