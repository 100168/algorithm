package com.jiduauto.sps.order.server.aspect;

import com.baomidou.mybatisplus.extension.service.IService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jiduauto.sps.order.server.controller.common.SpsInternalCommonController;
import com.jiduauto.sps.sdk.client.common.AggregateQuery;
import com.jiduauto.sps.sdk.exception.BizException;
import org.apache.commons.io.IOUtils;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.lang.reflect.Type;

public class AggregateQueryArgumentResolver  implements HandlerMethodArgumentResolver {

    /**
     * 当 controller 方法中有 AggregateQuery 该参数切没有附带 @RequestBody 时, 该 ArgumentResolver 则会生效,
     * 因为有 @RequestBody 走的是 spring mvc 默认的 ArgumentResolver
     */
    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        return methodParameter.getParameterType().isAssignableFrom(AggregateQuery.class);
    }

    @Override
    public Object resolveArgument(@Nonnull MethodParameter methodParameter, @Nullable ModelAndViewContainer modelAndViewContainer, @Nonnull NativeWebRequest nativeWebRequest, @Nullable WebDataBinderFactory webDataBinderFactory) throws Exception {
        String[] split = ((ServletWebRequest) nativeWebRequest).getRequest().getRequestURI().split("/");
        if (split.length == 0) {
            throw new BizException("请求路径不合法");
        }
        String body = IOUtils.toString(((ServletWebRequest) nativeWebRequest).getRequest().getInputStream());
        Gson gson = new Gson();
        IService<?> iService = SpsInternalCommonController.QUERY_SERVICE_MAP.get(split[split.length - 1]);
        if (iService == null) {
            throw new BizException("请求路径不合法");
        }
        Class<?> clz = iService.getEntityClass();
        Type type = TypeToken.getParameterized(AggregateQuery.class, clz).getType();
        return gson.fromJson(body, type);
    }

}
