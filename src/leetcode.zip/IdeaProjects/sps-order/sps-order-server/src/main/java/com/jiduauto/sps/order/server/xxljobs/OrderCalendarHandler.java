package com.jiduauto.sps.order.server.xxljobs;

import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
@Slf4j
public class OrderCalendarHandler {

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private WebhookUtil webhookUtil;

    /**
     * 更新STK订单计划下发时间（门店已维订单日历但计划下发时间为空）
     * 如门店还未维护订单日历，则进行企微提醒
     */
    @XxlJob("orderCalendarUpdateAndNoticeHandler")
    public ReturnT<String> orderCalendarUpdateAndNoticeHandler(String param) throws Exception {
        try {
            log.info("orderCalendarUpdateAndNoticeHandler start, param: {}", param);
            saleOrderService.updateStkOrderPlanIssueTime();
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("orderCalendarUpdateAndNoticeHandler");
            log.error("orderCalendarUpdateAndNoticeHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

}
