package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.javakit.common.biz.Result;
import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.spare.parts.api.model.rpc.claim.ClaimOrderVO;
import com.jiduauto.spare.parts.api.model.rpc.request.claim.ClaimOrderBatchGetRequest;
import com.jiduauto.spare.parts.api.service.ClaimRpcService;
import com.jiduauto.sps.order.server.mapper.SapInvoiceInfoMapper;
import com.jiduauto.sps.order.server.pojo.req.SapSynInvoiceReq;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.sdk.enums.BizTypeEnum;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.enums.GlobalCodeEnum.GL_FAIL_DEFAULT;

/**
 * <p>
 * sap发票信息表 服务实现类
 * </p>
 *
 * @author generate
 * @since 2024-03-25
 */
@Service
@Slf4j
public class SapInvoiceInfoServiceImpl extends ServiceImpl<SapInvoiceInfoMapper, SapInvoiceInfoPo> implements ISapInvoiceInfoService {

    /**
     * 正常发票
     */
    public static final String NORMAL = "NORMAL";

    /**
     * 红票
     */
    public static final String RED = "RED";

    @Resource
    private ISaleOrderInvoiceRelationService saleOrderInvoiceRelationService;

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private IWarehouseDistributeItemService warehouseDistributeItemService;

    @Resource
    private ClaimRpcService claimRpcService;

    @Resource
    private ISaleOrderService saleOrderService;


    /**
     * 接受sap同步发票信息
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void synInvoice(SapSynInvoiceReq req) {
        SapSynInvoiceReq.ClassMessageBodyHeader header = req.getMessageBody().get(0).getHeader();
        List<SapSynInvoiceReq.ClassMessageBodyItem> item1 = req.getMessageBody().get(0).getItem1();

        try {
            if (StrUtil.isNotBlank(header.getInvoiceDate())) {
                String dateStr = header.getInvoiceDate();
                LocalDate date = LocalDate.parse(dateStr, DateTimeFormatter.ofPattern("yyyyMMdd"));
                header.setInvoiceDate(date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            }
        } catch (Exception e) {
            throw new BizException("发票日期格式不正确");
        }
        List<String> spsOrderNoList = item1.stream().map(SapSynInvoiceReq.ClassMessageBodyItem::getSpsOrderNo).distinct().collect(Collectors.toList());

        StringBuilder errorStr = new StringBuilder();
        //check req
        if (header.getInvoiceAmount().compareTo(BigDecimal.ZERO) == 0) {
            throw new BizException("发票金额不能等于 0");
        } else if (header.getInvoiceAmount().compareTo(BigDecimal.ZERO) < 0) {
            //检查红票数据是否存在
            Map<String, WarehouseDistributeOrderPo> businessBillNoMap = warehouseDistributeOrderService.getByBusinessBillOrderNoList(BizTypeEnum.SP.getBizType(), spsOrderNoList)
                    .stream().collect(Collectors.toMap(WarehouseDistributeOrderPo::getBusinessBillNo, Function.identity(), (p, n) -> n));

            for (SapSynInvoiceReq.ClassMessageBodyItem item : item1) {
                if (!businessBillNoMap.containsKey(item.getSpsOrderNo())) {
                    errorStr.append("关联仓配订单[").append(item.getSpsOrderNo()).append("]不存在;");
                }
            }

        }
        // 正常发票不做单号校验 若sap 传输不存在的关联 SO & ASN 数据也不会影响正常查询, 后续让SAP 重新推送正常数据即可

        if (StrUtil.isNotBlank(errorStr.toString())) {
            throw new BizException(errorStr.toString());
        }

        //判断是否已存在
        SapInvoiceInfoPo sapPo = getOne(Wrappers.lambdaQuery(SapInvoiceInfoPo.class)
                .eq(SapInvoiceInfoPo::getBizType, BizTypeEnum.SP.getBizType())
                .eq(SapInvoiceInfoPo::getInvoiceNo, header.getInvoiceNo()));

        if (sapPo != null) {
            //更新
            sapPo.setInvoiceAmount(header.getInvoiceAmount());
            sapPo.setInvoiceDate(header.getInvoiceDate());
            sapPo.setInvoiceUrl(header.getInvoiceUrl());
            sapPo.setInvoiceNo(header.getInvoiceNo());
            sapPo.setUpdateTime(LocalDateTime.now());
            updateById(sapPo);
            // 删除旧数据 发票关系
            saleOrderInvoiceRelationService.remove(Wrappers.lambdaQuery(SaleOrderInvoiceRelationPo.class)
                    .eq(SaleOrderInvoiceRelationPo::getBizType, BizTypeEnum.SP.getBizType())
                    .eq(SaleOrderInvoiceRelationPo::getInvoiceType, header.getInvoiceAmount().compareTo(BigDecimal.ZERO) < 0 ? RED : NORMAL)
                    .in(SaleOrderInvoiceRelationPo::getSpsOrderNo, spsOrderNoList)
            );
        } else {
            SapInvoiceInfoPo sapInvoiceInfoPo = new SapInvoiceInfoPo();
            sapInvoiceInfoPo.setInvoiceDate(header.getInvoiceDate() == null ? null : header.getInvoiceDate());
            sapInvoiceInfoPo.setBizType(BizTypeEnum.SP.getBizType());
            sapInvoiceInfoPo.setInvoiceAmount(header.getInvoiceAmount());
            sapInvoiceInfoPo.setInvoiceUrl(header.getInvoiceUrl());
            sapInvoiceInfoPo.setInvoiceNo(header.getInvoiceNo());
            save(sapInvoiceInfoPo);
        }

        if (header.getInvoiceAmount().compareTo(BigDecimal.ZERO) < 0) {
            processRedInvoice(header, item1);
        } else {
            processNormalInvoice(header, item1);
        }
    }


    /**
     * 处理正常发票
     */
    private void processNormalInvoice(SapSynInvoiceReq.ClassMessageBodyHeader header, List<SapSynInvoiceReq.ClassMessageBodyItem> item1) {
        for (SapSynInvoiceReq.ClassMessageBodyItem item : item1) {
            // 正常发票
            SaleOrderInvoiceRelationPo saleOrderInvoiceRelationPo = new SaleOrderInvoiceRelationPo();
            saleOrderInvoiceRelationPo.setBizType(BizTypeEnum.SP.getBizType());
            saleOrderInvoiceRelationPo.setSaleOrderNo(item.getSpsOrderNo());
            saleOrderInvoiceRelationPo.setSpsOrderNo(item.getSpsOrderNo());
            saleOrderInvoiceRelationPo.setInvoiceType(NORMAL);
            saleOrderInvoiceRelationPo.setInvoiceNo(header.getInvoiceNo());
            saleOrderInvoiceRelationPo.setItemKey(item.getItem_Key());
            saleOrderInvoiceRelationPo.setSapOrderNo(item.getSapOrderNo());
            saleOrderInvoiceRelationService.save(saleOrderInvoiceRelationPo);
        }
    }

    /**
     * 处理红票
     */
    private void processRedInvoice(SapSynInvoiceReq.ClassMessageBodyHeader header, List<SapSynInvoiceReq.ClassMessageBodyItem> item1) {
        for (SapSynInvoiceReq.ClassMessageBodyItem item : item1) {
            //红票
            String wdOrderBusinessNo = item.getSpsOrderNo();
            WarehouseDistributeOrderPo wdPo = warehouseDistributeOrderService.getByBusinessBillOrderNo(BizTypeEnum.SP.getBizType(), wdOrderBusinessNo);

            List<WarehouseDistributeItemPo> list = warehouseDistributeItemService.list(Wrappers.lambdaQuery(WarehouseDistributeItemPo.class)
                    .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, wdPo.getOrderNo())
                    .eq(WarehouseDistributeItemPo::getBizType, wdPo.getBizType())
            );
            List<String> spNoList = list.stream().map(WarehouseDistributeItemPo::getBatchNo).distinct().collect(Collectors.toList());

            if (CollUtil.isEmpty(spNoList)) {
                throw new BizException("关联仓配单明细对应批次索赔单不存在");
            }

            ClaimOrderBatchGetRequest claimOrderBatchGetRequest = new ClaimOrderBatchGetRequest();
            claimOrderBatchGetRequest.setClaimOrderNoList(spNoList);
            Result<List<ClaimOrderVO>> listResult = claimRpcService.batchGetClaimOrderList(claimOrderBatchGetRequest);

            if (GlobalCodeEnum.GL_SUCC_0.getCode() != listResult.getCode()) {
                log.warn("claimRpcService#claimOrderBatchGetRequest error, param: {}，result: {}",
                        JsonUtil.ObjectToJson(claimOrderBatchGetRequest),
                        JsonUtil.ObjectToJson(listResult));
                throw new BizException(GL_FAIL_DEFAULT.getCode(), GL_FAIL_DEFAULT.getDesc());
            }

            List<SaleOrderInvoiceRelationPo> collect = listResult.getData().stream().map(ClaimOrderVO::getSaleOrderNo).distinct().map(saleOrderNo -> {
                SaleOrderInvoiceRelationPo saleOrderInvoiceRelationPo = new SaleOrderInvoiceRelationPo();
                saleOrderInvoiceRelationPo.setBizType(BizTypeEnum.SP.getBizType());
                saleOrderInvoiceRelationPo.setSaleOrderNo(saleOrderNo);
                saleOrderInvoiceRelationPo.setSpsOrderNo(item.getSpsOrderNo());
                saleOrderInvoiceRelationPo.setInvoiceType(RED);
                saleOrderInvoiceRelationPo.setInvoiceNo(header.getInvoiceNo());
                saleOrderInvoiceRelationPo.setItemKey(item.getItem_Key());
                saleOrderInvoiceRelationPo.setSapOrderNo(item.getSapOrderNo());
                return saleOrderInvoiceRelationPo;
            }).collect(Collectors.toList());
            saleOrderInvoiceRelationService.saveBatch(collect);
        }
    }
}
