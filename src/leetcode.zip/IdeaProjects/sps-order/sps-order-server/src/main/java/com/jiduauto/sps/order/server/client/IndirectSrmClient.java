package com.jiduauto.sps.order.server.client;

import com.jiduauto.sps.order.server.client.config.IndirectSrmFeignConfig;
import com.jiduauto.sps.order.server.client.req.IndirectWDApplyOrderCloseReq;
import com.jiduauto.sps.order.server.client.req.IndirectWDApplyOrderPutOutReq;
import com.jiduauto.sps.order.server.client.resp.IndirectSrmResp;
import com.jiduauto.sps.order.server.client.resp.IndirectSrmWDCloseResp;
import com.jiduauto.sps.order.server.client.resp.IndirectSrmWDResp;
import com.jiduauto.sps.sdk.utils.StringUtils;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * 间采asn srm 接口
 *
 * @author panjian
 */

@FeignClient(name = "indirectSrm", url = "${feign.url.indirect.srm.nl}", configuration = IndirectSrmFeignConfig.class, fallbackFactory = IndirectSrmClient.SrmClientFallbackFactory.class)
public interface IndirectSrmClient {

    /**
     * 仓配订单-内领订单-关单-同步srm
     *
     * @param req 参数
     * @return PurchaseOrderSyncResp
     */
    @PostMapping(value = "/marmot-api/WTok5a36sjIDFjzXdzkYcy0d6NHCKz04NkvvmYMhNjg")
    IndirectSrmWDCloseResp syncWDApplyOrderClose(@RequestBody IndirectWDApplyOrderCloseReq req);

    /**
     * 仓配订单-内领订单-出库结果-同步srm
     *
     * @param req 参数
     * @return PurchaseOrderSyncResp
     */
    @PostMapping(value = "/marmot-api/ySQR4KzOpfzXtBibMmAEUrkEw3uArO1qHPFakGryF0xw")
    List<IndirectSrmWDResp> syncWDApplyOrderPutOut(@RequestBody IndirectWDApplyOrderPutOutReq req);


    @Slf4j
    @Component
    class SrmClientFallbackFactory implements FallbackFactory<IndirectSrmClient> {

        @Override
        public IndirectSrmClient create(Throwable cause) {

            return new IndirectSrmClient() {
                @Override
                public IndirectSrmWDCloseResp syncWDApplyOrderClose(IndirectWDApplyOrderCloseReq req) {
                    log.warn(String.format("IndirectSrmClient#syncWDApplyOrderClose error, param : %s", req), cause);
                    return IndirectSrmWDCloseResp.failure(StringUtils.cutString(cause.toString(), 150));
                }

                /**
                 * 仓配订单-内领订单-出库结果-同步srm
                 *
                 * @param req 参数
                 * @return PurchaseOrderSyncResp
                 */
                @Override
                public List<IndirectSrmWDResp> syncWDApplyOrderPutOut(IndirectWDApplyOrderPutOutReq req) {
                    log.warn(String.format("IndirectSrmClient#syncWDApplyOrderPutOut error, param : %s", req), cause);
                    return IndirectSrmWDResp.failure(StringUtils.cutString(cause.toString(), 150));
                }
            };
        }
    }
}
