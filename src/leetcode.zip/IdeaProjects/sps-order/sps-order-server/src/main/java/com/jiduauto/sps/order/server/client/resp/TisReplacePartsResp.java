package com.jiduauto.sps.order.server.client.resp;

import lombok.Data;

import java.util.List;

@Data
public class TisReplacePartsResp {

    private String salePartNum;

    private String model;

    private Integer code;

    private String msg;

    private List<ReplacePartsItem> replacePartList;
}
