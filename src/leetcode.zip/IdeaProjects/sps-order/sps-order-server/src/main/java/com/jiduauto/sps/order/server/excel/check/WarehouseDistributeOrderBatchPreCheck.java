package com.jiduauto.sps.order.server.excel.check;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.constant.MapConstant;
import com.jiduauto.sps.order.server.pojo.fileimport.WarehouseDistributeOrderImportExportResp;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.handler.ExcelThreadLocalHolder;
import com.jiduauto.sps.sdk.pojo.dto.DictItemClientDto;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.NumberUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class WarehouseDistributeOrderBatchPreCheck implements BatchPreCheck<WarehouseDistributeOrderImportExportResp> {

    @Resource
    private SpsClient spsClient;
    /**
     * 2023/01/01
     */
    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy/MM/dd");
    public static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm");

    /**
     * 校验
     */
    @Override
    public void invoke(List<ExtendExportDto<WarehouseDistributeOrderImportExportResp>> extendExportDtos) {
        String bizType = BizTypeThreadHolder.getBizType();
        List<WarehouseDistributeOrderImportExportResp> data = extendExportDtos.stream().map(ExtendExportDto::getT).collect(Collectors.toList());
        if (CollUtil.isEmpty(data)) {
            return;
        }
        List<String> deliverWarehouseCodeList = data.stream().map(WarehouseDistributeOrderImportExportResp::getDeliverWarehouseCode).filter(StrUtil::isNotBlank).distinct().collect(Collectors.toList());
        List<String> receiveWarehouseCodeList = data.stream().map(WarehouseDistributeOrderImportExportResp::getReceiveWarehouseCode).filter(StrUtil::isNotBlank).distinct().collect(Collectors.toList());
        List<String> materialCodes = data.stream().map(WarehouseDistributeOrderImportExportResp::getMaterialCode).filter(StrUtil::isNotBlank).distinct().collect(Collectors.toList());
        List<String> supplierCodes = data.stream().map(WarehouseDistributeOrderImportExportResp::getSupplierCode).filter(StrUtil::isNotBlank).distinct().collect(Collectors.toList());
        List<String> carCodesCodes = data.stream().map(WarehouseDistributeOrderImportExportResp::getCarCode).filter(StrUtil::isNotBlank).distinct().collect(Collectors.toList());
        List<String> workbinCodes = data.stream().map(WarehouseDistributeOrderImportExportResp::getCaseNo).filter(StrUtil::isNotBlank).distinct().collect(Collectors.toList());
        List<String> palletCodes = data.stream().map(WarehouseDistributeOrderImportExportResp::getPalletNo).filter(StrUtil::isNotBlank).distinct().collect(Collectors.toList());

        List<String> dictCode = new ArrayList<>();
        dictCode.add(DictEnum.MaterialStockStatus.getDictCode());
        dictCode.add(DictEnum.StockStatus.getDictCode());
        dictCode.add(DictEnum.MaterialSort.getDictCode());
        dictCode.add(DictEnum.MaterialStatus.getDictCode());
        dictCode.add(DictEnum.Project.getDictCode());
        dictCode.add(DictEnum.Stage.getDictCode());
        dictCode.add(DictEnum.LogisticType.getDictCode());

        deliverWarehouseCodeList.addAll(receiveWarehouseCodeList);
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setWarehouseCodes(deliverWarehouseCodeList);
        baseDataReq.setMaterialCodes(materialCodes);
        baseDataReq.setSupplierCodes(supplierCodes);
        baseDataReq.setDictCodes(dictCode);
        baseDataReq.setWorkbinCodes(workbinCodes);
        baseDataReq.setPalletCodes(palletCodes);
        baseDataReq.setCarCodes(carCodesCodes);

        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        Integer num = 0;
        for (int i = 0; i < extendExportDtos.size(); i++) {
            ExtendExportDto<WarehouseDistributeOrderImportExportResp> extendExportDto = extendExportDtos.get(i);
            WarehouseDistributeOrderImportExportResp req = extendExportDto.getT();
            boolean isCheckBasicField = !basicFiledIsEmpty(req);
            //第一行必校验
            if (i == 0) {
                isCheckBasicField = true;
            }
            if (isCheckBasicField) {
                num++;
                req.setOrderNumber(num);
            } else {
                req.setOrderNumber(num);
            }
            StringBuilder errs = new StringBuilder();
            check(isCheckBasicField, extendExportDto, req, errs, ret.getData());
        }
    }

    /**
     * 基本字段是否为空
     */
    public static boolean basicFiledIsEmpty(WarehouseDistributeOrderImportExportResp req) {
        return StrUtil.isBlank(req.getLogisticType())
                && StrUtil.isBlank(req.getOrderType());
    }

    /**
     * check
     */
    @SuppressWarnings({"OptionalGetWithoutIsPresent", "ResultOfMethodCallIgnored"})
    private static void check(boolean isCheckBasicField,
                              ExtendExportDto<WarehouseDistributeOrderImportExportResp> extendExportDto,
                              WarehouseDistributeOrderImportExportResp req,
                              StringBuilder errs,
                              BaseDataResp data
    ) {
        Map<String, Map<String, String>> dictMap = new HashMap<>();
        Map<String, Map<String, String>> dictNameMap = new HashMap<>();
        List<DictItemClientDto> dictItemClientDtos = data.getDictItemClientDtos();
        if (!CollUtil.isEmpty(dictItemClientDtos)) {
            for (DictItemClientDto clientDto : dictItemClientDtos) {
                if (dictNameMap.containsKey(clientDto.getCode())) {
                    dictMap.get(clientDto.getCode()).put(clientDto.getItemCode(), clientDto.getItemName());
                    dictNameMap.get(clientDto.getCode()).put(clientDto.getItemName(), clientDto.getItemCode());
                }
                if (!dictNameMap.containsKey(clientDto.getCode())) {
                    HashMap<String, String> value = new HashMap<>();
                    HashMap<String, String> valueName = new HashMap<>();
                    value.put(clientDto.getItemCode(), clientDto.getItemName());
                    valueName.put(clientDto.getItemName(), clientDto.getItemCode());
                    dictNameMap.put(clientDto.getCode(), valueName);
                    dictMap.put(clientDto.getCode(), value);
                }
            }

        }
        List<String> supplierCodes = data.getSupplierPos() == null ? new ArrayList<>() : data.getSupplierPos().stream().map(SupplierPo::getSapCode).collect(Collectors.toList());
        List<String> carCodes = data.getCarPos() == null ? new ArrayList<>() : data.getCarPos().stream().map(CarPo::getCode).collect(Collectors.toList());
        List<String> pallCodes = data.getPalletPos() == null ? new ArrayList<>() : data.getPalletPos().stream().map(PalletPo::getCode).collect(Collectors.toList());
        List<String> workbinCodes = data.getWorkbinPos() == null ? new ArrayList<>() : data.getWorkbinPos().stream().map(WorkbinPo::getCode).collect(Collectors.toList());
        List<String> wareHouseCodes = data.getWarehouses() == null ? new ArrayList<>() : data.getWarehouses().stream().map(WarehousePo::getCode).collect(Collectors.toList());
        Map<String, String> MaterialSortMap = dictNameMap.get(DictEnum.MaterialSort.getDictCode());
        Map<String, String> stockStatusMap = dictNameMap.get(DictEnum.StockStatus.getDictCode());
        Map<String, String> projectMap = dictMap.get(DictEnum.Project.getDictCode());
        Map<String, String> stageMap = dictMap.get(DictEnum.Stage.getDictCode());
        Map<String, String> MaterialStockStatusMap = dictNameMap.get(DictEnum.MaterialStockStatus.getDictCode());
        Map<String, String> wdLogisticTypeMap = dictNameMap.get(DictEnum.LogisticType.getDictCode());
        ExcelThreadLocalHolder.put("dictNameMap", dictNameMap);
        ExcelThreadLocalHolder.put("dictMap", dictMap);
        ExcelThreadLocalHolder.put("BaseDataResp", data);

        //是否检查基本字段
        if (isCheckBasicField) {
            Integer logisticType = null;
            String orderType = null;
            if (StrUtil.isEmpty(req.getLogisticType())) {
                errs.append("仓配类型不能为空");
            } else if (!wdLogisticTypeMap.containsKey(req.getLogisticType())) {
                errs.append("仓配类型不存在");
            } else {
                logisticType = Integer.parseInt(wdLogisticTypeMap.get(req.getLogisticType()));
            }

            if (StrUtil.isEmpty(req.getOrderType())) {
                errs.append("订单类型不能为空");
            } else if (Arrays.stream(WarehouseDistributeOrderTypeEnum.values()).noneMatch(t -> t.getValue().equals(req.getOrderType()))) {
                errs.append("订单类型不存在");
            } else {
                orderType = Arrays.stream(WarehouseDistributeOrderTypeEnum.values()).filter(t -> t.getValue().equals(req.getOrderType())).findFirst().get().getValue();
            }

            if (Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.PUT_OUT.getValue())
                    || Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.TRANSPORT_AND_PUT_OUT.getValue())
                    || Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.STOCK_TRANSFER.getValue())
            ) {
                if (StrUtil.isEmpty(req.getDeliverWarehouseCode())) {
                    errs.append("发货仓库不能为空");
                }
            }

            if (Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.PUT_IN.getValue())
                    || Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.TRANSPORT_AND_PUT_IN.getValue())
                    || Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.STOCK_TRANSFER.getValue())
            ) {
                if (StrUtil.isEmpty(req.getReceiveWarehouseCode())) {
                    errs.append("收货仓库不能为空");
                }
            }

            if (StrUtil.isNotBlank(req.getDeliverWarehouseCode()) && !wareHouseCodes.contains(req.getDeliverWarehouseCode())) {
                errs.append("发货仓库编码不存在");
            }

            if (StrUtil.isNotBlank(req.getReceiveWarehouseCode()) && !wareHouseCodes.contains(req.getReceiveWarehouseCode())) {
                errs.append("收货仓库编码不存在");
            }

            if (StrUtil.isNotBlank(req.getRemark()) && req.getRemark().length() > 200) {
                errs.append("备注长度不能超过200");
            }

            //存在性校验
            if (logisticType != null && WarehouseDistributeOrderlogisticTypeEnum.needCheck(logisticType)) {
                if (StrUtil.isBlank(req.getEstPickTime())) {
                    errs.append("预计提货时间不存在");
                }
            }

            //有效性校验
            if (StrUtil.isNotBlank(req.getEstPickTime())) {
                try {
                    LocalDate.parse(req.getEstPickTime(), TIME_FORMATTER);
                } catch (Exception e) {
                    errs.append("预计提货时间不正确");
                }
            }

            if (StrUtil.isNotEmpty(req.getEstArrivalTime())) {
                try {
                    LocalDate.parse(req.getEstArrivalTime(), TIME_FORMATTER);
                } catch (Exception e) {
                    errs.append("要求送达时间不正确");
                }
            }

            if (logisticType != null && WarehouseDistributeOrderlogisticTypeEnum.needCheck(logisticType) && !ShippingMethodEnum.isExist(req.getShippingMethod())) {
                errs.append("运输方式不正确");
            }

            if (StrUtil.isNotBlank(req.getLogisticNo()) && req.getLogisticNo().length() > 30) {
                errs.append("物流单号长度不能超过30");
            }

            //出库
            if (Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.PUT_OUT.getValue())) {
                if (StrUtil.isEmpty(req.getDeliverWarehouseCode())) {
                    errs.append("发货仓库编码不能为空");
                }
            }

            //入库
            if (Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.PUT_IN.getValue())) {
                if (StrUtil.isEmpty(req.getReceiveWarehouseCode())) {
                    errs.append("收货仓库编码不能为空");
                }
            }

            //调拨
            if (Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.STOCK_TRANSFER.getValue())) {
                if (StrUtil.isEmpty(req.getDeliverWarehouseCode())) {
                    errs.append("发货仓库编码不能为空");
                }
                if (StrUtil.isEmpty(req.getReceiveWarehouseCode())) {
                    errs.append("收货仓库编码不能为空");
                }
            }

            //入库+运输 收货仓库、收发货人、收发货地址、运输方式必填
            if (Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.TRANSPORT_AND_PUT_IN.getValue())) {
                if (StrUtil.isEmpty(req.getReceiveWarehouseCode())) {
                    errs.append("收货仓库编码不能为空");
                }
                checkShipperInfoAndReceiverInfo(req, errs);
            }

            //出库+运输：发货仓库、收发货人、收发货地址、运输方式必填
            if (Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.TRANSPORT_AND_PUT_OUT.getValue())) {
                if (StrUtil.isEmpty(req.getDeliverWarehouseCode())) {
                    errs.append("发货仓库编码不能为空");
                }
                checkShipperInfoAndReceiverInfo(req, errs);
            }

            //运输 收发货人、收发货地址、运输方式必填
            if (Objects.equals(logisticType, WarehouseDistributeOrderlogisticTypeEnum.TRANSPORT.getValue())) {
                checkShipperInfoAndReceiverInfo(req, errs);
            }
        }

        if (StrUtil.isEmpty(req.getMaterialCode())) {
            errs.append("零件编码不能为空");
        } else if (!data.getMaterials().stream().map(MaterialPo::getSalePartNum).collect(Collectors.toList()).contains(req.getMaterialCode())) {
            errs.append("零件编码不存在");
        }

        if (StrUtil.isEmpty(req.getMaterialStatus())) {
            errs.append("零件状态不能为空");
        } else if (!MaterialStockStatusMap.containsKey(req.getMaterialStatus())) {
            errs.append("零件状态不存在");
        }

        if (StrUtil.isEmpty(req.getStockStatus())) {
            errs.append("库存状态不能为空");
        } else if (!stockStatusMap.containsKey(req.getStockStatus())) {
            errs.append("库存状态不存在");
        } else if (!StockStatusEnum.NORMAL.getDesc().equals(req.getStockStatus())
                && !StockStatusEnum.FROZEN.getDesc().equals(req.getStockStatus())
        ) {
            errs.append("库存状态只允许为冻结 & 正常");
        }

        if (!NumberUtil.isThreeDecimalNumber(req.getQty()) || new BigDecimal(req.getQty()).compareTo(BigDecimal.ZERO) <= 0) {
            errs.append("数量格式不正确或小于等于0");
        }

        if (StrUtil.isNotBlank(req.getSamplePartStatus()) && req.getSamplePartStatus().length() > 50) {
            errs.append("样件状态长度不能超过50");
        }

        if (StrUtil.isNotBlank(req.getMaterialSort()) && !MaterialSortMap.containsKey(req.getMaterialSort())) {
            errs.append("零件种类不存在");
        }

        if (StrUtil.isNotBlank(req.getCarCode()) && !carCodes.contains(req.getCarCode())) {
            errs.append("车辆号不存在");
        }

        if (StrUtil.isNotBlank(req.getBatchNo()) && req.getBatchNo().length() > 20) {
            errs.append("批次长度不能超过20");
        }

        if (StrUtil.isNotBlank(req.getSequenceNo()) && req.getSequenceNo().length() > 50) {
            errs.append("序列号长度不能超过50");
        }

        if (StrUtil.isNotBlank(req.getMaterialBarCode()) && req.getMaterialBarCode().length() > 50) {
            errs.append("零件条码长度不能超过50");
        }

        if (StrUtil.isNotEmpty(req.getAddDate())) {
            try {
                LocalDate.parse(req.getAddDate(), DATE_FORMATTER);
            } catch (Exception e) {
                errs.append("入库日期不正确");
            }
        }

        if (StrUtil.isNotEmpty(req.getProductDate())) {
            try {
                LocalDate.parse(req.getProductDate(), DATE_FORMATTER);
            } catch (Exception e) {
                errs.append("生产日期不正确");
            }
        }

        if (StrUtil.isNotEmpty(req.getExpireDate())) {
            try {
                LocalDate.parse(req.getExpireDate(), DATE_FORMATTER);
            } catch (Exception e) {
                errs.append("失效日期不正确");
            }
        }

        if (StrUtil.isNotEmpty(req.getSupplierCode()) && !supplierCodes.contains(req.getSupplierCode())) {
            errs.append("供应商不存在");
        }

        if (StrUtil.isNotEmpty(req.getProjectCode()) && !projectMap.containsKey(req.getProjectCode())) {
            errs.append("项目不存在");
        }

        if (StrUtil.isNotEmpty(req.getStageCode()) && !stageMap.containsKey(req.getStageCode())) {
            errs.append("阶段不存在");
        }

        if (StrUtil.isNotBlank(req.getWbsCode()) && req.getWbsCode().length() > 50) {
            errs.append("WBS编号长度不能超过50");
        }

        if (StrUtil.isNotBlank(req.getPurchaseOrderNo()) && req.getPurchaseOrderNo().length() > 20) {
            errs.append("业务单号长度不能超过20");
        }

        if (StrUtil.isNotBlank(req.getColumnProjectNo()) && req.getColumnProjectNo().length() > 20) {
            errs.append("业务单行号长度不能超过20");
        }

        if (StrUtil.isNotBlank(req.getPalletNo()) && !pallCodes.contains(req.getPalletNo())) {
            errs.append("托盘号不存在");
        }

        if (StrUtil.isNotBlank(req.getCaseNo()) && !workbinCodes.contains(req.getCaseNo())) {
            errs.append("料箱号不存在");
        }

        extendExportDto.setCheckResult(errs.toString());
    }

    private static void checkShipperInfoAndReceiverInfo(WarehouseDistributeOrderImportExportResp req, StringBuilder errs) {
        if (StrUtil.isEmpty(req.getReceiveWarehouseCode())) {
            errs.append("收货仓库编码不能为空");
        }

        if (StrUtil.isEmpty(req.getReceiverContact())) {
            errs.append("收货人电话不能为空");
        }

        if (!MapConstant.isProvinceAndCityExist(req.getReceiveProvinceCode(), req.getReceiveCityCode())) {
            errs.append("收货省市不正确或为空");
        }

        if (StrUtil.isBlank(req.getReceiveAddress())) {
            errs.append("收货货地址不能为空");
        }

        if (StrUtil.isEmpty(req.getShipper())) {
            errs.append("发货人不能为空");
        }

        if (StrUtil.isEmpty(req.getShipperContact())) {
            errs.append("发货人电话不能为空");
        }

        if (!MapConstant.isProvinceAndCityExist(req.getDeliverProvinceCode(), req.getDeliverCityCode())) {
            errs.append("发货省市不正确或为空");
        }

        if (StrUtil.isBlank(req.getDeliverAddress())) {
            errs.append("发货地址不能为空");
        }
    }
}
