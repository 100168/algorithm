package com.jiduauto.sps.order.server.utils;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.sdk.enums.GenerateSerialEnum;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.consts.BaseConstants.RedisKey;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author panjian
 */
@Component
@Slf4j
public class GenerateSerialNoUtil {

    @Resource
    private RedisUtil redisUtil;

    /**
     *  单号样式 : CS230101001TEST
     * @author O_chaopeng.huang
     * @param
     */
    public String generateOrderNoPostBiz(GenerateSerialEnum generateSerialEnum, String bizType) {
        String dateStr = DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2);
        String serialNo = generateSerialNo(generateSerialEnum, dateStr, bizType);
        return generateSerialEnum.getType() + dateStr + serialNo + bizType;
    }

    /**
      * 单号样式 : TEST-CS230101001
      * @author O_chaopeng.huang
      * @param
      */
    public String generateOrderNoPreBiz(GenerateSerialEnum generateSerialEnum, String bizType) {
        String dateStr = DateUtils.getDateStr(DateUtil.date(), DateUtils.SHORT_DATE_FORMAT_2);
        String serialNo = generateSerialNo(generateSerialEnum, dateStr, bizType);
        return bizType + "-" + generateSerialEnum.getType() + dateStr + serialNo;
    }

    /**
     * 单号样式 : TEST-CS230101001
     * * @author jian
     */
    public String generateEncodeOrderNoPreBiz(GenerateSerialEnum generateSerialEnum, String bizType) {
        DateTime date = DateUtil.date();
        String dateStr = DateUtils.getDateStr(date, DateUtils.SHORT_DATE_FORMAT_2);
        String serialNo = generateSerialNo(generateSerialEnum, dateStr, bizType);
        int year = date.year() % 2000;
        int month = date.monthBaseOne();
        int day = date.dayOfMonth();
        return bizType + "-" + generateSerialEnum.getType() + StrUtil.padPre(String.valueOf(day), 2, '0') + serialNo + StrUtil.padPre(String.valueOf(month), 2, '0') + year;
    }

    private String generateSerialNo(GenerateSerialEnum generateSerialEnum, String dateStr, String bizType) {

        String redisKey = String.format(RedisKey.ORDER_SERIAL_NO_KEY, generateSerialEnum.getType(), dateStr, bizType);
        Long serialNo = redisUtil.incrAndExpire(redisKey, generateSerialEnum.getStart(),
                24 * 60 * 60);
        log.info("redisKey:{},bizType:{},orderType:{},serialNo:{}", redisKey, bizType, generateSerialEnum.getType(), serialNo);
        if (serialNo > generateSerialEnum.getMaxSerial()) {
            throw new BizException(SpsResponseCodeEnum.SERIAL_MAX_ERROR);
        }
        return StrUtil.padPre(String.valueOf(serialNo), generateSerialEnum.getMaxLength(), '0');
    }

    public String getRedisKey(GenerateSerialEnum generateSerialEnum, String dateStr, String bizType) {
        return String.format(RedisKey.ORDER_SERIAL_NO_KEY, generateSerialEnum.getType(), dateStr, bizType);
    }

}
