package com.jiduauto.sps.order.server.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.List;

/**
 * log key 枚举，一般为记录业务的表名
 */
@Getter
public enum LogKey {

    store_transfer_order("store_transfer_order"),
    store_transfer_order_detail("store_transfer_order_detail"),
    store_free_times("store_free_times"),
    ;

    private final String value;

    LogKey(String value) {
        this.value = value;
    }
    private  final static List<String> STORE_TRANSFER_ORDER_LOG = Arrays.asList(store_transfer_order.value,store_transfer_order_detail.value);
    /**
     * 调拨订单日志key
     */
    public static List<String> getStoreTransferOrderLog() {
        return STORE_TRANSFER_ORDER_LOG;
    }
}
