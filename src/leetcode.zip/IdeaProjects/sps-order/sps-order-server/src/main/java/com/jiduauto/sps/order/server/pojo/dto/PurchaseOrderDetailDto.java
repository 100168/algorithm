package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author panjian
 */
@Data
public class PurchaseOrderDetailDto implements Serializable {

    /**
     * 详情 id
     */
    private Long detailId;
    /**
     * 售后件号
     */
    private String salePartNum;
    /**
     * 物料名称
     */
    private String salePartName;

    /**
     * 采购订单id
     */
    private String purchaseOrderNo;

    /**
     * 最小包装
     */
    private String minPackage;
    /**
     * 折后单价
     */
    private String discountUnitPrice;

    /**
     * 数量
     */
    private String qty;

    /**
     * 行金额
     */
    private String lineAmount;
    /**
     * 门店备注
     */
    private String storeRemark;
    /**
     * vin
     */
    private String vin;
    /**
     * 取消数量
     */
    private String cancelQty;
    /**
     * 收货数量
     */
    private String receiveQty;
    /**
     * 发货数量
     */
    private String deliverQty;

    /**
     * 是否管控件 Y 是 N否
     */
    private String isControl;

    /**
     * 已转单管控件数量
     */
    private String turnedControlQty;

    /**
     * 标准含税价格
     */
    private String standardPriceIncludeTax;

    /**
     * 标准不含税价格
     */
    private String standardPriceExcludeTax;

    /**
     * 折扣率
     */
    private String discountRate;
}
