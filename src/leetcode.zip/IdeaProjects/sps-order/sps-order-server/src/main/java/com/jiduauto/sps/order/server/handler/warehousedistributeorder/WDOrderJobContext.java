package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import java.util.HashMap;

import static com.jiduauto.sps.order.server.handler.warehousedistributeorder.WDJobIndexEnum.*;

@Component
public class WDOrderJobContext implements InitializingBean {


    private final HashMap<Integer, WDOrderJobHandler> map;

    private final HashMap<WarehouseDistributeOrderTypeEnum, Integer> jobIndexMap;

    /*
     * 用来存handler*/
    public WDOrderJobContext() {
        map = new HashMap<>();
        jobIndexMap = new HashMap<>();
    }

    public void register(Integer index, WDOrderJobHandler syncHandler) {
        map.put(index, syncHandler);
    }

    public WDOrderJobHandler getSyncHandler(Integer index) {
        return map.get(index);
    }

    public int getJobIndex(WarehouseDistributeOrderTypeEnum orderType) {
        return jobIndexMap.get(orderType);
    }

    /**
     * 当前订单类型是否需要执行指定的job
     */
    public boolean needExecuteJob(WarehouseDistributeOrderTypeEnum orderType, WDJobIndexEnum jobIndexEnum) {
        Integer i = jobIndexMap.get(orderType);
        if (i == null) {
            return false;
        }
        return (i & jobIndexEnum.getBitIndex()) != 0;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        //商城订单占库
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SM20, OCCUPY_STOCK.getBitIndex() | OUTBOUND_COMMAND.getBitIndex());
        //商城退货同步dhl入库指令&同步tms更新物流信息
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SM11, INBOUND_COMMAND.getBitIndex() | SYNC_TO_TMS_LOGISTIC.getBitIndex());
        //QE11生成待收货列表、同步tms
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.QE11, GENERATE_PENDING_RECEIVE_ORDER.getBitIndex() | SYNC_TO_TMS.getBitIndex());
        //QE12生成待收货列表、同步tms
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.QE12, GENERATE_PENDING_RECEIVE_ORDER.getBitIndex() | SYNC_TO_TMS.getBitIndex());
        //QE13 同步tms更新物流信息
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.QE13, SYNC_TO_TMS_LOGISTIC.getBitIndex());
        //附件旧件索赔回运同步tms、下发入库指令
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SP18, SYNC_TO_TMS.getBitIndex() | INBOUND_COMMAND.getBitIndex());
        //附件旧件索赔回运同步tms、下发入库指令
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SP19, SYNC_TO_TMS.getBitIndex() | INBOUND_COMMAND.getBitIndex());
        //精品间采创建供应商、下发入库指令
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.JC11, INIT_SUPPLIER.getBitIndex() | INBOUND_COMMAND.getBitIndex());
        //附件间采创建供应商、下发入库指令
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SP11, INIT_SUPPLIER.getBitIndex() | INBOUND_COMMAND.getBitIndex());
        //能源间采创建供应商、下发入库指令、同步能源
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.ES11, INIT_SUPPLIER.getBitIndex() | INBOUND_COMMAND.getBitIndex() | INBOUND_TO_ES.getBitIndex());
        //工服间采创建供应商、下发入库指令
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.CL11, INIT_SUPPLIER.getBitIndex() | INBOUND_COMMAND.getBitIndex());

        //报废
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.JC25, OCCUPY_STOCK.getBitIndex() | GENERATE_OUTBOUND_ORDER.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SP25, OCCUPY_STOCK.getBitIndex() | GENERATE_OUTBOUND_ORDER.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.ES25, OCCUPY_STOCK.getBitIndex() | GENERATE_OUTBOUND_ORDER.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.QE25, GENERATE_OUTBOUND_ORDER.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.VP25, GENERATE_OUTBOUND_ORDER.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.JADT25, GENERATE_OUTBOUND_ORDER.getBitIndex());

        //能源调拨先占库然后同步能源出库
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.ES31, OCCUPY_STOCK.getBitIndex() | TRANSFER_OUT_TO_ES.getBitIndex());

        //SM30 同步tms更新物流信息&发送出库消息给商城&初始化供应商
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SM30, SYNC_TO_TMS_LOGISTIC.getBitIndex() | SEND_MSG_SM.getBitIndex() | INIT_SUPPLIER.getBitIndex());

        //SM20 一件代发退货
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SM12, INBOUND_COMMAND.getBitIndex() | SYNC_TO_TMS_LOGISTIC.getBitIndex());


        //索赔出库
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SP29, OCCUPY_STOCK.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.JC29, OCCUPY_STOCK.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.ES29, OCCUPY_STOCK.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.CL29, OCCUPY_STOCK.getBitIndex());

        //采购退货
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SP28, OCCUPY_STOCK.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.JC28, OCCUPY_STOCK.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.ES28, OCCUPY_STOCK.getBitIndex() | TRANSFER_OUT_TO_ES.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.CL28, OCCUPY_STOCK.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.JC21, OUTBOUND_COMMAND.getBitIndex() | UPDATE_FORK_QTY.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.CL21, OUTBOUND_COMMAND.getBitIndex() | UPDATE_FORK_QTY.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.SP21, OCCUPY_STOCK.getBitIndex() | UPDATE_FORK_QTY.getBitIndex());
        jobIndexMap.put(WarehouseDistributeOrderTypeEnum.ES23, OCCUPY_STOCK.getBitIndex() | UPDATE_FORK_QTY.getBitIndex() | APPLY_OUT_TO_ES.getBitIndex());
    }
}
