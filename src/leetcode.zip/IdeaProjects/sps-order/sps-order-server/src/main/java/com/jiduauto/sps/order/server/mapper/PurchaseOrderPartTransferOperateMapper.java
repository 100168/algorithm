package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPartTransferOperatePo;

/**
 * <p>
 * 采购订单部分转单操作表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-12-15
 */
public interface PurchaseOrderPartTransferOperateMapper extends BaseMapper<PurchaseOrderPartTransferOperatePo> {

}
