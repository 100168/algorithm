package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.json.JSONUtil;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.convertor.TmsOrderConvertor;
import com.jiduauto.sps.order.server.convertor.TmsOrderItemConvertor;
import com.jiduauto.sps.order.server.convertor.TmsOrderPackageConvertor;
import com.jiduauto.sps.order.server.service.IBaseDataRespCheckService;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.tms.api.feign.TmsOpenClient;
import com.jiduauto.tms.api.pojo.BaseResp;
import com.jiduauto.tms.api.pojo.req.SpsOrderApplyReq;
import com.jiduauto.tms.api.pojo.req.SpsOrderGoodsItemReq;
import com.jiduauto.tms.api.pojo.resp.OrderApplyReturnResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/*
 * 下发tms创建运单*/
@Slf4j
@Component
public class SyncToTmsHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private TmsOpenClient tmsOpenClient;

    @Resource
    private TmsOrderConvertor tmsOrderConvertor;

    @Resource
    private TmsOrderItemConvertor tmsOrderItemConvertor;

    @Resource
    private TmsOrderPackageConvertor tmsOrderPackageConvertor;

    @Resource
    private SpsClient spsClient;
    @Resource
    private IBaseDataRespCheckService baseDataRespCheckService;

    /**
     * 仓配订单同步tms出库
     */
    @Override
    public void process(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {

        WarehouseDistributeOrderPo orderPo = warehouseDistributeOrderAllPo.getWarehouseDistributeOrderPo();
        WarehouseDistributeLogisticPo logisticPo = warehouseDistributeOrderAllPo.getWarehouseDistributeLogisticPo();
        List<WarehouseDistributeItemPo> poItems = warehouseDistributeOrderAllPo.getItems();
        List<WarehouseDistributeItemPackagePo> itemPackages = warehouseDistributeOrderAllPo.getItemPackages();
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(orderPo.getBizType());
        baseDataReq.setMaterialCodes(poItems.stream().map(WarehouseDistributeItemPo::getMaterialCode).collect(Collectors.toList()));
        BaseResult<BaseDataResp> resp = spsClient.searchBaseData(baseDataReq);
        baseDataRespCheckService.check(resp, baseDataReq);
        Map<String, MaterialPo> materialPoMap = resp.getData().getMaterials().stream().collect(Collectors.toMap(MaterialPo::getSalePartNum, Function.identity()));
        SpsOrderApplyReq spsOrderApplyReq = tmsOrderConvertor.toReq(orderPo, logisticPo);
        spsOrderApplyReq.setUniqueKey(IdUtil.getSnowflake().nextIdStr());
        spsOrderApplyReq.setPackageList(tmsOrderPackageConvertor.toReq(itemPackages).stream().peek(e -> {
            if (Objects.isNull(e.getPackageWeight())) {
                e.setPackageWeight(BigDecimal.ZERO);
            }
        }).collect(Collectors.toList()));
        ArrayList<SpsOrderGoodsItemReq> goodsItemReqs = new ArrayList<>();
        for (WarehouseDistributeItemPo poItem : poItems) {
            SpsOrderGoodsItemReq itemReq = tmsOrderItemConvertor.toReq(poItem);
            MaterialPo materialPo = materialPoMap.getOrDefault(poItem.getMaterialCode(), new MaterialPo());
            itemReq.setGoodsName(materialPo.getMaterialName());
            itemReq.setUnit(materialPo.getOrderUnit());
            goodsItemReqs.add(itemReq);

        }
        spsOrderApplyReq.setGoodsList(goodsItemReqs);
        BaseResp<List<OrderApplyReturnResp>> listBaseResp = tmsOpenClient.spsOrderApply(spsOrderApplyReq);
        List<OrderApplyReturnResp> data = listBaseResp.getData();
        if (listBaseResp.getCode() != 0 || CollUtil.isEmpty(data)) {
            log.info("SyncToTmsHandler#process#listBaseResp:{}", JSONUtil.toJsonStr(listBaseResp));
            throw new BizException("创建承运单异常:" + JSONUtil.toJsonStr(listBaseResp));
        }
        OrderApplyReturnResp orderApplyReturnResp = data.get(0);
        orderPo.setLogisticNo(orderApplyReturnResp.getOrderNo());
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.SYNC_TO_TMS.getBitIndex(), this);
    }
}
