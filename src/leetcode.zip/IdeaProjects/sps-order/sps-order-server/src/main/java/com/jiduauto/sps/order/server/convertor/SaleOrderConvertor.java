package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.vo.req.InternalSoSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderPageSearchReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface SaleOrderConvertor {

    /**转外部
     * @param internalSoSearchReq
     * @return */
    @Mapping(target = "saleOrderNos", ignore = true)
    @Mapping(target = "transferAdvice", ignore = true)
    @Mapping(target = "salePartNum", ignore = true)
    @Mapping(target = "saleOrderType", ignore = true)
    @Mapping(target = "receiveWarehouseCode", ignore = true)
    @Mapping(target = "isDfs", ignore = true)
    @Mapping(target = "dfsStatus", ignore = true)
    @Mapping(target = "deliverWarehouseCode", ignore = true)
    SaleOrderPageSearchReq toReq(InternalSoSearchReq internalSoSearchReq);

}
