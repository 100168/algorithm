package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 销售订单返回字段
 *
 * @author dong.li01
 * @since 4/14/23 2:16 PM
 */
@Data
public class SaleOrderByPoDto {

    private Long id;

    /**
     * 折后单价
     */
    private BigDecimal discountUnitPrice;


    /**
     * 门店采购单号
     */
    private String purchaseOrderNo;

    /**
     * 销售单号
     */
    private String saleOrderNo;


    /**
     * SAP单号
     */
    private String sapOrderNo;

    /**
     * 是否DFS
     */
    private Boolean isDfs;


    /**
     * 订单类型
     */
    private String saleOrderType;

    /**
     * 运输建议
     */
    private String transferAdvice;

    /**
     * 门店code
     */
    private String storeCode;

    /**
     * 门店名称
     */
    private String storeName;

    /**
     * 收货仓库代码
     */
    private String receiveWarehouseCode;

    /**
     * 收货仓库名称
     */
    private String receiveWarehouseName;

    /**
     * 仓库代码
     */
    private String deliverWarehouseCode;

    /**
     * 仓库名称
     */
    private String deliverWarehouseName;

    /**
     * DFS状态中文明
     */
    private String dfsStatus;
    /**
     * DFS状态
     */
    private String dfsStatusCode;

    /**
     * 状态中文明
     */
    private String saleOrderStatus;

    /**
     * 状态
     */
    private String saleOrderStatusCode;

    /**
     * 收货人
     */
    private String receiver;

    /**
     * 收货地址
     */
    private String receiverAddress;

    /*收货人联系方式*/

    private String receiverPhone;

    /**
     * 下发时间
     */
    private String issuedTime;

    /**
     * 转单备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新人
     */
    private String updateUser;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    private String receiverProvince;

    /**
     * 收货市
     */

    private String receiverCity;
    /**
     * 收货区
     */

    private String receiverDistrict;


    /**
     * 预计到货日期
     */
    private String estArrivalTime;

    /**
     * 物流单号
     */
    private String logisticsNo;

    /**
     * WMS实际运输方式
     */
    private String transportType;

    /**
     * 是否 索赔白名单
     */
    private Boolean isClaimWhitelist;

    /**
     * 计划下发时间
     */
    private String planIssueTime;

    /**
     * 售后件号
     */
    private String salePartNum;

    /**
     * 零件名称
     */
    private String salePartName;

    /**
     * 零件销售属性
     */
    private String partSaleField;

    /**
     * 最小包装
     */
    private String minPackage;

    /**
     * 数量
     */
    private BigDecimal qty;

    /**
     * 发货数量
     */
    private BigDecimal deliverQty;

    /**
     * 收货数量
     */
    private BigDecimal receiveQty;

    /**
     * 取消数量
     */
    private BigDecimal cancelQty;

}
