package com.jiduauto.sps.order.server.client.resp;

import lombok.Data;

@Data
public class ReplacePartsItem {
    private String number;

    private String salePartNum;

    private String name;

    private String description;

    private Long sortNum;
}
