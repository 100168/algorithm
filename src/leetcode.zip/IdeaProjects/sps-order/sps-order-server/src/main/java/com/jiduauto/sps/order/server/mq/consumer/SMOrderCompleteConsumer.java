package com.jiduauto.sps.order.server.mq.consumer;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.pojo.param.StockCheckIdempotent;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeOrderMessage;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderOutboundParamPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.VirtualWarehouseUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;

/**
 * @author panjian
 */
@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_SM_PUT_OUT_COMPLETE, topic = BaseConstants.RocketMqTopic.SM_PUT_OUT_COMPLETE, consumeThreadMax = 10)
public class SMOrderCompleteConsumer implements RocketMQListener<MessageExt> {
    @Resource
    private SpsClient spsClient;

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;


    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("SMReceiveConsumer#onMessage messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
        try {
            WarehouseDistributeOrderMessage msg = JSONUtil.toBean(body, WarehouseDistributeOrderMessage.class);
            //只处理正向并且收货完成的数据
            if (isInvalid(msg)) {
                return;
            }
            WarehouseDistributeOrderPo distributeOrderPo = warehouseDistributeOrderService.getByOrderNo(BizTypeEnum.SM.getBizType(), msg.getSpsOrderId());
            //数据校验
            if (Objects.isNull(distributeOrderPo)) {
                log.warn("SMOrderCompleteConsumer#onMessage#仓配订单:{},不存在", msg.getSpsOrderId());
                return;
            }
            //推送sap
            warehouseDistributeOrderService.pushToSap(distributeOrderPo);
        } catch (Exception e) {
            log.warn("StockPutOutResultConsumer#onMessage exception:{}", e.getMessage());
            throw e;
        }

    }

    /**
     * @see WarehouseDistributeOrderMessage
     * 只接收已收货（FulfillmentUserViewStatus() == 3 ）&正向（getFulfillmentType==1）
     */
    private boolean isInvalid(WarehouseDistributeOrderMessage msg) {
        return msg.getFulfillmentUserViewStatus() != 3 || msg.getFulfillmentType() != 1 || StrUtil.isEmpty(msg.getSpsOrderId()) || StrUtil.isEmpty(msg.getOrderId());
    }

    private void updateTransmitQty(List<SaleOrderOutboundParamPo> orderOutboundParamPos) {
        for (SaleOrderOutboundParamPo outboundParamPo : orderOutboundParamPos) {
            InAndOutStockRequest request = JSONUtil.toBean(outboundParamPo.getOutboundParam(), InAndOutStockRequest.class);
            request.setOperationType(OperationType.SUBTRACT);
            request.setIdempotentNo(request.getIdempotentNo() + outboundParamPo.getBizType());
            StockCheckIdempotent idempotent = new StockCheckIdempotent();
            idempotent.setIdempotentNo(request.getIdempotentNo());
            idempotent.setOperationType(OperationType.SUBTRACT);
            idempotent.setBizType(request.getBizType());
            BaseResult result = spsClient.checkIdempotent(idempotent);
            if (!result.isSuccess()) {
                continue;
            }
            request.setBusinessBillNo(request.getBusinessBillNo() + "_v");
            for (InAndOutStockParam param : request.getParams()) {
                param.setStockStatus(StockStatusEnum.IN_TRANSIT.getValue());
                param.setWarehouseCode(VirtualWarehouseUtil.getDefaultVirtualWarehouse());
            }
            BaseResult<Object> resp = spsClient.putOutStock(request);
            if (!resp.isSuccess()) {
                log.info("SMOrderCompleteConsumer#updateTransmitQty:{}", resp.getMessage());
            }
        }
    }

    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
    public void smWdOrderErrorStatusDataFix(WarehouseDistributeOrderPo distributeOrderPo) {
        //异步更新在途库存
        OrderNoReq orderNoReq = new OrderNoReq();
        orderNoReq.setOrderNo(distributeOrderPo.getOrderNo());
        orderNoReq.setBizType(distributeOrderPo.getBizType());
        spsClient.updateVmStock(orderNoReq);
        //更新订单状态为已完成
        distributeOrderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
        distributeOrderPo.setIsSpecial(false);
        warehouseDistributeOrderService.pushToSap(distributeOrderPo);
    }

}
