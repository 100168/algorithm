package com.jiduauto.sps.order.server.convertor;


import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeItemAttachDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemAttachPo;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeItemAttachReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface WarehouseDistributeItemAttachConvertor {

    /**
     * to po
     *
     * @param req req
     * @return WarehouseDistributeItemAttachPo
     */

    @Mapping(target = "warehouseDistributeOrderNo", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "planApplyFlag", expression = "java(java.util.Objects.equals(req.getPlanApplyFlag(),1))")
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    WarehouseDistributeItemAttachPo toPo(WarehouseDistributeItemAttachReq req);

    @Mapping(target = "planApplyFlag", expression = "java(po.getPlanApplyFlag()?1:0)")
    WarehouseDistributeItemAttachReq toReq(WarehouseDistributeItemAttachPo po);
    List<WarehouseDistributeItemAttachReq> toReq(List<WarehouseDistributeItemAttachPo> po);

    List<WarehouseDistributeItemAttachPo> toPo(List<WarehouseDistributeItemAttachReq> req);
    WarehouseDistributeItemAttachDto toDto(WarehouseDistributeItemAttachPo po);

    List<WarehouseDistributeItemAttachDto> toDto(List<WarehouseDistributeItemAttachPo> pos);
}
