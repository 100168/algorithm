package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.sps.order.server.facade.SaleOrderFacadeService;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderByPoDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalSoSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderListSearchByPoReq;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderListSearchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 提供智子销售订单
 * @author panjian
 */
@RestController
@RequestMapping("/internal/saleOrder")
@Slf4j
public class InternalSaleOrderController {

    @Resource
    private SaleOrderFacadeService saleOrderFacadeService;
    /**销售订单列表查询*/
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<SaleOrderDto>> internalPageSearch(@RequestBody @Valid BasePageParam<InternalSoSearchReq> pageParam) {
        return BaseResult.OK(saleOrderFacadeService.internalPageSearch(pageParam));
    }
    /**销售订单明细查询*/
    @PostMapping("/detail/pageSearch")
    public BaseResult<BasePageData<SaleOrderDetailDto>> internalDetailPageSearch(@RequestBody @Valid BasePageParam<SaleOrderDetailByIdReq> pageParam) {
        return BaseResult.OK(saleOrderFacadeService.internalDetailPageSearch(pageParam));
    }

    /**智子销售订单列表批量查询接口 SO单号*/
    @PostMapping("/list")
    public BaseResult<List<SaleOrderDto>> internalPageSearch(@RequestBody @Valid SaleOrderListSearchReq listSearchReq) {
        return BaseResult.OK(saleOrderFacadeService.list(listSearchReq));
    }


    /**智子销售订单列表批量查询接口 PO单号*/
    @PostMapping("/listDetailByPo")
    public BaseResult<List<SaleOrderByPoDto>> internalPageSearchByPo(@RequestBody @Valid SaleOrderListSearchByPoReq listSearchReq) {
        return BaseResult.OK(saleOrderFacadeService.listByPo(listSearchReq));
    }


}
