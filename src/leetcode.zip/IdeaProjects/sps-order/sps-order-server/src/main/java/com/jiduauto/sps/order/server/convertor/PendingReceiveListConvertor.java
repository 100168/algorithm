package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.dto.PendingReceiveListDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PendingReceiveListConvertor {


    @Mapping(target = "processCode", source = "inProcessCode")
    @Mapping(target = "shipperContact", ignore = true)
    @Mapping(target = "shipper", ignore = true)
    @Mapping(target = "orderStatusCode", ignore = true)
    @Mapping(target = "warehouseCode", ignore = true)
    @Mapping(target = "outOrderNo", source = "po.businessBillNo")
    @Mapping(target = "materialQty", ignore = true)
    @Mapping(target = "expectQty", ignore = true)
    @Mapping(target = "estArrivalTime", ignore = true)
    @Mapping(target = "actualQty", ignore = true)
    @Mapping(target = "id", ignore = true)
    PendingReceiveListDto toDto(WarehouseDistributeOrderPo po);
}
