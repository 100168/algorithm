package com.jiduauto.sps.order.server.facade;


import com.jiduauto.sps.order.server.pojo.dto.SaleOrderByPoDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalSoSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderListSearchByPoReq;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderListSearchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

import java.util.List;

/**
 * @author panjian
 */
public interface SaleOrderFacadeService {

    /**
     * 销售订单列表查询
     * @param pageParam
     * @return */
    BasePageData<SaleOrderDto> internalPageSearch(BasePageParam<InternalSoSearchReq> pageParam);

    /**
     * 销售订单明细列表查询
     * @param pageParam
     * @return */
    BasePageData<SaleOrderDetailDto> internalDetailPageSearch(BasePageParam<SaleOrderDetailByIdReq> pageParam);

    /**
     * 销售订单列表批量查询  SO单号
     * @param listSearchReq 订单号
     * @return list*/
    List<SaleOrderDto> list(SaleOrderListSearchReq listSearchReq);
    /**
     * 销售订单列表批量查询
     * @param listSearchReq po单号
     * @return list*/
    List<SaleOrderByPoDto> listByPo(SaleOrderListSearchByPoReq listSearchReq);
}
