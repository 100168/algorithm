package com.jiduauto.sps.order.server.caches;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Lists;
import com.jiduauto.sps.order.server.client.MapLocationClient;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.DictItemPo;
import com.jiduauto.sps.sdk.pojo.resp.DistrictResp;
import com.jiduauto.sps.sdk.pojo.resp.ResultResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Nonnull;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;


@Component
@Slf4j
public class MapLocationCache {

    @Resource
    private MapLocationClient mapLocationClient;

    private final LoadingCache<String, Optional<List<DictItemPo>>> loadingCache = CacheBuilder.newBuilder().expireAfterWrite(1, TimeUnit.HOURS)
            .build(new CacheLoader<String, Optional<List<DictItemPo>>>() {
                @Override
                public Optional<List<DictItemPo>> load(@Nonnull String key) {
                    return Optional.of(initDictCode(key));
                }
            });

    /**
     * 只支持地图信息查询
     */
    public List<DictItemPo> getByDictCode(String dictCode) {
        if (!DictEnum.MapLocationDistrict.getDictCode().equals(dictCode)) {
            log.error("MapLocationCache 只支持地图信息查询");
            return new ArrayList<>();
        }
        try {
            if (StrUtil.isBlank(dictCode)) {
                return new ArrayList<>();
            }
            List<DictItemPo> result = loadingCache.get(dictCode).orElse(Lists.newArrayList());
            if (CollUtil.isEmpty(result)) {
                loadingCache.invalidate(dictCode);
                //缓存没有 重新查询下数据库
                return initDictCode(dictCode);
            }
            return result;
        } catch (Exception e) {
            log.error("字典缓存查询异常", e);
            return initDictCode(dictCode);
        }
    }


    private List<DictItemPo> initDictCode(String dictCode) {
        ResultResp<List<DistrictResp>> result = mapLocationClient.listDistrict();
        if (!result.isSuccess()) {
            throw new BizException("获取省市区出错");
        }
        return convertDictItem(result.getData(), 1);
    }

    private List<DictItemPo> convertDictItem(List<DistrictResp> districtResps, int level) {
        List<DictItemPo> dictItemPos = Lists.newArrayList();
        if (CollUtil.isNotEmpty(districtResps)) {
            districtResps.forEach(item -> {
                DictItemPo dictItemPo = new DictItemPo();
                dictItemPo.setItemCode(item.getCode());
                dictItemPo.setItemName(item.getName());
                dictItemPo.setStatus(Boolean.TRUE);
                dictItemPos.add(dictItemPo);
                dictItemPo.setSort(level);
                dictItemPos.addAll(convertDictItem(item.getChildList(), level + 1));
            });
        }
        return dictItemPos;
    }
}
