package com.jiduauto.sps.order.server.mapper;


import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface TestSpsMaterialMapper {

    @Select("select count(*) from material")
    int countMaterial();
}
