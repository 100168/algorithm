package com.jiduauto.sps.order.server.facade.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.convertor.BackOrderConvertor;
import com.jiduauto.sps.order.server.facade.BackOrderFacadeService;
import com.jiduauto.sps.order.server.mapper.BackOrderMapper;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalBackOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderCancelReq;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderListSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderPageSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalBoSearchReq;
import com.jiduauto.sps.order.server.service.IBackOrderService;
import com.jiduauto.sps.order.server.service.IPurchaseOrderDetailService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.BackOrderStatusEnum;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.OperateUserEnum;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.BackOrderPo;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import lombok.val;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author panjian
 */
@Service
public class BackOrderFacadeServiceImpl implements BackOrderFacadeService {

    @Resource
    private IBackOrderService backOrderService;

    @Resource
    private BackOrderMapper backOrderMapper;

    @Resource
    private BackOrderConvertor backOrderConvertor;
    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;

    @Resource
    private BaseDataQuery baseDataQuery;
    @Resource
    private WebhookUtil webhookUtil;

    @Override
    public BasePageData<InternalBackOrderDto> internalPageSearch(BasePageParam<InternalBoSearchReq> internalPageParam) {

        BasePageParam<BackOrderPageSearchReq> pageParam = new BasePageParam<>();
        BeanUtils.copyProperties(internalPageParam, pageParam);
        BackOrderPageSearchReq searchReq = backOrderConvertor.toReq(internalPageParam.getParam());
        searchReq.setBackOrderType(internalPageParam.getParam().getPurchaseOrderType());

        List<String> salePartNums = CollUtil.isEmpty(searchReq.getSalePartNums()) ?
                new ArrayList<>() : searchReq.getSalePartNums();
        if (StrUtil.isNotBlank(searchReq.getSalePartName())) {
            List<MaterialPo> materialPos = baseDataQuery.queryNameLikeMaterial(searchReq.getBizType(), searchReq.getSalePartName());
            if (CollUtil.isEmpty(materialPos)) {
                //说明没有这样的零件名称
                return BasePageData.empty();
            }

            List<String> collect = materialPos.stream().map(MaterialPo::getSalePartNum).collect(Collectors.toList());
            salePartNums.addAll(collect);
            searchReq.setSalePartNums(salePartNums);
        }
        pageParam.setParam(searchReq);
        BasePageData<BackOrderDto> pageData = backOrderService.pageSearch(pageParam);
        Map<String, BigDecimal> priceByPos = purchaseOrderDetailService.getDiscountUnitPriceByPos(
                pageData.getRecords().stream().map(BackOrderDto::getPurchaseOrderNo).collect(
                        Collectors.toList()));
        List<InternalBackOrderDto> collect = pageData.getRecords().stream().map(o -> {
            InternalBackOrderDto internalBackOrderDto = BeanUtil.copyProperties(o, InternalBackOrderDto.class);
            internalBackOrderDto.setPurchaseOrderType(o.getBackOrderType());
            //折后单价
            internalBackOrderDto.setDiscountUnitPrice(
                    priceByPos.getOrDefault(o.getPurchaseOrderNo() + o.getSalePartNum(), new BigDecimal(0)));
            return internalBackOrderDto;
        }).collect(Collectors.toList());
        return new BasePageData<>(pageData.getTotal(), pageData.getSize(), pageData.getCurrent(), pageData.getPages(), collect);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancelApply(BackOrderCancelReq cancelReq) {
        BackOrderPo backOrderPo = backOrderMapper.selectOne(Wrappers.lambdaQuery(BackOrderPo.class)
                .eq(BackOrderPo::getBackOrderNo, cancelReq.getBackOrderNo()));
        if (Objects.isNull(backOrderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        if (!BackOrderStatusEnum.canCancel(backOrderPo.getBackOrderStatus())) {
            throw new BizException(SpsResponseCodeEnum.OPERATE_NOT_SUPPORTED);
        }
        backOrderService.updateStatusAndSendMessage(BackOrderStatusChangeDto.builder()
                .backOrderPo(backOrderPo)
                .newStatusEnum(BackOrderStatusEnum.CANCEL_PENDING)
                .operateEnum(OperateEnum.MANUAL_CANCEL_APPLY)
                .operateUser(OperateUserEnum.ODIN.getName())
                .build());

        //成功发起取消， 通知总仓飞书群
        webhookUtil.sendMarkdownMessage2Business(cancelReq.getBackOrderNo()+"缺件行号，申请取消，请处理","缺件取消门店发起提醒");
    }

    @Override
    public List<InternalBackOrderDto> list(BackOrderListSearchReq listSearchReq) {
        BasePageParam<BackOrderPageSearchReq> pageParam = new BasePageParam<>();
        pageParam.setSize(BaseConstants.ListMaxSize.HUNDRED);
        val backOrderPageSearchReq = new BackOrderPageSearchReq();
        backOrderPageSearchReq.setBackOrderNos(listSearchReq.getBackOrderNos());
        backOrderPageSearchReq.setBizType(listSearchReq.getBizType());
        pageParam.setParam(backOrderPageSearchReq);
        return backOrderService.pageSearch(pageParam).getRecords().stream()
                .map(o -> BeanUtil.copyProperties(o, InternalBackOrderDto.class)).collect(Collectors.toList());
    }
}
