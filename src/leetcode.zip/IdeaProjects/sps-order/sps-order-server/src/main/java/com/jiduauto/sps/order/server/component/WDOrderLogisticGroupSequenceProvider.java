package com.jiduauto.sps.order.server.component;

import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeLogisticReq;
import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;


import java.util.ArrayList;
import java.util.List;

import static com.jiduauto.sps.order.server.component.WDOrderItemGroupSequenceProvider.getClasses;

/**
 * @author panjian
 */
public class WDOrderLogisticGroupSequenceProvider implements DefaultGroupSequenceProvider<WarehouseDistributeLogisticReq> {


    @Override
    public List<Class<?>> getValidationGroups(WarehouseDistributeLogisticReq bean) {
        List<Class<?>> defaultGroupSequence = new ArrayList<>();
        defaultGroupSequence.add(WarehouseDistributeLogisticReq.class);
        // 这块判空请务必要做
        return getClasses(defaultGroupSequence, bean != null);
    }
}
