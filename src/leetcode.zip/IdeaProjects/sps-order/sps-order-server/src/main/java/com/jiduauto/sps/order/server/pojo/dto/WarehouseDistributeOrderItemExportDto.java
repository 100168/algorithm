package com.jiduauto.sps.order.server.pojo.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.*;
import com.alibaba.excel.enums.BooleanEnum;
import com.alibaba.excel.enums.poi.FillPatternTypeEnum;
import com.alibaba.excel.enums.poi.HorizontalAlignmentEnum;
import com.alibaba.excel.enums.poi.VerticalAlignmentEnum;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 仓配订单明细导出
 */
@Data
@HeadStyle(fillPatternType = FillPatternTypeEnum.SOLID_FOREGROUND, fillForegroundColor = 51)
@HeadFontStyle(fontHeightInPoints = 11)
@ContentFontStyle(fontHeightInPoints = 11)
@ContentStyle(horizontalAlignment = HorizontalAlignmentEnum.LEFT,
        verticalAlignment = VerticalAlignmentEnum.CENTER,
        wrapped = BooleanEnum.TRUE)
public class WarehouseDistributeOrderItemExportDto implements Serializable {


    /**
     * 订单号
     */
    @ExcelProperty(value = {"订单号"})
    @ColumnWidth(20)
    private String orderNo;
    /**
     * 订单时间
     */
    @ExcelProperty(value = {"订单时间"})
    @ColumnWidth(20)
    private String orderTime;
    /**
     * 订单状态
     */
    @ExcelProperty(value = {"订单状态"})
    @ColumnWidth(20)
    private String orderStatusName;
    /**
     * 业务单号订单号
     */
    @ExcelProperty(value = {"业务订单号"})
    @ColumnWidth(20)
    private String businessBillNo;

    /**
     * 关联订单号
     */
    @ExcelProperty(value = {"业务关联单号"})
    @ColumnWidth(20)
    private String associateBillNo;
    /**
     * 运单号
     */
    @ExcelProperty(value = {"运单号"})
    @ColumnWidth(20)
    private String logisticNo;


    /**
     * 流程编号
     */
    @ExcelProperty(value = {"流程编号"})
    @ColumnWidth(20)
    private String processCode;

    /**
     * 订单类型
     */
    @ExcelProperty(value = {"订单类型"})
    @ColumnWidth(20)
    private String orderTypeName;
    /**
     * 业务类型
     */
    @ExcelProperty(value = {"业务类型"})
    @ColumnWidth(20)
    private String bizTypeName;
    /**
     * 仓配类型
     */
    @ExcelProperty(value = {"仓配类型"})
    @ColumnWidth(20)
    private String logisticTypeName;

    //零件总数
    @ExcelProperty(value = {"零件总数量"})
    @ColumnWidth(20)
    private BigDecimal totalQty;
    //零件总入库数
    @ExcelProperty(value = {"入库总数量"})
    @ColumnWidth(20)
    private BigDecimal totalRealInQty;
    //零件总出库数
    @ExcelProperty(value = {"出库总数量"})
    @ColumnWidth(20)
    private BigDecimal totalRealOutQty;
    //零件总体积数
    @ExcelProperty(value = {"零件总体积"})
    @ColumnWidth(20)
    private BigDecimal totalVolume;
    //零件总重量数
    @ExcelProperty(value = {"零件总重量"})
    @ColumnWidth(20)
    private BigDecimal totalWeight;
    //零件包装总数
    @ExcelProperty(value = {"包装总数量"})
    @ColumnWidth(20)
    private BigDecimal totalPackingQty;
    //零件包装总体积数
    @ExcelProperty(value = {"包装总体积"})
    @ColumnWidth(20)
    private BigDecimal totalPackingVolume;
    //零件包装总重量数
    @ExcelProperty(value = {"包装总重量"})
    @ColumnWidth(20)
    private BigDecimal totalPackingWeight;
    /**
     * 发货仓库代码
     */
    @ExcelProperty(value = {"发货仓库"})
    @ColumnWidth(20)
    private String deliverWarehouseCode;

    /**
     * 收货仓库代码
     */
    @ExcelProperty(value = {"收货仓库"})
    @ColumnWidth(20)
    private String receiveWarehouseCode;

    /**
     * 运输方式
     */
    @ExcelProperty(value = {"运输方式"})
    @ColumnWidth(20)
    private String shippingMethodName;
    /**
     * 预计提货时间
     */
    @ExcelProperty(value = {"预计提货时间"})
    @ColumnWidth(20)
    private String estPickTime;

    /**
     * 预计到货时间(要求到货时间)
     */
    @ExcelProperty(value = {"要求到货时间"})
    @ColumnWidth(20)
    private String estArrivalTime;
    /**
     * 实际到货时间
     */
    @ExcelProperty(value = {"实际到货时间"})
    @ColumnWidth(20)
    private String actualArrivalTime;
    /**
     * 取消原因
     */
    @ExcelProperty(value = {"取消原因"})
    @ColumnWidth(20)
    private String reason;

    /**
     * 入库流程名称
     */
    @ExcelProperty(value = {"入库流程"})
    @ColumnWidth(20)
    private String inProcessCodeName;

    /**
     * 出库流程名称
     */
    @ExcelProperty(value = {"出库流程"})
    @ColumnWidth(20)
    private String outProcessCodeName;

    /**
     * 备注
     */
    @ExcelProperty(value = {"备注"})
    @ColumnWidth(20)
    private String remark;
    /**
     * 创建者
     */
    @ExcelProperty(value = {"创建人"})
    @ColumnWidth(20)
    private String createUser;

    /**
     * 创建时间
     */
    @ExcelProperty(value = {"创建时间"})
    @ColumnWidth(20)
    private String createTime;

    /**
     * 更新者
     */
    @ExcelProperty(value = {"更新人"})
    @ColumnWidth(20)
    private String updateUser;

    /**
     * 更新时间
     */
    @ExcelProperty(value = {"更新时间"})
    @ColumnWidth(20)
    private String updateTime;

    /**
     * 发货人
     */
    @ExcelProperty(value = {"发货人"})
    @ColumnWidth(20)
    private String shipper;

    /**
     * 发货省/市/区名称
     */
    @ExcelProperty(value = {"发货省市区"})
    @ColumnWidth(20)
    private String deliverUni;

    /**
     * 发货地址
     */
    @ExcelProperty(value = {"发货地址"})
    @ColumnWidth(20)
    private String deliverAddress;

    /**
     * 收货人
     */
    @ExcelProperty(value = {"收货人"})
    @ColumnWidth(20)
    private String receiver;

    /**
     * 收货省/市/区名称
     */
    @ExcelProperty(value = {"收货省市区"})
    @ColumnWidth(20)
    private String receiveUni;

    /**
     * 收货地址
     */
    @ExcelProperty(value = {"收货地址"})
    @ColumnWidth(20)
    private String receiveAddress;

    /**
     * 领用人
     */
    @ExcelProperty(value = {"领用人"})
    @ColumnWidth(20)
    private String applier;

    /**
     * 领用人联系方式
     */
    @ExcelProperty(value = {"领用人联系方式"})
    @ColumnWidth(20)
    private String applierContact;

    /**
     * 领用日期
     */
    @ExcelProperty(value = {"领用日期"})
    @ColumnWidth(20)
    private String applyDate;

    /**
     * 领用公司
     */
    @ExcelProperty(value = {"领用公司"})
    @ColumnWidth(20)
    private String applyCompany;

    /**
     * 被领用公司
     */
    @ExcelProperty(value = {"被领用公司"})
    @ColumnWidth(20)
    private String beAppliedCompany;

    /**
     * 领用目的
     */
    @ExcelProperty(value = {"领用目的"})
    @ColumnWidth(20)
    private String applyAim;

    /**
     * 零件行号
     */
    @ExcelProperty(value = {"零件行号"})
    @ColumnWidth(20)
    private String materialLineNo;


    /**
     * 零件业务类型
     */
    @ExcelProperty(value = {"零件业务类型"})
    @ColumnWidth(20)
    private String bizType;



    /**
     * 零件编码
     */
    @ExcelProperty(value = {"零件编码"})
    @ColumnWidth(20)
    private String materialCode;
    /**
     * 零件name
     */
    @ExcelProperty(value = {"零件名称"})
    @ColumnWidth(20)
    private String materialName;

    /**
     * 包装编码
     */
    @ExcelProperty(value = {"包装编码"})
    @ColumnWidth(20)
    private String packingCode;

    /**
     * 体积
     */
    @ExcelProperty(value = {"体积"})
    @ColumnWidth(20)
    private BigDecimal volume;

    /**
     * 重量
     */
    @ExcelProperty(value = {"重量"})
    @ColumnWidth(20)
    private BigDecimal weight;
    /**
     * 数量
     */
    @ExcelProperty(value = {"数量"})
    @ColumnWidth(20)
    private BigDecimal qty;


    /**
     * 实际入库数量
     */
    @ExcelProperty(value = {"入库数量"})
    @ColumnWidth(20)
    private BigDecimal realInQty;
    /**
     * 实际出库数量
     */
    @ExcelProperty(value = {"出库数量"})
    @ColumnWidth(20)
    private BigDecimal realOutQty;

    /**
     * 零件状态
     */
    @ExcelProperty(value = {"零件状态"})
    @ColumnWidth(20)
    private String materialStatusName;

    /**
     * 库存状态
     */
    @ExcelProperty(value = {"库存状态"})
    @ColumnWidth(20)
    private String stockStatusName;

    /**
     * 零件种类
     */
    @ExcelProperty(value = {"零件种类"})
    @ColumnWidth(20)
    private String materialSortName;

    @ExcelProperty(value = {"样件状态"})
    @ColumnWidth(20)
    private String samplePartStatus;

    /**
     * 车辆编码
     */
    @ExcelProperty(value = {"车辆号"})
    @ColumnWidth(20)
    private String carCode;

    /**
     * 批次号
     */
    @ExcelProperty(value = {"批次号"})
    @ColumnWidth(20)
    private String batchNo;

    /**
     * 零件条码
     */
    @ExcelProperty(value = {"零件条码"})
    @ColumnWidth(20)
    private String materialBarCode;

    /**
     * 序列号
     */
    @ExcelProperty(value = {"序列号"})
    @ColumnWidth(20)
    private String sequenceNo;

    /**
     * 入库日期
     */
    @ExcelProperty(value = {"入库日期"})
    @ColumnWidth(20)
    private String addDate;

    /**
     * 生产日期
     */
    @ExcelProperty(value = {"生产日期"})
    @ColumnWidth(20)
    private String productDate;

    /**
     * 失效日期
     */
    @ExcelProperty(value = {"失效日期"})
    @ColumnWidth(20)
    private String expireDate;

    /**
     * 供应商编码
     */
    @ExcelProperty(value = {"供应商代码"})
    @ColumnWidth(20)
    private String supplierCode;

    /**
     * 项目号
     */
    @ExcelProperty(value = {"项目"})
    @ColumnWidth(20)
    private String projectName;
    /**
     * 阶段
     */
    @ExcelProperty(value = {"阶段"})
    @ColumnWidth(20)
    private String stageName;
    /**
     * wbs编号
     */
    @ExcelProperty(value = {"wbs编号"})
    @ColumnWidth(20)
    private String wbsCode;

    /**
     * 业务单号
     */
    @ExcelProperty(value = {"业务单号"})
    @ColumnWidth(20)
    private String purchaseOrderNo;

    /**
     * 业务行号
     */
    @ExcelProperty(value = {"业务行号"})
    @ColumnWidth(20)
    private String columnProjectNo;

    /**
     * 仓库代码
     */
    @ExcelProperty(value = {"仓库"})
    @ColumnWidth(20)
    private String warehouseName;

    /**
     * 区域代码
     */
    @ExcelProperty(value = {"区域"})
    @ColumnWidth(20)
    private String areaName;


    /**
     * 库位代码
     */
    @ExcelProperty(value = {"库位"})
    private String locationName;


    /**
     * 领用用途
     */
    @ExcelProperty(value = {"领用用途"})
    @ColumnWidth(20)
    private String applyPurposeName;

    /**
     * 是否计划内领料,1是0不是
     */
    @ExcelProperty(value = {"计划内领料"})
    @ColumnWidth(20)
    private String planApplyFlag;

    /**
     * SAP卡片号
     */
    @ExcelProperty(value = {"SAP卡片号"})
    @ColumnWidth(20)
    private String sapCardNo;

    /**
     * 成本中心
     */
    @ExcelProperty(value = {"成本中心"})
    @ColumnWidth(20)
    private String costCenter;

    /**
     * 责任方
     */
    @ExcelProperty(value = {"责任方"})
    @ColumnWidth(20)
    private String responsibleParty;

}
