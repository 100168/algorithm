package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.StoreFreeTimesDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreFreeTimesAddAndEditReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreFreeTimesPageReq;
import com.jiduauto.sps.order.server.service.IStoreFreeTimesService;
import com.jiduauto.sps.sdk.pojo.dto.CommonLogDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 门店免费次数配置 前端控制器
 *
 * @author generate
 * @since 2024-05-11
 */
@RestController
@RequestMapping("/storeFreeTimes")
public class StoreFreeTimesController {

    @Resource
    private IStoreFreeTimesService storeFreeTimesService;

    /**
     * 新建
     */
    @PostMapping("/add")
    public BaseResult<String> add(@RequestBody @Valid StoreFreeTimesAddAndEditReq req) {
        storeFreeTimesService.add(req);
        return BaseResult.OK();
    }

    /**
     * 编辑
     */
    @PostMapping("/edit")
    public BaseResult<String> edit(@RequestBody @Valid StoreFreeTimesAddAndEditReq req) {
        storeFreeTimesService.edit(req);
        return BaseResult.OK();
    }

    /**
     * 分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StoreFreeTimesDto>> pageSearch(@RequestBody @Valid BasePageParam<StoreFreeTimesPageReq> pageParam) {
        return BaseResult.OK(storeFreeTimesService.pageSearch(pageParam));
    }


    /**
     * 删除
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid IdReq req) {
        storeFreeTimesService.delete(req);
        return BaseResult.OK();
    }

    /**
     * 详情
     */
    @PostMapping("/detail")
    public BaseResult<StoreFreeTimesDto> detail(@RequestBody @Valid IdReq req) {
        return BaseResult.OK(storeFreeTimesService.detail(req));
    }

    /**
     * 导入 折扣配置
     */
    @PostMapping("/import")
    public BaseResult<ImportResultResp> importExcel(@RequestHeader("bizType") String bizType, @RequestPart("file") MultipartFile file) {
        return BaseResult.OK(storeFreeTimesService.importExcel(bizType, file));
    }

    /**
     * 日志分页查询
     */
    @PostMapping("/log/pageSearch")
    public BaseResult<BasePageData<CommonLogDto>> logPageSearch(@RequestBody @Valid BasePageParam<IdReq> pageParam) {
        return BaseResult.OK(storeFreeTimesService.logPageSearch(pageParam));
    }
}
