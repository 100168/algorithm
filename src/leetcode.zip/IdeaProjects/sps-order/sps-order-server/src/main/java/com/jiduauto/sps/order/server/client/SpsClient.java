package com.jiduauto.sps.order.server.client;

import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.client.config.SpsFeignConfig;
import com.jiduauto.sps.order.server.client.req.InternalCreateOrderReq;
import com.jiduauto.sps.order.server.pojo.dto.StockPutOutResultMessage;
import com.jiduauto.sps.order.server.pojo.param.StockCheckIdempotent;
import com.jiduauto.sps.order.server.pojo.vo.req.OutboundApplyOrderCreateReq;
import com.jiduauto.sps.order.server.pojo.vo.req.PendingReceiveListCreateReq;
import com.jiduauto.sps.order.server.pojo.vo.req.PoOccupyStockReq;
import com.jiduauto.sps.order.server.pojo.vo.resp.PoOccupyStockResult;
import com.jiduauto.sps.sdk.client.req.QueryProcessCodeReq;
import com.jiduauto.sps.sdk.client.req.StockOutMapBusinessDto;
import com.jiduauto.sps.sdk.client.req.StockSearchForSS;
import com.jiduauto.sps.sdk.client.resp.QueryProcessCodeResp;
import com.jiduauto.sps.sdk.client.resp.StockSearchForSSResp;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.pojo.dto.PriceLedgerItemDto;
import com.jiduauto.sps.sdk.pojo.dto.StockInMapBusinessDto;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.*;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@FeignClient(name = "cn.dit.dad.sps.http", contextId = "spsClient", path = "/internal/spsOrder", fallbackFactory = SpsClient.SPsClientFallbackFactory.class, configuration = SpsFeignConfig.class)
public interface SpsClient {


    /**
     * /internal/stockOnly  仅处理库存，无订单逻辑
     *
     * @param req
     * @return
     */
    @PostMapping("/putOutStock")
    BaseResult<Object> putOutStock(InAndOutStockRequest req);

    /**
     * 一件代发出库同步商城
     */
    @PostMapping("/sendToSM")
    BaseResult<String> sendToSM(StockPutOutResultMessage req);

    /**
     * 待收货列表创建
     *
     * @param request request
     * @return 订单号
     */
    @PostMapping("/pendingReceiveOrder/create")
    BaseResult<String> createPendingReceiveOrder(@RequestBody PendingReceiveListCreateReq request);

    /**
     * 待出库列表创建
     *
     * @param request request
     * @return 订单号
     */
    @PostMapping("/outboundApplyOrder/create")
    BaseResult<String> createOutboundApplyOrder(@RequestBody OutboundApplyOrderCreateReq request);

    /**
     * 待出库列表取消
     *
     * @param orderNoReq request
     * @return 订单号
     */
    @PostMapping("/outboundApplyOrder/cancel")
    BaseResult<String> cancelOutboundApplyOrder(@RequestBody OrderNoReq orderNoReq);

    /**
     * 根据配置流程 动态创建订单
     */
    @PostMapping("/dynamicCreateOrder")
    BaseResult<String> dynamicCreateOrder(@RequestBody InternalCreateOrderReq request);


    /**
     * 仓配订单占库
     *
     * @param request request
     * @return 订单号
     */
    @PostMapping("/putOutStockMultiBizType")
    BaseResult<String> putOutStockMultiBizType(@RequestBody List<InAndOutStockRequest> request);

    /**
     * 框架协议查询
     *
     * @param request request
     * @return 框架协议
     */
    @PostMapping("/searchFrameContract")
    BaseResult<Map<String, List<PriceLedgerItemDto>>> searchFrameContract(@RequestBody BaseDataReq request);

    /**
     * 基础数据查询
     *
     * @param req req
     * @return baseData
     */
    @PostMapping("/searchBaseData")
    BaseResult<BaseDataResp> searchBaseData(BaseDataReq req);

    /**
     * 销售订单&仓配订单在途库存参数关系表
     *
     * @param request req
     * @return baseData
     */
    @PostMapping("/saleOrderOutParam/list")
    BaseResult<List<SaleOrderOutboundParamPo>> getSaleOrderOutParamList(@RequestBody OrderNoReq request);

    /**
     * 创建采购申请
     */
    @PostMapping("/createPurchaseApply")
    BaseResult<String> createPurchaseApply(@RequestBody CreatePrOrderReq request);

    /**
     * 采购订单 占用库存
     */
    @PostMapping("/poOccupyAllStock")
    BaseResult<Map<String, PoOccupyStockResult>> poOccupyAllStock(@RequestBody PoOccupyStockReq req);

    /**
     * 采购订单 部分占用库存
     */
    @PostMapping("/poOccupyPartStock")
    BaseResult<Map<String, PoOccupyStockResult>> poOccupyPartStock(@RequestBody PoOccupyStockReq req);

    /**
     * 根据销售订单获取物流信息 and 提醒
     */
    @PostMapping("/getLogisticsPo")
    BaseResult<LogisticsPo> getLogisticsPo(@RequestBody SaleOrderPo so);

    /**
     * 校验 SO单的库存占用数量是否正常
     *
     * @param req
     * @return
     */
    @PostMapping("/checkPoOccupy")
    BaseResult<String> checkPoOccupy(@RequestBody PoOccupyStockReq req);

    /**
     * @param req
     * @return
     */
    @PostMapping("/stockOutOrderItemList")
    BaseResult<List<StockOutOrderItemPo>> getStockOutOrderItemList(@RequestBody OrderNoReq req);


    /**
     * 供应商保存
     *
     * @param supplierPo
     * @return
     */
    @PostMapping("/createSupplier")
    BaseResult<String> createSupplier(@RequestBody SupplierPo supplierPo);

    /**
     * 供应商保存
     */
    @PostMapping("/getSpecialWarehouse")
    BaseResult<List<DictItemPo>> getSpecialWarehouse(@RequestBody String bizType);


    /**
     * 采购订单取消， 取消占用库存
     *
     * @return
     */
    @PostMapping("/cancelPoOccupy")
    BaseResult<String> cancelPoOccupy(@RequestBody PoOccupyStockReq req);

    /**
     * 将在途库存变更为正常
     *
     * @return
     */
    @PostMapping("/updateVmStock")
    BaseResult<String> updateVmStock(@RequestBody OrderNoReq req);

    /**
     * 在途库存出库
     *
     * @return
     */
    @PostMapping("/outOfVmStock")
    BaseResult<String> outOfVmStock(@RequestBody OrderNoReq req);

    /**
     * 库存 出库 订单记录新增、编辑等
     *
     * @param stockOutMapBusinessDto
     * @return
     */
    @RequestMapping("/stockOutMapBusiness")
    BaseResult<Boolean> stockOutMapBusiness(@RequestBody StockOutMapBusinessDto stockOutMapBusinessDto);

    @RequestMapping("/checkIdempotent")
    BaseResult<String> checkIdempotent(@RequestBody @Valid StockCheckIdempotent stockCheckIdempotent);


    /**
     * 查询门店库存 (待翻包数量 + 正常数量 - 占用数量)
     */
    @PostMapping("/stock/store/pageSearch")
    BaseResult<List<StockSearchForSSResp>> ssStockSearch(@RequestBody StockSearchForSS ss);

    /**
     * 入库订单创建
     *
     * @param request request
     * @return 订单号
     */
    @PostMapping("/stockInMapBusiness/create")
    BaseResult<String> createStockInMapBusiness(@RequestBody StockInMapBusinessDto request);

    /**
     * 根据门店code 查询 配置了发运金额的订单发运日历
     * @param req IdBatchReq 门店 code list
     */
    @PostMapping("/queryConfigAmountOrderCalendar")
    BaseResult<List<OrderCalendarPo>> queryConfigAmountOrderCalendar(@RequestBody IdBatchReq req);

    /**
     * 查询对应出入库流程code
     */
    @PostMapping("/queryInAndOutProcessCode")
    BaseResult<QueryProcessCodeResp> queryInAndOutProcessCode(@RequestBody QueryProcessCodeReq req);


    /**
     * 仓配订单占库校验
     *
     * @param request request
     * @return 校验信息
     */
    @PostMapping("/checkWdoOccupy")
    BaseResult<String> checkWdoOccupy(@RequestBody InAndOutStockRequest request);


    @Slf4j
    @Component
    class SPsClientFallbackFactory implements FallbackFactory<SpsClient> {

        @Override
        public SpsClient create(Throwable throwable) {
            return new SpsClient() {
                @Override
                public BaseResult<Object> putOutStock(InAndOutStockRequest req) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(req)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> sendToSM(StockPutOutResultMessage req) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> createPendingReceiveOrder(PendingReceiveListCreateReq request) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(request)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> createOutboundApplyOrder(OutboundApplyOrderCreateReq request) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> cancelOutboundApplyOrder(OrderNoReq orderNoReq) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> dynamicCreateOrder(InternalCreateOrderReq request) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> putOutStockMultiBizType(List<InAndOutStockRequest> request) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(request)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<Map<String, List<PriceLedgerItemDto>>> searchFrameContract(BaseDataReq request) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(request)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<BaseDataResp> searchBaseData(BaseDataReq req) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(req)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<List<SaleOrderOutboundParamPo>> getSaleOrderOutParamList(OrderNoReq request) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(request)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> createPurchaseApply(CreatePrOrderReq request) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(request)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<Map<String, PoOccupyStockResult>> poOccupyAllStock(PoOccupyStockReq req) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(req)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<Map<String, PoOccupyStockResult>> poOccupyPartStock(PoOccupyStockReq req) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(req)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<LogisticsPo> getLogisticsPo(SaleOrderPo so) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(so)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> checkPoOccupy(PoOccupyStockReq req) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(req)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<List<StockOutOrderItemPo>> getStockOutOrderItemList(OrderNoReq req) {
                    log.warn(String.format("SpsClient#request error, param: %s", JsonUtil.ObjectToJson(req)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> createSupplier(SupplierPo supplierPo) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<List<DictItemPo>> getSpecialWarehouse(String bizType) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> cancelPoOccupy(PoOccupyStockReq req) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> updateVmStock(OrderNoReq req) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> outOfVmStock(OrderNoReq req) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                /**
                 * 库存 出库 订单记录新增、编辑等
                 *
                 * @param stockOutMapBusinessDto
                 * @return
                 */
                @Override
                public BaseResult<Boolean> stockOutMapBusiness(StockOutMapBusinessDto stockOutMapBusinessDto) {
                    log.warn(String.format("SpsClient#stockOutMapBusiness error, param: %s", JsonUtil.ObjectToJson(stockOutMapBusinessDto)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> checkIdempotent(StockCheckIdempotent stockCheckIdempotent) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                /**
                 * 查询门店库存
                 *
                 * @param ss
                 */
                @Override
                public BaseResult<List<StockSearchForSSResp>> ssStockSearch(StockSearchForSS ss) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> createStockInMapBusiness(StockInMapBusinessDto request) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<List<OrderCalendarPo>> queryConfigAmountOrderCalendar(IdBatchReq req) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<QueryProcessCodeResp> queryInAndOutProcessCode(QueryProcessCodeReq req) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public BaseResult<String> checkWdoOccupy(InAndOutStockRequest request) {
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }
            };
        }
    }
}
