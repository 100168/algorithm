package com.jiduauto.sps.order.server.client.req;

import cn.hutool.core.date.DateUtil;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.google.common.collect.Lists;
import com.jiduauto.sps.sdk.enums.PRTypeEnum;
import com.jiduauto.sps.sdk.enums.PartCategoryEnum;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.pojo.po.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class DfsOrderPlanSyncReq {

    private final static DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern(BaseConstants.DatePattern.DATETIME);
    private final static DateTimeFormatter NONE_DATE_FORMATTER = DateTimeFormatter.ofPattern(BaseConstants.DatePattern.NONE_DATE);
    private final static DateTimeFormatter NONE_TIME_FORMATTER = DateTimeFormatter.ofPattern(BaseConstants.DatePattern.NONE_TIME);

    private ClassMessageHeader MessageHeader;
    private ClassMessageBody MessageBody;


    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageHeader {
        private String Sender;
        private Long SerialNum;
        private String InterfaceID;
        private String SendDate;
        private String SendTime;
        private String Reserve1;
        private String Reserve2;
        private String Reserve3;
        private String Reserve4;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBody {
        private ClassMessageBodyHeader Header;
        private List<ClassMessageBodyItem> item1;
    }


    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyHeader {
        private String Receiver;
        private String Header_Key;
        private String ZSRMPO;
        private String DFSFLAG;
        private String BSART;
        private String LIFNR;
        private String BUKRS;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyItem {
        private String item_Key;
        private String EBELP;
        private String MATNR;
        private String TXZ01;
        private String WERKS;
        private String MENGE;
        private String MEINS;
        private String PEINH;
        private String EINDT;
        private String ZSPSYHJH;
        private String ZSPSSO;
        private String RECEIPTADDRESS;
        private String RECEIPTPERSON;
        private String RECEIPTCONTACT;
        private String SHIPTOCODE;
        private String SHIPTONAME;
        private String ZZTYPE;
        private String ZEBELN;
        private String LGORT;
        private String Reserve1;
        private String Reserve2;
    }


    public static DfsOrderPlanSyncReq newInstance() {
        DfsOrderPlanSyncReq orderPlanSyncDto = new DfsOrderPlanSyncReq();
        orderPlanSyncDto.setMessageHeader(new ClassMessageHeader());
        ClassMessageBody messageBody = new ClassMessageBody();
        messageBody.setHeader(new ClassMessageBodyHeader());
        messageBody.setItem1(Lists.newArrayList(new ClassMessageBodyItem()));
        orderPlanSyncDto.setMessageBody(messageBody);

        orderPlanSyncDto.messageHeader();
        return orderPlanSyncDto;
    }

    public DfsOrderPlanSyncReq messageHeader() {
        LocalDateTime now = LocalDateTime.now();

        MessageHeader.Sender = "SPS";
        MessageHeader.InterfaceID = "MM_003";
        MessageHeader.SendDate = now.format(NONE_DATE_FORMATTER);
        MessageHeader.SendTime = now.format(NONE_TIME_FORMATTER);
        MessageHeader.SerialNum = null;
        return this;
    }
//
//    public DfsOrderPlanSyncReq setOrderPlan(OrderPlanPo orderPlanPo) {
//        MessageBody.Header.Receiver = "SAP";
//        MessageBody.Header.Header_Key = orderPlanPo.getOrderPlanNo();
//        MessageBody.Header.ZSRMPO = orderPlanPo.getPurchaseOrderNo();
//        MessageBody.Header.DFSFLAG = orderPlanPo.getRequirementType();
//        MessageBody.Header.BSART = "ZP05";
//        MessageBody.Header.LIFNR = orderPlanPo.getSupplierSapCode();
//        MessageBody.Header.BUKRS = orderPlanPo.getCompanyCode();
//
//        MessageBody.item1.get(0).item_Key = orderPlanPo.getOrderPlanNo();
//        MessageBody.item1.get(0).EBELP = "10";
//        MessageBody.item1.get(0).MATNR = orderPlanPo.getSalePartNum();
//        MessageBody.item1.get(0).WERKS = orderPlanPo.getPlantCode();
//        MessageBody.item1.get(0).MENGE = orderPlanPo.getQuantity().toString();
//        MessageBody.item1.get(0).MEINS = orderPlanPo.getOrderUnit();
//        MessageBody.item1.get(0).PEINH = "1";
//        MessageBody.item1.get(0).EINDT = orderPlanPo.getEstArrivalTime().format(NONE_DATE_FORMATTER);
//        MessageBody.item1.get(0).ZSPSYHJH = orderPlanPo.getOrderPlanNo();
//        MessageBody.item1.get(0).ZSPSSO = orderPlanPo.getSaleOrderNo();
//        MessageBody.item1.get(0).ZZTYPE = convertPartCategory(orderPlanPo.getBizType());
//        MessageBody.item1.get(0).ZEBELN = orderPlanPo.getContractNo();
//
//        MessageBody.item1.get(0).Reserve1 = orderPlanPo.getVin();
//        MessageBody.item1.get(0).Reserve2 = orderPlanPo.getStoreRemark();
//        return this;
//    }
//
//    /**
//     * 设置类型为 co 和 dfs 类型的采购申请
//     */
//    public void setPurchaseApplyOrderCoAndDfs(PurchaseApplyOrderPo orderPo,
//                                              List<PurchaseApplyOrderDetailPo> detailPos,
//                                              Map<String, MaterialPo> materialPoMap,
//                                              PurchaseOrderPo po,
//                                              WarehousePo warehousePo,
//                                              StorePo storePo
//                                              ) {
//        MessageBody.Header.Receiver = "SAP";
//        MessageBody.Header.Header_Key = orderPo.getOrderNo();
//        MessageBody.Header.ZSRMPO = detailPos.get(0).getPurchaseOrderNo();
//        PRTypeEnum prTypeEnum = PRTypeEnum.getByCode(orderPo.getOrderType());
//        MessageBody.Header.DFSFLAG = prTypeEnum.getSapCode();
//        MessageBody.Header.BSART = "ZP05";
//        MessageBody.Header.LIFNR = orderPo.getSupplierCode();
//        MessageBody.Header.BUKRS = orderPo.getCompanyCode();
//        List<ClassMessageBodyItem> items = new ArrayList<>();
//        for (PurchaseApplyOrderDetailPo detailPo : detailPos) {
//            ClassMessageBodyItem item = new ClassMessageBodyItem();
//            item.item_Key = (String.valueOf(detailPo.getLineNo()));
//            item.EBELP = (String.valueOf(detailPo.getLineNo()));
//            item.MATNR = detailPo.getSalePartNum();
//            item.TXZ01 = materialPoMap.getOrDefault(detailPo.getSalePartNum(), new MaterialPo()).getMaterialName();
//            item.WERKS = orderPo.getCompanyCode();
//            item.MENGE = String.valueOf(detailPo.getQty());
//            item.MEINS = detailPo.getOrderUnit();
//            item.PEINH = "1";
//            item.EINDT = DateUtil.format(DateUtil.parse(detailPo.getEstArrivalTime(), "YYYY-MM-dd"), "yyyyMMdd");
//            item.ZSPSYHJH = orderPo.getOrderNo();
//            item.ZZTYPE = convertPartCategory(orderPo.getBizType());
//            item.ZEBELN = detailPo.getContractNo();
//            item.Reserve2 = detailPo.getRemark();
//            item.SHIPTOCODE = warehousePo.getCode();
//
//            item.LGORT = warehousePo.getStockLocation();
//            if (prTypeEnum.equals(PRTypeEnum.DFS)) {
//                item.ZSPSSO = detailPo.getSaleOrderNo();
//                item.RECEIPTADDRESS = po.getReceiverAddress();
//                item.RECEIPTPERSON = po.getReceiver();
//                item.RECEIPTCONTACT = po.getReceiverPhone();
//
//                item.SHIPTONAME = storePo.getStoreName();
//            } else if (prTypeEnum.equals(PRTypeEnum.CO)){
//                item.RECEIPTADDRESS = warehousePo.getStockLocation();
//                item.RECEIPTPERSON = warehousePo.getContact();
//                item.RECEIPTCONTACT = warehousePo.getPhoneNumber();
//
//                item.SHIPTONAME = warehousePo.getName();
//                item.Reserve1 = detailPo.getVin();
//            }
//            items.add(item);
//        }
//        MessageBody.item1 = items;
//    }
//
//    public void setPurchaseApplyOrder(PurchaseApplyOrderPo orderPo, List<PurchaseApplyOrderDetailPo> detailPos, Map<String, MaterialPo> materialPoMap) {
//        MessageBody.Header.Receiver = "SAP";
//        MessageBody.Header.Header_Key = orderPo.getOrderNo();
//        MessageBody.Header.ZSRMPO = orderPo.getOrderNo();
//        PRTypeEnum prTypeEnum = PRTypeEnum.getByCode(orderPo.getOrderType());
//        MessageBody.Header.DFSFLAG = prTypeEnum.getSapCode();
//        MessageBody.Header.BSART = "ZP05";
//        MessageBody.Header.LIFNR = orderPo.getSupplierCode();
//        MessageBody.Header.BUKRS = orderPo.getCompanyCode();
//        List<ClassMessageBodyItem> items = new ArrayList<>();
//        for (PurchaseApplyOrderDetailPo detailPo : detailPos) {
//            ClassMessageBodyItem item = new ClassMessageBodyItem();
//            item.item_Key = (String.valueOf(detailPo.getLineNo()));
//            item.EBELP = (String.valueOf(detailPo.getLineNo()));
//            item.MATNR = detailPo.getSalePartNum();
//            item.TXZ01 = materialPoMap.getOrDefault(detailPo.getSalePartNum(), new MaterialPo()).getMaterialName();
//            item.WERKS = orderPo.getCompanyCode();
//            item.MENGE = String.valueOf(detailPo.getQty());
//            item.MEINS = detailPo.getOrderUnit();
//            item.PEINH = "1";
//            item.EINDT = DateUtil.format(DateUtil.parse(detailPo.getEstArrivalTime(), "YYYY-MM-dd"), "yyyyMMdd");
//            item.ZSPSYHJH = orderPo.getOrderNo();
//            item.ZZTYPE = convertPartCategory(orderPo.getBizType());
//            item.ZEBELN = detailPo.getContractNo();
//            item.Reserve2 = detailPo.getRemark();
//            //DB子件订单：默认传：600Y
//            if (prTypeEnum.equals(PRTypeEnum.DB_SUB)) {
//                item.LGORT = "600Y";
//            }
//            items.add(item);
//        }
//        MessageBody.item1 = items;
//    }
//
//    public DfsOrderPlanSyncReq setMaterial(MaterialPo materialPo) {
//        if (Objects.nonNull(materialPo)) {
//            MessageBody.item1.get(0).TXZ01 = materialPo.getMaterialName();
//        }
//        return this;
//    }
//
//    public DfsOrderPlanSyncReq setWarehouse(WarehousePo warehousePo) {
//        if (Objects.nonNull(warehousePo)) {
//            MessageBody.item1.get(0).SHIPTOCODE = warehousePo.getCode();
//            MessageBody.item1.get(0).SHIPTONAME = warehousePo.getName();
//            MessageBody.item1.get(0).LGORT = warehousePo.getStockLocation();
//        }
//        return this;
//    }
//
//    public void setPrWarehouse(WarehousePo warehousePo) {
//        List<ClassMessageBodyItem> item1 = MessageBody.item1;
//        if (Objects.nonNull(warehousePo)) {
//            for (ClassMessageBodyItem item : item1) {
//                item.SHIPTOCODE = warehousePo.getCode();
//                item.SHIPTONAME = warehousePo.getName();
//                item.LGORT = warehousePo.getStockLocation();
//                item.setRECEIPTADDRESS(warehousePo.getAddress());
//                item.setRECEIPTPERSON(warehousePo.getContact());
//                item.setRECEIPTCONTACT(warehousePo.getPhoneNumber());
//            }
//        }
//    }

    private String convertPartCategory(String bizType) {
        Integer partCategory = PartCategoryEnum.getBizCode(bizType);
        return Objects.isNull(partCategory) ? null : partCategory.toString();
    }

    public static void main(String[] args) {
        System.out.println(DateUtil.format(DateUtil.parse("", "YYYY-MM-dd"), "yyyyMMdd"));
    }
}
