package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.EmergencyTransferStoreDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalEmergencyTransferStoreDto;
import com.jiduauto.sps.order.server.pojo.po.EmergencyTransferStorePo;
import com.jiduauto.sps.order.server.pojo.vo.req.EmergencyTransferStoreSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalEmergencyTransferStoreReq;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * <p>
 * 应急调拨门店 服务类
 * </p>
 *
 * @author generate
 * @since 2024-11-04
 */
public interface IEmergencyTransferStoreService extends IService<EmergencyTransferStorePo> {

    /**
     * 分页查询
     */
    BasePageData<EmergencyTransferStoreDto> pageSearch(BasePageParam<EmergencyTransferStoreSearchReq> pageParam);

    /**
     * 导入
     */
    ImportResultResp importExcel(String bizType, MultipartFile file);

    /**
     * 智子查询
     */
    List<InternalEmergencyTransferStoreDto> internalSearch(InternalEmergencyTransferStoreReq req);
}
