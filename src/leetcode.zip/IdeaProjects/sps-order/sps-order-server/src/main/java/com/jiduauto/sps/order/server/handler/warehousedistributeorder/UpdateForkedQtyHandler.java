package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.order.server.service.IWarehouseDistributeItemService;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/*
 * 下发dhl入库指令*/
@Component
public class UpdateForkedQtyHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private IWarehouseDistributeItemService warehouseDistributeItemService;

    /*反写已拆数量*/
    @Override
    public void process(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {
        List<WarehouseDistributeItemPo> items = warehouseDistributeOrderAllPo.getItems();
        WarehouseDistributeOrderPo orderPo = warehouseDistributeOrderAllPo.getWarehouseDistributeOrderPo();
        if (WarehouseDistributeOrderTypeEnum.isApplyOrder(orderPo.getOrderType())&&!orderPo.getIsChild()){
            for (WarehouseDistributeItemPo item : items) {
                item.setForkedQty(item.getQty());
            }
        }
        warehouseDistributeItemService.updateBatchById(items);
    }

    /*
     * 注册单前handler*/
    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.UPDATE_FORK_QTY.getBitIndex(), this);
    }
}
