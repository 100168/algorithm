package com.jiduauto.sps.order.server.convertor;


import com.jiduauto.sps.order.server.pojo.dto.PendingReceiveListDetailDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;


@Mapper(componentModel = "spring")
public interface PendingReceiveListDetailPoConvertor {


    @Mapping(target = "supplierName", ignore = true)
    @Mapping(target = "stageName", ignore = true)
    @Mapping(target = "projectName", ignore = true)
    @Mapping(target = "outOrderNo", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    @Mapping(target = "lineNo", source = "po.materialLineNo")
    @Mapping(target = "expectQty", source = "po.qty")
    @Mapping(target = "businessBillNo", source = "po.purchaseOrderNo")
    @Mapping(target = "actualQty", ignore = true)
    @Mapping(target = "id", ignore = true)
    PendingReceiveListDetailDto toDto(WarehouseDistributeItemPo po);


}
