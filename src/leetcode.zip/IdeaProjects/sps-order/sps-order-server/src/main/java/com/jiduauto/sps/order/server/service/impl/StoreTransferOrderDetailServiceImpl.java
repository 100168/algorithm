package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.mapper.StoreTransferOrderDetailMapper;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderDetailService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.pojo.dto.StoreTransferOrderDetailDto;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.StoreTransferOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 门店调拨单明细 服务实现类
 * </p>
 */
@Service
public class StoreTransferOrderDetailServiceImpl extends ServiceImpl<StoreTransferOrderDetailMapper, StoreTransferOrderDetailPo> implements IStoreTransferOrderDetailService {

    @Resource
    private SpsClient spsClient;
    @Resource
    private BaseDataQuery baseDataQuery;

    @Override
    public BasePageData<StoreTransferOrderDetailDto> pageSearch(BasePageParam<OrderNoReq> pageParam) {
        Page<StoreTransferOrderDetailPo> page = page(new Page<>(pageParam.getPage(), pageParam.getSize()),
                Wrappers.lambdaQuery(StoreTransferOrderDetailPo.class)
                        .eq(StoreTransferOrderDetailPo::getBizType, pageParam.getParam().getBizType())
                        .eq(StoreTransferOrderDetailPo::getOrderNo, pageParam.getParam().getOrderNo())
                        .orderByDesc(StoreTransferOrderDetailPo::getId)
        );
        Map<String, MaterialPo> materialPoMap = getmaterialPoMap(pageParam.getParam(),
                page.getRecords().stream().map(StoreTransferOrderDetailPo::getMaterialCode).collect(
                        Collectors.toList()));
        BasePageData<StoreTransferOrderDetailDto> pageData = new BasePageData<>(page);
        pageData.setRecords(page.getRecords().stream().map(item -> {
            StoreTransferOrderDetailDto dto = BeanCopierUtil.copy(item, StoreTransferOrderDetailDto.class);
            dto.setMaterialName(materialPoMap.getOrDefault(item.getMaterialCode(),new MaterialPo()).getMaterialName());
            return dto;
        }).collect(Collectors.toList()));
        return pageData;
    }

    @Override
    public List<StoreTransferOrderDetailPo> listByOrderNo(String orderNo) {
        return list(Wrappers.lambdaQuery(StoreTransferOrderDetailPo.class).eq(StoreTransferOrderDetailPo::getOrderNo, orderNo));
    }

    private Map<String, MaterialPo> getmaterialPoMap(OrderNoReq req, List<String> materialCodeList) {
        return baseDataQuery.mapMaterialPo(req.getBizType(), materialCodeList, false);
    }
}
