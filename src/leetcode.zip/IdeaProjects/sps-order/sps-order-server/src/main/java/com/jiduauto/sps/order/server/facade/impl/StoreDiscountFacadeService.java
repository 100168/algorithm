package com.jiduauto.sps.order.server.facade.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.pojo.dto.InternalStoreDiscountDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountDto;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountPo;
import com.jiduauto.sps.order.server.pojo.po.StoreFreeTimesPo;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreDiscountListReq;
import com.jiduauto.sps.order.server.service.IPurchaseOrderService;
import com.jiduauto.sps.order.server.service.IStoreDiscountService;
import com.jiduauto.sps.order.server.service.IStoreFreeTimesService;
import com.jiduauto.sps.sdk.enums.PurchaseOrderTypeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.BasePo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class StoreDiscountFacadeService {
    @Resource
    private IStoreDiscountService storeDiscountService;

    @Resource
    private IStoreFreeTimesService storeFreeTimesService;

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    /**
     * 根据门店code+订单类型+售后件号+折扣取值日期 获取对应零件的折扣值
     */
    public List<InternalStoreDiscountDto> listEffectiveDiscount(InternalStoreDiscountListReq req) {
        if (!PurchaseOrderTypeEnum.hasValue(req.getOrderType())) {
            throw new BizException("orderType 不存在");
        }

        StoreFreeTimesPo freeTimesPo = storeFreeTimesService.getOne(Wrappers.lambdaQuery(StoreFreeTimesPo.class)
                .eq(StoreFreeTimesPo::getBizType, req.getBizType())
                .eq(StoreFreeTimesPo::getStoreCode, req.getStoreCode())
                .eq(StoreFreeTimesPo::getOrderType, req.getOrderType())
                .eq(StoreFreeTimesPo::getIsDel, false)
        );

        LocalDateTime firstDayOfMonth = LocalDate.now().with(TemporalAdjusters.firstDayOfMonth()).atTime(LocalTime.MIN);
        //当月下单次数
        int count = purchaseOrderService.count(
                Wrappers.lambdaQuery(PurchaseOrderPo.class)
                        .eq(PurchaseOrderPo::getPurchaseOrderType, req.getOrderType())
                        .eq(PurchaseOrderPo::getBizType, req.getBizType())
                        .eq(PurchaseOrderPo::getIsDel, false)
                        .eq(PurchaseOrderPo::getStoreCode, req.getStoreCode())
                        .ge(BasePo::getCreateTime, firstDayOfMonth)
                        .le(BasePo::getCreateTime, LocalDateTime.now())
        );

        //获取对应零件折扣
        Map<String, StoreDiscountDto> materialDiscountMap = storeDiscountService.listEffectiveDiscount(req).stream()
                .collect(Collectors.toMap(StoreDiscountDto::getMaterialCode, Function.identity(), (k, v) -> v));

        StoreDiscountPo noMaterialCodeDiscountPo = storeDiscountService.getOne(Wrappers.lambdaQuery(StoreDiscountPo.class)
                .eq(StoreDiscountPo::getBizType, req.getBizType())
                .eq(StoreDiscountPo::getStoreCode, req.getStoreCode())
                .eq(StoreDiscountPo::getOrderType, req.getOrderType())
                .eq(StoreDiscountPo::getIsDel, false)
                .eq(StoreDiscountPo::getMaterialCode, "")
                .le(StoreDiscountPo::getEffectiveStartTime, req.getDiscountDate().atTime(LocalTime.MIN))
        );
        return req.getMaterialCodeList().stream().map(item -> {
            InternalStoreDiscountDto dto = new InternalStoreDiscountDto();
            //当月下单次数小于等于免费次数
            //https://jiduauto.feishu.cn/wiki/H9jFwMLTsieZI1kuFmFcRwVSn9b
            if (Objects.isNull(freeTimesPo)) {
                dto.setMaterialCode(item);
                dto.setDiscountRate(BigDecimal.ONE);
            } else if (count <= freeTimesPo.getFreeTimes()) {
                dto.setMaterialCode(item);
                dto.setDiscountRate(BigDecimal.ONE);
            } else {
                //此时获取零件折扣 零件折扣只有在 免费次数配置了，用完了的情况下才去获取
                StoreDiscountDto discountDto = materialDiscountMap.get(item);
                if (Objects.nonNull(discountDto)) {
                    dto.setMaterialCode(item);
                    dto.setDiscountRate(new BigDecimal(discountDto.getDiscountRate()));
                } else if (Objects.nonNull(noMaterialCodeDiscountPo)) {
                    dto.setMaterialCode(item);
                    dto.setDiscountRate(noMaterialCodeDiscountPo.getDiscountRate());
                } else {
                    dto.setMaterialCode(item);
                    dto.setDiscountRate(BigDecimal.ONE);
                }
            }
            return dto;
        }).collect(Collectors.toList());
    }
}
