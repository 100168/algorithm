package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.mapper.SaleOrderDetailMapper;
import com.jiduauto.sps.order.server.mapper.SaleOrderMapper;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderStatusChangeDto;
import com.jiduauto.sps.order.server.service.IPurchaseOrderService;
import com.jiduauto.sps.order.server.service.ISaleOrderOperateLogService;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.service.ISaleOrderUpdateService;
import com.jiduauto.sps.sdk.client.req.AsnUpdateReq;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.PurchaseModeEnum;
import com.jiduauto.sps.sdk.enums.RequirementTypeEnum;
import com.jiduauto.sps.sdk.enums.SaleOrderStatusEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.AsnPartReceiveInfoDto;
import com.jiduauto.sps.sdk.pojo.dto.AsnReceivePartParam;
import com.jiduauto.sps.sdk.pojo.po.AsnBasicPo;
import com.jiduauto.sps.sdk.pojo.po.AsnDeliverInfoPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Slf4j
@Service
@AllArgsConstructor
public class SaleOrderUpdateServiceImpl implements ISaleOrderUpdateService {

    private final SaleOrderMapper saleOrderMapper;

    private final SaleOrderDetailMapper saleOrderDetailMapper;

    private final ISaleOrderService saleOrderService;

    private final IPurchaseOrderService purchaseOrderService;

    private final ISaleOrderOperateLogService saleOrderOperateLogService;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateReceiveInfoByASN(AsnUpdateReq asnUpdateReq) {

        Set<String> needUpdateStateSoOrderNoSet = new HashSet<>();
        List<String> needUpdateStatePoOrderNoList = new ArrayList<>();

        //部分收货
        Map<String, AsnDeliverInfoPo> asnDeliverInfoPoReceiveMap = asnUpdateReq.getAsnDeliverInfoPoReceiveMap();
        Map<String, AsnReceivePartParam> asnPartReceiveInfoParamReceiveMap = asnUpdateReq.getAsnPartReceiveInfoParamReceiveMap();
        asnPartReceiveInfoParamReceiveMap.forEach((k, v) -> {
            AsnDeliverInfoPo asnDeliverInfoPo = asnDeliverInfoPoReceiveMap.get(k);
            needUpdateStatePoOrderNoList.add(asnDeliverInfoPo.getPurchaseOrderNo());
            String saleOrderNo = increaseReceivedQtyForDfs(asnUpdateReq.getAsnBasicPo(), asnDeliverInfoPo, v);
            if (StrUtil.isNotEmpty(saleOrderNo)) {
                needUpdateStateSoOrderNoSet.add(saleOrderNo);
            }
        });

        //欠收
        Map<String, AsnDeliverInfoPo> asnDeliverInfoPoReduceMap = asnUpdateReq.getAsnDeliverInfoPoReduceMap();
        asnUpdateReq.getAsnPartReceiveInfoDtoReduceMap().forEach((k, v) -> {
            AsnDeliverInfoPo asnDeliverInfoPo = asnDeliverInfoPoReduceMap.get(k);
            decreaseDeliveryQtyForDfs(asnUpdateReq.getAsnBasicPo(), asnDeliverInfoPo, v);
        });


        //所有明细都已更新数量后，再更新销售订单状态  防止重复更新订单状态
        updateSaleOrderState(needUpdateStateSoOrderNoSet, asnUpdateReq.getAsnBasicPo().getAsnCode());

        // 更新采购订单状态
        if (CollUtil.isNotEmpty(needUpdateStatePoOrderNoList)) {
            needUpdateStatePoOrderNoList.stream().filter(StrUtil::isNotBlank).forEach(no ->
                    purchaseOrderService.updateStateByReceiveQtyAndCancelQty(no, asnUpdateReq.getAsnBasicPo().getBizType())
            );
        }
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void increaseDeliveryQtyForDfs(AsnBasicPo asnBasicPo, List<AsnDeliverInfoPo> asnDeliverInfoPos) {

        Map<String, SaleOrderPo> soMap = new HashMap<>();

        for (AsnDeliverInfoPo asnDeliverInfoPo : asnDeliverInfoPos) {
            if (!dfsRequirementType(asnBasicPo) || asnDeliverInfoPo.getDeliveryQty() == 0) {
                return;
            }
            SaleOrderPo saleOrderPo = saleOrderMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class)
                    .eq(SaleOrderPo::getSaleOrderNo, asnDeliverInfoPo.getSaleOrderNo()));
            if (Objects.isNull(saleOrderPo)) {
                throw new BizException("销售订单不存在" + asnDeliverInfoPo.getSaleOrderNo());
            }
            SaleOrderDetailPo saleOrderDetailPo = saleOrderDetailMapper.selectOne(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                    .eq(SaleOrderDetailPo::getSaleOrderNo, asnDeliverInfoPo.getSaleOrderNo())
                    .eq(SaleOrderDetailPo::getSalePartNum, asnDeliverInfoPo.getSalePartNum()));
            if (Objects.isNull(saleOrderDetailPo)) {
                throw new BizException("销售订单明细不存在" + asnDeliverInfoPo.getSaleOrderNo());
            }
            BigDecimal deliverQty = BigDecimal.valueOf(asnDeliverInfoPo.getDeliveryQty())
                    .add(Objects.isNull(saleOrderDetailPo.getDeliverQty()) ? BigDecimal.ZERO : saleOrderDetailPo.getDeliverQty());
            if (deliverQty.compareTo(saleOrderDetailPo.getQty()) > 0) {
                throw new BizException("物料" + saleOrderDetailPo.getSalePartNum() + "发货数量大于订单数量");
            }
            updateDeliverQty(saleOrderDetailPo, deliverQty);

            soMap.put(asnDeliverInfoPo.getSaleOrderNo(), saleOrderPo);
        }

        //过滤重复的 asnDeliverInfoPos ,
        soMap.values().forEach(saleOrderPo -> {
            if (SaleOrderStatusEnum.PENDING_DELIVERY.getCode().equals(saleOrderPo.getSaleOrderStatus())) {
                saleOrderService.updateStatusAndSendMessage(SaleOrderStatusChangeDto.builder()
                        .saleOrderPo(saleOrderPo)
                        .newStatusEnum(SaleOrderStatusEnum.DELIVERED)
                        .operateEnum(OperateEnum.ASN_DELIVERED)
                        .operateUser(asnBasicPo.getAsnCode())
                        .build());
            } else if (SaleOrderStatusEnum.DELIVERED.getCode().equals(saleOrderPo.getSaleOrderStatus())
                    || SaleOrderStatusEnum.PARTIALLY_RECEIVED.getCode().equals(saleOrderPo.getSaleOrderStatus())
            ) {
                // 存在多次发货或者部分收货后再次发货的情况, 此时只记录日志, 不改变状态
                saleOrderOperateLogService.saveStatusChangeLog(SaleOrderStatusChangeDto.builder()
                        .saleOrderPo(saleOrderPo)
                        .newStatusEnum(SaleOrderStatusEnum.getByCode(saleOrderPo.getSaleOrderStatus()))
                        .operateEnum(OperateEnum.ASN_DELIVERED)
                        .operateUser(asnBasicPo.getAsnCode())
                        .build());
            }
        });
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void decreaseDeliveryQtyForDfs(AsnBasicPo asnBasicPo, List<AsnDeliverInfoPo> asnDeliverInfoPos) {
        for (AsnDeliverInfoPo asnDeliverInfoPo : asnDeliverInfoPos) {
            if (!dfsRequirementType(asnBasicPo) || asnDeliverInfoPo.getDeliveryQty() == 0) {
                return;
            }
            SaleOrderDetailPo saleOrderDetailPo = saleOrderDetailMapper.selectOne(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                    .eq(SaleOrderDetailPo::getSaleOrderNo, asnDeliverInfoPo.getSaleOrderNo())
                    .eq(SaleOrderDetailPo::getSalePartNum, asnDeliverInfoPo.getSalePartNum()));
            if (Objects.isNull(saleOrderDetailPo) || Objects.isNull(saleOrderDetailPo.getDeliverQty())) {
                log.warn("SaleOrderUpdateServiceImpl#deleteUpdateSaleOrderDeliveryQty saleOrderDetailPo is null, param: {}", JsonUtil.ObjectToJson(asnDeliverInfoPo));
                return;
            }
            BigDecimal deliverQty = saleOrderDetailPo.getDeliverQty().subtract(BigDecimal.valueOf(asnDeliverInfoPo.getDeliveryQty()));
            updateDeliverQty(saleOrderDetailPo, deliverQty);
        }

    }

    /**
     * @return 待更改状态的 SO 单号
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String increaseReceivedQtyForDfs(AsnBasicPo asnBasicPo, AsnDeliverInfoPo asnDeliverInfoPo, AsnReceivePartParam asnReceivePartParam) {
        if (!dfsRequirementType(asnBasicPo) || defaultInt(asnReceivePartParam.getReceivedQty()) == 0) {
            return null;
        }
        SaleOrderPo saleOrderPo = saleOrderMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class)
                .eq(SaleOrderPo::getSaleOrderNo, asnDeliverInfoPo.getSaleOrderNo()));
        if (Objects.isNull(saleOrderPo)) {
            throw new BizException("销售订单不存在" + asnDeliverInfoPo.getSaleOrderNo());
        }
        SaleOrderDetailPo saleOrderDetailPo = saleOrderDetailMapper.selectOne(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                .eq(SaleOrderDetailPo::getSaleOrderNo, asnDeliverInfoPo.getSaleOrderNo())
                .eq(SaleOrderDetailPo::getSalePartNum, asnDeliverInfoPo.getSalePartNum()));
        if (Objects.isNull(saleOrderDetailPo)) {
            throw new BizException("销售订单明细不存在" + asnDeliverInfoPo.getSaleOrderNo());
        }
        BigDecimal receiveQty = BigDecimal.valueOf(asnReceivePartParam.getReceivedQty())
                .add(Objects.isNull(saleOrderDetailPo.getReceiveQty()) ? BigDecimal.ZERO : saleOrderDetailPo.getReceiveQty());
        int row = saleOrderDetailMapper.update(null, Wrappers.lambdaUpdate(SaleOrderDetailPo.class)
                .set(SaleOrderDetailPo::getReceiveQty, receiveQty)
                .eq(SaleOrderDetailPo::getId, saleOrderDetailPo.getId())
                .eq(Objects.nonNull(saleOrderDetailPo.getReceiveQty()), SaleOrderDetailPo::getReceiveQty, saleOrderDetailPo.getReceiveQty()));
        if (row == 0) {
            throw new BizException("销售订单已更新，请稍稍再试");
        }

        return saleOrderPo.getSaleOrderNo();
    }

    /**
     * 更新销售订单状态
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateSaleOrderState(Set<String> set, String asnCode) {

        if (CollUtil.isEmpty(set)) {
            return;
        }
        for (String saleOrderNo : set) {
            //increaseReceivedQtyForDfs 方法已校验所有数据, 此处不必重复校验
            SaleOrderPo saleOrderPo = saleOrderMapper.selectOne(Wrappers.lambdaQuery(SaleOrderPo.class)
                    .eq(SaleOrderPo::getSaleOrderNo, saleOrderNo));

            if (SaleOrderStatusEnum.DELIVERED.getCode().equals(saleOrderPo.getSaleOrderStatus())
                    || SaleOrderStatusEnum.PARTIALLY_RECEIVED.getCode().equals(saleOrderPo.getSaleOrderStatus())) {
                SaleOrderStatusEnum newSaleOrderStatus = computeOrderStatus(saleOrderPo.getSaleOrderNo());
                SaleOrderStatusChangeDto dto = SaleOrderStatusChangeDto.builder()
                        .saleOrderPo(saleOrderPo)
                        .newStatusEnum(newSaleOrderStatus)
                        .operateEnum(OperateEnum.ASN_RECEIVED)
                        .operateUser(asnCode)
                        .build();
                // 多次收货 不变更状态, 只记录日志
                if (newSaleOrderStatus.getCode().equals(saleOrderPo.getSaleOrderStatus())) {
                    saleOrderOperateLogService.saveStatusChangeLog(dto);
                }
                saleOrderService.updateStatusAndSendMessage(dto);
            }
        }
    }
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void decreaseDeliveryQtyForDfs(AsnBasicPo asnBasicPo, AsnDeliverInfoPo asnDeliverInfoPo, AsnPartReceiveInfoDto asnPartReceiveInfoDto) {
        if (!dfsRequirementType(asnBasicPo) || defaultInt(asnPartReceiveInfoDto.getUnreceivedQty()) == 0) {
            return;
        }

        SaleOrderDetailPo saleOrderDetailPo = saleOrderDetailMapper.selectOne(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                .eq(SaleOrderDetailPo::getSaleOrderNo, asnDeliverInfoPo.getSaleOrderNo())
                .eq(SaleOrderDetailPo::getSalePartNum, asnDeliverInfoPo.getSalePartNum()));
        if (Objects.isNull(saleOrderDetailPo) || Objects.isNull(saleOrderDetailPo.getDeliverQty())) {
            log.warn("SaleOrderUpdateServiceImpl#decreaseDeliveryQtyForDfs saleOrderDetailPo is null, param: {}", JsonUtil.ObjectToJson(asnDeliverInfoPo));
            return;
        }
        BigDecimal deliverQty = saleOrderDetailPo.getDeliverQty().subtract(BigDecimal.valueOf(asnPartReceiveInfoDto.getUnreceivedQty()));
        updateDeliverQty(saleOrderDetailPo, deliverQty);
    }

    private void updateDeliverQty(SaleOrderDetailPo saleOrderDetailPo, BigDecimal deliverQty) {
        int row = saleOrderDetailMapper.update(null, Wrappers.lambdaUpdate(SaleOrderDetailPo.class)
                .set(SaleOrderDetailPo::getDeliverQty, deliverQty)
                .eq(SaleOrderDetailPo::getId, saleOrderDetailPo.getId())
                .eq(Objects.nonNull(saleOrderDetailPo.getDeliverQty()), SaleOrderDetailPo::getDeliverQty, saleOrderDetailPo.getDeliverQty()));
        if (row == 0) {
            throw new BizException("销售订单已更新，请稍稍再试");
        }
    }

    private SaleOrderStatusEnum computeOrderStatus(String saleOrderNo){
        List<SaleOrderDetailPo> saleOrderDetailPos = saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                .eq(SaleOrderDetailPo::getSaleOrderNo, saleOrderNo));
        for (SaleOrderDetailPo saleOrderDetailPo : saleOrderDetailPos) {
            if(saleOrderDetailPo.getQty().compareTo(saleOrderDetailPo.getReceiveQty()) > 0){
                return SaleOrderStatusEnum.PARTIALLY_RECEIVED;
            }
        }
        return SaleOrderStatusEnum.FULLY_RECEIVED;
    }

    private boolean dfsRequirementType(AsnBasicPo asnBasicPo) {
        return PurchaseModeEnum.F.getCode().equals(asnBasicPo.getAsnType()) && RequirementTypeEnum.DFS.getCode().equals(asnBasicPo.getRequirementType());
    }

    private int defaultInt(Integer integer) {
        return Objects.isNull(integer) ? 0 : integer;
    }
}
