package com.jiduauto.sps.order.server.client.req;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.jiduauto.sps.sdk.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeAttachDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import lombok.Data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 内领出库结果同步SRM
 */
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)

public class IndirectWDApplyOrderPutOutReq implements Serializable {
    /**
     * 表头
     */
    private Header data;

    /**
     * 明细
     */
    private List<Item> dataLine;
    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class Header{
        /**
         *SRM内领订单号
         */
        private String orderCode;
        /**
         * 精品传JC
         * 能源传ES
         * 零附件传SP
         * 工服传CL
         */
        private String businessType;
        /**
         * SPS内领单号
         */
        private String receiptCode;

        /**
         *领用公司编码，如：2000
         */
        private String companyCode;

        /**
         *被领用公司编码，如：6000
         */
        private String supplierCompanyCode;

        /**
         *默认SPS
         */
        private String cecFromCode;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class Item{
        private String lineNum;
        private String itemCode;

        private String quantity;
    }

    public static IndirectWDApplyOrderPutOutReq newInstance(){

        IndirectWDApplyOrderPutOutReq instance = new IndirectWDApplyOrderPutOutReq();
        instance.data = new Header();
        instance.dataLine = new ArrayList<>();
        return instance;
    }

    public  IndirectWDApplyOrderPutOutReq setHeaderContent(WarehouseDistributeOrderPo po, WarehouseDistributeAttachDto attachPo){
        data.businessType = po.getBizType();
        data.orderCode = cutOrderCodeSuffix(po.getBusinessBillNo());
        data.cecFromCode = "SPS";
        data.companyCode = attachPo.getApplyCompany();
        data.supplierCompanyCode = attachPo.getBeAppliedCompany();
        data.receiptCode = po.getOrderNo();
        return this;
    }

    public IndirectWDApplyOrderPutOutReq setItemList(InAndOutStockRequest request){
        List<Item> itemList = new ArrayList<>();
        for(InAndOutStockParam param:request.getParams()){
            Item item = new Item();
            item.setItemCode(param.getMaterialCode());
            item.setLineNum(param.getColumnNo());
            item.setQuantity(param.getSumQuantity().toString());
            itemList.add(item);
        }
        dataLine = itemList;
        return this;
    }


    /**
     * 拆单的话 子单 SRM会传递后缀过来， 同步接续需要去除后缀处理
     *
     * @param orderCode
     * @return
     */
    private String cutOrderCodeSuffix(String orderCode){
        if(orderCode.indexOf("-") > 0){
            return orderCode.substring(0, orderCode.indexOf("-"));
        }
        return orderCode;
    }
}
