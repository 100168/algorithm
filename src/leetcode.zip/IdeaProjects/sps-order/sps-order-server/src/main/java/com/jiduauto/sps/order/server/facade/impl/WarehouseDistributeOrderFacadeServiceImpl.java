package com.jiduauto.sps.order.server.facade.impl;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.convertor.WarehouseDistributeItemAttachConvertor;
import com.jiduauto.sps.order.server.convertor.WarehouseDistributeLogisticConvertor;
import com.jiduauto.sps.order.server.convertor.WarehouseDistributeOrderAttachConvertor;
import com.jiduauto.sps.order.server.facade.WarehouseDistributeOrderFacadeService;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.*;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeItemReq;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderReq;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.order.server.utils.AESUtil;
import com.jiduauto.sps.order.server.utils.GenerateSerialNoUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.GenerateSerialEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderlogisticTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.order.server.pojo.vo.resp.WarehouseDistributeOrderAddResp;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderStatusEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@Slf4j
public class WarehouseDistributeOrderFacadeServiceImpl implements WarehouseDistributeOrderFacadeService {

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private IWarehouseDistributeAttachService warehouseDistributeAttachService;

    @Resource
    private IWarehouseDistributeLogisticService warehouseDistributeLogisticService;

    @Resource
    private IWarehouseDistributeItemAttachService warehouseDistributeItemAttachService;

    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private RedissonClient redissonClient;


    @Resource
    private GenerateSerialNoUtil generateSerialNoUtil;

    @Resource
    private StockInMapBusinessHandler stockInMapBusinessHandler;

    @Resource
    private IWarehouseDistributeItemService warehouseDistributeItemService;


    @Resource
    private WarehouseDistributeItemAttachConvertor warehouseDistributeItemAttachConvertor;

    @Resource
    private WarehouseDistributeOrderAttachConvertor warehouseDistributeOrderAttachConvertor;

    @Resource
    private WarehouseDistributeLogisticConvertor warehouseDistributeLogisticConvertor;

    @Resource
    private AESUtil aesUtil;


    /**
     * 仓配订单保存
     *
     * @see WarehouseDistributeOrderTypeEnum
     * @see WDJobIndexEnum
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public WarehouseDistributeOrderAddResp add(WarehouseDistributeOrderAddReq req) {
        WarehouseDistributeOrderReq head = req.getHead();
        //先判断数据是否已经存在，如果存在则返回订单号
        WarehouseDistributeOrderPo orderPo = warehouseDistributeOrderService.getByBusinessBillOrderNo(head.getBizType(), head.getBusinessBillNo());
        if (Objects.nonNull(orderPo)) {
            return WarehouseDistributeOrderAddResp
                    .builder()
                    .orderNo(orderPo.getOrderNo())
                    .logisticNo(orderPo.getLogisticNo())
                    .build();
        }
        head.setOrderNo(generateSerialNoUtil.generateEncodeOrderNoPreBiz(GenerateSerialEnum.JO, head.getBizType()));
        //数据保存
        WarehouseDistributeOrderAllPo allPo = warehouseDistributeOrderService.add(req, true);


        WarehouseDistributeOrderTypeEnum distributeOrderType = WarehouseDistributeOrderTypeEnum.getByType(head.getOrderType());
        if (Objects.isNull(distributeOrderType)) {
            throw new BizException("仓配订单类型不存在");
        }
        WarehouseDistributeOrderPo distributeOrderPo = allPo.getWarehouseDistributeOrderPo();

        //内领订单直接返回
        if (WarehouseDistributeOrderTypeEnum.isApplyOrder(distributeOrderType.getValue())) {
            return WarehouseDistributeOrderAddResp
                    .builder()
                    .orderNo(distributeOrderPo.getOrderNo())
                    .logisticNo(distributeOrderPo.getLogisticNo())
                    .build();
        }
        //获取当前订单类型需要执行的接口
        Integer jobIndex = wdOrderJobContext.getJobIndex(distributeOrderType);
        while (jobIndex > 0) {
            //获取最右边的二进制位
            Integer lowBit = lowBit(jobIndex);
            WDOrderJobHandler wdOrderJobHandler = wdOrderJobContext.getSyncHandler(lowBit);
            wdOrderJobHandler.process(allPo);
            //减去最右边的1
            jobIndex -= lowBit;
        }


        Integer logisticType = Integer.valueOf(distributeOrderPo.getLogisticType());
        //仓配类型为入库+运输&调拨
        if (logisticType.equals(WarehouseDistributeOrderlogisticTypeEnum.TRANSPORT_AND_PUT_IN.getValue()) || logisticType.equals(WarehouseDistributeOrderlogisticTypeEnum.STOCK_TRANSFER.getValue())) {
            stockInMapBusinessHandler.process(allPo);
        }

        //商城订单出库单默认已下发
        if (distributeOrderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM20.getValue()) && !distributeOrderPo.getIsSpecial()) {
            distributeOrderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.DELIVERED.getCode());
            warehouseDistributeOrderService.updateById(distributeOrderPo);
        }
        //QE11, QE12, SP18, SP19订单类型需要把状态改成已下发
        if (WarehouseDistributeOrderTypeEnum.needInitStatus(head.getOrderType())) {
            distributeOrderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.DELIVERED.getCode());
            if (WarehouseDistributeOrderTypeEnum.SM30.getValue().equals(distributeOrderPo.getOrderType())) {
                distributeOrderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.SHIPPED.getCode());
            }
            warehouseDistributeOrderService.updateById(distributeOrderPo);
        }
        //返回仓配订单号和物流单号
        return WarehouseDistributeOrderAddResp
                .builder()
                .orderNo(distributeOrderPo.getOrderNo())
                .logisticNo(distributeOrderPo.getLogisticNo())
                .build();

    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void create(WarehouseDistributeOrderAddReq req) {
        WarehouseDistributeOrderReq head = req.getHead();
        int index = 1;
        for (WarehouseDistributeItemReq item : req.getItems()) {
            item.setMaterialLineNo(String.valueOf(index++));
        }
        head.setOrderNo(generateSerialNoUtil.generateEncodeOrderNoPreBiz(GenerateSerialEnum.JO, head.getBizType()));
        warehouseDistributeOrderService.add(req, false);
    }

    @Override
    public void fork(WarehouseDistributeOrderAddReq req) {

        WarehouseDistributeOrderReq head = req.getHead();
        //母单号
        String associateBillNo = head.getAssociateBillNo();
        String redisKey = String.format(BaseConstants.RedisKey.WAREHOUSE_DISTRIBUTE_ORDER_CREATE_KEY, associateBillNo, head.getBizType());
        RLock rLock = redissonClient.getLock(redisKey);

        try {
            rLock.lock();
            head.setOrderNo(generateSerialNoUtil.generateEncodeOrderNoPreBiz(GenerateSerialEnum.JO, head.getBizType()));
            WarehouseDistributeOrderPo parentOrder = warehouseDistributeOrderService.getByOrderNo(head.getBizType(), associateBillNo);
            if (parentOrder == null) {
                throw new BizException("母单号不存在");
            }
            req.setItems(req.getItems().stream().filter(e -> e.getQty().compareTo(BigDecimal.ZERO) > 0).collect(Collectors.toList()));
            List<WarehouseDistributeItemPo> parentItemPos = warehouseDistributeItemService.selectList(associateBillNo);

            if (CollUtil.isEmpty(req.getItems())) {
                throw new BizException("子单明细为空");
            }
            //判断是否跟母单完全一致
            boolean isSame = true;
            Map<String, WarehouseDistributeItemPo> parentItemPoMap = parentItemPos.stream().collect(Collectors.toMap(WarehouseDistributeItemPo::getMaterialLineNo, Function.identity()));
            for (WarehouseDistributeItemReq item : req.getItems()) {
                WarehouseDistributeItemPo parentItemPo = parentItemPoMap.get(item.getMaterialLineNo());
                if (parentItemPo == null) {
                    throw new BizException("子单零件明细不存在" + item.getMaterialLineNo());
                }
                if (parentItemPo.getQty().compareTo(item.getQty()) != 0) {
                    isSame = false;
                }
                parentItemPo.setForkedQty(parentItemPo.getForkedQty().add(item.getQty()));
                if (parentItemPo.getQty().compareTo(BigDecimal.ZERO) < 0) {
                    throw new BizException("子单出库数量大于母单可出库数量");
                }
            }
            if (isSame && req.getItems().size() == parentItemPoMap.size()) {
                throw new BizException("子单出库数量跟母单一至,请直接出母单");
            }
            List<WarehouseDistributeItemAttachPo> itemAttachPos = warehouseDistributeItemAttachService.list(Wrappers.<WarehouseDistributeItemAttachPo>lambdaQuery()
                    .in(WarehouseDistributeItemAttachPo::getMaterialLineNo, req.getItems().stream().map(WarehouseDistributeItemReq::getMaterialLineNo).collect(Collectors.toList()))
                    .eq(WarehouseDistributeItemAttachPo::getWarehouseDistributeOrderNo, associateBillNo));
            req.setItemAttaches(warehouseDistributeItemAttachConvertor.toReq(itemAttachPos));
            head.setIsChild(true);
            WarehouseDistributeAttachPo attachPo = warehouseDistributeAttachService.getOne(Wrappers.<WarehouseDistributeAttachPo>lambdaQuery().eq(WarehouseDistributeAttachPo::getWarehouseDistributeOrderNo, associateBillNo));
            WarehouseDistributeLogisticPo logisticPo = warehouseDistributeLogisticService.getByOrderNo(associateBillNo);
            aesUtil.decode(logisticPo);
            req.setAttach(warehouseDistributeOrderAttachConvertor.toReq(attachPo));
            req.setLogistic(warehouseDistributeLogisticConvertor.toReq(logisticPo));
            parentOrder.setOrderStatus(WarehouseDistributeOrderStatusEnum.FORKED.getCode());
            head.setBusinessBillNo(null);
            warehouseDistributeOrderService.fork(req, parentItemPos, parentOrder);
        } catch (Exception e) {
            log.warn("拆单异常");
            throw e;
        } finally {
            if (rLock.isHeldByCurrentThread()) {
                rLock.unlock();
            }
        }
    }


    /**
     * 找到最右边的1
     * 0000100100
     * ~=》1111011011 + 1 =》1111011100
     */
    public Integer lowBit(Integer index) {
        return index & -index;
    }

}
