package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 缺件订单返回字段
 *
 * @author dong.li01
 * @since 4/13/23 10:01 AM
 */
@Data
public class BackOrderDto {

    private Long id;

    /**
     * 缺件行号
     */
    private String backOrderNo;

    /**
     * 门店采购订单
     */
    private String purchaseOrderNo;

    /**
     * 订单类型
     */
    private String backOrderType;

    /**
     * 门店code
     */
    private String storeCode;

    /**
     * 门店名称
     */
    private String storeName;

    /**
     * 售后件号
     */
    private String salePartNum;

    /**
     * 零件名称
     */
    private String salePartName;

    /**
     * BO是否转单
     */
    private String boTransfer;

    /**
     * 缺件总数
     */
    private BigDecimal backQty;

    /**
     * 剩余缺件数量
     */
    private BigDecimal restBackQty;

    /**
     * 状态
     */
    private String backOrderStatus;

    /**
     * 状态描述
     */
    private String backOrderStatusDesc;

    /**
     * 转单备注
     */
    private String remark;

    /**
     * 创建人
     */
    private String createUser;


    /**
     * 预计到货日期
     */
    private String estArrivalTime;

    /**
     * 延期说明
     */
    private String delayExplanation;

    /**
     * BO时长 (单位: 天)
     */
    private Long boDuration;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新人
     */
    private String updateUser;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 折后单价
     */
    private BigDecimal discountUnitPrice;

    /**
     * 是否管控件
     */
    private String isControl;
    /**
     * 最小包装
     */
    private String minPackage;
}
