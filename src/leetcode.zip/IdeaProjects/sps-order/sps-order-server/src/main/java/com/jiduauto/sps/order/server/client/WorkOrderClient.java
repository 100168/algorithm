package com.jiduauto.sps.order.server.client;

import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.client.req.WorkOrderAddReq;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient(name = "work-order", url = "${feign.url.work-order}", fallbackFactory = WorkOrderClient.WorkOrderClientFallbackFactory.class)
public interface WorkOrderClient {


    @PostMapping({"/open/order/add"})
    BaseResult<List<String>> addOrder(@RequestBody WorkOrderAddReq req);

    @Slf4j
    @Component
    class WorkOrderClientFallbackFactory implements FallbackFactory<WorkOrderClient> {

        @Override
        public WorkOrderClient create(Throwable throwable) {
            return req -> {
                log.warn(String.format("WorkOrderClient#addOrder error, param: %s", JsonUtil.ObjectToJson(req)), throwable);
                return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
            };
        }
    }
}
