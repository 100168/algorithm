package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.order.server.client.ChargePartnerClient;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.convertor.AsnConvertor;
import com.jiduauto.sps.order.server.handler.WDOrderAddThreadLocalHolder;
import com.jiduauto.sps.sdk.client.req.AsnPushReq;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.SupplierPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/*
 * 下发dhl入库指令*/
@Component
public class InitSupplierHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private SpsClient spsClient;



    /*
    todo
    供应商保存
    */
    @Override
    public void process(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {
        SupplierPo supplierPo = WDOrderAddThreadLocalHolder.getObject(WDOrderAddThreadLocalHolder.SUPPLIER, SupplierPo.class);
        spsClient.createSupplier(supplierPo).check();
    }

    /*
     * 注册单前handler*/
    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.INIT_SUPPLIER.getBitIndex(), this);
    }
}
