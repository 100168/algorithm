package com.jiduauto.sps.order.server.convertor;


import cn.hutool.core.util.BooleanUtil;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.WarehouseDistributeOrderAllPo;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.client.req.TransferInToEsReq;
import com.jiduauto.sps.sdk.client.req.TransferOutToEsReq;
import com.jiduauto.sps.sdk.client.req.TransferToEsReqItem;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class EsTransferReqConvertor {


    @Resource
    private TransferToEsConvertor transferToEsConvertor;

    @Resource
    private BaseDataQuery baseDataQuery;


    public TransferOutToEsReq transferOutToEsReq(WarehouseDistributeOrderAllPo allPo) {
        WarehouseDistributeLogisticPo logisticPo = allPo.getWarehouseDistributeLogisticPo();
        List<TransferToEsReqItem> itemReq = transferToEsConvertor.toItemReq(allPo.getItems());
        TransferOutToEsReq outReq = transferToEsConvertor.toOutReq(logisticPo);
        if (allPo.getWarehouseDistributeOrderPo().getOrderType().equals(WarehouseDistributeOrderTypeEnum.ES28.getValue())) {
            outReq.setBizSource(2);
        }

        outReq.setOriAddress(logisticPo.getDeliverProvinceName() + logisticPo.getDeliverCityName() + logisticPo.getDeliverDistrictName() + logisticPo.getDeliverAddress());
        outReq.setReceiveAddress(logisticPo.getReceiveProvinceName() + logisticPo.getReceiveCityName() + logisticPo.getReceiveDistrictName() + logisticPo.getReceiveAddress());
        buildTransferReqItems(allPo, itemReq);
        outReq.setMaterialInfoList(itemReq);
        outReq.setRemark(allPo.getWarehouseDistributeOrderPo().getRemark());
        return outReq;
    }

    public TransferInToEsReq transferInToEsReq(WarehouseDistributeOrderAllPo allPo) {
        List<TransferToEsReqItem> itemReq = transferToEsConvertor.toItemReq(allPo.getItems());
        TransferInToEsReq inReq = transferToEsConvertor.toInReq(allPo.getWarehouseDistributeLogisticPo());
        buildTransferReqItems(allPo, itemReq);
        inReq.setMaterialInfoList(itemReq);
        WarehouseDistributeLogisticPo logisticPo = allPo.getWarehouseDistributeLogisticPo();
        inReq.setExpressNo(allPo.getWarehouseDistributeOrderPo().getLogisticNo());
        inReq.setOriAddress(logisticPo.getDeliverProvinceName() + logisticPo.getDeliverCityName() + logisticPo.getDeliverDistrictName() + logisticPo.getDeliverAddress());
        inReq.setReceiveAddress(logisticPo.getReceiveProvinceName() + logisticPo.getReceiveCityName() + logisticPo.getReceiveDistrictName() + logisticPo.getReceiveAddress());
        inReq.setRemark(allPo.getWarehouseDistributeOrderPo().getRemark());
        return inReq;
    }

    private void buildTransferReqItems(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo, List<TransferToEsReqItem> itemReq) {
        List<String> materialCodes = warehouseDistributeOrderAllPo.getItems().stream().map(WarehouseDistributeItemPo::getMaterialCode).collect(Collectors.toList());
        Map<String, MaterialPo> poMap = baseDataQuery.mapMaterialPo(warehouseDistributeOrderAllPo.getWarehouseDistributeLogisticPo().getBizType(), materialCodes);
        Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(DictEnum.MaterialStockStatus.getDictCode());
        for (TransferToEsReqItem item : itemReq) {
            MaterialPo materialPo = poMap.get(item.getMaterialCode());
            item.setMaterialName(materialPo.getMaterialName());
            if (BooleanUtil.toBoolean(materialPo.getAccurateTrace())) {
                item.setTraceStatus(1);
            } else {
                item.setTraceStatus(2);
            }
            item.setMaterialStatusDesc(codeAndNameMap.get(item.getMaterialStatus()));
        }
    }
}
