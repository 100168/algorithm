package com.jiduauto.sps.order.server.service.impl;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.pojo.po.OrderCalendarPo;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.apache.commons.lang.text.StrSubstitutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class OrderCalendarService {

    private final static String SPLIT_CHARACTER = "、";

    @Resource
    private WebhookUtil webhookUtil;

    @Value("${logistics.notice.webhookUrl:}")
    private String webhookUrl;

    @Resource
    private SpsClient spsClient;

    /**
     * 根据门店id, 获取最近的下次下单时间，
     * 若门店未维护订单日历，则企微提醒门店，返回 null
     */
    public Optional<LocalDateTime> recentlyIssueTime(String bizType, String storeCode) {
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setOrderCalendarCodes(Lists.newArrayList(storeCode));
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        if (CollUtil.isEmpty(ret.getData().getOrderCalendarPos())) {
            sendSyncMissingOrderCalendarNotice(bizType, storeCode);
            return Optional.empty();
        }
        OrderCalendarPo orderCalendar = ret.getData().getOrderCalendarPos().get(0);
        if (orderCalendar == null || Objects.isNull(orderCalendar.getOrderCycleType()) || StrUtil.isEmpty(orderCalendar.getOrderCycle())) {
            sendSyncMissingOrderCalendarNotice(bizType, storeCode);
            return Optional.empty();
        }
        LocalDateTime now = LocalDateTime.now();
        LocalDate currentCycleFirstDay, nextCycleFirstDay;
        int currentCycleMaxDay, nextCycleMaxDay;
        if (orderCalendar.getOrderCycleType() == 0) {   // 按周
            currentCycleFirstDay = now.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toLocalDate();
            nextCycleFirstDay = now.plusWeeks(1).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toLocalDate();
            currentCycleMaxDay = nextCycleMaxDay = 7;
        } else if (orderCalendar.getOrderCycleType() == 1) {    // 按月
            currentCycleFirstDay = now.with(TemporalAdjusters.firstDayOfMonth()).toLocalDate();
            currentCycleMaxDay = currentCycleFirstDay.with(TemporalAdjusters.lastDayOfMonth()).getDayOfMonth();
            nextCycleFirstDay = now.plusMonths(1).with(TemporalAdjusters.firstDayOfMonth()).toLocalDate();
            nextCycleMaxDay = nextCycleFirstDay.with(TemporalAdjusters.lastDayOfMonth()).getDayOfMonth();
        } else {
            return Optional.empty();
        }

        List<Integer> values = Arrays.stream(orderCalendar.getOrderCycle().split(SPLIT_CHARACTER)).filter(StrUtil::isNotEmpty).map(Integer::valueOf).distinct().sorted().collect(Collectors.toList());

        List<LocalDate> candidateLocalDateList = new ArrayList<>();
        for (Integer value : values) {
            if (value <= currentCycleMaxDay) {
                candidateLocalDateList.add(currentCycleFirstDay.plusDays(value - 1));
            }
            if (value <= nextCycleMaxDay) {
                candidateLocalDateList.add(nextCycleFirstDay.plusDays(value - 1));
            }
        }

        return candidateLocalDateList
                .stream()
                .map(item -> item.atTime(orderCalendar.getStoreReportDeadline().toLocalTime()))
                .filter(item -> !item.isBefore(LocalDateTime.now()))
                .sorted()
                .findFirst();
    }

    /**
     * 给未维护STK订单日历的门店发送企微提醒
     */
    public void sendSyncMissingOrderCalendarNotice(String bizType, String storeCode) {
        String content = "**订单发运日历未维护**\n" +
                "业务类型: <font color='comment'>${bizType}</font>\n" +
                "门店Id: <font color='comment'>${storeCode}</font>";
        Map<String, Object> contentMap = Maps.newHashMap();
        contentMap.put("storeCode", storeCode);
        contentMap.put("bizType", bizType);
        webhookUtil.sendMarkdownMessage(webhookUrl, new StrSubstitutor(contentMap).replace(content),"未维护STK订单日历的门店");
    }

}
