package com.jiduauto.sps.order.server.client;

import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.pojo.req.DHLOutboundReq;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author panjian
 */
@FeignClient(name = "cn.dit.dad.pdp-gateway.mixed",contextId = "pdpClient", fallbackFactory = PdpClient.PdpClientFallbackFactory.class)
public interface PdpClient {
    /**wms出库
     * @param outboundReq 参数
     * @return res*/
    @PostMapping("/dhl/JIDU/do")
    ResultResp<Object> outbound(DHLOutboundReq outboundReq);

    @Slf4j
    @Component
    class PdpClientFallbackFactory implements FallbackFactory<PdpClient> {

        @Override
        public PdpClient create(Throwable throwable) {
            return outboundReq -> {
                log.warn(String.format("SyncWmsClient#outbound error, param: %s", JsonUtil.ObjectToJson(outboundReq)), throwable);
                return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
            };
        }
    }
}
