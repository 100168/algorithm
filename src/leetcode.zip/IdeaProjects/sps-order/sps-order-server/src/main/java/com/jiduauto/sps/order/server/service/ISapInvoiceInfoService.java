package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.req.SapSynInvoiceReq;
import com.jiduauto.sps.sdk.pojo.po.SapInvoiceInfoPo;

/**
 * <p>
 * sap发票信息表 服务类
 * </p>
 *
 * @author generate
 * @since 2024-03-25
 */
public interface ISapInvoiceInfoService extends IService<SapInvoiceInfoPo> {

    /**
     * 接受sap同步发票信息
     */
    void synInvoice(SapSynInvoiceReq req);
}
