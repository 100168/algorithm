package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.order.server.client.ChargePartnerAuthClient;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.order.server.convertor.EsTransferReqConvertor;
import com.jiduauto.sps.sdk.client.req.TransferInToEsReq;
import com.jiduauto.sps.sdk.exception.BizException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/*
 * 下发dhl入库指令*/
@Component
public class TransferInToESHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private EsTransferReqConvertor esTransferReqConvertor;

    @Resource
    private ChargePartnerAuthClient chargePartnerAuthClient;

    /*调拨入库同步能源*/
    @Override
    public void process(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {

        TransferInToEsReq req = esTransferReqConvertor.transferInToEsReq(warehouseDistributeOrderAllPo);
        ResultResp<Object> resp = chargePartnerAuthClient.createTransferInWorkOrder(req);
        if (!resp.isSuccess()){
            throw new BizException(resp.getMsg());
        }

    }

    /*
     * 注册单前handler*/
    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.TRANSFER_IN_TO_ES.getBitIndex(), this);
    }
}
