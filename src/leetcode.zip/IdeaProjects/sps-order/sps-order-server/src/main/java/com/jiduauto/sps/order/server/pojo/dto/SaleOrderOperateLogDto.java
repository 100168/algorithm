package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 销售订单状态跟踪返回字段
 *
 * @author dong.li01
 * @since 4/17/23 4:10 PM
 */
@Data
public class SaleOrderOperateLogDto {

    /**
     * 序号
     */
    private Long id;

    /**
     * 操作
     */
    private String actionDesc;

    /**
     * 状态变更
     */
    private String newValue;

    /**
     * 转单备注
     */
    private String remark;

    /**
     * 操作用户
     */
    private String createUser;

    /**
     * 操作时间
     */
    private LocalDateTime createTime;
}
