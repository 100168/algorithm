package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeLogisticDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeLogisticReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface WarehouseDistributeLogisticConvertor {

    /**
     * to po
     * @param req req
     * @return WarehouseDistributeOrderPo
     */

    @Mapping(target = "warehouseDistributeOrderNo", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "iv", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    WarehouseDistributeLogisticPo toPo(WarehouseDistributeLogisticReq req);
    @Mapping(target = "shippingMethodName", ignore = true)
    @Mapping(target = "receiveUni", ignore = true)
    @Mapping(target = "logisticNo", ignore = true)
    @Mapping(target = "deliverUni", ignore = true)
    WarehouseDistributeLogisticDto toDto(WarehouseDistributeLogisticPo po);


    @Mapping(target = "logisticNo", ignore = true)
    WarehouseDistributeLogisticReq toReq(WarehouseDistributeLogisticPo po);
}
