package com.jiduauto.sps.order.server.convertor;


import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.track.api.vo.req.BillIntoReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface BillIntoReqConvertor {

    String operate = "NEW";
    String statusDesc = "订单创建";
    String country = "中国";
    String exp = "快递";
    @Mapping(target = "isSubscribe", expression = "java(1)")
    @Mapping(target = "transportType", expression = "java(BillIntoReqConvertor.exp)")
    @Mapping(target = "trackTime", source = "orderPo.orderTime")
    @Mapping(target = "trackDesc", expression = "java(BillIntoReqConvertor.statusDesc)")
    @Mapping(target = "totalWeight", ignore = true)
    @Mapping(target = "totalVolume", ignore = true)
    @Mapping(target = "totalQuantity", ignore = true)
    @Mapping(target = "supplierCode", source = "logisticPo.logisticCompany")
    @Mapping(target = "supplier", ignore = true)
    @Mapping(target = "senderPhone", source = "logisticPo.shipperContact")
    @Mapping(target = "senderAddress", source = "logisticPo.deliverAddress")
    @Mapping(target = "sender", source = "logisticPo.shipper")
    @Mapping(target = "sendProvince", source = "logisticPo.deliverProvinceName")
    @Mapping(target = "sendCountry", expression = "java(BillIntoReqConvertor.country)")
    @Mapping(target = "sendCity", source = "logisticPo.deliverCityName")
    @Mapping(target = "sendArea", source = "logisticPo.deliverDistrictName")
    @Mapping(target = "receiverPhone", source = "logisticPo.receiverContact")
    @Mapping(target = "receiverAddress", source = "logisticPo.receiveAddress")
    @Mapping(target = "receiveProvince", source = "logisticPo.receiveProvinceName")
    @Mapping(target = "receiveCountry",   expression = "java(BillIntoReqConvertor.country)")
    @Mapping(target = "receiveCity", source = "logisticPo.receiveCityName")
    @Mapping(target = "receiveArea", source = "logisticPo.receiveDistrictName")
    @Mapping(target = "masterBillNo", source = "orderPo.logisticNo")
    @Mapping(target = "goodsInfos", ignore = true)
    @Mapping(target = "extendInfo", ignore = true)
    @Mapping(target = "businessTypeCode", source = "orderPo.bizType")
    @Mapping(target = "businessOrderType", source = "orderPo.orderType")
    @Mapping(target = "businessOperateType", expression = "java(BillIntoReqConvertor.operate)")
    @Mapping(target = "businessNo", source = "orderPo.businessBillNo")
    @Mapping(target = "billType", expression = "java(0)")
    @Mapping(target = "billNo", source = "orderPo.logisticNo")
    BillIntoReq toReq(WarehouseDistributeLogisticPo logisticPo, WarehouseDistributeOrderPo orderPo);
}
