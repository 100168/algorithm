package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.convertor.SaleOrderDetailConvertor;
import com.jiduauto.sps.order.server.mapper.SaleOrderDetailMapper;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.order.server.service.IPurchaseOrderDetailService;
import com.jiduauto.sps.order.server.service.ISaleOrderDetailService;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 采购订单明细 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Service
public class SaleOrderDetailServiceImpl extends ServiceImpl<SaleOrderDetailMapper, SaleOrderDetailPo> implements ISaleOrderDetailService {

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private SaleOrderDetailConvertor saleOrderDetailConvertor;

    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;



    /**
     * 销售订单明细分页查询
     *
     * @author dong.li
     * @date 4/17/23 3:04 PM
     */
    @Override
    public BasePageData<SaleOrderDetailDto> pageSearch(BasePageParam<SaleOrderDetailByIdReq> pageParam) {

        Page<SaleOrderDetailPo> page = new Page<>(pageParam.getPage(), pageParam.getSize());
        SaleOrderDetailByIdReq param = pageParam.getParam();
        Page<SaleOrderDetailPo> pageSearchList = this.page(page,
                Wrappers.<SaleOrderDetailPo>lambdaQuery().eq(SaleOrderDetailPo::getBizType, param.getBizType())
                        .eq(SaleOrderDetailPo::getSaleOrderNo, param.getSaleOrderNo())
                        .eq(StringUtils.isNotBlank(param.getSalePartNum()),SaleOrderDetailPo::getSalePartNum,param.getSalePartNum())
                        .orderByAsc(SaleOrderDetailPo::getSalePartNum));
        BasePageData<SaleOrderDetailDto> res = new BasePageData<>(pageSearchList);

        List<String> saleOrderNos = new ArrayList<>();
        saleOrderNos.add(param.getSaleOrderNo());
        List<SaleOrderDetailDto> records = getSaleOrderDetailDtos(saleOrderNos,
                param.getBizType(), pageSearchList.getRecords());
        res.setRecords(records);
        return res;
    }

    private List<SaleOrderDetailDto> getSaleOrderDetailDtos(List<String> saleOrderNos, String bizType,
                                                            List<SaleOrderDetailPo> list) {
        Map<String, SaleOrderPo> saleOrderPoMap = saleOrderService.mapSaleOrderPo(saleOrderNos);
        List<String> purchaseOrderNos = saleOrderPoMap.values().stream().map(SaleOrderPo::getPurchaseOrderNo)
                .collect(Collectors.toList());
        Map<String, PurchaseOrderDetailPo> detailPoMap = purchaseOrderDetailService.getDetailPoByPos(purchaseOrderNos);
        // 获取零件信息
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(bizType,
                list.stream().map(SaleOrderDetailPo::getSalePartNum).collect(Collectors.toList()));

        return list.stream().map(e -> {
            // 设置零件名称
            SaleOrderDetailDto detailDto = saleOrderDetailConvertor.toDetailDto(e);
            MaterialPo curMaterial = materialPoMap.getOrDefault(e.getSalePartNum(), new MaterialPo());
            detailDto.setSalePartName(curMaterial.getMaterialName());
            // 设置零件销售属性
            detailDto.setPartSaleField(curMaterial.getPartSaleField());
            //获取折后单价
            SaleOrderPo saleOrderPo = saleOrderPoMap.getOrDefault(e.getSaleOrderNo(), new SaleOrderPo());
            PurchaseOrderDetailPo detailPo = detailPoMap.getOrDefault(saleOrderPo.getPurchaseOrderNo() + e.getSalePartNum(), new PurchaseOrderDetailPo());
            detailDto.setDiscountUnitPrice(detailPo.getDiscountUnitPrice().toString());
            detailDto.setStandardPriceExcludeTax(getStandardPriceExcludeTax(detailPo));
            detailDto.setStandardPriceIncludeTax(getStandardPriceIncludeTax(detailPo));
            // 设置最小包装
            detailDto.setMinPackage(curMaterial.getMinPackage());
            return detailDto;
        }).collect(Collectors.toList());
    }

    /**
     * 获取有效的 标准价格 排除 0.0 PurchaseOrderDetailPo
     */
    public static String getStandardPriceExcludeTax(PurchaseOrderDetailPo detailPo) {
        if (detailPo == null) {
            return null;
        }
        return detailPo.getStandardPriceExcludeTax().compareTo(BigDecimal.ZERO) == 0 ? "" : detailPo.getStandardPriceExcludeTax().toString();
    }

    /**
     * 获取有效的 标准价格 排除 0.0 PurchaseOrderDetailPo
     */
    public static String getStandardPriceIncludeTax(PurchaseOrderDetailPo detailPo) {
        if (detailPo == null) {
            return null;
        }
        return detailPo.getStandardPriceIncludeTax().compareTo(BigDecimal.ZERO) == 0 ? "" : detailPo.getStandardPriceIncludeTax().toString();
    }
}
