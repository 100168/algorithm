package com.jiduauto.sps.order.server.client.req;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.io.Serializable;

/**
 * 直采ASN 整单0 收货同步请求体
 */
@Configuration
@Data
public class GetInSrmTokenReq implements Serializable {

    @Value("${feign.url.indirect.grantType}")
    private String grant_type;
    @Value("${feign.url.indirect.clientId}")
    private String client_id;
    @Value("${feign.url.indirect.clientSecret}")
    private String client_secret;
    @Value("${feign.url.indirect.scope}")
    private String scope;

}
