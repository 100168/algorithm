package com.jiduauto.sps.order.server.enums;

import com.jiduauto.sps.sdk.enums.LogType;
import com.jiduauto.sps.sdk.utils.log.GeneralModifyColum;
import lombok.Getter;

import static com.jiduauto.sps.sdk.enums.LogType.FIELD;

@Getter
public enum StoreFreeTimesModifyColum implements GeneralModifyColum {

    storeCode("storeCode", "门店code"),
    orderType("orderType", "订单类型"),
    freeTimes("freeTimes", "免费次数"),
    ;
    private final String value;
    private final String desc;
    private LogType logType = FIELD;

    StoreFreeTimesModifyColum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    StoreFreeTimesModifyColum(String value, String desc, LogType logType) {
        this.value = value;
        this.desc = desc;
        this.logType = logType;
    }

    @Override
    public String getOrderNoFieldName() {
        return "id";
    }

    @Override
    public String getLogKey() {
        return LogKey.store_free_times.getValue();
    }

    @Override
    public int getLogType() {
        return this.logType.getType();
    }

    /**
     * 获取中文变更描述
     */
    public static String getByDesc(String value) {
        for (StoreFreeTimesModifyColum colum : StoreFreeTimesModifyColum.values()) {
            if (colum.getValue().equals(value)) {
                return colum.getDesc();
            }
        }
        return null;
    }
}
