package com.jiduauto.sps.order.server.service.impl;

import com.jiduauto.sps.order.server.service.IBaseDataRespCheckService;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.po.kit.KitPo;
import com.jiduauto.sps.sdk.pojo.req.AreaCheckReq;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.req.LocationCheckReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import com.jiduauto.sps.sdk.utils.StringUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @ClassName BaseDataRespCheckServiceIpml
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/11/20 16:55
 */
@Service
@RequiredArgsConstructor
public class BaseDataRespCheckServiceImpl implements IBaseDataRespCheckService {

    @Override
    public void check(BaseResult<BaseDataResp> resp, BaseDataReq req) {
        if (!resp.isSuccess()) {
            throw new BizException(resp.getMessage());
        }
        if (CollectionUtils.isNotEmpty(req.getMaterialCodes())) {
            List<String> materialCodes = req.getMaterialCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            Map<String, MaterialPo> materialMap = resp.getData().getMaterials().stream()
                    .collect(Collectors.toMap(MaterialPo::getSalePartNum, Function.identity(), (k, v) -> v));
            for (String s : materialCodes) {
                if (!materialMap.containsKey(s)) {
                    throw new BizException("该零件不存在(" + s + ")");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getSupplierCodes())) {
            List<String> supplierCodes = req.getSupplierCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            Map<String, SupplierPo> supplierPoMap = resp.getData().getSupplierPos().stream()
                    .collect(Collectors.toMap(SupplierPo::getSapCode, Function.identity(), (k, v) -> v));
            for (String s : supplierCodes) {
                if (!supplierPoMap.containsKey(s)) {
                    throw new BizException("该供应商不存在(" + s + ")");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getStoreWarehouseCodes())) {
            List<String> storeWarehouseCodes = req.getStoreWarehouseCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            Map<String, StoreWarehouseConfigPo> configPoMap = resp.getData().getStoreWarehouseConfigPos().stream()
                    .collect(Collectors.toMap(StoreWarehouseConfigPo::getStoreCode, Function.identity(), (k, v) -> v));
            for (String s : storeWarehouseCodes) {
                if (!configPoMap.containsKey(s)) {
                    throw new BizException("该门店仓库配置不存在(" + s + ")");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getOrderCalendarCodes())) {
            List<String> orderCalendarCodes = req.getOrderCalendarCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            Map<String, OrderCalendarPo> orderCalendarPoMap = resp.getData().getOrderCalendarPos().stream()
                    .collect(Collectors.toMap(OrderCalendarPo::getStoreCode, Function.identity(), (k, v) -> v));
            for (String s : orderCalendarCodes) {
                if (!orderCalendarPoMap.containsKey(s)) {
                    throw new BizException("该门店(" + s + ")不存在订单日历");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getWarehouseCodes())) {
            List<String> warehouseCodes = req.getWarehouseCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            Map<String, WarehousePo> warehousePoMap = resp.getData().getWarehouses().stream()
                    .collect(Collectors.toMap(WarehousePo::getCode, Function.identity(), (k, v) -> v));
            for (String s : warehouseCodes) {
                if (!warehousePoMap.containsKey(s)){
                    throw new BizException("该仓库不存在("+s+")");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getStoreCodes())) {
            List<String> storeCodes = req.getStoreCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            Map<String, StorePo> storePoMap = resp.getData().getStorePos().stream()
                    .collect(Collectors.toMap(StorePo::getStoreCode, Function.identity(), (k, v) -> v));
            for (String s : storeCodes) {
                if (!storePoMap.containsKey(s)){
                    throw new BizException("该门店不存在("+s+")");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getAreaCheckReqs())) {
            List<AreaCheckReq> areaCheckReqs = req.getAreaCheckReqs().stream()
                    .filter(e -> StringUtils.isNotBlank(e.getCode()) && StringUtils.isNotBlank(e.getWarehouseCode()))
                    .collect(Collectors.toList());
            Map<String, AreasPo> areasPoMap = resp.getData().getAreas().stream()
                    .collect(Collectors.toMap(e -> e.getWarehouseCode() + e.getCode(), Function.identity(),
                            (k, v) -> v));
            for (AreaCheckReq code : areaCheckReqs) {
                String key = code.getWarehouseCode() + code.getCode();
                if (!areasPoMap.containsKey(key)) {
                    throw new BizException(
                            "该仓库编码下(" + code.getWarehouseCode() + ")该区域(" + code.getCode() + ")主数据不存在");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getLocationCheckReqs())) {
            List<LocationCheckReq> locationCheckReqs = req.getLocationCheckReqs().stream()
                    .filter(e -> StringUtils.isNotBlank(e.getCode()) && StringUtils.isNotBlank(e.getWarehouseCode())
                            && StringUtils.isNotBlank(e.getAreaCode()))
                    .collect(Collectors.toList());
            Map<String, LocationsPo> locationsPoMap = resp.getData().getLocations().stream()
                    .collect(Collectors.toMap(e -> e.getWarehouseCode() + e.getAreaCode() + e.getCode(),
                            Function.identity(), (k, v) -> v));
            for (LocationCheckReq checkReq : locationCheckReqs) {
                String key = checkReq.getWarehouseCode() + checkReq.getAreaCode() + checkReq.getCode();
                if (!locationsPoMap.containsKey(key)) {
                    throw new BizException(
                            "该仓库下(" + checkReq.getWarehouseCode() + ")该区域下(" + checkReq.getAreaCode() + ")的该库位("
                                    + checkReq.getCode() + ")主数据中不存在");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getCompanyCodes())) {
            Map<String, CompanyPo> companyPoMap = resp.getData().getCompanyPos().stream()
                    .collect(Collectors.toMap(CompanyPo::getCode, Function.identity(), (k, v) -> v));
            List<String> companyCodes = req.getCompanyCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            for (String code : companyCodes) {
                if (!companyPoMap.containsKey(code)) {
                    throw new BizException("该公司(" + code + ")不存在");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getPalletCodes())) {
            Map<String, PalletPo> palletPoMap = resp.getData().getPalletPos().stream()
                    .collect(Collectors.toMap(PalletPo::getCode, Function.identity(), (k, v) -> v));
            List<String> palletCodes = req.getPalletCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            for (String code : palletCodes) {
                if (!palletPoMap.containsKey(code)) {
                    throw new BizException("该托盘(" + code + ")不存在");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getWorkbinCodes())) {
            Map<String, WorkbinPo> workbinPoMap = resp.getData().getWorkbinPos().stream()
                    .collect(Collectors.toMap(WorkbinPo::getCode, Function.identity(), (k, v) -> v));
            List<String> workbinCodes = req.getWorkbinCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            for (String code : workbinCodes) {
                if (!workbinPoMap.containsKey(code)) {
                    throw new BizException("该料箱(" + code + ")不存在");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getCarCodes())) {
            Map<String, CarPo> carPoMap = resp.getData().getCarPos().stream()
                    .collect(Collectors.toMap(CarPo::getCode, Function.identity(), (k, v) -> v));
            List<String> carCodes = req.getCarCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            for (String code : carCodes) {
                if (!carPoMap.containsKey(code)) {
                    throw new BizException("该车辆(" + code + ")不存在");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getPriceCodes())) {
            List<String> codes = resp.getData().getSalePricePos().stream().map(SalePricePo::getSalePartNum)
                    .collect(Collectors.toList());
            List<String> priceCodes = req.getPriceCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            for (String storeCode : priceCodes) {
                if (!codes.contains(storeCode)) {
                    throw new BizException("该零件(" + storeCode + ")价格查询中不存在价格");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getKitCodes())) {
            Map<String, KitPo> map = resp.getData().getKitPos().stream()
                    .collect(Collectors.toMap(KitPo::getMaterialCode, Function.identity(), (k, v) -> v));
            List<String> kitCodes = req.getKitCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            for (String code : kitCodes) {
                if (!map.containsKey(code)) {
                    throw new BizException("该kit(" + code + ")主数据中不存在");
                }
            }
        }
        if (CollectionUtils.isNotEmpty(req.getDbCodes())) {
            Map<String, DbPo> map = resp.getData().getDbPoList().stream()
                    .collect(Collectors.toMap(DbPo::getMaterialCode, Function.identity(), (k, v) -> v));
            List<String> dbCodes = req.getDbCodes().stream().filter(StringUtils::isNotBlank).collect(
                    Collectors.toList());
            for (String code : dbCodes) {
                if (!map.containsKey(code)) {
                    throw new BizException("该db件(" + code + ")主数据中不存在");
                }
            }
        }
    }


}
