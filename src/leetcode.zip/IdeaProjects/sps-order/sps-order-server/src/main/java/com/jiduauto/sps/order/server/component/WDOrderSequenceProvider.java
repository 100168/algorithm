package com.jiduauto.sps.order.server.component;

import com.jiduauto.sps.order.server.handler.WDOrderAddThreadLocalHolder;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderReq;
import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;

import java.util.ArrayList;
import java.util.List;

import static com.jiduauto.sps.order.server.component.WDOrderItemGroupSequenceProvider.getClasses;


/**
 * @author panjian
 */
public class WDOrderSequenceProvider implements DefaultGroupSequenceProvider<WarehouseDistributeOrderAddReq> {


    @Override
    public List<Class<?>> getValidationGroups(WarehouseDistributeOrderAddReq bean) {
        List<Class<?>> defaultGroupSequence = new ArrayList<>();
        defaultGroupSequence.add(WarehouseDistributeOrderAddReq.class);
        // 这块判空请务必要做
        if (bean != null) {
            WarehouseDistributeOrderReq head = bean.getHead();
            //根据订单类型校验
            WDOrderAddThreadLocalHolder.put(WDOrderAddThreadLocalHolder.ORDER_TYPE, head.getOrderType());
            //根据物流类型校验
            WDOrderAddThreadLocalHolder.put(WDOrderAddThreadLocalHolder.LOGISTIC_TYPE, head.getLogisticType());
            WDOrderAddThreadLocalHolder.put(WDOrderAddThreadLocalHolder.SOURCE_SYSTEM, head.getSourceSystem());
            if (bean.getLogistic() != null) {
                WDOrderAddThreadLocalHolder.put(WDOrderAddThreadLocalHolder.SHIPPING_METHOD, bean.getLogistic().getShippingMethod());
            }

        }
        return getClasses(defaultGroupSequence, bean != null);
    }
}
