package com.jiduauto.sps.order.server.client.resp;

import lombok.Data;

/**
 * @author panjian
 */
@Data
public class PurchaseReturnOrderSyncResp {
    private String  sappo;
    private String  messagetype;
    private String  message;
}
