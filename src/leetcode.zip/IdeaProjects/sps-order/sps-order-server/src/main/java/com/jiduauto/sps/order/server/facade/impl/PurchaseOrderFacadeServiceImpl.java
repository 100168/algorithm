package com.jiduauto.sps.order.server.facade.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.convertor.NoticedDtoConvertor;
import com.jiduauto.sps.order.server.convertor.PurchaseOrderConvertor;
import com.jiduauto.sps.order.server.convertor.PurchaseOrderDetailConvertor;
import com.jiduauto.sps.order.server.facade.PurchaseOrderFacadeService;
import com.jiduauto.sps.order.server.pojo.PurchaseOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalPurchaseOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalPurchaseOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.order.server.service.IPurchaseOrderDetailService;
import com.jiduauto.sps.order.server.service.IPurchaseOrderService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.GenerateSerialNoUtil;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.client.SAPRestAdapterClient;
import com.jiduauto.sps.sdk.client.req.PurchaseOrderSyncReq;
import com.jiduauto.sps.sdk.client.resp.PurchaseOrderSyncResp;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.pojo.po.WarehousePo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import com.jiduauto.sps.sdk.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum.*;


/**
 * @author panjian
 */
@Service
@Slf4j
public class PurchaseOrderFacadeServiceImpl implements PurchaseOrderFacadeService {

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @Resource
    private GenerateSerialNoUtil generateSerialNoUtil;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private SAPRestAdapterClient sapRestAdapterClient;

    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;

    @Resource
    private PurchaseOrderConvertor purchaseOrderConvertor;

    @Resource
    private PurchaseOrderDetailConvertor purchaseOrderDetailConvertor;

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private WebhookUtil webhookUtil;

    @Resource
    private NoticedDtoConvertor noticedDtoConvertor;


    @Override
    public BaseResult<String> internalAdd(InternalPurchaseOrderAddReq request) {

        String redisKey = String.format(BaseConstants.RedisKey.PURCHASE_ORDER_CREATE_KEY, request.getBizType(),
                request.getTradeNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            PurchaseOrderPo po = purchaseOrderService.getOne(Wrappers.<PurchaseOrderPo>lambdaQuery()
                    .eq(PurchaseOrderPo::getBizType, request.getBizType())
                    .eq(PurchaseOrderPo::getTradeNo, request.getTradeNo())
            );
            if (Objects.nonNull(po)) {
                return BaseResult.error(RECORD_EXIST, po.getPurchaseOrderNo());
            }
            purchaseOrderService.check(request);
            PurchaseOrderPo orderPo = purchaseOrderConvertor.reqToPo(request);
            orderPo.setVin(orderPo.getVin() == null ? StrUtil.EMPTY : orderPo.getVin());
            orderPo.setReceiverPhone(orderPo.getReceiverPhone() == null ? StrUtil.EMPTY : orderPo.getReceiverPhone());
            orderPo.setPurchaseOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.PO, request.getBizType()));
            orderPo.setCreateUser(request.getOperateUser());
            orderPo.setUpdateUser(request.getOperateUser());
            List<PurchaseOrderDetailPo> detailPos = build(request.getItemList(), orderPo);
            //是否存在管控件
            long existControl = detailPos.stream().filter(e -> YNEnums.Y.getCode().equals(e.getIsControl())).count();
            orderPo.setTurnControlStatus(existControl == 0L ? "" : POTurnControlStatus.PENDING.getCode());
            orderPo.setPurchaseOrderAmount(detailPos.stream().map(PurchaseOrderDetailPo::getLineAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add));
            orderPo.setPurchaseOrderStatus(PurchaseOrderStatusEnum.PENDING_REVIEW.getCode());
            purchaseOrderService.savePoAndDetail(orderPo, detailPos);
            //同步sap和发送消息
            return syncAndSendMsg(orderPo, detailPos);
        } catch (Exception e) {
            log.error("PurchaseOrderFacadeServiceImpl#internalAdd error", e);
            throw new BizException(e.getMessage());
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    @Override
    public BaseResult<String> internalCommit(InternalPoCommitReq request) {

        String redisKey = String.format(BaseConstants.RedisKey.PURCHASE_ORDER_COMMIT_KEY, request.getBizType(), request.getPurchaseOrderNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            PurchaseOrderPo orderPo = purchaseOrderService.getOne(Wrappers.<PurchaseOrderPo>lambdaQuery()
                    .eq(PurchaseOrderPo::getBizType, request.getBizType())
                    .eq(PurchaseOrderPo::getPurchaseOrderNo, request.getPurchaseOrderNo()));
            if (Objects.isNull(orderPo)) {
                throw new BizException(RECORD_NOT_EXIST);
            }
            if (!PurchaseOrderStatusEnum.canCommit(orderPo.getPurchaseOrderStatus())) {
                throw new BizException(PO_COMMIT_ERROR);
            }
            orderPo.setUpdateUser(request.getOperateUser());
            List<PurchaseOrderDetailPo> orderDetails = purchaseOrderDetailService.list(
                    Wrappers.<PurchaseOrderDetailPo>lambdaQuery()
                            .eq(PurchaseOrderDetailPo::getBizType, request.getBizType())
                            .eq(PurchaseOrderDetailPo::getPurchaseOrderNo, request.getPurchaseOrderNo()));
            return syncAndSendMsg(orderPo, orderDetails);
        } catch (Exception e) {
            log.error("PurchaseOrderFacadeServiceImpl#internalCommit error", e);
            throw new BizException(e.getMessage());
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    @Override
    public BaseResult<String> internalDelete(InternalPoDeleteReq request) {
        return purchaseOrderService.delete(request);
    }

    @Override
    public BasePageData<InternalPurchaseOrderDto> internalPageSearch(BasePageParam<InternalPoSearchReq> pageParam) {
        InternalPoSearchReq poSearchReq = pageParam.getParam();
        PurchaseOrderSearchReq purchaseOrderSearchReq = purchaseOrderConvertor.toReq(poSearchReq);
        BasePageParam<PurchaseOrderSearchReq> basePageParam = new BasePageParam<>();
        BeanUtils.copyProperties(pageParam, basePageParam);
        basePageParam.setParam(purchaseOrderSearchReq);
        BasePageData<PurchaseOrderDto> ret = purchaseOrderService.pageSearch(basePageParam);
        List<InternalPurchaseOrderDto> collect =
                ret.getRecords().stream().map(o -> BeanUtil.copyProperties(o, InternalPurchaseOrderDto.class)).collect(Collectors.toList());
        return new BasePageData<>(ret.getTotal(), ret.getSize(), ret.getCurrent(), ret.getPages(), collect);
    }

    @Override
    public BasePageData<InternalPurchaseOrderDetailDto> internalDetailPageSearch(
            BasePageParam<PurchaseOrderDetailSearchReq> pageSearchReq) {
        BasePageData<PurchaseOrderDetailDto> ret = purchaseOrderDetailService.pageSearch(pageSearchReq);
        List<InternalPurchaseOrderDetailDto> collect =
                ret.getRecords().stream().map(o -> BeanUtil.copyProperties(o, InternalPurchaseOrderDetailDto.class)).collect(Collectors.toList());
        return new BasePageData<>(ret.getTotal(), ret.getSize(), ret.getCurrent(), ret.getPages(), collect);
    }

    @Override
    public List<InternalPurchaseOrderDto> list(PurchaseOrderListSearchReq listSearchReq) {
        BasePageParam<PurchaseOrderSearchReq> pageParam = new BasePageParam<>();
        pageParam.setSize(BaseConstants.ListMaxSize.HUNDRED);
        val purchaseOrderSearchReq = new PurchaseOrderSearchReq();
        purchaseOrderSearchReq.setPurchaseOrderNos(listSearchReq.getPurchaseOrderNos());
        purchaseOrderSearchReq.setBizType(listSearchReq.getBizType());
        pageParam.setParam(purchaseOrderSearchReq);
        return purchaseOrderService.pageSearch(pageParam).getRecords()
                .stream().map(o -> BeanUtil.copyProperties(o, InternalPurchaseOrderDto.class)).collect(Collectors.toList());
    }


    private BaseResult<String> syncAndSendMsg(PurchaseOrderPo orderPo, List<PurchaseOrderDetailPo> detailPos) {
        PurchaseOrderSyncResp purchaseOrderSyncResp = syncPurchaseOrder(orderPo, detailPos);
        log.info("PurchaseOrderFacadeServiceImpl-syncAndSendMsg-purchaseOrderSyncResp:{}",
                JSONUtil.toJsonStr(purchaseOrderSyncResp));

        if (!PurchaseOrderSyncResp.success(purchaseOrderSyncResp)) {

            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, JSONUtil.toJsonStr(purchaseOrderSyncResp),
                            BaseConstants.MessageTitle.PO_CREATE_PUSH_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), BaseConstants.MessageTitle.PO_CREATE_PUSH_SAP);
            return BaseResult.error(GlobalCodeEnum.GL_FAIL_10000.getCode(),
                    JSONUtil.toJsonStr(purchaseOrderSyncResp.getMessageBody()), orderPo.getPurchaseOrderNo());
        }
        List<String> controlMaterials = getControlMaterial(detailPos);
        if(CollectionUtils.isNotEmpty(controlMaterials)){
            //管控件  需要飞书提醒
            webhookUtil.sendMarkdownMessage2Business(orderPo.getPurchaseOrderNo()+"单号，"+ JSON.toJSONString(controlMaterials)+"管控件，订单已发起","门店订单管控件提醒");
        }
        if(PurchaseOrderTypeEnum.VOR.getValue().equals(orderPo.getPurchaseOrderType())){
            //VOR订单发起  需要飞书提醒
            webhookUtil.sendMarkdownMessage2Business(orderPo.getPurchaseOrderNo()+"单号，VOR订单已发起","门店VOR订单发起提醒");
        }
        if(PurchaseOrderTypeEnum.CO.getValue().equals(orderPo.getPurchaseOrderType())){
            //CO订单发起  需要飞书提醒
            webhookUtil.sendMarkdownMessage2Business(orderPo.getPurchaseOrderNo()+"单号，CO订单已发起","门店CO订单发起提醒");
        }
        orderPo.setSapOrderNo(purchaseOrderSyncResp.getMessageBody().get(0).getHeader().getVBELN());

        orderPo.setSapOrderCreateTime(purchaseOrderSyncResp.getMessageBody().get(0).getHeader().getCreateDate());
        purchaseOrderService.updateById(orderPo);
        //同步发消息
        boolean res = purchaseOrderService.updateStatusAndSendMessage(PurchaseOrderStatusChangeDto.builder()
                .purchaseOrderPo(orderPo)
                .newOrderStatus(PurchaseOrderStatusEnum.APPROVED)
                .operateEnum(OperateEnum.COMMIT)
                .remark(StrUtil.EMPTY)
                .operateUser(orderPo.getCreateUser()).build());
        return res ? BaseResult.OK(orderPo.getPurchaseOrderNo()) : BaseResult.error(SpsResponseCodeEnum.SEND_MESSAGE_ERROR, orderPo.getPurchaseOrderNo());
    }

    @SuppressWarnings("OptionalGetWithoutIsPresent")
    public PurchaseOrderSyncResp syncPurchaseOrder(PurchaseOrderPo orderPo, List<PurchaseOrderDetailPo> detailPos) {
        PurchaseOrderSyncReq purchaseOrderSyncReq = PurchaseOrderSyncReq.newInstance();
        purchaseOrderSyncReq.setPurchaseOrder(orderPo);
        purchaseOrderSyncReq.setDetail(detailPos);
        Optional<WarehousePo> warehousePo = baseDataQuery.getWarehousePo(BizTypeEnum.getNewBizType(orderPo.getBizType()), orderPo.getReceiveWarehouseCode());
        purchaseOrderSyncReq.setWarehouse(warehousePo.get());

        log.info("PurchaseOrderFacadeServiceImpl-syncPurchaseOrder-purchaseOrderSyncReq:{}",
                JSONUtil.toJsonStr(purchaseOrderSyncReq));
        return sapRestAdapterClient.syncPurchaseOrder(purchaseOrderSyncReq);
    }

    public List<PurchaseOrderDetailPo> build(List<InternalPurchaseOrderAddReq.Item> itemList, PurchaseOrderPo orderPo) {
        List<String> salePartNums = itemList.stream().map(InternalPurchaseOrderAddReq.Item::getSalePartNum).distinct().collect(Collectors.toList());
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(orderPo.getBizType(), salePartNums);
        return itemList.stream().map(e -> {
            PurchaseOrderDetailPo detailPo = purchaseOrderDetailConvertor.reqToPo(e);
            detailPo.setPurchaseOrderNo(orderPo.getPurchaseOrderNo());
            detailPo.setStoreRemark(StringUtils.defaultIfNull(e.getStoreRemark()));
            detailPo.setBizType(orderPo.getBizType());
            detailPo.setUpdateUser("");
            detailPo.setCreateUser("");
            detailPo.setIsDfs(materialPoMap.get(e.getSalePartNum()).getIsDfs());
            //先判断是不是 dfs， 是dfs，管控件设置为 ""
            String isControl = YNEnums.Y.getCode().equals(materialPoMap.get(e.getSalePartNum()).getIsDfs())
                    ? "" : materialPoMap.get(e.getSalePartNum()).getIsControl();
            detailPo.setIsControl(isControl);
            return detailPo;
        }).collect(Collectors.toList());
    }

    private List<String> getControlMaterial(List<PurchaseOrderDetailPo> detailPos){
        return detailPos.stream().filter(e -> YNEnums.Y.getCode().equals(e.getIsControl())).map(PurchaseOrderDetailPo::getSalePartNum).collect(Collectors.toList());
    }
}
