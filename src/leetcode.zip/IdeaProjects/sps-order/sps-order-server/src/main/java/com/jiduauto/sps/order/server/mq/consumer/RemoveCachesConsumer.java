package com.jiduauto.sps.order.server.mq.consumer;

import com.jiduauto.sps.order.server.caches.WarehouseCache;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.pojo.req.JVMCachesReq;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.annotation.MessageModel;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * delete-local-cache 为指定的tag
 */
@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_5,
        topic = BaseConstants.RocketMqTopic.CACHES_DELETE,
        messageModel = MessageModel.BROADCASTING
)
public class RemoveCachesConsumer implements RocketMQListener<JVMCachesReq> {

    @Resource
    private WarehouseCache warehouseCache;

    /**
     * 接收到消息后删除对应消息的缓存(监听所有消息)
     */
    @Override
    public void onMessage(JVMCachesReq message) {
        log.info("缓存清除MQ:{}", message.toString());
        try {
            if (message.getCacheType().equals("WAREHOUSE_CACHE")) {
                warehouseCache.remove(message.getBizType(), message.getCode());
            }
        } catch (Exception e) {
            log.error("删除缓存失败", e);
        }
    }
}
