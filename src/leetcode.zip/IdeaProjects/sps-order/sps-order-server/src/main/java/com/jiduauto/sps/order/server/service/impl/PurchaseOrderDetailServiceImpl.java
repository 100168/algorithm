package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.convertor.PurchaseOrderDetailConvertor;
import com.jiduauto.sps.order.server.mapper.PurchaseOrderDetailMapper;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderDetailSearchReq;
import com.jiduauto.sps.order.server.service.IPurchaseOrderDetailService;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.YNEnums;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * <p>
 * 采购订单明细 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Service
public class PurchaseOrderDetailServiceImpl extends
        ServiceImpl<PurchaseOrderDetailMapper, PurchaseOrderDetailPo> implements IPurchaseOrderDetailService {

    @Resource
    private PurchaseOrderDetailConvertor purchaseOrderDetailConvertor;

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private PurchaseOrderDetailMapper purchaseOrderDetailMapper;

    @Override
    public BasePageData<PurchaseOrderDetailDto> pageSearch(BasePageParam<PurchaseOrderDetailSearchReq> pageSearchReq) {

        Page<PurchaseOrderDetailDto> objectPage = new Page<>(pageSearchReq.getPage(), pageSearchReq.getSize());
        objectPage.setOptimizeCountSql(false);
        IPage<PurchaseOrderDetailDto> page = purchaseOrderDetailMapper.pageSearch(objectPage, pageSearchReq.getParam());
        BasePageData<PurchaseOrderDetailDto> res = new BasePageData<>(page);
        res.setRecords(buildDetailDto(page.getRecords(), pageSearchReq.getParam().getBizType()));
        return res;
    }

    @Override
    public List<PurchaseOrderDetailDto> getDetail(PurchaseOrderDetailSearchReq req) {
        List<PurchaseOrderDetailPo> list = list(Wrappers.<PurchaseOrderDetailPo>lambdaQuery()
                .eq(PurchaseOrderDetailPo::getBizType, req.getBizType())
                .eq(StringUtils.isNotBlank(req.getSalePartNum()),PurchaseOrderDetailPo::getSalePartNum,req.getSalePartNum())
                .eq(PurchaseOrderDetailPo::getPurchaseOrderNo, req.getPurchaseOrderNo())
                .orderByAsc(PurchaseOrderDetailPo::getSalePartNum)
        );

        return buildPurchaseOrderDetailDto(list,req.getBizType()) ;
    }

    /** 获取PO单的 折后单价
     * @param purchaseOrderNos
     * @return */
    public Map<String, BigDecimal> getDiscountUnitPriceByPos(List<String> purchaseOrderNos) {
        Map<String, BigDecimal> result  = new HashMap<>();
        List<PurchaseOrderDetailPo>  detailPos = list(Wrappers.<PurchaseOrderDetailPo>lambdaQuery().in(PurchaseOrderDetailPo::getPurchaseOrderNo, purchaseOrderNos));
        for(PurchaseOrderDetailPo detailPo:detailPos){
            result.put(detailPo.getPurchaseOrderNo()+detailPo.getSalePartNum(), detailPo.getDiscountUnitPrice());
        }
        return result;
    }

    public Map<String, PurchaseOrderDetailPo> getDetailPoByPos(List<String> purchaseOrderNos) {
        Map<String, PurchaseOrderDetailPo> result = new HashMap<>();
        List<PurchaseOrderDetailPo> detailPos = list(Wrappers.<PurchaseOrderDetailPo>lambdaQuery().in(PurchaseOrderDetailPo::getPurchaseOrderNo, purchaseOrderNos));
        for (PurchaseOrderDetailPo detailPo : detailPos) {
            result.put(detailPo.getPurchaseOrderNo() + detailPo.getSalePartNum(), detailPo);
        }
        return result;
    }

    private List<PurchaseOrderDetailDto> buildDetailDto(List<PurchaseOrderDetailDto> poList, String bizType){
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(bizType,
               poList.stream().map(PurchaseOrderDetailDto::getSalePartNum).collect(Collectors.toList()));

        return poList.stream().map(e->{
            PurchaseOrderDetailDto dto = BeanUtil.copyProperties(e, PurchaseOrderDetailDto.class);
            MaterialPo materialPo = Optional.ofNullable(materialPoMap.get(e.getSalePartNum())).orElse(new MaterialPo());
            dto.setMinPackage(materialPo.getMinPackage());
            dto.setSalePartName(materialPo.getMaterialName());
            dto.setIsControl(YNEnums.getValue(dto.getIsControl()));
            //0.00 代表不存在该数据, 不展示
            dto.setStandardPriceExcludeTax("0.00".equals(dto.getStandardPriceExcludeTax()) ? "" : dto.getStandardPriceExcludeTax());
            dto.setStandardPriceIncludeTax("0.00".equals(dto.getStandardPriceIncludeTax()) ? "" : dto.getStandardPriceIncludeTax());
            dto.setDiscountRate("0.00".equals(dto.getDiscountRate()) ? "" : dto.getDiscountRate());
            return dto;
        }).collect(Collectors.toList());
    }


    private List<PurchaseOrderDetailDto> buildPurchaseOrderDetailDto(List<PurchaseOrderDetailPo> poList, String bizType) {
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(bizType,
                poList.stream().map(PurchaseOrderDetailPo::getSalePartNum).collect(Collectors.toList()));

        return poList.stream().map(e -> {
            PurchaseOrderDetailDto dto = purchaseOrderDetailConvertor.poToDto(e);
            MaterialPo materialPo = Optional.ofNullable(materialPoMap.get(e.getSalePartNum())).orElse(new MaterialPo());
            dto.setMinPackage(materialPo.getMinPackage());
            dto.setSalePartName(materialPo.getMaterialName());
            //0.00 代表不存在该数据, 不展示
            dto.setStandardPriceExcludeTax("0.00".equals(dto.getStandardPriceExcludeTax()) ? "" : dto.getStandardPriceExcludeTax());
            dto.setStandardPriceIncludeTax("0.00".equals(dto.getStandardPriceIncludeTax()) ? "" : dto.getStandardPriceIncludeTax());
            dto.setDiscountRate("0.00".equals(dto.getDiscountRate()) ? "" : dto.getDiscountRate());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public Map<String, PurchaseOrderDetailPo> mapPurchaseOrderDetail(String purchaseOrderNo) {
        return list(Wrappers.<PurchaseOrderDetailPo>lambdaQuery().eq(PurchaseOrderDetailPo::getPurchaseOrderNo, purchaseOrderNo))
                .stream()
                .collect(Collectors.toMap(PurchaseOrderDetailPo::getSalePartNum, Function.identity(), (p, n) -> n));
    }

    /**
     * 查询 SO单对应的PO单 明细中 每个物料的 折后单价
     */
    @Override
    public Map<String, BigDecimal> getDiscountUnitPrice(List<String> soOrderNo) {
        List<SaleOrderPo> list =  saleOrderService.list(Wrappers.<SaleOrderPo>lambdaQuery().in(SaleOrderPo::getSaleOrderNo, soOrderNo));
        List<String> poList = new ArrayList<>();
        Map<String, List<String>> poSoMap = new HashMap<>();
        for(SaleOrderPo saleOrderPo:list){
            poList.add(saleOrderPo.getPurchaseOrderNo());
            List<String> temp = poSoMap.get(saleOrderPo.getPurchaseOrderNo());
            if(temp == null){
                //多个SO查询时， 可能属于同一个PO
                temp = new ArrayList<>();
                temp.add(saleOrderPo.getSaleOrderNo());
                poSoMap.put(saleOrderPo.getPurchaseOrderNo(), temp);
            }else{
                temp.add(saleOrderPo.getSaleOrderNo());
            }
        }
        Map<String, BigDecimal> result  = new HashMap<>();
        List<PurchaseOrderDetailPo>  detailPos = list(Wrappers.<PurchaseOrderDetailPo>lambdaQuery().in(PurchaseOrderDetailPo::getPurchaseOrderNo, poList));
        for(PurchaseOrderDetailPo detailPo:detailPos){
            List<String> temp = poSoMap.get(detailPo.getPurchaseOrderNo());
            for(String soNo:temp){
                result.put(soNo+detailPo.getSalePartNum(), detailPo.getDiscountUnitPrice());
            }
        }
        return result;
    }
}
