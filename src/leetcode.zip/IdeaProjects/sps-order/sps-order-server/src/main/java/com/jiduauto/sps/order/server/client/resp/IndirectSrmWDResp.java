package com.jiduauto.sps.order.server.client.resp;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class IndirectSrmWDResp {

    private String receiptCode;
    /**
     * success   error
     */
    private String receiptResult;

    private String resultMessage;

    private String resultCode;

//    private String receiptEntryVOS;

    public  boolean isSuccess() {
        if( this.receiptResult != null && this.receiptResult.equalsIgnoreCase("success")){
            return true;
        }
        if( this.receiptResult != null
                && this.receiptResult.equalsIgnoreCase("error")
                && this.resultCode != null &&
                this.resultCode.equalsIgnoreCase("9001")){
            //超时 或者其他原因 重复提交，SRM 已经处理成功
            return true;
        }
        return false;
    }


    public static List<IndirectSrmWDResp> failure(String message) {

        ArrayList<IndirectSrmWDResp> respList = new ArrayList<>();
        IndirectSrmWDResp resp = new IndirectSrmWDResp();
        resp.setResultMessage(message);
        resp.setReceiptResult("error");
        respList.add(resp);
        return respList;
    }
}
