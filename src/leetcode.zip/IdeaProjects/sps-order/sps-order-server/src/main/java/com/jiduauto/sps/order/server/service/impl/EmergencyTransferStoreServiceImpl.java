package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.excel.EmergencyTransferStoreImportHandler;
import com.jiduauto.sps.order.server.mapper.EmergencyTransferStoreMapper;
import com.jiduauto.sps.order.server.pojo.dto.EmergencyTransferStoreDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalEmergencyTransferStoreDto;
import com.jiduauto.sps.order.server.pojo.po.EmergencyTransferStorePo;
import com.jiduauto.sps.order.server.pojo.vo.req.EmergencyTransferStoreImportReq;
import com.jiduauto.sps.order.server.pojo.vo.req.EmergencyTransferStoreSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalEmergencyTransferStoreReq;
import com.jiduauto.sps.order.server.service.IEmergencyTransferStoreService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 应急调拨门店 服务实现类
 * </p>
 *
 * @author generate
 * @since 2024-11-04
 */
@Service
public class EmergencyTransferStoreServiceImpl extends ServiceImpl<EmergencyTransferStoreMapper, EmergencyTransferStorePo> implements IEmergencyTransferStoreService {

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private EmergencyTransferStoreImportHandler emergencyTransferStoreImportHandler;

    @Override
    public BasePageData<EmergencyTransferStoreDto> pageSearch(BasePageParam<EmergencyTransferStoreSearchReq> pageParam) {
        EmergencyTransferStoreSearchReq req = pageParam.getParam();
        IPage<EmergencyTransferStorePo> page = page(new Page<>(pageParam.getPage(), pageParam.getSize()),
                Wrappers.lambdaQuery(EmergencyTransferStorePo.class)
                        .eq(EmergencyTransferStorePo::getBizType, req.getBizType())
                        .in(CollUtil.isNotEmpty(req.getStoreCodeList()), EmergencyTransferStorePo::getStoreCode, req.getStoreCodeList())
        );
        if (CollUtil.isEmpty(page.getRecords())) {
            return new BasePageData<>(page);
        }
        BasePageData<EmergencyTransferStoreDto> pageData = new BasePageData<>(page);

        List<String> storeCodeList = page.getRecords().stream().map(EmergencyTransferStorePo::getStoreCode).distinct().collect(Collectors.toList());
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(req.getBizType(), storeCodeList);

        List<EmergencyTransferStoreDto> dtoList = page.getRecords().stream().map(item -> {
            EmergencyTransferStoreDto dto = BeanCopierUtil.copy(item, EmergencyTransferStoreDto.class);
            dto.setStoreName(storePoMap.getOrDefault(item.getStoreCode(), new StorePo()).getStoreName());
            return dto;
        }).collect(Collectors.toList());
        pageData.setRecords(dtoList);
        return pageData;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ImportResultResp importExcel(String bizType, MultipartFile file) {
        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        ImportReturnDataInfo<ExtendExportDto<EmergencyTransferStoreImportReq>> resp = emergencyTransferStoreImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return resultResp;
    }

    @Override
    public List<InternalEmergencyTransferStoreDto> internalSearch(InternalEmergencyTransferStoreReq req) {
        BasePageParam<EmergencyTransferStoreSearchReq> basePageParam = new BasePageParam<>();
        basePageParam.setPage(1);
        basePageParam.setSize(Integer.MAX_VALUE);
        EmergencyTransferStoreSearchReq tempReq = BeanUtil.copyProperties(req, EmergencyTransferStoreSearchReq.class);
        basePageParam.setParam(tempReq);
        BasePageData<EmergencyTransferStoreDto> data = pageSearch(basePageParam);
        if (CollUtil.isEmpty(data.getRecords())) {
            return CollUtil.newArrayList();
        }
        return BeanUtil.copyToList(data.getRecords(), InternalEmergencyTransferStoreDto.class);
    }

}
