package com.jiduauto.sps.order.server.controller.common;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import com.google.common.collect.ImmutableMap;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.sdk.client.common.AggregateQuery;
import com.jiduauto.sps.sdk.consts.QueryKey;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.AggregateQueryUtil;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 通用查询接口
 */
@SuppressWarnings("unchecked")
@RestController
@RequestMapping("/spsInternal/common")
public class SpsInternalCommonController {

    public static Map<String, IService<?>> QUERY_SERVICE_MAP;

    /**
     * 需要增加表查询, QUERY_SERVICE_MAP 中放入对应映射关系即可
     */
    public SpsInternalCommonController(ISaleOrderService saleOrderService,
                                       IBackOrderService backOrderService,
                                       IPurchaseOrderService purchaseOrderService,
                                       IPurchaseOrderDetailService purchaseOrderDetailService,
                                       ISaleOrderDetailService saleOrderDetailService,
                                       IStoreTransferOrderService storeTransferOrderService,
                                       IStoreTransferOrderDetailService storeTransferOrderDetailService,
                                       IWarehouseDistributeAttachService warehouseDistributeAttachService,
                                       IWarehouseDistributeItemAttachService  warehouseDistributeItemAttachService,
                                       IWarehouseDistributeOrderService warehouseDistributeOrderService,
                                       IBackSaleRelationService backSaleRelationService
    ) {
        QUERY_SERVICE_MAP = ImmutableMap.<String, IService<?>>builder()
                .put(QueryKey.SALE_ORDER, saleOrderService)
                .put(QueryKey.BACK_ORDER, backOrderService)
                .put(QueryKey.PURCHASE_ORDER, purchaseOrderService)
                .put(QueryKey.PURCHASE_ORDER_DETAIL, purchaseOrderDetailService)
                .put(QueryKey.SALE_ORDER_DETAIL, saleOrderDetailService)
                .put(QueryKey.STORE_TRANSFER_ORDER, storeTransferOrderService)
                .put(QueryKey.STORE_TRANSFER_ORDER_DETAIL, storeTransferOrderDetailService)
                .put(QueryKey.WAREHOUSE_DISTRIBUTE_ATTACH, warehouseDistributeAttachService)
                .put(QueryKey.WAREHOUSE_DISTRIBUTE_ITEM_ATTACH, warehouseDistributeItemAttachService)
                .put(QueryKey.WAREHOUSE_DISTRIBUTE_ORDER, warehouseDistributeOrderService)
                .put(QueryKey.BACK_SALE_RELATION, backSaleRelationService)
                .build();
    }

    /**
     * 公共查询方法
     */
    @PostMapping("/{key}")
    public BaseResult<Object> commonQuery(AggregateQuery<?> req, @PathVariable("key") String key) {
        QueryWrapper queryWrapper = AggregateQueryUtil.splicingAggregateQueries(new QueryWrapper<>(), req);
        return BaseResult.OK(QUERY_SERVICE_MAP.get(key).list(queryWrapper));
    }
}
