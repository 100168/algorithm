package com.jiduauto.sps.order.server.controller;


import com.jiduauto.javakit.common.biz.Result;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 *
 * @author generate
 * @since 2022-12-14
 */
@RestController
@AllArgsConstructor
public class BaseController {
    @RequestMapping("/misc/ping")
    @ResponseBody
    public Result<String> ping() {
        return Result.ofSuccess("success");
    }
}
