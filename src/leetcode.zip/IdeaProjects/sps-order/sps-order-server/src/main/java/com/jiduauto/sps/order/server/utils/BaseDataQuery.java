package com.jiduauto.sps.order.server.utils;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jiduauto.sps.order.server.caches.MapLocationCache;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.service.IBaseDataRespCheckService;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.pojo.dto.DictItemClientDto;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author shaofei.xie
 */
@Component
public class BaseDataQuery {

    @Resource
    private SpsClient spsClient;
    @Resource
    private IBaseDataRespCheckService baseDataRespCheckService;

    @Resource
    private MapLocationCache mapLocationCache;

    public Optional<WarehousePo> getWarehousePo(String bizType, String warehouseCode) {
        return getWarehousePo(bizType, warehouseCode, true);
    }

    /**
     * 根据零件号 salePartNum 查询
     */
    public Optional<MaterialPo> getMaterialPo(String bizType, String salePartNum) {
        if (StrUtil.isBlank(salePartNum)) {
            return Optional.empty();
        }
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setMaterialCodes(Lists.newArrayList(salePartNum));
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        return Optional.of(ret.getData().getMaterials().get(0));
    }

    /**
     * 根据仓库 code 查询
     */
    public Optional<WarehousePo> getWarehousePo(String bizType, String warehouseCode, Boolean isCheck) {
        if (StrUtil.isBlank(warehouseCode)) {
            return Optional.empty();
        }
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setWarehouseCodes(Lists.newArrayList(warehouseCode));
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        if (isCheck) {
            baseDataRespCheckService.check(ret, baseDataReq);
        }
        return Optional.of(ret.getData().getWarehouses().get(0));
    }


    public Map<String, WarehousePo> mapWarehousePo(String bizType, List<String> warehouseCodes) {
        return mapWarehousePo(bizType, warehouseCodes, true);
    }

    /**
     * 根据指定的业务类型和仓库编码，映射仓库PO。
     *
     * @param bizType        业务类型
     * @param warehouseCodes 仓库编码列表
     * @return 仓库PO的映射
     */
    public Map<String, WarehousePo> mapWarehousePo(String bizType, List<String> warehouseCodes, Boolean isCheck) {
        if (CollUtil.isEmpty(warehouseCodes)) {
            return Maps.newHashMap();
        }
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setWarehouseCodes(warehouseCodes);
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        if (isCheck) {
            baseDataRespCheckService.check(ret, baseDataReq);
        }
        return ret.getData().getWarehouses().stream().collect(Collectors.toMap(WarehousePo::getCode, Function.identity(), (p, n) -> n));
    }


    public Optional<StorePo> getStorePo(String bizType, String storeCode) {
        return getStorePo(bizType, storeCode, true);
    }

    /**
     * 根据给定的业务类型和店铺编码，获取 StorePo 对象。
     *
     * @param bizType   业务类型
     * @param storeCode 店铺编码
     * @return 可选的 StorePo 对象，表示店铺；如果店铺编码为空或店铺不存在，则返回一个空的可选对象
     */
    public Optional<StorePo> getStorePo(String bizType, String storeCode, Boolean isCheck) {
        if (StrUtil.isBlank(storeCode)) {
            return Optional.empty();
        }
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setStoreCodes(Lists.newArrayList(storeCode));
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        if (isCheck) {
            baseDataRespCheckService.check(ret, baseDataReq);
        }
        return Optional.ofNullable(ret.getData().getStorePos().get(0));
    }

    public Map<String, StorePo> mapStorePo(String bizType, List<String> storeCodes, Boolean isCheck) {
        if (storeCodes.isEmpty()) {
            return Maps.newHashMap();
        }
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setStoreCodes(storeCodes);
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        if (isCheck) {
            baseDataRespCheckService.check(ret, baseDataReq);
        }
        return ret.getData().getStorePos().stream().collect(Collectors.toMap(StorePo::getStoreCode, Function.identity(), (p1, p2) -> p2));
    }

    public Map<String, String> mapCompanyPo(String bizType, List<String> companyCodes, Boolean isCheck) {
        if (CollUtil.isEmpty(companyCodes)) {
            return Maps.newHashMap();
        }
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setCompanyCodes(companyCodes);
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        if (isCheck) {
            baseDataRespCheckService.check(ret, baseDataReq);
        }
        return ret.getData().getCompanyPos().stream().collect(Collectors.toMap(CompanyPo::getCode, CompanyPo::getName, (p1, p2) -> p2));
    }

    public Map<String, String> mapCompanyPo(String bizType, List<String> companyCodes) {
        return mapCompanyPo(bizType, companyCodes, false);
    }
    public Map<String, StorePo> mapStorePo(String bizType, List<String> storeCodes) {
        return mapStorePo(bizType, storeCodes, true);
    }

    /**
     * 根据给定的字典代码，获取代码和名称的映射关系的Map。
     *
     * @param dictCode 用于检索映射关系的字典代码
     * @return 包含代码和名称映射关系的Map
     */
    public Map<String, String> getCodeAndNameMap(String dictCode) {
        if (StrUtil.isBlank(dictCode)) {
            return Maps.newHashMap();
        }

        if (DictEnum.MapLocationDistrict.getDictCode().equals(dictCode)) {
            List<DictItemPo> list = mapLocationCache.getByDictCode(dictCode);
            if (CollUtil.isEmpty(list)) {
                return Maps.newHashMap();
            }
            return list.stream().collect(Collectors.toMap(DictItemPo::getItemCode, DictItemPo::getItemName, (p, n) -> n));
        }
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setDictCodes(Lists.newArrayList(dictCode));
        baseDataReq.setDictSearchAll(true);
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();

        return ret.getData().getDictItemPos().stream().collect(Collectors.toMap(DictItemPo::getItemCode, DictItemPo::getItemName, (p, n) -> n));
    }

    public String getProvinceCodeByName(String provinceName) {
        List<DictItemPo> list = mapLocationCache.getByDictCode(DictEnum.MapLocationDistrict.getDictCode());
        if (CollUtil.isEmpty(list)) {
            return "";
        }
        return list.stream().filter(item -> provinceName.equals(item.getItemName()) && item.getSort() == 1
        ).map(DictItemPo::getItemCode).findFirst().orElse("");
    }

    public String getCityCodeByName(String cityName) {
        List<DictItemPo> list = mapLocationCache.getByDictCode(DictEnum.MapLocationDistrict.getDictCode());
        if (CollUtil.isEmpty(list)) {
            return "";
        }
        return list.stream().filter(item ->
                cityName.equals(item.getItemName()) && item.getSort() == 2
        ).map(DictItemPo::getItemCode).findFirst().orElse("");
    }

    public String getDistrictCodeByName(String districtName) {
        List<DictItemPo> list = mapLocationCache.getByDictCode(DictEnum.MapLocationDistrict.getDictCode());
        if (CollUtil.isEmpty(list)) {
            return "";
        }
        return list.stream().filter(item ->
                districtName.equals(item.getItemName()) && item.getSort() == 3
        ).map(DictItemPo::getItemCode).findFirst().orElse("");
    }



    /**
     * 将给定的销售部件号根据指定的业务类型映射为MaterialPo对象。
     *
     * @param bizType      用于筛选搜索结果的业务类型
     * @param salePartNums 要映射的销售部件号列表
     * @return 销售部件号到MaterialPo对象的映射
     */
    public Map<String, MaterialPo> mapMaterialPo(String bizType, List<String> salePartNums, Boolean isCheck) {
        if (CollUtil.isEmpty(salePartNums)) {
            return Maps.newHashMap();
        }

        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setMaterialCodes(salePartNums);
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        if (isCheck) {
            baseDataRespCheckService.check(ret, baseDataReq);
        }
        return ret.getData().getMaterials().stream().collect(Collectors.toMap(MaterialPo::getSalePartNum, Function.identity(), (p, n) -> n));
    }

    public Map<String, MaterialPo> mapMaterialPo(String bizType, List<String> salePartNums) {
        return mapMaterialPo(bizType, salePartNums, true);
    }

    /**
     * 获取所用该业务类型该门店下的仓库配置
     */
    public List<StoreWarehouseConfigPo> allStoreWarehouseConfig(String bizType, String storeCode) {
        if (StrUtil.isBlank(storeCode)) {
            return Lists.newArrayList();
        }

        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setStoreWarehouseCodes(Lists.newArrayList(storeCode));
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        baseDataRespCheckService.check(ret, baseDataReq);

        return ret.getData().getStoreWarehouseConfigPos().stream().sorted(Comparator.comparing(StoreWarehouseConfigPo::getPriority)).collect(Collectors.toList());
    }

    public Optional<OrderCalendarPo> getOrderCalendarPo(String bizType, String storeCode) {
        if (StrUtil.isBlank(storeCode)) {
            return Optional.empty();
        }

        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setOrderCalendarCodes(Lists.newArrayList(storeCode));
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq);
        baseDataRespCheckService.check(ret, baseDataReq);
        return Optional.of(ret.getData().getOrderCalendarPos().get(0));
    }

    public List<OrderCalendarPo> listOrderCalendarPo(String bizType, List<String> storeCodes) {
        if (CollUtil.isEmpty(storeCodes)) {
            return Lists.newArrayList();
        }
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setOrderCalendarCodes(storeCodes);
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        baseDataRespCheckService.check(ret, baseDataReq);
        return ret.getData().getOrderCalendarPos();
    }

    public List<MaterialPo> queryNameLikeMaterial(String bizType, String salePartLikeName) {
        if (StrUtil.isBlank(salePartLikeName)) {
            return Lists.newArrayList();
        }
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setMaterialNameLike(salePartLikeName);
        BaseResult<BaseDataResp> ret = spsClient.searchBaseData(baseDataReq).check();
        return ret.getData().getMaterials();
    }
    /**
     * 获取dict code为key (dictItem itemCode为key , itemName为value )为value的map
     *
     */
    public Map<String, Map<String, String>> getDictItemName(List<DictItemClientDto> dictItemClientDtos) {
        Map<String, Map<String, String>> map = new HashMap<>();
        for (DictItemClientDto clientDto : dictItemClientDtos) {
            if (!map.containsKey(clientDto.getCode())){
                HashMap<String, String> value = new HashMap<>();
                value.put(clientDto.getItemCode(), clientDto.getItemName());
                map.put(clientDto.getCode(), value);
            }else {
                map.get(clientDto.getCode()).put(clientDto.getItemCode(), clientDto.getItemName());
            }
        }
        return map;
    }
}
