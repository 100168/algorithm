package com.jiduauto.sps.order.server.client.resp;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author panjian
 */
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class PurchaseOrderSyncResp {

    private List<ClassMessageBody> MessageBody;

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBody {

        private ClassMessageBodyHeader Header;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyHeader {

        private String Receiver;
        private String Header_Key;
        private String ZTYPE;
        private String BSTNK;
        private String VBELN;
        private LocalDateTime CreateDate;
        private String Message_Status;
        private String Message_Text;
    }

    public static boolean success(PurchaseOrderSyncResp resp) {
        if (resp == null) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody())) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody().get(0).getHeader())) {
            return false;
        } else {
            return "S".equals(resp.getMessageBody().get(0).getHeader().getMessage_Status());
        }
    }

    public static PurchaseOrderSyncResp failedResp(String message) {
        PurchaseOrderSyncResp resp = new PurchaseOrderSyncResp();
        ArrayList<ClassMessageBody> messageBodies = new ArrayList<>();
        messageBodies.add(new ClassMessageBody());
        resp.setMessageBody(messageBodies);
        resp.getMessageBody().get(0).setHeader(new ClassMessageBodyHeader());
        resp.getMessageBody().get(0).getHeader().setMessage_Status("fallback");
        resp.getMessageBody().get(0).getHeader().setMessage_Text(message);
        return resp;
    }

    public static String errorMessage(String desc) {
        if (desc == null || !desc.startsWith("{\"MessageBody\"")) {
            return desc;
        }
        try {
            PurchaseOrderSyncResp resp = JsonUtil.toObject(desc, PurchaseOrderSyncResp.class);
            return resp.getMessageBody().get(0).getHeader().getMessage_Text();
        } catch (Exception e) {
            return desc;
        }
    }
}
