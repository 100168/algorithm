package com.jiduauto.sps.order.server.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.NumberNoReq;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeAttachItemDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemAttachPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;

import java.util.List;

/**
 * <p>
 * 仓配订单零件附属信息 服务类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
public interface IWarehouseDistributeItemAttachService extends IService<WarehouseDistributeItemAttachPo> {
    /**
     * 仓配零件附属信息分页查询
     * @author O_chaopeng.huang
     */
    BaseResult<BasePageData<WarehouseDistributeAttachItemDto>> pageSearch(BasePageParam<NumberNoReq> req);

    List<WarehouseDistributeAttachItemDto> getDtoList(List<WarehouseDistributeItemAttachPo> pos);

    List<WarehouseDistributeItemAttachPo> getByOrderNo(String orderNo);
}
