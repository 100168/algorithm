package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.util.List;

/**
 * @ClassName PendingReceiveDto
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/9/11 15:12
 */
@Data
public class PendingReceiveDto {
    private String bizType;
    private String outOrderNo;
    private String orderStatus;
    private List<PendingReceiveDetailDto> itemList;
}
