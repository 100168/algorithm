package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import com.jiduauto.sps.order.server.enums.StoreDiscountApprovalStatusEnum;
import com.jiduauto.sps.order.server.excel.StoreDiscountApprovalDetailImportHandler;
import com.jiduauto.sps.order.server.excel.check.StoreDiscountApprovalDetailBatchPreCheck;
import com.jiduauto.sps.order.server.mapper.StoreDiscountApprovalDetailMapper;
import com.jiduauto.sps.order.server.mapper.StoreDiscountApprovalMapper;
import com.jiduauto.sps.order.server.pojo.dto.FileDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountApprovalDetailDto;
import com.jiduauto.sps.order.server.pojo.fileexport.StoreDiscountApprovalDetailExportDto;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalDetailPo;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailEditReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailImportReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailPageSearchReq;
import com.jiduauto.sps.order.server.service.IStoreDiscountApprovalDetailService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.PurchaseOrderTypeEnum;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.handler.ExcelThreadLocalHolder;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.ItemIdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BosFileResult;
import com.jiduauto.sps.sdk.service.IBosService;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.DateUtils;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * 门店折扣审批明细 服务实现类
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
@Service
public class StoreDiscountApprovalDetailServiceImpl extends ServiceImpl<StoreDiscountApprovalDetailMapper, StoreDiscountApprovalDetailPo> implements IStoreDiscountApprovalDetailService {

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private IBosService bosService;

    @Value("${store-discount.config.max-detail-size:10000}")
    private Integer maxDetailSize;

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private StoreDiscountApprovalMapper storeDiscountApprovalMapper;

    @Resource
    private StoreDiscountApprovalDetailMapper storeDiscountApprovalDetailMapper;

    @Resource
    private StoreDiscountApprovalDetailImportHandler storeDiscountApprovalDetailImportHandler;

    @Override
    public FileDto generateExcel(IdReq idReq) {

        List<StoreDiscountApprovalDetailPo> detailPoList = list(Wrappers.lambdaQuery(StoreDiscountApprovalDetailPo.class)
                .eq(StoreDiscountApprovalDetailPo::getApprovalId, idReq.getId())
                .eq(StoreDiscountApprovalDetailPo::getBizType, idReq.getBizType()));
        if (CollUtil.isEmpty(detailPoList)) {
            return null;
        }
        List<StoreDiscountApprovalDetailExportDto> collect = detailPoList.stream()
                .map(item -> {
                    StoreDiscountApprovalDetailExportDto approvalDetailExportDto = new StoreDiscountApprovalDetailExportDto();
                    BeanUtils.copyProperties(item, approvalDetailExportDto);
                    approvalDetailExportDto.setEffectiveStartDate(item.getEffectiveStartTime().toLocalDate());
                    approvalDetailExportDto.setDiscountRate(item.getDiscountRate().toString());
                    return approvalDetailExportDto;
                }).collect(Collectors.toList());

        String fileName = "门店折扣审批明细";
        File excelFile;
        try {
            excelFile = File.createTempFile(IdUtil.objectId() + "_" + fileName, BaseConstants.FileType.XLSX);
            EasyExcel.write(excelFile.getAbsoluteFile(), StoreDiscountApprovalDetailExportDto.class).sheet("折扣明细").doWrite(collect);
        } catch (Exception e) {
            throw new BizException("生成文件异常");
        }

        try (InputStream inputStream = Files.newInputStream(excelFile.toPath())) {
            BosFileResult bosFileResult = bosService.putObjInputStream(inputStream, fileName + BaseConstants.FileType.XLSX);
            return FileDto.builder().name(fileName.concat(BaseConstants.FileType.XLSX)).url(bosFileResult.getFileUrl()).length(excelFile.length()).build();
        } catch (IOException e) {
            throw new BizException("上传文件异常");
        } finally {
            if (excelFile.exists()) {
                excelFile.delete();
            }
        }
    }

    private void checkExistApprovalDetailPo(StoreDiscountApprovalDetailAddReq request) {
        StoreDiscountApprovalDetailPo po = getOne(Wrappers.lambdaQuery(StoreDiscountApprovalDetailPo.class)
                .eq(StoreDiscountApprovalDetailPo::getApprovalId, request.getApprovalId())
                .eq(StoreDiscountApprovalDetailPo::getMaterialCode, request.getMaterialCode())
                .eq(StoreDiscountApprovalDetailPo::getStoreCode, request.getStoreCode())
                .eq(StoreDiscountApprovalDetailPo::getOrderType, request.getOrderType())
                .eq(StoreDiscountApprovalDetailPo::getEffectiveStartTime, request.getEffectiveStartDate())
                .eq(StoreDiscountApprovalDetailPo::getBizType, request.getBizType())
        );
        if (Objects.nonNull(po)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_EXIST);
        }
    }

    private StoreDiscountApprovalPo checkAndGetApprovalPo(Long approvalId, String bizType) {
        StoreDiscountApprovalPo po = storeDiscountApprovalMapper.getById(approvalId, bizType);
        if (Objects.isNull(po)) {
            throw new BizException("审批单号不存在");
        }
        return po;
    }

    /**
     * 校验有效开始日期
     */
    private void checkEffectiveStartTime(LocalDateTime effectiveStartTime) {
        if (Objects.isNull(effectiveStartTime)) {
            throw new BizException("有效开始日期不能为空");
        }
        if (effectiveStartTime.toLocalDate().isBefore(LocalDate.now())) {
            throw new BizException("有效开始日期必须大于或等于当前日期");
        }
    }

    private void checkMaterialPo(String bizType, String materialCode) {
        baseDataQuery.mapMaterialPo(bizType, Lists.newArrayList(materialCode), true);
    }

    /**
     * 新增明细
     */
    @Override
    public void add(StoreDiscountApprovalDetailAddReq request) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_DISCOUNT_APPROVAL_OPERATE_KEY, request.getApprovalId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            checkExistApprovalDetailPo(request);
            StoreDiscountApprovalPo discountApprovalPo = checkAndGetApprovalPo(request.getApprovalId(), request.getBizType());
            checkEffectiveStartTime(DateUtils.parse(String.valueOf(request.getEffectiveStartDate()), DateUtils.STANDARD_DATE_FORMAT));
            if (!StoreDiscountApprovalStatusEnum.canEdit(discountApprovalPo.getApprovalStatus())) {
                throw new BizException("该状态审批单不支持新增明细");
            }

            if (discountApprovalPo.getDetailQuantity() >= maxDetailSize) {
                throw new BizException(String.format("单条审核单明细不能超过%d条", maxDetailSize));
            }

            if (!PurchaseOrderTypeEnum.hasValue(request.getOrderType())) {
                throw new BizException("订单类型不正确");
            }
            baseDataQuery.getStorePo(request.getBizType(), request.getStoreCode(), true);
            if (StrUtil.isNotBlank(request.getMaterialCode())) {
                checkMaterialPo(request.getBizType(), request.getMaterialCode());
            }
            StoreDiscountApprovalDetailPo detailPo = new StoreDiscountApprovalDetailPo();
            BeanUtils.copyProperties(request, detailPo);
            detailPo.setEffectiveStartTime(request.getEffectiveStartDate().atTime(LocalTime.MIN));
            save(detailPo);

            incrApprovalDetailQty(discountApprovalPo);
        } catch (DuplicateKeyException e) {
            throw new BizException(SpsResponseCodeEnum.RECORD_EXIST);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    private void incrApprovalDetailQty(StoreDiscountApprovalPo discountApprovalPo) {
        storeDiscountApprovalMapper.updateDetailQty(discountApprovalPo.getId(), discountApprovalPo.getDetailQuantity() + 1, UserUtil.getUserName());
    }

    private void decrApprovalDetailQty(StoreDiscountApprovalPo discountApprovalPo) {
        storeDiscountApprovalMapper.updateDetailQty(discountApprovalPo.getId(), discountApprovalPo.getDetailQuantity() - 1, UserUtil.getUserName());
    }

    /**
     * 清空
     */
    @Override
    public void deleteAll(IdReq approvalIdReq) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_DISCOUNT_APPROVAL_OPERATE_KEY, approvalIdReq.getId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            StoreDiscountApprovalPo po = checkAndGetApprovalPo(approvalIdReq.getId(), approvalIdReq.getBizType());
            if (!StoreDiscountApprovalStatusEnum.canEdit(po.getApprovalStatus())) {
                throw new BizException("该状态审批单不支持删除明细");
            }

            storeDiscountApprovalDetailMapper.deleteByApprovalId(po.getId());
            storeDiscountApprovalMapper.updateDetailQty(po.getId(), 0, UserUtil.getUserName());
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    private StoreDiscountApprovalDetailPo checkAndGetApprovalDetailPo(Long id, String bizType) {
        StoreDiscountApprovalDetailPo detailPo = getOne(Wrappers.lambdaQuery(StoreDiscountApprovalDetailPo.class)
                .eq(StoreDiscountApprovalDetailPo::getId, id)
                .eq(StoreDiscountApprovalDetailPo::getBizType, bizType));
        if (Objects.isNull(detailPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        return detailPo;
    }


    /**
     * 删除明细
     */
    @Override
    public void delete(ItemIdReq request) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_DISCOUNT_APPROVAL_OPERATE_KEY, request.getId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            StoreDiscountApprovalDetailPo detailPo = checkAndGetApprovalDetailPo(request.getItemId(), request.getBizType());
            if (!request.getId().equals(detailPo.getApprovalId())) {
                throw new BizException("审批单不匹配");
            }

            StoreDiscountApprovalPo approvalPo = checkAndGetApprovalPo(detailPo.getApprovalId(), detailPo.getBizType());
            if (!StoreDiscountApprovalStatusEnum.canEdit(approvalPo.getApprovalStatus())) {
                throw new BizException("该状态审批单不支持删除明细");
            }

            detailPo.setDelUniqueKey(detailPo.getId());
            updateById(detailPo);

            int row = storeDiscountApprovalDetailMapper.deleteById(detailPo.getId());
            if (row > 0) {
                decrApprovalDetailQty(approvalPo);
            }
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    /**
     * 分页查询明细
     */
    @Override
    public BasePageData<StoreDiscountApprovalDetailDto> pageSearch(BasePageParam<StoreDiscountApprovalDetailPageSearchReq> req) {
        StoreDiscountApprovalDetailPageSearchReq param = req.getParam();
        IPage<StoreDiscountApprovalDetailPo> page = page(new Page<>(req.getPage(), req.getSize()),
                Wrappers.lambdaQuery(StoreDiscountApprovalDetailPo.class)
                        .eq(StoreDiscountApprovalDetailPo::getBizType, param.getBizType())
                        .eq(StoreDiscountApprovalDetailPo::getApprovalId, param.getApprovalId())
                        .eq(StrUtil.isNotBlank(param.getMaterialCode()), StoreDiscountApprovalDetailPo::getMaterialCode, param.getMaterialCode())
        );
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(param.getBizType(), page.getRecords().stream().map(StoreDiscountApprovalDetailPo::getMaterialCode).collect(Collectors.toList()));
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(param.getBizType(), page.getRecords().stream().map(StoreDiscountApprovalDetailPo::getStoreCode).collect(Collectors.toList()));
        BasePageData<StoreDiscountApprovalDetailDto> pageData = new BasePageData<>(page);
        pageData.setRecords(page.getRecords().stream().map(item -> {
            StoreDiscountApprovalDetailDto dto = BeanCopierUtil.copy(item, StoreDiscountApprovalDetailDto.class);
            dto.setMaterialName(materialPoMap.getOrDefault(item.getMaterialCode(), new MaterialPo()).getMaterialName());
            dto.setStoreName(storePoMap.getOrDefault(item.getStoreCode(), new StorePo()).getStoreName());
            dto.setEffectiveStartDate(item.getEffectiveStartTime().toLocalDate());
            return dto;
        }).collect(Collectors.toList()));
        return pageData;
    }

    /**
     * 导入明细
     */
    @Override
    public ImportResultResp importDetail(String bizType, Long approvalId, MultipartFile file) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_DISCOUNT_APPROVAL_OPERATE_KEY, approvalId);
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            ImportParamDto importParam = new ImportParamDto();
            importParam.setFile(file);
            importParam.setBizType(bizType);
            ExcelThreadLocalHolder.put(StoreDiscountApprovalDetailBatchPreCheck.KEY_APPROVAL_ID, approvalId);
            ImportReturnDataInfo<ExtendExportDto<StoreDiscountApprovalDetailImportReq>> resp = storeDiscountApprovalDetailImportHandler.doTask(importParam);
            ImportResultResp resultResp = new ImportResultResp();
            resultResp.setFileUrl(resp.getFileUrl());
            resultResp.setImportFlag(resp.getImportFlag());
            return resultResp;
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    /**
     * 编辑
     */
    @Override
    public void edit(StoreDiscountApprovalDetailEditReq request) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_DISCOUNT_APPROVAL_OPERATE_KEY, request.getApprovalId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            StoreDiscountApprovalDetailPo detailPo = checkAndGetApprovalDetailPo(request.getId(), request.getBizType());
            checkEffectiveStartTime(detailPo.getEffectiveStartTime());
            if (!request.getApprovalId().equals(detailPo.getApprovalId())) {
                throw new BizException("审批单不匹配");
            }

            StoreDiscountApprovalPo approvalPo = checkAndGetApprovalPo(detailPo.getApprovalId(), detailPo.getBizType());
            if (!StoreDiscountApprovalStatusEnum.canEdit(approvalPo.getApprovalStatus())) {
                throw new BizException("该状态审批单不支持编辑明细");
            }

            StoreDiscountApprovalDetailPo update = new StoreDiscountApprovalDetailPo();
            update.setId(detailPo.getId());
            update.setDiscountRate(request.getDiscountRate());
            updateById(update);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }
}
