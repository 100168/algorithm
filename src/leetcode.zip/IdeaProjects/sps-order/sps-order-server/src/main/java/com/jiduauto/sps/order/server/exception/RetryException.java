package com.jiduauto.sps.order.server.exception;

import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import lombok.Data;

/**
 * @Author xKun
 * @Date 2021/12/7 19:18
 * @Version 1.0
 * @Desc 自定义业务异常
 */
@Data
public class RetryException extends RuntimeException {
    //错误码
    private Integer errCode;
    //错误内容
    private String errMessage;

    //私有无参构造
    private RetryException(){
        super();
    }


    //构造器2：code，message
    public RetryException(Integer errCode, String errMessage){
        super(errMessage);
        this.errMessage = errMessage;
        this.errCode = errCode;
    }


    public RetryException(SpsResponseCodeEnum codeEnum){
        super(codeEnum.getDesc());
        this.errMessage = codeEnum.getDesc();
        this.errCode = codeEnum.getCode();
    }
}
