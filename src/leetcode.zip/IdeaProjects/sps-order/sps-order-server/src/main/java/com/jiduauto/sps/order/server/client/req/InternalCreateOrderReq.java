package com.jiduauto.sps.order.server.client.req;

import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.SpsBaseReq;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
public class InternalCreateOrderReq extends SpsBaseReq {

    /*
     * 仓配订单基本信息
     */
    private WarehouseDistributeOrderPo head;

    /*
     * 仓配订单物流信息
     */
    private WarehouseDistributeLogisticPo logistic;

    /**
     * 仓配订单明细
     */
    private List<WarehouseDistributeItemPo> items;
}
