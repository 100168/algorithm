package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class InternalStoreRecommendationForecastDto implements Serializable {

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 备件号码
     */
    private String materialCode;

    /**
     * 备件名称
     */
    private String materialName;

    /**
     * 最小包装
     */
    private String minPackage;

    /**
     * 最小推荐数量
     */
    private Integer minQty;

    /**
     * 最大推荐数量
     */
    private Integer maxQty;

    /**
     * 门店可用库存
     */
    private BigDecimal storeStockQty = BigDecimal.ZERO;

    /**
     * 销售入库在途数量
     */
    private BigDecimal inSaleQty = BigDecimal.ZERO;

    /**
     * 推荐数量
     */
    private BigDecimal adviceQty;

    /**
     * 调拨入库在途数量
     */
    private BigDecimal inTransferQty = BigDecimal.ZERO;

    /**
     * 替换件 (新到旧)
     */
    private String replaceParts;

    /**
     * 替换件可用库存
     */
    private BigDecimal replacePartsStockQty = BigDecimal.ZERO;

    /**
     * 替换件销售在途数量
     */
    private BigDecimal replacePartsInSaleQty = BigDecimal.ZERO;

    /**
     * 替换件调拨在途数量
     */
    private BigDecimal replacePartsInTransferQty = BigDecimal.ZERO;
}
