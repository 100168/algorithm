package com.jiduauto.sps.order.server.facade.impl;

import com.jiduauto.sps.order.server.convertor.SaleOrderConvertor;
import com.jiduauto.sps.order.server.convertor.SaleOrderDetailConvertor;
import com.jiduauto.sps.order.server.facade.SaleOrderFacadeService;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderByPoDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.order.server.service.IPurchaseOrderDetailService;
import com.jiduauto.sps.order.server.service.ISaleOrderDetailService;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants.ListMaxSize;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import lombok.val;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * @author panjian
 */
@Service
public class SaleOrderFacadeServiceImpl implements SaleOrderFacadeService {

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private ISaleOrderDetailService saleOrderDetailService;

    @Resource
    private SaleOrderConvertor saleOrderConvertor;

    @Resource
    private SaleOrderDetailConvertor saleOrderDetailConvertor;

    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;


    @Override
    public BasePageData<SaleOrderDto> internalPageSearch(BasePageParam<InternalSoSearchReq> pageParam) {

        BasePageParam<SaleOrderPageSearchReq> param = new BasePageParam<>();
        BeanUtils.copyProperties(pageParam, param);
        val soSearchReq = saleOrderConvertor.toReq(pageParam.getParam());
        soSearchReq.setSalePartNumLike(pageParam.getParam().getMaterialCode());
        param.setParam(soSearchReq);
        return saleOrderService.pageSearch(param);
    }

    @Override
    public BasePageData<SaleOrderDetailDto> internalDetailPageSearch(BasePageParam<SaleOrderDetailByIdReq> pageParam) {
        return saleOrderDetailService.pageSearch(pageParam);
    }

    @Override
    public List<SaleOrderDto> list(SaleOrderListSearchReq listSearchReq) {
        BasePageParam<SaleOrderPageSearchReq> pageParam = new BasePageParam<>();
        pageParam.setSize(ListMaxSize.HUNDRED);
        val saleOrderPageSearchReq = new SaleOrderPageSearchReq();
        saleOrderPageSearchReq.setSaleOrderNos(listSearchReq.getSaleOrderNos());
        saleOrderPageSearchReq.setBizType(listSearchReq.getBizType());
        pageParam.setParam(saleOrderPageSearchReq);
        return saleOrderService.pageSearch(pageParam).getRecords();
    }

    /**
     * 销售订单列表批量查询
     *
     * @param listSearchReq po单号
     * @return list
     */
    @Override
    public List<SaleOrderByPoDto> listByPo(SaleOrderListSearchByPoReq listSearchReq) {
        BasePageParam<SaleOrderPageSearchReq> pageParam = new BasePageParam<>();
        pageParam.setSize(ListMaxSize.TEN_THOUSAND);
        SaleOrderPageSearchReq saleOrderPageSearchReq = new SaleOrderPageSearchReq();
        saleOrderPageSearchReq.setPurchaseOrderNos(listSearchReq.getPurchaseOrderNos());
        saleOrderPageSearchReq.setBizType(listSearchReq.getBizType());
        pageParam.setParam(saleOrderPageSearchReq);
        List<SaleOrderByPoDto> list =  saleOrderService.pageSearchByPos(pageParam);

        if(CollectionUtils.isEmpty(list)){
            return null;
        }
        Map<String, BigDecimal> priceMap =  purchaseOrderDetailService.getDiscountUnitPriceByPos(listSearchReq.getPurchaseOrderNos());
        for(SaleOrderByPoDto dto : list){
            dto.setDiscountUnitPrice(priceMap.get(dto.getPurchaseOrderNo()+dto.getSalePartNum()));
        }
        return list;
    }
}
