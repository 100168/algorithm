package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.mapper.BackSaleRelationMapper;
import com.jiduauto.sps.sdk.pojo.po.BackSaleRelationPo;
import com.jiduauto.sps.order.server.service.IBackSaleRelationService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 缺件订单跟销售订单的关系 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Service
public class BackSaleRelationServiceImpl extends ServiceImpl<BackSaleRelationMapper, BackSaleRelationPo> implements IBackSaleRelationService {

}
