package com.jiduauto.sps.order.server.client.req;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.jiduauto.sps.order.server.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.enums.OperationType;
import com.jiduauto.sps.sdk.pojo.req.SpsBaseReq;
import com.jiduauto.sps.sdk.enums.StockSource;
import com.jiduauto.sps.sdk.utils.StringUtils;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 库存操作请求实体
 */
@Data
public class InAndOutStockRequest extends SpsBaseReq {

    /**
     * 操作类型
     ADD("增加"),
     CANCEL("取消"),
     OCCUPY("占用"),
     UN_OCCUPY("取消占用"),
     SUBTRACT("扣减");
     */
    @NotNull(message = "操作类型不能为空;")
    private OperationType operationType;
    /**
     * 业务类型(能源-ANS-收货：ES10   )
     */
    @NotNull(message = "业务类型不能为空;")
    private String businessType;

    /**
     * 业务单号 唯一（用于业务反查相关信息）
     */
    @NotNull(message = "业务单号不能为空;")
    private String businessBillNo;
    /**
     * 交易凭证号
     */
    @NotNull(message = "交易凭证号不能为空;")
    private String tradeNo;

    /**
     * 幂等操作流水号  废弃 业务单号唯一，作为幂等字段
     */
    @NotNull(message = "幂等操作流水号不能为空;")
    private String idempotentNo;

    /**
     * 操作人
     */
    @NotNull(message = "操作人不能为空")
    private String operateUser;

    /**
     * 操作时间
     */
    @NotNull(message = "操作时间不能为空")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private LocalDateTime operateTime;

    /**
     * 数据来源
     */
    private StockSource stockSource;
    /**
     * 是否是 三方WMS-DHL的请求 。  DHL 出库的时候 无法给全所有的属性， 需要反查库存明细表
     */
    private boolean wmsFlag;

    /**
     * 维修工单类型
     * X1: 售前维修
     * X2: 售后维修
     * 门店智子 必填
     */
    private String repairCaseType;
    /**
     * 结算模式
     * Z1: 结算
     * Z2: 反结算
     * 门店智子 必填
     */
    private String settlementMode;

    /**
     * 车架号 vin码
     */
    private String vinNo;
    /**
     * 门店BP编码
     */
    private String storeBpCode;

    /**
     * 批量物料
     */
    @Valid
    private List<InAndOutStockParam> params;

    /**
     * 自定义拓展信息
     */
    private Map<String, String> extraInfo;

    public void addExtraInfo(String key,String value){
        if(StringUtils.isNotBlank(value)){
            if(this.extraInfo == null){
                this.extraInfo = new HashMap<>();
            }
            this.extraInfo.put(key, value);
        }
    }
}
