package com.jiduauto.sps.order.server.mq.consumer;

import cn.hutool.json.JSONUtil;
import com.jiduauto.dit.outbox.OutboxMessageService;
import com.jiduauto.sps.order.server.pojo.dto.StockPutOutResultMessage;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.client.req.SOStockOutTimeAndDeliverQtyReq;
import com.jiduauto.sps.sdk.client.req.StockOutItemQuantityDto;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.consts.OutboxConst;
import com.jiduauto.sps.sdk.enums.StockOperationType;
import com.jiduauto.sps.sdk.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import com.jiduauto.sps.sdk.utils.DateUtils;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author panjian
 */
@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_ORDER_STOCK_OPERATE_RESULT,
        topic = BaseConstants.RocketMqTopic.STOCK_PUT_OUT_RESULT,
        consumeThreadMax = 10)
public class StockPutOutResultConsumer implements RocketMQListener<MessageExt> {

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private IStoreTransferOrderService storeTransferOrderService;

    @Resource
    private OutboxMessageService outboxMessageService;

    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("StockPutOutResultConsumer#onMessage messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
        String tag = message.getTags();

        //仓配订单-领料订单-出库结果同步SRM
        if(StockOperationType.isWDOApplyOrderPutOut(tag)){
                warehouseDistributeOrderService.syncWDApplyOrderPutOutTOSrm(body);
        }

        //仓配订单出库
        if (StockOperationType.isWDOPutOut(tag)) {
            try {
                InAndOutStockRequest msg = JSONUtil.toBean(body, InAndOutStockRequest.class);
                WarehouseDistributeOrderPo po = warehouseDistributeOrderService.getByOrderNo( msg.getBizType(),msg.getTradeNo());
                if (po == null) {
                    return;
                }
                Map<String, WarehouseDistributeItemPo> warehouseDistributeItemPoMap = getWarehouseDistributeItemPoMap(msg);
                warehouseDistributeOrderService.updateDeliverQty(msg.getTradeNo(), msg.getExpressNo(), warehouseDistributeItemPoMap);
            } catch (Exception e) {
                log.warn("StockPutOutResultConsumer#onMessage exception:{}", e.getMessage());
                throw e;
            }
            return;
        }
        //仓配订单占库
        if ("SM-ORDER".equals(tag)) {
            try {
                StockPutOutResultMessage msg = JsonUtil.toObject(body, StockPutOutResultMessage.class);
                warehouseDistributeOrderService.updateStatusAndSyncDhlIfSuccess(msg);
                return;
            } catch (Exception e) {
                log.warn("StockPutOutResultConsumer#onMessage exception:{}", e.getMessage());
                throw e;
            }
        }

        //dhl出库成功反写销售订单状态&数量
        if (StockOperationType.SP20.getOperationType().equals(tag)) {
            InAndOutStockRequest request = JSONUtil.toBean(body, InAndOutStockRequest.class);
            List<StockOutItemQuantityDto> outQuantityList = new ArrayList<>();
            for (InAndOutStockParam param : request.getParams()) {
                StockOutItemQuantityDto dto = new StockOutItemQuantityDto();
                dto.setQuantity(param.getSumQuantity());
                dto.setSalePartNum(param.getMaterialCode());
                outQuantityList.add(dto);
            }
            saleOrderService.updateStockOutTimeAndDeliverQty(new SOStockOutTimeAndDeliverQtyReq(request.getTradeNo(),
                    DateUtils.dateToLocalDateTime(DateUtils.getLocalDateTimeStr(request.getOperateTime(), DateUtils.STANDARD_TIME_FORMAT)),
                    "", outQuantityList)
            );
            return;
        }
        //门店调拨出库
        if (StockOperationType.isStockTransferPutout(tag)) {
            com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest request = JSONUtil.toBean(body, com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest.class);
            storeTransferOrderService.updateTransferOutQty(request);
        }
    }

    public static Map<String, WarehouseDistributeItemPo> getWarehouseDistributeItemPoMap(InAndOutStockRequest request) {
        return request.getParams().stream().collect(Collectors.toMap(InAndOutStockParam::getColumnNo, e -> {
            WarehouseDistributeItemPo itemPo = new WarehouseDistributeItemPo();
            itemPo.setMaterialCode(e.getMaterialCode());
            itemPo.setBizType(e.getBizType());
            itemPo.setRealOutQty(e.getSumQuantity());
            return itemPo;
        }, (e1, e2) -> {
            e1.setRealOutQty(e1.getRealOutQty().add(e2.getRealOutQty()));
            return e1;
        }));
    }

}
