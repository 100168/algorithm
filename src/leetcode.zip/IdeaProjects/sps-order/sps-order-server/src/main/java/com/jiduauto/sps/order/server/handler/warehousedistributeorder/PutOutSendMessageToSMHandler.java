package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import cn.hutool.core.date.DateUtil;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.pojo.dto.StockPutOutResultMessage;
import com.jiduauto.sps.sdk.enums.StockSource;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDateTime;

@Component
public class PutOutSendMessageToSMHandler implements WDOrderJobHandler, InitializingBean {

    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private SpsClient spsClient;

    /**
     * 一件代发出库消息同步商城*/
    @Override
    public void process(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {
        WarehouseDistributeOrderPo warehouseDistributeOrderPo = warehouseDistributeOrderAllPo.getWarehouseDistributeOrderPo();
        StockPutOutResultMessage request = new StockPutOutResultMessage();

        request.setBusinessBillNo(warehouseDistributeOrderPo.getBusinessBillNo());
        request.setTradeNo(warehouseDistributeOrderPo.getOrderNo());
        request.setBusinessType(warehouseDistributeOrderPo.getOrderType());
        request.setResult(1);

        request.setPutOutTime(DateUtil.formatLocalDateTime(LocalDateTime.now()));
        spsClient.sendToSM(request);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.SEND_MSG_SM.getBitIndex(), this);
    }
}
