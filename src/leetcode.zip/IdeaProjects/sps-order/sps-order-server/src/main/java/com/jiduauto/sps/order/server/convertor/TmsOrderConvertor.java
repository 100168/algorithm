package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.tms.api.pojo.req.SpsOrderApplyReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface TmsOrderConvertor {
    @Mapping(target = "goodsList", ignore = true)
    @Mapping(target = "uniqueKey", source = "orderPo.businessBillNo")
    @Mapping(target = "packageList", ignore = true)
    @Mapping(target = "upstreamCode", source = "orderPo.businessBillNo")
    @Mapping(target = "transportType", source = "logisticPo.shippingMethod")
    @Mapping(target = "storageType", source = "orderPo.orderType")
    @Mapping(target = "source", expression = "java(com.jiduauto.tms.api.enums.OrderSourceEnum.SPS.getType())")
    @Mapping(target = "serviceShop", source = "logisticPo.deliverWarehouseCode")
    @Mapping(target = "senderPhone", source = "logisticPo.shipperContact")
    @Mapping(target = "senderAddress", source = "logisticPo.deliverAddress")
    @Mapping(target = "sender", source = "logisticPo.shipper")
    @Mapping(target = "requestArriveTime", source = "logisticPo.estArrivalTime")
    @Mapping(target = "remarks", source = "orderPo.remark")
    @Mapping(target = "receiverPhone", source = "logisticPo.receiverContact")
    @Mapping(target = "receiverAddress", source = "logisticPo.receiveAddress")
    @Mapping(target = "receiver", source = "logisticPo.receiver")
    @Mapping(target = "planTakeTime", source = "logisticPo.estPickTime")
    @Mapping(target = "placeOrderTime", expression = "java(cn.hutool.core.date.DateUtil.formatLocalDateTime(orderPo.getOrderTime()))")
    @Mapping(target = "oriProvinceCode", source = "logisticPo.deliverProvinceCode")
    @Mapping(target = "oriCountryCode", expression = "java(com.jiduauto.sps.sdk.enums.NationEnum.CN.getCode())")
    @Mapping(target = "oriCityCode", source = "logisticPo.deliverCityCode")
    @Mapping(target = "oriAreaCode", source = "logisticPo.deliverDistrictCode")
    @Mapping(target = "desProvinceCode", source = "logisticPo.receiveProvinceCode")
    @Mapping(target = "desCountryCode", expression = "java(com.jiduauto.sps.sdk.enums.NationEnum.CN.getCode())")
    @Mapping(target = "desCityCode", source = "logisticPo.receiveCityCode")
    @Mapping(target = "desAreaCode", source = "logisticPo.receiveDistrictCode")
    @Mapping(target = "businessType", source = "orderPo.bizType")
    @Mapping(target = "orderType", expression = "java(com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum.getByType(orderPo.getOrderType()).getTmsOrderType())")
    SpsOrderApplyReq toReq(WarehouseDistributeOrderPo orderPo, WarehouseDistributeLogisticPo logisticPo);
}
