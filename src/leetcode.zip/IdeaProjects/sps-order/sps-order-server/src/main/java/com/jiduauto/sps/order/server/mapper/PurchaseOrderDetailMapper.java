package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderDetailSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderSearchReq;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 采购订单明细 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface PurchaseOrderDetailMapper extends BaseMapper<PurchaseOrderDetailPo> {

    /**
     * 详情分页查询
     */
    IPage<PurchaseOrderDetailDto> pageSearch(Page<PurchaseOrderDetailDto> objectPage,@Param("searchReq") PurchaseOrderDetailSearchReq searchReq);

    /**
     * 采购订单详情批量查询
     */
    List<PurchaseOrderDetailDto> batchQuery(@Param("searchReq") PurchaseOrderSearchReq searchReq);
}
