package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.enums.StoreDiscountApprovalStatusEnum;
import com.jiduauto.sps.order.server.mapper.StoreDiscountApprovalMapper;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalPo;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.CommonFileAttachmentDto;
import com.jiduauto.sps.sdk.pojo.po.CommonFileAttachmentPo;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.ItemIdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BosFileResult;
import com.jiduauto.sps.sdk.service.IBosService;
import com.jiduauto.sps.sdk.service.ICommonFileAttachmentService;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class StoreDiscountApprovalAttachmentService {

    @Value("${store-discount.config.max-attachment-size:20}")
    private Integer maxAttachmentSize;

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private ICommonFileAttachmentService commonFileAttachmentService;

    @Resource
    private StoreDiscountApprovalMapper storeDiscountApprovalMapper;

    @Resource
    private IBosService bosService;

    private StoreDiscountApprovalPo checkAndGetApprovalPo(Long approvalId, String bizType) {
        StoreDiscountApprovalPo discountApprovalPo = storeDiscountApprovalMapper.getById(approvalId, bizType);
        if (Objects.isNull(discountApprovalPo)) {
            throw new BizException("审批单号不存在");
        }
        return discountApprovalPo;
    }

    public void upload(String bizType, Long approvalId, MultipartFile[] files) {
        StoreDiscountApprovalPo approvalPo = checkAndGetApprovalPo(approvalId, bizType);
        if (!StoreDiscountApprovalStatusEnum.canEdit(approvalPo.getApprovalStatus())) {
            throw new BizException("该状态审批单不支持添加附件");
        }

        if (approvalPo.getAttachmentQuantity() + files.length > maxAttachmentSize) {
            throw new BizException(String.format("单条审核单附件明细不能超过%d条", maxAttachmentSize));
        }

        List<CommonFileAttachmentPo> attachmentPos = new ArrayList<>();
        for (MultipartFile file : files) {
            attachmentPos.add(doUpload(approvalPo, file));
        }

        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_DISCOUNT_APPROVAL_OPERATE_KEY, approvalId);
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            approvalPo = checkAndGetApprovalPo(approvalId, bizType);
            if (!StoreDiscountApprovalStatusEnum.canEdit(approvalPo.getApprovalStatus())) {
                throw new BizException("该状态审批单不支持添加附件");
            }

            if (approvalPo.getAttachmentQuantity() + files.length > maxAttachmentSize) {
                throw new BizException(String.format("单条审核单附件明细不能超过%d条", maxAttachmentSize));
            }

            ((StoreDiscountApprovalAttachmentService) AopContext.currentProxy()).saveApprovalAttachmentPo(approvalPo, attachmentPos);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void saveApprovalAttachmentPo(StoreDiscountApprovalPo discountApprovalPo, List<CommonFileAttachmentPo> attachmentPos) {
        for (CommonFileAttachmentPo attachmentPo : attachmentPos) {
            commonFileAttachmentService.save(attachmentPo);
        }
        storeDiscountApprovalMapper.updateAttachmentQty(discountApprovalPo.getId(), discountApprovalPo.getAttachmentQuantity() + attachmentPos.size(), UserUtil.getUserName());
    }

    private CommonFileAttachmentPo doUpload(StoreDiscountApprovalPo discountApprovalPo, MultipartFile file) {
        try (InputStream inputStream = file.getInputStream()) {
            String fileName = file.getOriginalFilename();
            BosFileResult bosFileResult = bosService.putObjInputStream(inputStream, fileName);
            if (bosFileResult == null) {
                throw new BizException("文件上传BOS失败");
            }

            CommonFileAttachmentPo attachmentPo = new CommonFileAttachmentPo();
            attachmentPo.setBizType(discountApprovalPo.getBizType());
            attachmentPo.setSourceTable(StoreDiscountApprovalServiceImpl.TABLE_NAME);
            attachmentPo.setOrderNo(discountApprovalPo.getId().toString());
            attachmentPo.setFileName(fileName);
            attachmentPo.setFileKey(bosFileResult.getKey());
            attachmentPo.setFileUrl(bosFileResult.getFileUrl());
            attachmentPo.setFileLength(file.getSize());
            return attachmentPo;
        } catch (IOException e) {
            throw new BizException("文件上传BOS失败");
        }
    }

    public void delete(ItemIdReq request) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_DISCOUNT_APPROVAL_OPERATE_KEY, request.getId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            CommonFileAttachmentPo attachmentPo = checkAndGetApprovalAttachmentPo(request.getItemId(), request.getBizType());
            if (!request.getId().toString().equals(attachmentPo.getOrderNo())) {
                throw new BizException("审批单不匹配");
            }

            StoreDiscountApprovalPo discountApprovalPo = checkAndGetApprovalPo(Long.parseLong(attachmentPo.getOrderNo()), attachmentPo.getBizType());
            if (!StoreDiscountApprovalStatusEnum.canEdit(discountApprovalPo.getApprovalStatus())) {
                throw new BizException("该状态审批单不支持删除附件");
            }

            attachmentPo.setIsDel(Boolean.TRUE);
            commonFileAttachmentService.updateById(attachmentPo);
            storeDiscountApprovalMapper.updateAttachmentQty(discountApprovalPo.getId(), discountApprovalPo.getAttachmentQuantity() - 1, UserUtil.getUserName());
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    private CommonFileAttachmentPo checkAndGetApprovalAttachmentPo(Long id, String bizType) {
        CommonFileAttachmentPo attachmentPo = commonFileAttachmentService.getOne(Wrappers.lambdaQuery(CommonFileAttachmentPo.class)
                .eq(CommonFileAttachmentPo::getId, id)
                .eq(CommonFileAttachmentPo::getSourceTable, StoreDiscountApprovalServiceImpl.TABLE_NAME)
                .eq(CommonFileAttachmentPo::getIsDel, false)
                .eq(CommonFileAttachmentPo::getBizType, bizType));
        if (Objects.isNull(attachmentPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        return attachmentPo;
    }

    public BasePageData<CommonFileAttachmentDto> pageSearch(BasePageParam<IdReq> req) {
        IdReq param = req.getParam();
        IPage<CommonFileAttachmentPo> page = commonFileAttachmentService.page(new Page<>(req.getPage(), req.getSize()),
                Wrappers.lambdaQuery(CommonFileAttachmentPo.class)
                        .eq(CommonFileAttachmentPo::getBizType, param.getBizType())
                        .eq(CommonFileAttachmentPo::getOrderNo, param.getId().toString())
                        .eq(CommonFileAttachmentPo::getIsDel, false)
                        .eq(CommonFileAttachmentPo::getSourceTable, StoreDiscountApprovalServiceImpl.TABLE_NAME)
        );
        BasePageData<CommonFileAttachmentDto> pageData = new BasePageData<>(page);
        pageData.setRecords(page.getRecords().stream().map(item -> BeanCopierUtil.copy(item, CommonFileAttachmentDto.class)).collect(Collectors.toList()));
        return pageData;
    }
}
