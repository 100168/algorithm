package com.jiduauto.sps.order.server.facade;

public interface TestMultiplyDatabaseService {

    void testMultiplyDatabase();
}
