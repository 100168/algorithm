package com.jiduauto.sps.order.server.client.req;

import com.jiduauto.sps.sdk.pojo.req.SpsBaseReq;

import java.util.List;

/**
 * 基础数据查询校验
 */
public class BaseDataSearchReq extends SpsBaseReq {

    /**
     * 零件编码
     */
    private List<String> materialCodes;


}
