package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.excel.StandardRecommendationListImportHandler;
import com.jiduauto.sps.order.server.mapper.StandardRecommendationListMapper;
import com.jiduauto.sps.order.server.pojo.dto.StandardRecommendationListDto;
import com.jiduauto.sps.order.server.pojo.po.StandardRecommendationListPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListEditReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListImportReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListPageReq;
import com.jiduauto.sps.order.server.service.IStandardRecommendationListService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.pojo.req.IdBatchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 标准推荐清单 服务实现类
 */
@Service
public class StandardRecommendationListServiceImpl extends ServiceImpl<StandardRecommendationListMapper, StandardRecommendationListPo> implements IStandardRecommendationListService {

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private StandardRecommendationListImportHandler standardRecommendationListImportHandler;

    /**
     * 分页查询
     */
    @Override
    public BasePageData<StandardRecommendationListDto> pageSearch(BasePageParam<StandardRecommendationListPageReq> req) {
        StandardRecommendationListPageReq param = req.getParam();
        IPage<StandardRecommendationListPo> page = page(new Page<>(req.getPage(), req.getSize()),
                Wrappers.lambdaQuery(StandardRecommendationListPo.class)
                        .eq(StandardRecommendationListPo::getBizType, param.getBizType())
                        .eq(StrUtil.isNotBlank(param.getStoreCode()), StandardRecommendationListPo::getStoreCode, param.getStoreCode())
                        .eq(StrUtil.isNotBlank(param.getMaterialCode()), StandardRecommendationListPo::getMaterialCode, param.getMaterialCode())
                        .in(CollUtil.isNotEmpty(param.getMaterialCodeList()), StandardRecommendationListPo::getMaterialCode, param.getMaterialCodeList())
                        .orderByDesc(StandardRecommendationListPo::getId)
        );

        BasePageData<StandardRecommendationListDto> pageData = new BasePageData<>(page);

        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(req.getParam().getBizType(), page.getRecords().stream()
                .map(StandardRecommendationListPo::getStoreCode).distinct().collect(Collectors.toList()), false);

        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(param.getBizType(), page.getRecords().stream()
                .map(StandardRecommendationListPo::getMaterialCode).distinct().collect(Collectors.toList()));

        pageData.setRecords(page.getRecords().stream().map(item -> {
            StandardRecommendationListDto dto = BeanCopierUtil.copy(item, StandardRecommendationListDto.class);
            dto.setStoreName(storePoMap.getOrDefault(item.getStoreCode(), new StorePo()).getStoreName());
            dto.setMaterialName(materialPoMap.getOrDefault(item.getMaterialCode(), new MaterialPo()).getMaterialName());
            return dto;
        }).collect(Collectors.toList()));
        return pageData;
    }

    /**
     * 删除
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(IdBatchReq req) {
        List<StandardRecommendationListPo> list = list(
                Wrappers.lambdaQuery(StandardRecommendationListPo.class)
                        .eq(StandardRecommendationListPo::getBizType, req.getBizType())
                        .in(StandardRecommendationListPo::getId, req.getIdList())
        );
        if (CollUtil.isEmpty(list) || list.size() != req.getIdList().size()) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        for (StandardRecommendationListPo po : list) {
            po.setDelUniqueKey(po.getId());
            updateById(po);
            removeById(po.getId());
        }
    }

    /**
     * 清空
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void clear(StandardRecommendationListPageReq req) {
        List<StandardRecommendationListPo> list = list(
                Wrappers.lambdaQuery(StandardRecommendationListPo.class)
                        .eq(StandardRecommendationListPo::getBizType, req.getBizType())
                        .eq(StrUtil.isNotBlank(req.getStoreCode()), StandardRecommendationListPo::getStoreCode, req.getStoreCode())
                        .eq(StrUtil.isNotBlank(req.getMaterialCode()), StandardRecommendationListPo::getMaterialCode, req.getMaterialCode())
        );
        if (CollUtil.isEmpty(list)) {
            return;
        }
        for (StandardRecommendationListPo po : list) {
            po.setDelUniqueKey(po.getId());
            updateById(po);
            removeById(po.getId());
        }
    }

    /**
     * 新增
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void add(StandardRecommendationListAddReq req) {
        checkQty(req.getMinQty(), req.getMaxQty());
        checkMaterialAndStore(req.getBizType(), req.getStoreCode(), req.getMaterialCode());
        if (getOne(req.getBizType(), req.getStoreCode(), req.getMaterialCode()) != null) {
            throw new BizException(SpsResponseCodeEnum.RECORD_EXIST);
        }
        StandardRecommendationListPo po = new StandardRecommendationListPo();
        BeanUtil.copyProperties(req, po);
        try {
            save(po);
        } catch (DuplicateKeyException e) {
            //业务类型+门店code+零件号 主键不重复
            throw new BizException(String.format("门店:[%s] 零件号:[%s]配置已存在", req.getStoreCode(), req.getMaterialCode()));
        }
    }

    /**
     * 编辑
     */
    @SuppressWarnings("OptionalGetWithoutIsPresent")
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void edit(StandardRecommendationListEditReq req) {
        checkQty(req.getMinQty(), req.getMaxQty());
        StandardRecommendationListPo po = getById(req.getId());
        if (po == null) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        MaterialPo materialPo = baseDataQuery.getMaterialPo(req.getBizType(), po.getMaterialCode()).get();
        if (Objects.equals(materialPo.getIsCustom(), "Y")) {
            throw new BizException("零件号不允许为定制件");
        }
        po.setMinQty(req.getMinQty());
        po.setMaxQty(req.getMaxQty());
        po.setUpdateTime(LocalDateTime.now());
        updateById(po);
    }

    /**
     * 导入
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ImportResultResp importExcel(String bizType, MultipartFile file) {
        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        ImportReturnDataInfo<ExtendExportDto<StandardRecommendationListImportReq>> resp = standardRecommendationListImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return resultResp;
    }

    private StandardRecommendationListPo getOne(String bizType,
                                                String storeCode,
                                                String materialCode) {
        return getOne(
                Wrappers.lambdaQuery(StandardRecommendationListPo.class)
                        .eq(StandardRecommendationListPo::getBizType, bizType)
                        .eq(StandardRecommendationListPo::getStoreCode, storeCode)
                        .eq(StandardRecommendationListPo::getMaterialCode, materialCode)
        );
    }

    public static void checkQty(Integer minQty, Integer maxQty) {
        if (minQty >= maxQty) {
            throw new BizException("最小数量不能大于等于最大数量");
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insertOrUpdate(List<StandardRecommendationListPo> list) {
        if (CollUtil.isEmpty(list)) {
            return;
        }
        list.forEach(item -> {
            StandardRecommendationListPo newPo = getOne(item.getBizType(), item.getStoreCode(), item.getMaterialCode());
            if (Objects.nonNull(newPo)) {
                updateStandardRecommend(item);
            } else {
                try {
                    save(item);
                } catch (DuplicateKeyException e) {
                    updateStandardRecommend(item);
                }
            }
        });
    }

    private void updateStandardRecommend(StandardRecommendationListPo po) {
        update(po, Wrappers.lambdaQuery(StandardRecommendationListPo.class)
                .eq(StandardRecommendationListPo::getBizType, po.getBizType())
                .eq(StandardRecommendationListPo::getMaterialCode, po.getMaterialCode())
                .eq(StandardRecommendationListPo::getStoreCode, po.getStoreCode()));
    }

    @Override
    public void checkMaterialAndStore(String bizType, String storeCode, String materialCode) {
        baseDataQuery.getStorePo(bizType, storeCode, true);
        MaterialPo materialPo = baseDataQuery.getMaterialPo(bizType, materialCode).orElseThrow(
                () -> new BizException(String.format("零件号[%s]不存在", materialCode))
        );
        if (Objects.equals(materialPo.getIsCustom(), "Y")) {
            throw new BizException("零件号不允许为定制件");
        }
    }
}
