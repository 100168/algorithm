package com.jiduauto.sps.order.server.facade;


import com.jiduauto.sps.order.server.pojo.dto.InternalPurchaseOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalPurchaseOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;

import java.util.List;

/**
 * @author panjian
 */
public interface PurchaseOrderFacadeService {

    /**
     * 采购订单创建接口
     *
     * @param request
     * @return
     */
    BaseResult<String> internalAdd(InternalPurchaseOrderAddReq request);

    /**
     * 手工提交
     *
     * @param request
     * @return BaseResult
     */
    BaseResult<String> internalCommit(InternalPoCommitReq request);

    /**
     * 外部删除
     *
     * @param request
     * @return BaseResult
     */
    BaseResult<String> internalDelete(InternalPoDeleteReq request);

    /**
     * 外部采购订单列表查询
     *
     * @param pageParam
     * @return
     */
    BasePageData<InternalPurchaseOrderDto> internalPageSearch(BasePageParam<InternalPoSearchReq> pageParam);

    /**
     * 外部采购订单明细列表查询
     *
     * @param pageSearchReq
     * @return
     */
    BasePageData<InternalPurchaseOrderDetailDto> internalDetailPageSearch(BasePageParam<PurchaseOrderDetailSearchReq> pageSearchReq);

    /**
     * 采购订单批量查询
     * @param listSearchReq 列表查询
     * @return list
     */
    List<InternalPurchaseOrderDto> list(PurchaseOrderListSearchReq listSearchReq);
}
