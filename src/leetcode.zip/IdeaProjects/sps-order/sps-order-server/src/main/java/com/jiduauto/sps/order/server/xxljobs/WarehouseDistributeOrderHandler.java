package com.jiduauto.sps.order.server.xxljobs;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Lists;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.enums.BizTypeEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderStatusEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.BasePo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.text.StrSubstitutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class WarehouseDistributeOrderHandler {


    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private WebhookUtil webhookUtil;

    private String wdOrderNoticeUrl = null;
    @Value("${wd.order.notice.webhook.url:}")
    public void setWdOrderNoticeUrl(String wdOrderNoticeUrl) {
        this.wdOrderNoticeUrl = wdOrderNoticeUrl;
    }


    @XxlJob("wdOrderReOccupy")
    public ReturnT<String> warehouseDistributeOrderReOccupy(String param) throws Exception {
        log.info("WarehouseDistributeOrderHandler start, param: {}", param);
        warehouseDistributeOrderService.reOccupy();
        return ReturnT.SUCCESS;
    }

    @XxlJob("wdOrderNotice")
    public ReturnT<String> wdOrderNotice(String param) throws Exception {
        log.info("WarehouseDistributeOrderHandler start, param: {}", param);
        LocalDate threeDayBefore = LocalDate.now().plusDays(-3);
        LocalDate tenDayBefore = LocalDate.now().plusDays(-10);
        List<WarehouseDistributeOrderPo> list = warehouseDistributeOrderService.list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                .eq(WarehouseDistributeOrderPo::getBizType, BizTypeEnum.SM.getBizType())
                .in(WarehouseDistributeOrderPo::getOrderType, Lists.newArrayList(WarehouseDistributeOrderTypeEnum.SM11.getValue(), WarehouseDistributeOrderTypeEnum.SM12.getValue()))
                .notIn(WarehouseDistributeOrderPo::getOrderStatus, Lists.newArrayList(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode(),WarehouseDistributeOrderStatusEnum.CANCELED.getCode()))
                .le(BasePo::getCreateTime, threeDayBefore)
                .ge(BasePo::getCreateTime,tenDayBefore));
        if (!list.isEmpty()) {
            String s = fillWdNoticed(list);
            webhookUtil.sendMarkdownMessage(wdOrderNoticeUrl, s,"商城退货未到货提醒");
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 商城订单 -DHL 未发货 提醒
     * @param param
     * @return
     * @throws Exception
     */
    @XxlJob("wdOrderDelayOutbound")
    public ReturnT<String> wdOrderDelayOutbound(String param) throws Exception {
        log.info("wdOrderDelayOutbound  start, param: {}", param);
        LocalDate twoDayBefore = LocalDate.now().plusDays(-2);
        List<WarehouseDistributeOrderPo> list = warehouseDistributeOrderService.list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                .eq(WarehouseDistributeOrderPo::getBizType, BizTypeEnum.SM.getBizType())
                .eq(WarehouseDistributeOrderPo::getOrderType, WarehouseDistributeOrderTypeEnum.SM20.getValue())
                .eq(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.DELIVERED.getCode())
                .le(BasePo::getCreateTime,twoDayBefore));
        if (!list.isEmpty()) {
            String s = fillWdDelayNoticed(list);
            webhookUtil.sendMarkdownMessage(wdOrderNoticeUrl, s,"以下商城销售订单未及时出库，请及时干预处理");
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 创建消息
     * @return map
     */
    public Map<String, String> buildWdOrderMsgMap(WarehouseDistributeOrderPo orderPo) {
        Map<String, String> contentMap = new HashMap<>();
        contentMap.put("businessNo", orderPo.getBusinessBillNo());
        contentMap.put("wdOrderNo", orderPo.getOrderNo());
        contentMap.put("logisticNo", orderPo.getLogisticNo());
        contentMap.put("deliverTime", orderPo.getCreateTime().toLocalDate().toString());
        return contentMap;
    }
    public String fillWdNoticed(List<WarehouseDistributeOrderPo> list) {
        StringBuilder sb = new StringBuilder();
        sb.append("**未到货提醒**\n");
        for (WarehouseDistributeOrderPo warehouseDistributeOrderPo : list) {
            Map<String, String> contentMap = buildWdOrderMsgMap(warehouseDistributeOrderPo);
            String content =
                    "业务单号: <font color='comment'> ${businessNo}</font>\n" +
                            "仓配订单号: <font color='comment'>${wdOrderNo}</font>\n" +
                            "物流单号: <font color='comment'>${logisticNo}</font>\n" +
                            "发货时间: <font color='comment'>${deliverTime}</font>\n";
            sb.append(new StrSubstitutor(contentMap).replace(content));
        }
        return sb.toString();
    }

    public String fillWdDelayNoticed(List<WarehouseDistributeOrderPo> list) {
        StringBuilder sb = new StringBuilder();
        for (WarehouseDistributeOrderPo warehouseDistributeOrderPo : list) {
            Map<String, String> contentMap = buildWdOrderMsgMap(warehouseDistributeOrderPo);
            String content =
                            "<font color='comment'>${wdOrderNo}</font>; ";
            sb.append(new StrSubstitutor(contentMap).replace(content));
        }
        return sb.toString();
    }
}
