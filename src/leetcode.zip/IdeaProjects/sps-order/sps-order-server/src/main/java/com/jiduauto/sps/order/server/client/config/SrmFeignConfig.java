package com.jiduauto.sps.order.server.client.config;

import feign.Util;
import feign.auth.BasicAuthRequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;

/**
 * @author panjian
 */
public class SrmFeignConfig {

    @Value("${auth.basic.srm.username}")
    private String username;

    @Value("${auth.basic.srm.password}")
    private String password;

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password, Util.UTF_8);
    }
}
