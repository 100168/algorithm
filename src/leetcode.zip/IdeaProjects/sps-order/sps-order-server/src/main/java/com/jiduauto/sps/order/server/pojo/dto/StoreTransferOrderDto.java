package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @ClassName StoreTransferOrderDto
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2024/1/12 10:37
 */
@Data
public class StoreTransferOrderDto implements Serializable {
    /**
     * 主键
     */
    private Long id;

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 调拨单号
     */
    private String orderNo;

    /**
     * sap单号
     */
    private String sapOrderNo;

    /**
     * 订单归属(售后自营101 售后授权102)
     */
    private String orderAttr;

    /**
     * 订单归属名称
     */
    private String orderAttrName;

    /**
     * 订单总金额
     */
    private BigDecimal orderAmount;

    /**
     * 调入组织编码
     */
    private String transferInOrganizationCode;

    /**
     * 调入组织名称
     */
    private String transferInOrganizationName;

    /**
     * 调入仓库编码
     */
    private String transferInWarehouseCode;
    /**
     * 调入仓库名称
     */
    private String transferInWarehouseName;

    /**
     * 调入地址
     */
    private String transferInAddress;

    /**
     * 调入联系人
     */
    private String transferInContactName;

    /**
     * 调入联系人电话
     */
    private String transferInContactMobile;

    /**
     * 调出组织编码
     */
    private String transferOutOrganizationCode;
    private String transferOutOrganizationName;

    /**
     * 调出仓库编码
     */
    private String transferOutWarehouseCode;
    private String transferOutWarehouseName;

    /**
     * 调出地址
     */
    private String transferOutAddress;

    /**
     * 调出联系人
     */
    private String transferOutContactName;

    /**
     * 调出联系人电话
     */
    private String transferOutContactMobile;

    /**
     * 订单提报时间
     */
    private LocalDateTime commitTime;

    /**
     * ("WAIT_COMMIT", "待提交"),
     * ("COMMITTED", "已提交"),
     * ("CANCELED", "已取消"),
     * ("CONFIRM", "已确认"),
     * ("PART_OUT", "部分调出"),
     * ("ALL_OUT", "已调出"),
     * ("ALL_IN", "已完成"),
     */
    private String orderStatus;
    private String orderStatusName;

    /**
     * 物流单号
     */
    private String logisticsNo;

    /**
     * 物流公司
     */
    private String logisticsCompany;
    /**
     * SAP 创建时间
     */
    private LocalDateTime sapOrderCreateTime;

    /**
     * 总数量
     */
    private BigDecimal totalQty;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建者
     */
    private String createUser;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新者
     */
    private String updateUser;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 确认人
     */
    private String confirmUser;
}
