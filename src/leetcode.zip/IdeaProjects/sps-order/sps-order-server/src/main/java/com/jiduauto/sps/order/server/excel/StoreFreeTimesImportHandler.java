package com.jiduauto.sps.order.server.excel;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.excel.check.StoreFreeTimesImportBatchPreCheck;
import com.jiduauto.sps.order.server.pojo.po.StoreFreeTimesPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreFreeTimesImportReq;
import com.jiduauto.sps.order.server.service.IStoreFreeTimesService;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.handler.ExtendImportHandler;
import com.jiduauto.sps.sdk.service.impl.BosServiceImpl;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class StoreFreeTimesImportHandler  extends ExtendImportHandler<StoreFreeTimesImportReq> {

    @Resource
    private IStoreFreeTimesService storeFreeTimesService;


    public StoreFreeTimesImportHandler(List<BatchPreCheck<StoreFreeTimesImportReq>> batchChecks, BosServiceImpl bosService) {
        super.bosService = bosService;
        this.batchChecks = batchChecks;
        super.eClass = StoreFreeTimesImportReq.class;
    }

    @Override
    protected void saveData(List<ExtendExportDto<StoreFreeTimesImportReq>> extendExportDto) {
        List<StoreFreeTimesImportReq> list = extendExportDto.stream().map(ExtendExportDto::getT).collect(Collectors.toList());
        List<String> storeCodes = list.stream().map(StoreFreeTimesImportReq::getStoreCode).collect(Collectors.toList());
        List<String> orderTypes = list.stream().map(StoreFreeTimesImportReq::getOrderType).collect(Collectors.toList());
        List<StoreFreeTimesPo> storeFreeTimesPos = storeFreeTimesService.list(Wrappers.<StoreFreeTimesPo>lambdaQuery().in(StoreFreeTimesPo::getStoreCode, storeCodes).in(StoreFreeTimesPo::getOrderType, orderTypes));
        Map<String, StoreFreeTimesPo> storeFreeTimesPosMap = storeFreeTimesPos.stream().collect(Collectors.toMap( e -> e.getStoreCode() + "_" + e.getOrderType(), e -> e,(e, e2) -> e));
        List<StoreFreeTimesPo> newList = new ArrayList<>();
        String bizType = BizTypeThreadHolder.getBizType();

        for(StoreFreeTimesImportReq req : list) {
            String key = req.getStoreCode() + "_" + req.getOrderType();
            if (storeFreeTimesPosMap.containsKey(key)) {
                StoreFreeTimesPo storeFreeTimesPo = storeFreeTimesPosMap.get(key);
                StoreFreeTimesPo update = new StoreFreeTimesPo();
                update.setId(storeFreeTimesPo.getId());
                update.setFreeTimes(Integer.parseInt(req.getFreeTimes()));
                storeFreeTimesService.updateById(update);
            } else {
                StoreFreeTimesPo storeFreeTimesPo = BeanCopierUtil.copy(req, StoreFreeTimesPo.class);
                storeFreeTimesPo.setFreeTimes(Integer.parseInt(req.getFreeTimes()));
                storeFreeTimesPo.setBizType(bizType);
                newList.add(storeFreeTimesPo);
            }
        }
        storeFreeTimesService.saveBatch(newList);
    }
}
