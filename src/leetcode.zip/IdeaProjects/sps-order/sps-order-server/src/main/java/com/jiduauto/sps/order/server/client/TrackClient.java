package com.jiduauto.sps.order.server.client;

import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.client.req.TrackDetailReq;
import com.jiduauto.sps.order.server.client.resp.TrackDetailResp;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * 能源平台api
 */

@FeignClient(name = "track-query", url = "${track.server.url:http://track:8080}", fallbackFactory = TrackClient.TrackClientFallbackFactory.class)
public interface TrackClient {

    /**
     * 轨迹明细
     *
     * @param
     * @return
     */
    @PostMapping("/track/detail")
    BaseResult<TrackDetailResp> trackDetail(@RequestBody TrackDetailReq trackDetailReq);

    @Slf4j
    @Component
    class TrackClientFallbackFactory implements FallbackFactory<TrackClient> {

        @Override
        public TrackClient create(Throwable throwable) {
            return new TrackClient() {
                @Override
                public BaseResult<TrackDetailResp> trackDetail(TrackDetailReq trackDetailReq) {
                    log.warn(String.format("TrackClient#trackDetail error, param: %s", JsonUtil.ObjectToJson(trackDetailReq)), throwable);
                    return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }
            };
        }
    }
}
