package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.sps.order.server.pojo.dto.InternalStoreTransferOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalStoreTransferOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderFacadeService;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 智子门店调拨单
 */
@RestController
@RequestMapping("/internal/storeTransferOrder")
public class InternalStoreTransferOrderController {

    @Resource
    private IStoreTransferOrderFacadeService storeTransferOrderFacadeService;

    /**
     * 调拨订单创建接口
     *
     * @return 订单号
     */
    @PostMapping("/add")
    public BaseResult<String> add(@RequestBody @Valid InternalStoreTransferOrderAddReq req) {
        return storeTransferOrderFacadeService.add(req);
    }

    /**
     * 调拨单订单提交接口
     *
     * @return 订单号
     */
    @PostMapping("/commit")
    public BaseResult<String> commit(@RequestBody @Valid InternalStoreTransferOrderOperateReq request) {
        return storeTransferOrderFacadeService.internalCommit(request);
    }

    /**
     * 调拨订单更新接口
     */
    @PostMapping("/update")
    public BaseResult<String> updateOrder(@RequestBody @Valid InternalStoreTransferOrderUpdateReq req) {
        return storeTransferOrderFacadeService.updateOrder(req);
    }

    /**
     * 调拨订单取消接口
     */
    @PostMapping("/cancel")
    public BaseResult<String> cancel(@RequestBody @Valid InternalStoreTransferOrderOperateReq req) {
        return storeTransferOrderFacadeService.cancelOrder(req);
    }

    /**
     * 调拨订单确认接口
     */
    @PostMapping("/confirm")
    public BaseResult<String> confirm(@RequestBody @Valid InternalStoreTransferOrderOperateReq req) {
        return storeTransferOrderFacadeService.internalConfirm(req);
    }

    /**
     * 门店调拨单 分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<InternalStoreTransferOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<InternalStoreTransferOrderReq> pageParam) {
        return BaseResult.OK(storeTransferOrderFacadeService.pageSearch(pageParam));
    }

    /**
     * 调拨单明细分页查询接口
     */
    @PostMapping("/detail/pageSearch")
    public BaseResult<BasePageData<InternalStoreTransferOrderDetailDto>> internalDetailPageSearch(@RequestBody @Valid BasePageParam<InternalStoreTransferOrderDetailSearchReq> pageSearchReq) {
        return BaseResult.OK(storeTransferOrderFacadeService.internalDetailPageSearch(pageSearchReq));
    }
}
