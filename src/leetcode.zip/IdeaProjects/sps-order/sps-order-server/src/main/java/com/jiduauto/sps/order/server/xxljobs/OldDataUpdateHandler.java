package com.jiduauto.sps.order.server.xxljobs;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Lists;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.StockInMapBusinessHandler;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.WarehouseDistributeOrderAllPo;
import com.jiduauto.sps.order.server.mq.consumer.SMOrderCompleteConsumer;
import com.jiduauto.sps.order.server.service.IPurchaseOrderPartTransferOperateService;
import com.jiduauto.sps.order.server.service.IPurchaseOrderService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
public class OldDataUpdateHandler {

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @Resource
    private IPurchaseOrderPartTransferOperateService purchaseOrderPartTransferOperateService;

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private SMOrderCompleteConsumer smOrderCompleteConsumer;

    @Resource
    private SpsClient spsClient;

    @Resource
    private WebhookUtil webhookUtil;

    @Resource
    private StockInMapBusinessHandler stockInMapBusinessHandler;

    /**
     * 根据 BO SO 收货&取消数量去更新历史采购订单状态
     */
    @Deprecated
    @XxlJob("poOldDataUpdateHandler")
    public ReturnT<String> poOldDataUpdateHandler(String param) {
        try {
            log.info("poOldDataUpdateHandler start, param: {}", param);
            //只更新 已转单成功的历史数据
            List<PurchaseOrderPo> list = purchaseOrderService.list(
                    Wrappers.<PurchaseOrderPo>lambdaQuery()
                            .eq(PurchaseOrderPo::getPurchaseOrderStatus, PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL.getCode())
            );
            if (CollUtil.isEmpty(list)) {
                return ReturnT.SUCCESS;
            }
            List<String> collect = list.stream().map(PurchaseOrderPo::getPurchaseOrderNo).collect(Collectors.toList());
            log.info("poOldDataUpdateHandler#poList:{}", JsonUtil.toJsonString(collect));
            list.forEach(o -> purchaseOrderService.updateStateByReceiveQtyAndCancelQty(o.getPurchaseOrderNo(), o.getBizType()));
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("poOldDataUpdateHandler");
            log.error("poOldDataUpdateHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 管控件失败兜底 job
     */
    @XxlJob("poControlPartTurnFailHandler")
    public ReturnT<String> poControlPartTurnFailHandler(String param) {
        try {
            log.info("poControlPartTurnFailHandler start, param: {}", param);
            List<PurchaseOrderPartTransferOperatePo> list = purchaseOrderPartTransferOperateService.list(
                    Wrappers.<PurchaseOrderPartTransferOperatePo>lambdaQuery()
                            .eq(PurchaseOrderPartTransferOperatePo::getTurnStatus, PoPartTurnStatus.PENDING.getCode())
            );
            if (CollUtil.isEmpty(list)) {
                return ReturnT.SUCCESS;
            }
            List<Long> collect = list.stream().map(PurchaseOrderPartTransferOperatePo::getId).collect(Collectors.toList());
            log.info("poControlPartTurnFailHandler#updateList:{}", JsonUtil.toJsonString(collect));
            list.forEach(o -> purchaseOrderService.controlTransferJob(o));
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("poControlPartTurnFailHandler");
            log.error("poControlPartTurnFailHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 修复商城因dhl返回出库结果超时导致流程异常产生的问题数据 job
     */
    @XxlJob("smWdOrderErrorStatusDataFixHandler")
    public ReturnT<String> smWdOrderErrorStatusDataFixHandler(String param) {
        try {
            log.info("smWdOrderErrorStatusDataFixHandler start, param: {}", param);
            String maxDate = LocalDate.now().plusDays(-10).toString();
            if (StrUtil.isNotEmpty(param)) {
                maxDate = param;
            }
            List<WarehouseDistributeOrderPo> list = warehouseDistributeOrderService.list(
                    Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                            .eq(WarehouseDistributeOrderPo::getBizType, BizTypeEnum.SM.getBizType())
                            .eq(WarehouseDistributeOrderPo::getOrderType, WarehouseDistributeOrderTypeEnum.SM20.getValue())
                            .in(WarehouseDistributeOrderPo::getOrderStatus, Lists.newArrayList(
                                    WarehouseDistributeOrderStatusEnum.DELIVERED.getCode(),
                                    WarehouseDistributeOrderStatusEnum.SHIPPED.getCode(),
                                    WarehouseDistributeOrderStatusEnum.OUT_STOCK_COMPLETED.getCode())
                            )
                            .le(WarehouseDistributeOrderPo::getCreateTime, maxDate)
                            .orderByAsc(WarehouseDistributeOrderPo::getCreateTime)
                            .last("limit 50")
            );
            if (CollUtil.isEmpty(list)) {
                return ReturnT.SUCCESS;
            }
            for (WarehouseDistributeOrderPo orderPo : list) {
                smOrderCompleteConsumer.smWdOrderErrorStatusDataFix(orderPo);
            }
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("smWdOrderErrorStatusDataFixHandler");
            log.error("smWdOrderErrorStatusDataFixHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 修复商城因dhl返回出库结果超时导致流程异常产生的问题数据 job
     */
    @XxlJob("smWdOrderErrorStatusDataFixByOrderNoHandler")
    public ReturnT<String> smWdOrderErrorStatusDataFixByOrderNoHandler(String param) {
        try {
            WarehouseDistributeOrderPo orderPo = warehouseDistributeOrderService.getByOrderNo(
                    BizTypeEnum.SM.getBizType(), param
            );
            if (Objects.isNull(orderPo)) {
                return ReturnT.SUCCESS;
            }
            smOrderCompleteConsumer.smWdOrderErrorStatusDataFix(orderPo);

        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("smWdOrderErrorStatusDataFixHandler");
            log.error("smWdOrderErrorStatusDataFixHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }


    /**
     * 更新商城历史数据状态 only in v1.16.2 , 后期版本删除 todo(shaofei.xie)
     */
    @XxlJob("updateSMOldDataStatus")
    public ReturnT<String> updateSMOldDataStatus(String param) {
        try {
            log.info("smWdOrderErrorStatusDataFixHandler start, param: {}", param);
            String maxDate = LocalDate.now().plusDays(-10).toString();
            if (StrUtil.isNotEmpty(param)) {
                maxDate = param;
            }
            List<WarehouseDistributeOrderPo> list = warehouseDistributeOrderService.list(
                    Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                            .eq(WarehouseDistributeOrderPo::getBizType, BizTypeEnum.SM.getBizType())
                            .eq(WarehouseDistributeOrderPo::getOrderType, WarehouseDistributeOrderTypeEnum.SM20.getValue())
                            .in(WarehouseDistributeOrderPo::getOrderStatus, Lists.newArrayList(
                                    WarehouseDistributeOrderStatusEnum.DELIVERED.getCode(),
                                    WarehouseDistributeOrderStatusEnum.SHIPPED.getCode(),
                                    WarehouseDistributeOrderStatusEnum.OUT_STOCK_COMPLETED.getCode()))
                            .lt(WarehouseDistributeOrderPo::getCreateTime, maxDate)
                            .orderByAsc(WarehouseDistributeOrderPo::getCreateTime)
                            .last("limit 1000")
            );
            if (CollUtil.isEmpty(list)) {
                return ReturnT.SUCCESS;
            }
            log.info("updateSMOldDataStatus#list:{}",
                    JsonUtil.toJsonString(list.stream().map(WarehouseDistributeOrderPo::getOrderNo).collect(Collectors.toList())));
            for (WarehouseDistributeOrderPo po : list) {
                if (StrUtil.isEmpty(po.getLogisticNo())) {
                    continue;
                }
                OrderNoReq orderNoReq = new OrderNoReq();
                orderNoReq.setOrderNo(po.getOrderNo());
                orderNoReq.setBizType(po.getBizType());
                BaseResult<List<SaleOrderOutboundParamPo>> ret = spsClient.getSaleOrderOutParamList(orderNoReq).check();
                if (CollUtil.isEmpty(ret.getData())) {
                    //历史数据 更新状态
                    po.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
                    warehouseDistributeOrderService.updateById(po);
                }
            }
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("updateSMOldDataStatus");
            log.error("updateSMOldDataStatus error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 修复仓配订单历史数据状态*/
    @XxlJob("updateOldDataStatusByOrderNo")
    public ReturnT<String> updateOldDataStatusByOrderNo(String param) {
        try {
            if (StrUtil.isBlank(param)) {
                return ReturnT.SUCCESS;
            }
            WarehouseDistributeOrderPo orderPo = warehouseDistributeOrderService.getOne(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery().eq(WarehouseDistributeOrderPo::getOrderNo,param));
            if (Objects.isNull(orderPo)) {
                return ReturnT.SUCCESS;
            }
            orderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
            warehouseDistributeOrderService.updateById(orderPo);
        } catch (Exception e) {
            log.error("updateSMOldDataStatus error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 修复快反历史数据状态*/
    @XxlJob("updateQE12OldDataStatus")
    public ReturnT<String> updateQE12OldDataStatus(String param) {
        try {
            String maxDate = LocalDate.now().plusDays(-10).toString();
            if (StrUtil.isNotEmpty(param)) {
                maxDate = param;
            }
            List<WarehouseDistributeOrderPo> list = warehouseDistributeOrderService.list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                    .eq(WarehouseDistributeOrderPo::getOrderType,"QE12")
                    .in(WarehouseDistributeOrderPo::getOrderStatus,WarehouseDistributeOrderStatusEnum.SHIPPED.getCode(),WarehouseDistributeOrderStatusEnum.DELIVERED.getCode())
                    .lt(WarehouseDistributeOrderPo::getCreateTime,maxDate)
            );

            for (WarehouseDistributeOrderPo orderPo : list) {
                orderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
            }
            warehouseDistributeOrderService.updateBatchById(list);
        } catch (Exception e) {
            log.error("updateSMOldDataStatus error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }


    /**
     * 商城履约完成同步sap&出库修复 job
     */
    @XxlJob("smDataFix")
    public ReturnT<String> smDataFix(String param) {
        try {
            String[] split = param.split(",");
            List<WarehouseDistributeOrderPo> list = warehouseDistributeOrderService.list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                    .eq(WarehouseDistributeOrderPo::getOrderType, WarehouseDistributeOrderTypeEnum.SM20.getValue())
                    .gt(BasePo::getCreateTime, split[0])
                    .lt(BasePo::getCreateTime, split[1])
                    .eq(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.COMPLETED.getCode())
            );
            if (CollUtil.isEmpty(list)) {
                return ReturnT.SUCCESS;
            }
            for (WarehouseDistributeOrderPo po : list) {
                smOrderCompleteConsumer.smWdOrderErrorStatusDataFix(po);
            }
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("smWdOrderErrorStatusDataFixHandler");
            log.error("smWdOrderErrorStatusDataFixHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 商城履约完成同步sap&出库修复 job
     */
    @XxlJob("oldToInOrder")
    public ReturnT<String> oldToInOrder (String param) {
        try {
            List<WarehouseDistributeOrderPo> list = warehouseDistributeOrderService.list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                    .in(WarehouseDistributeOrderPo::getLogisticType, Lists.newArrayList(WarehouseDistributeOrderlogisticTypeEnum.TRANSPORT_AND_PUT_IN.getValue(), WarehouseDistributeOrderlogisticTypeEnum.STOCK_TRANSFER.getValue()))
            );
            for (WarehouseDistributeOrderPo orderPo : list) {
                WarehouseDistributeOrderAllPo allPo = warehouseDistributeOrderService.buildAllPo(orderPo);
                stockInMapBusinessHandler.process(allPo);
            }
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("smWdOrderErrorStatusDataFixHandler");
            log.error("smWdOrderErrorStatusDataFixHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 在途库存出库
     */
    @XxlJob("outOfVmStock")
    public ReturnT<String> outOfVmStock (String param) {
        OrderNoReq orderNoReq = new OrderNoReq();
        orderNoReq.setOrderNo(param);
        orderNoReq.setBizType("SM");
        spsClient.outOfVmStock(orderNoReq);
        return ReturnT.SUCCESS;
    }
}
