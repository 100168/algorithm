package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountDto;
import com.jiduauto.sps.order.server.pojo.fileexport.StoreDiscountExportDto;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalDetailPo;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountPo;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreDiscountListReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountPageReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

import java.util.List;

/**
 * <p>
 * 门店折扣表 服务类
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
public interface IStoreDiscountService extends IService<StoreDiscountPo> {

    void insertOrUpdate(List<StoreDiscountApprovalDetailPo> detailPoList);

    BasePageData<StoreDiscountDto> pageSearch(BasePageParam<StoreDiscountPageReq> pageParam);

    List<StoreDiscountExportDto> export(BasePageParam<StoreDiscountPageReq> pageParam);

    /**
     * 查询门店折扣
     */
    List<StoreDiscountDto> listEffectiveDiscount(InternalStoreDiscountListReq req);
}
