package com.jiduauto.sps.order.server.service;


import com.jiduauto.sps.sdk.client.req.AsnUpdateReq;
import com.jiduauto.sps.sdk.pojo.dto.AsnPartReceiveInfoDto;
import com.jiduauto.sps.sdk.pojo.dto.AsnReceivePartParam;
import com.jiduauto.sps.sdk.pojo.po.AsnBasicPo;
import com.jiduauto.sps.sdk.pojo.po.AsnDeliverInfoPo;

import java.util.List;
import java.util.Set;

public interface ISaleOrderUpdateService {

    void updateReceiveInfoByASN(AsnUpdateReq asnUpdateReq);

    /**
     * 创建ASN更新发货数量
     */
    void increaseDeliveryQtyForDfs(AsnBasicPo asnBasicPo, List<AsnDeliverInfoPo> asnDeliverInfoPos);

    /**
     * 删除ASN更新发货数量
     */
    void decreaseDeliveryQtyForDfs(AsnBasicPo asnBasicPo, List<AsnDeliverInfoPo> asnDeliverInfoPos);

    /**
     *
     */
    String increaseReceivedQtyForDfs(AsnBasicPo asnBasicPo, AsnDeliverInfoPo asnDeliverInfoPo, AsnReceivePartParam asnReceivePartParam);

    /**
     * 更新销售订单状态
     */
    void updateSaleOrderState(Set<String> saleOrderNo, String asnCode);

    /**
     * ASN欠收更新发货数量
     *
     * @param asnBasicPo
     * @param asnDeliverInfoPo
     * @param asnPartReceiveInfoDto
     */
    void decreaseDeliveryQtyForDfs(AsnBasicPo asnBasicPo, AsnDeliverInfoPo asnDeliverInfoPo, AsnPartReceiveInfoDto asnPartReceiveInfoDto);



}
