package com.jiduauto.sps.order.server.excel.check;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.excel.StoreDiscountApprovalDetailImportHandler;
import com.jiduauto.sps.order.server.mapper.StoreDiscountApprovalDetailMapper;
import com.jiduauto.sps.order.server.mapper.StoreDiscountApprovalMapper;
import com.jiduauto.sps.order.server.pojo.param.StoreDiscountApprovalDetailQueryParam;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalDetailPo;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalDetailImportReq;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.PurchaseOrderTypeEnum;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.handler.ExcelThreadLocalHolder;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.utils.DateUtils;
import com.jiduauto.sps.sdk.utils.NumberUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Component
public class StoreDiscountApprovalDetailBatchPreCheck implements BatchPreCheck<StoreDiscountApprovalDetailImportReq> {

    private static final Pattern EFFECTIVE_START_DATE_PATTERN = Pattern.compile(BaseConstants.Regex.SALE_PRICE_EFFECTIVE_START_DATE);

    public final static String KEY_APPROVAL_ID = "KEY_APPROVAL_ID";

    @Value("${store-discount.config.max-detail-size:10000}")
    private Integer maxDetailSize;

    @Resource
    private StoreDiscountApprovalMapper storeDiscountApprovalMapper;
    @Resource
    private StoreDiscountApprovalDetailMapper storeDiscountApprovalDetailMapper;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Override
    public void invoke(List<ExtendExportDto<StoreDiscountApprovalDetailImportReq>> extendExportDtos) {
        String bizType = BizTypeThreadHolder.getBizType();
        StoreDiscountApprovalPo approvalPo = checkAndGetApprovalPo(ExcelThreadLocalHolder.getLong(KEY_APPROVAL_ID), bizType);
        if ((approvalPo.getDetailQuantity() + extendExportDtos.size()) > maxDetailSize) {
            throw new BizException(String.format("单条审核单价格明细不能超过%d条", maxDetailSize));
        }
        ExcelThreadLocalHolder.put(StoreDiscountApprovalDetailImportHandler.KEY_STORE_DISCOUNT_APPROVAL, approvalPo);
        List<String> salePartNums = extendExportDtos.stream().map(ExtendExportDto::getT).map(StoreDiscountApprovalDetailImportReq::getMaterialCode).filter(StringUtils::isNotEmpty).distinct().collect(Collectors.toList());
        List<String> storeCodes = extendExportDtos.stream().map(ExtendExportDto::getT).map(StoreDiscountApprovalDetailImportReq::getStoreCode).filter(StringUtils::isNotEmpty).distinct().collect(Collectors.toList());
        Map<String, MaterialPo> materialMap = baseDataQuery.mapMaterialPo(bizType, salePartNums, false);
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(bizType, storeCodes, false);
        ExcelThreadLocalHolder.put(StoreDiscountApprovalDetailImportHandler.KEY_MATERIAL_MAP, materialMap);

        for (ExtendExportDto<StoreDiscountApprovalDetailImportReq> extendExportDto : extendExportDtos) {
            StoreDiscountApprovalDetailImportReq importReq = extendExportDto.getT();
            StringBuilder errors = new StringBuilder();

            if (StrUtil.isBlank(importReq.getStoreCode())) {
                errors.append("门店code为空;");
            } else if (!storePoMap.containsKey(importReq.getStoreCode())) {
                errors.append("门店code不存在;");
            }

            if (StrUtil.isNotBlank(importReq.getMaterialCode()) && !materialMap.containsKey(importReq.getMaterialCode())) {
                errors.append("售后件号不存在;");
            }

            if (StrUtil.isBlank(importReq.getOrderType())) {
                errors.append("订单类型为空;");
            } else if (!PurchaseOrderTypeEnum.hasValue(importReq.getOrderType())) {
                errors.append("订单类型不存在;");
            }

            if (!NumberUtil.isNumeric(importReq.getDiscountRate())) {
                errors.append("折扣不正确;");
            } else if (BigDecimal.ONE.compareTo(new BigDecimal(importReq.getDiscountRate())) > 0) {
                errors.append("折扣不能小于1;");
            }

            if (StringUtils.isEmpty(importReq.getEffectiveStartDateStr())) {
                errors.append("有效开始日期为空;");
            } else if (!EFFECTIVE_START_DATE_PATTERN.matcher(importReq.getEffectiveStartDateStr()).matches()) {
                errors.append("有效开始日期格式不正确;");
            } else if (DateUtil.parseLocalDateTime(importReq.getEffectiveStartDateStr(), DateUtils.SHORT_DATE_FORMAT).toLocalDate().isBefore(LocalDate.now())) {
                errors.append("有效开始日期必须大于等于当前日期");
            }
            extendExportDto.setCheckResult(errors.toString());
        }

        List<ExtendExportDto<StoreDiscountApprovalDetailImportReq>> correctList = extendExportDtos.stream()
                .filter(item -> StringUtils.isEmpty(item.getCheckResult()))
                .collect(Collectors.toList());
        if (CollUtil.isEmpty(correctList)) {
            return;
        }

        List<String> excelDuplicateUniqueIds = correctList.stream().map(ExtendExportDto::getT).collect(Collectors.toMap(this::concatUniqueId, item -> 1, Integer::sum))
                .entrySet().stream()
                .filter(item -> item.getValue() > 1)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
        if (CollUtil.isNotEmpty(excelDuplicateUniqueIds)) {
            for (ExtendExportDto<StoreDiscountApprovalDetailImportReq> extendExportDto : correctList) {
                if (excelDuplicateUniqueIds.contains(concatUniqueId(extendExportDto.getT()))) {
                    extendExportDto.setCheckResult("数据重复;");
                }
            }
        }

        Map<String, StoreDiscountApprovalDetailPo> approvalDetailPoMap = storeDiscountApprovalDetailMapper.listApprovalDetailPo(StoreDiscountApprovalDetailQueryParam.builder()
                        .bizType(BizTypeThreadHolder.getBizType())
                        .approvalId(approvalPo.getId())
                        .detailParams(correctList.stream()
                                .map(ExtendExportDto::getT)
                                .map(item -> {
                                    StoreDiscountApprovalDetailQueryParam.DetailParam detailParam = new StoreDiscountApprovalDetailQueryParam.DetailParam();
                                    BeanUtil.copyProperties(item, detailParam);
                                    detailParam.setMaterialCode(StrUtil.isBlank(item.getMaterialCode()) ? "" : item.getMaterialCode());
                                    LocalDateTime effectiveStartTime = LocalDate.parse(item.getEffectiveStartDateStr(), DateTimeFormatter.ofPattern(BaseConstants.DatePattern.NONE_DATE)).atTime(LocalTime.MIN);
                                    detailParam.setEffectiveStartTime(effectiveStartTime);
                                    return detailParam;
                                }).collect(Collectors.toList()))
                        .build())
                .stream().collect(Collectors.toMap(this::concatUniqueId, Function.identity(), (p, n) -> n));

        correctList.forEach(item -> {
            if (approvalDetailPoMap.containsKey(concatUniqueId(item.getT()))) {
                item.setCheckResult("数据已存在;");
            }
        });
    }

    private StoreDiscountApprovalPo checkAndGetApprovalPo(Long approvalId, String bizType) {
        StoreDiscountApprovalPo po = storeDiscountApprovalMapper.getById(approvalId, bizType);
        if (Objects.isNull(po)) {
            throw new BizException("审批单号不存在");
        }
        return po;
    }

    private String concatUniqueId(StoreDiscountApprovalDetailPo po) {
        return StringUtils.defaultString(po.getStoreCode()).concat("_")
                .concat(StringUtils.defaultString(po.getMaterialCode())).concat("_")
                .concat(StringUtils.defaultString(po.getOrderType())).concat("_")
                .concat(Objects.isNull(po.getEffectiveStartTime()) ? "" : DateUtils.format(po.getEffectiveStartTime(), BaseConstants.DatePattern.NONE_DATE));
    }

    private String concatUniqueId(StoreDiscountApprovalDetailImportReq req) {
        return StringUtils.defaultString(req.getStoreCode()).concat("_")
                .concat(StringUtils.defaultString(req.getMaterialCode())).concat("_")
                .concat(StringUtils.defaultString(req.getOrderType())).concat("_")
                .concat(StringUtils.defaultString(req.getEffectiveStartDateStr()));
    }
}
