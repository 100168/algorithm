package com.jiduauto.sps.order.server.handler;


import com.google.common.collect.Maps;

import java.util.Map;

/**
 * 导入通用线程变量
 */
public class WDOrderAddThreadLocalHolder {

    public final static String ORDER_TYPE = "ORDER_TYPE";
    public final static String LOGISTIC_TYPE = "LOGISTIC_TYPE";
    public final static String SOURCE_SYSTEM = "SOURCE_SYSTEM";
    public final static String SUPPLIER = "SUPPLIER";
    public final static String SHIPPING_METHOD = "SHIPPING_METHOD";

    private static final ThreadLocal<Map<String, Object>> threadLocal = ThreadLocal.withInitial(Maps::newHashMap);

    public static void put(String key, Object value) {
        threadLocal.get().put(key, value);
    }

    public static Object get(String key) {
        return threadLocal.get().get(key);
    }

    public static String getString(String key) {
        return getObject(key, String.class);
    }

    public static <T> T getObject(String key, Class<T> clazz) {
        Object value = threadLocal.get().get(key);
        return clazz.isInstance(value) ? (T) value : null;
    }

    public static void remove() {
        threadLocal.remove();
    }
}
