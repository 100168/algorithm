package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.order.server.client.ChargePartnerAuthClient;
import com.jiduauto.sps.order.server.client.ChargePartnerClient;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.order.server.convertor.EsTransferReqConvertor;
import com.jiduauto.sps.sdk.client.req.TransferOutToEsReq;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.DictItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/*
 * 下发dhl入库指令*/
@Component
public class TransferOutToESHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private ChargePartnerAuthClient chargePartnerAuthClient;


    @Resource
    private EsTransferReqConvertor esTransferReqConvertor;

    @Resource
    private SpsClient spsClient;


    /*出库同步能源*/
    @Override
    public void process(WarehouseDistributeOrderAllPo allPo) {

        WarehouseDistributeLogisticPo logisticPo = allPo.getWarehouseDistributeLogisticPo();
        BaseResult<List<DictItemPo>> specialWarehouse = spsClient.getSpecialWarehouse(logisticPo.getBizType());
        //不是G59仓库不需要下发能源
        if (specialWarehouse.getData().stream().anyMatch(dictItemPo -> dictItemPo.getItemCode().equals(logisticPo.getDeliverWarehouseCode()))) {
            return;
        }
        TransferOutToEsReq req = esTransferReqConvertor.transferOutToEsReq(allPo);
        ResultResp<Object> resp = chargePartnerAuthClient.createTransferOutWorkOrder(req);
        if (!resp.isSuccess()){
            throw new BizException(resp.getMsg());
        }

    }



    /*
     * 注册单前handler*/
    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.TRANSFER_OUT_TO_ES.getBitIndex(), this);
    }
}
