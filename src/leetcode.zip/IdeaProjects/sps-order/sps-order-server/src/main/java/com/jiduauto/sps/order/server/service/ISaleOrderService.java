package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.*;
import com.jiduauto.sps.order.server.pojo.fileexport.SaleOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.sdk.client.req.SOStockOutTimeAndDeliverQtyReq;
import com.jiduauto.sps.sdk.client.req.StockInItemQuantityDto;
import com.jiduauto.sps.sdk.client.req.StockOutItemQuantityDto;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import com.jiduauto.sps.sdk.pojo.req.CreatePrOrderReq;
import com.jiduauto.sps.sdk.pojo.req.DHLOutboundReq;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 * 销售订单 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface ISaleOrderService extends IService<SaleOrderPo> {

    /**
     * 销售订单分页查询
     *
     * @author dong.li
     * @date 4/14/23 2:18 PM
     */
    BasePageData<SaleOrderDto> pageSearch(BasePageParam<SaleOrderPageSearchReq> pageParam);

    /**
     * 销售订单所有明细查询  关键字 PO单单号集合
     * @param pageParam
     * @return
     */
    List<SaleOrderByPoDto> pageSearchByPos(BasePageParam<SaleOrderPageSearchReq> pageParam);

    /**
     * 构建DFS销售订单
     *
     * @param contextDto
     */
    void builderDfsSaleOrderPo(PurchaseOrderTransferContextDto contextDto);

    /**
     * 构建非DFS销售订单
     *
     * @param contextDto
     */
    void builderSaleOrderPos(PurchaseOrderTransferContextDto contextDto);

    /**
     * 批量保存销售订单
     *
     * @param contextDto
     */
    void batchInsertSaleOrder(PurchaseOrderTransferContextDto contextDto);

    /**
     * 查询销售订单
     *
     * @param purchaseOrderNo
     * @return
     */
    List<SaleOrderPo> listSaleOrderPo(String purchaseOrderNo);

    /**
     * 销售订单转单
     *
     * @param operateEnum
     * @param saleOrderId
     */
    void transferOrder(OperateEnum operateEnum, Long saleOrderId);

    /**
     * 下发给DHL出库指令
     *
     * @param saleOrderId
     */
    void dhlOutBound(Long saleOrderId);

    /**
     * 获取销售订单Map，key=saleOrderNo
     *
     * @param saleOrderNos
     * @return
     */
    Map<String, SaleOrderPo> mapSaleOrderPo(List<String> saleOrderNos);

    /**
     * 根据缺件订单构建销售订单
     *
     * @param contextDto
     */
    void builderSaleOrderPos(BackOrderTransferContextDto contextDto);

    /**
     * 批量保存销售订单
     *
     * @param contextDto
     */
    void batchInsertSaleOrder(BackOrderTransferContextDto contextDto);

    /**
     * 更新出库时间
     *
     * @param saleOrderNo
     * @param stockOutTime
     * @return
     */
    boolean updateStockOutTime(String saleOrderNo, LocalDateTime stockOutTime);

    /**
     * 更新物流编号
     *
     * @param saleOrderNo
     * @param logisticsNo
     * @return
     */
    boolean updateLogisticsNo(String saleOrderNo, String logisticsNo, String transportType);

    /**
     * 校验发货数量
     *
     * @param saleOrderNo
     * @param outQuantityList
     * @return
     */
    Map<String, BigDecimal> checkDeliverQty(String saleOrderNo, List<StockOutItemQuantityDto> outQuantityList);

    /**
     * 更新发货数量
     *
     * @param saleOrderNo
     * @param outQuantityList
     * @return
     */
    boolean updateDeliverQty(String saleOrderNo, List<StockOutItemQuantityDto> outQuantityList);

    /**
     * 批量更新预计到货时间
     */
    void batchUpdateEstArrivalTime();

    /**
     * 创建dhl请求体
     * @param saleOrderPo saleOrderPo
     * @return DHLOutboundReq
     */
    DHLOutboundReq buildDhlOutBoundReq(SaleOrderPo saleOrderPo, String type);

    void createPrOrder(CreatePrOrderReq req, OperateEnum operateEnum, SaleOrderPo saleOrderPo);

    /**
     * 更新销售订单状态
     *
     * @param statusChangeDto
     */
    void updateStatusAndSendMessage(SaleOrderStatusChangeDto statusChangeDto);

    /**
     * 更新收货数量
     *
     * @param saleOrderNo
     * @param inQuantityList
     * @return
     */
    void updateReceiveQty(String saleOrderNo, List<StockInItemQuantityDto> inQuantityList);

    /**
     *  返回so表中stk类型计划下发时间为空的所有 bizType + store code
     */
    Set<String> getAllSktBlankPlanIssueTimeStore();

    /**
     * 下发待下发的STK订单
     */
    void stkSaleOrderIssue();

    /**
     * 更新STK订单计划下发时间（门店已维订单日历但计划下发时间为空）
     */
    void updateStkOrderPlanIssueTime();

    /**
     *  RO且非DFS的销售订单、CO定制件订单定时下发
     */
    void roAndCoSaleOrderIssueHandler();

    /**
     * 根据订单类型处理下发订单，
     */
    void issueOrder(Long saleOrderId);

    /**
     * 更改销售单 是否索赔白名单
     */
    void changeClaimWhitelist(SaleOrderNoAndClaimReq req);

    PoOccupyStockReq buildPoOccupyStockReq(SaleOrderPo saleOrderPo);

    void cancel(Long id);

    /**
     * 物流轨迹
     *
     * @param request
     * @return
     */
    List<TrackDetailItemResp> trackDetail(SaleOrderNoReq request);

    /**
     * 手工下发
     * @param idReq 销售订单主键id
     */
    BaseResult<String> manualDownSend(IdReq idReq);

    /**
     * 销售订单导出查询
     */
    List<SaleOrderExportDto> exportSearch(SaleOrderPageSearchReq pageParam);

    /**
     * 销售订单 更新出库时间结果 & 更新出库数量结果
     */
    void updateStockOutTimeAndDeliverQty(SOStockOutTimeAndDeliverQtyReq req);


    /**
     * SO 门店收货时 校验订单信息
     * @param saleOrderNo
     * @param inQuantityList
     */
    void checkReceiveQty(String saleOrderNo, List<StockInItemQuantityDto> inQuantityList);

    /**
     * 根据门店发运日历配置金额 下发stk订单
     */
    void stkSaleOrderIssueByAmountHandler();
}
