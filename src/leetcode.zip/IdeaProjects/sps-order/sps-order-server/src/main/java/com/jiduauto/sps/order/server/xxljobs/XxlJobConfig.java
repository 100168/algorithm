package com.jiduauto.sps.order.server.xxljobs;

import com.jiduauto.sps.sdk.utils.StringUtils;
import com.xxl.job.core.executor.impl.XxlJobSpringExecutor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * xxljob的配置
 */
@Configuration
@Slf4j
public class XxlJobConfig {
    @Value("${xxl.job.admin.addresses:http://xxl-job-admin:8080/xxl-job-admin}")
    private String adminAddresses;

    @Value("${xxl.job.accessToken:}")
    private String accessToken;

    @Value("${xxl.job.executor.appname:sps-order}")
    private String appname;

    @Value("${spring.application.name}")
    private String springAppname;

    @Value("${xxl.job.executor.address:}")
    private String address;

    @Value("${xxl.job.executor.ip:}")
    private String ip;

    @Value("${xxl.job.executor.port:}")
    private Integer port;

    @Value("${xxl.job.executor.logpath:}")
    private String logPath;

    @Value("${xxl.job.executor.logretentiondays:}")
    private Integer logRetentionDays;

    @Value("${spring.profiles.active}")
    private String profile;

    @Bean
    public XxlJobSpringExecutor xxlJobExecutor() {
        log.info(">>>>>>>>>>> xxl-job config init.");
        XxlJobSpringExecutor xxlJobSpringExecutor = new XxlJobSpringExecutor();
        if(StringUtils.isNotBlank(adminAddresses)){
            xxlJobSpringExecutor.setAdminAddresses(adminAddresses);
        }
        if(StringUtils.isNotBlank(springAppname)){
            xxlJobSpringExecutor.setAppname(springAppname);
        }
        if(StringUtils.isNotBlank(appname)){
            xxlJobSpringExecutor.setAppname(appname);
        }
        return xxlJobSpringExecutor;
    }
}
