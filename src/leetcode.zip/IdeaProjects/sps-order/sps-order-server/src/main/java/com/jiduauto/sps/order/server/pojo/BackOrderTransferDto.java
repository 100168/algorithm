package com.jiduauto.sps.order.server.pojo;

import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 缺件订单转单
 */
@Data
public class BackOrderTransferDto {

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 门店code
     */
    private String storeCode;

    /**
     * 门店采购订单号
     */
    private String purchaseOrderNo;

    /**
     * 门店采购订单
     */
    private PurchaseOrderPo purchaseOrderPo;

    /**
     * 转单时间
     */
    private LocalDateTime transferTime;

}
