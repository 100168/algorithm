package com.jiduauto.sps.order.server.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeOrderItemExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.NumberNoReq;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.WarehouseDistributeOrderPageSearchReq;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeOrderItemDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;

import java.util.List;

/**
 * <p>
 * 仓配订单零件信息 服务类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
public interface IWarehouseDistributeItemService extends IService<WarehouseDistributeItemPo> {
    /**

    /**
     * 订单明细
     * @param bizType
     * @param warehouseDistributeOrderNo
     * @return
     */
    List<WarehouseDistributeItemPo> selectList(String warehouseDistributeOrderNo);

    /**
     * 仓配基本信息分页查询
     * @author O_chaopeng.huang
     */
    BaseResult<BasePageData<WarehouseDistributeOrderItemDto>> pageSearch(BasePageParam<NumberNoReq> req);

    List<WarehouseDistributeOrderItemDto> listAll(OrderNoReq req);

    List<WarehouseDistributeOrderItemExportDto> getExportDtoList(BasePageParam<WarehouseDistributeOrderPageSearchReq> req);
}
