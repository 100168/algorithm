package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.order.server.service.ISaleOrderDetailService;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * <p>
 * 采购订单明细 前端控制器
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@RestController
@RequestMapping("/spsInternal/so/detail")
public class SpsInternalSODController {

    @Resource
    private ISaleOrderDetailService detailService;

    /**
     * 销售订单明细分页查询接口
     *
     * @author dong.li
     * @date 4/17/23 11:05 AM
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<SaleOrderDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<SaleOrderDetailByIdReq> pageParam) {
        return BaseResult.OK(detailService.pageSearch(pageParam));
    }

}
