package com.jiduauto.sps.order.server.controller.internal;


import com.jiduauto.sps.order.server.pojo.dto.InternalEmergencyTransferStoreDto;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalEmergencyTransferStoreReq;
import com.jiduauto.sps.order.server.service.IEmergencyTransferStoreService;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/internal/emergencyTransferStore")
public class InternalEmergencyTransferStoreController {

    @Resource
    private IEmergencyTransferStoreService emergencyTransferStoreService;

    /**
     * 应急调拨门店查询
     */
    @PostMapping("/search")
    public BaseResult<List<InternalEmergencyTransferStoreDto>> search(@RequestBody @Valid InternalEmergencyTransferStoreReq req) {
        return BaseResult.OK(emergencyTransferStoreService.internalSearch(req));
    }

}
