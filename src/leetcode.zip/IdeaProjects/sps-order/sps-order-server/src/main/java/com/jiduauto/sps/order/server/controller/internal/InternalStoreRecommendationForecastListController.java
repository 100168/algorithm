package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.sps.order.server.pojo.dto.InternalStoreRecommendationForecastDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreRecommendationForecastSearchReq;
import com.jiduauto.sps.order.server.service.impl.StoreRecommendationForecastFacadeService;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 智子门店计算推荐清单
 */
@RestController
@RequestMapping("/internal/storeRecommendationForecastList")
public class InternalStoreRecommendationForecastListController {

    @Resource
    private StoreRecommendationForecastFacadeService storeRecommendationForecastFacadeService;

    /**
     * 门店计算推荐清单
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<InternalStoreRecommendationForecastDto>> pageSearch(@RequestBody @Valid BasePageParam<StoreRecommendationForecastSearchReq> pageParam) {
        return BaseResult.OK(storeRecommendationForecastFacadeService.internalPageSearch(pageParam));
    }

}
