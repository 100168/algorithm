package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderPageSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalBoSearchReq;
import com.jiduauto.sps.sdk.client.req.ApplyOrderToEsReq;
import com.jiduauto.sps.sdk.client.req.TransferInToEsReq;
import com.jiduauto.sps.sdk.client.req.TransferOutToEsReq;
import com.jiduauto.sps.sdk.client.req.TransferToEsReqItem;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface TransferToEsConvertor {

    @Mapping(target = "bizSource", expression = "java(1)")
    @Mapping(target = "bizNo", source = "warehouseDistributeOrderNo")
    @Mapping(target = "receiveContactPhone", source = "receiverContact")
    @Mapping(target = "receiveContactName", source = "receiver")
    @Mapping(target = "receiveAddress", source = "receiverContact")
    @Mapping(target = "outBranchCode", source = "deliverWarehouseCode")
    @Mapping(target = "oriContactPhone", source = "shipperContact")
    @Mapping(target = "oriContactName", source = "shipper")
    @Mapping(target = "oriAddress", source = "deliverAddress")
    @Mapping(target = "materialInfoList", ignore = true)
    @Mapping(target = "inBranchCode", source = "receiveWarehouseCode")
    TransferOutToEsReq toOutReq(WarehouseDistributeLogisticPo po);


    @Mapping(target = "traceStatus", ignore = true)
    @Mapping(target = "sum", source = "qty")
    @Mapping(target = "materialStatusDesc", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    @Mapping(target = "lineNo", source = "materialLineNo")
    TransferToEsReqItem toItemReq(WarehouseDistributeItemPo po);


    List<TransferToEsReqItem> toItemReq(List<WarehouseDistributeItemPo> po);


    @Mapping(target = "inBranchCode", source = "receiveWarehouseCode")
    @Mapping(target = "expressNo", ignore = true)
    @Mapping(target = "bizSource", expression = "java(1)")
    @Mapping(target = "bizNo", source = "warehouseDistributeOrderNo")
    @Mapping(target = "receiveContactPhone", source = "receiverContact")
    @Mapping(target = "receiveContactName", source = "receiver")
    @Mapping(target = "receiveAddress", source = "receiverContact")
    @Mapping(target = "outBranchCode", source = "deliverWarehouseCode")
    @Mapping(target = "oriContactPhone", source = "shipperContact")
    @Mapping(target = "oriContactName", source = "shipper")
    @Mapping(target = "oriAddress", source = "deliverAddress")
    @Mapping(target = "materialInfoList", ignore = true)
    TransferInToEsReq toInReq(WarehouseDistributeLogisticPo po);


    @Mapping(target = "wbs", ignore = true)
    @Mapping(target = "traceStatus", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    @Mapping(target = "isApply", ignore = true)
    @Mapping(target = "costCenter", ignore = true)
    @Mapping(target = "columnNo", source = "materialLineNo")
    @Mapping(target = "applySum", source = "qty")
    @Mapping(target = "applySake", ignore = true)
    ApplyOrderToEsReq.ApplyOrderToEsReqItem toApplyItemReq(WarehouseDistributeItemPo po);


}
