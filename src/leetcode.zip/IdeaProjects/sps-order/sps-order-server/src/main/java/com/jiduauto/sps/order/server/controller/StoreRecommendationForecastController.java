package com.jiduauto.sps.order.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.order.server.pojo.dto.StoreRecommendationForecastDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreRecommendationForecastExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreRecommendationForecastSearchReq;
import com.jiduauto.sps.order.server.service.impl.StoreRecommendationForecastFacadeService;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.ExcelUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * 门店推荐试算 前端控制器
 */
@RestController
@RequestMapping("/storeRecommendationForecast")
public class StoreRecommendationForecastController {

    @Resource
    private StoreRecommendationForecastFacadeService storeRecommendationForecastFacadeService;

    /**
     * 分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StoreRecommendationForecastDto>> pageSearch(@RequestBody @Valid BasePageParam<StoreRecommendationForecastSearchReq> pageParam) {
        return BaseResult.OK(storeRecommendationForecastFacadeService.pageSearch(pageParam));
    }

    /**
     * 导出
     */
    @RequestMapping("/export")
    public void export(
            HttpServletResponse response, @RequestBody @Valid BasePageParam<StoreRecommendationForecastSearchReq> pageParam) {
        try {
            ExcelUtils.exportXlsxResponse(response, "门店推荐试算");
            EasyExcel.write(response.getOutputStream(), StoreRecommendationForecastExportDto.class).sheet("门店推荐试算").doWrite(storeRecommendationForecastFacadeService.export(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

}
