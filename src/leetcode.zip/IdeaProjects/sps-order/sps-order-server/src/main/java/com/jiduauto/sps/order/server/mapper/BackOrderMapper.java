package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.pojo.BackOrderTransferDto;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderPageSearchReq;
import com.jiduauto.sps.sdk.pojo.po.BackOrderPo;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 * 缺件订单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface BackOrderMapper extends BaseMapper<BackOrderPo> {

    /**
     * 缺件订单分野条件查询
     *
     * @author dong.li
     * @date 4/13/23 2:51 PM
     */
    IPage<BackOrderDto> pageSearch(Page<BackOrderDto> page, BackOrderPageSearchReq param);

    /**
     * 缺件订单批量更新
     * @param backOrderPos 列表
     */
    void updateBatchByNo(List<BackOrderPo> backOrderPos);

    /**
     * 获取所有需要转单的采购订单号
     *
     * @return
     */
    List<BackOrderTransferDto> listPendingTransferPurchaseOrderNo(@Param("orderType") String orderType);

    /**
     * 扣减剩余数量
     */
    int subtractRestBackQty(@Param("id") Long id, @Param("qty") BigDecimal qty, @Param("updateUser") String updateUser);
}
