package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderDetailSearchReq;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 采购订单明细 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface IPurchaseOrderDetailService extends IService<PurchaseOrderDetailPo> {

    /**采购订单明细分页查询
     * @param pageSearchReq
     * @return */
    BasePageData<PurchaseOrderDetailDto> pageSearch(BasePageParam<PurchaseOrderDetailSearchReq> pageSearchReq);

    /**采购订单明细查询
     * @param purchaseOrderId
     * @return */
    List<PurchaseOrderDetailDto> getDetail(PurchaseOrderDetailSearchReq purchaseOrderId);

    /** 获取PO单的 折后单价
     * @param purchaseOrderNos
     * @return */
    Map<String, BigDecimal> getDiscountUnitPriceByPos(List<String> purchaseOrderNos);

    /**
     *  获取PO单的详情
     */
    Map<String, PurchaseOrderDetailPo> getDetailPoByPos(List<String> purchaseOrderNos);

    /**
     * 获取采购订单明细
     * @param purchaseOrderNo
     * @return
     */
    Map<String, PurchaseOrderDetailPo> mapPurchaseOrderDetail(String purchaseOrderNo);

    /**
     * 查询 SO单对应的PO单 明细中 每个物料的 折后单价
     * @param soOrderNo
     * @return
     */
    Map<String, BigDecimal> getDiscountUnitPrice(List<String> soOrderNo);
}
