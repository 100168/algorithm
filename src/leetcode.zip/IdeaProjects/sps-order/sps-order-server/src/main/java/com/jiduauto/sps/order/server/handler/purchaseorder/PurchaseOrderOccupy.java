package com.jiduauto.sps.order.server.handler.purchaseorder;


import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderOccupyDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderTransferContextDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PoOccupyStockReq;
import com.jiduauto.sps.order.server.pojo.vo.resp.PoOccupyStockResult;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.pojo.po.StoreWarehouseConfigPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import com.jiduauto.sps.sdk.utils.NumberUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
public abstract class PurchaseOrderOccupy {


    /**
     * 占用库存
     *
     * @param contextDto
     */
    public abstract void occupy(PurchaseOrderTransferContextDto contextDto);

    /**
     * 获取运输建议
     *
     * @param materialPo
     * @return
     */
    public abstract String getShippingMethod(MaterialPo materialPo);

    /**
     * 整单占用
     *
     * @param contextDto
     * @return
     */
    protected boolean occupyAllStock(PurchaseOrderTransferContextDto contextDto, SpsClient spsClient) {
        if (CollectionUtils.isEmpty(contextDto.getOtherPurchaseOrderDetails())) {
            return true;
        }

        // 逐个仓库尝试占用库存
        PoOccupyStockReq poOccupyStockReq = convertPoOccupyStockReq(contextDto);
        for (int i = 0; i < contextDto.getStoreWarehouseConfigs().size(); i++) {
            StoreWarehouseConfigPo storeWarehouseConfig = contextDto.getStoreWarehouseConfigs().get(i);
            poOccupyStockReq.setBusinessNo(generateBusinessNo(contextDto, contextDto.getPurchaseOrder(), i));
            poOccupyStockReq.setWarehouseCode(storeWarehouseConfig.getWarehouseCode());
            poOccupyStockReq.setOccupyNo(contextDto.getPurchaseOrder().getPurchaseOrderNo());
            BaseResult<Map<String, PoOccupyStockResult>> baseResult = null;
            try {
                baseResult = spsClient.poOccupyAllStock(poOccupyStockReq);
                log.info("PurchaseOrderOccupy#occupyAllStock param: {}, result: {}", JsonUtil.toJsonString(poOccupyStockReq), JsonUtil.toJsonString(baseResult));
            } catch (Exception e) {
                log.warn(String.format("PurchaseOrderOccupy#occupyAllStock param: %s", JsonUtil.toJsonString(poOccupyStockReq)), e);
                throw e;
            }
            if (baseResult.isSuccess() || baseResult.getCode().equals(SpsResponseCodeEnum.DUPLICATE_OPERATE.getCode())) {
                // 全部占用成功生成占用详情
                contextDto.getOccupyDetails().addAll(poOccupyStockReq.getInfos().stream().map(item -> {
                    PurchaseOrderOccupyDetailDto detailDto = new PurchaseOrderOccupyDetailDto();
                    detailDto.setDeliverWarehouseCode(storeWarehouseConfig.getWarehouseCode());
                    detailDto.setTransferAdvice(getShippingMethod(contextDto.getMaterialMap().get(item.getMaterialCode())));
                    detailDto.setSalePartNum(item.getMaterialCode());
                    detailDto.setQuantity(item.getOccupyQuantity());
                    return detailDto;
                }).collect(Collectors.toList()));
                return true;
            }
        }
        return false;
    }

    /**
     * 部分占用
     *
     * @param contextDto
     */
    protected void occupyPartStock(PurchaseOrderTransferContextDto contextDto, SpsClient spsClient) {
        if (CollectionUtils.isEmpty(contextDto.getOtherPurchaseOrderDetails())) {
            return;
        }

        // 逐个仓库尝试占用库存
        PoOccupyStockReq poOccupyStockReq = convertPoOccupyStockReq(contextDto);
        for (int i = 0; i < contextDto.getStoreWarehouseConfigs().size(); i++) {
            if (CollectionUtils.isEmpty(poOccupyStockReq.getInfos())) {
                break;
            }
            StoreWarehouseConfigPo storeWarehouseConfig = contextDto.getStoreWarehouseConfigs().get(i);
            poOccupyStockReq.setBusinessNo(generateBusinessNo(contextDto,contextDto.getPurchaseOrder(), i));
            poOccupyStockReq.setWarehouseCode(storeWarehouseConfig.getWarehouseCode());
            poOccupyStockReq.setOccupyNo(contextDto.getPurchaseOrder().getPurchaseOrderNo());
            BaseResult<Map<String, PoOccupyStockResult>> baseResult = null;
            try {
                baseResult = spsClient.poOccupyPartStock(poOccupyStockReq);
                log.info("PurchaseOrderOccupy#occupyPartStock param: {}, result: {}", JsonUtil.toJsonString(poOccupyStockReq), JsonUtil.toJsonString(baseResult));
            } catch (Exception e) {
                log.warn(String.format("PurchaseOrderOccupy#occupyPartStock param: %s", JsonUtil.toJsonString(poOccupyStockReq)), e);
                throw e;
            }
            if (baseResult.isSuccess() || baseResult.getCode().equals(SpsResponseCodeEnum.DUPLICATE_OPERATE.getCode())) {
                Map<String, PoOccupyStockResult> poOccupyStockResultMap = baseResult.getData();
                if(MapUtils.isNotEmpty(poOccupyStockResultMap)){
                    poOccupyStockResultMap = poOccupyStockResultMap.entrySet().stream().filter(item -> item.getValue().getOccupyQuantity().compareTo(BigDecimal.ZERO) > 0).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
                }
                if(MapUtils.isEmpty(poOccupyStockResultMap)){
                    continue;
                }

                // 添加库存占用情况
                contextDto.getOccupyDetails().addAll(poOccupyStockResultMap.entrySet().stream().map(item -> {
                    PurchaseOrderOccupyDetailDto detailDto = new PurchaseOrderOccupyDetailDto();
                    detailDto.setDeliverWarehouseCode(storeWarehouseConfig.getWarehouseCode());
                    detailDto.setTransferAdvice(getShippingMethod(contextDto.getMaterialMap().get(item.getKey())));
                    detailDto.setSalePartNum(item.getKey());
                    detailDto.setQuantity(item.getValue().getOccupyQuantity());
                    return detailDto;
                }).collect(Collectors.toList()));

                // 取出已占用的数量
                Iterator<PoOccupyStockReq.PoOccupyStockInfo> iterator = poOccupyStockReq.getInfos().iterator();
                while (iterator.hasNext()) {
                    PoOccupyStockReq.PoOccupyStockInfo poOccupyStockInfo = iterator.next();
                    if (poOccupyStockResultMap.containsKey(poOccupyStockInfo.getMaterialCode())) {
                        poOccupyStockInfo.setOccupyQuantity(poOccupyStockInfo.getOccupyQuantity().subtract(poOccupyStockResultMap.get(poOccupyStockInfo.getMaterialCode()).getOccupyQuantity()));
                    }
                    if (poOccupyStockInfo.getOccupyQuantity().compareTo(BigDecimal.ZERO) <= 0) {
                        iterator.remove();
                    }
                }
            }
        }

        // 记录库存占用失败的详情
        if (CollectionUtils.isNotEmpty(poOccupyStockReq.getInfos())) {
            contextDto.getOccupyFailedDetails().addAll(poOccupyStockReq.getInfos().stream().map(poOccupyStockInfo -> {
                PurchaseOrderOccupyDetailDto detailDto = new PurchaseOrderOccupyDetailDto();
                detailDto.setSalePartNum(poOccupyStockInfo.getMaterialCode());
                detailDto.setQuantity(poOccupyStockInfo.getOccupyQuantity());
                return detailDto;
            }).collect(Collectors.toList()));
        }
    }

    private PoOccupyStockReq convertPoOccupyStockReq(PurchaseOrderTransferContextDto contextDto) {
        PoOccupyStockReq poOccupyStockReq = new PoOccupyStockReq();
        poOccupyStockReq.setBizType(contextDto.getPurchaseOrder().getBizType());
        poOccupyStockReq.setInfos(contextDto.getOtherPurchaseOrderDetails().stream().map(purchaseOrderDetailPo -> {
            PoOccupyStockReq.PoOccupyStockInfo poOccupyStockInfo = new PoOccupyStockReq.PoOccupyStockInfo();
            poOccupyStockInfo.setMaterialCode(purchaseOrderDetailPo.getSalePartNum());
            poOccupyStockInfo.setOccupyQuantity(purchaseOrderDetailPo.getQty());
            poOccupyStockInfo.setMinPackage(getMinPackage(contextDto.getMaterialMap().get(purchaseOrderDetailPo.getSalePartNum())));
            return poOccupyStockInfo;
        }).collect(Collectors.toList()));
        return poOccupyStockReq;
    }

    private Integer getMinPackage(MaterialPo materialPo) {
        if (Objects.isNull(materialPo) || !NumberUtil.isPositiveInteger(materialPo.getMinPackage())) {
            return 1; // 默认值
        } else {
            return Integer.valueOf(materialPo.getMinPackage());
        }
    }

    private String generateBusinessNo(PurchaseOrderTransferContextDto contextDto, PurchaseOrderPo purchaseOrderPo, int warehousePriority) {
        if (contextDto.getOperateEnum() == OperateEnum.MANUAL_PART_TURN_ORDER) {
            //管控件转单  同一单采购订单可能会重复占库, 原来的幂等号不唯一了
            return purchaseOrderPo
                    .getPurchaseOrderNo()
                    .concat("#")
                    .concat(String.valueOf(warehousePriority)
                            .concat("#")
                            .concat(String.valueOf(contextDto.getPoPartTransferOperateId())));
        }
        return purchaseOrderPo.getPurchaseOrderNo().concat("#").concat(String.valueOf(warehousePriority));
    }
}
