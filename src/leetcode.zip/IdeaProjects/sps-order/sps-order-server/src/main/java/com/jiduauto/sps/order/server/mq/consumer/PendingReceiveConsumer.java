package com.jiduauto.sps.order.server.mq.consumer;

import cn.hutool.json.JSONUtil;
import com.jiduauto.sps.order.server.pojo.dto.PendingReceiveDto;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.req.ReceiveReq;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

/**
 * @ClassName PendingReceiveConsumer
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/9/11 15:57
 */
@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_8,
        topic = BaseConstants.RocketMqTopic.TC_DIT_SPS_PEND_RECEIVE_RECEIVED_ASYNC,
        consumeThreadMax = 10)
public class PendingReceiveConsumer implements RocketMQListener<MessageExt> {
    @Autowired
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;
    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("PendingReceiveConsumer#onMessage messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
        try {
            ReceiveReq req = JSONUtil.toBean(body, ReceiveReq.class);
            warehouseDistributeOrderService.updateRealInQty(req);
        } catch (BizException e) {
            log.info("PendingReceiveConsumer#onMessage messageId: {}, tag: {}, body: {}", e.getLogRelId(), e.getErrMessage(), body);
            throw new BizException(e.getErrMessage(),e.getLogRelId());
        }catch (Exception e) {
            log.info("PendingReceiveConsumer#onMessage  tag: {}, body: {}", e.getMessage(), body);
            throw new RuntimeException(e);
        }
    }
}
