package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum WDJobIndexEnum {
    /*
    占库 00000001
    * */
    OCCUPY_STOCK(1),

    /*同步tms出库 00000010
     * */
    SYNC_TO_TMS(1 << 1),

    /*同步tms写入运单 00000010
     * */
    SYNC_TO_TMS_LOGISTIC(1 << 2),
    /*
    生成待收货列表 00000100
    * */
    GENERATE_PENDING_RECEIVE_ORDER(1 << 3),

    /*初始化供应商
     * */
    INIT_SUPPLIER(1 << 4),

    /*同步能源 00010000
     * */
    INBOUND_TO_ES(1 << 5),
    /*
     生成待出库列表 1000000
  * */
    GENERATE_OUTBOUND_ORDER(1 << 6),

    /*dhl入库指令 00001000
     * */
    INBOUND_COMMAND(1 << 7),
    /*
     * 发送出库消息给商城
     * */
    SEND_MSG_SM(1 << 8),

    TRANSFER_OUT_TO_ES(1 << 9),

    TRANSFER_IN_TO_ES(1 << 10),
    /*
     * 生成入库订单
     * */
    GENERATE_STOCK_IN_MAP_BUSINESS(1 << 11),

    /*dhl出库指令 00001000
     * */
    OUTBOUND_COMMAND(1 << 12),

    UPDATE_FORK_QTY(1 << 13),


    APPLY_OUT_TO_ES(1 << 14),

    ;

    private final Integer bitIndex;
}
