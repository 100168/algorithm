package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.convertor.SaleOrderOperateLogConvertor;
import com.jiduauto.sps.order.server.mapper.SaleOrderOperateLogMapper;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDfsStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderOperateLogDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.order.server.service.ISaleOrderOperateLogService;
import com.jiduauto.sps.sdk.enums.ColumnEnum;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderOperateLogPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 销售订单操作记录 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Service
public class SaleOrderOperateLogServiceImpl extends
        ServiceImpl<SaleOrderOperateLogMapper, SaleOrderOperateLogPo> implements ISaleOrderOperateLogService {


    @Resource
    private SaleOrderOperateLogConvertor saleOrderOperateLogConvertor;
    /**
     * 销售订单状态跟踪明细
     *
     * @author dong.li
     * @date 4/17/23 4:15 PM
     */
    @Override
    public BasePageData<SaleOrderOperateLogDto> pageSearch(BasePageParam<SaleOrderDetailByIdReq> pageParam) {
        SaleOrderDetailByIdReq param = pageParam.getParam();
        Page<SaleOrderOperateLogPo> page = new Page<>(pageParam.getPage(), pageParam.getSize());
        Page<SaleOrderOperateLogPo> pageSearchList = this.page(page,
                Wrappers.<SaleOrderOperateLogPo>lambdaQuery().eq(SaleOrderOperateLogPo::getBizType, param.getBizType())
                        .eq(SaleOrderOperateLogPo::getSaleOrderNo, param.getSaleOrderNo())
                        .orderByDesc(SaleOrderOperateLogPo::getId)
        );
        List<SaleOrderOperateLogPo> records = pageSearchList.getRecords();
        BasePageData<SaleOrderOperateLogDto> data = new BasePageData<>();
        data.setRecords(saleOrderOperateLogConvertor.toDtoList(records));
        return data;
    }

    @Override
    public void saveStatusChangeLog(SaleOrderDfsStatusChangeDto changeDto) {
        SaleOrderOperateLogPo saleOrderOperateLogPo = new SaleOrderOperateLogPo();
        saleOrderOperateLogPo.setBizType(changeDto.getSaleOrderPo().getBizType());
        saleOrderOperateLogPo.setSaleOrderNo(changeDto.getSaleOrderPo().getSaleOrderNo());
        saleOrderOperateLogPo.setActionDesc(changeDto.getOperateEnum().getDesc());
        saleOrderOperateLogPo.setModifyColumn(ColumnEnum.DFS_STATUS.getDesc());
        saleOrderOperateLogPo.setOldValue(changeDto.getSaleOrderPo().getSaleOrderStatus());
        saleOrderOperateLogPo.setNewValue(changeDto.getNewDfsStatusEnum().getCode());
        saleOrderOperateLogPo.setCreateUser(changeDto.getOperateUser());
        saleOrderOperateLogPo.setRemark(changeDto.getRemark());
        baseMapper.insert(saleOrderOperateLogPo);
    }

    @Override
    public void saveStatusChangeLog(SaleOrderStatusChangeDto changeDto) {
        SaleOrderOperateLogPo saleOrderOperateLogPo = new SaleOrderOperateLogPo();
        saleOrderOperateLogPo.setBizType(changeDto.getSaleOrderPo().getBizType());
        saleOrderOperateLogPo.setSaleOrderNo(changeDto.getSaleOrderPo().getSaleOrderNo());
        saleOrderOperateLogPo.setActionDesc(changeDto.getOperateEnum().getDesc());
        saleOrderOperateLogPo.setModifyColumn(ColumnEnum.STATUS.getDesc());
        saleOrderOperateLogPo.setOldValue(changeDto.getSaleOrderPo().getSaleOrderStatus());
        saleOrderOperateLogPo.setNewValue(changeDto.getNewStatusEnum().getCode());
        saleOrderOperateLogPo.setCreateUser(changeDto.getOperateUser());
        saleOrderOperateLogPo.setRemark(changeDto.getRemark());
        baseMapper.insert(saleOrderOperateLogPo);
    }
}
