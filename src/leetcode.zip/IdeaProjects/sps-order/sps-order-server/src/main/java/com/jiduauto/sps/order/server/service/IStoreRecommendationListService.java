package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.StoreRecommendationListDto;
import com.jiduauto.sps.order.server.pojo.po.StoreRecommendationListPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListPageReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

/**
 * 门店推荐清单 服务类
 */
public interface IStoreRecommendationListService extends IService<StoreRecommendationListPo> {

    /**
     * 分页查询
     */
    BasePageData<StoreRecommendationListDto> pageSearch(BasePageParam<StandardRecommendationListPageReq> pageParam);

    StoreRecommendationListPo getOne(String bizType,
                                     String storeCode,
                                     String materialCode);

    void insertOrUpdate(StoreRecommendationListPo po, String operateUser);
}
