package com.jiduauto.sps.order.server.pojo.dto;

import com.jiduauto.sps.sdk.enums.BackOrderStatusEnum;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.pojo.po.BackOrderPo;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BackOrderStatusChangeDto {

    /**
     * 取件订单
     */
    private BackOrderPo backOrderPo;

    /**
     * 新的状态
     */
    private BackOrderStatusEnum newStatusEnum;

    /**
     * 变更备注
     */
    private String remark;

    /**
     * 操作行为
     */
    private OperateEnum operateEnum;

    /**
     * 操作用户
     */
    private String operateUser;
}
