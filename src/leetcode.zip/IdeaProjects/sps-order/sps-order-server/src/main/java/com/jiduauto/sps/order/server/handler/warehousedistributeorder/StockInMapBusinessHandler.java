package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.convertor.StockInMapBusinessConvertor;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderlogisticTypeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.StockInMapBusinessDto;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/*
 * 生成入库订单*/
@Component
public class StockInMapBusinessHandler implements WDOrderJobHandler, InitializingBean {

    @Resource
    private WDOrderJobContext wdOrderJobContext;
    @Resource
    private SpsClient spsClient;

    @Resource
    private StockInMapBusinessConvertor stockInMapBusinessConvertor;
    /**
     * 生成待收货列表
     */
    @Override
    public void process(WarehouseDistributeOrderAllPo allPo) {


        StockInMapBusinessDto dto = stockInMapBusinessConvertor.toDto(allPo.getWarehouseDistributeOrderPo());
        List<StockInMapBusinessDto.StockInMapBusinessItemDto> itemDto = stockInMapBusinessConvertor.toItemDto(allPo.getItems());

        if (allPo.getWarehouseDistributeOrderPo().getLogisticType().equals(WarehouseDistributeOrderlogisticTypeEnum.TRANSPORT_AND_PUT_IN.getValue().toString())){
            dto.setOrderNo(allPo.getWarehouseDistributeOrderPo().getBusinessBillNo());
            for (StockInMapBusinessDto.StockInMapBusinessItemDto businessItemDto : itemDto) {
                businessItemDto.setOrderNo(allPo.getWarehouseDistributeOrderPo().getBusinessBillNo());
            }
        }
        dto.setDetails(itemDto);
        BaseResult<String> resp = spsClient.createStockInMapBusiness(dto);
        if (!resp.isSuccess()){
            throw new BizException(resp.getMessage());
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.GENERATE_STOCK_IN_MAP_BUSINESS.getBitIndex(), this);
    }
}
