package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderOperateLogDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderDetailSearchReq;
import com.jiduauto.sps.order.server.service.IPurchaseOrderOperateLogService;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * <p>
 * 采购订单操作记录 前端控制器
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@RestController
@RequestMapping("/spsInternal/po/operateLog")
public class SpsInternalPOOperateLogController {

    @Resource
    private IPurchaseOrderOperateLogService purchaseOrderOperateLogService;

    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<PurchaseOrderOperateLogDto>> pageSearch(@RequestBody @Valid BasePageParam<PurchaseOrderDetailSearchReq> pageSearchReq) {
        return BaseResult.OK(purchaseOrderOperateLogService.pageSearch(pageSearchReq));
    }

}
