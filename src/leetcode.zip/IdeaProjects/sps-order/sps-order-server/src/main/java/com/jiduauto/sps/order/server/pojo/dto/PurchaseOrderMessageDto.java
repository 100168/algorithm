package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class PurchaseOrderMessageDto {

    /**
     * 采购订单id
     */
    private Long id;

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 采购订单号
     */
    private String purchaseOrderNo;

    /**
     * 采购订单归属
     */
    private String purchaseOrderAttr;

    /**
     * 采购订单类型
     */
    private String purchaseOrderType;

    /**
     * 门店编码
     */
    private String storeCode;

    /**
     * 订单提交时间
     */
    private LocalDateTime commitTime;

    /**
     * 收货仓库编码
     */
    private String receiveWarehouseCode;

    /**
     * 订单总金额
     */
    private BigDecimal purchaseOrderAmount;

    /**
     * 订单状态
     */
    private String purchaseOrderStatus;

    /**
     * 收件人
     */
    private String receiver;

    /**
     * 收件人电话
     */
    private String receiverPhone;

    /**
     * 收货省
     */
    private String receiverProvince;

    /**
     * 收货市
     */
    private String receiverCity;
    /**
     * 收货区
     */
    private String receiverDistrict;

    /**
     * 收货地址
     */
    private String receiverAddress;

    /**
     * vin
     */
    private String vin;

    /**
     * 是否管控件转单
     */
    private Boolean isControlTurn;

    /**
     * 管控件转单Id 主键
     */
    private Long partTransferOperateId;
}
