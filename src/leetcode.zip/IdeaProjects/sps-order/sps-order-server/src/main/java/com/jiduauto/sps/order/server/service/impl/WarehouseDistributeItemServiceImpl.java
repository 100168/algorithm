package com.jiduauto.sps.order.server.service.impl;


import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.convertor.WarehouseDistributeItemConvertor;
import com.jiduauto.sps.order.server.mapper.WarehouseDistributeItemMapper;
import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeOrderItemExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.NumberNoReq;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.WarehouseDistributeOrderPageSearchReq;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.order.server.utils.AESUtil;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.pojo.dto.DictItemClientDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.*;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.AreaCheckReq;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.req.LocationCheckReq;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.consts.BaseConstants.ImportExport.PAGE_START_AT;
import static com.jiduauto.sps.sdk.consts.BaseConstants.ListMaxSize.TEN_THOUSAND;

/**
 * <p>
 * 仓配订单零件信息 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
@Service
public class WarehouseDistributeItemServiceImpl extends ServiceImpl<WarehouseDistributeItemMapper, WarehouseDistributeItemPo> implements IWarehouseDistributeItemService {

    @Resource
    private SpsClient spsClient;

    @Resource
    private WarehouseDistributeItemConvertor warehouseDistributeItemConvertor;

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;


    @Resource
    private IWarehouseDistributeAttachService warehouseDistributeAttachService;


    @Resource
    private IWarehouseDistributeItemAttachService warehouseDistributeItemAttachService;

    @Resource
    private IWarehouseDistributeLogisticService warehouseDistributeLogisticService;


    @Resource
    private AESUtil aesUtil;

    /**
     * 订单明细
     *
     * @param
     * @param warehouseDistributeOrderNo
     * @return
     */
    @Override
    public List<WarehouseDistributeItemPo> selectList(String warehouseDistributeOrderNo) {
        return list(Wrappers.<WarehouseDistributeItemPo>lambdaQuery().eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, warehouseDistributeOrderNo));
    }

    @Override
    public BaseResult<BasePageData<WarehouseDistributeOrderItemDto>> pageSearch(BasePageParam<NumberNoReq> req) {
        NumberNoReq param = req.getParam();
        String numberNo = param.getNumberNo();
        String bizType = param.getBizType();
        IPage<WarehouseDistributeItemPo> iPage = new Page<>(req.getPage(), req.getSize());
        iPage = baseMapper.selectPage(iPage,
                Wrappers.lambdaQuery(WarehouseDistributeItemPo.class)
                        .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, numberNo)
                        .orderByAsc(WarehouseDistributeItemPo::getMaterialLineNo));


        List<WarehouseDistributeItemPo> records = iPage.getRecords();
        if (CollectionUtils.isEmpty(records)) {
            return BaseResult.OK(new BasePageData<>());
        }

        List<WarehouseDistributeOrderItemDto> collect = getDtoList(bizType, records);
        BasePageData<WarehouseDistributeOrderItemDto> pageData = new BasePageData<>(iPage);
        pageData.setRecords(collect);
        return BaseResult.OK(pageData);
    }

    private List<WarehouseDistributeOrderItemDto> getDtoList(String bizType, List<WarehouseDistributeItemPo> records) {
        List<String> materialCodeAndBizType = new ArrayList<>();
        List<String> supplierCode = new ArrayList<>();
        List<String> warehouseCode = new ArrayList<>();
        List<String> bizTypes = new ArrayList<>();
        bizTypes.add(bizType);
        List<AreaCheckReq> areaCode = new ArrayList<>();
        List<LocationCheckReq> locationCode = new ArrayList<>();
        for (WarehouseDistributeItemPo record : records) {
            AreaCheckReq areaCheckReq = new AreaCheckReq();
            areaCheckReq.setWarehouseCode(record.getWarehouseCode());
            areaCheckReq.setCode(record.getAreaCode());
            LocationCheckReq locationCheckReq = new LocationCheckReq();
            locationCheckReq.setWarehouseCode(record.getWarehouseCode());
            locationCheckReq.setAreaCode(record.getAreaCode());
            locationCheckReq.setCode(record.getLocationCode());
            areaCode.add(areaCheckReq);
            warehouseCode.add(record.getWarehouseCode());
            supplierCode.add(record.getSupplierCode());
            materialCodeAndBizType.add(record.getMaterialCode());
            locationCode.add(locationCheckReq);
            if (!bizTypes.contains(record.getBizType())) {
                bizTypes.add(record.getBizType());
            }
        }
        List<String> dictCode = new ArrayList<>();
        dictCode.add(DictEnum.BIZTYPE.getDictCode());
        dictCode.add(DictEnum.MaterialStockStatus.getDictCode());
        dictCode.add(DictEnum.StockStatus.getDictCode());
        dictCode.add(DictEnum.MaterialSort.getDictCode());
        dictCode.add(DictEnum.Project.getDictCode());
        dictCode.add(DictEnum.Stage.getDictCode());
        List<BaseDataResp> baseResults = new ArrayList<>();
        //如果明细有多业务
        if (bizTypes.size() > 1) {
            for (String type : bizTypes) {
                getBaseDateResult(type, warehouseCode, supplierCode, materialCodeAndBizType, areaCode, locationCode,
                        baseResults, dictCode);
            }
        } else {
            getBaseDateResult(bizType, warehouseCode, supplierCode, materialCodeAndBizType, areaCode, locationCode,
                    baseResults, dictCode);
        }
        Map<String, String> bizTypeMapSupplierPo = new HashMap<>();
        Map<String, String> bizTypeMapWarehousePo = new HashMap<>();
        Map<String, String> bizTypeMapAreasPo = new HashMap<>();
        Map<String, String> bizTypeMapLocationsPo = new HashMap<>();
        Map<String, MaterialPo> bizTypeMapMaterialPo = new HashMap<>();
        Map<String, Map<String, String>> bizTypeMap = new HashMap<>();
        for (BaseDataResp baseResult : baseResults) {
            bizTypeMapSupplierPo.putAll(baseResult.getSupplierPos().stream()
                    .collect(Collectors.toMap(e -> e.getBizType() + e.getSapCode(),
                            SupplierPo::getSupplierName)));
            bizTypeMapWarehousePo.putAll(baseResult.getWarehouses().stream()
                    .collect(Collectors.toMap(e -> e.getBizType() + e.getCode(),
                            WarehousePo::getName)));
            bizTypeMapAreasPo.putAll(baseResult.getAreas().stream()
                    .collect(Collectors.toMap(e -> e.getBizType() + e.getWarehouseCode() + e.getCode(),
                            AreasPo::getName)));
            bizTypeMapLocationsPo.putAll(baseResult.getLocations().stream()
                    .collect(
                            Collectors.toMap(e -> e.getBizType() + e.getWarehouseCode() + e.getAreaCode() + e.getCode(),
                                    LocationsPo::getName)));
            bizTypeMapMaterialPo.putAll(baseResult.getMaterials().stream()
                    .collect(Collectors.toMap(e -> e.getBizType() + e.getSalePartNum(),
                            Function.identity())));
        }
        List<DictItemClientDto> dictItemClientDtos = baseResults.get(0).getDictItemClientDtos();
        if (!CollUtil.isEmpty(dictItemClientDtos)) {
            for (DictItemClientDto clientDto : dictItemClientDtos) {
                if (bizTypeMap.containsKey(clientDto.getCode())) {
                    bizTypeMap.get(clientDto.getCode()).put(clientDto.getItemCode(), clientDto.getItemName());
                }
                if (!bizTypeMap.containsKey(clientDto.getCode())) {
                    HashMap<String, String> value = new HashMap<>();
                    value.put(clientDto.getItemCode(), clientDto.getItemName());
                    bizTypeMap.put(clientDto.getCode(), value);
                }
            }
        }
        Map<String, String> bizMap = bizTypeMap.get(DictEnum.BIZTYPE.getDictCode());
        Map<String, String> statusMap = bizTypeMap.get(DictEnum.MaterialStockStatus.getDictCode());
        Map<String, String> sortMap = bizTypeMap.get(DictEnum.MaterialSort.getDictCode());
        Map<String, String> stockStatusMap = bizTypeMap.get(DictEnum.StockStatus.getDictCode());
        Map<String, String> projectMap = bizTypeMap.get(DictEnum.Project.getDictCode());
        Map<String, String> stageMap = bizTypeMap.get(DictEnum.Stage.getDictCode());
        return records.stream()
                .map(e -> {
                    WarehouseDistributeOrderItemDto item = BeanCopierUtil.copy(e,
                            WarehouseDistributeOrderItemDto.class);
                    MaterialPo materialPo = bizTypeMapMaterialPo.getOrDefault(e.getBizType() + e.getMaterialCode(),
                            new MaterialPo());
                    item.setWarehouseName(bizTypeMapWarehousePo.get(e.getBizType() + e.getWarehouseCode()));
                    item.setAreaName(bizTypeMapAreasPo.get(e.getBizType() + e.getWarehouseCode() + e.getAreaCode()));
                    item.setLocationName(
                            bizTypeMapLocationsPo.get(
                                    e.getBizType() + e.getWarehouseCode() + e.getAreaCode() + e.getLocationCode()));
                    item.setSupplierName(bizTypeMapSupplierPo.get(e.getBizType() + e.getSupplierCode()));
                    item.setBizTypeName(bizMap.get(e.getBizType()));
                    item.setMaterialName(materialPo.getMaterialName());
                    item.setMaterialStatusName(statusMap.get(String.valueOf(e.getMaterialStatus())));
                    item.setMaterialSortName(sortMap.get(e.getMaterialSort()));
                    item.setProjectName(projectMap.get(e.getProjectCode()));
                    item.setStageName(stageMap.get(e.getStageCode()));
                    item.setStockStatusName(stockStatusMap.get(String.valueOf(e.getStockStatus())));
                    return item;
                }).collect(Collectors.toList());
    }

    @Override
    public List<WarehouseDistributeOrderItemDto> listAll(OrderNoReq req) {
        List<WarehouseDistributeItemPo> itemPos = selectList(req.getOrderNo());
        return warehouseDistributeItemConvertor.toDto(itemPos);
    }

    @Override
    public List<WarehouseDistributeOrderItemExportDto> getExportDtoList(BasePageParam<WarehouseDistributeOrderPageSearchReq> req) {

        WarehouseDistributeOrderPageSearchReq param = req.getParam();
        List<Long> ids = param.getIds();
        if (CollUtil.isEmpty(ids)) {
            List<WarehouseDistributeOrderDto> cur;
            List<WarehouseDistributeOrderDto> all = new ArrayList<>();
            req.setSize(2000);
            //限制导出最大一万条
            int count = PAGE_START_AT;
            while (all.size() < TEN_THOUSAND && !(cur = warehouseDistributeOrderService.pageSearch(req).getData().getRecords()).isEmpty()) {
                req.setPage(++count);
                all.addAll(cur);
            }
            ids = all.stream().map(WarehouseDistributeOrderDto::getId).collect(Collectors.toList());
        }

        List<WarehouseDistributeOrderPo> orderPos = warehouseDistributeOrderService.listByIds(ids);

        List<String> orderNos = orderPos.stream().map(WarehouseDistributeOrderPo::getOrderNo).collect(Collectors.toList());
        List<WarehouseDistributeOrderPo> childes = warehouseDistributeOrderService.list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery().in(WarehouseDistributeOrderPo::getAssociateBillNo, orderNos));
        orderPos.addAll(childes);
        if (CollUtil.isEmpty(orderPos)) {
            return Collections.emptyList();
        }
        List<WarehouseDistributeOrderItemExportDto> res = new ArrayList<>();
        List<WarehouseDistributeOrderDto> warehouseDistributeOrderDtoList = warehouseDistributeOrderService.getWarehouseDistributeOrderDtoList(orderPos, orderPos.get(0).getBizType());
        Map<String, WarehouseDistributeOrderDto> dtoMap = warehouseDistributeOrderDtoList.stream().collect(Collectors.toMap(WarehouseDistributeOrderDto::getOrderNo, Function.identity(), (o, n) -> o));
        List<WarehouseDistributeAttachDto> attachDto = warehouseDistributeAttachService.getDto(orderPos.get(0).getBizType(), new ArrayList<>(dtoMap.keySet()));
        Map<String, WarehouseDistributeAttachDto> attachDtoMap = attachDto.stream().collect(Collectors.toMap(WarehouseDistributeAttachDto::getWarehouseDistributeOrderNo, Function.identity()));
        List<WarehouseDistributeLogisticPo> logisticDtoList = warehouseDistributeLogisticService.list(Wrappers.<WarehouseDistributeLogisticPo>lambdaQuery().in(WarehouseDistributeLogisticPo::getWarehouseDistributeOrderNo, dtoMap.keySet()));
        Map<String, WarehouseDistributeLogisticPo> logisticDtoMap = logisticDtoList.stream().peek(e -> aesUtil.decode(e)).collect(Collectors.toMap(WarehouseDistributeLogisticPo::getWarehouseDistributeOrderNo, Function.identity()));

        List<WarehouseDistributeItemPo> list = list(Wrappers.<WarehouseDistributeItemPo>lambdaQuery().in(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, orderNos));
        List<WarehouseDistributeOrderItemDto> dtoList = getDtoList(req.getParam().getBizType(), list);

        Map<String, List<WarehouseDistributeOrderItemDto>> itemMap = dtoList.stream().collect(Collectors.groupingBy(WarehouseDistributeOrderItemDto::getWarehouseDistributeOrderNo));
        List<WarehouseDistributeItemAttachPo> itemAttachPos = warehouseDistributeItemAttachService.list(Wrappers.<WarehouseDistributeItemAttachPo>lambdaQuery().in(WarehouseDistributeItemAttachPo::getWarehouseDistributeOrderNo,orderNos));

        List<WarehouseDistributeAttachItemDto> attachItemDtoList = warehouseDistributeItemAttachService.getDtoList(itemAttachPos);
        Map<String, List<WarehouseDistributeAttachItemDto>> itemAttachMap = attachItemDtoList.stream().collect(Collectors.groupingBy(WarehouseDistributeAttachItemDto::getWarehouseDistributeOrderNo));

        HashSet<String> set = new HashSet<>();
        for (WarehouseDistributeOrderPo orderPo : orderPos) {
            if (set.contains(orderPo.getOrderNo())) {
                continue;
            }
            set.add(orderPo.getOrderNo());
            String orderNo = orderPo.getOrderNo();

            List<WarehouseDistributeOrderItemDto> itemDtoList = itemMap.get(orderNo);
            List<WarehouseDistributeAttachItemDto> itemAttachPoList = itemAttachMap.getOrDefault(orderNo,new ArrayList<>());
            Map<String, WarehouseDistributeAttachItemDto> attachItemDtoMap = itemAttachPoList.stream().collect(Collectors.toMap(WarehouseDistributeAttachItemDto::getMaterialLineNo, Function.identity()));
            for (WarehouseDistributeOrderItemDto dto : itemDtoList) {
                WarehouseDistributeOrderItemExportDto exportDto = warehouseDistributeItemConvertor.toDto(dtoMap.get(orderNo), dto, logisticDtoMap.get(orderNo), attachDtoMap.get(orderNo), attachItemDtoMap.get(dto.getMaterialLineNo()));
                res.add(exportDto);
            }
        }
        return res;
    }

    /**
     * 获取对应业务类新基础数据
     */
    private void getBaseDateResult(String bizType, List<String> warehouseCode, List<String> supplierCode,
                                   List<String> materialCodeAndBizType, List<AreaCheckReq> areaCode, List<LocationCheckReq> locationCode,
                                   List<BaseDataResp> baseResults, List<String> dictCode) {
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setWarehouseCodes(warehouseCode);
        baseDataReq.setSupplierCodes(supplierCode);
        baseDataReq.setMaterialCodes(materialCodeAndBizType);
        baseDataReq.setAreaCheckReqs(areaCode);
        baseDataReq.setLocationCheckReqs(locationCode);
        baseDataReq.setDictCodes(dictCode);
        BaseResult<BaseDataResp> baseDataRespBaseResult = spsClient.searchBaseData(baseDataReq);
        baseResults.add(baseDataRespBaseResult.getData());
    }
}
