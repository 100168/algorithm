package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import com.jiduauto.dit.outbox.OutboxMessageService;
import com.jiduauto.sps.order.server.client.*;
import com.jiduauto.sps.order.server.client.req.IndirectWDApplyOrderCloseReq;
import com.jiduauto.sps.order.server.client.req.TrackDetailReq;
import com.jiduauto.sps.order.server.client.resp.IndirectSrmWDCloseResp;
import com.jiduauto.sps.order.server.client.resp.ResultResp;
import com.jiduauto.sps.order.server.client.resp.TrackDetailResp;
import com.jiduauto.sps.order.server.convertor.*;
import com.jiduauto.sps.order.server.handler.WDOrderAddThreadLocalHolder;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.*;
import com.jiduauto.sps.order.server.mapper.WarehouseDistributeOrderMapper;
import com.jiduauto.sps.order.server.pojo.dto.*;
import com.jiduauto.sps.order.server.pojo.fileimport.WarehouseDistributeOrderImportExportResp;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.WarehouseDistributeOrderPageSearchReq;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.order.server.utils.AESUtil;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.client.req.*;
import com.jiduauto.sps.sdk.client.resp.QueryProcessCodeResp;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.consts.OutboxConst;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.pojo.dto.*;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.*;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportParamDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportReturnDataInfo;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.*;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.pojo.vo.BosFileResult;
import com.jiduauto.sps.sdk.service.IBosService;
import com.jiduauto.sps.sdk.service.ICommonFileAttachmentService;
import com.jiduauto.sps.sdk.service.ICommonService;
import com.jiduauto.sps.sdk.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.InputStream;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.jiduauto.sps.order.server.handler.warehousedistributeorder.WDJobIndexEnum.GENERATE_OUTBOUND_ORDER;
import static com.jiduauto.sps.order.server.handler.warehousedistributeorder.WDJobIndexEnum.GENERATE_PENDING_RECEIVE_ORDER;
import static com.jiduauto.sps.sdk.consts.BaseConstants.ImportExport.PAGE_START_AT;
import static com.jiduauto.sps.sdk.consts.BaseConstants.ListMaxSize.TEN_THOUSAND;
import static com.jiduauto.sps.sdk.consts.OutboxConst.MessageType.STOCK_OUT_MAP_BUSINESS_TO_SPS;

/**
 * <p>
 * 仓配订单 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
@Service
@Slf4j
public class WarehouseDistributeOrderServiceImpl extends ServiceImpl<WarehouseDistributeOrderMapper, WarehouseDistributeOrderPo> implements IWarehouseDistributeOrderService {

    public static final String TABLE_NAME = "warehouse_distribute_order";

    @Resource
    private WarehouseDistributeOrderImportHandler warehouseDistributeOrderImportHandler;

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;
    @Resource
    private IWarehouseDistributeAttachService warehouseDistributeAttachService;

    @Resource
    private IWarehouseDistributeLogisticService warehouseDistributeLogisticService;

    @Resource
    private IWarehouseDistributeItemPackageService warehouseDistributeItemPackageService;

    @Resource
    private IWarehouseDistributeItemAttachService warehouseDistributeItemAttachService;
    @Resource
    private IWarehouseDistributeItemService warehouseDistributeItemService;
    @Resource
    private WarehouseDistributeOrderConvertor warehouseDistributeOrderConvertor;

    @Resource
    private WarehouseDistributeItemConvertor warehouseDistributeItemConvertor;
    @Resource
    private WarehouseDistributeLogisticConvertor warehouseDistributeLogisticConvertor;

    @Resource
    private WarehouseDistributeItemPackageConvertor warehouseDistributeItemPackageConvertor;
    @Resource
    private WarehouseDistributeItemAttachConvertor warehouseDistributeItemAttachConvertor;

    @Resource
    private SpsClient spsClient;
    @Resource
    private ICommonService commonService;

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private AESUtil aesUtil;


    @Resource
    private PdpClient pdpClient;

    @Resource
    private OutboxMessageService outboxMessageService;

    @Resource
    private OutboundReqConvertor outboundReqConvertor;
    @Resource
    private InboundReqConvertor inboundReqConvertor;

    @Resource
    private WmsClient wmsClient;
    @Resource
    private IBaseDataRespCheckService baseDataRespCheckService;

    @Resource
    private AsnConvertor asnConvertor;

    @Resource
    private ChargePartnerClient chargePartnerClient;


    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private IBosService bosService;

    @Resource
    private ICommonFileAttachmentService commonFileAttachmentService;


    @Resource
    private SyncToTmsLogisticHandler syncToTmsLogisticHandler;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private ChargePartnerAuthClient chargePartnerAuthClient;

    @Resource
    private TransferInToESHandler transferInToESHandler;

    @Resource
    private OutboundCommandHandler outboundCommandHandler;

    @Resource
    private PendingReceiveListHandler pendingReceiveListHandler;

    @Resource
    private OutboundApplyOrderHandler outboundApplyOrderHandler;
    @Resource
    private WarehouseDistributeOrderAttachConvertor warehouseDistributeOrderAttachConvertor;

    @Resource
    private IndirectSrmClient indirectSrmClient;

    /**
     * 更新 仓配订单的 物流单号
     *
     * @param id          订单Id
     * @param logisticsNo 物流单号（运单号）
     */
    @Override
    public void updateLogisticsNo(Long id, String logisticsNo) {
        WarehouseDistributeOrderPo warehouseDistributeOrderPo = getById(id);
        if (Objects.isNull(warehouseDistributeOrderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        warehouseDistributeOrderPo.setLogisticNo(logisticsNo);
        warehouseDistributeOrderPo.setUpdateTime(LocalDateTime.now());
        updateById(warehouseDistributeOrderPo);
    }

    @Override
    public void updateLogisticsNoAndStatus(Long id, String logisticsNo) {
        WarehouseDistributeOrderPo warehouseDistributeOrderPo = getById(id);
        if (Objects.isNull(warehouseDistributeOrderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        warehouseDistributeOrderPo.setLogisticNo(logisticsNo);
        if (WarehouseDistributeOrderStatusEnum.canChangeStatusToShipped(warehouseDistributeOrderPo.getOrderStatus())) {
            warehouseDistributeOrderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.SHIPPED.getCode());
        }
        warehouseDistributeOrderPo.setUpdateTime(LocalDateTime.now());
        updateById(warehouseDistributeOrderPo);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public WarehouseDistributeOrderAllPo add(WarehouseDistributeOrderAddReq request, boolean isApi) {
        WarehouseDistributeOrderReq head = request.getHead();
        List<WarehouseDistributeItemReq> items = request.getItems();
        //数据校验
        checkAddParam(request);
        initSupplierCode(request);
        //req数据转成po
        WarehouseDistributeOrderPo warehouseDistributeOrderPo = warehouseDistributeOrderConvertor.toPo(head);
        warehouseDistributeOrderPo.setOrderTime(DateUtils.parse(head.getOrderTime(), DateUtils.STANDARD_TIME_FORMAT));
        List<WarehouseDistributeItemPo> warehouseDistributeItemPos = warehouseDistributeItemConvertor.toPo(items);
        WarehouseDistributeLogisticPo warehouseDistributeLogisticPo = warehouseDistributeLogisticConvertor.toPo(request.getLogistic());
        setWarehouseDistributeLogisticPo(warehouseDistributeLogisticPo);
        List<WarehouseDistributeItemPackagePo> itemPackagePos = warehouseDistributeItemPackageConvertor.toPo(request.getItemPackages());
        List<WarehouseDistributeItemAttachPo> itemAttachPos = warehouseDistributeItemAttachConvertor.toPo(request.getItemAttaches());
        WarehouseDistributeAttachPo attachPo = warehouseDistributeOrderAttachConvertor.toPo(request.getAttach());

        if (attachPo != null) {
            attachPo.setWarehouseDistributeOrderNo(warehouseDistributeOrderPo.getOrderNo());
            if (CollUtil.isNotEmpty(itemAttachPos)) {
                attachPo.setApplyPurpose(itemAttachPos.get(0).getApplyPurpose());
            }
            attachPo.setBizType(warehouseDistributeOrderPo.getBizType());
        }
        warehouseDistributeLogisticPo.setBizType(warehouseDistributeOrderPo.getBizType());
        warehouseDistributeOrderPo.setIsApi(isApi);
        warehouseDistributeOrderPo.setIsSpecial(Objects.equals(head.getOccupyStock(), 1));
        warehouseDistributeOrderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.CREATED.getCode());
        warehouseDistributeLogisticPo.setWarehouseDistributeOrderNo(warehouseDistributeOrderPo.getOrderNo());
        warehouseDistributeItemPos = warehouseDistributeItemPos
                .stream().peek(e -> {
                    e.setWarehouseDistributeOrderNo(warehouseDistributeOrderPo.getOrderNo());
                    if (WarehouseDistributeOrderTypeEnum.isQe(head.getOrderType()) && StrUtil.isNotEmpty(e.getBatchNo())) {
                        e.setMaterialBarCode(e.getBatchNo() + StrUtil.DASHED + e.getMaterialCode());
                    }
                })
                .collect(Collectors.toList());
        if (Objects.isNull(itemPackagePos)) {
            itemPackagePos = CollUtil.newArrayList();
        }
        warehouseDistributeOrderPo.setLogisticNo(request.getLogistic().getLogisticNo());
        itemPackagePos = itemPackagePos.stream().peek(e -> {
            e.setWarehouseDistributeOrderNo(warehouseDistributeOrderPo.getOrderNo());
            e.setBizType(warehouseDistributeOrderPo.getBizType());
        }).collect(Collectors.toList());

        if (Objects.isNull(itemAttachPos)) {
            itemAttachPos = CollUtil.newArrayList();
        }
        itemAttachPos = itemAttachPos.stream().peek(e -> {
            e.setWarehouseDistributeOrderNo(warehouseDistributeOrderPo.getOrderNo());
            e.setBizType(warehouseDistributeOrderPo.getBizType());
        }).collect(Collectors.toList());
        //更新附件
        if (CollUtil.isNotEmpty(request.getFileIdList())) {
            commonFileAttachmentService.update(Wrappers.lambdaUpdate(CommonFileAttachmentPo.class)
                    .in(CommonFileAttachmentPo::getId, request.getFileIdList())
                    .eq(CommonFileAttachmentPo::getSourceTable, TABLE_NAME)
                    .eq(CommonFileAttachmentPo::getBizType, warehouseDistributeOrderPo.getBizType())
                    .set(CommonFileAttachmentPo::getOrderNo, warehouseDistributeOrderPo.getOrderNo())
                    .set(CommonFileAttachmentPo::getIsDel, false)
            );
        }
        fillOrderProcessCode(warehouseDistributeOrderPo, warehouseDistributeLogisticPo);
        //加密物流信息
        aesUtil.encode(warehouseDistributeLogisticPo);
        save(warehouseDistributeOrderPo);
        warehouseDistributeItemService.saveBatch(warehouseDistributeItemPos);
        warehouseDistributeLogisticService.save(warehouseDistributeLogisticPo);
        warehouseDistributeItemAttachService.saveBatch(itemAttachPos);
        warehouseDistributeItemPackageService.saveBatch(itemPackagePos);

        if (attachPo != null) {
            warehouseDistributeAttachService.save(attachPo);
        }

        if (WarehouseDistributeOrderTypeEnum.isSpecialAppLyOrder(warehouseDistributeOrderPo.getOrderType())) {
            occupyCheck(warehouseDistributeOrderPo, warehouseDistributeLogisticPo, warehouseDistributeItemPos);
        }

        //解密物流信息，后面需要用到
        aesUtil.decode(warehouseDistributeLogisticPo);
        //包装一个大对象返回
        return WarehouseDistributeOrderAllPo
                .builder()
                .warehouseDistributeOrderPo(warehouseDistributeOrderPo)
                .warehouseDistributeLogisticPo(warehouseDistributeLogisticPo)
                .items(warehouseDistributeItemPos)
                .itemAttaches(itemAttachPos)
                .ItemPackages(itemPackagePos)
                .build();
    }

    private void occupyCheck(WarehouseDistributeOrderPo warehouseDistributeOrderPo, WarehouseDistributeLogisticPo warehouseDistributeLogisticPo, List<WarehouseDistributeItemPo> warehouseDistributeItemPos) {
        if (Objects.equals(warehouseDistributeOrderPo.getIsChild(), Boolean.TRUE)) {
            return;
        }
        InAndOutStockRequest req = new InAndOutStockRequest();
        req.setBusinessBillNo(warehouseDistributeOrderPo.getBusinessBillNo());
        req.setIdempotentNo(warehouseDistributeLogisticPo.getWarehouseDistributeOrderNo());
        req.setBusinessType(warehouseDistributeOrderPo.getOrderType());
        req.setOperateTime(LocalDateTime.now());
        req.setOperationType(OperationType.UN_OCCUPY);
        req.setStockSource(StockSource.SYS);
        req.setBizType(warehouseDistributeOrderPo.getBizType());
        req.setTradeNo(warehouseDistributeOrderPo.getBusinessBillNo());
        List<InAndOutStockParam> params = buildStockRequestItem(warehouseDistributeItemPos, warehouseDistributeLogisticPo, warehouseDistributeOrderPo);
        req.setParams(params);
        spsClient.checkWdoOccupy(req).check();
    }

    /**
     * 填充流程code
     */
    private void fillOrderProcessCode(WarehouseDistributeOrderPo warehouseDistributeOrderPo,
                                      WarehouseDistributeLogisticPo warehouseDistributeLogisticPo) {
        boolean needIn = wdOrderJobContext.needExecuteJob(WarehouseDistributeOrderTypeEnum.getByType(warehouseDistributeOrderPo.getOrderType()), GENERATE_PENDING_RECEIVE_ORDER) || !WarehouseDistributeOrderTypeEnum.isExist(warehouseDistributeOrderPo.getOrderType()) && Integer.valueOf(warehouseDistributeOrderPo.getLogisticType()).equals(WarehouseDistributeOrderlogisticTypeEnum.PUT_IN.getValue());
        boolean needOut = wdOrderJobContext.needExecuteJob(WarehouseDistributeOrderTypeEnum.getByType(warehouseDistributeOrderPo.getOrderType()), GENERATE_OUTBOUND_ORDER) || !WarehouseDistributeOrderTypeEnum.isExist(warehouseDistributeOrderPo.getOrderType()) && Integer.valueOf(warehouseDistributeOrderPo.getLogisticType()).equals(WarehouseDistributeOrderlogisticTypeEnum.PUT_OUT.getValue());
        if (!needIn && !needOut) {
            return;
        }
        QueryProcessCodeReq req = new QueryProcessCodeReq();
        req.setBizType(warehouseDistributeOrderPo.getBizType());
        req.setOrderType(warehouseDistributeOrderPo.getOrderType());
        req.setInWarehouseCode(needIn ? warehouseDistributeLogisticPo.getReceiveWarehouseCode() : null);
        req.setOutWarehouseCode(needOut ? warehouseDistributeLogisticPo.getDeliverWarehouseCode() : null);

        BaseResult<QueryProcessCodeResp> ret = spsClient.queryInAndOutProcessCode(req).check();

        warehouseDistributeOrderPo.setInProcessCode(needIn ? ret.getData().getInCode() : null);
        warehouseDistributeOrderPo.setOutProcessCode(needOut ? ret.getData().getOutCode() : null);
    }

    private void setWarehouseDistributeLogisticPo(WarehouseDistributeLogisticPo po) {
        Map<String, String> addressMap = baseDataQuery.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());
        if (StrUtil.isNotEmpty(po.getReceiveProvinceCode())) {
            po.setReceiveProvinceName(addressMap.get(po.getReceiveProvinceCode()));
        }
        if (StrUtil.isNotEmpty(po.getReceiveCityCode())) {
            po.setReceiveCityName(addressMap.get(po.getReceiveCityCode()));
        }
        if (StrUtil.isNotEmpty(po.getReceiveDistrictCode())) {
            po.setReceiveDistrictName(addressMap.get(po.getReceiveDistrictCode()));
        }

        if (StrUtil.isNotEmpty(po.getDeliverProvinceCode())) {
            po.setDeliverProvinceName(addressMap.get(po.getDeliverProvinceCode()));
        }
        if (StrUtil.isNotEmpty(po.getDeliverCityCode())) {
            po.setDeliverCityName(addressMap.get(po.getDeliverCityCode()));
        }
        if (StrUtil.isNotEmpty(po.getDeliverDistrictCode())) {
            po.setDeliverDistrictName(addressMap.get(po.getDeliverDistrictCode()));
        }

    }

    public void checkAddParam(WarehouseDistributeOrderAddReq request) {

        Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(DictEnum.DistributeType.getDictCode());

        if (!codeAndNameMap.containsKey(request.getHead().getOrderType())) {
            throw new BizException("订单类型不存在");
        }

        if (StrUtil.containsBlank(request.getLogistic().getLogisticNo())) {
            throw new BizException("运单号存在空格,请确认单号是否正确");
        }
        //间采srm明细业务类型填订单业务类型
        if (WarehouseDistributeOrderTypeEnum.isSrm(request.getHead().getOrderType())) {
            for (WarehouseDistributeItemReq item : request.getItems()) {
                BizTypeEnum anEnum = BizTypeEnum.getByBizType(item.getBizType());
                if (anEnum == null) {
                    item.setBizType(request.getHead().getBizType());
                }
            }
        }
        List<WarehouseDistributeItemAttachReq> itemAttaches = request.getItemAttaches();
        List<WarehouseDistributeItemReq> items = request.getItems();
        if (CollUtil.isNotEmpty(itemAttaches)) {
            Set<String> attachLineSet = itemAttaches.stream()
                    .map(WarehouseDistributeItemAttachReq::getMaterialLineNo)
                    .collect(Collectors.toSet());
            Set<String> itemLineSet = items.stream().map(WarehouseDistributeItemReq::getMaterialLineNo).collect(Collectors.toSet());
            if (!CollUtil.containsAll(itemLineSet, attachLineSet)) {
                throw new BizException("零件附属信息行号有误");
            }
        }
        //校验仓库
        checkWarehouseCode(request);
        List<String> duplicateMaterialLineNo = items.stream()
                .collect(Collectors.toMap(WarehouseDistributeItemReq::getMaterialLineNo, e -> 1, Integer::sum))
                .entrySet().stream().filter(e -> e.getValue() > 1).map(Map.Entry::getKey).collect(Collectors.toList());
        if (CollUtil.isNotEmpty(duplicateMaterialLineNo)) {
            throw new BizException(SpsResponseCodeEnum.LINE_NO_ERROR);
        }
        Map<String, List<WarehouseDistributeItemReq>> bizMaterailMap = items.stream().collect(Collectors.groupingBy(WarehouseDistributeItemReq::getBizType));

        for (Map.Entry<String, List<WarehouseDistributeItemReq>> entry : bizMaterailMap.entrySet()) {
            BaseDataReq baseDataReq = new BaseDataReq();
            baseDataReq.setBizType(entry.getKey());
            baseDataReq.setMaterialCodes(entry.getValue().stream().map(WarehouseDistributeItemReq::getMaterialCode).collect(Collectors.toList()));
            BaseResult<BaseDataResp> resp = spsClient.searchBaseData(baseDataReq);
            baseDataRespCheckService.check(resp, baseDataReq);
        }

        if (!request.getHead().getBizType().equals(BizTypeEnum.SM.getBizType())) {
            for (WarehouseDistributeItemReq item : items) {
                if (!item.getBizType().equals(request.getHead().getBizType())) {
                    throw new BizException("零件业务类型与订单业务类型不相同");
                }
            }
        }
    }

    /**
     * 校验仓库是否存在
     */
    private void checkWarehouseCode(WarehouseDistributeOrderAddReq request) {
        WarehouseDistributeOrderReq head = request.getHead();
        WarehouseDistributeOrderTypeEnum distributeOrderTypeEnum = WarehouseDistributeOrderTypeEnum.getByType(head.getOrderType());
        //商城订单校验发货仓库
        BaseDataReq baseDataReq = new BaseDataReq();
        ArrayList<String> warehouseCodes = new ArrayList<>();
        if (distributeOrderTypeEnum == WarehouseDistributeOrderTypeEnum.SM20) {
            warehouseCodes.add(request.getLogistic().getDeliverWarehouseCode());
        }
        //间采asn校验收货仓库
        if (distributeOrderTypeEnum != null && WarehouseDistributeOrderTypeEnum.isDirAsn(distributeOrderTypeEnum.getValue())) {
            warehouseCodes.add(request.getLogistic().getReceiveWarehouseCode());
        }
        if (distributeOrderTypeEnum != null && WarehouseDistributeOrderTypeEnum.isApplyOrder(distributeOrderTypeEnum.getValue())) {
            warehouseCodes.add(request.getLogistic().getDeliverWarehouseCode());
        }
        if (CollUtil.isEmpty(warehouseCodes)) {
            return;
        }
        baseDataReq.setWarehouseCodes(warehouseCodes);
        baseDataReq.setBizType(BizTypeEnum.getParentBizType(head.getBizType()));
        BaseResult<BaseDataResp> resp = spsClient.searchBaseData(baseDataReq);
        baseDataRespCheckService.check(resp, baseDataReq);

    }

    /**
     * 订单类型为QE11、QE12 根据零件号去SP 框架协议去找对应供应商信息，
     * 若匹配到多个不同值，则不赋值，若只有一个值，则赋值到供应商代码上
     * sm11去出库结果清单找
     */
    private void initSupplierCode(WarehouseDistributeOrderAddReq req) {

        WarehouseDistributeItemReq warehouseDistributeItemReq = req.getItems().get(0);
        if (StrUtil.isNotEmpty(warehouseDistributeItemReq.getSupplierCode())) {
            SupplierPo supplierPo = new SupplierPo();
            supplierPo.setSupplierName(warehouseDistributeItemReq.getSupplierName());
            supplierPo.setSapCode(warehouseDistributeItemReq.getSupplierCode());
            supplierPo.setAddress(warehouseDistributeItemReq.getSupplierAddress());
            supplierPo.setBizType(req.getHead().getBizType());
            WDOrderAddThreadLocalHolder.put(WDOrderAddThreadLocalHolder.SUPPLIER, supplierPo);
        }
        List<WarehouseDistributeItemReq> items = req.getItems();
        if (req.getHead().getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM11.getValue())) {
            OrderNoReq orderNoReq = new OrderNoReq();
            orderNoReq.setBizType(req.getHead().getBizType());
            orderNoReq.setOrderNo(req.getHead().getAssociateBillNo());
            BaseResult<List<StockOutOrderItemPo>> resp = spsClient.getStockOutOrderItemList(orderNoReq);
            if (!resp.isSuccess()) {
                throw new BizException(resp.getMessage());
            }
            Map<String, String> stockOutOrderItemPoMap = resp.getData().stream().collect(Collectors.toMap(e -> e.getBizType() + e.getMaterialNumber(), StockOutOrderItemPo::getSupplierCode, (o, n) -> o));
            for (WarehouseDistributeItemReq item : items) {
                if (StrUtil.isEmpty(item.getSupplierCode())) {
                    item.setSupplierCode(stockOutOrderItemPoMap.get(item.getBizType() + item.getMaterialCode()));
                }
            }
            return;
        }
        if (WarehouseDistributeOrderTypeEnum.needWriteSupplierCode(req.getHead().getOrderType())) {
            BaseDataReq baseDataReq = new BaseDataReq();
            baseDataReq.setBizType(BizTypeEnum.SP.getBizType());
            baseDataReq.setMaterialCodes(items.stream().map(WarehouseDistributeItemReq::getMaterialCode)
                    .collect(Collectors.toList()));
            BaseResult<Map<String, List<PriceLedgerItemDto>>> mapBaseResult = spsClient.searchFrameContract(baseDataReq);
            if (!mapBaseResult.isSuccess()) {
                throw new BizException(mapBaseResult.getMessage());
            }
            Map<String, List<PriceLedgerItemDto>> frameContractDtoMap = mapBaseResult.getData();
            for (WarehouseDistributeItemReq e : items) {
                frameContractDtoMap.computeIfPresent(e.getMaterialCode(), (k, v) -> {
                    if (v.size() == 1) {
                        e.setSupplierCode(v.get(0).getSupplierCode());
                    } else {
                        //没有查询到就置空
                        e.setSupplierCode("");
                    }
                    return v;
                });
            }
        }
    }


    private List<InAndOutStockParam> buildStockRequestItem(List<WarehouseDistributeItemPo> distributeItemPos,
                                                           WarehouseDistributeLogisticPo warehouseDistributeLogisticPo, WarehouseDistributeOrderPo po) {
        List<InAndOutStockParam> list = new ArrayList<>();
        for (WarehouseDistributeItemPo stockInfo : distributeItemPos) {
            InAndOutStockParam param = new InAndOutStockParam();
            param.setMaterialCode(stockInfo.getMaterialCode());
            param.setWarehouseCode(warehouseDistributeLogisticPo.getDeliverWarehouseCode());
            param.setMaterialStatus(stockInfo.getMaterialStatus());
            param.setStockStatus(stockInfo.getStockStatus());
            param.setOccupyQuantity(stockInfo.getQty());
            param.setSumQuantity(stockInfo.getQty());
            //存在部分出库
            if (po.getOrderType().equals(WarehouseDistributeOrderTypeEnum.CL21.getValue()) || po.getOrderType().equals(WarehouseDistributeOrderTypeEnum.JC21.getValue())) {
                param.setOccupyQuantity(stockInfo.getQty().subtract(Optional.ofNullable(stockInfo.getRealOutQty()).orElse(BigDecimal.ZERO)));
                param.setSumQuantity(stockInfo.getQty().subtract(Optional.ofNullable(stockInfo.getRealOutQty()).orElse(BigDecimal.ZERO)));
            }
            if (param.getOccupyQuantity().compareTo(BigDecimal.ZERO) != 0) {
                list.add(param);
            }
        }
        return list;
    }

    /**
     * 仓配订单号的校验
     *
     * @param applyOrderNo
     */
    private void checkOrderByOrderNo(String applyOrderNo) {
        WarehouseDistributeOrderPo one = getOne(Wrappers.lambdaQuery(WarehouseDistributeOrderPo.class)
                .eq(WarehouseDistributeOrderPo::getOrderNo, applyOrderNo));
        if (Objects.isNull(one)) {
            throw new BizException("未匹配到该(" + applyOrderNo + ")仓配订单");
        }
        checkOrderStatus(one);
    }

    private void checkOrderStatus(WarehouseDistributeOrderPo one) {
        if (!WarehouseDistributeOrderStatusEnum.canOperate(one.getOrderStatus())) {
            throw new BizException("订单状态不可操作(" + one.getOrderNo() + ")");
        }
    }

    private BigDecimal min(BigDecimal a, BigDecimal b) {
        if (a.compareTo(b) > 0) {
            return b;
        }
        return a;
    }

    @Override
    public WarehouseDistributeOrderPo getByBusinessBillOrderNo(String bizType, String businessBillNo) {
        return warehouseDistributeOrderService.getOne(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                .eq(WarehouseDistributeOrderPo::getBizType, bizType)
                .ne(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.CANCELED.getCode())
                .eq(WarehouseDistributeOrderPo::getBusinessBillNo, businessBillNo));
    }

    @Override
    public List<WarehouseDistributeOrderPo> getByBusinessBillOrderNoList(String bizType, List<String> businessBillNo) {
        return warehouseDistributeOrderService.list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                .eq(WarehouseDistributeOrderPo::getBizType, bizType)
                .ne(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.CANCELED.getCode())
                .in(WarehouseDistributeOrderPo::getBusinessBillNo, businessBillNo));
    }

    /**
     * 根据 订单号 找仓配订单
     *
     * @param bizType bizType
     * @param orderNo orderNo
     * @return WarehouseDistributeOrderPo
     */
    @Override
    public WarehouseDistributeOrderPo getByOrderNo(String bizType, String orderNo) {
        return warehouseDistributeOrderService.getOne(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                .eq(WarehouseDistributeOrderPo::getOrderNo, orderNo));
    }


    @Transactional(rollbackFor = Exception.class)
    @Override
    public void pushToSap(WarehouseDistributeOrderPo warehouseDistributeOrderPo) {
        if (warehouseDistributeOrderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM20.getValue())) {
            outboxMessageService.saveMessage(OutboxConst.MessageType.SM_ORDER_RECEIVE_TO_SAP, JSONUtil.toJsonStr(warehouseDistributeOrderPo));
        } else {
            outboxMessageService.saveMessage(OutboxConst.MessageType.SM30_RECEIVE_TO_SAP, JSONUtil.toJsonStr(warehouseDistributeOrderPo));
        }
    }

    @Override
    public void occupyStock(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {
        ArrayList<InAndOutStockRequest> requests = new ArrayList<>();
        Map<String, List<WarehouseDistributeItemPo>> map = warehouseDistributeOrderAllPo.getItems().stream()
                .collect(Collectors.groupingBy(WarehouseDistributeItemPo::getBizType));
        WarehouseDistributeLogisticPo warehouseDistributeLogisticPo = warehouseDistributeOrderAllPo.getWarehouseDistributeLogisticPo();
        WarehouseDistributeOrderPo warehouseDistributeOrderPo = warehouseDistributeOrderAllPo.getWarehouseDistributeOrderPo();
        for (Map.Entry<String, List<WarehouseDistributeItemPo>> entry : map.entrySet()) {
            InAndOutStockRequest request = new InAndOutStockRequest();
            request.setBusinessBillNo(warehouseDistributeOrderPo.getBusinessBillNo());
            request.setIdempotentNo(warehouseDistributeLogisticPo.getWarehouseDistributeOrderNo() + entry.getKey());
            request.setTradeNo(warehouseDistributeLogisticPo.getWarehouseDistributeOrderNo());
            request.setBusinessType(warehouseDistributeOrderPo.getOrderType());
            request.setOperateTime(LocalDateTime.now());
            request.setOperationType(OperationType.OCCUPY);
            request.setStockSource(StockSource.SYS);
            request.setBizType(entry.getKey());
            List<InAndOutStockParam> stockParams = buildStockRequestItem(entry.getValue(), warehouseDistributeLogisticPo, warehouseDistributeOrderPo);
            request.setParams(stockParams);
            request.addExtraInfo("occupyNo", StrUtil.blankToDefault(warehouseDistributeOrderPo.getBusinessBillNo(), warehouseDistributeOrderPo.getOrderNo()));
            requests.add(request);
        }
        BaseResult<String> resp = spsClient.putOutStockMultiBizType(requests);
        if (!resp.isSuccess()) {
            throw new BizException(resp.getMessage());
        }
    }

    @Override
    public void reOccupy() {
        List<WarehouseDistributeOrderPo> warehouseDistributeOrderPos = list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                .eq(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.OUT_STOCK_FAILED.getCode()));
        for (WarehouseDistributeOrderPo distributeOrderPo : warehouseDistributeOrderPos) {
            WarehouseDistributeLogisticPo logisticPo = warehouseDistributeLogisticService.getOne(Wrappers.<WarehouseDistributeLogisticPo>lambdaQuery()
                    .eq(WarehouseDistributeLogisticPo::getWarehouseDistributeOrderNo, distributeOrderPo.getOrderNo()));
            List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService
                    .list(Wrappers.<WarehouseDistributeItemPo>lambdaQuery()
                            .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, distributeOrderPo.getOrderNo()));
            occupyStock(WarehouseDistributeOrderAllPo
                    .builder()
                    .warehouseDistributeOrderPo(distributeOrderPo)
                    .warehouseDistributeLogisticPo(logisticPo)
                    .items(itemPos)
                    .build());
        }

    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStatusAndSyncDhlIfSuccess(StockPutOutResultMessage msg) {
        WarehouseDistributeOrderPo distributeOrderPo = getOne(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                .eq(WarehouseDistributeOrderPo::getOrderNo, msg.getTradeNo()));
        if (Objects.isNull(distributeOrderPo)) {
            log.warn("WarehouseDistributeOrderServiceImpl#updateStatusAndSyncDhlIfSuccess#仓配订单数据不存在");
            throw new BizException("数据不存在");
        }
        if (distributeOrderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.ES31.getValue())) {
            return;
        }
        if (WarehouseDistributeOrderStatusEnum.canRetry(distributeOrderPo.getOrderStatus())) {
            WarehouseDistributeOrderStatusEnum status = msg.isSuccess() || Objects.equals(msg.getResult(), SpsResponseCodeEnum.DUPLICATE_OPERATE.getCode()) ? WarehouseDistributeOrderStatusEnum.DELIVERED : WarehouseDistributeOrderStatusEnum.OUT_STOCK_FAILED;
            update(Wrappers.<WarehouseDistributeOrderPo>lambdaUpdate()
                    .eq(WarehouseDistributeOrderPo::getOrderNo, msg.getTradeNo())
                    .set(WarehouseDistributeOrderPo::getOrderStatus, status.getCode()));
            if (msg.isSuccess()) {
                outbound(distributeOrderPo);
                //出库关联清单
//                outboxMessageService.saveMessage(STOCK_OUT_MAP_BUSINESS_TO_SPS, JsonUtil.toJsonString(createStockOutMapBusinessDto(distributeOrderPo, logisticPo)));
            }
        }
    }


    //dhl出库指令
    private void outbound(WarehouseDistributeOrderPo distributeOrderPo) {
        WarehouseDistributeOrderAllPo allPo = buildAllPo(distributeOrderPo);
        distributeOrderPo.setIsSpecial(false);
        outboundCommandHandler.process(allPo);
        distributeOrderPo.setIsSpecial(true);
    }


    /**
     * 构建 出库关联订单请求体
     *
     * @param po
     * @return
     */
    @Override
    public StockOutMapBusinessDto createStockOutMapBusinessDto(WarehouseDistributeOrderPo po, WarehouseDistributeLogisticPo logisticPo) {
        List<StockOutMapBusinessItemDto> itemDtos = new ArrayList<>();
        StockOutMapBusinessDto dto = new StockOutMapBusinessDto();
        dto.setBizType(po.getBizType());
        dto.setOperateType(OperateTypeEnum.SAVE);
        dto.setBusinessNo(po.getBusinessBillNo());
        dto.setOrderNo(po.getOrderNo());
        dto.setOutType(po.getOrderType());
        dto.setTargetCity(logisticPo.getReceiveCityName());
        dto.setTargetAddress(logisticPo.getReceiveAddress());
        dto.setRemark(po.getRemark());
        if (po.getOrderType() != null) {
            WarehouseDistributeOrderTypeEnum tmsType = WarehouseDistributeOrderTypeEnum.getByType(po.getOrderType());
            if (tmsType == null || StringUtils.isBlank(tmsType.getTmsOrderType())) {
                dto.setOrderType("STK");
            } else {
                dto.setOrderType(tmsType.getTmsOrderType());
            }
        } else {
            dto.setOrderType("STK");
        }

        dto.setShippingMethod(logisticPo.getShippingMethod());
        dto.setOrderDate(DateUtils.getLocalDateTimeStr(po.getCreateTime(), DateUtils.STANDARD_TIME_FORMAT));
        WarehouseDistributeLogisticDto distributeLogisticDto = warehouseDistributeLogisticService.selectWarehouseDistributeLogistic(po.getBizType(), po.getOrderNo());
        List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.list(Wrappers.lambdaQuery(WarehouseDistributeItemPo.class)
                .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, po.getOrderNo()));
        for (WarehouseDistributeItemPo itemPo : itemPos) {
            StockOutMapBusinessItemDto itemDto = new StockOutMapBusinessItemDto();
            itemDto.setBizType(itemPo.getBizType());
            itemDto.setOrderNo(po.getOrderNo());
            //发货仓库
            itemDto.setWarehouseCode(distributeLogisticDto.getDeliverWarehouseCode());
            itemDto.setMaterialCode(itemPo.getMaterialCode());
            itemDto.setPlanQuantity(itemPo.getQty());
            itemDto.setRemark(itemPo.getRemark());
            itemDtos.add(itemDto);
        }
        dto.setDtos(itemDtos);
        return dto;
    }

    /**
     * 构建 取消 出库关联订单请求体
     *
     * @param po
     * @return
     */
    private StockOutMapBusinessDto cancelStockOutMapBusinessDto(WarehouseDistributeOrderPo po) {
        List<StockOutMapBusinessItemDto> itemDtos = new ArrayList<>();
        StockOutMapBusinessDto dto = new StockOutMapBusinessDto();
        dto.setOrderNo(po.getOrderNo());
        dto.setRemark(po.getReason());
        dto.setOperateType(OperateTypeEnum.CANCEL);
        dto.setDtos(itemDtos);
        return dto;
    }

    /**
     * 需要取消占用库存并下发到dhl
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean cancel(WarehouseDistributeOrderCancelReq request, boolean isApi) {
        String redisKey = String.format(BaseConstants.RedisKey.WAREHOUSE_DISTRIBUTE_ORDER_CANCEL_KEY,
                request.getBizType(),
                request.getOrderNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            WarehouseDistributeOrderPo orderPo = getOne(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery()
                    .eq(WarehouseDistributeOrderPo::getBizType, request.getBizType())
                    .eq(WarehouseDistributeOrderPo::getOrderNo, request.getOrderNo()));
            if (Objects.isNull(orderPo)) {
                throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
            }
            if (orderPo.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.CANCELED.getCode())) {
                return true;
            }
            if (!WarehouseDistributeOrderStatusEnum.canCancel(orderPo.getOrderStatus())) {
                throw new BizException(SpsResponseCodeEnum.CANCEL_ERROR);
            }

            //内领订单api调用取消只能是已创建状态
            if (isApi && WarehouseDistributeOrderTypeEnum.isApplyOrder(orderPo.getOrderType()) && !orderPo.getIsChild()) {
                if (!WarehouseDistributeOrderStatusEnum.CREATED.getCode().equals(orderPo.getOrderStatus())) {
                    throw new BizException("当前状态不可以取消");
                }
                orderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.CANCELED.getCode());
                orderPo.setUpdateTime(LocalDateTime.now());
                return updateById(orderPo);
            }
            WarehouseDistributeLogisticPo distributeLogisticPo = warehouseDistributeLogisticService
                    .getOne(Wrappers.<WarehouseDistributeLogisticPo>lambdaQuery()
                            .eq(WarehouseDistributeLogisticPo::getWarehouseDistributeOrderNo, orderPo.getOrderNo()));

            List<WarehouseDistributeItemPo> distributeItemPos = warehouseDistributeItemService
                    .list(Wrappers.<WarehouseDistributeItemPo>lambdaQuery()
                            .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, orderPo.getOrderNo()));
            orderPo.setReason(request.getReason());
            orderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.CANCELED.getCode());


            WarehouseDistributeOrderTypeEnum orderTypeEnum = WarehouseDistributeOrderTypeEnum.getByType(orderPo.getOrderType());

            switch (orderTypeEnum) {
                case SM20:
                case SP25:
                case JC25:
                case ES25:
                case SP29:
                case JC29:
                case ES29:
                case CL29:
                case SP28:
                case JC28:
                case ES28:
                case CL28: {
                    if (isSpecialWarehouse(orderPo.getBizType(), distributeLogisticPo.getDeliverWarehouseCode())) {
                        //下发到dhl
                        DHLOutboundReq dhlOutBoundReq = outboundReqConvertor.toDhlOutBoundReq(orderPo,
                                distributeItemPos,
                                distributeLogisticPo,
                                BaseConstants.OperateType.CANCEL);
                        ResultResp<Object> outbound = pdpClient.outbound(dhlOutBoundReq);
                        if (!outbound.isSuccess()) {
                            throw new BizException(outbound.getMsg());
                        }
                        //取消占库
                        cancelStock(distributeItemPos, distributeLogisticPo, orderPo);
                        //取消结果同步到 库存出库关联订单
                        outboxMessageService.saveMessage(STOCK_OUT_MAP_BUSINESS_TO_SPS, JsonUtil.toJsonString(cancelStockOutMapBusinessDto(orderPo)));
                        break;
                    }
                    if (orderTypeEnum == WarehouseDistributeOrderTypeEnum.ES28) {
                        ResultResp<Object> resp = chargePartnerAuthClient.cancelTransferWorkOrder(TransferToEsCancelReq.builder().bizNo(orderPo.getOrderNo()).type(1).bizSource(2).build());
                        if (!resp.isSuccess()) {
                            throw new BizException(resp.getMsg());
                        }
                        cancelStock(distributeItemPos, distributeLogisticPo, orderPo);
                        break;
                    }
                    OrderNoReq orderNoReq = new OrderNoReq();
                    orderNoReq.setOrderNo(orderPo.getOrderNo());
                    orderNoReq.setBizType(orderPo.getBizType());
                    spsClient.cancelOutboundApplyOrder(orderNoReq);
                    break;
                }
                case ES31: {
                    ResultResp<Object> resp = chargePartnerAuthClient.cancelTransferWorkOrder(TransferToEsCancelReq.builder().bizNo(orderPo.getOrderNo()).type(1).bizSource(1).build());
                    if (!resp.isSuccess()) {
                        throw new BizException(resp.getMsg());
                    }
                    cancelStock(distributeItemPos, distributeLogisticPo, orderPo);
                    break;
                }
                case SM11:
                case SM12:
                case SP11:
                case CL11:
                case JC11: {
                    cancelToDhl(orderPo, distributeLogisticPo, distributeItemPos);
                    break;
                }
                case ES11: {
                    if (isSpecialWarehouse(orderPo.getBizType(), distributeLogisticPo.getReceiveWarehouseCode())) {
                        cancelToDhl(orderPo, distributeLogisticPo, distributeItemPos);
                        break;
                    }
                    AsnPushReq asnPushReq = asnConvertor.toAsnPushReq(WarehouseDistributeOrderAllPo.builder()
                            .warehouseDistributeOrderPo(orderPo)
                            .warehouseDistributeLogisticPo(distributeLogisticPo)
                            .warehouseDistributeAttachPo(new WarehouseDistributeAttachPo())
                            .items(distributeItemPos)
                            .ItemPackages(Lists.newArrayList())
                            .build());
                    chargePartnerClient.receiveAsn(asnPushReq);
                    break;
                }

                case JADT25:
                case VP25:
                case QE25: {
                    OrderNoReq orderNoReq = new OrderNoReq();
                    orderNoReq.setOrderNo(orderPo.getOrderNo());
                    orderNoReq.setBizType(orderPo.getBizType());
                    spsClient.cancelOutboundApplyOrder(orderNoReq);
                    break;
                }
            }
            orderPo.setUpdateTime(LocalDateTime.now());
            return updateById(orderPo);
        } catch (Exception e) {
            log.error("WarehouseDistributeOrderServiceImpl#cancel error", e);
            throw new BizException(e.getMessage());
        } finally {
            if (rLock.isHeldByCurrentThread()) {
                rLock.unlock();
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean cancel(IdReq req) {
        WarehouseDistributeOrderPo orderPo = getById(req.getId());
        if (Objects.isNull(orderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_EXIST);
        }
        if (!orderPo.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.DELIVERED.getCode())) {
            throw new BizException("当前状态不可以取消");
        }
        WarehouseDistributeOrderCancelReq cancelReq = new WarehouseDistributeOrderCancelReq();
        cancelReq.setOrderNo(orderPo.getOrderNo());
        cancelReq.setBizType(orderPo.getBizType());
        return cancel(cancelReq, false);
    }

    private void cancelToDhl(WarehouseDistributeOrderPo orderPo, WarehouseDistributeLogisticPo distributeLogisticPo, List<WarehouseDistributeItemPo> distributeItemPos) {
        AsnAddSyncReq inBoundReq = inboundReqConvertor.toInBoundReq(WarehouseDistributeOrderAllPo
                .builder()
                .warehouseDistributeOrderPo(orderPo)
                .warehouseDistributeLogisticPo(distributeLogisticPo)
                .warehouseDistributeAttachPo(new WarehouseDistributeAttachPo())
                .itemAttaches(Lists.newArrayList())
                .ItemPackages(Lists.newArrayList())
                .items(distributeItemPos).build());
        ResultResp<Object> resp = wmsClient.pushAsn(inBoundReq);
        if (!resp.isSuccess()) {
            throw new BizException(resp.getMsg());
        }
    }

    /**
     * 取消占用库存
     */
    private void cancelStock(List<WarehouseDistributeItemPo> warehouseDistributeItemPos,
                             WarehouseDistributeLogisticPo warehouseDistributeLogisticPo, WarehouseDistributeOrderPo po) {
        ArrayList<InAndOutStockRequest> requests = new ArrayList<>();

        Map<String, List<WarehouseDistributeItemPo>> map = warehouseDistributeItemPos.stream()
                .collect(Collectors.groupingBy(WarehouseDistributeItemPo::getBizType));
        for (Map.Entry<String, List<WarehouseDistributeItemPo>> entry : map.entrySet()) {
            InAndOutStockRequest request = new InAndOutStockRequest();
            request.setBusinessBillNo(po.getBusinessBillNo());
            request.setIdempotentNo(warehouseDistributeLogisticPo.getWarehouseDistributeOrderNo() + entry.getKey());
            request.setBusinessType(po.getOrderType());
            request.setOperateTime(LocalDateTime.now());
            request.setOperationType(OperationType.UN_OCCUPY);
            request.setStockSource(StockSource.SYS);
            request.setBizType(entry.getKey());
            request.setTradeNo(po.getOrderNo());
            List<InAndOutStockParam> stockParams = buildStockRequestItem(entry.getValue(), warehouseDistributeLogisticPo, po);
            request.setParams(stockParams);
            request.addExtraInfo("occupyNo", StrUtil.blankToDefault(po.getBusinessBillNo(), po.getOrderNo()));
            if (CollUtil.isNotEmpty(stockParams)) {
                requests.add(request);
            }
        }
        if (CollUtil.isNotEmpty(requests)) {
            BaseResult<String> resp = spsClient.putOutStockMultiBizType(requests);
            if (!resp.isSuccess()) {
                throw new BizException(resp.getMessage());
            }
        }
    }

    /**
     * 分页查询
     *
     * @author O_chaopeng.huang
     */
    @Override
    public BaseResult<BasePageData<WarehouseDistributeOrderDto>> pageSearch(
            BasePageParam<WarehouseDistributeOrderPageSearchReq> req) {
        WarehouseDistributeOrderPageSearchReq param = req.getParam();
        String bizType = param.getBizType();
        if ((StringUtils.isNotBlank(param.getMaterialCode())) ||
                (StringUtils.isNotBlank(param.getNumberColumn())
                        && param.getNumberColumn().equals("batchNo")
                        && CollectionUtils.isNotEmpty(param.getNumberNOs()))) {
            //查询零件 或者 批次号
            param.setSearchItemFlag(true);
        }
        IPage<WarehouseDistributeOrderPo> iPage = new Page<>(req.getPage(), req.getSize());
        iPage = baseMapper.selectPageSearch(iPage, param);
        BasePageData<WarehouseDistributeOrderDto> pageDate = new BasePageData<>(iPage);
        List<WarehouseDistributeOrderDto> collect = getWarehouseDistributeOrderDtoList(iPage.getRecords(), bizType);
        pageDate.setRecords(collect);
        return BaseResult.OK(pageDate);
    }

    /**
     * 设置反馈值
     */
    @Override
    public List<WarehouseDistributeOrderDto> getWarehouseDistributeOrderDtoList(
            List<WarehouseDistributeOrderPo> records, String bizType) {
        if (CollectionUtils.isEmpty(records)) {
            return new ArrayList<>();
        }
        List<String> list = new ArrayList<>();
        list.add(DictEnum.BIZTYPE.getDictCode());
        list.add(DictEnum.DistributeStatus.getDictCode());
        list.add(DictEnum.DistributeType.getDictCode());
        list.add(DictEnum.LogisticType.getDictCode());
        list.add(DictEnum.ORDER_PROCESS_NAME.getDictCode());
        list.add(DictEnum.ApplySake.getDictCode());
        Map<String, Map<String, String>> map = getStringMapMap(bizType, list);
        Map<String, String> bizMap = map.getOrDefault(DictEnum.BIZTYPE.getDictCode(), new HashMap<>());
        Map<String, String> orderStatusMap = map.getOrDefault(DictEnum.DistributeStatus.getDictCode(), new HashMap<>());
        Map<String, String> orderTypeMap = map.getOrDefault(DictEnum.DistributeType.getDictCode(), new HashMap<>());
        Map<String, String> logisticTypeMap = map.getOrDefault(DictEnum.LogisticType.getDictCode(), new HashMap<>());
        Map<String, String> processMap = map.getOrDefault(DictEnum.ORDER_PROCESS_NAME.getDictCode(), new HashMap<>());

        Map<String, String> applyPurposeMap = map.getOrDefault(DictEnum.ApplySake.getDictCode(), new HashMap<>());
        List<String> orderList = records.stream().map(WarehouseDistributeOrderPo::getOrderNo).collect(
                Collectors.toList());
        List<WarehouseDistributeItemPackagePo> itemPackagePos = warehouseDistributeItemPackageService.list(
                Wrappers.lambdaQuery(WarehouseDistributeItemPackagePo.class)
                        .in(WarehouseDistributeItemPackagePo::getWarehouseDistributeOrderNo,
                                orderList));
        Map<String, WarehouseDistributeAttachPo> attachPoMap = warehouseDistributeAttachService.list(
                Wrappers.lambdaQuery(WarehouseDistributeAttachPo.class)
                        .in(WarehouseDistributeAttachPo::getWarehouseDistributeOrderNo,
                                orderList)).stream().collect(Collectors.toMap(WarehouseDistributeAttachPo::getWarehouseDistributeOrderNo, Function.identity()));
        List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.list(
                Wrappers.lambdaQuery(WarehouseDistributeItemPo.class)
                        .in(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo,
                                orderList));
        List<WarehouseDistributeLogisticDto> logisticDtos = warehouseDistributeLogisticService.selectWarehouseDistributeLogisticList(
                bizType, orderList);

        List<WarehouseDistributeOrderPo> child = list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery().in(WarehouseDistributeOrderPo::getAssociateBillNo, orderList));

        Map<String, List<WarehouseDistributeOrderPo>> childMap = child.stream().collect(Collectors.groupingBy(WarehouseDistributeOrderPo::getAssociateBillNo));
        return records.stream().map((e) -> {
            WarehouseDistributeOrderDto warehouseDistributeOrderDto = getWarehouseDistributeOrderDto(bizMap,
                    orderStatusMap, orderTypeMap, logisticTypeMap, processMap, e);
            warehouseDistributeOrderDto.setHashChild(childMap.containsKey(e.getOrderNo()));
            getQtyValue(warehouseDistributeOrderDto, itemPos.stream().filter(Objects::nonNull)
                    .filter(item -> item.getWarehouseDistributeOrderNo()
                            .equals(warehouseDistributeOrderDto.getOrderNo()))
                    .collect(
                            Collectors.toList()), itemPackagePos.stream().filter(Objects::nonNull)
                    .filter(item -> item.getWarehouseDistributeOrderNo()
                            .equals(warehouseDistributeOrderDto.getOrderNo()))
                    .collect(
                            Collectors.toList()));
            getLogisticValue(warehouseDistributeOrderDto, logisticDtos.stream().filter(Objects::nonNull)
                    .filter(item -> item.getWarehouseDistributeOrderNo()
                            .equals(warehouseDistributeOrderDto.getOrderNo()))
                    .collect(
                            Collectors.toList()));
            WarehouseDistributeAttachPo attachPo = attachPoMap.get(e.getOrderNo());
            if (attachPo != null) {
                warehouseDistributeOrderDto.setProcessCode(attachPo.getProcessCode());
                warehouseDistributeOrderDto.setApplyPurpose(applyPurposeMap.get(attachPo.getApplyPurpose()));
            }
            return warehouseDistributeOrderDto;
        }).collect(Collectors.toList());
    }

    @Override
    public Map<String, Map<String, String>> getStringMapMap(String bizType, List<String> list) {
        BaseDataReq req = new BaseDataReq();
        req.setBizType(bizType);
        req.setDictCodes(list);
        req.setDictSearchAll(true);
        BaseResult<BaseDataResp> resp = spsClient.searchBaseData(req);
        if (!resp.isSuccess()) {
            throw new BizException(resp.getMessage());
        }
        List<DictItemClientDto> dictItemClientDtos = resp.getData().getDictItemClientDtos();
        Map<String, Map<String, String>> map = new HashMap<>();
        if (CollUtil.isNotEmpty(dictItemClientDtos)) {
            for (DictItemClientDto clientDto : dictItemClientDtos) {
                if (map.containsKey(clientDto.getCode())) {
                    map.get(clientDto.getCode()).put(clientDto.getItemCode(), clientDto.getItemName());
                } else {
                    HashMap<String, String> value = new HashMap<>();
                    value.put(clientDto.getItemCode(), clientDto.getItemName());
                    map.put(clientDto.getCode(), value);
                }
            }
        }
        return map;
    }

    /**
     * 物流信息获取
     *
     * @author O_chaopeng.huang
     */
    private void getLogisticValue(WarehouseDistributeOrderDto dto,
                                  List<WarehouseDistributeLogisticDto> collect) {
        if (CollectionUtils.isNotEmpty(collect)) {
            dto.setDeliverWarehouseCode(collect.get(0).getDeliverWarehouseCode());
            dto.setDeliverUni(collect.get(0).getDeliverUni());
            dto.setReceiveWarehouseCode(collect.get(0).getReceiveWarehouseCode());
            dto.setReceiveUni(collect.get(0).getReceiveUni());
            dto.setShippingMethodName(collect.get(0).getShippingMethodName());
            dto.setEstPickTime(collect.get(0).getEstPickTime());
            dto.setEstArrivalTime(collect.get(0).getEstArrivalTime());
        }
    }

    /**
     * 设置仓配信息值
     */
    private WarehouseDistributeOrderDto getWarehouseDistributeOrderDto(Map<String, String> bizMap,
                                                                       Map<String, String> orderStatusMap,
                                                                       Map<String, String> orderTypeMap,
                                                                       Map<String, String> logisticTypeMap,
                                                                       Map<String, String> processMap,
                                                                       WarehouseDistributeOrderPo e
    ) {
        WarehouseDistributeOrderDto warehouseDistributeOrderDto = BeanCopierUtil.copy(e,
                WarehouseDistributeOrderDto.class);
        if (Objects.isNull(warehouseDistributeOrderDto)) {
            return new WarehouseDistributeOrderDto();
        }

        //内领订单剩余可拆单数量不为0并且状态不等于已完成
        if (WarehouseDistributeOrderTypeEnum.isApplyOrder(e.getOrderType()) && !e.getIsChild() && WarehouseDistributeOrderStatusEnum.canFork(e.getOrderStatus())) {
            List<WarehouseDistributeItemPo> poList = warehouseDistributeItemService.selectList(e.getOrderNo());
            for (WarehouseDistributeItemPo itemPo : poList) {
                if (itemPo.getQty().compareTo(itemPo.getForkedQty()) != 0) {
                    warehouseDistributeOrderDto.setCanFork(true);
                    break;
                }
            }
        }
        warehouseDistributeOrderDto.setBizTypeName(bizMap.get(e.getBizType()));
        warehouseDistributeOrderDto.setOrderStatusName(orderStatusMap.get(e.getOrderStatus()));
        warehouseDistributeOrderDto.setOrderTypeName(orderTypeMap.get(e.getOrderType()));
        warehouseDistributeOrderDto.setLogisticTypeName(logisticTypeMap.get(e.getLogisticType()));
        warehouseDistributeOrderDto.setInProcessCodeName(processMap.get(e.getInProcessCode()));
        warehouseDistributeOrderDto.setOutProcessCodeName(processMap.get(e.getOutProcessCode()));
        return commonService.changeNull(warehouseDistributeOrderDto);
    }

    @Override
    public BaseResult<WarehouseDistributeAllDto> selectById(IdIpage req) {
        WarehouseDistributeOrderPo orderPo = checkAndGetPo(req);
        String bizType = orderPo.getBizType();
        String orderNo = orderPo.getOrderNo();
        List<WarehouseDistributeItemPo> itemPos = getWarehouseDistributeItemPos(orderNo);
        List<WarehouseDistributeItemPackagePo> itemPackagePos = warehouseDistributeItemPackageService.list(
                Wrappers.lambdaQuery(WarehouseDistributeItemPackagePo.class)
                        .eq(WarehouseDistributeItemPackagePo::getWarehouseDistributeOrderNo, orderNo));
        WarehouseDistributeLogisticDto logisticDto = warehouseDistributeLogisticService.selectOne(bizType, orderNo);
        WarehouseDistributeAllDto allDto = getWarehouseDistributeAllDto(orderPo, bizType, orderNo,
                logisticDto);
        //数量计算
        getQtyValue(allDto.getWarehouseDistributeOrderDto(), itemPos, itemPackagePos);
        return BaseResult.OK(allDto);
    }


    private WarehouseDistributeOrderPo checkAndGetPo(IdIpage req) {
        WarehouseDistributeOrderPo orderPo = baseMapper.selectById(req.getId());
        if (Objects.isNull(orderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        return orderPo;
    }

    private List<WarehouseDistributeItemPo> getWarehouseDistributeItemPos(String orderNo) {
        return warehouseDistributeItemService.list(
                Wrappers.lambdaQuery(WarehouseDistributeItemPo.class)
                        .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, orderNo));
    }

    /**
     * 数量计算
     *
     * @author O_chaopeng.huang
     */
    private void getQtyValue(WarehouseDistributeOrderDto dto, List<WarehouseDistributeItemPo> itemPos,
                             List<WarehouseDistributeItemPackagePo> itemPackagePos) {
        //零件总数
        dto.setTotalQty(itemPos.stream().map(WarehouseDistributeItemPo::getQty)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
        //零件总入库数
        dto.setTotalRealInQty(itemPos.stream().map(WarehouseDistributeItemPo::getRealInQty)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
        //零件总出库数
        dto.setTotalRealOutQty(itemPos.stream().map(WarehouseDistributeItemPo::getRealOutQty)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
        //零件总体积数
        dto.setTotalVolume(itemPos.stream().map(WarehouseDistributeItemPo::getVolume)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
        //零件总重量数
        dto.setTotalWeight(itemPos.stream().map(WarehouseDistributeItemPo::getWeight)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
        //总包装数
        dto.setTotalPackingQty(new BigDecimal(itemPackagePos.size()));
        //零件包装总体积数
        dto.setTotalPackingVolume(itemPackagePos.stream().map(WarehouseDistributeItemPackagePo::getPackingVolume)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
        //零件包装总重量数
        dto.setTotalPackingWeight(itemPackagePos.stream().map(WarehouseDistributeItemPackagePo::getPackingWeight)
                .reduce(BigDecimal.ZERO, BigDecimal::add));
    }

    @Override
    public List<WarehouseDistributeOrderExportDto> getExportDtoList(BasePageParam<WarehouseDistributeOrderPageSearchReq> pageParam) {
        List<WarehouseDistributeOrderDto> cur;
        List<WarehouseDistributeOrderDto> all = new ArrayList<>();
        pageParam.setSize(2000);
        pageParam.getParam().setGetChild(true);
        //限制导出最大一万条
        int count = PAGE_START_AT;
        while (all.size() < TEN_THOUSAND && !(cur = pageSearch(pageParam).getData().getRecords()).isEmpty()) {
            pageParam.setPage(++count);
            all.addAll(cur);
        }
        return all.stream().map(item -> {
            WarehouseDistributeOrderExportDto exportDto = BeanCopierUtil.copy(item,
                    WarehouseDistributeOrderExportDto.class);
            exportDto.setOrderTime(DateUtils.getLocalDateTimeStr(item.getOrderTime(), DateUtils.STANDARD_TIME_FORMAT));
            exportDto.setCreateTime(
                    DateUtils.getLocalDateTimeStr(item.getCreateTime(), DateUtils.STANDARD_TIME_FORMAT));
            exportDto.setUpdateTime(
                    DateUtils.getLocalDateTimeStr(item.getUpdateTime(), DateUtils.STANDARD_TIME_FORMAT));
            return exportDto;
        }).collect(Collectors.toList());
    }

    /**
     * 仓配订单预收货结果同步状态变更
     *
     * @author O_chaopeng.huang
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public BaseResult<WarehouseDistributeOrderPo> updateStatus(ExternalBeforehandReceiveReq receive) {
        WarehouseDistributeOrderPo one = getByBusinessBillOrderNo(receive.getBizType(), receive.getTradeNo());
        if (Objects.isNull(one)) {
            throw new BizException("仓配订单不存在");
        }

        switch (receive.getStatus()) {
            case 1:
                if (!WarehouseDistributeOrderStatusEnum.SHIPPED.getCode().equals(one.getOrderStatus()) &&
                        !WarehouseDistributeOrderStatusEnum.DELIVERED.getCode().equals(one.getOrderStatus())) {
                    throw new BizException("只能对已发货或者已下发仓配订单进行预收货操作");
                }
                update(Wrappers.lambdaUpdate(WarehouseDistributeOrderPo.class)
                        .eq(WarehouseDistributeOrderPo::getId, one.getId())
                        .set(WarehouseDistributeOrderPo::getActualArrivalTime, receive.getOperateTime())
                        .set(WarehouseDistributeOrderPo::getOrderStatus,
                                WarehouseDistributeOrderStatusEnum.ARRIVAL.getCode())
                        .set(WarehouseDistributeOrderPo::getUpdateUser, receive.getOperateBy()));
                return BaseResult.OK(one);
            case 0:
                if (!WarehouseDistributeOrderStatusEnum.ARRIVAL.getCode().equals(one.getOrderStatus())) {
                    throw new BizException("只能对已到货仓配订单进行预收货操作");
                }
                update(Wrappers.lambdaUpdate(WarehouseDistributeOrderPo.class)
                        .eq(WarehouseDistributeOrderPo::getId, one.getId())
                        .set(WarehouseDistributeOrderPo::getOrderStatus,
                                WarehouseDistributeOrderStatusEnum.SHIPPED.getCode())
                        .set(WarehouseDistributeOrderPo::getActualArrivalTime, "")
                        .set(WarehouseDistributeOrderPo::getUpdateUser, receive.getOperateBy()));
                return BaseResult.OK(one);
            default:
                return BaseResult.OK(-1, "所传状态值不正确");
        }
    }

    @Override
    public void repeal(OrderNoReq orderNoReq) {
        update(Wrappers.<WarehouseDistributeOrderPo>lambdaUpdate()
                .set(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.CANCELED.getCode())
                .eq(WarehouseDistributeOrderPo::getOrderNo, orderNoReq.getOrderNo()));
    }


    /**
     * 更新实出数量
     *
     * @param orderNo         单号
     * @param outQuantityList 赋值字段：  bizType materialLineNo materialCode qty
     * @return boolean
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateDeliverQty(String orderNo, String expressNo, Map<String, WarehouseDistributeItemPo> outQuantityList) {
        // 根据维度校验该仓配订单下是否存在对应明细
        List<WarehouseDistributeItemPo> newItemPos = checkAndSetItemRealOutQty(orderNo, outQuantityList);
        try {
            // 如果dhl所给实际出库数量等于应出数量
            warehouseDistributeItemService.updateBatchById(newItemPos);
            // 更新订单状态
            WarehouseDistributeOrderPo wdPo = warehouseDistributeOrderService.getOne(Wrappers.lambdaQuery(WarehouseDistributeOrderPo.class)
                    .eq(WarehouseDistributeOrderPo::getOrderNo, orderNo)
            );
            //根据是否存在物流单号更新状态 因为存在dhl 调用传入出库结果 超时,
            //存在物流单号 更新为已发货 不存在更新为已出库
            String wdStatus = StrUtil.isBlank(wdPo.getLogisticNo()) ? WarehouseDistributeOrderStatusEnum.OUT_STOCK_COMPLETED.getCode() :
                    WarehouseDistributeOrderStatusEnum.SHIPPED.getCode();
            //可能存在订单已经签收了，但还没反写收货数量
            if (wdPo.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode())) {
                wdStatus = WarehouseDistributeOrderStatusEnum.COMPLETED.getCode();
            }
            //报废出库状态更改为已完成
            if (!WarehouseDistributeOrderTypeEnum.SM20.getValue().equals(wdPo.getOrderType()) && !WarehouseDistributeOrderTypeEnum.ES31.getValue().equals(wdPo.getOrderType())) {
                wdStatus = WarehouseDistributeOrderStatusEnum.COMPLETED.getCode();
            }

            BigDecimal sumQty = newItemPos.stream().map(WarehouseDistributeItemPo::getQty).reduce(BigDecimal.ZERO, BigDecimal::add);
            BigDecimal sumRealQty = newItemPos.stream().map(WarehouseDistributeItemPo::getRealOutQty).reduce(BigDecimal.ZERO, BigDecimal::add);

            //实际出库数量小于需求数量状态为部分完成
            if (WarehouseDistributeOrderTypeEnum.isApplyOrder(wdPo.getOrderType()) && sumRealQty.compareTo(sumQty) < 0) {
                wdStatus = WarehouseDistributeOrderStatusEnum.PART_COMPLETED.getCode();
            }
            warehouseDistributeOrderService.update(null,
                    Wrappers.lambdaUpdate(WarehouseDistributeOrderPo.class)
                            .set(WarehouseDistributeOrderPo::getOrderStatus, wdStatus)
                            .set(StrUtil.isNotEmpty(expressNo), WarehouseDistributeOrderPo::getLogisticNo, expressNo)
                            .eq(WarehouseDistributeOrderPo::getOrderNo, orderNo));
            if (StrUtil.isNotEmpty(expressNo)) {
                wdPo.setLogisticNo(expressNo);
            }
            //能源调拨出库同时给能源下发入库指令
            if (wdPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.ES31.getValue())) {
                WarehouseDistributeOrderAllPo allPo = buildAllPo(wdPo);
                transferInToESHandler.process(allPo);
            }
            if (WarehouseDistributeOrderTypeEnum.isApplyOrder(wdPo.getOrderType())) {
                //子单出库完成要反写母单已拆单数量和实际出库数量
                if (wdPo.getIsChild()) {
                    updateParentOrder(newItemPos, wdPo.getAssociateBillNo(), wdPo.getBizType());
                }
            }

        } catch (Exception e) {
            log.info("更新仓配订单明细实际出库数量出错", e);
            throw new BizException(SpsResponseCodeEnum.WAREHOUSE_DISTRIBUTE_ORDER_ERROR.getDesc(), e);
        }
    }

    /*
     * 反写母单*/
    private void updateParentOrder(List<WarehouseDistributeItemPo> childItemPos, String parentOrderNo, String bizType) {

        WarehouseDistributeOrderPo parentPo = getByOrderNo(bizType, parentOrderNo);
        List<WarehouseDistributeItemPo> pos = warehouseDistributeItemService.selectList(parentOrderNo);

        Map<String, WarehouseDistributeItemPo> itemPoMap = childItemPos.stream().collect(Collectors.toMap(WarehouseDistributeItemPo::getMaterialLineNo, Function.identity()));
        boolean allPutOut = true;

        boolean isZero = true;
        for (WarehouseDistributeItemPo po : pos) {
            WarehouseDistributeItemPo childPo = itemPoMap.get(po.getMaterialLineNo());
            if (childPo != null) {
                po.setRealOutQty(po.getRealOutQty().add(childPo.getRealOutQty()));
                //子单部分出库需要反写母单可拆单数量
                po.setForkedQty(po.getForkedQty().subtract(childPo.getQty().subtract(childPo.getRealOutQty())));
            }
            if (po.getQty().compareTo(po.getRealOutQty()) != 0) {
                allPutOut = false;
            }

            if (po.getForkedQty().compareTo(BigDecimal.ZERO) != 0) {
                isZero = false;
            }

        }

        if (allPutOut) {
            parentPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
            parentPo.setUpdateTime(LocalDateTime.now());
            updateById(parentPo);
        }
        //未拆单，状态还原
        if (isZero) {
            parentPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.CREATED.getCode());
            parentPo.setUpdateTime(LocalDateTime.now());
            updateById(parentPo);
        }
        warehouseDistributeItemService.updateBatchById(pos);
    }

    /**
     * 校验参数
     *
     * @author O_chaopeng.huang
     */
    private static void checkParameter(String applyOrderNo, Map<String, WarehouseDistributeItemPo> outQuantityList) {
        // 校验参数
        if (StringUtils.isBlank(applyOrderNo)) {
            log.info("仓配订单号不能为空");
            throw new BizException("仓配订单号不能为空");
        }
        if (CollectionUtils.isEmpty(outQuantityList)) {
            log.info("仓配订单出库明细不能为空");
            throw new BizException("仓配订单出库明细不能为空");
        }
    }

    /**
     * 根据维度校验该仓配订单下是否存在对应明细
     *
     * @author O_chaopeng.huang
     */
    private List<WarehouseDistributeItemPo> checkAndSetItemRealOutQty(String orderNo,
                                                                      Map<String, WarehouseDistributeItemPo> qtyMap) {
        List<WarehouseDistributeItemPo> itemPos =
                warehouseDistributeItemService.list(Wrappers.lambdaQuery(WarehouseDistributeItemPo.class)
                        .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, orderNo));
        WarehouseDistributeOrderPo orderPo = getOne(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery().eq(WarehouseDistributeOrderPo::getOrderNo, orderNo));
        log.info("checkAndSetItemRealOutQty#qtyMap:{}", JSONUtil.toJsonStr(qtyMap));

        if (qtyMap.size() != itemPos.size() && WarehouseDistributeOrderTypeEnum.isAllPutOut(orderPo.getOrderType())) {
            throw new BizException(SpsResponseCodeEnum.WAREHOUSE_DISTRIBUTE_ORDER_NOT_ALLOWED_ERROR.getDesc());
        }
        // 根据唯一性维度修改实际出库数量
        for (WarehouseDistributeItemPo itemPo : itemPos) {
            WarehouseDistributeItemPo po = qtyMap.get(itemPo.getMaterialLineNo());
            if (Objects.isNull(po)) {
                itemPo.setForkedQty(BigDecimal.ZERO);
                continue;
            }
            // dhl所给实际出库数量只能等于仓配订单应出数量否则不做处理
            if (WarehouseDistributeOrderTypeEnum.isAllPutOut(orderPo.getOrderType()) && po.getRealOutQty().compareTo(itemPo.getQty()) != 0) {
                log.info("仓配订单不允许部分出库 orderNo :{} materialCode :{}", po.getWarehouseDistributeOrderNo(), po.getMaterialCode());
                throw new BizException(SpsResponseCodeEnum.WAREHOUSE_DISTRIBUTE_ORDER_NOT_ALLOWED_ERROR.getDesc());
            }
            if (po.getRealOutQty().compareTo(itemPo.getQty()) > 0) {
                throw new BizException("实出数量不能大于需求数量");
            }
            itemPo.setRealOutQty(po.getRealOutQty());
            //内领母单部分出库反写已拆数量
            if (WarehouseDistributeOrderTypeEnum.isApplyOrder(orderPo.getOrderType()) && !orderPo.getIsChild()) {
                itemPo.setForkedQty(po.getRealOutQty());
            }

        }
        if (CollUtil.isEmpty(itemPos)) {
            throw new BizException("未匹配到要更新的仓配订单明细");
        }
        return itemPos;
    }

    /**
     * 仓配订单入库数量反写，按物料号+批次 正序反写
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateRealInQty(InAndOutStockRequest request) {

        WarehouseDistributeOrderPo distributeOrderPo = getByBusinessBillOrderNo(request.getBizType(), request.getTradeNo());
        Map<String, InAndOutStockParam> sumMap = request.getParams().stream().collect(Collectors.toMap(e -> e.getMaterialCode() + e.getBatchNo(), Function.identity(), (o, n) -> {
            o.setSumQuantity(o.getSumQuantity().add(n.getSumQuantity()));
            return o;
        }));
        checkOrderStatus(distributeOrderPo);
        List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.list(Wrappers
                .<WarehouseDistributeItemPo>lambdaQuery()
                .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, distributeOrderPo.getOrderNo()));
        Map<String, List<WarehouseDistributeItemPo>> groupMap = itemPos.stream().collect(Collectors.groupingBy(e -> e.getMaterialCode() + e.getBatchNo()));

        List<WarehouseDistributeItemPo> updateList = new ArrayList<>();

        for (Map.Entry<String, InAndOutStockParam> en : sumMap.entrySet()) {
            InAndOutStockParam value = en.getValue();
            BigDecimal restQty = value.getSumQuantity();
            String key = en.getKey();
            List<WarehouseDistributeItemPo> distributeItemPos = groupMap.get(key);
            if (CollUtil.isEmpty(distributeItemPos)) {
                throw new BizException("批次号不存在");
            }
            for (int i = 0; i < distributeItemPos.size() && restQty.intValue() > 0; i++) {
                WarehouseDistributeItemPo cur = distributeItemPos.get(i);
                BigDecimal diff = cur.getQty().subtract(cur.getRealInQty());
                cur.setRealInQty(cur.getRealInQty().add(min(restQty, diff)));
                restQty = restQty.subtract(diff);
                updateList.add(cur);
            }
            if (restQty.compareTo(BigDecimal.ZERO) > 0) {
                throw new BizException(key + "入库数量大于需求数量");
            }

        }
        try {
            //更新入库数量
            warehouseDistributeItemService.updateBatchById(updateList);
            // 更新订单状态
            distributeOrderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
            distributeOrderPo.setUpdateTime(LocalDateTime.now());
            updateById(distributeOrderPo);
        } catch (Exception e) {
            log.info("更新仓配订单明细实际入库数量出错", e);
            throw new BizException(SpsResponseCodeEnum.WAREHOUSE_DISTRIBUTE_ORDER_IN_ERROR);
        }
    }


    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateRealInQty(StockPutInResultMessage resultMessage) {
        if (Objects.equals(resultMessage.getBusinessType(), WarehouseDistributeOrderTypeEnum.SM11.getValue()) ||
                Objects.equals(resultMessage.getBusinessType(), WarehouseDistributeOrderTypeEnum.SM12.getValue())
        ) {
            resultMessage.setBizType(BizTypeEnum.SM.getBizType());
        }
        WarehouseDistributeOrderPo orderPo = getByBusinessBillOrderNo(resultMessage.getBizType(), resultMessage.getTradeNo());
        if (Objects.isNull(orderPo)) {
            orderPo = getByOrderNo(resultMessage.getBizType(), resultMessage.getTradeNo());
        }

        List<WarehouseDistributeItemPo> list = warehouseDistributeItemService.list(Wrappers.<WarehouseDistributeItemPo>lambdaQuery().eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, orderPo.getOrderNo()));

        Map<String, InAndOutStockParam> map = resultMessage.getStockParams().stream().collect(Collectors.toMap(InAndOutStockParam::getColumnNo, Function.identity(), (e, v) -> {
            e.setSumQuantity(v.getSumQuantity().add(e.getSumQuantity()));
            return e;
        }));
        log.info("updateRealInQty--list==:{},map==:{}", list, map);
        ArrayList<WarehouseDistributeItemPo> itemPos = new ArrayList<>();

        for (WarehouseDistributeItemPo distributeItemPo : list) {
            if (map.containsKey(distributeItemPo.getMaterialLineNo())) {
                distributeItemPo.setRealInQty(map.get(distributeItemPo.getMaterialLineNo()).getSumQuantity());
                itemPos.add(distributeItemPo);
            }
        }
        warehouseDistributeItemService.updateBatchById(itemPos);
        orderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
        orderPo.setUpdateTime(LocalDateTime.now());
        updateById(orderPo);
    }

    /**
     * 校验出库数量
     */
    @Override
    public List<WarehouseDistributeItemPo> checkDeliverQty(InAndOutStockRequest request) {
        Map<String, WarehouseDistributeItemPo> outQuantityList = convertOrderRequest(request.getParams());
        // 校验参数
        checkParameter(request.getTradeNo(), outQuantityList);
        //校验仓配订单状态
        checkOrderByOrderNo(request.getTradeNo());
        //仓配订单 对应 出入库 参数中的 明细数据校验
        return checkInAndOutToItemParam(request.getTradeNo(), outQuantityList);
    }

    private Map<String, WarehouseDistributeItemPo> convertOrderRequest(List<InAndOutStockParam> params) {
        Map<String, WarehouseDistributeItemPo> map = new HashMap<>();
        for (InAndOutStockParam param : params) {
            WarehouseDistributeItemPo dto = map.get(param.getColumnNo());
            if (dto == null) {
                dto = new WarehouseDistributeItemPo();
                dto.setBizType(param.getBizType());
                dto.setMaterialCode(param.getMaterialCode());
                dto.setRealOutQty(param.getSumQuantity());
                dto.setMaterialLineNo(param.getColumnNo());
                map.put(param.getColumnNo(), dto);
            } else {
                dto.setRealOutQty(dto.getRealOutQty().add(param.getSumQuantity()));
            }
        }
        return map;
    }

    /**
     * 仓配订单 对应 出入库 参数中的 明细数据校验
     *
     * @param applyOrderNo
     * @param outQuantityList
     * @return
     */
    private List<WarehouseDistributeItemPo> checkInAndOutToItemParam(String applyOrderNo, Map<String, WarehouseDistributeItemPo> outQuantityList) {
        // 根据维度校验该仓配订单下是否存在对应明细
        return checkAndSetItemRealOutQty(applyOrderNo, outQuantityList);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateRealInQty(ReceiveReq req) {
        if (Objects.isNull(req)) {
            throw new BizException("参数为空 ");
        }
        WarehouseDistributeOrderPo one = warehouseDistributeOrderService.getByBusinessBillOrderNo(req.getBizType(), req.getOutOrderNo());
        if (Objects.isNull(one)) {
            throw new BizException(
                    "WarehouseDistributeOrderServiceImpl#updateRealInQty 未找到对应待收货列表信息 (" + req.getOutOrderNo() + ")");
        }
        update(Wrappers.lambdaUpdate(WarehouseDistributeOrderPo.class)
                .eq(WarehouseDistributeOrderPo::getId, one.getId())
                .set(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.COMPLETED.getCode()));
        for (PendingReceiveListDetailPo pendingReceiveListDetailPo : req.getDetails()) {
            warehouseDistributeItemService.update(Wrappers.lambdaUpdate(WarehouseDistributeItemPo.class)
                    .eq(WarehouseDistributeItemPo::getBizType, pendingReceiveListDetailPo.getBizType())
                    .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, one.getOrderNo())
                    .eq(WarehouseDistributeItemPo::getMaterialLineNo, pendingReceiveListDetailPo.getLineNo())
                    .eq(WarehouseDistributeItemPo::getMaterialCode, pendingReceiveListDetailPo.getMaterialCode())
                    .set(WarehouseDistributeItemPo::getRealInQty, pendingReceiveListDetailPo.getActualQty()));
        }
    }

    @Override
    public BaseResult<WarehouseDistributeAllDto> selectNoHide(IdIpage req) {
        WarehouseDistributeOrderPo orderPo = checkAndGetPo(req);
        String bizType = orderPo.getBizType();
        String orderNo = orderPo.getOrderNo();
        WarehouseDistributeLogisticDto logisticDto = warehouseDistributeLogisticService.selectWarehouseDistributeLogistic(
                bizType, orderNo);
        List<WarehouseDistributeItemPo> itemPos = getWarehouseDistributeItemPos(
                orderNo);
        List<WarehouseDistributeItemPackagePo> itemPackagePos = warehouseDistributeItemPackageService.list(
                Wrappers.lambdaQuery(WarehouseDistributeItemPackagePo.class)
                        .eq(WarehouseDistributeItemPackagePo::getWarehouseDistributeOrderNo, orderNo));
        WarehouseDistributeAllDto allDto = getWarehouseDistributeAllDto(orderPo, bizType, orderNo, logisticDto);
        getQtyValue(allDto.getWarehouseDistributeOrderDto(), itemPos, itemPackagePos);
        return BaseResult.OK(allDto);
    }

    private WarehouseDistributeAllDto getWarehouseDistributeAllDto(WarehouseDistributeOrderPo orderPo, String bizType,
                                                                   String orderNo, WarehouseDistributeLogisticDto logisticDto) {
        WarehouseDistributeAttachDto attachDto = warehouseDistributeAttachService.selectWarehouseDistributeAttach(
                bizType, orderNo);
        List<String> list = new ArrayList<>();
        list.add(DictEnum.DistributeStatus.getDictCode());
        list.add(DictEnum.DistributeType.getDictCode());
        list.add(DictEnum.LogisticType.getDictCode());
        list.add(DictEnum.BIZTYPE.getDictCode());
        list.add(DictEnum.CLAIM_SUPPLIER.getDictCode());
        list.add(DictEnum.ORDER_PROCESS_NAME.getDictCode());
        list.add(DictEnum.ApplyPurpose.getDictCode());
        list.add(DictEnum.ApplySake.getDictCode());


        Map<String, Map<String, String>> map = getStringMapMap(bizType, list);
        Map<String, String> orderTypeMap = map.getOrDefault(DictEnum.DistributeType.getDictCode(), new HashMap<>());
        Map<String, String> orderStatusMap = map.getOrDefault(DictEnum.DistributeStatus.getDictCode(), new HashMap<>());
        Map<String, String> logisticTypeMap = map.getOrDefault(DictEnum.LogisticType.getDictCode(), new HashMap<>());
        Map<String, String> bizMap = map.getOrDefault(DictEnum.BIZTYPE.getDictCode(), new HashMap<>());
        Map<String, String> claimSupplier = map.getOrDefault(DictEnum.CLAIM_SUPPLIER.getDictCode(), new HashMap<>());
        Map<String, String> processName = map.getOrDefault(DictEnum.ORDER_PROCESS_NAME.getDictCode(), new HashMap<>());
        Map<String, String> applyAim = map.getOrDefault(DictEnum.ApplyPurpose.getDictCode(), new HashMap<>());
        Map<String, String> applyPurpose = map.getOrDefault(DictEnum.ApplySake.getDictCode(), new HashMap<>());
        WarehouseDistributeOrderDto orderDto = getWarehouseDistributeOrderDto(bizMap, orderStatusMap, orderTypeMap,
                logisticTypeMap, processName, orderPo);
        logisticDto.setLogisticNo(orderDto.getLogisticNo());
        //填充财务字段
        if (attachDto != null) {
            attachDto.setApplyAim(applyAim.get(attachDto.getApplyAim()));
            attachDto.setApplyPurpose(applyPurpose.get(attachDto.getApplyPurpose()));
            Map<String, String> mapCompanyPo = baseDataQuery.mapCompanyPo(attachDto.getBizType(), CollUtil.toList(attachDto.getApplyCompany(), attachDto.getBeAppliedCompany()));
            attachDto.setApplyCompany(mapCompanyPo.get(attachDto.getApplyCompany()));
            attachDto.setBeAppliedCompany(mapCompanyPo.get(attachDto.getBeAppliedCompany()));
        }
        orderDto.setResponsibleParty(claimSupplier.get(orderDto.getResponsibleParty()));
        return WarehouseDistributeAllDto.builder()
                .warehouseDistributeOrderDto(orderDto)
                .warehouseDistributeLogisticDto(logisticDto)
                .warehouseDistributeAttachDto(attachDto)
                .build();
    }

    @Resource
    private TrackClient trackClient;

    /**
     * 物流轨迹查询
     *
     * @author O_chaopeng.huang
     */
    @Override
    public List<TrackDetailItemResp> trackDetail(OrderNoReq req) {

        WarehouseDistributeOrderPo orderPo = getByOrderNo(req.getBizType(), req.orderNo);
        TrackDetailReq trackDetailReq = TrackDetailReq.builder()
                .businessTypeCode(req.getBizType())
                .billNo(orderPo.getLogisticNo())
                .build();
        BaseResult<TrackDetailResp> result = trackClient.trackDetail(trackDetailReq);
        if (Objects.nonNull(result) && result.isSuccess()) {
            if (Objects.nonNull(result.getData())
                    && !org.springframework.util.CollectionUtils.isEmpty(result.getData().getBillList())
                    && !org.springframework.util.CollectionUtils.isEmpty(
                    result.getData().getBillList().get(0).getItemList())) {
                return result.getData().getBillList().get(0).getItemList().stream()
                        .map(item -> BeanCopierUtil.copy(item, TrackDetailItemResp.class)).sorted(
                                Comparator.comparing(TrackDetailItemResp::getActionTime, Comparator.reverseOrder()))
                        .collect(Collectors.toList());
            } else {
                return Lists.newArrayList();
            }
        } else {
            throw new BizException(result.getMessage());
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteByIds(IdBatchReq req) {
        List<WarehouseDistributeOrderPo> warehouseDistributeOrderPos = listByIds(req.getIdList());
        for (WarehouseDistributeOrderPo orderPo : warehouseDistributeOrderPos) {
            if (!orderPo.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.CREATED.getCode())) {
                throw new BizException(orderPo.getOrderNo() + ":当前状态不可以删除");
            }
            //内领子单删除反写母单
            if (orderPo.getIsChild()) {
                List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.selectList(orderPo.getOrderNo());
                updateParentOrder(itemPos, orderPo.getAssociateBillNo(), orderPo.getBizType());
            }
        }
        removeByIds(req.getIdList());
    }


    @Transactional(rollbackFor = Exception.class)
    @Override
    public Boolean confirm(IdReq req) {
        WarehouseDistributeOrderPo orderPo = getById(req.getId());
        if (Objects.isNull(orderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        if (!orderPo.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.CREATED.getCode())) {
            throw new BizException("当前状态不能确认");
        }
        String redisKey = String.format(
                BaseConstants.RedisKey.WAREHOUSE_DISTRIBUTE_ORDER_CREATE_KEY,
                orderPo.getBizType(),
                orderPo.getOrderNo());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            WarehouseDistributeOrderAllPo allPo = buildAllPo(orderPo);
            WarehouseDistributeOrderTypeEnum orderType = WarehouseDistributeOrderTypeEnum.getByType(orderPo.getOrderType());
            //枚举订单类型不存在，根据出入库类型走默认流程
            if (orderType == null) {
                if (Integer.valueOf(orderPo.getLogisticType()).equals(WarehouseDistributeOrderlogisticTypeEnum.PUT_IN.getValue())) {
                    pendingReceiveListHandler.process(allPo);
                }
                if (Integer.valueOf(orderPo.getLogisticType()).equals(WarehouseDistributeOrderlogisticTypeEnum.PUT_OUT.getValue())) {
                    outboundApplyOrderHandler.process(allPo);
                }
            } else {
                Integer jobIndex = wdOrderJobContext.getJobIndex(orderType);
                while (jobIndex > 0) {
                    Integer lowBit = lowBit(jobIndex);
                    WDOrderJobHandler wdOrderJobHandler = wdOrderJobContext.getSyncHandler(lowBit);
                    wdOrderJobHandler.process(allPo);
                    jobIndex -= lowBit;
                }
            }
        } finally {
            if (rLock.isHeldByCurrentThread()) {
                rLock.unlock();
            }
        }
        WarehouseDistributeOrderPo newPo = new WarehouseDistributeOrderPo();
        newPo.setId(orderPo.getId());
        //同步给dhl的状态默认为已创建
        newPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.DELIVERED.getCode());
        return updateById(newPo);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void edit(WarehouseDistributeOrderAddReq request) {
        //编辑之前先删除
        WarehouseDistributeOrderReq head = request.getHead();
        remove(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery().eq(WarehouseDistributeOrderPo::getOrderNo, head.getOrderNo()));
        warehouseDistributeItemService.remove(Wrappers.<WarehouseDistributeItemPo>lambdaQuery().eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo, head.getOrderNo()));
        warehouseDistributeItemPackageService.remove(Wrappers.<WarehouseDistributeItemPackagePo>lambdaQuery().eq(WarehouseDistributeItemPackagePo::getWarehouseDistributeOrderNo, head.getOrderNo()));
        warehouseDistributeItemAttachService.remove(Wrappers.<WarehouseDistributeItemAttachPo>lambdaQuery().eq(WarehouseDistributeItemAttachPo::getWarehouseDistributeOrderNo, head.getOrderNo()));
        warehouseDistributeLogisticService.remove(Wrappers.<WarehouseDistributeLogisticPo>lambdaQuery().eq(WarehouseDistributeLogisticPo::getWarehouseDistributeOrderNo, head.getOrderNo()));
        commonFileAttachmentService.update(Wrappers.<CommonFileAttachmentPo>lambdaUpdate()
                .eq(CommonFileAttachmentPo::getBizType, head.getBizType())
                .eq(CommonFileAttachmentPo::getSourceTable, TABLE_NAME)
                .eq(CommonFileAttachmentPo::getOrderNo, head.getOrderNo())
                .set(CommonFileAttachmentPo::getIsDel, true)
        );
        int index = 1;
        for (WarehouseDistributeItemReq item : request.getItems()) {
            item.setMaterialLineNo(String.valueOf(index++));
        }
        add(request, false);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public List<CommonFileAttachmentDto> upload(String bizType, MultipartFile[] files) {
        if (files == null || files.length == 0) {
            return Lists.newArrayList();
        }
        for (MultipartFile file : files) {
            if (file.getSize() > 20 * 1024 * 1024) {
                throw new BizException("文件大小不能超过20M");
            }
        }

        List<CommonFileAttachmentDto> attachmentDtos = new ArrayList<>();
        for (MultipartFile file : files) {
            try (InputStream inputStream = file.getInputStream()) {
                BosFileResult bosFileResult = bosService.putObjInputStream(inputStream, file.getOriginalFilename());
                if (bosFileResult == null) {
                    throw new BizException("请求log文件上传BOS失败！");
                }

                CommonFileAttachmentPo po = new CommonFileAttachmentPo();
                po.setFileUrl(bosFileResult.getFileUrl());
                po.setFileName(file.getOriginalFilename());
                po.setFileKey(bosFileResult.getKey());
                po.setBizType(bizType);
                po.setSourceTable(TABLE_NAME);
                commonFileAttachmentService.save(po);

                CommonFileAttachmentDto attachmentDto = new CommonFileAttachmentDto();
                attachmentDto.setId(po.getId());
                attachmentDto.setFileName(file.getOriginalFilename());
                attachmentDto.setFileKey(bosFileResult.getKey());
                attachmentDto.setFileKey(bosFileResult.getFileUrl());
                attachmentDtos.add(attachmentDto);
            } catch (Exception e) {
                log.error("updateRequestUrl", e);
            }
        }
        return attachmentDtos;
    }

    /**
     * 根据单号查询附件
     *
     * @param req
     */
    @Override
    public List<CommonFileAttachmentDto> attachmentFile(NoReq req) {
        List<CommonFileAttachmentPo> attachmentPos = commonFileAttachmentService.list(Wrappers.<CommonFileAttachmentPo>lambdaQuery()
                .eq(CommonFileAttachmentPo::getBizType, req.getBizType())
                .eq(CommonFileAttachmentPo::getOrderNo, req.getNo())
                .eq(CommonFileAttachmentPo::getSourceTable, TABLE_NAME)
                .eq(CommonFileAttachmentPo::getIsDel, false)
        );
        return BeanUtil.copyToList(attachmentPos, CommonFileAttachmentDto.class);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateRealOutForPickOrder(OutboundApplyOrderMsg msg) {
        WarehouseDistributeOrderPo orderPo = getOne(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery().eq(WarehouseDistributeOrderPo::getOrderNo, msg.getOrderNo()));
        if (Objects.isNull(orderPo)) {
            log.info("仓配订单不存在:{}", msg.getOrderNo());
            return;
        }
        if (WarehouseDistributeOrderStatusEnum.COMPLETED.getCode().equals(orderPo.getOrderStatus())) {
            log.info("仓配订单已完成:{}", msg.getOrderNo());
            return;
        }
        orderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
        List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.selectList(orderPo.getOrderNo());
        //可能存在不同库位的明细，需要按明细id合并
        Map<Long, OutboundApplyOrderMsg.Item> itemSumMap = msg.getItems().stream().collect(Collectors.toMap(OutboundApplyOrderMsg.Item::getRefItemId, Function.identity()
                , (e1, e2) -> {
                    e1.setQty(e1.getQty().add(e2.getQty()));
                    return e1;
                }));

        for (WarehouseDistributeItemPo itemPo : itemPos) {
            OutboundApplyOrderMsg.Item item = itemSumMap.get(itemPo.getId());
            if (Objects.nonNull(item)) {
                itemPo.setRealOutQty(item.getQty());
            }
        }
        warehouseDistributeItemService.updateBatchById(itemPos);
        updateById(orderPo);
    }

    @Override
    public WarehouseDistributeOrderAllDto detail(OrderNoReq orderNoReq) {
        WarehouseDistributeOrderPo orderPo = warehouseDistributeOrderService.getByOrderNo(orderNoReq.getBizType(), orderNoReq.getOrderNo());
        WarehouseDistributeOrderAllPo allPo = buildAllPo(orderPo);
        WarehouseDistributeOrderDto dto = warehouseDistributeOrderConvertor.toDto(orderPo);
        WarehouseDistributeLogisticDto logisticConvertorDto = warehouseDistributeLogisticConvertor.toDto(allPo.getWarehouseDistributeLogisticPo());
        List<WarehouseDistributeOrderItemDto> itemConvertorDto = warehouseDistributeItemConvertor.toDto(allPo.getItems());
        List<WarehouseDistributeItemPackageDto> itemPackageConvertorDto = warehouseDistributeItemPackageConvertor.toDto(allPo.getItemPackages());
        List<WarehouseDistributeItemAttachDto> attachConvertorDto = warehouseDistributeItemAttachConvertor.toDto(allPo.getItemAttaches());
        NoReq noReq = new NoReq();
        noReq.setNo(orderPo.getOrderNo());
        noReq.setBizType(orderPo.getBizType());
        List<CommonFileAttachmentDto> attachmentFiles = attachmentFile(noReq);
        logisticConvertorDto.setLogisticNo(dto.getLogisticNo());
        return WarehouseDistributeOrderAllDto
                .builder()
                .head(dto)
                .logistic(logisticConvertorDto)
                .items(itemConvertorDto)
                .itemPackages(itemPackageConvertorDto)
                .itemAttaches(attachConvertorDto)
                .attachments(attachmentFiles)
                .build();
    }

    @Override
    public boolean isSpecialWarehouse(String bizType, String warehouseCode) {
        BaseResult<List<DictItemPo>> specialWarehouse = spsClient.getSpecialWarehouse(bizType);
        return specialWarehouse.getData().stream().anyMatch(dictItemPo -> dictItemPo.getItemCode().equals(warehouseCode));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean updateLogistic(WarehouseDistributeOrderAddReq request) {
        String businessBillNo = request.getHead().getBusinessBillNo();
        WarehouseDistributeOrderPo orderPo = getByBusinessBillOrderNo(request.getHead().getBizType(), businessBillNo);

        if (Objects.isNull(orderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        if (StrUtil.containsBlank(request.getLogistic().getLogisticNo())) {
            throw new BizException("运单号存在空格,请确认单号是否正确");
        }

        if (WarehouseDistributeOrderTypeEnum.isApplyOrder(orderPo.getOrderType()) && !WarehouseDistributeOrderStatusEnum.CREATED.getCode().equals(orderPo.getOrderStatus())) {
            throw new BizException("当前订单不能更新");
        }
        orderPo.setLogisticNo(request.getLogistic().getLogisticNo());
        WarehouseDistributeOrderAllPo allPo = buildAllPo(orderPo);
        WarehouseDistributeLogisticPo logisticPo = allPo.getWarehouseDistributeLogisticPo();
        WarehouseDistributeLogisticPo newPo = warehouseDistributeLogisticConvertor.toPo(request.getLogistic());
        setWarehouseDistributeLogisticPo(newPo);
        newPo.setWarehouseDistributeOrderNo(orderPo.getOrderNo());
        newPo.setBizType(orderPo.getBizType());
        newPo.setId(logisticPo.getId());
        if (newPo.getShipper() == null) {
            newPo.setShipper(logisticPo.getShipper());
        }
        if (newPo.getShipperContact() == null) {
            newPo.setShipperContact(logisticPo.getShipperContact());
        }
        if (newPo.getDeliverAddress() == null) {
            newPo.setDeliverAddress(logisticPo.getDeliverAddress());
        }
        if (newPo.getReceiver() == null) {
            newPo.setReceiver(logisticPo.getReceiver());
        }
        if (newPo.getReceiverContact() == null) {
            newPo.setReceiverContact(logisticPo.getReceiverContact());
        }
        if (newPo.getReceiveAddress() == null) {
            newPo.setReceiveAddress(logisticPo.getReceiveAddress());
        }
        allPo.setWarehouseDistributeLogisticPo(newPo);
        if (!WarehouseDistributeOrderTypeEnum.isApplyOrder(orderPo.getOrderType())) {
            syncToTmsLogisticHandler.process(allPo);
        }
        //内领订单更新
        if (WarehouseDistributeOrderTypeEnum.isApplyOrder(orderPo.getOrderType())) {
            if (request.getAttach() != null) {
                WarehouseDistributeAttachDto attachDto = warehouseDistributeAttachService.selectWarehouseDistributeAttach(orderPo.getBizType(), orderPo.getOrderNo());
                WarehouseDistributeAttachPo attachPo = new WarehouseDistributeAttachPo();
                attachPo.setId(attachDto.getId());
                attachPo.setProductLineAndRate(request.getAttach().getProductLineAndRate());
                warehouseDistributeAttachService.updateById(attachPo);
            }
            if (CollUtil.isNotEmpty(request.getItemAttaches())) {
                List<WarehouseDistributeItemAttachPo> attachPos = warehouseDistributeItemAttachService.getByOrderNo(orderPo.getOrderNo());
                Map<String, WarehouseDistributeItemAttachReq> map = request.getItemAttaches().stream().collect(Collectors.toMap(WarehouseDistributeItemAttachReq::getMaterialLineNo, Function.identity()));
                List<WarehouseDistributeItemAttachPo> updates = new ArrayList<>();
                for (WarehouseDistributeItemAttachPo attachPo : attachPos) {
                    WarehouseDistributeItemAttachReq req = map.get(attachPo.getMaterialLineNo());
                    if (req != null) {
                        WarehouseDistributeItemAttachPo itemAttachPo = new WarehouseDistributeItemAttachPo();
                        itemAttachPo.setId(attachPo.getId());
                        itemAttachPo.setSubjectCode(req.getSubjectCode());
                        updates.add(itemAttachPo);
                    }
                }
                warehouseDistributeItemAttachService.updateBatchById(updates);
            }

        }
        aesUtil.encode(newPo);
        warehouseDistributeLogisticService.updateById(newPo);
        orderPo.setUpdateTime(LocalDateTime.now());
        return updateById(orderPo);
    }

    @Override
    public Boolean close(IdReq req) {
        WarehouseDistributeOrderPo orderPo = getById(req.getId());
        if (Objects.isNull(orderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }

        closedCheck(orderPo);
        WarehouseDistributeOrderTypeEnum type = WarehouseDistributeOrderTypeEnum.getByType(orderPo.getOrderType());
        switch (type) {
            case ES31: {
                //下发能源入库取消指令
                ResultResp<Object> resp = chargePartnerAuthClient.cancelTransferWorkOrder(TransferToEsCancelReq.builder().bizNo(orderPo.getOrderNo()).type(2).bizSource(1).build());
                if (!resp.isSuccess()) {
                    throw new BizException(resp.getMsg());
                }
                OrderNoReq orderNoReq = new OrderNoReq();
                orderNoReq.setOrderNo(orderPo.getOrderNo());
                orderNoReq.setBizType(orderPo.getBizType());
                spsClient.updateVmStock(orderNoReq);
                orderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.CANCELED.getCode());
                break;
            }
            case JC21:
            case SP21:
            case ES23:
            case CL21: {
                IndirectSrmWDCloseResp resp = syncWDApplyOrderCloseTOSrm(orderPo);
                //工服要取消占库
                if (type.equals(WarehouseDistributeOrderTypeEnum.JC21) || type.equals(WarehouseDistributeOrderTypeEnum.CL21)) {
                    List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.selectList(orderPo.getOrderNo());
                    WarehouseDistributeLogisticPo logisticPo = warehouseDistributeLogisticService.getByOrderNo(orderPo.getOrderNo());
                    cancelStock(itemPos, logisticPo, orderPo);
                }
                if (resp.isSuccess()) {
                    orderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
                } else {
                    throw new BizException(-1, resp.getResultMessage());
                }
                break;
            }
            default:
        }
        return updateById(orderPo);
    }


    public void closedCheck(WarehouseDistributeOrderPo orderPo) {

        //订单类型为能源调拨并且是已出库状态才能关闭
        if (!WarehouseDistributeOrderTypeEnum.canClosed(orderPo.getOrderType())) {
            throw new BizException("当前订单类型不能关闭");
        }
        //能源调拨只有已出库才能关闭
        if (WarehouseDistributeOrderTypeEnum.ES31.getValue().equals(orderPo.getOrderType()) && !WarehouseDistributeOrderStatusEnum.OUT_STOCK_COMPLETED.getCode().equals(orderPo.getOrderStatus())) {
            throw new BizException("当前状态不能关闭");
        }
        //内领子单不能关闭
        if (WarehouseDistributeOrderTypeEnum.isApplyOrder(orderPo.getOrderType())) {
            if (orderPo.getIsChild()) {
                throw new BizException("子单不允许关闭");
            }
            if (!WarehouseDistributeOrderStatusEnum.canClosed(orderPo.getOrderStatus())) {
                throw new BizException("当前状态不能关闭");
            }
            List<WarehouseDistributeOrderPo> lists = list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery().eq(WarehouseDistributeOrderPo::getAssociateBillNo, orderPo.getOrderNo()));
            for (WarehouseDistributeOrderPo child : lists) {
                if (!(WarehouseDistributeOrderStatusEnum.canClosed(child.getOrderStatus()) || WarehouseDistributeOrderStatusEnum.COMPLETED.getCode().equals(child.getOrderStatus()))) {
                    throw new BizException("子单还未完成");
                }
            }
        }

    }

    @Transactional
    @Override
    public void fork(WarehouseDistributeOrderAddReq req, List<WarehouseDistributeItemPo> itemPos, WarehouseDistributeOrderPo po) {
        add(req, true);
        warehouseDistributeItemService.updateBatchById(itemPos);
        updateById(po);
    }

    @Override
    public void updateStatus(OutboundApplyOrderMsg msg, String updateStatus) {
        update(Wrappers.<WarehouseDistributeOrderPo>lambdaUpdate()
                .set(WarehouseDistributeOrderPo::getOrderStatus, updateStatus)
                .eq(WarehouseDistributeOrderPo::getOrderNo, msg.getOrderNo()));
    }

    /**
     * 导入订单
     *
     * @param bizType
     * @param file
     */
    @Override
    public ImportResultResp createOrderByImport(String bizType, MultipartFile file) {
        ImportParamDto importParam = new ImportParamDto();
        importParam.setFile(file);
        importParam.setBizType(bizType);
        ImportReturnDataInfo<ExtendExportDto<WarehouseDistributeOrderImportExportResp>> resp
                = warehouseDistributeOrderImportHandler.doTask(importParam);
        ImportResultResp resultResp = new ImportResultResp();
        resultResp.setFileUrl(resp.getFileUrl());
        resultResp.setImportFlag(resp.getImportFlag());
        return resultResp;
    }

    /**
     * 找到最右边的1
     * 0000100100
     * ~=》1111011011 + 1 =》1111011100
     */
    public Integer lowBit(Integer index) {
        return index & -index;
    }

    @Override
    public WarehouseDistributeOrderAllPo buildAllPo(WarehouseDistributeOrderPo orderPo) {
        WarehouseDistributeLogisticPo logisticPo = warehouseDistributeLogisticService.getByOrderNo(orderPo.getOrderNo());
        aesUtil.decode(logisticPo);
        List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.selectList(orderPo.getOrderNo());
        List<WarehouseDistributeItemAttachPo> itemAttachPos = warehouseDistributeItemAttachService.getByOrderNo(orderPo.getOrderNo());
        List<WarehouseDistributeItemPackagePo> itemPackagePos = warehouseDistributeItemPackageService.getByOrderNo(orderPo.getOrderNo());
        WarehouseDistributeAttachPo attachPo = warehouseDistributeAttachService.getOne(Wrappers.<WarehouseDistributeAttachPo>lambdaQuery().eq(WarehouseDistributeAttachPo::getWarehouseDistributeOrderNo, orderPo.getOrderNo()));
        return WarehouseDistributeOrderAllPo
                .builder()
                .warehouseDistributeOrderPo(orderPo)
                .warehouseDistributeLogisticPo(logisticPo)
                .items(itemPos)
                .itemAttaches(itemAttachPos)
                .ItemPackages(itemPackagePos)
                .warehouseDistributeAttachPo(attachPo)
                .build();
    }

    @Override
    public List<WarehouseDistributeItemPo> checkReceiveQty(InAndOutStockRequest request) {
        WarehouseDistributeOrderPo orderPo = getByBusinessBillOrderNo(request.getBizType(), request.getTradeNo());
        if (orderPo == null) {
            orderPo = getByOrderNo(request.getBizType(), request.getTradeNo());
        }
        checkOrderStatus(orderPo);
        List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.selectList(orderPo.getOrderNo());
        Map<String, InAndOutStockParam> stockParamMap = request.getParams().stream().collect(Collectors.toMap(InAndOutStockParam::getColumnNo, Function.identity(), (e, n) -> {
            e.setSumQuantity(e.getSumQuantity().add(n.getSumQuantity()));
            return e;
        }));
        Map<String, WarehouseDistributeItemPo> itemPoMap = itemPos.stream().collect(Collectors.toMap(WarehouseDistributeItemPo::getMaterialLineNo, Function.identity()));
        for (InAndOutStockParam value : stockParamMap.values()) {
            WarehouseDistributeItemPo warehouseDistributeItemPo = itemPoMap.get(value.getColumnNo());
            if (Objects.isNull(warehouseDistributeItemPo)) {
                throw new BizException("间采行号不存在");
            }
            if (warehouseDistributeItemPo.getQty().compareTo(value.getSumQuantity()) < 0) {
                throw new BizException("入库数量不能超过需求数量:" + value.getColumnNo());
            }
        }
        return itemPos;
    }

    /**
     * 内领订单关闭 同步结果到SRM
     *
     * @param orderPo
     * @return
     */
    @Override
    public IndirectSrmWDCloseResp syncWDApplyOrderCloseTOSrm(WarehouseDistributeOrderPo orderPo) {
        IndirectWDApplyOrderCloseReq req = new IndirectWDApplyOrderCloseReq();
        IndirectWDApplyOrderCloseReq.IndirectWDApplyOrderCloseReqItem item = new IndirectWDApplyOrderCloseReq.IndirectWDApplyOrderCloseReqItem();
        item.setOrderCode(cutOrderCodeSuffix(orderPo.getBusinessBillNo()));
        item.setBusinessType(orderPo.getBizType());
        item.setCloseFlag("Y");
        req.setData(item);
        return indirectSrmClient.syncWDApplyOrderClose(req);
    }


    /**
     * 拆单的话 子单 SRM会传递后缀过来， 同步接续需要去除后缀处理
     *
     * @param orderCode
     * @return
     */
    private String cutOrderCodeSuffix(String orderCode) {
        if (orderCode.indexOf("-") > 0) {
            return orderCode.substring(0, orderCode.indexOf("-"));
        }
        return orderCode;
    }

    /**
     * 内领订单 出库结果同步到SRM
     *
     * @param message
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void syncWDApplyOrderPutOutTOSrm(String message) {
        outboxMessageService.saveMessage(OutboxConst.MessageType.WD_APPLY_ORDER_PUT_OUT_TO_SRM, message);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(IdReq req) {
        WarehouseDistributeOrderPo orderPo = getById(req.getId());
        if (!orderPo.getIsChild()) {
            throw new BizException("只有子单可以删除");
        }
        List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.selectList(orderPo.getOrderNo());
        updateParentOrder(itemPos, orderPo.getAssociateBillNo(), orderPo.getBizType());
        removeById(orderPo);
    }

    @Override
    public List<WarehouseDistributeOrderDto> listChild(OrderNoReq req) {
        List<WarehouseDistributeOrderPo> orderPos = list(Wrappers.<WarehouseDistributeOrderPo>lambdaQuery().eq(WarehouseDistributeOrderPo::getAssociateBillNo, req.getOrderNo()).eq(WarehouseDistributeOrderPo::getBizType, req.getBizType()));
        return getWarehouseDistributeOrderDtoList(orderPos, req.getBizType());
    }
}
