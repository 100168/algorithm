package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.PurchaseOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderMessageDto;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderTransferContextDto;
import com.jiduauto.sps.order.server.pojo.fileexport.PurchaseOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.ControlTransferReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalPoDeleteReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalPurchaseOrderAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderSearchReq;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPartTransferOperatePo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.pojo.po.StoreWarehouseConfigPo;
import com.jiduauto.sps.sdk.pojo.req.CreatePrOrderReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;

import java.util.List;

/**
 * <p>
 * 采购订单 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface IPurchaseOrderService extends IService<PurchaseOrderPo> {

    /**
     * 采购订单列表查询
     *
     * @param pageParam
     * @return
     */
    BasePageData<PurchaseOrderDto> pageSearch(BasePageParam<PurchaseOrderSearchReq> pageParam);

    /**
     * 采购订单转单
     *
     * @param operateEnum
     * @param purchaseOrderId
     */
    void transferOrder(OperateEnum operateEnum, Long purchaseOrderId);

    void createPrOrder(CreatePrOrderReq req, PurchaseOrderPo purchaseOrderPo, OperateEnum operateEnum);

    /**
     * CO采购订单转采购申请
     *
     * @param operateEnum
     * @param purchaseOrderId
     */
    void transferPurchaseApply(OperateEnum operateEnum, Long purchaseOrderId);

    /**
     * 删除
     *
     * @param request
     * @return BaseResult
     */
    BaseResult<String> delete(InternalPoDeleteReq request);

    /**
     * 处理转单逻辑
     *
     * @param contextDto
     */
    void doTransferOrder(PurchaseOrderTransferContextDto contextDto);

    /**
     * 参数校验
     * @param request
     * @return
     * */
    void check(InternalPurchaseOrderAddReq request);

    /**
     * 根据采购订单明细的收货,取消数量计算是否更新采购订单状态
     * 对于涉及 SO, BO 收货数量变更 & 取消的地方,都需要调用该方法
     * @see <a href="https://wiki.jiduauto.com/pages/viewpage.action?pageId=702735548">需求文档</>
     */
    void updateStateByReceiveQtyAndCancelQty(String poNo, String bizType);

    /**
     * 保存采购订单和明细
     * @param orderPo
     * @param detailPos
     * */
    void savePoAndDetail(PurchaseOrderPo orderPo, List<PurchaseOrderDetailPo> detailPos);

    /**
     * 采购申请 管控件指定零件数量转单 加上事务 独立个方法实现 事务结束后再释放redis 锁
     */
    void controlTransferWithTransactional(ControlTransferReq idReq);

    /**
     * 部分转单失败兜底job
     */
    void controlTransferJob(PurchaseOrderPartTransferOperatePo operatePo);

    /**
     * 采购申请 管控件指定零件数量转单
     */
    void transferOrderDetailSpecifyQty(PurchaseOrderPo po, List<StoreWarehouseConfigPo> storeWarehouseConfigPos, PurchaseOrderPartTransferOperatePo operatePo);

    /**
     * 更新采购订单状态并且发送MQ
     * @param purchaseOrderStatusChangeDto
     * @return
     */
    boolean updateStatusAndSendMessage(PurchaseOrderStatusChangeDto purchaseOrderStatusChangeDto);


    /**
     * 转单成功发送消息
     *
     */
    void transferSuccessSendMessage(PurchaseOrderMessageDto purchaseOrderMessageDto );

    /**
     * 导出查询
     */
    List<PurchaseOrderExportDto> exportSearch(BasePageParam<PurchaseOrderSearchReq> pageParam);

    /**
     * 管控件转单
     */
    void controlTransfer(ControlTransferReq idReq);
}
