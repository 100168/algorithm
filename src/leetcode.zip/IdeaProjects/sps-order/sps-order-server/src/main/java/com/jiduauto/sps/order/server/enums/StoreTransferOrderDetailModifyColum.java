package com.jiduauto.sps.order.server.enums;

import com.jiduauto.sps.sdk.enums.LogType;
import com.jiduauto.sps.sdk.utils.log.GeneralModifyColum;
import lombok.Getter;

import static com.jiduauto.sps.sdk.enums.LogType.FIELD;

@Getter
public enum StoreTransferOrderDetailModifyColum implements GeneralModifyColum {

    transferInQty("transferInQty", "调入数量"),
    transferOutQty("transferOutQty", "调出数量"),
    ;
    private final String value;
    private final String desc;
    private LogType logType = FIELD;

    StoreTransferOrderDetailModifyColum(String value, String desc) {
        this.value = value;
        this.desc = desc;
    }

    StoreTransferOrderDetailModifyColum(String value, String desc, LogType logType) {
        this.value = value;
        this.desc = desc;
        this.logType = logType;
    }

    @Override
    public String getOrderNoFieldName() {
        return "orderNo";
    }

    @Override
    public String getLogKey() {
        return LogKey.store_transfer_order_detail.getValue();
    }

    @Override
    public int getLogType() {
        return this.logType.getType();
    }
    /**
      * 获取中文变更描述
      */
    public static String getByDesc(String value) {
        for (StoreTransferOrderDetailModifyColum colum : StoreTransferOrderDetailModifyColum.values()) {
            if (colum.getValue().equals(value)){
                return colum.getDesc();
            }
        }
        return null;
    }
}
