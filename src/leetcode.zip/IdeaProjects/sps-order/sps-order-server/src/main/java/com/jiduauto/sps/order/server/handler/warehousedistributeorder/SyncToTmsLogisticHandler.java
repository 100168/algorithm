package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.convertor.BillIntoItemReqConvertor;
import com.jiduauto.sps.order.server.convertor.BillIntoReqConvertor;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.BizTypeEnum;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.track.api.feign.TrackFeignClient;
import com.jiduauto.track.api.vo.req.BillIntoReq;
import com.jiduauto.track.api.vo.req.GoodsInfoReq;
import com.jiduauto.track.api.vo.resp.BaseResultObj;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/*
 * 下发tms创建运单*/
@Slf4j
@Component
public class SyncToTmsLogisticHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private TrackFeignClient trackFeignClient;

    @Resource
    private BillIntoReqConvertor billIntoReqConvertor;

    @Resource
    private BillIntoItemReqConvertor billIntoItemReqConvertor;
    @Resource
    private BaseDataQuery baseDataQuery;

    /**
     * 仓配订单同步运输信息给tms
     */
    @Override
    public void process(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {

        WarehouseDistributeLogisticPo logisticPo = warehouseDistributeOrderAllPo.getWarehouseDistributeLogisticPo();
        WarehouseDistributeOrderPo orderPo = warehouseDistributeOrderAllPo.getWarehouseDistributeOrderPo();
        if (StrUtil.isBlank(orderPo.getLogisticNo())) {
            return;
        }
        List<WarehouseDistributeItemPo> items = warehouseDistributeOrderAllPo.getItems();
        Map<String, List<WarehouseDistributeItemPo>> groupByBizType = items.stream().collect(Collectors.groupingBy(WarehouseDistributeItemPo::getBizType));
        Map<String, MaterialPo> materialMap = new HashMap<>();
        for (Map.Entry<String, List<WarehouseDistributeItemPo>> entry : groupByBizType.entrySet()) {
            Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(entry.getKey(), entry.getValue().stream().map(WarehouseDistributeItemPo::getMaterialCode).collect(Collectors.toList()), false);
            materialMap.putAll(materialPoMap);
        }

        BillIntoReq req = billIntoReqConvertor.toReq(logisticPo, orderPo);
        if (orderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM30.getValue())) {
            req.setBusinessNo(orderPo.getOrderNo());
        }
        if (orderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM12.getValue()) || orderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM11.getValue())) {
            //获取仓库地址 目前都是 G59
            Map<String, String> mapLocationMap = baseDataQuery.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());
            WarehousePo warehousePo = baseDataQuery.getWarehousePo(BizTypeEnum.SP.getBizType(), logisticPo.getReceiveWarehouseCode()).get();
            req.setReceiveProvince(mapLocationMap.get(warehousePo.getProvinceCode()));
            req.setReceiveCity(mapLocationMap.get(warehousePo.getCityCode()));
            req.setReceiveArea(mapLocationMap.get(warehousePo.getDistrictCode()));
            req.setReceiver(warehousePo.getContact());
            req.setReceiverPhone(warehousePo.getPhoneNumber());
            req.setReceiverAddress(warehousePo.getAddress());
        }
        List<GoodsInfoReq> goodsInfoReqList = billIntoItemReqConvertor.toReq(items);
        BigDecimal sum = items.stream().map(WarehouseDistributeItemPo::getQty).reduce(BigDecimal.ZERO, BigDecimal::add);

        for (GoodsInfoReq goodsInfoReq : goodsInfoReqList) {
            goodsInfoReq.setGoodsName(materialMap.getOrDefault(goodsInfoReq.getGoodsName(), new MaterialPo()).getMaterialName());
        }
        req.setTotalQuantity(sum.toString());
        req.setGoodsInfos(goodsInfoReqList);
        BaseResultObj<String> resp = trackFeignClient.billInto(req);
        if (resp.getCode() != 0) {
            throw new BizException("物流信息下发tms异常:" + resp.getMessage());
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.SYNC_TO_TMS_LOGISTIC.getBitIndex(), this);
    }
}
