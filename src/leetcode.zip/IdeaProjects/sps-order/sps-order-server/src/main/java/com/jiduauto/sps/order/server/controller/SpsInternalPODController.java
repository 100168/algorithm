package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderDetailSearchReq;
import com.jiduauto.sps.order.server.service.IPurchaseOrderDetailService;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * 采购订单明细 前端控制器
 *
 * @author generate
 * @since 2023-04-12
 */
@RestController
@RequestMapping("/spsInternal/po/detail")
public class SpsInternalPODController {

    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;

    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<PurchaseOrderDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<PurchaseOrderDetailSearchReq> pageSearchReq) {
        return BaseResult.OK(purchaseOrderDetailService.pageSearch(pageSearchReq));
    }


    @PostMapping("/detail")
    public BaseResult<List<PurchaseOrderDetailDto>> detail(@RequestBody @Valid PurchaseOrderDetailSearchReq req) {
        return BaseResult.OK(purchaseOrderDetailService.getDetail(req));
    }



}
