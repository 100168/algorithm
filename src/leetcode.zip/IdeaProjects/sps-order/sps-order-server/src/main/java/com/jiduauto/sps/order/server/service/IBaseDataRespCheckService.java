package com.jiduauto.sps.order.server.service;

import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;

/**
 * @ClassName BaseDataRespCheckService
 * @Description
 * @Author O_chaopeng.huang
 * @Date 2023/11/20 16:54
 */
public interface IBaseDataRespCheckService {
    /**
      * 基础数据存在性校验
      */
    void check(BaseResult<BaseDataResp> resp, BaseDataReq req);


}
