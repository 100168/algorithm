package com.jiduauto.sps.order.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountDto;
import com.jiduauto.sps.order.server.pojo.fileexport.StoreDiscountExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountPageReq;
import com.jiduauto.sps.order.server.service.IStoreDiscountService;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.ExcelUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

/**
 * <p>
 * 门店折扣表 前端控制器
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
@RestController
@RequestMapping("/storeDiscount")
public class StoreDiscountController {


    @Resource
    private IStoreDiscountService storeDiscountService;

    /**
     * 分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StoreDiscountDto>> pageSearch(@RequestBody @Valid BasePageParam<StoreDiscountPageReq> pageParam) {
        return BaseResult.OK(storeDiscountService.pageSearch(pageParam));
    }

    /**
     * 门店折扣导出
     */
    @RequestMapping("/export")
    public void export(
            HttpServletResponse response, @RequestBody @Valid BasePageParam<StoreDiscountPageReq> pageParam) {
        try {
            ExcelUtils.exportXlsxResponse(response, "门店折扣数据");
            EasyExcel.write(response.getOutputStream(), StoreDiscountExportDto.class).sheet("门店折扣").doWrite(storeDiscountService.export(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }
}
