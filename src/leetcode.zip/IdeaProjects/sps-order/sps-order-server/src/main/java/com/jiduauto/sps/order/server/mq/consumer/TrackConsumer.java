package com.jiduauto.sps.order.server.mq.consumer;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderStatusEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.resp.TrackMqMessageResp;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Objects;

@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_ORDER_TRACK_STATUS_CHANGE,
        topic = BaseConstants.RocketMqTopic.TC_DIT_TRACK_INTO,
        consumeThreadMax = 10)
public class TrackConsumer implements RocketMQListener<MessageExt> {

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private SpsClient spsClient;


    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("入库异步处理业务订单:" + body);
        TrackMqMessageResp request = JSONUtil.toBean(body, TrackMqMessageResp.class);
        //目前只接仓配订单QE快反和商城订单且已签收
        if (isValid(request)) {
            WarehouseDistributeOrderPo orderPo;
            orderPo = warehouseDistributeOrderService.getOne(Wrappers.lambdaQuery(WarehouseDistributeOrderPo.class).eq(WarehouseDistributeOrderPo::getOrderNo, request.getBusinessNo()));
            if (Objects.isNull(orderPo)) {
                orderPo = warehouseDistributeOrderService.getOne(Wrappers.lambdaQuery(WarehouseDistributeOrderPo.class)
                        .ne(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.CANCELED.getCode())
                        .eq(WarehouseDistributeOrderPo::getBusinessBillNo, request.getBusinessNo()));
            }
            if (orderPo == null
                    || Objects.equals(orderPo.getOrderType(), WarehouseDistributeOrderTypeEnum.QE12.getValue())
                    || Objects.equals(orderPo.getOrderType(), WarehouseDistributeOrderTypeEnum.QE11.getValue())
                    || orderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM11.getValue())
                    || orderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM12.getValue())) {
                return;
            }
            if (orderPo.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode())) {
                return;
            }
            orderPo.setOrderStatus(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode());
            orderPo.setUpdateTime(LocalDateTime.now());
            if (orderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM20.getValue())) {
                OrderNoReq orderNoReq = new OrderNoReq();
                orderNoReq.setOrderNo(orderPo.getOrderNo());
                orderNoReq.setBizType(orderPo.getBizType());
                spsClient.outOfVmStock(orderNoReq);
            }
            warehouseDistributeOrderService.updateById(orderPo);
        }
    }

    private boolean isValid(TrackMqMessageResp request) {
        return (Objects.equals(request.getBusinessTypeCode(), "QE")
                || Objects.equals(request.getBusinessTypeCode(), "SM"))
                && Objects.equals(request.getPersonCode(), "60");
    }
}
