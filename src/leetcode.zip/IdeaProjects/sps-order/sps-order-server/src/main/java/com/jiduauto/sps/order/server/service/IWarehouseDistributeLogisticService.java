package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeLogisticDto;

import java.util.List;

/**
 * <p>
 * 仓配订单物流信息 服务类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
public interface IWarehouseDistributeLogisticService extends IService<WarehouseDistributeLogisticPo> {

    /**
     * 脱敏的信息
     * @author O_chaopeng.huang
     * @param  bizType 业务类型 orderNo 仓配订单号
     */
    WarehouseDistributeLogisticDto selectOne(String bizType, String orderNo);


    /**
     * 批量获取
     * @author O_chaopeng.huang
     * @param  bizType 业务类型 orderNo 仓配订单号
     */
    List<WarehouseDistributeLogisticDto> selectWarehouseDistributeLogisticList(String bizType, List<String> orderNos);
    /**
     * 不脱敏的信息
     * @author O_chaopeng.huang
     * @param  bizType 业务类型 orderNo 仓配订单号
     */
    WarehouseDistributeLogisticDto selectWarehouseDistributeLogistic(String bizType, String orderNo);

    /**
     * 根据订单号查询*/
    WarehouseDistributeLogisticPo getByOrderNo(String orderNo);
}
