package com.jiduauto.sps.order.server.facade;


import com.jiduauto.sps.order.server.pojo.dto.InternalBackOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderCancelReq;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderListSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalBoSearchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

import java.util.List;

/**
 * @author panjian
 */
public interface BackOrderFacadeService {

    /**
     * 缺件订单列表查询
     * @param pageParam
     * @return */
    BasePageData<InternalBackOrderDto> internalPageSearch(BasePageParam<InternalBoSearchReq> pageParam);

    /**
     * 申请取消缺件订单
     *
     * @param cancelReq
     */
    void cancelApply(BackOrderCancelReq cancelReq);
    /**
     * 缺件订单列表查询
     * @param listSearchReq 缺件订单号
     * @return list */
    List<InternalBackOrderDto> list(BackOrderListSearchReq listSearchReq);
}
