package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.DictItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/*
 *占用库存
 * */
@Component
public class OccupyStockHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;
    @Resource
    private SpsClient spsClient;


    /**
     * 占用库存
     */
    @Override
    public void process(WarehouseDistributeOrderAllPo allPo) {
        WarehouseDistributeLogisticPo logisticPo = allPo.getWarehouseDistributeLogisticPo();
        BaseResult<List<DictItemPo>> specialWarehouse = spsClient.getSpecialWarehouse(logisticPo.getBizType());
        WarehouseDistributeOrderPo orderPo = allPo.getWarehouseDistributeOrderPo();
        // 商城订单需要占库先不出库，占库成功后再出库
        if (orderPo.getOrderType().equals(WarehouseDistributeOrderTypeEnum.SM20.getValue()) && !orderPo.getIsSpecial()) {
            return;
        }
        //不是G59仓库不需要占库
        if (!WarehouseDistributeOrderTypeEnum.needOccupyStock(orderPo.getOrderType())
                && specialWarehouse.getData().stream().noneMatch(dictItemPo -> dictItemPo.getItemCode().equals(logisticPo.getDeliverWarehouseCode()))) {
            return;
        }
        warehouseDistributeOrderService.occupyStock(allPo);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.OCCUPY_STOCK.getBitIndex(), this);
    }
}
