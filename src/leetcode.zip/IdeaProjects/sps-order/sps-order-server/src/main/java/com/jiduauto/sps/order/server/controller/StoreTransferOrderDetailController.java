package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.service.IStoreTransferOrderDetailService;
import com.jiduauto.sps.sdk.pojo.dto.StoreTransferOrderDetailDto;
import com.jiduauto.sps.sdk.pojo.req.OrderNoReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import javax.annotation.Resource;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 门店调拨单明细 前端控制器
 *
 * @author generate
 * @since 2024-01-12
 */
@RestController
@RequestMapping("/storeTransferOrderDetail")
public class StoreTransferOrderDetailController {
    @Resource
    private IStoreTransferOrderDetailService storeTransferOrderDetailService;
    /**
     * 门店调拨单明细分页
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StoreTransferOrderDetailDto>> pageSearch(@RequestBody @Valid BasePageParam<OrderNoReq> pageParam) {
        return BaseResult.OK(storeTransferOrderDetailService.pageSearch(pageParam));
    }
}
