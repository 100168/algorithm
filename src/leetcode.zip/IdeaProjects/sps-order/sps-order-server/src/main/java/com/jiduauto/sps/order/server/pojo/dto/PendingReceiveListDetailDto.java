package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PendingReceiveListDetailDto {
    /**
     * 主键
     */
    private Long id;

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 外部系统单号
     */
    private String outOrderNo;
    /**
     * 行号
     */
    private String lineNo;
    /**
     * 业务单行号
     */
    private String columnProjectNo;
    /**
     * 业务单号
     */
    private String businessBillNo;

    /**
     * 零件编码
     */
    private String materialCode;

    /**
     * 零件名称
     */
    private String materialName;


    /**
     * 供应商编码
     */
    private String supplierCode;
    /**
     * 供应商名称
     */
    private String supplierName;

    /**
     * 零件条码
     */
    private String materialBarCode;

    /**
     * 应收总数
     */
    private BigDecimal expectQty;

    /**
     * 实收总数
     */
    private BigDecimal actualQty;

    /**
     * 项目
     */
    private String projectCode;

    /**
     * 阶段
     */
    private String stageCode;

    /**
     * 项目名
     */
    private String projectName;

    /**
     * 阶段名
     */
    private String stageName;

    /**
     * 推荐数量
     */
    private BigDecimal qty;

    /**差异原因*/
    private String remark;

    /**
     * 详情备注
     */
    private String detailRemark;
}
