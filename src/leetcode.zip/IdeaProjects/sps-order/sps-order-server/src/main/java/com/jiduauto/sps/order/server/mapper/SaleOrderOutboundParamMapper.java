package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderOutboundParamPo;

/**
 * <p>
 * 销售订单出库关系表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-07-10
 */
public interface SaleOrderOutboundParamMapper extends BaseMapper<SaleOrderOutboundParamPo> {

}
