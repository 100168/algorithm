package com.jiduauto.sps.order.server.handler.purchaseorder;


import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderTransferContextDto;
import com.jiduauto.sps.sdk.enums.PartSaleFieldEnum;
import com.jiduauto.sps.sdk.enums.ShippingMethodEnum;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.utils.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component
public class VorPurchaseOrderOccupy extends PurchaseOrderOccupy {

    @Resource
    private SpsClient spsClient;

    public void occupy(PurchaseOrderTransferContextDto contextDto) {
        occupyPartStock(contextDto, spsClient);
    }

    @Override
    public String getShippingMethod(MaterialPo materialPo) {
        if (StringUtils.isEmpty(materialPo.getPartSaleField())) {
            return ShippingMethodEnum.AIR.getCode();
        }

        PartSaleFieldEnum partSaleField = PartSaleFieldEnum.getByName(materialPo.getPartSaleField());
        switch (partSaleField) {
            case AIR_PROHIBITION:
                return ShippingMethodEnum.EXPRESS.getCode();
            case EXPRESS_PROHIBITION:
            case AIR_AND_EXPRESS_PROHIBITION:
                return ShippingMethodEnum.LTL_LAND.getCode();
            default:
                return ShippingMethodEnum.AIR.getCode();
        }
    }
}
