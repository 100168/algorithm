package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderOperateLogDto;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderStatusChangeDto;
import com.jiduauto.sps.sdk.pojo.req.BackOrderOperateSearchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.po.BackOrderOperateLogPo;

/**
 * <p>
 * 缺件订单操作记录 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface IBackOrderOperateLogService extends IService<BackOrderOperateLogPo> {

    /**缺件订单状态查询
     * @param pageSearchReq
     * @return  */
    BasePageData<BackOrderOperateLogDto> pageSearch(BasePageParam<BackOrderOperateSearchReq> pageSearchReq);

    /**
     * 保存状态变更记录
     *
     * @param changeDto
     */
    void saveStatusChangeLog(BackOrderStatusChangeDto changeDto);
}
