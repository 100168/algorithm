package com.jiduauto.sps.order.server.service.impl;

import com.jiduauto.sps.order.server.mapper.*;
import com.jiduauto.sps.order.server.pojo.dto.SynchoResultDto;
import com.jiduauto.sps.order.server.service.ISynchroOrderService;
import com.jiduauto.sps.sdk.pojo.po.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service
@Slf4j
public class ISynchroOrderServiceImpl implements ISynchroOrderService {
    @Resource
    private BackOrderMapper backOrderMapper;
    @Resource
    private BackOrderOperateLogMapper backOrderOperateLogMapper;
    @Resource
    private BackSaleRelationMapper backSaleRelationMapper;
    @Resource
    private PurchaseOrderDetailMapper purchaseOrderDetailMapper;
    @Resource
    private PurchaseOrderMapper purchaseOrderMapper;
    @Resource
    private  PurchaseOrderOperateLogMapper purchaseOrderOperateLogMapper;
    @Resource
    private SaleOrderDetailMapper saleOrderDetailMapper;
    @Resource
    private SaleOrderMapper saleOrderMapper;
    @Resource
    private SaleOrderOperateLogMapper saleOrderOperateLogMapper;
    @Resource
    private WarehouseDistributeAttachMapper warehouseDistributeAttachMapper;
    @Resource
    private WarehouseDistributeItemAttachMapper warehouseDistributeItemAttachMapper;
    @Resource
    private  WarehouseDistributeItemMapper warehouseDistributeItemMapper;
    @Resource
    private  WarehouseDistributeItemPackageMapper warehouseDistributeItemPackageMapper;
    @Resource
    private  WarehouseDistributeLogisticMapper warehouseDistributeLogisticMapper;
    @Resource
    private  WarehouseDistributeOrderMapper warehouseDistributeOrderMapper;

    @Override
    @Transactional
    public void batchInsert(SynchoResultDto poMap) {
        List<BackOrderPo> backOrderPos = poMap.getBackOrderPos();
        List<BackOrderOperateLogPo> backOrderOperateLogPos = poMap.getBackOrderOperateLogPos();
        List<BackSaleRelationPo> backSaleRelationPos = poMap.getBackSaleRelationPos();
        List<PurchaseOrderDetailPo> purchaseOrderDetailPos = poMap.getPurchaseOrderDetailPos();
        List<PurchaseOrderPo> purchaseOrderPos =  poMap.getPurchaseOrderPos();
        List<PurchaseOrderOperateLogPo> purchaseOrderOperateLogPos =  poMap.getPurchaseOrderOperateLogPos();
        List<SaleOrderDetailPo> saleOrderDetailPos = poMap.getSaleOrderDetailPos();
        List<SaleOrderPo> saleOrderPos =  poMap.getSaleOrderPos();
        List<SaleOrderOperateLogPo> saleOrderOperateLogPos = poMap.getSaleOrderOperateLogPos();
        List<WarehouseDistributeAttachPo> warehouseDistributeAttachPos =  poMap.getWarehouseDistributeAttachPos();
        List<WarehouseDistributeItemAttachPo> warehouseDistributeItemAttachPos = poMap.getWarehouseDistributeItemAttachPos();
        List<WarehouseDistributeItemPo> warehouseDistributeItemPos = poMap.getWarehouseDistributeItemPos();
        List<WarehouseDistributeItemPackagePo> warehouseDistributeItemPackagePos =  poMap.getWarehouseDistributeItemPackagePos();
        List<WarehouseDistributeLogisticPo> warehouseDistributeLogisticPos =  poMap.getWarehouseDistributeLogisticPos();
        List<WarehouseDistributeOrderPo> warehouseDistributeOrderPos =  poMap.getWarehouseDistributeOrderPos();
        for(BackOrderPo po:backOrderPos){
            backOrderMapper.insert(po);
        }
        for(BackOrderOperateLogPo po : backOrderOperateLogPos){
            backOrderOperateLogMapper.insert(po);
        }
        for(BackSaleRelationPo po : backSaleRelationPos){
            backSaleRelationMapper.insert(po);
        }
        for(PurchaseOrderDetailPo po : purchaseOrderDetailPos){
            purchaseOrderDetailMapper.insert(po);
        }
        for(PurchaseOrderPo po : purchaseOrderPos){
            purchaseOrderMapper.insert(po);
        }
        for(PurchaseOrderOperateLogPo po : purchaseOrderOperateLogPos){
            purchaseOrderOperateLogMapper.insert(po);
        }
        for(SaleOrderDetailPo po : saleOrderDetailPos){
            saleOrderDetailMapper.insert(po);
        }
        for(SaleOrderPo po : saleOrderPos){
            saleOrderMapper.insert(po);
        }
        for(SaleOrderOperateLogPo po : saleOrderOperateLogPos){
            saleOrderOperateLogMapper.insert(po);
        }
        for(WarehouseDistributeAttachPo po : warehouseDistributeAttachPos){
            warehouseDistributeAttachMapper.insert(po);
        }
        for(WarehouseDistributeItemAttachPo po : warehouseDistributeItemAttachPos){
            warehouseDistributeItemAttachMapper.insert(po);
        }
        for(WarehouseDistributeItemPo po : warehouseDistributeItemPos){
            warehouseDistributeItemMapper.insert(po);
        }
        for(WarehouseDistributeItemPackagePo po : warehouseDistributeItemPackagePos){
            warehouseDistributeItemPackageMapper.insert(po);
        }
        for(WarehouseDistributeLogisticPo po : warehouseDistributeLogisticPos){
            warehouseDistributeLogisticMapper.insert(po);
        }
        for(WarehouseDistributeOrderPo po : warehouseDistributeOrderPos){
            warehouseDistributeOrderMapper.insert(po);
        }

    }
}
