package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeOrderItemExportDto;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.*;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeItemReq;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface WarehouseDistributeItemConvertor {

    /**
     * to po
     * @param req req
     * @return WarehouseDistributeOrderPo
     */
    @Mapping(target = "warehouseDistributeOrderNo", ignore = true)
    @Mapping(target = "warehouseCode", ignore = true)
    @Mapping(target = "realOutQty", ignore = true)
    @Mapping(target = "realInQty", ignore = true)
    @Mapping(target = "locationCode", ignore = true)
    @Mapping(target = "forkedQty", ignore = true)
    @Mapping(target = "areaCode", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "expireDate", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    WarehouseDistributeItemPo toPo(WarehouseDistributeItemReq req);

    /**
     * to po
     * @param req req
     * @return WarehouseDistributeOrderPo
     */
    List<WarehouseDistributeItemPo> toPo(List<WarehouseDistributeItemReq> req);
    @Mapping(target = "restForkedQty", expression = "java(po.getQty().subtract(po.getForkedQty()))")
    @Mapping(target = "warehouseName", ignore = true)
    @Mapping(target = "supplierName", ignore = true)
    @Mapping(target = "stockStatusName", ignore = true)
    @Mapping(target = "stageName", ignore = true)
    @Mapping(target = "projectName", ignore = true)
    @Mapping(target = "materialStatusName", ignore = true)
    @Mapping(target = "materialSortName", ignore = true)
    @Mapping(target = "materialName", ignore = true)
    @Mapping(target = "locationName", ignore = true)
    @Mapping(target = "bizTypeName", ignore = true)
    @Mapping(target = "areaName", ignore = true)
    WarehouseDistributeOrderItemDto toDto(WarehouseDistributeItemPo po);
    List<WarehouseDistributeOrderItemDto> toDto(List<WarehouseDistributeItemPo> po);

    @Mapping(target = "logisticNo", source = "dto.logisticNo")
    @Mapping(target = "processCode", source = "attachDto.processCode")
    @Mapping(target = "bizTypeName", source = "dto.bizTypeName")
    @Mapping(target = "deliverWarehouseCode", source = "dto.deliverWarehouseCode")
    @Mapping(target = "receiveWarehouseCode", source = "dto.receiveWarehouseCode")
    @Mapping(target = "shippingMethodName", source = "dto.shippingMethodName")
    @Mapping(target = "estPickTime", source = "dto.estPickTime")
    @Mapping(target = "estArrivalTime", source = "dto.estArrivalTime")
    @Mapping(target = "remark", source = "dto.remark")
    @Mapping(target = "deliverUni", source = "dto.deliverUni")
    @Mapping(target = "receiveUni", source = "dto.receiveUni")
    @Mapping(target = "materialLineNo", source = "itemDto.materialLineNo")
    @Mapping(target = "bizType", source = "itemDto.bizTypeName")
    @Mapping(target = "wbsCode", source = "itemAttachDto.wbsCode")
    @Mapping(target = "responsibleParty", source = "dto.responsibleParty")
    @Mapping(target = "planApplyFlag", expression = "java(cn.hutool.core.util.BooleanUtil.toStringYesNo(itemAttachDto != null && itemAttachDto.getPlanApplyFlag()))")
    @Mapping(target = "createUser", source = "dto.createUser")
    @Mapping(target = "createTime", source = "dto.createTime")
    @Mapping(target = "updateUser", source = "dto.updateUser")
    @Mapping(target = "updateTime", source = "dto.updateTime")
    WarehouseDistributeOrderItemExportDto toDto(WarehouseDistributeOrderDto dto, WarehouseDistributeOrderItemDto itemDto, WarehouseDistributeLogisticPo logisticPo, WarehouseDistributeAttachDto attachDto, WarehouseDistributeAttachItemDto itemAttachDto);

}
