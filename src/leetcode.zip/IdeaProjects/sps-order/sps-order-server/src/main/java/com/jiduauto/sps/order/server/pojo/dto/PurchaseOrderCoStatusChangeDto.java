package com.jiduauto.sps.order.server.pojo.dto;

import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.TurnPurchaseOrderStatusEnum;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PurchaseOrderCoStatusChangeDto {

    /**
     * 采购订单
     */
    private PurchaseOrderPo purchaseOrderPo;

    /**
     * 新的订单状态
     */
    private TurnPurchaseOrderStatusEnum newOrderStatus;

    /**
     * 操作行为
     */
    private OperateEnum operateEnum;

    /**
     * 操作用户
     */
    private String operateUser;

    /**
     * 变更备注
     */
    private String remark;
}
