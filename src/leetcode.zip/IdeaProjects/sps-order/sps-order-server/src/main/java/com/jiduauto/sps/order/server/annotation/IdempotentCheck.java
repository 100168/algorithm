package com.jiduauto.sps.order.server.annotation;

import java.lang.annotation.*;


/**
 * 接口幂等注解
 * 使用方式, 在 controller 接口方法上加上该注解, 要求使用方 请求时, 请求头中设置 idempotentNo 字段
 * 即会根据 路径 & idempotentNo 值判断是否执行过, 执行过则直接返回成功
 * <p>
 * 当 forceCheck 为 false 则不强制校验 请求头中是否存在 idempotentNo 字段, idempotentNo 没有值时不校验幂等
 * 由客户端请求方自己控制是否想要幂等, 适用于一个接口有多个业务方使用时, 不强制客户端增加幂等字段
 */
@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface IdempotentCheck {

    /**
     * 是否强制校验 请求头中是否存在 idempotentNo 字段
     */
    boolean forceCheck() default true;
}
