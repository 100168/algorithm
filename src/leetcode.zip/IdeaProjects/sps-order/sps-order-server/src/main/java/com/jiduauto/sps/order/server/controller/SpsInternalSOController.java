package com.jiduauto.sps.order.server.controller;

import cn.hutool.core.io.IoUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import cn.hutool.http.HttpUtil;
import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDto;
import com.jiduauto.sps.order.server.pojo.fileexport.SaleOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderNoAndClaimReq;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderNoReq;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderPageSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.TrackDetailItemResp;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.service.ISapInvoiceInfoService;
import com.jiduauto.sps.sdk.client.req.StockInItemQuantityDto;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.pojo.po.SapInvoiceInfoPo;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import com.jiduauto.sps.sdk.pojo.req.NoReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.ExcelUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * sps 需要调用的相关接口
 */
@RestController
@RequestMapping("/spsInternal/so")
public class SpsInternalSOController {


    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private ISapInvoiceInfoService sapInvoiceInfoService;

    /**
     * 销售订单分页查询
     *
     * @author dong.li
     * @date 4/14/23 2:14 PM
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<SaleOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<SaleOrderPageSearchReq> pageParam) {
        return BaseResult.OK(saleOrderService.pageSearch(pageParam));
    }

    /**
     * 手工转单 dfs
     *
     * @param idReq
     * @return
     */
    @PostMapping("/transferOrder")
    public BaseResult<String> transferOrder(@RequestBody @Valid IdReq idReq) {
        saleOrderService.transferOrder(OperateEnum.MANUAL_TRANSFER, idReq.getId());
        return BaseResult.OK();
    }

    /**
     * 销售订单取消
     * @param idReq
     * @return
     */
    @PostMapping("/cancel")
    public BaseResult<String> cancel(@RequestBody @Valid IdReq idReq) {
        saleOrderService.cancel(idReq.getId());
        return BaseResult.OK();
    }

    /**
     * 物流轨迹
     *
     * @param saleOrderNoReq
     * @return
     */
    @PostMapping("/trackDetail")
    public BaseResult<List<TrackDetailItemResp>> trackDetail(@RequestBody SaleOrderNoReq saleOrderNoReq) {
        return BaseResult.OK(saleOrderService.trackDetail(saleOrderNoReq));
    }

    /**
     * 更改是否 是索赔白名单
     */
    @PostMapping("/changeClaimWhitelist")
    public BaseResult<String> changeClaimWhitelist(@RequestBody @Valid SaleOrderNoAndClaimReq req){
        saleOrderService.changeClaimWhitelist(req);
        return BaseResult.OK();
    }

    /**
     * 手工下发
     * @param idReq 销售订单主键id
     */
    @PostMapping("/manualDownSend")
    public BaseResult<String> manualDownSend(@RequestBody @Valid IdReq idReq) {
        return saleOrderService.manualDownSend(idReq);
    }

    /**
     * 导出
     **/
    @RequestMapping("/export")
    public void export(HttpServletResponse response, @RequestBody @Valid BasePageParam<SaleOrderPageSearchReq> pageParam){
        try {
            ExcelUtils.exportXlsxResponse(response, "销售订单查询结果");
            EasyExcel.write(response.getOutputStream(), SaleOrderExportDto.class)
                    .sheet("销售订单查询结果").doWrite(saleOrderService.exportSearch(pageParam.getParam()));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

    /**
     * SO 收货校验
     **/
    @PostMapping("/checkReceiveQty")
    public BaseResult<String> checkReceiveQty( @RequestBody @Valid InAndOutStockRequest request ) {
        List<StockInItemQuantityDto> outQuantityList = new ArrayList<>();
        for(InAndOutStockParam param: request.getParams()){
            StockInItemQuantityDto dto = new StockInItemQuantityDto();
            dto.setQuantity(param.getSumQuantity());
            dto.setSalePartNum(param.getMaterialCode());
            outQuantityList.add(dto);
        }
        try{
            saleOrderService.checkReceiveQty(request.getTradeNo(),outQuantityList);
        }catch (Exception e){
            return BaseResult.error(-1,e.getMessage());
        }
        return BaseResult.OK();
    }

    /**
     * 发票附件下载
     */
    @PostMapping("/invoice/download")
    public void downloadFile(HttpServletResponse response, @RequestBody @Valid NoReq req) throws IOException {
        SapInvoiceInfoPo po = sapInvoiceInfoService.getOne(Wrappers.lambdaQuery(SapInvoiceInfoPo.class)
                .eq(SapInvoiceInfoPo::getBizType, req.getBizType())
                .eq(SapInvoiceInfoPo::getInvoiceNo, req.getNo())
        );
        if (po == null) {
            throw new BizException("附件不存在");
        }
        response.setCharacterEncoding("utf-8");
        HttpRequest request = HttpUtil.createPost(po.getInvoiceUrl());
        HttpResponse resp = request.execute();
        String replace = resp.header("Content-disposition").replace("fileName", "filename");
        response.setHeader("Content-disposition", replace);
        IoUtil.write(response.getOutputStream(), true, resp.bodyBytes());
    }
}
