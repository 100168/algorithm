package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountApprovalDto;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalPageReq;
import com.jiduauto.sps.sdk.pojo.dto.WorkOrderCallBackDto;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.SpsBaseReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

/**
 * <p>
 * 门店折扣审批表 服务类
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
public interface IStoreDiscountApprovalService extends IService<StoreDiscountApprovalPo> {

    /**
     * 分页查询
     */
    BasePageData<StoreDiscountApprovalDto> pageSearch(BasePageParam<StoreDiscountApprovalPageReq> pageParam);

    /**
     * 删除
     */
    void deleteById(IdReq req);

    /**
     * 创建临时记录
     */
    Long createTempRecord(SpsBaseReq request);

    /**
     * 启用临时记录
     */
    void enableTempRecord(IdReq req);

    /**
     * 提交
     */
    void commit(IdReq request);

    /**
     * 工单 callback
     */
    void workOrderCallBack(WorkOrderCallBackDto callBackDto);
}
