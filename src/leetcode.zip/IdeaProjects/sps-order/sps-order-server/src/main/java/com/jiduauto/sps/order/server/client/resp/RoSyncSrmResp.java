package com.jiduauto.sps.order.server.client.resp;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author panjian
 */
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class RoSyncSrmResp {

    private List<ClassMessageBody> MessageBody;

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBody {
        private ClassMessageBodyHeader Header;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyHeader {
        private String Receiver;
        private String Header_Key;
        private String Message_Status;
        private String Message_Text;
    }

    public static boolean success(RoSyncSrmResp resp) {
        if (Objects.isNull(resp)) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody())) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody().get(0).getHeader())) {
            return false;
        } else {
            return "S".equals(resp.getMessageBody().get(0).getHeader().getMessage_Status());
        }
    }

    public String getErrorMsg(){
        List<ClassMessageBody> messageBody = this.getMessageBody();
        if (CollUtil.isEmpty(messageBody)||Objects.isNull(messageBody.get(0).getHeader())){
            return StrUtil.EMPTY;
        }
        return messageBody.get(0).getHeader().getMessage_Text();
    }

    public static RoSyncSrmResp failedResp(String message) {
        RoSyncSrmResp resp = new RoSyncSrmResp();
        ArrayList<ClassMessageBody> classMessageBodies = new ArrayList<>();
        classMessageBodies.add(new ClassMessageBody());
        resp.setMessageBody(classMessageBodies);
        resp.getMessageBody().get(0).setHeader(new ClassMessageBodyHeader());
        resp.getMessageBody().get(0).getHeader().setMessage_Status("error");
        resp.getMessageBody().get(0).getHeader().setMessage_Text(message);
        return resp;
    }

}
