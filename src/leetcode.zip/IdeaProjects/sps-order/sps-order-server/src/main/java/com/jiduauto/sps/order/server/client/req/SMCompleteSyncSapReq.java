package com.jiduauto.sps.order.server.client.req;

import cn.hutool.core.date.LocalDateTimeUtil;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.google.common.collect.Lists;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

/**
 * @author panjian
 */
@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class SMCompleteSyncSapReq {

    private final static DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern(BaseConstants.DatePattern.DATETIME);
    private final static DateTimeFormatter NONE_DATE_FORMATTER = DateTimeFormatter.ofPattern(BaseConstants.DatePattern.NONE_DATE);
    private final static DateTimeFormatter NONE_TIME_FORMATTER = DateTimeFormatter.ofPattern(BaseConstants.DatePattern.NONE_TIME);

    private ClassMessageHeader MessageHeader;
    private List<ClassMessageBody> MessageBody;


    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageHeader {
        private String Sender;
        private Long SerialNum;
        private String InterfaceID;
        private String SendDate;
        private String SendTime;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBody {
        private List<ClassMessageBodyHeader> Header;
    }


    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyHeader {
        private String Receiver;

        //唯一随机码
        private String Header_Key;
        //业务单据号：商城订单号
        private String RequestNo;
        //签收日期
        private String budat;
    }


    public static SMCompleteSyncSapReq newInstance() {
        SMCompleteSyncSapReq stockPutOutSyncReq = new SMCompleteSyncSapReq();
        ClassMessageHeader classMessageHeader = new ClassMessageHeader();
        stockPutOutSyncReq.setMessageHeader(classMessageHeader);
        ClassMessageBody messageBody = new ClassMessageBody();
        ClassMessageBodyHeader classMessageBodyHead = new ClassMessageBodyHeader();
        messageBody.setHeader(Lists.newArrayList(classMessageBodyHead));
        stockPutOutSyncReq.setMessageBody(Lists.newArrayList(messageBody));
        stockPutOutSyncReq.messageHeader();
        return stockPutOutSyncReq;
    }

    public SMCompleteSyncSapReq messageHeader() {
        LocalDateTime now = LocalDateTime.now();
        MessageHeader.Sender = "TMS";
        MessageHeader.InterfaceID = "FI_006";
        MessageHeader.SendDate = now.format(NONE_DATE_FORMATTER);
        MessageHeader.SendTime = now.format(NONE_TIME_FORMATTER);
        MessageHeader.SerialNum = null;
        return this;
    }

    public void setBodyHead(WarehouseDistributeOrderPo po) {
        MessageBody.get(0).Header.get(0).Receiver = "SAP";
        MessageBody.get(0).Header.get(0).Header_Key = po.getBusinessBillNo();
        MessageBody.get(0).Header.get(0).RequestNo = po.getBusinessBillNo();
        MessageBody.get(0).Header.get(0).budat = LocalDateTime.now().format(NONE_DATE_FORMATTER);
    }

    public static void main(String[] args) {

        long curTime = new Date().getTime();
        System.out.println( LocalDateTimeUtil.of(curTime).format(NONE_DATE_FORMATTER));
    }
}
