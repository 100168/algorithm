package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.dto.SaleOrderOperateLogDto;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderOperateLogPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface SaleOrderOperateLogConvertor {

    /**
     * toDto
     * @param saleOrderOperateLogPo
     * @return dto*/
    @Mapping(target = "newValue", expression = "java(com.jiduauto.sps.sdk.enums.SaleOrderOperateLogStatusEnum.getDesc(saleOrderOperateLogPo.getNewValue()))")
    SaleOrderOperateLogDto toDto(SaleOrderOperateLogPo saleOrderOperateLogPo);
    /**
     * toDto
     * @param saleOrderOperateLogPoList
     * @return dto*/
    List<SaleOrderOperateLogDto> toDtoList(List<SaleOrderOperateLogPo> saleOrderOperateLogPoList);



}
