package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PurchaseOrderOccupyDetailDto {

    /**
     * 发货仓库
     */
    private String deliverWarehouseCode;

    /**
     * 运输建议
     */
    private String transferAdvice;

    /**
     * 售后件号
     */
    private String salePartNum;

    /**
     * 数量
     */
    private BigDecimal quantity;
}
