package com.jiduauto.sps.order.server.controller;


import com.alibaba.excel.EasyExcel;
import com.jiduauto.sps.order.server.annotation.IdempotentCheck;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderDto;
import com.jiduauto.sps.order.server.pojo.fileexport.BackOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderPageSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.ControlTransferReq;
import com.jiduauto.sps.order.server.service.IBackOrderService;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.BackOrderPo;
import com.jiduauto.sps.sdk.pojo.req.BackOrderBatchCancelReq;
import com.jiduauto.sps.sdk.pojo.req.IdBatchReq;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.ExcelUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * 缺件订单 前端控制器
 *
 * @author generate
 * @since 2023-04-12
 */
@RestController
@RequestMapping("/spsInternal/bo")
public class SpsInternalBOController {

    @Resource
    private IBackOrderService backOrderService;

    @Value("${MAX_SIZE_10000:10000}")
    private Integer maxSize;


    /**
     * 缺件订单条件查询
     * @param pageParam
     * @return
     */
    @PostMapping("pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<BackOrderDto>> pageSearch(@RequestBody @Valid BasePageParam<BackOrderPageSearchReq> pageParam) {
        return BaseResult.OK(backOrderService.pageSearch(pageParam));
    }

    /**
     * 批量更新到货时间
     * @param backOrderPos
     * @return
     */
    @IdempotentCheck
    @PostMapping("/updateByBoNo")
    public BaseResult<String> updateByBoNo(@RequestBody List<BackOrderPo> backOrderPos) {
        return backOrderService.updateByBoNo(backOrderPos);
    }


    /**
     * 缺件订单取消审核
     */
    @PostMapping("cancelApproval")
    public BaseResult<String> cancelApproval(@RequestParam("backOrderNo") String backOrderNo) {
        backOrderService.cancelApproval(backOrderNo);
        return BaseResult.OK();
    }

    /**
     * 缺件订单批量取消审核
     */
    @PostMapping("batchCancelApproval")
    public BaseResult<String> batchCancelApproval(@RequestBody @Valid BackOrderBatchCancelReq req) {
        backOrderService.batchCancelApproval(req);
        return BaseResult.OK();
    }

    /**
     * 手工转单
     *
     * @param idReq
     * @return
     */
    @PostMapping("/transferOrder")
    public BaseResult<String> transferOrder(@RequestBody @Valid IdReq idReq) {
        return backOrderService.manualTransferOrder(idReq.getId(), UserUtil.getUserName());
    }

    /**
     * 批量手工转单
     * idList 传入 bo 主键
     */
    @PostMapping("/batchTransferOrder")
    public BaseResult<String> transferOrder(@RequestBody @Valid IdBatchReq idBatchReq) {
        return backOrderService.manualBatchTransferOrder(idBatchReq);
    }

    /**
     * 缺件订单批量取消审核-驳回
     */
    @PostMapping("batchCancelApprovalRejected")
    public BaseResult<String> batchCancelApprovalRejected(@RequestBody @Valid BackOrderBatchCancelReq req) {
        backOrderService.batchCancelApprovalRejected(req);
        return BaseResult.OK();
    }

    /**
     * bo 管控件转单
     */
    @PostMapping("/controlTransfer")
    public BaseResult<String> controlTransfer(@RequestBody @Valid ControlTransferReq idReq) {
        return backOrderService.controlTransfer(idReq);
    }

    /**
     * 缺件订单导出接口（导出字段为页面可查看的字段）
     *
     * @author dong.li
     * @date 4/14/23 11:25 AM
     */
    @RequestMapping("export")
    public void export(HttpServletResponse response, @RequestBody @Valid BasePageParam<BackOrderPageSearchReq> pageParam) {
        try {
            // 导出最大返回前1000条
            pageParam.setPage(BaseConstants.ImportExport.PAGE_START_AT);
            pageParam.setSize(maxSize);
            ExcelUtils.exportXlsxResponse(response, "缺件订单");
            EasyExcel.write(response.getOutputStream(), BackOrderExportDto.class).sheet("缺件订单").doWrite(backOrderService.getExportDtoList(pageParam));
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }
}
