package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.dit.outbox.OutboxMessageService;
import com.jiduauto.dit.outbox.pojo.HandleResult;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * 定时任务 手动执行
 */
@RestController
@RequestMapping("/spsInternal/outbox")
@Slf4j
public class InternalOutboxController {


    @Resource
    private OutboxMessageService outboxMessageService;

    @PostMapping("/handlerMessage")
    @ResponseBody
    public BaseResult handlerMessage(@RequestBody IdReq idReq){
        HandleResult handleResult =  outboxMessageService.doHandleMessageById(idReq.getId());
        return BaseResult.packageObject(null,handleResult.getResultCode(), handleResult.getResultMsg());
    }

    @PostMapping("/listMessage")
    @ResponseBody
    public BaseResult<List<OutboxMessage>> listMessage(){
        return BaseResult.OK(outboxMessageService.listMessage());
    }
}
