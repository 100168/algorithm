package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountDto;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountPo;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreDiscountListReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountPageReq;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;

/**
 * <p>
 * 门店折扣表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
public interface StoreDiscountMapper extends BaseMapper<StoreDiscountPo> {
    IPage<StoreDiscountDto> pageSearch(Page<StoreDiscountDto> page, @Param("req") StoreDiscountPageReq req);

    List<StoreDiscountDto> listEffectiveDiscount(@Param("req") InternalStoreDiscountListReq req, @Param("queryTime") LocalDateTime queryTime);
}
