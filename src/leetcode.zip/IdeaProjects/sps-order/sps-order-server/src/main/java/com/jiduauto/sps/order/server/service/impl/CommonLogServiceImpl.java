package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.enums.LogKey;
import com.jiduauto.sps.order.server.enums.StoreTransferOrderDetailModifyColum;
import com.jiduauto.sps.order.server.enums.StoreTransferOrderModifyColum;
import com.jiduauto.sps.order.server.mapper.CommonLogMapper;
import com.jiduauto.sps.order.server.service.ICommonLogService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.enums.LogType;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.CommonLogDto;
import com.jiduauto.sps.sdk.pojo.po.CommonLogPo;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.req.CommonLogReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 通用日志记录 服务实现类
 * </p>
 */
@Service
public class CommonLogServiceImpl extends ServiceImpl<CommonLogMapper, CommonLogPo> implements ICommonLogService {
    @Resource
    private BaseDataQuery baseDataQuery;
    @Resource
    private SpsClient spsClient;
    @Override
    public void saveStatusLog(String newStatus,
                              String no,
                              String bizType,
                              String logKey,
                              String user,
                              String column,
                              String remark
    ) {
        saveStatusLog(newStatus, "", no, bizType, logKey, user, column, remark);
    }

    /**
     * 通用记录状态变更方法
     */
    @Override
    public void saveStatusLog(String newStatus,
                              String actionDesc,
                              String no,
                              String bizType,
                              String logKey,
                              String user,
                              String column,
                              String remark) {
        CommonLogPo po = new CommonLogPo();
        po.setNewValue(newStatus);
        po.setActionDesc(actionDesc);
        po.setModifyColumn(column);
        po.setOrderNo(no);
        po.setLogKey(logKey);
        po.setLogType(LogType.STATUS.getType());
        po.setBizType(bizType);
        po.setCreateUser(user);
        po.setRemark(remark);
        save(po);
    }

    /**
     * 调拨单日志分页查询
     *
     * @param req
     */
    @Override
    public BasePageData<CommonLogDto> pageSearchStoreTransferLog(BasePageParam<CommonLogReq> req) {
        if (Objects.isNull(req.getParam().getLogType())){
            throw new BizException(GlobalCodeEnum.GL_FAIL_9998,"日志类型参数不能为空");
        }
        IPage<CommonLogPo> page = page(new Page<>(req.getPage(), req.getSize()),
                Wrappers.lambdaQuery(CommonLogPo.class)
                        .eq(CommonLogPo::getBizType, req.getParam().getBizType())
                        .eq(CommonLogPo::getLogType, req.getParam().getLogType())
                        .eq(CommonLogPo::getOrderNo, req.getParam().getOrderNo())
                        .in(CommonLogPo::getLogKey, LogKey.getStoreTransferOrderLog())
                        .orderByDesc(CommonLogPo::getId)
        );
        List<CommonLogPo> records = page.getRecords();
        BasePageData<CommonLogDto> pageData = new BasePageData<>(page);
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(req.getParam().getBizType());
        baseDataReq.setDictCodes(Collections.singletonList(DictEnum.STO_STATUS.getDictCode()));
        BaseResult<BaseDataResp> resp = spsClient.searchBaseData(baseDataReq);
        Map<String, Map<String, String>> map = baseDataQuery.getDictItemName(
                resp.getData().getDictItemClientDtos());
        pageData.setRecords(records.stream().map(item -> {
            CommonLogDto dto = BeanCopierUtil.copy(item, CommonLogDto.class);
            String byDesc = StoreTransferOrderModifyColum.getByDesc(item.getModifyColumn());
            if (StoreTransferOrderModifyColum.orderStatus.getValue().equals(item.getModifyColumn())) {
                if (StringUtils.isNotBlank(dto.getNewValue())) {
                    dto.setNewValue(map.getOrDefault(DictEnum.STO_STATUS.getDictCode(), new HashMap<>())
                            .getOrDefault(item.getNewValue(), item.getNewValue()));
                }
                if (StringUtils.isNotBlank(dto.getOldValue())) {
                    dto.setOldValue(map.getOrDefault(DictEnum.STO_STATUS.getDictCode(), new HashMap<>())
                            .getOrDefault(item.getOldValue(), item.getOldValue()));
                }
            }
            dto.setModifyColumn(StringUtils.defaultIfNull(
                    byDesc == null ? StoreTransferOrderDetailModifyColum.getByDesc(
                            item.getModifyColumn()) : byDesc, item.getModifyColumn()));
            return dto;
        }).collect(Collectors.toList()));
        return pageData;
    }
}
