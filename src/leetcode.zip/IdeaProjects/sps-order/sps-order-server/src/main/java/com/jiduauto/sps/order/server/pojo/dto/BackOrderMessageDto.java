package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class BackOrderMessageDto {

    /**
     * 缺件订单id
     */
    private Long id;

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 缺件单号
     */
    private String backOrderNo;

    /**
     * 缺件订单类型
     */
    private String backOrderType;

    /**
     * 采购订单号
     */
    private String purchaseOrderNo;

    /**
     * 售后件号
     */
    private String salePartNum;

    /**
     * 缺件总数
     */
    private BigDecimal backQty;

    /**
     * 剩余缺件总数
     */
    private BigDecimal restBackQty;

    /**
     * 缺件订单状态
     */
    private String backOrderStatus;

    /**
     * 门店编码
     */
    private String storeCode;
}
