package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.order.server.pojo.po.IdempotentLogPo;

/**
 * <p>
 * 接口幂等记录表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-11-16
 */
public interface IdempotentLogMapper extends BaseMapper<IdempotentLogPo> {

}
