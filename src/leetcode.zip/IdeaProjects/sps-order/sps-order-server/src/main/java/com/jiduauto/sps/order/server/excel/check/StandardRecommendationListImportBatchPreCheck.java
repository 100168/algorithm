package com.jiduauto.sps.order.server.excel.check;

import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListImportReq;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.excel.BatchPreCheck;
import com.jiduauto.sps.sdk.excel.ExtendExportDto;
import com.jiduauto.sps.sdk.handler.BizTypeThreadHolder;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.utils.NumberUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

@Component
public class StandardRecommendationListImportBatchPreCheck implements BatchPreCheck<StandardRecommendationListImportReq> {

    @Resource
    private BaseDataQuery baseDataQuery;

    @Override
    public void invoke(List<ExtendExportDto<StandardRecommendationListImportReq>> extendExportDtos) {
        String bizType = BizTypeThreadHolder.getBizType();
        List<String> salePartNums = extendExportDtos.stream().map(ExtendExportDto::getT).map(StandardRecommendationListImportReq::getMaterialCode).filter(StringUtils::isNotEmpty).distinct().collect(Collectors.toList());
        List<String> storeCodes = extendExportDtos.stream().map(ExtendExportDto::getT).map(StandardRecommendationListImportReq::getStoreCode).distinct().collect(toList());
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(bizType, storeCodes, false);
        Map<String, MaterialPo> materialMap = baseDataQuery.mapMaterialPo(bizType, salePartNums, false);

        for (ExtendExportDto<StandardRecommendationListImportReq> extendExportDto : extendExportDtos) {
            StandardRecommendationListImportReq importReq = extendExportDto.getT();
            StringBuilder errors = new StringBuilder();

            if (StrUtil.isBlank(importReq.getStoreCode())) {
                errors.append("门店code为空;");
            } else if (!storePoMap.containsKey(importReq.getStoreCode())) {
                errors.append("门店code不存在;");
            }

            if (StrUtil.isBlank(importReq.getMaterialCode())) {
                errors.append("售后件号为空;");
            } else if (!materialMap.containsKey(importReq.getMaterialCode())) {
                errors.append("售后件号不存在;");
            }

            if (StrUtil.isNotBlank(importReq.getMaterialCode())
                    && materialMap.containsKey(importReq.getMaterialCode())
                    && Objects.equals(materialMap.get(importReq.getMaterialCode()).getIsCustom(), "Y")
            ) {
                errors.append("售后件号不允许为定制件;");
            }

            if (!NumberUtil.isPositiveInteger(importReq.getMinQty())) {
                errors.append("min不正确;");
            }
            if (!NumberUtil.isPositiveInteger(importReq.getMaxQty())) {
                errors.append("max不正确;");
            }
            if ((NumberUtil.isPositiveInteger(importReq.getMinQty()) && NumberUtil.isPositiveInteger(importReq.getMaxQty())) &&
                    Integer.parseInt(importReq.getMinQty()) >= Integer.parseInt(importReq.getMaxQty())) {
                errors.append("min不能大于等于max;");
            }
            extendExportDto.setCheckResult(errors.toString());
        }
    }
}
