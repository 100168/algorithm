package com.jiduauto.sps.order.server.mq.consumer;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.pojo.dto.StockPutOutResultMessage;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.StockOperationType;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;

@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_ORDER_PUT_OUT,
        topic = BaseConstants.RocketMqTopic.STOCK_PUT_OUT,
        consumeThreadMax = 10)
public class StockPutOutConsumer implements RocketMQListener<MessageExt> {

    @Autowired
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @Resource
    private ISaleOrderService saleOrderService;


    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("####出库消息体:" + body);
        StockPutOutResultMessage resultMessage = JSON.parseObject(body, StockPutOutResultMessage.class);

        //销售订单出库同步sap更新sap单号
        if (StockOperationType.SP20.getOperationType().equals(resultMessage.getBusinessType())) {
            saleOrderService
                    .update(Wrappers.<SaleOrderPo>lambdaUpdate()
                            .set(SaleOrderPo::getSapOrderNo, resultMessage.getSapNoForSo())
                            .eq(SaleOrderPo::getSaleOrderNo, resultMessage.getTradeNo()));
        }
    }


}
