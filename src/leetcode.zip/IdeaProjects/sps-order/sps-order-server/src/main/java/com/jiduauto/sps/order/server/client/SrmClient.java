package com.jiduauto.sps.order.server.client;

import com.jiduauto.sps.order.server.client.config.SrmFeignConfig;
import com.jiduauto.sps.order.server.client.req.RoSyncSrmReq;
import com.jiduauto.sps.order.server.client.resp.RoSyncSrmResp;
import com.jiduauto.sps.sdk.utils.StringUtils;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * SAP RESTAdapter 接口
 * @author panjian
 */

//@FeignClient(name = "srm", url = "${feign.url.srm}",configuration = SrmFeignConfig.class,fallbackFactory = SrmClient.SrmClientFallbackFactory.class)
public interface SrmClient {

    /**
     * 采购退货同步给srm
     * @param roSyncSrmReq 参数
     * @return PurchaseOrderSyncResp
     */
    @PostMapping("/invoke/sps/push/returnInfo")
    RoSyncSrmResp syncPurchaseOrder(@RequestBody RoSyncSrmReq roSyncSrmReq);
    @Slf4j
    @Component
    class SrmClientFallbackFactory implements FallbackFactory<SrmClient> {

        @Override
        public SrmClient create(Throwable cause) {
            return roSyncSrmReq -> {
                log.warn(String.format("SrmClient#syncPurchaseOrder error, param : %s", roSyncSrmReq), cause);
                return RoSyncSrmResp.failedResp(StringUtils.cutString(cause.toString(), 150));
            };
        }
    }
}
