package com.jiduauto.sps.order.server.pojo.dto;

import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.pojo.po.*;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 采购订单转单上下文
 */
@Data
@Builder
public class BackOrderTransferContextDto {

    private OperateEnum operateEnum;

    /**
     * 门店仓库配置列表
     */
    private List<StoreWarehouseConfigPo> storeWarehouseConfigs;

    /**
     * 零件主数据，key=salePartNum
     */
    private Map<String, MaterialPo> materialMap;

    /**
     * 采购订单
     */
    private PurchaseOrderPo purchaseOrder;

    /**
     * 缺件订单列表
     */
    private List<BackOrderPo> backOrderPos;

    /**
     * 占用明细列表
     */
    private List<BackOrderOccupyDetailDto> occupyDetails;

    /**
     * 生成的销售订单列表
     */
    private List<SaleOrderPo> saleOrders;

    /**
     * 生成的销售订单明细列表
     */
    private List<SaleOrderDetailPo> saleOrderDetails;

    /**
     * 生成的缺件订单和销售订单的关联关系
     */
    private List<BackSaleRelationPo> backSaleRelationPos;
    /**
     * 管控件转单的 bo 当前剩余缺件数量
     */
    private BigDecimal restBackQty;
}
