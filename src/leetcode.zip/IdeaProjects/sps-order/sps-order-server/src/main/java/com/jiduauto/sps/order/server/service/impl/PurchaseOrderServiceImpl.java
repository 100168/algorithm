package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.convertor.PurchaseOrderConvertor;
import com.jiduauto.sps.order.server.handler.purchaseorder.PurchaseOrderOccupy;
import com.jiduauto.sps.order.server.mapper.PurchaseOrderDetailMapper;
import com.jiduauto.sps.order.server.mapper.PurchaseOrderMapper;
import com.jiduauto.sps.order.server.mq.RocketMqTxProducer;
import com.jiduauto.sps.order.server.pojo.PurchaseOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.context.ControlTransferContext;
import com.jiduauto.sps.order.server.pojo.dto.*;
import com.jiduauto.sps.order.server.pojo.fileexport.PurchaseOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.ControlTransferReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalPoDeleteReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalPurchaseOrderAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderSearchReq;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.CreatePrOrderReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import com.jiduauto.sps.sdk.utils.StringUtils;
import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.enums.PurchaseOrderAttrEnum.AUTHORIZED;
import static com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum.*;


/**
 * <p>
 * 采购订单 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Service
public class PurchaseOrderServiceImpl extends ServiceImpl<PurchaseOrderMapper, PurchaseOrderPo> implements
        IPurchaseOrderService {

    @Resource
    private PurchaseOrderMapper purchaseOrderMapper;

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @Resource
    private RocketMqTxProducer rocketMqTxProducer;

    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;

    @Resource
    private IPurchaseOrderOperateLogService purchaseOrderOperateLogService;

    @Resource
    private Map<String, PurchaseOrderOccupy> purchaseOrderOccupyMap;

    @Resource
    private PurchaseOrderDetailMapper purchaseOrderDetailMapper;

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private IBackOrderService backOrderService;

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private SpsClient spsClient;

    @Resource
    private WebhookUtil webhookUtil;

    @Resource
    private RocketMQTemplate rocketMQTemplate;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private PurchaseOrderConvertor purchaseOrderConvertor;

    @Resource
    private ISaleOrderOperateLogService saleOrderOperateLogService;

    @Resource
    private IPurchaseOrderPartTransferOperateService purchaseOrderPartTransferOperateService;

    @Value("${MAX_SIZE_10000:10000}")
    private Integer maxSize;

    /**
     *
     **/
    @Override
    public BasePageData<PurchaseOrderDto> pageSearch(BasePageParam<PurchaseOrderSearchReq> pageParam) {
        Page<PurchaseOrderPo> page = new Page<>(pageParam.getPage(), pageParam.getSize());
        PurchaseOrderSearchReq param = pageParam.getParam();
        IPage<PurchaseOrderPo> pageSearchList = purchaseOrderMapper.pageSearch(page, param);
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(param.getBizType(), pageSearchList.getRecords().stream()
                .map(PurchaseOrderPo::getStoreCode).distinct().collect(Collectors.toList()));
        Map<String, WarehousePo> warehousePoMap = baseDataQuery.mapWarehousePo(BizTypeEnum.getNewBizType(param.getBizType()), pageSearchList.getRecords().stream()
                .map(PurchaseOrderPo::getReceiveWarehouseCode).distinct().collect(Collectors.toList()));
        Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());
        BasePageData<PurchaseOrderDto> res = new BasePageData<>(pageSearchList);
        res.setRecords(pageSearchList.getRecords().stream().map(e -> {
            StorePo storePo = storePoMap.getOrDefault(e.getStoreCode(), new StorePo());
            WarehousePo warehousePo = warehousePoMap.getOrDefault(e.getReceiveWarehouseCode(), new WarehousePo());
            PurchaseOrderDto purchaseOrderDto = purchaseOrderConvertor.poToDto(e);
            String provinceName = codeAndNameMap.getOrDefault(e.getReceiverProvince(), "");
            String cityName = codeAndNameMap.getOrDefault(e.getReceiverCity(), "");
            String districtName = codeAndNameMap.getOrDefault(e.getReceiverDistrict(), "");
            purchaseOrderDto.setStoreName(storePo.getStoreName());
            purchaseOrderDto.setReceiveWarehouseName(warehousePo.getName());
            purchaseOrderDto.setTurnControlStatusName(POTurnControlStatus.getNameByCode(e.getTurnControlStatus()));
            purchaseOrderDto.setPurchaseOrderStatus(PurchaseOrderStatusEnum.getDesc(e.getPurchaseOrderStatus()));
            purchaseOrderDto.setPurchaseOrderStatusCode(e.getPurchaseOrderStatus());
            purchaseOrderDto.setTurnPurchaseOrderStatusName(TurnPurchaseOrderStatusEnum.getDesc(e.getTurnPurchaseOrderStatus()));
            purchaseOrderDto.setPurchaseOrderAttr(PurchaseOrderAttrEnum.getName(e.getPurchaseOrderAttr()));
            purchaseOrderDto.setReceiverAddress(provinceName.concat(cityName)
                    .concat(districtName).concat(e.getReceiverAddress()));
            return purchaseOrderDto;
        }).collect(Collectors.toList()));
        return res;
    }


    /**
     * 根据采购订单明细的收货,取消数量计算是否更新采购订单状态
     * 对于涉及 SO, BO 收货数量变更 & 取消的地方,都需要调用该方法
     * @see <a href="https://wiki.jiduauto.com/pages/viewpage.action?pageId=702735548">需求文档</>
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStateByReceiveQtyAndCancelQty(String poNo, String bizType) {
        //1. 获取采购订单详情
        PurchaseOrderSearchReq purchaseOrderSearchReq = new PurchaseOrderSearchReq();
        purchaseOrderSearchReq.setBizType(bizType);
        purchaseOrderSearchReq.setPurchaseOrderNos(Lists.newArrayList(poNo));
        List<PurchaseOrderDetailDto> detailDtoList = purchaseOrderDetailMapper.batchQuery(purchaseOrderSearchReq);

        if (CollUtil.isEmpty(detailDtoList)) {
            return;
        }

        //2. 获取采购订单判断状态是否更新
        PurchaseOrderPo po = getOne(Wrappers.<PurchaseOrderPo>lambdaQuery()
                .eq(PurchaseOrderPo::getBizType, bizType)
                .eq(PurchaseOrderPo::getPurchaseOrderNo, poNo)
        );

        if (Objects.isNull(po)) {
            return;
        }

        PurchaseOrderStatusEnum poState = PurchaseOrderStatusEnum.getByCode(po.getPurchaseOrderStatus());

        if (poState != PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL) {
            return;
        }

        PurchaseOrderStatusEnum updateEnum = calcState(detailDtoList, poState);

        //还是处理中状态
        if (updateEnum == PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL) {
            return;
        }

        //3. 更新采购订单状态
        update(Wrappers.<PurchaseOrderPo>lambdaUpdate().eq(PurchaseOrderPo::getId, po.getId())
                .set(PurchaseOrderPo::getPurchaseOrderStatus, updateEnum.getCode())
        );

        //4. 日志操作记录
        purchaseOrderOperateLogService.saveStatusChangeLog(PurchaseOrderStatusChangeDto.builder()
                .operateEnum(OperateEnum.END)
                .purchaseOrderPo(po)
                .newOrderStatus(updateEnum)
                .operateUser(StrUtil.isBlank(UserUtil.getUserName()) ? OperateUserEnum.SPS.getName() : UserUtil.getUserName())
                .build());
    }


    /**
     * 根据 采购订单明 收货,取消数量计算对应状态
     *
     * @param list 对应的采购订单明细
     * @return 状态
     */
    private PurchaseOrderStatusEnum calcState(List<PurchaseOrderDetailDto> list, PurchaseOrderStatusEnum poState) {
        if (PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL != poState) {
            return poState;
        }

        //全部收货 所有订单明细的收货数量=数量
        long receiveCount = list.stream().filter(o -> {
            BigDecimal rQty = new BigDecimal(o.getReceiveQty());
            BigDecimal qty = new BigDecimal(o.getQty());
            return rQty.compareTo(BigDecimal.ZERO) > 0 && qty.compareTo(rQty) == 0;
        }).count();

        if (receiveCount == list.size()) {
            return PurchaseOrderStatusEnum.COMPLETED;
        }

        //全部取消
        long cancelCount = list.stream().filter(o -> {
            BigDecimal cQty = new BigDecimal(o.getCancelQty());
            BigDecimal qty = new BigDecimal(o.getQty());
            return cQty.compareTo(BigDecimal.ZERO) > 0 && qty.compareTo(cQty) == 0;
        }).count();

        if (cancelCount == list.size()) {
            return PurchaseOrderStatusEnum.CANCELED;
        }

        //有取消
        long existCancel = list.stream().filter(o -> {
            BigDecimal rQty = new BigDecimal(o.getReceiveQty());
            BigDecimal cQty = new BigDecimal(o.getCancelQty());
            BigDecimal qty = new BigDecimal(o.getQty());
            return qty.compareTo(rQty.add(cQty)) == 0;
        }).count();

        if (existCancel == list.size()) {
            return PurchaseOrderStatusEnum.COMPLETED;
        }

        return PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void savePoAndDetail(PurchaseOrderPo orderPo, List<PurchaseOrderDetailPo> detailPos) {
        save(orderPo);
        purchaseOrderDetailService.saveBatch(detailPos);
    }


    public void check(InternalPurchaseOrderAddReq request) {
        //非空判断
        checkVinNotEmpty(request);
        //校验门店仓库配置
        checkWarehouseConfig(request);
        //省市区校验
        checkLocation(request);
        //校验收货仓库
        checkReceiveWarehouse(request);
        //校验售后件
        checkSalePartNum(request);
    }

    private void checkVinNotEmpty(InternalPurchaseOrderAddReq request) {
        if (PurchaseOrderTypeEnum.VOR.getValue().equals(request.getPurchaseOrderType())) {
            if (StringUtils.isEmpty(request.getVin())) {
                throw new BizException(SpsResponseCodeEnum.VIN_CAN_NOT_BE_EMPTY);
            }
        }
    }

    @SuppressWarnings("OptionalGetWithoutIsPresent")
    private void checkSalePartNum(InternalPurchaseOrderAddReq request) {
        List<InternalPurchaseOrderAddReq.Item> itemList = request.getItemList();
        List<String> salePartNums = itemList.stream().map(InternalPurchaseOrderAddReq.Item::getSalePartNum).distinct().collect(Collectors.toList());
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(request.getBizType(), salePartNums);
        StorePo storePo = baseDataQuery.getStorePo(request.getBizType(), request.getStoreCode()).get();
        HashSet<String> existCodes = new HashSet<>();
        for (InternalPurchaseOrderAddReq.Item item : itemList) {
            if (existCodes.contains(item.getSalePartNum())) {
                throw new BizException(item.getSalePartNum() + SpsResponseCodeEnum.DUP_SALE_PART_NUM.getDesc());
            }
            MaterialPo materialPo = materialPoMap.get(item.getSalePartNum());
            if (materialPo == null) {
                throw new BizException(item.getSalePartNum() + SpsResponseCodeEnum.SALE_PART_NUM_NOT_EXIST.getDesc());
            }
            if (isNotSaleable(storePo.getStoreType().equals(AUTHORIZED.getCode()), materialPo)) {
                throw new BizException(item.getSalePartNum() + SpsResponseCodeEnum.MATERIAL_NOT_SALEABLE.getDesc());
            }
            if (isNotMulti(item.getQty(), materialPo)) {
                throw new BizException(item.getSalePartNum() + SpsResponseCodeEnum.QTY_NOT_MIN_PACKAGE_MUL.getDesc());
            }
            // 为定制订单时校验
            if (request.getPurchaseOrderType().equals(PurchaseOrderTypeEnum.CO.getValue())) {
                if (itemList.size() > 1) {
                    throw new BizException(CO_ITEM_SIZE_ERROR.getDesc());
                }

                // 零件物料必须不是DFS
                if (StringUtils.isNotBlank(materialPo.getIsDfs())
                        && materialPo.getIsDfs().equals(YNEnums.Y.getCode())) {
                    throw new BizException(item.getSalePartNum() + CUSTOM_CAN_NOT_IS_DFS.getDesc());
                }
                // VIN必须有值
                if (StringUtils.isBlank(item.getVin())) {
                    throw new BizException(SpsResponseCodeEnum.VIN_CAN_NOT_BE_EMPTY);
                }
                // 零件物料必须是定制件
                if (!YNEnums.Y.getCode().equals(materialPo.getIsCustom())) {
                    throw new BizException(item.getSalePartNum() + CUSTOM_CAN_NOT_IS_DFS.getDesc());
                }
                // 零件物料明细数量为1
                if (item.getQty().compareTo(BigDecimal.valueOf(1L)) != 0) {
                    throw new BizException(item.getSalePartNum() + QTY_IS_ONE.getDesc());
                }

            }
            existCodes.add(item.getSalePartNum());
        }
    }

    private void checkWarehouseConfig(InternalPurchaseOrderAddReq request) {
        List<StoreWarehouseConfigPo> storeWarehouseConfigPos = baseDataQuery.allStoreWarehouseConfig(request.getBizType(), request.getStoreCode());

        if (storeWarehouseConfigPos.isEmpty()) {
            throw new BizException(SpsResponseCodeEnum.STORE_WAREHOUSE_CONFIG_NOT_EXIST);
        }
    }

    private void checkReceiveWarehouse(InternalPurchaseOrderAddReq request) {
        baseDataQuery.getWarehousePo(BizTypeEnum.getNewBizType(request.getBizType()),
                request.getReceiveWarehouseCode()).orElseThrow(() -> new BizException(SpsResponseCodeEnum.WAREHOUSE_NOT_EXIST));
    }

    private void checkLocation(InternalPurchaseOrderAddReq request) {
        Map<String, String> localtionMap = baseDataQuery.getCodeAndNameMap(
               DictEnum.MapLocationDistrict.getDictCode());
        if (!(localtionMap.containsKey(request.getReceiverProvince()) && localtionMap.containsKey(request.getReceiverCity()))) {
            throw new BizException(SpsResponseCodeEnum.LOCATION_ERROR);
        }

        if (StrUtil.isNotBlank(request.getReceiverDistrict()) && !localtionMap.containsKey(request.getReceiverDistrict())) {
            throw new BizException(SpsResponseCodeEnum.LOCATION_ERROR);
        }
    }

    /**
     * 判断物料数量是否是物料最小包装的整数倍
     *
     * @param qty 物料数量
     */
    public static boolean isNotMulti(BigDecimal qty, MaterialPo materialPo) {
        return StrUtil.isNotEmpty(materialPo.getMinPackage())
                && BigDecimal.ZERO.compareTo(qty
                .remainder(new BigDecimal(materialPo.getMinPackage()))) != 0;
    }


    /**
     * 判断订单物料数量是否存在和可销售
     *
     * @param isAuth
     * @param materialPo
     * @return
     */

    private boolean isNotSaleable(boolean isAuth, MaterialPo materialPo) {

        return
                Objects.equals(materialPo.getIsSale(), YesNoEnums.NO.getValue())
                        || (isAuth && Objects.equals(materialPo.getBanPenOrder(), YesNoEnums.NO.getValue()));
    }

    @Override
    public void transferOrder(OperateEnum operateEnum, Long purchaseOrderId) {
        String redisKey = String.format(BaseConstants.RedisKey.PURCHASE_ORDER_TRANSFER_KEY, purchaseOrderId);
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            PurchaseOrderPo purchaseOrderPo = purchaseOrderMapper.selectById(purchaseOrderId);
            if (Objects.isNull(purchaseOrderPo)) {
                throw new BizException(RECORD_NOT_EXIST);
            }
            if (!PurchaseOrderStatusEnum.canTransfer(purchaseOrderPo.getPurchaseOrderStatus())) {
                return;
            }

            List<StoreWarehouseConfigPo> storeWarehouseConfigPos = baseDataQuery.allStoreWarehouseConfig(purchaseOrderPo.getBizType(),
                    purchaseOrderPo.getStoreCode());

            boolean result;
            if (CollectionUtils.isEmpty(storeWarehouseConfigPos)) {
                updateStatusAndSendMessage(PurchaseOrderStatusChangeDto.builder()
                        .purchaseOrderPo(purchaseOrderPo)
                        .newOrderStatus(PurchaseOrderStatusEnum.TRANSFER_FAILED)
                        .operateEnum(operateEnum)
                        .operateUser(getOperateUser(operateEnum))
                        .remark("未匹配到门店仓库配置")
                        .build());

                sendTransferOrderFailedNotice(purchaseOrderPo.getBizType(), purchaseOrderPo.getPurchaseOrderNo());
                throw new BizException("转单处理失败，未匹配到门店仓库配置");
            } else {
                PurchaseOrderTransferContextDto transferContextDto = initTransferContext(
                        PurchaseOrderTransferContextDto.builder()
                                .operateEnum(operateEnum)
                                .purchaseOrder(purchaseOrderPo)
                                .storeWarehouseConfigs(storeWarehouseConfigPos)
                                .build());

                result = updateStatusAndSendMessage(PurchaseOrderStatusChangeDto.builder()
                        .purchaseOrderPo(purchaseOrderPo)
                        .transferContextDto(transferContextDto)
                        .newOrderStatus(PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL)
                        .operateEnum(operateEnum)
                        .operateUser(getOperateUser(operateEnum))
                        .build());

                if (!result) {
                    sendTransferOrderFailedNotice(purchaseOrderPo.getBizType(), purchaseOrderPo.getPurchaseOrderNo());
                    throw new BizException("转单处理失败，请稍后再试");
                }
            }
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createPrOrder(CreatePrOrderReq req, PurchaseOrderPo purchaseOrderPo, OperateEnum operateEnum) {
        purchaseOrderMapper.update(null, Wrappers.lambdaUpdate(PurchaseOrderPo.class)
                .set(PurchaseOrderPo::getTurnPurchaseOrderStatus, TurnPurchaseOrderStatusEnum.PROCESSED.getCode())
                .set(BasePo::getRemark, StringUtils.EMPTY)
                .eq(PurchaseOrderPo::getId, purchaseOrderPo.getId()));

        purchaseOrderOperateLogService.saveStatusChangeLog(PurchaseOrderCoStatusChangeDto.builder()
                .operateEnum(operateEnum)
                .purchaseOrderPo(purchaseOrderPo)
                .newOrderStatus(TurnPurchaseOrderStatusEnum.PROCESSED)
                .operateUser(getOperateUser(operateEnum))
                .build());
        spsClient.createPurchaseApply(req).check();
    }

    @Override
    public void transferPurchaseApply(OperateEnum operateEnum, Long purchaseOrderId) {
        String redisKey = String.format(BaseConstants.RedisKey.CO_PURCHASE_ORDER_TRANSFER_KEY, purchaseOrderId);
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            PurchaseOrderPo purchaseOrderPo = purchaseOrderMapper.selectById(purchaseOrderId);
            if (Objects.isNull(purchaseOrderPo)) {
                throw new BizException(RECORD_NOT_EXIST);
            }
            if (!PurchaseOrderStatusEnum.canTransfer(purchaseOrderPo.getPurchaseOrderStatus())) {
                return;
            }

            List<PurchaseOrderDetailPo> detailPoList = purchaseOrderDetailService.list(Wrappers.<PurchaseOrderDetailPo>lambdaQuery()
                    .eq(PurchaseOrderDetailPo::getBizType, purchaseOrderPo.getBizType())
                    .eq(PurchaseOrderDetailPo::getPurchaseOrderNo, purchaseOrderPo.getPurchaseOrderNo())
            );

            if (CollUtil.isEmpty(detailPoList)) {
                throw new BizException(RECORD_NOT_EXIST);
            }

            try {
                CreatePrOrderReq req = new CreatePrOrderReq();
                req.setPurchaseOrderPo(purchaseOrderPo);
                req.setOperateEnumDesc(operateEnum.getDesc());
                req.setPoDetailList(detailPoList);
                req.setPrType(PRTypeEnum.CO.getCode());
                purchaseOrderService.createPrOrder(req, purchaseOrderPo, operateEnum);

            } catch (Exception e) {
                String remark = StringUtils.cutString(e.getMessage(), 500);

                purchaseOrderMapper.update(null, Wrappers.lambdaUpdate(PurchaseOrderPo.class)
                        .set(PurchaseOrderPo::getTurnPurchaseOrderStatus, TurnPurchaseOrderStatusEnum.TRANSFER_FAILED.getCode())
                        .set(PurchaseOrderPo::getRemark, StringUtils.defaultIfNull(remark))
                        .eq(PurchaseOrderPo::getId, purchaseOrderPo.getId()));

                purchaseOrderOperateLogService.saveStatusChangeLog(PurchaseOrderCoStatusChangeDto.builder()
                        .operateEnum(operateEnum)
                        .purchaseOrderPo(purchaseOrderPo)
                        .newOrderStatus(TurnPurchaseOrderStatusEnum.TRANSFER_FAILED)
                        .remark(remark)
                        .operateUser(getOperateUser(operateEnum))
                        .build());

                throw new BizException(remark);
            }
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public BaseResult<String> delete(InternalPoDeleteReq request) {
        PurchaseOrderPo orderPo = getOne(Wrappers.<PurchaseOrderPo>lambdaQuery()
                .eq(PurchaseOrderPo::getBizType, request.getBizType())
                .eq(PurchaseOrderPo::getPurchaseOrderNo, request.getPurchaseOrderNo()));
        if (orderPo == null) {
            return BaseResult.error(RECORD_NOT_EXIST.getDesc());
        }
        if (!PurchaseOrderStatusEnum.PENDING_REVIEW.getCode().equals(orderPo.getPurchaseOrderStatus())) {
            throw new BizException("只有待审核状态才能删除");
        }
        removeById(orderPo.getId());
        purchaseOrderDetailService.remove(Wrappers.<PurchaseOrderDetailPo>lambdaQuery()
                .eq(PurchaseOrderDetailPo::getBizType, request.getBizType())
                .eq(PurchaseOrderDetailPo::getPurchaseOrderNo, request.getPurchaseOrderNo()));
        purchaseOrderOperateLogService.remove(Wrappers.<PurchaseOrderOperateLogPo>lambdaQuery()
                .eq(PurchaseOrderOperateLogPo::getBizType, request.getBizType())
                .eq(PurchaseOrderOperateLogPo::getPurchaseOrderNo, request.getPurchaseOrderNo()));
        return BaseResult.OK();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void doTransferOrder(PurchaseOrderTransferContextDto contextDto) {
        if (CollectionUtils.isNotEmpty(contextDto.getDfsPurchaseOrderDetails())) {
            saleOrderService.builderDfsSaleOrderPo(contextDto);
        }

        PurchaseOrderOccupy strategy = purchaseOrderOccupyMap.get(PurchaseOrderOccupyEnum.getBeanNameByCode(contextDto.getPurchaseOrder().getPurchaseOrderType()));
        if (strategy == null) {
            throw new IllegalArgumentException("订单类型错误");
        }
        strategy.occupy(contextDto);

        if (CollectionUtils.isNotEmpty(contextDto.getOccupyDetails())) {
            saleOrderService.builderSaleOrderPos(contextDto);
        }
        if (CollectionUtils.isNotEmpty(contextDto.getOccupyFailedDetails())) {
            backOrderService.builderBackOrderPos(contextDto);
        }

        saleOrderService.batchInsertSaleOrder(contextDto);
        backOrderService.batchInsertBackOrder(contextDto);

        contextDto.getSaleOrders().forEach(so ->
                saleOrderOperateLogService.saveStatusChangeLog(
                        SaleOrderStatusChangeDto.builder()
                                .operateEnum(OperateEnum.AUTO_TRANSFER)
                                .saleOrderPo(so)
                                .newStatusEnum(SaleOrderStatusEnum.WAIT_ISSUED)
                                .operateUser(OperateUserEnum.SPS.getName())
                                .build()
                )
        );
    }

    @Override
    public void transferSuccessSendMessage(PurchaseOrderMessageDto purchaseOrderMessageDto) {
        String purchaseOrderNo = purchaseOrderMessageDto.getPurchaseOrderNo();
        List<SaleOrderPo> saleOrderPos = new ArrayList<>();
        List<BackOrderPo> backOrderPos = new ArrayList<>();
        if (purchaseOrderMessageDto.getIsControlTurn()) {
            //管控件转单
            PurchaseOrderPartTransferOperatePo po = purchaseOrderPartTransferOperateService.getById(purchaseOrderMessageDto.getPartTransferOperateId());
            //存在 so 或者 bo 有一个不存在的情况
            if (StrUtil.isNotBlank(po.getSaleOrderNo())) {
                saleOrderPos = saleOrderService.list(Wrappers.lambdaQuery(SaleOrderPo.class).eq(SaleOrderPo::getSaleOrderNo, po.getSaleOrderNo()));
            }
            if (StrUtil.isNotBlank(po.getBackOrderNo())) {
                backOrderPos = backOrderService.list(Wrappers.lambdaQuery(BackOrderPo.class).eq(BackOrderPo::getBackOrderNo, po.getBackOrderNo()));
            }
        } else {
            saleOrderPos = saleOrderService.listSaleOrderPo(purchaseOrderNo);
            backOrderPos = backOrderService.listBackOrderPo(purchaseOrderNo);
        }

        saleOrderPos.forEach(saleOrderPo -> {
            String saleOrderDestination = BaseConstants.RocketMqTopic.SALE_ORDER
                    .concat(":").concat(SaleOrderStatusEnum.getMsgTag(saleOrderPo.getSaleOrderStatus()));
            rocketMQTemplate.syncSend(saleOrderDestination, BeanCopierUtil.copy(saleOrderPo, SaleOrderMessageDto.class));
        });

        String backOrderDestination = BaseConstants.RocketMqTopic.BACK_ORDER.concat(":").concat(BackOrderStatusEnum.PENDING.getMsgTag());
        backOrderPos.forEach(backOrderPo ->
                rocketMQTemplate.syncSend(backOrderDestination, BeanCopierUtil.copy(backOrderPo, BackOrderMessageDto.class))
        );
    }

    @Override
    public List<PurchaseOrderExportDto> exportSearch(BasePageParam<PurchaseOrderSearchReq> pageParam) {
        PurchaseOrderSearchReq param = pageParam.getParam();
        pageParam.setPage(BaseConstants.ImportExport.PAGE_START_AT); // 导出最大返回前10000条
        pageParam.setSize(maxSize);
        Page<PurchaseOrderPo> pageObj = new Page<>(pageParam.getPage(), pageParam.getSize());
        pageObj.setOptimizeCountSql(false);
        IPage<PurchaseOrderExportDto> page = purchaseOrderMapper.qtySearch(pageObj, param);
        List<PurchaseOrderExportDto> records = page.getRecords();

        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(param.getBizType(), records.stream().map(PurchaseOrderExportDto::getSalePartNum)
                .distinct().collect(Collectors.toList()));
        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(param.getBizType(), records.stream()
                .map(PurchaseOrderExportDto::getStoreCode).distinct().collect(Collectors.toList()));
        Map<String, WarehousePo> warehousePoMap = baseDataQuery.mapWarehousePo(BizTypeEnum.getNewBizType(param.getBizType()), records.stream()
                .map(PurchaseOrderExportDto::getReceiveWarehouseCode).distinct().collect(Collectors.toList()));
        Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(DictEnum.MapLocationDistrict.getDictCode());

        return records.stream().map(item -> {
            PurchaseOrderExportDto dto = BeanUtil.copyProperties(item, PurchaseOrderExportDto.class);
            dto.setMaterialName(materialPoMap.getOrDefault(dto.getSalePartNum(), new MaterialPo()).getMaterialName());
            dto.setMinPackage(materialPoMap.getOrDefault(dto.getSalePartNum(), new MaterialPo()).getMinPackage());
            dto.setStoreName(storePoMap.getOrDefault(dto.getStoreCode(),new StorePo()).getStoreName());
            dto.setReceiveWarehouseName(warehousePoMap.getOrDefault(dto.getReceiveWarehouseCode(), new WarehousePo()).getName());
            dto.setPurchaseOrderStatus(PurchaseOrderStatusEnum.getDesc(dto.getPurchaseOrderStatus()));
            dto.setPurchaseOrderAttr(PurchaseOrderAttrEnum.getName(dto.getPurchaseOrderAttr()));
            dto.setTurnPurchaseOrderStatus(TurnPurchaseOrderStatusEnum.getDesc(dto.getTurnPurchaseOrderStatus()));
            dto.setTurnControlStatus(POTurnControlStatus.getNameByCode(dto.getTurnControlStatus()));
            dto.setIsControl(YNEnums.getValue(dto.getIsControl()));
            dto.setStandardPriceExcludeTax("0.00".equals(dto.getStandardPriceExcludeTax()) ? "" : dto.getStandardPriceExcludeTax());
            dto.setStandardPriceIncludeTax("0.00".equals(dto.getStandardPriceIncludeTax()) ? "" : dto.getStandardPriceIncludeTax());
            dto.setDiscountRate("0.00".equals(dto.getDiscountRate()) ? "" : dto.getDiscountRate());
            String provinceName = codeAndNameMap.getOrDefault(item.getReceiverProvince(), "");
            String cityName = codeAndNameMap.getOrDefault(item.getReceiverCity(), "");
            String districtName = codeAndNameMap.getOrDefault(item.getReceiverDistrict(), "");
            dto.setReceiverAddress(provinceName.concat(cityName)
                    .concat(districtName).concat(item.getReceiverAddress()));
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public void controlTransfer(ControlTransferReq idReq) {
        String redisKey = String.format(BaseConstants.RedisKey.PURCHASE_ORDER_CONTROL_TRANSFER_KEY, idReq.getDetailId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            purchaseOrderService.controlTransferWithTransactional(idReq);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
    @Override
    public void controlTransferWithTransactional(ControlTransferReq idReq){
        ControlTransferContext context = checkControlTransferReq(idReq);
        PurchaseOrderDetailPo detailPo = context.getDetailPo();
        detailPo.setTurnedControlQty(idReq.getQty().add(detailPo.getTurnedControlQty()));
        purchaseOrderDetailService.updateById(detailPo);

        //更新采购订单主数据 管控件转单状态
        updatePoTurnControlStatus(context.getPo());
        PurchaseOrderPartTransferOperatePo operatePo = purchaseOrderPartTransferOperateService.saveNewPartTransferOperate(idReq.getQty(), detailPo.getId(), PoTurnType.SO.getType());
        transferOrderDetailSpecifyQty(context.getPo(), context.getStoreWarehouseConfigPos(), operatePo);
    }

    private void updatePoTurnControlStatus(PurchaseOrderPo po) {
        List<PurchaseOrderDetailPo> list = purchaseOrderDetailService.list(Wrappers.lambdaQuery(PurchaseOrderDetailPo.class)
                .eq(PurchaseOrderDetailPo::getPurchaseOrderNo, po.getPurchaseOrderNo()));
        // 管控件全部数量
        BigDecimal totalControlQty = list.stream().filter(p -> YNEnums.Y.getCode().equals(p.getIsControl())).map(PurchaseOrderDetailPo::getQty)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal totalTurnedControlQty = list.stream().filter(p -> YNEnums.Y.getCode().equals(p.getIsControl()))
                .map(PurchaseOrderDetailPo::getTurnedControlQty)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        if (totalControlQty.compareTo(totalTurnedControlQty) == 0) {
            purchaseOrderService.update(Wrappers.lambdaUpdate(PurchaseOrderPo.class)
                    .eq(PurchaseOrderPo::getPurchaseOrderNo, po.getPurchaseOrderNo())
                    .set(PurchaseOrderPo::getTurnControlStatus, POTurnControlStatus.ALL_DONE.getCode()));
            return;
        }
        if (POTurnControlStatus.PENDING.getCode().equals(po.getTurnControlStatus())) {
            purchaseOrderService.update(Wrappers.lambdaUpdate(PurchaseOrderPo.class)
                    .eq(PurchaseOrderPo::getPurchaseOrderNo, po.getPurchaseOrderNo())
                    .set(PurchaseOrderPo::getTurnControlStatus, POTurnControlStatus.PART_TRANSFER.getCode()));
        }
    }


    @Override
    public void controlTransferJob(PurchaseOrderPartTransferOperatePo operatePo) {
        String redisKey = String.format(BaseConstants.RedisKey.PURCHASE_ORDER_CONTROL_TRANSFER_KEY, operatePo.getPurchaseOrderDetailId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            PurchaseOrderDetailPo detailPo = purchaseOrderDetailService.getById(operatePo.getPurchaseOrderDetailId());
            PurchaseOrderPo po = purchaseOrderService.getOne(Wrappers.lambdaQuery(PurchaseOrderPo.class)
                    .eq(PurchaseOrderPo::getPurchaseOrderNo, detailPo.getPurchaseOrderNo()));

            List<StoreWarehouseConfigPo> storeWarehouseConfigPos = baseDataQuery.allStoreWarehouseConfig(po.getBizType(),
                    po.getStoreCode());
            transferOrderDetailSpecifyQty(po, storeWarehouseConfigPos, operatePo);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    /**
     * Checks the control transfer request.
     *
     * @param  idReq   the control transfer request
     */
    private ControlTransferContext checkControlTransferReq(ControlTransferReq idReq) {
        if (idReq.getQty().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BizException("转单数量不能小于等于 0");
        }
        PurchaseOrderDetailPo detailPo = purchaseOrderDetailService.getById(idReq.getDetailId());
        if (detailPo == null) {
            throw new BizException(RECORD_NOT_EXIST);
        }
        PurchaseOrderPo po = getOne(Wrappers.lambdaQuery(PurchaseOrderPo.class)
                .eq(PurchaseOrderPo::getPurchaseOrderNo, detailPo.getPurchaseOrderNo()));

        if (po == null) {
            throw new BizException(RECORD_NOT_EXIST);
        }
        if (!YNEnums.Y.getCode().equals(detailPo.getIsControl())) {
            throw new BizException("该零件不属于管控件");
        }

        MaterialPo materialPO = baseDataQuery.getMaterialPo(idReq.getBizType(), detailPo.getSalePartNum())
                .orElseThrow(() -> new BizException("该零件不存在"));
        //没有配置 最小包装默认为 1
        if (StrUtil.isBlank(materialPO.getMinPackage())) {
            materialPO.setMinPackage("1");
        }
        if (isNotMulti(idReq.getQty(), materialPO)) {
            throw new BizException(materialPO.getSalePartNum() + SpsResponseCodeEnum.QTY_NOT_MIN_PACKAGE_MUL.getDesc());
        }
        if (YNEnums.Y.getCode().equals(materialPO.getIsDfs())) {
            throw new BizException("DFS 零件不允许部分转单");
        }
        if (detailPo.getTurnedControlQty().add(idReq.getQty()).compareTo(detailPo.getQty()) > 0) {
            throw new BizException("管控件数量超过订单数量");
        }
        if (!PurchaseOrderStatusEnum.canPartTurn(po.getPurchaseOrderStatus())) {
            throw new BizException("该订单当前状态不允许部分转单");
        }

        List<StoreWarehouseConfigPo> storeWarehouseConfigPos = baseDataQuery.allStoreWarehouseConfig(po.getBizType(),
                po.getStoreCode());
        if (CollectionUtils.isEmpty(storeWarehouseConfigPos)) {
            throw new BizException("转单处理失败，未匹配到门店仓库配置");
        }

        return ControlTransferContext.builder()
                .detailPo(detailPo)
                .po(po)
                .storeWarehouseConfigPos(storeWarehouseConfigPos)
                .build();
    }

    @Override
    public void transferOrderDetailSpecifyQty(PurchaseOrderPo purchaseOrderPo,
                                              List<StoreWarehouseConfigPo> storeWarehouseConfigPos,
                                              PurchaseOrderPartTransferOperatePo operatePo
    ) {
        OperateEnum operateEnum = OperateEnum.MANUAL_PART_TURN_ORDER;
        String redisKey = String.format(BaseConstants.RedisKey.PURCHASE_ORDER_TRANSFER_KEY, purchaseOrderPo.getId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            if (!PurchaseOrderStatusEnum.canPartTurn(purchaseOrderPo.getPurchaseOrderStatus())) {
                return;
            }

            PurchaseOrderTransferContextDto transferContextDto = initTransferControlSalePartContext(
                    PurchaseOrderTransferContextDto.builder()
                            .operateEnum(operateEnum)
                            .purchaseOrder(purchaseOrderPo)
                            .storeWarehouseConfigs(storeWarehouseConfigPos)
                            .poPartTransferOperateId(operatePo.getId())
                            .build(), operatePo.getPurchaseOrderDetailId(), operatePo.getQty());

            boolean result = updateStatusAndSendMessage(PurchaseOrderStatusChangeDto.builder()
                    .purchaseOrderPo(purchaseOrderPo)
                    .transferContextDto(transferContextDto)
                    .newOrderStatus(PurchaseOrderStatusEnum.TRANSFER_SUCCESSFUL)
                    .operateEnum(operateEnum)
                    .operateUser(getOperateUser(operateEnum))
                    .build());

            if (!result) {
                sendTransferOrderFailedNotice(purchaseOrderPo.getBizType(), purchaseOrderPo.getPurchaseOrderNo());
                throw new BizException("转单处理失败，请稍后再试");
            }
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }


    /**
     * 更新采购订单状态并且发送MQ
     *
     * @return
     */
    @Override
    public boolean updateStatusAndSendMessage(PurchaseOrderStatusChangeDto purchaseOrderStatusChangeDto) {
        return rocketMqTxProducer.sendPurchaseOrderStatusChangeMessage(purchaseOrderStatusChangeDto);
    }

    /**
     * 初始化context熟悉
     *
     * @param contextDto
     * @return
     */
    private PurchaseOrderTransferContextDto initTransferContext(PurchaseOrderTransferContextDto contextDto) {
        PurchaseOrderPo purchaseOrderPo = contextDto.getPurchaseOrder();
        List<PurchaseOrderDetailPo> detailList = purchaseOrderDetailMapper.selectList(
                Wrappers.lambdaQuery(PurchaseOrderDetailPo.class)
                        .eq(PurchaseOrderDetailPo::getPurchaseOrderNo, purchaseOrderPo.getPurchaseOrderNo()));
        contextDto.setPurchaseOrderDetails(detailList);

        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(purchaseOrderPo.getBizType(),
                detailList.stream().map(PurchaseOrderDetailPo::getSalePartNum).distinct().collect(Collectors.toList()));
        contextDto.setMaterialMap(materialPoMap);

        List<PurchaseOrderDetailPo> dfsDetailList = detailList.stream()
                .filter(item -> "Y".equals(materialPoMap.get(item.getSalePartNum()).getIsDfs()))
                .collect(Collectors.toList()); //dfs 无视管控件
        contextDto.setDfsPurchaseOrderDetails(dfsDetailList);

        List<PurchaseOrderDetailPo> otherDetailList = detailList.stream()
                .filter(item -> !YNEnums.Y.getCode().equals(materialPoMap.get(item.getSalePartNum()).getIsDfs()))
                .filter(item -> !YNEnums.Y.getCode().equals(item.getIsControl()))  ////管控件不参与转单
                .collect(Collectors.toList());
        contextDto.setOtherPurchaseOrderDetails(otherDetailList);

        contextDto.setOccupyDetails(Lists.newArrayList());
        contextDto.setOccupyFailedDetails(Lists.newArrayList());

        contextDto.setSaleOrders(Lists.newArrayList());
        contextDto.setSaleOrderDetails(Lists.newArrayList());

        contextDto.setBackOrders(Lists.newArrayList());

        return contextDto;
    }

    /**
     * 初始化context  构建管控件转单上下文
     *
     * @param contextDto
     * @return
     */
    private PurchaseOrderTransferContextDto initTransferControlSalePartContext(PurchaseOrderTransferContextDto contextDto, Long prDetailId, BigDecimal qty) {
        PurchaseOrderPo purchaseOrderPo = contextDto.getPurchaseOrder();
        PurchaseOrderDetailPo detailPo = purchaseOrderDetailMapper.selectById(prDetailId);
        detailPo.setQty(qty);  //指定转单数量
        List<PurchaseOrderDetailPo> detailList = Lists.newArrayList(detailPo);
        contextDto.setPurchaseOrderDetails(detailList);

        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(purchaseOrderPo.getBizType(),
                detailList.stream().map(PurchaseOrderDetailPo::getSalePartNum).distinct().collect(Collectors.toList()));
        contextDto.setMaterialMap(materialPoMap);

        //这里不会有 dfs 零件
        contextDto.setDfsPurchaseOrderDetails(Lists.newArrayList());

        List<PurchaseOrderDetailPo> otherDetailList = detailList.stream()
                .filter(item -> !"Y".equals(materialPoMap.get(item.getSalePartNum()).getIsDfs()))
                .collect(Collectors.toList());
        contextDto.setOtherPurchaseOrderDetails(otherDetailList);

        contextDto.setOccupyDetails(Lists.newArrayList());
        contextDto.setOccupyFailedDetails(Lists.newArrayList());

        contextDto.setSaleOrders(Lists.newArrayList());
        contextDto.setSaleOrderDetails(Lists.newArrayList());

        contextDto.setBackOrders(Lists.newArrayList());

        return contextDto;
    }


    private String getOperateUser(OperateEnum operateEnum) {
        if (OperateEnum.isSystemOpt(operateEnum)) {
            return OperateUserEnum.SPS.getName();
        } else {
            if (StrUtil.isBlank(UserUtil.getUserName())) {
                return UserUtil.getUserNameByRequest();
            }
            return UserUtil.getUserName();
        }
    }

    private void sendTransferOrderFailedNotice(String bizType, String purchaseOrderNo) {
        String content = "**采购订单转单失败**\n" +
                "**业务类型: <font color='comment'>${bizType}</font>**\n" +
                "**采购订单: <font color='comment'>${purchaseOrderNo}</font>**";

        Map<String, Object> contentMap = Maps.newHashMap();
        contentMap.put("bizType", bizType);
        contentMap.put("purchaseOrderNo", purchaseOrderNo);
        webhookUtil.sendMarkdownMessage(null, new StrSubstitutor(contentMap).replace(content),"采购订单转单失败");
    }
}
