package com.jiduauto.sps.order.server.client.config;

import feign.Util;
import feign.auth.BasicAuthRequestInterceptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;


/**
 * @author tao.wang
 * @date 2023/1/9
 * @description
 */
public class ChargePartnerFeignAuthConfig {


    @Value("${auth.basic.charge.partner.username}")
    private String username;

    @Value("${auth.basic.charge.partner.password}")
    private String password;

    @Bean
    public BasicAuthRequestInterceptor basicAuthRequestInterceptor() {
        return new BasicAuthRequestInterceptor(username, password, Util.UTF_8);
    }
}
