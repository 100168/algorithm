package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.BackOrderOperateLogPo;

/**
 * <p>
 * 缺件订单操作记录 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface BackOrderOperateLogMapper extends BaseMapper<BackOrderOperateLogPo> {

}
