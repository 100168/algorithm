package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalPoSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalPurchaseOrderAddReq;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderSearchReq;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface PurchaseOrderConvertor {

    /**po转dto
     * @param purchaseOrderPo po
     * @return dto*/
    @Mapping(target = "storeName", ignore = true)
    @Mapping(target = "receiveWarehouseName", ignore = true)
    PurchaseOrderDto poToDto(PurchaseOrderPo purchaseOrderPo);

    /**po转dto
     * @param request po
     * @return dto*/
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "sapOrderNo", ignore = true)
    @Mapping(target = "sapOrderCreateTime", ignore = true)
    @Mapping(target = "remark", ignore = true)
    @Mapping(target = "purchaseOrderStatus", ignore = true)
    @Mapping(target = "purchaseOrderNo", ignore = true)
    @Mapping(target = "purchaseOrderAmount", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    PurchaseOrderPo reqToPo(InternalPurchaseOrderAddReq request);
    /**po转dto
     * @param list po
     * @return dto*/
    List<PurchaseOrderDto> toDtoList(List<PurchaseOrderPo> list);
    /**外部req转系统req
     * @param internalPoSearchReq req
     * @return dto*/
    @Mapping(target = "purchaseOrderNos", ignore = true)
    @Mapping(target = "purchaseOrderAttr", ignore = true)
    PurchaseOrderSearchReq toReq(InternalPoSearchReq internalPoSearchReq);




}
