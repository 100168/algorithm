package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.WarehouseDistributeOrderPageSearchReq;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 仓配订单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
@Mapper
public interface WarehouseDistributeOrderMapper extends BaseMapper<WarehouseDistributeOrderPo> {

    IPage<WarehouseDistributeOrderPo> selectPageSearch(IPage<WarehouseDistributeOrderPo> iPage,@Param("param") WarehouseDistributeOrderPageSearchReq param);
}
