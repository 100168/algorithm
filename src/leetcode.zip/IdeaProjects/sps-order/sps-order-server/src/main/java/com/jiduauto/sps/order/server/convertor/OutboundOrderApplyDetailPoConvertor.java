package com.jiduauto.sps.order.server.convertor;


import com.jiduauto.sps.sdk.pojo.po.OutboundApplyOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;


@Mapper(componentModel = "spring")
public interface OutboundOrderApplyDetailPoConvertor {



    @Mapping(target = "refItemId", source = "id")
    @Mapping(target = "orderNo", source = "warehouseDistributeOrderNo")
    @Mapping(target = "expectQty", source = "qty")
    @Mapping(target = "actualQty", ignore = true)
    OutboundApplyOrderDetailPo toDto(WarehouseDistributeItemPo po);

    List<OutboundApplyOrderDetailPo> toPo(List<WarehouseDistributeItemPo> list);


}
