package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.sps.order.server.facade.BackOrderFacadeService;
import com.jiduauto.sps.order.server.pojo.dto.InternalBackOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderCancelReq;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderListSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalBoSearchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @author panjian
 * 给智子提供的缺件订单
 */
@RestController
@RequestMapping("/internal/backOrder")
@Slf4j
public class InternalBackOrderController {

     @Resource
    private BackOrderFacadeService backOrderFacadeService;
     /**缺件订单列表*/
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<InternalBackOrderDto>> internalPageSearch(@RequestBody @Valid BasePageParam<InternalBoSearchReq> pageParam) {
        return BaseResult.OK(backOrderFacadeService.internalPageSearch(pageParam));
    }


    /**
     * 申请取消
     *
     * @param cancelReq
     * @return
     */
    @PostMapping("/cancelApply")
    public BaseResult<String> cancelApply(@RequestBody @Valid BackOrderCancelReq cancelReq) {
        backOrderFacadeService.cancelApply(cancelReq);
        return BaseResult.OK();
    }
    /**缺件订单列表查询接口*/
    @PostMapping("/list")
    public BaseResult<List<InternalBackOrderDto>> internalPageSearch(@RequestBody @Valid BackOrderListSearchReq listSearchReq) {
        return BaseResult.OK(backOrderFacadeService.list(listSearchReq));
    }
}
