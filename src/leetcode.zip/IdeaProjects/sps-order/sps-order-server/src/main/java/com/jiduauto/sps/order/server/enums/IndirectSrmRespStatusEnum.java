package com.jiduauto.sps.order.server.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum IndirectSrmRespStatusEnum {

    SUCCESS("SUCCESS", "成功"),
    ERROR("ERROR", "失败");

    private final String code;

    private final String desc;

}
