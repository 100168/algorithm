package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.SaleOrderOperateLogDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.order.server.service.ISaleOrderOperateLogService;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * <p>
 * 销售订单操作记录 前端控制器
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@RestController
@RequestMapping("/spsInternal/so/operateLog")
public class SpsInternalSOOperateLogController {

    @Resource
    private ISaleOrderOperateLogService logService;

    /**
     * 销售订单状态跟踪明细接口
     *
     * @author dong.li
     * @date 4/17/23 4:08 PM
     */
    @PostMapping("/pageSearch")
    @ResponseBody
    public BaseResult<BasePageData<SaleOrderOperateLogDto>> pageSearch(@RequestBody @Valid BasePageParam<SaleOrderDetailByIdReq> pageParam) {
        return BaseResult.OK(logService.pageSearch(pageParam));
    }

}
