package com.jiduauto.sps.order.server.client.resp;

import com.jiduauto.sps.order.server.enums.IndirectSrmRespStatusEnum;
import lombok.Data;

import java.util.List;

@Data
public class IndirectSrmResp {
    private String batchNum;
    //SUCCESS/数据全部执行成功|FAILED/数据全部执行失败|PART/数据部分成功部分失败
    private String executeResult;
    private String responseMessage;
    //ERROR/失败|SUCCESS/成功；（如果状态为ERROR说明整批数据程序执行异常，无需关系明细响应结构）
    //状态为SUCCESS，需要从restResponseDtlDTOList中获取具体每条数据的执行状态
    private String responseStatus;
    private List<RestResponseDtlDTO> restResponseDtlDTOList;


    public static IndirectSrmResp failedResp(String s) {
        IndirectSrmResp indirectSrmResp = new IndirectSrmResp();
        indirectSrmResp.setExecuteResult(s);
        indirectSrmResp.setResponseMessage(s);
        indirectSrmResp.setResponseStatus(IndirectSrmRespStatusEnum.ERROR.getCode());
        return indirectSrmResp;
    }
    @Data
    public static class RestResponseDtlDTO {
        private String documentCode;
        private String documentId;
        private String responseMessage;
        //SUCCESS/成功|ERROR/失败（当前此笔单据执行的状态）
        private String responseStatus;
    }

    public static boolean isSuccess(IndirectSrmResp resp) {
        return resp.getExecuteResult().equals(IndirectSrmRespStatusEnum.SUCCESS.getCode());
    }
}