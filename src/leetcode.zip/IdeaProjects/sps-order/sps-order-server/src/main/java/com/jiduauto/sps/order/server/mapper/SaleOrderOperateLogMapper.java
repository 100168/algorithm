package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderOperateLogDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderOperateLogPo;

/**
 * <p>
 * 销售订单操作记录 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface SaleOrderOperateLogMapper extends BaseMapper<SaleOrderOperateLogPo> {

    /**
     * 销售订单状态跟踪明细
     *
     * @author dong.li
     * @date 4/17/23 4:27 PM
     */
    IPage<SaleOrderOperateLogDto> pageSearch(Page<SaleOrderOperateLogDto> page, SaleOrderDetailByIdReq param);
}
