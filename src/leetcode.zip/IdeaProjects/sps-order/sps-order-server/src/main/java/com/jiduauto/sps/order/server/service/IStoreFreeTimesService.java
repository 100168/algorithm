package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.StoreFreeTimesDto;
import com.jiduauto.sps.order.server.pojo.po.StoreFreeTimesPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreFreeTimesAddAndEditReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreFreeTimesPageReq;
import com.jiduauto.sps.sdk.pojo.dto.CommonLogDto;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * 门店免费次数配置 服务类
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
public interface IStoreFreeTimesService extends IService<StoreFreeTimesPo> {
    /**
     * 编辑
     */
    void edit(StoreFreeTimesAddAndEditReq req);

    /**
     * 新增
     */
    void add(StoreFreeTimesAddAndEditReq req);

    /**
     * 分页查询
     */
    BasePageData<StoreFreeTimesDto> pageSearch(BasePageParam<StoreFreeTimesPageReq> pageParam);

    /**
     * 删除配置
     * @param req
     */
    void delete(IdReq req);

    /**
     * 详情
     * @param req
     * @return
     */
    StoreFreeTimesDto detail(IdReq req);

    /**
     * 导入 折扣配置
     * @param bizType
     * @param file
     */
    ImportResultResp importExcel(String bizType, MultipartFile file);

    /**
     * 日志查询
     */
    BasePageData<CommonLogDto> logPageSearch(BasePageParam<IdReq> pageParam);
}
