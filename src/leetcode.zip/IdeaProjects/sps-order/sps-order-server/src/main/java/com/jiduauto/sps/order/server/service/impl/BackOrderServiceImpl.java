package com.jiduauto.sps.order.server.service.impl;


import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.jiduauto.dit.outbox.OutboxMessageService;
import com.jiduauto.dit.outbox.anno.MessageHandle;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.pojo.Result;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.handler.backorder.BackOrderOccupy;
import com.jiduauto.sps.order.server.mapper.BackOrderMapper;
import com.jiduauto.sps.order.server.mapper.PurchaseOrderMapper;
import com.jiduauto.sps.order.server.pojo.BackOrderTransferDto;
import com.jiduauto.sps.order.server.pojo.context.ControlTransferContext;
import com.jiduauto.sps.order.server.pojo.dto.*;
import com.jiduauto.sps.order.server.pojo.fileexport.BackOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.BackOrderPageSearchReq;
import com.jiduauto.sps.order.server.pojo.vo.req.ControlTransferReq;
import com.jiduauto.sps.order.server.service.*;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.GenerateSerialNoUtil;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.sdk.client.SAPRestAdapterClient;
import com.jiduauto.sps.sdk.client.req.BackOrderCancelSyncReq;
import com.jiduauto.sps.sdk.client.resp.BackOrderCancelSyncResp;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.BackOrderBatchCancelReq;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.req.IdBatchReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import com.jiduauto.sps.sdk.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.jiduauto.sps.order.server.service.impl.PurchaseOrderServiceImpl.isNotMulti;
import static com.jiduauto.sps.sdk.consts.OutboxConst.MessageType.BACK_ORDER_CANCEL;
import static com.jiduauto.sps.sdk.consts.OutboxConst.MessageType.BACK_ORDER_STATUS_CHANGE;
import static com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum.BACK_ORDER_CANCEL_ERROR;
import static com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum.RECORD_NOT_EXIST;

/**
 * <p>
 * 缺件订单 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Slf4j
@Service
@EnableAspectJAutoProxy(proxyTargetClass = true, exposeProxy = true)
public class BackOrderServiceImpl extends ServiceImpl<BackOrderMapper, BackOrderPo> implements IBackOrderService {

    @Resource
    private BackOrderMapper backOrderMapper;

    @Resource
    private GenerateSerialNoUtil generateSerialNoUtil;

    @Resource
    private IBackOrderOperateLogService backOrderOperateLogService;

    @Resource
    private PurchaseOrderMapper purchaseOrderMapper;

    @Resource
    private Map<String, BackOrderOccupy> backOrderOccupyMap;

    @Resource
    private ISaleOrderService saleOrderService;


    @Resource
    private OutboxMessageService outboxMessageService;

    @Resource
    private RocketMQTemplate rocketMQTemplate;

    @Resource
    private ISaleOrderOperateLogService saleOrderOperateLogService;

    @Resource
    private IPurchaseOrderService purchaseOrderService;

    @Resource
    private IBackOrderService backOrderService;

    @Resource
    private BaseDataQuery baseDataQuery;
    @Resource
    private SAPRestAdapterClient sapRestAdapterClient;
    @Resource
    private SpsClient spsClient;
    @Resource
    private IBaseDataRespCheckService baseDataRespCheckService;
    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;

    @Resource
    private RedissonClient redissonClient;

    /**
     * 缺件订单分野查询
     *
     * @author dong.li
     * @date 4/13/23 3:58 PM
     */
    @Override
    public BasePageData<BackOrderDto> pageSearch(BasePageParam<BackOrderPageSearchReq> pageParam) {
        Page<BackOrderDto> page = new Page<>(pageParam.getPage(), pageParam.getSize());
        if (CollUtil.isEmpty(pageParam.getParam().getBackOrderNos())) {
            pageParam.getParam().setBackOrderNos(null);
        }
        if (CollUtil.isNotEmpty(pageParam.getParam().getBackOrderNos()) && pageParam.getParam().getBackOrderNos().stream().noneMatch(StringUtils::isNotBlank)) {
            pageParam.getParam().setBackOrderNos(null);
        }
        IPage<BackOrderDto> pageSearchList = backOrderMapper.pageSearch(page, pageParam.getParam());
        BasePageData<BackOrderDto> res = new BasePageData<>(pageSearchList);

        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(pageParam.getParam().getBizType(), pageSearchList.getRecords().stream()
                .map(BackOrderDto::getStoreCode).distinct().collect(Collectors.toList()), false);
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(pageParam.getParam().getBizType(),
                pageSearchList.getRecords().stream().map(BackOrderDto::getSalePartNum).distinct().collect(Collectors.toList()), false);
        Map<String, BigDecimal> priceByPos = purchaseOrderDetailService.getDiscountUnitPriceByPos(
                res.getRecords().stream().map(BackOrderDto::getPurchaseOrderNo).collect(
                        Collectors.toList()));
                res.setRecords(pageSearchList.getRecords().stream().peek(e -> {
            String backOrderState = e.getBackOrderStatus();
            // 设置门店名称
            StorePo storePo = storePoMap.getOrDefault(e.getStoreCode(), new StorePo());
            e.setStoreName(storePo.getStoreName());
            //折后单价
            e.setDiscountUnitPrice(
                 priceByPos.getOrDefault(e.getPurchaseOrderNo() + e.getSalePartNum(), new BigDecimal(0)));
            // 设置零件名称
            MaterialPo materialPo = materialPoMap.getOrDefault(e.getSalePartNum(), new MaterialPo());
            e.setSalePartName(materialPo.getMaterialName());
            // BO是否转单
            e.setBoTransfer(materialPo.getBoTransfer());
            e.setBackOrderStatusDesc(BackOrderStatusEnum.getDesc(backOrderState));
            e.setMinPackage(materialPo.getMinPackage());

            //当状态不等于关闭and已取消时，显示BO时长字段（当前时间--创建时间）
            //当状态等于关闭or已取消时，显示BO时长（关闭/取消确认--创建时间）
            long daysBetween;
            if (!BackOrderStatusEnum.CANCELED.getCode().equals(backOrderState) &&
                    !BackOrderStatusEnum.CLOSED.getCode().equals(backOrderState)
            ) {
                daysBetween = ChronoUnit.DAYS.between(e.getCreateTime().toLocalDate(), LocalDate.now());
            } else {
                daysBetween = ChronoUnit.DAYS.between(e.getCreateTime().toLocalDate(), e.getUpdateTime().toLocalDate());
            }
            e.setIsControl(YNEnums.getValue(e.getIsControl()));
            e.setBoDuration(daysBetween);
        }).collect(Collectors.toList()));
        return res;
    }

    @Override
    public void builderBackOrderPos(PurchaseOrderTransferContextDto contextDto) {
        if (CollectionUtils.isEmpty(contextDto.getOccupyFailedDetails())) {
            return;
        }

        PurchaseOrderPo purchaseOrderPo = contextDto.getPurchaseOrder();
        //采购订单明细不会因有重复零件
        Map<String, PurchaseOrderDetailPo> salePartNumMap = contextDto.getPurchaseOrderDetails().stream()
                .collect(Collectors.toMap(PurchaseOrderDetailPo::getSalePartNum, Function.identity()));
        List<BackOrderPo> backOrderPos = contextDto.getOccupyFailedDetails().stream().map(item -> {
            BackOrderPo backOrderPo = new BackOrderPo();
            backOrderPo.setBizType(purchaseOrderPo.getBizType());
            backOrderPo.setPurchaseOrderNo(purchaseOrderPo.getPurchaseOrderNo());
            backOrderPo.setBackOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.BO, purchaseOrderPo.getBizType()));
            backOrderPo.setBackOrderType(purchaseOrderPo.getPurchaseOrderType());
            backOrderPo.setSalePartNum(item.getSalePartNum());
            backOrderPo.setBackQty(item.getQuantity());
            backOrderPo.setBackOrderStatus(BackOrderStatusEnum.PENDING.getCode());
            backOrderPo.setRestBackQty(item.getQuantity());
            backOrderPo.setStoreCode(purchaseOrderPo.getStoreCode());
            backOrderPo.setCreateUser(OperateUserEnum.SPS.getName());
            backOrderPo.setIsControl(salePartNumMap.get(item.getSalePartNum()).getIsControl());
            return backOrderPo;
        }).collect(Collectors.toList());

        contextDto.getBackOrders().addAll(backOrderPos);
    }

    @Override
    public void batchInsertBackOrder(PurchaseOrderTransferContextDto contextDto) {
        contextDto.getBackOrders().forEach(item -> backOrderMapper.insert(item));
    }

    @Override
    public List<BackOrderPo> listBackOrderPo(String purchaseOrderNo) {
        return baseMapper.selectList(Wrappers.lambdaQuery(BackOrderPo.class)
                .eq(BackOrderPo::getPurchaseOrderNo, purchaseOrderNo));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStatusAndSendMessage(BackOrderStatusChangeDto changeDto) {
        backOrderOperateLogService.saveStatusChangeLog(changeDto);

        if (!changeDto.getNewStatusEnum().getCode().equals(changeDto.getBackOrderPo().getBackOrderStatus())) {
            backOrderMapper.update(null, Wrappers.lambdaUpdate(BackOrderPo.class)
                    .set(BackOrderPo::getBackOrderStatus, changeDto.getNewStatusEnum().getCode())
                    .set(BasePo::getUpdateUser, StringUtils.defaultIfNull(changeDto.getOperateUser()))
                    .eq(BackOrderPo::getId, changeDto.getBackOrderPo().getId()));

            BackOrderMessageDto backOrderMessageDto = BeanCopierUtil.copy(changeDto.getBackOrderPo(), BackOrderMessageDto.class);
            backOrderMessageDto.setBackOrderStatus(changeDto.getNewStatusEnum().getCode());
            outboxMessageService.saveMessage(BACK_ORDER_STATUS_CHANGE, JsonUtil.toJsonString(backOrderMessageDto));


            //更新采购订单状态
            if (BackOrderStatusEnum.CANCELED.getCode().equals(changeDto.getNewStatusEnum().getCode())) {
                BackOrderPo backOrderPo = changeDto.getBackOrderPo();
                purchaseOrderService.updateStateByReceiveQtyAndCancelQty(backOrderPo.getPurchaseOrderNo(), backOrderPo.getBizType());
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void updateStatusAndSendMessage(List<BackOrderPo> backOrderPos){
        for (BackOrderPo backOrderPo : backOrderPos) {
            //状态变更发送mq
            BackOrderStatusChangeDto changeDto = BackOrderStatusChangeDto.builder()
                    .backOrderPo(backOrderPo)
                    .newStatusEnum(BackOrderStatusEnum.CANCELED)
                    .operateEnum(OperateEnum.MANUAL_CANCEL_APPROVAL)
                    .operateUser(UserUtil.getUserName())
                    .build();
            ((BackOrderServiceImpl) AopContext.currentProxy()).updateStatusAndSendMessage(changeDto);
        }

        List<Long> ids = backOrderPos.stream().map(BackOrderPo::getId).collect(Collectors.toList());
        outboxMessageService.saveMessage(BACK_ORDER_CANCEL, JSONUtil.toJsonStr(ids));
    }

    @Override
    public Map<String, BackOrderPo> mapBackOrderPo(List<String> backOrderNos) {
        return list(Wrappers.<BackOrderPo>lambdaQuery().in(BackOrderPo::getBackOrderNo,backOrderNos))
                .stream().collect(Collectors.toMap(BackOrderPo::getBackOrderNo,
                Function.identity()));
    }

    /**
     * 开始转单（需要在事务方法中调用）
     * @param contextDto
     */
    private BaseResult<String> doTransferOrder(BackOrderTransferContextDto contextDto) {
        BackOrderOccupy backOrderOccupy = backOrderOccupyMap.get(BackOrderOccupyEnum.getBeanNameByCode(contextDto.getPurchaseOrder().getPurchaseOrderType()));
        if (backOrderOccupy == null) {
            throw new BizException("订单类型错误");
        }
        backOrderOccupy.occupy(contextDto);

        if (CollectionUtils.isNotEmpty(contextDto.getOccupyDetails())) {
            saleOrderService.builderSaleOrderPos(contextDto);
            saleOrderService.batchInsertSaleOrder(contextDto);
            batchUpdateBackOrder(contextDto);

            contextDto.getSaleOrders().forEach(so ->
                    saleOrderOperateLogService.saveStatusChangeLog(
                            SaleOrderStatusChangeDto.builder()
                                    .operateEnum(OperateEnum.AUTO_TRANSFER)
                                    .saleOrderPo(so)
                                    .newStatusEnum(SaleOrderStatusEnum.WAIT_ISSUED)
                                    .operateUser(OperateUserEnum.SPS.getName())
                                    .build()
                    )
            );
            return BaseResult.OK();
        } else {
            return BaseResult.error("库存不存在");
        }
    }


    @Override
    public BackOrderPo builderAndSaveBackOrderPo(SaleOrderPo saleOrderPo, SaleOrderDetailPo saleOrderDetailPo, Map<String, PurchaseOrderDetailPo> partMap) {
        BigDecimal backQty = saleOrderDetailPo.getQty().subtract(saleOrderDetailPo.getDeliverQty());
        BackOrderPo backOrderPo = new BackOrderPo();
        backOrderPo.setBizType(saleOrderPo.getBizType());
        backOrderPo.setBackOrderNo(generateSerialNoUtil.generateOrderNoPostBiz(GenerateSerialEnum.BO, saleOrderPo.getBizType()));
        backOrderPo.setBackOrderType(saleOrderPo.getSaleOrderType());
        backOrderPo.setPurchaseOrderNo(saleOrderPo.getPurchaseOrderNo());
        backOrderPo.setSalePartNum(saleOrderDetailPo.getSalePartNum());
        backOrderPo.setBackQty(backQty);
        backOrderPo.setRestBackQty(backQty);
        backOrderPo.setBackOrderStatus(BackOrderStatusEnum.PENDING.getCode());
        backOrderPo.setStoreCode(saleOrderPo.getStoreCode());
        backOrderPo.setCreateUser(OperateUserEnum.SPS.getName());
        backOrderPo.setIsControl(partMap.get(saleOrderDetailPo.getSalePartNum()).getIsControl());
        baseMapper.insert(backOrderPo);
        outboxMessageService.saveMessage(BACK_ORDER_STATUS_CHANGE, JsonUtil.toJsonString(BeanCopierUtil.copy(backOrderPo, BackOrderMessageDto.class)));
        return backOrderPo;
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void autoTransferOrder(BackOrderTransferDto backOrderTransferDto) {
        PurchaseOrderPo purchaseOrderPo = backOrderTransferDto.getPurchaseOrderPo();
        List<BackOrderPo> backOrderPoList = backOrderMapper.selectList(Wrappers.lambdaQuery(BackOrderPo.class)
                .eq(BackOrderPo::getPurchaseOrderNo, backOrderTransferDto.getPurchaseOrderNo())
                .in(BackOrderPo::getBackOrderStatus, BackOrderStatusEnum.PENDING.getCode(), BackOrderStatusEnum.TRANSFER_FAILED.getCode(), BackOrderStatusEnum.PROCESSING.getCode()));

        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(purchaseOrderPo.getBizType(), backOrderPoList.stream().map(BackOrderPo::getSalePartNum).distinct().collect(Collectors.toList()));
        backOrderPoList = backOrderPoList.stream().filter(item -> {
            MaterialPo materialPo = materialPoMap.get(item.getSalePartNum());
            return materialPo != null && !YesNoEnums.NO.getValue().equals(materialPo.getBoTransfer());
        }).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(backOrderPoList)) {
            return;
        }
        tryTransferOrder(backOrderPoList, purchaseOrderPo, OperateEnum.AUTO_TRANSFER);
    }

    /**
     * 检查相关配置条件是否满足
     * 开始尝试 BO 转单
     */
    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
    public BaseResult<String> tryTransferOrder(List<BackOrderPo> backOrderPoList, PurchaseOrderPo purchaseOrderPo, OperateEnum operate) {
        if (CollectionUtils.isEmpty(backOrderPoList)) {
            return BaseResult.OK();
        }
        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(purchaseOrderPo.getBizType(), backOrderPoList.stream().map(BackOrderPo::getSalePartNum).distinct().collect(Collectors.toList()));
        List<StoreWarehouseConfigPo> storeWarehouseConfigPos = baseDataQuery.allStoreWarehouseConfig(purchaseOrderPo.getBizType(), purchaseOrderPo.getStoreCode());
        if (CollectionUtils.isEmpty(storeWarehouseConfigPos)) {
            backOrderPoList.forEach(item ->
                    updateStatusAndSendMessage(BackOrderStatusChangeDto.builder()
                            .backOrderPo(item)
                            .newStatusEnum(BackOrderStatusEnum.TRANSFER_FAILED)
                            .operateEnum(operate)
                            .operateUser(OperateUserEnum.SPS.getName())
                            .remark("未匹配到门店仓库配置")
                            .build()));
            return BaseResult.error("未匹配到门店仓库配置");
        } else {
            return doTransferOrder(initTransferContext(BackOrderTransferContextDto.builder()
                    .operateEnum(operate)
                    .purchaseOrder(purchaseOrderPo)
                    .backOrderPos(backOrderPoList)
                    .storeWarehouseConfigs(storeWarehouseConfigPos)
                    .materialMap(materialPoMap)
                    .build()));
        }
    }

    @MessageHandle(BACK_ORDER_STATUS_CHANGE)
    public Result sendBackOrderStatusChangeMessage(OutboxMessage outboxMessage) {
        BackOrderMessageDto messageDto = JsonUtil.toObject(outboxMessage.getContent(), BackOrderMessageDto.class);
        String msgTag = BackOrderStatusEnum.getMsgTag(messageDto.getBackOrderStatus());
        if (StringUtils.isEmpty(msgTag)) {
            throw new BizException("消息tag未设置");
        }
        rocketMQTemplate.syncSend(BaseConstants.RocketMqTopic.BACK_ORDER.concat(":").concat(msgTag), messageDto);
        return Result.success();
    }

    private BackOrderTransferContextDto initTransferContext(BackOrderTransferContextDto contextDto) {
        contextDto.setOccupyDetails(Lists.newArrayList());
        contextDto.setSaleOrders(Lists.newArrayList());
        contextDto.setSaleOrderDetails(Lists.newArrayList());
        contextDto.setBackSaleRelationPos(Lists.newArrayList());
        return contextDto;
    }

    private void batchUpdateBackOrder(BackOrderTransferContextDto contextDto) {
        Map<String, BigDecimal> occupyQtyMap = contextDto.getOccupyDetails().stream().collect(Collectors.toMap(BackOrderOccupyDetailDto::getBackOrderNo, BackOrderOccupyDetailDto::getQuantity, BigDecimal::add));
        for (BackOrderPo item : contextDto.getBackOrderPos()) {
            BigDecimal occupyQty = occupyQtyMap.getOrDefault(item.getBackOrderNo(), BigDecimal.ZERO);
            if (occupyQty.compareTo(BigDecimal.ZERO) <= 0) {
                continue;
            }

            int row = backOrderMapper.subtractRestBackQty(item.getId(), occupyQty, getOperateUser(contextDto.getOperateEnum()));
            if (row == 0) {
                log.warn("缺件单转单扣减剩余转单数量异常, 缺件单id: {}, 占用数量：{}", item.getId(), occupyQty);
                throw new BizException("缺件单转单扣减剩余转单数量异常");
            }

            BackOrderPo backOrderPo = backOrderMapper.selectById(item.getId());
            BackOrderStatusEnum newBackOrderStatus = (backOrderPo.getRestBackQty().compareTo(BigDecimal.ZERO) <= 0) ? BackOrderStatusEnum.CLOSED : BackOrderStatusEnum.PENDING;
            updateStatusAndSendMessage(BackOrderStatusChangeDto.builder()
                    .backOrderPo(item)
                    .newStatusEnum(newBackOrderStatus)
                    .operateEnum(contextDto.getOperateEnum())
                    .operateUser(getOperateUser(contextDto.getOperateEnum()))
                    .build());
        }
    }

    private String getOperateUser(OperateEnum operateEnum) {
        if (OperateEnum.AUTO_TRANSFER == operateEnum) {
            return OperateUserEnum.SPS.getName();
        } else {
            return UserUtil.getUserName();
        }
    }

    /**
     * 批量更新 Bo的预计到货时间
     *
     * @param backOrderPos
     */
    @Override
    public BaseResult<String> updateByBoNo(List<BackOrderPo> backOrderPos) {
        try{
            backOrderMapper.updateBatchByNo(backOrderPos);
        }catch (Exception e){
            log.error("批量更新BO单的预计到货时间异常",e);
            return BaseResult.error(GlobalCodeEnum.GL_FAIL_DEFAULT);
        }
        return BaseResult.OK();
    }

    /**
     * 取消审批
     *
     * @param backOrderNo
     */
    @Override
    public BaseResult<String> cancelApproval(String backOrderNo) {
        BackOrderPo backOrderPo = backOrderMapper.selectOne(Wrappers.lambdaQuery(BackOrderPo.class)
                .eq(BackOrderPo::getBackOrderNo, backOrderNo));
        if (Objects.isNull(backOrderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        if (!BackOrderStatusEnum.CANCEL_PENDING.getCode().equals(backOrderPo.getBackOrderStatus())) {
            throw new BizException(SpsResponseCodeEnum.OPERATE_NOT_SUPPORTED);
        }

        BackOrderStatusChangeDto changeDto = BackOrderStatusChangeDto.builder()
                .backOrderPo(backOrderPo)
                .newStatusEnum(BackOrderStatusEnum.CANCELED)
                .operateEnum(OperateEnum.MANUAL_CANCEL_APPROVAL)
                .operateUser(UserUtil.getUserName())
                .build();
        PurchaseOrderPo purchaseOrderPo = purchaseOrderMapper.selectOne(Wrappers.lambdaQuery(PurchaseOrderPo.class)
                .eq(PurchaseOrderPo::getPurchaseOrderNo, backOrderPo.getPurchaseOrderNo()));

        BackOrderCancelSyncReq backOrderCancelSyncReq = BackOrderCancelSyncReq
                .newInstance()
                .setPurchaseOrder(purchaseOrderPo)
                .setBackOrder(backOrderPo);
        BackOrderCancelSyncResp backOrderCancelSyncResp = sapRestAdapterClient.backOrderCancelSync(backOrderCancelSyncReq);
        log.info("BackOrderServiceImpl#cancelApproval backOrderCancelSync, param: {}, result: {}", JsonUtil.toJsonString(backOrderCancelSyncReq), JsonUtil.toJsonString(backOrderCancelSyncResp));
        if (!BackOrderCancelSyncResp.success(backOrderCancelSyncResp)) {
            String errorMessage = backOrderCancelSyncResp.getMessageBody().get(0).getItem().get(0).getMessage_Text();
            changeDto.setRemark(errorMessage);
            backOrderOperateLogService.saveStatusChangeLog(changeDto);
            throw new BizException(GlobalCodeEnum.GL_FAIL_10000, errorMessage);
        }

        ((BackOrderServiceImpl) AopContext.currentProxy()).updateStatusAndSendMessage(changeDto);

        return BaseResult.OK();
    }

    /**
     * 批量取消审批
     * @param req
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void batchCancelApproval(BackOrderBatchCancelReq req) {
        List<BackOrderPo> backOrderPos = list(
                Wrappers.<BackOrderPo>lambdaQuery().in(BackOrderPo::getBackOrderNo, req.getBackOrderNos())
                        .eq(BackOrderPo::getBizType, req.getBizType())
                        .eq(BackOrderPo::getBackOrderStatus, BackOrderStatusEnum.CANCEL_PENDING.getCode()));
        if (backOrderPos.size() != req.getBackOrderNos().size()) {
            throw new BizException(BACK_ORDER_CANCEL_ERROR);
        }
        updateStatusAndSendMessage(backOrderPos);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
    public BaseResult<String> manualTransferOrder(Long id,String operationUser) {
        BackOrderPo backOrderPo = backOrderMapper.selectById(id);
        if (Objects.isNull(backOrderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        PurchaseOrderPo purchaseOrderPo = purchaseOrderMapper.selectOne(Wrappers.lambdaQuery(PurchaseOrderPo.class)
                .eq(PurchaseOrderPo::getPurchaseOrderNo, backOrderPo.getPurchaseOrderNo()));
        if (Objects.isNull(purchaseOrderPo)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        if (!BackOrderStatusEnum.canTransfer(backOrderPo.getBackOrderStatus())) {
            throw new BizException(SpsResponseCodeEnum.OPERATE_NOT_SUPPORTED);
        }
        BaseDataResp baseDataResp = getBaseData(backOrderPo.getBizType(),backOrderPo.getSalePartNum(), purchaseOrderPo.getStoreCode());

        List<StoreWarehouseConfigPo> storeWarehouseConfigPos = baseDataResp.getStoreWarehouseConfigPos();
        if (CollectionUtils.isEmpty(storeWarehouseConfigPos)) {
            updateStatusAndSendMessage(BackOrderStatusChangeDto.builder()
                    .backOrderPo(backOrderPo)
                    .newStatusEnum(BackOrderStatusEnum.TRANSFER_FAILED)
                    .operateEnum(OperateEnum.MANUAL_TRANSFER)
                    .operateUser(operationUser)
                    .remark("未匹配到门店仓库配置")
                    .build());
            return BaseResult.error("未匹配到门店仓库配置");
        } else {
            Map<String, MaterialPo> materialPoMap = Maps.newHashMap();
            materialPoMap.put(backOrderPo.getSalePartNum(), baseDataResp.getMaterials().get(0));

            return doTransferOrder(initTransferContext(BackOrderTransferContextDto.builder()
                    .operateEnum(OperateEnum.MANUAL_TRANSFER)
                    .purchaseOrder(purchaseOrderPo)
                    .backOrderPos(Lists.newArrayList(backOrderPo))
                    .storeWarehouseConfigs(storeWarehouseConfigPos)
                    .materialMap(materialPoMap)
                    .build()));
        }
    }

    @Override
    public BaseResult<String> manualBatchTransferOrder(IdBatchReq idBatchReq) {
        List<BackOrderPo> backOrderPos = backOrderMapper.selectList(Wrappers.lambdaQuery(BackOrderPo.class)
                .in(BackOrderPo::getId, idBatchReq.getIdList())
                .orderByAsc(BackOrderPo::getCreateTime)
        );

        //校验缺件订单状态
        backOrderPos.forEach(o -> {
            if (!BackOrderStatusEnum.canTransfer(o.getBackOrderStatus())) {
                throw new BizException(BACK_ORDER_CANCEL_ERROR);
            }
        });

        if (idBatchReq.getIdList().size() != backOrderPos.size()) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }

        Map<String, PurchaseOrderPo> poMap = purchaseOrderService.list(Wrappers.lambdaQuery(PurchaseOrderPo.class)
                .eq(PurchaseOrderPo::getBizType, idBatchReq.getBizType())
                .in(PurchaseOrderPo::getPurchaseOrderNo, backOrderPos.stream().map(BackOrderPo::getPurchaseOrderNo).distinct().collect(Collectors.toList()))
        ).stream().collect(Collectors.toMap(PurchaseOrderPo::getPurchaseOrderNo, Function.identity()));
        //针对选中的bo  po分组, 根据po创建时间 顺序执行 ,同一个po内的根据 bo创建时间顺序执行
        Map<String, List<BackOrderPo>> boMapByPo = backOrderPos.stream().collect(Collectors.groupingBy(BackOrderPo::getPurchaseOrderNo, Collectors.toList()));

        StringBuilder totalStr = new StringBuilder();
        for (String poNo : boMapByPo.keySet()) {
            List<BackOrderPo> boList = boMapByPo.get(poNo).stream().sorted(Comparator.comparing(BasePo::getCreateTime)).collect(Collectors.toList());
            String noList = boList.stream().map(BackOrderPo::getBackOrderNo).collect(Collectors.joining(", "));
            try {
                //各个转单为单独的独立事务, 各自成功,各自失败,不相互影响
                BaseResult<String> ret = backOrderService.tryTransferOrder(boList, poMap.get(poNo), OperateEnum.MANUAL_TRANSFER);
                if (!ret.isSuccess()) {
                    totalStr.append("缺件单号 ")
                            .append(noList)
                            .append(" ")
                            .append("转单失败，").append("原因: ").append(ret.getMessage())
                            .append("\n");
                }
            } catch (BizException e) {
                totalStr.append("缺件单号: ")
                        .append(noList)
                        .append(" ")
                        .append("转单失败，").append("原因: ").append(e.getErrMessage())
                        .append("\n");
            }
        }
        if (StrUtil.isBlank(totalStr.toString())) {
            return BaseResult.OK();
        } else {
            return BaseResult.error(totalStr.toString());
        }
    }

    @Override
    public List<BackOrderExportDto> getExportDtoList(BasePageParam<BackOrderPageSearchReq> pageParam) {
        List<BackOrderDto> records = pageSearch(pageParam).getRecords();
        return records.stream().map(e -> {
            BackOrderExportDto exportDto = new BackOrderExportDto();
            BeanUtils.copyProperties(e, exportDto);
            return exportDto;
        }).collect(Collectors.toList());
    }


    @Override
    public void batchCancelApprovalRejected(BackOrderBatchCancelReq req) {
        List<BackOrderPo> backOrderPos = list(
                Wrappers.<BackOrderPo>lambdaQuery().in(BackOrderPo::getBackOrderNo, req.getBackOrderNos())
                        .eq(BackOrderPo::getBizType, req.getBizType())
                        .eq(BackOrderPo::getIsDel, false)
                        .eq(BackOrderPo::getBackOrderStatus, BackOrderStatusEnum.CANCEL_PENDING.getCode()));
        if (backOrderPos.size() != req.getBackOrderNos().size()) {
            throw new BizException(BACK_ORDER_CANCEL_ERROR);
        }

        for (BackOrderPo backOrderPo : backOrderPos) {
            backOrderPo.setBackOrderStatus(BackOrderStatusEnum.PENDING.getCode());
            backOrderPo.setUpdateUser(req.getOperateUser());
            updateById(backOrderPo);
            //状态变更发送mq
            BackOrderMessageDto messageDto = BeanCopierUtil.copy(backOrderPo, BackOrderMessageDto.class);
            String msgTag = BackOrderStatusEnum.getMsgTag(messageDto.getBackOrderStatus());
            rocketMQTemplate.syncSend(BaseConstants.RocketMqTopic.BACK_ORDER.concat(":").concat(msgTag), messageDto);
            BackOrderStatusChangeDto changeDto = BackOrderStatusChangeDto.builder()
                    .backOrderPo(backOrderPo)
                    .newStatusEnum(BackOrderStatusEnum.PENDING)
                    .operateEnum(OperateEnum.MANUAL_CANCEL_APPROVAL_REJECTED)
                    .operateUser(req.getOperateUser())
                    .build();
            backOrderOperateLogService.saveStatusChangeLog(changeDto);

        }
    }

    private BaseDataResp getBaseData(String bizType, String materialCode, String storeCode){

        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setMaterialCodes(Collections.singletonList(materialCode));
        baseDataReq.setStoreWarehouseCodes(Collections.singletonList(storeCode));
        BaseResult<BaseDataResp> resp = spsClient.searchBaseData(baseDataReq);
        resp.check();
        baseDataRespCheckService.check(resp,baseDataReq);
        return resp.getData();
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public BaseResult<String> controlTransfer(ControlTransferReq idReq) {
        String redisKey = String.format(BaseConstants.RedisKey.BACK_ORDER_CONTROL_TRANSFER_KEY, idReq.getDetailId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();
            ControlTransferContext context = checkControlTransferReq(idReq);
            PurchaseOrderPo purchaseOrderPo = context.getPo();
            BackOrderPo backOrderPo = context.getBackOrderPo();
            BackOrderPo temp = BeanUtil.copyProperties(backOrderPo, BackOrderPo.class);
            Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(purchaseOrderPo.getBizType(), Collections.singletonList(backOrderPo.getSalePartNum()));
            //指定转单数量
            backOrderPo.setRestBackQty(idReq.getQty());
            return doTransferOrder(initTransferContext(BackOrderTransferContextDto.builder()
                    .operateEnum(OperateEnum.MANUAL_PART_TURN_ORDER)
                    .purchaseOrder(purchaseOrderPo)
                    .backOrderPos(Lists.newArrayList(backOrderPo))
                    .storeWarehouseConfigs(context.getStoreWarehouseConfigPos())
                    .materialMap(materialPoMap)
                    .restBackQty(temp.getRestBackQty())
                    .build()));
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    /**
     * Checks the control transfer request.
     *
     * @param  idReq   the control transfer request
     */
    private ControlTransferContext checkControlTransferReq(ControlTransferReq idReq) {
        if (idReq.getQty().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BizException("转单数量不能小于等于 0");
        }
        BackOrderPo boPo = backOrderService.getById(idReq.getDetailId());
        if (boPo == null) {
            throw new BizException(RECORD_NOT_EXIST);
        }
        PurchaseOrderPo po = purchaseOrderService.getOne(Wrappers.lambdaQuery(PurchaseOrderPo.class)
                .eq(PurchaseOrderPo::getPurchaseOrderNo, boPo.getPurchaseOrderNo()));
        if (po == null) {
            throw new BizException(RECORD_NOT_EXIST);
        }
        MaterialPo materialPO = baseDataQuery.getMaterialPo(idReq.getBizType(), boPo.getSalePartNum())
                .orElseThrow(() -> new BizException("该零件不存在"));
        //没有配置 最小包装默认为 1
        if (StrUtil.isBlank(materialPO.getMinPackage())) {
            materialPO.setMinPackage("1");
        }
        if (isNotMulti(idReq.getQty(), materialPO)) {
            throw new BizException(materialPO.getSalePartNum() + SpsResponseCodeEnum.QTY_NOT_MIN_PACKAGE_MUL.getDesc());
        }
        if (boPo.getRestBackQty().compareTo(idReq.getQty()) < 0) {
            throw new BizException("转单数量超过剩余数量");
        }
        List<StoreWarehouseConfigPo> storeWarehouseConfigPos = baseDataQuery.allStoreWarehouseConfig(po.getBizType(),
                po.getStoreCode());
        if (CollectionUtils.isEmpty(storeWarehouseConfigPos)) {
            throw new BizException("转单处理失败，未匹配到门店仓库配置");
        }

        return ControlTransferContext.builder()
                .po(po)
                .backOrderPo(boPo)
                .storeWarehouseConfigPos(storeWarehouseConfigPos)
                .build();
    }

}
