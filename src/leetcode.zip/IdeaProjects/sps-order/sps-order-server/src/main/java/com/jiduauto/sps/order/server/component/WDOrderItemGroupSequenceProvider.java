package com.jiduauto.sps.order.server.component;


import cn.hutool.core.util.StrUtil;
import com.jiduauto.sps.order.server.handler.WDOrderAddThreadLocalHolder;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeItemReq;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderAddReq;
import com.jiduauto.sps.sdk.enums.ShippingMethodEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderlogisticTypeEnum;
import org.hibernate.validator.spi.group.DefaultGroupSequenceProvider;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


/**
 * @author panjian
 */
public class WDOrderItemGroupSequenceProvider implements DefaultGroupSequenceProvider<WarehouseDistributeItemReq> {


    @Override
    public List<Class<?>> getValidationGroups(WarehouseDistributeItemReq bean) {
        List<Class<?>> defaultGroupSequence = new ArrayList<>();
        defaultGroupSequence.add(WarehouseDistributeItemReq.class);
        // 这块判空请务必要做
        return getClasses(defaultGroupSequence, bean != null);
    }

    static List<Class<?>> getClasses(List<Class<?>> defaultGroupSequence, boolean nonnullBean) {
        if (nonnullBean) {
            String orderType = WDOrderAddThreadLocalHolder.getString(WDOrderAddThreadLocalHolder.ORDER_TYPE);
            String logisticType = WDOrderAddThreadLocalHolder.getString(WDOrderAddThreadLocalHolder.LOGISTIC_TYPE);
            String sourceSystem = WDOrderAddThreadLocalHolder.getString(WDOrderAddThreadLocalHolder.SOURCE_SYSTEM);
            String shippingMethod = WDOrderAddThreadLocalHolder.getString(WDOrderAddThreadLocalHolder.SHIPPING_METHOD);
            if (StrUtil.isNotEmpty(logisticType) && WarehouseDistributeOrderlogisticTypeEnum.needCheck(Integer.valueOf(logisticType))) {
                defaultGroupSequence.add(WarehouseDistributeOrderAddReq.LogisticGroup.class);
            }
            if (WarehouseDistributeOrderTypeEnum.needCheckSP(orderType)) {
                defaultGroupSequence.add(WarehouseDistributeOrderAddReq.SP18AndSP19Group.class);
            }
            if (WarehouseDistributeOrderTypeEnum.needCheck(orderType)) {
                defaultGroupSequence.add(WarehouseDistributeOrderAddReq.OrderTypeGroup.class);
            }
            if (WarehouseDistributeOrderTypeEnum.SM11.getValue().equals(orderType)) {
                defaultGroupSequence.add(WarehouseDistributeOrderAddReq.SM11Group.class);
            }
            if (WarehouseDistributeOrderTypeEnum.SM12.getValue().equals(orderType)) {
                defaultGroupSequence.add(WarehouseDistributeOrderAddReq.SM12Group.class);
            }

            if (WarehouseDistributeOrderTypeEnum.isApplyOrder(orderType)) {
                defaultGroupSequence.add(WarehouseDistributeOrderAddReq.ApplyOrder.class);
            }
            if (WarehouseDistributeOrderTypeEnum.isDirAsn(orderType)) {
                defaultGroupSequence.add(WarehouseDistributeOrderAddReq.DirAsnGroup.class);
            }
            if (!Objects.equals(sourceSystem, "SPS")) {
                defaultGroupSequence.add(WarehouseDistributeOrderAddReq.API.class);
            }
            if (StrUtil.isNotEmpty(shippingMethod) && WarehouseDistributeOrderTypeEnum.isApplyOrder(orderType) && !Objects.equals(shippingMethod, ShippingMethodEnum.SPK.getCode())) {
                defaultGroupSequence.add(WarehouseDistributeOrderAddReq.ShippingMethod.class);
            }
        }
        return defaultGroupSequence;
    }
}
