package com.jiduauto.sps.order.server.mapper;

import com.jiduauto.sps.order.server.pojo.po.StoreFreeTimesPo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 门店免费次数配置 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
public interface StoreFreeTimesMapper extends BaseMapper<StoreFreeTimesPo> {

   void  saveBatch(List<StoreFreeTimesPo> list);
}
