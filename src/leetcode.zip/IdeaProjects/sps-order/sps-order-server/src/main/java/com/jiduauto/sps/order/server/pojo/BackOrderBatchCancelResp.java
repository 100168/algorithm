package com.jiduauto.sps.order.server.pojo;

import lombok.Data;

import java.util.List;

@Data
public class BackOrderBatchCancelResp {
    private String bizType;

    List<RespInfo> respInfos;

    @Data
    static
    public class RespInfo{
        private String backOrderNo;
        private String msg;
    }
}
