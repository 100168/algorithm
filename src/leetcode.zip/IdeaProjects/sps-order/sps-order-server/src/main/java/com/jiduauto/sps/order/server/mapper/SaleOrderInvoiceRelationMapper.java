package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderInvoiceRelationPo;

/**
 * <p>
 * 销售订单发票关联表 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2024-03-25
 */
public interface SaleOrderInvoiceRelationMapper extends BaseMapper<SaleOrderInvoiceRelationPo> {
}
