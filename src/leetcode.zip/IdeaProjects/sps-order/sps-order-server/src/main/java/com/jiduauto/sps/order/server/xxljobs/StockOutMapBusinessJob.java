package com.jiduauto.sps.order.server.xxljobs;


import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.mapper.SaleOrderDetailMapper;
import com.jiduauto.sps.order.server.mapper.SaleOrderMapper;
import com.jiduauto.sps.order.server.mapper.SaleOrderOperateLogMapper;
import com.jiduauto.sps.order.server.mapper.WarehouseDistributeOrderMapper;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeItemService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeLogisticService;
import com.jiduauto.sps.sdk.client.req.StockOutMapBusinessDto;
import com.jiduauto.sps.sdk.client.req.StockOutMapBusinessItemDto;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeLogisticDto;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import com.jiduauto.sps.sdk.utils.DateUtils;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * 存量订单同步到 库存出库关联订单
 */
@Component
@Slf4j
public class StockOutMapBusinessJob {

    @Resource
    private SaleOrderMapper saleOrderMapper;
    @Resource
    private SaleOrderDetailMapper saleOrderDetailMapper;
    @Resource
    private SaleOrderOperateLogMapper saleOrderOperateLogMapper;

    @Resource
    private WarehouseDistributeOrderMapper warehouseDistributeOrderMapper;
    @Resource
    private IWarehouseDistributeItemService warehouseDistributeItemService;

    @Resource
    private IWarehouseDistributeLogisticService warehouseDistributeLogisticService;
    @Resource
    SpsClient spsClient;


    @XxlJob("StockOutMapBusinessJob")
    public ReturnT<String> execute(String param) throws Exception{
        List<SaleOrderPo> orderPos = saleOrderMapper.selectList(Wrappers.lambdaQuery(SaleOrderPo.class)
                .eq(SaleOrderPo::getIsDel, false));
        for(SaleOrderPo saleOrderPo:orderPos){
            createStockOutMapBusinessDto(saleOrderPo);
        }

        List<WarehouseDistributeOrderPo> distributeOrderPos = warehouseDistributeOrderMapper.selectList(Wrappers.lambdaQuery(WarehouseDistributeOrderPo.class)
                .eq(WarehouseDistributeOrderPo::getIsDel, false)
                .eq(WarehouseDistributeOrderPo::getOrderType, WarehouseDistributeOrderTypeEnum.SM20.getValue())
        );
        for(WarehouseDistributeOrderPo saleOrderPo:distributeOrderPos){
            createStockOutMapBusinessDto(saleOrderPo);
        }
        return ReturnT.SUCCESS;
    }


    /**
     * 构建 出库关联订单请求体
     * @param po
     * @return
     */
    private StockOutMapBusinessDto createStockOutMapBusinessDto(SaleOrderPo po){
        List<StockOutMapBusinessItemDto> itemDtos = new ArrayList<>();
        StockOutMapBusinessDto dto = new StockOutMapBusinessDto();
        dto.setBizType(po.getBizType());
        dto.setOrderNo(po.getSaleOrderNo());
        dto.setOperateType(OperateTypeEnum.SAVE);
        dto.setBusinessNo(po.getPurchaseOrderNo());
        dto.setLogisticsNo(po.getLogisticsNo());
        dto.setOutType(StockOperationType.SP20.getOperationType());
        dto.setOrderType(po.getSaleOrderType());
        dto.setStoreCode(po.getStoreCode());
        dto.setTargetCity(po.getReceiverCity());
        dto.setTargetAddress(po.getReceiverAddress());
        dto.setRemark(po.getRemark());
        dto.setShippingMethod(po.getTransferAdvice());
        if(po.getSaleOrderStatus().equals(SaleOrderStatusEnum.PENDING_DELIVERY.getCode())){
            dto.setOrderStatus(StockOutMapBusinessStatus.DELIVERED.getCode());
            //已下发
        }else if(po.getSaleOrderStatus().equals(SaleOrderStatusEnum.PARTIALLY_RECEIVED.getCode()) ||
                po.getSaleOrderStatus().equals(SaleOrderStatusEnum.FULLY_RECEIVED.getCode())||
                po.getSaleOrderStatus().equals(SaleOrderStatusEnum.DELIVERED.getCode())){
            //已发货  门店已收货
            dto.setOrderStatus(StockOutMapBusinessStatus.DELIVERED.getCode());
        }else if(po.getSaleOrderStatus().equals(SaleOrderStatusEnum.CANCELED.getCode())){
            //取消
            dto.setOrderStatus(StockOutMapBusinessStatus.CANCEL.getCode());
        }
        List<SaleOrderOperateLogPo> saleOrderOperateLogPos = saleOrderOperateLogMapper.selectList(Wrappers.lambdaQuery(SaleOrderOperateLogPo.class).eq(SaleOrderOperateLogPo::getSaleOrderNo,
                po.getSaleOrderNo()).eq(SaleOrderOperateLogPo::getNewValue,"DELIVERED"));
        if(CollectionUtils.isNotEmpty(saleOrderOperateLogPos)){
            dto.setOutDate(DateUtils.getLocalDateTimeStr(saleOrderOperateLogPos.get(0).getCreateTime(), DateUtils.STANDARD_TIME_FORMAT));
        }
        dto.setOrderDate(DateUtils.getLocalDateTimeStr(po.getCreateTime(), DateUtils.STANDARD_TIME_FORMAT));
        List<SaleOrderDetailPo> itemPos = saleOrderDetailMapper.selectList(Wrappers.lambdaQuery(SaleOrderDetailPo.class)
                .eq(SaleOrderDetailPo::getSaleOrderNo,po.getSaleOrderNo())
                .eq(SaleOrderDetailPo::getBizType,po.getBizType()));
        for(SaleOrderDetailPo itemPo:itemPos){
            StockOutMapBusinessItemDto itemDto = new StockOutMapBusinessItemDto();
            itemDto.setBizType(itemPo.getBizType());
            itemDto.setOrderNo(po.getSaleOrderNo());
            itemDto.setWarehouseCode(po.getDeliverWarehouseCode());
            itemDto.setMaterialCode(itemPo.getSalePartNum());
            itemDto.setPlanQuantity(itemPo.getQty());
            itemDto.setRealQuantity(itemPo.getDeliverQty());
            itemDto.setRemark(itemPo.getRemark());
            itemDtos.add(itemDto);
        }
        dto.setDtos(itemDtos);
        spsClient.stockOutMapBusiness(dto);
        return dto;
    }


    /**
     * 构建 出库关联订单请求体
     * @param po
     * @return
     */
    private StockOutMapBusinessDto createStockOutMapBusinessDto(WarehouseDistributeOrderPo po){
        List<StockOutMapBusinessItemDto> itemDtos = new ArrayList<>();
        WarehouseDistributeLogisticDto logisticPo = warehouseDistributeLogisticService.selectWarehouseDistributeLogistic(po.getBizType(),po.getOrderNo());

        StockOutMapBusinessDto dto = new StockOutMapBusinessDto();
        dto.setBizType(po.getBizType());
        dto.setOperateType(OperateTypeEnum.SAVE);
        dto.setLogisticsNo(po.getLogisticNo());
        dto.setBusinessNo(po.getBusinessBillNo());
        dto.setOrderNo(po.getOrderNo());
        dto.setOutType(StockOperationType.SM20.getOperationType());
        dto.setTargetCity(logisticPo.getReceiveCityCode());
        dto.setTargetAddress(logisticPo.getReceiveAddress());
        dto.setRemark(po.getRemark());
        dto.setOrderType("TOC");
        dto.setShippingMethod(logisticPo.getShippingMethod());
        dto.setOrderDate(DateUtils.getLocalDateTimeStr(po.getCreateTime(), DateUtils.STANDARD_TIME_FORMAT));
//                DELIVERED("DELIVERED", "已下发"),
//                CANCELED("CANCELED", "已取消"),
//                OUT_STOCK_COMPLETED("OUT_STOCK_COMPLETED", "已出库"),
//                SHIPPED("SHIPPED", "已发货"),
//                COMPLETED("COMPLETED", "已完成");
        if(po.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.DELIVERED.getCode())){
            dto.setOrderStatus(StockOutMapBusinessStatus.DELIVERED.getCode());
            //已下发
        }else if(po.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.OUT_STOCK_COMPLETED.getCode()) ||
                po.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.SHIPPED.getCode())||
                po.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.COMPLETED.getCode())){
            //已发货  门店已收货
            dto.setOrderStatus(StockOutMapBusinessStatus.DELIVERED.getCode());
        }else if(po.getOrderStatus().equals(WarehouseDistributeOrderStatusEnum.CANCELED.getCode())){
            //取消
            dto.setOrderStatus(StockOutMapBusinessStatus.CANCEL.getCode());
        }

        List<WarehouseDistributeItemPo> itemPos = warehouseDistributeItemService.list(Wrappers.lambdaQuery(WarehouseDistributeItemPo.class)
                .eq(WarehouseDistributeItemPo::getWarehouseDistributeOrderNo,po.getOrderNo()));
        for(WarehouseDistributeItemPo itemPo:itemPos){
            StockOutMapBusinessItemDto itemDto = new StockOutMapBusinessItemDto();
            itemDto.setBizType(itemPo.getBizType());
            itemDto.setOrderNo(po.getOrderNo());
            //发货仓库
            itemDto.setWarehouseCode(logisticPo.getDeliverWarehouseCode());
            itemDto.setMaterialCode(itemPo.getMaterialCode());
            itemDto.setPlanQuantity(itemPo.getQty());
            itemDto.setRealQuantity(itemPo.getRealOutQty());
            itemDto.setRemark(itemPo.getRemark());
            itemDtos.add(itemDto);
        }
        dto.setDtos(itemDtos);
        spsClient.stockOutMapBusiness(dto);
        return dto;
    }
}
