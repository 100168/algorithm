package com.jiduauto.sps.order.server.config;

import cn.hutool.core.collection.CollUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.annotation.Order;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Order(1)
@WebFilter(urlPatterns = {"/internal/*"})
public class BasicAuthFilter implements Filter, InitializingBean {

    private final static String USER_JSON_KEY = "auth.basic.user-json";

    private final Map<String, String> usernamePasswordMap = new HashMap<>();

    @ApolloConfig
    public Config config;

    final Base64.Decoder decoder = Base64.getDecoder();

    private final String[] authMethods = {"POST", "GET"};

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        if (servletRequest instanceof HttpServletRequest && servletResponse instanceof HttpServletResponse) {
            HttpServletRequest request = (HttpServletRequest) servletRequest;
            HttpServletResponse response = (HttpServletResponse) servletResponse;

            if (!needAuth(request.getMethod())) {
                filterChain.doFilter(servletRequest, servletResponse);
                return;
            }

            response.setCharacterEncoding("UTF-8");
            String authorization = request.getHeader("authorization");

            if (authorization == null || authorization.isEmpty()) {
                reject(response);
                return;
            }

            String userAndPass = new String(decoder.decode(authorization.split(" ")[1]));
            String[] info = userAndPass.split(":");
            if (info.length < 2) {
                reject(response);
                return;
            }

            String user = info[0];
            String pass = info[1];

            if (usernamePasswordMap.containsKey(user) && pass.equals(usernamePasswordMap.get(user))) {
                filterChain.doFilter(servletRequest, servletResponse);
            } else {
                reject(response);
            }
        } else {
            filterChain.doFilter(servletRequest, servletResponse);
        }
    }

    private void reject(HttpServletResponse response) {
        response.setStatus(401);
        response.setHeader("WWW-authenticate", "Basic realm=\"Please ask the administrator for the username and password.\"");
    }

    private boolean needAuth(String httpMethod) {
        for (String method : authMethods) {
            if (StringUtils.equalsAnyIgnoreCase(method, httpMethod)) {
                return true;
            }
        }
        return false;
    }


    @ApolloConfigChangeListener(value = "application.properties", interestedKeys = {USER_JSON_KEY})
    private void refresh(ConfigChangeEvent changeEvent) {
        initUserDetailsMap(changeEvent.getChange(USER_JSON_KEY).getNewValue());
    }

    @Override
    public void afterPropertiesSet() {
        initUserDetailsMap(config.getProperty(USER_JSON_KEY, "{}"));
    }

    private void initUserDetailsMap(String userJson) {
        JSONObject userJSONObject = JSON.parseObject(userJson);
        usernamePasswordMap.clear();
        List<String> collected = userJSONObject.keySet().stream()
                .filter(StringUtils::isNotEmpty)
                .filter(username -> StringUtils.isNotEmpty(userJSONObject.getString(username))).collect(Collectors.toList());
        if (CollUtil.isNotEmpty(collected)) {
            for (String username : collected) {
                usernamePasswordMap.put(username, userJSONObject.getString(username));
            }
        }
    }
}