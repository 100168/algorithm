package com.jiduauto.sps.order.server;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Hello world!
 *
 */
@MapperScan(basePackages = {"com.jiduauto.sps.order.server.mapper","com.jiduauto.sps.sdk.mapper"})
@SpringBootApplication
@EnableFeignClients(basePackages = {"com.jiduauto.sps.order.server", "com.jiduauto.tms", "com.jiduauto.sps.sdk", "com.jiduauto.spare","com.jiduauto.track.api.feign"})
@EnableDiscoveryClient(autoRegister = false)
@EnableAsync
@ComponentScan(basePackages = {"com.jiduauto.sps.order.server","com.jiduauto.sps.sdk"})
@ServletComponentScan
public class App
{
    public static void main( String[] args )
    {
        SpringApplication.run(App.class,args);
    }
}
