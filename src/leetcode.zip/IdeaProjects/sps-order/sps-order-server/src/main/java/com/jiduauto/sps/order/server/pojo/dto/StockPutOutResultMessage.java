package com.jiduauto.sps.order.server.pojo.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * 库存 出库结果的MQ消息体  用于异步处理 相关业务逻辑
 */
@Data
public class StockPutOutResultMessage implements Serializable {
    /**
     * 业务类型
     */
    private String bizType;
    /**
     * 业务类型
     */
    private String businessType;

    private String businessBillNo;
    /**
     * 1  出库成功  -1：出库失败
     */
    private Integer result;
    /**
     * 对应的交易凭证号  eg:SO单号
     */
    private String tradeNo;
    /**
     * 出库 生成的SAP单号
     */
    private String sapNoForSo;
    /**
     * wms出库时间
     */
    private String putOutTime;
    /**
     * 零件物料的出库结果
     */
    private List<InAndOutStockParam> stockParams;
    /**
     * 出库请求体 用于重试
     */
    private String requestJson;

    /**
     * 描述信息
     */
    private String message;

    @JsonIgnore
    public boolean isSuccess() {
        return this.getResult() == 1;
    }

}
