package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.po.IdempotentLogPo;
import org.aspectj.lang.ProceedingJoinPoint;

/**
 * <p>
 * 接口幂等记录表 服务类
 * </p>
 *
 * @author generate
 * @since 2023-11-16
 */
public interface IIdempotentLogService extends IService<IdempotentLogPo> {

    /**
     * 执行 controller 方法 并保存幂等log, 写在这里不写在 {@link com.jiduauto.sps.order.server.aspect.IdempotentAspect}
     * 里面是因为 IdempotentAspect 里的方法事务注解不会生效, 所以在这里执行
     */
    Object proceedAndSaveIdLog(ProceedingJoinPoint pjp, String idNo) throws Throwable;

    /**
     * 根据 idNo 和 请求路径 判断是否存在操作记录
     */
    boolean isExist(String idNo, String requestURI);

    /**
     * 根据线程上下文获取 幂等号 & apiUrl 并保存
     */
    void saveLog();
}
