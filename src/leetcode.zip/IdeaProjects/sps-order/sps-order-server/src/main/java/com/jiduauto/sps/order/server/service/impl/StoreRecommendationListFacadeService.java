package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.jiduauto.sps.order.server.pojo.dto.InternalStandardRecommendationListDto;
import com.jiduauto.sps.order.server.pojo.dto.StandardRecommendationListDto;
import com.jiduauto.sps.order.server.pojo.po.StoreRecommendationListPo;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStandardRecommendationListPage;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreRecommendationListDelReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreRecommendationListOperateReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListPageReq;
import com.jiduauto.sps.order.server.service.IStandardRecommendationListService;
import com.jiduauto.sps.order.server.service.IStoreRecommendationListService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StoreRecommendationListFacadeService {

    @Resource
    private IStoreRecommendationListService storeRecommendationListService;

    @Resource
    private IStandardRecommendationListService standardRecommendationListService;

    @Resource
    private BaseDataQuery baseDataQuery;

    public void operate(InternalStoreRecommendationListOperateReq req) {
        for (InternalStoreRecommendationListOperateReq.Item item : req.getItemList()) {
            StandardRecommendationListServiceImpl.checkQty(item.getMinQty(), item.getMaxQty());
        }

        String bizType = req.getBizType();
        List<StoreRecommendationListPo> collect =
                req.getItemList().stream().map(o -> {
                    StoreRecommendationListPo po = BeanUtil.copyProperties(o, StoreRecommendationListPo.class);
                    po.setBizType(req.getBizType());
                    return po;
                }).collect(Collectors.toList());
        List<String> storeList = collect.stream().map(StoreRecommendationListPo::getStoreCode).distinct().collect(Collectors.toList());
        List<String> materialCode = collect.stream().map(StoreRecommendationListPo::getMaterialCode).distinct().collect(Collectors.toList());
        baseDataQuery.mapStorePo(bizType, storeList, true);
        baseDataQuery.mapMaterialPo(bizType, materialCode, true);
        for (StoreRecommendationListPo po : collect) {
            storeRecommendationListService.insertOrUpdate(po, req.getOperateUser());
        }
    }

    /**
     * 删除
     */
    @Transactional(rollbackFor = Exception.class)
    public void delete(InternalStoreRecommendationListDelReq req) {
        StoreRecommendationListPo po = storeRecommendationListService.getOne(req.getBizType(), req.getStoreCode(), req.getMaterialCode());
        if (po == null) {
            throw new BizException("门店推荐清单不存在");
        }
        po.setDelUniqueKey(po.getId());
        po.setUpdateUser(req.getOperateUser());
        po.setUpdateTime(LocalDateTime.now());
        storeRecommendationListService.updateById(po);
        storeRecommendationListService.removeById(po.getId());
    }

    /**
     * 分页查询
     */
    public BasePageData<InternalStandardRecommendationListDto> standardRecommendationListPageSearch(BasePageParam<InternalStandardRecommendationListPage> pageParam) {

        InternalStandardRecommendationListPage poSearchReq = pageParam.getParam();
        StandardRecommendationListPageReq searchReq = BeanUtil.copyProperties(poSearchReq, StandardRecommendationListPageReq.class);

        BasePageParam<StandardRecommendationListPageReq> basePageParam = new BasePageParam<>();
        BeanUtils.copyProperties(pageParam, basePageParam);
        basePageParam.setParam(searchReq);
        BasePageData<StandardRecommendationListDto> ret = standardRecommendationListService.pageSearch(basePageParam);
        List<InternalStandardRecommendationListDto> collect =
                ret.getRecords().stream().map(o -> BeanUtil.copyProperties(o, InternalStandardRecommendationListDto.class)).collect(Collectors.toList());
        return new BasePageData<>(ret.getTotal(), ret.getSize(), ret.getCurrent(), ret.getPages(), collect);
    }
}
