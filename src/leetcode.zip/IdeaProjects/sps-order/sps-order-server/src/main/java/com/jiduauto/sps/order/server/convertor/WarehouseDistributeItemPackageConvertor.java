package com.jiduauto.sps.order.server.convertor;

import com.jiduauto.sps.order.server.pojo.dto.WarehouseDistributeItemPackageDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPackagePo;
import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeItemPackageReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

/**
 * @author panjian
 */
@Mapper(componentModel = "spring")
public interface WarehouseDistributeItemPackageConvertor {

    /**
     * to po
     *
     * @param req req
     * @return WarehouseDistributeItemPackagePo
     */
    @Mapping(target = "warehouseDistributeOrderNo", ignore = true)
    @Mapping(target = "updateUser", ignore = true)
    @Mapping(target = "updateTime", ignore = true)
    @Mapping(target = "isDel", ignore = true)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createUser", ignore = true)
    @Mapping(target = "createTime", ignore = true)
    @Mapping(target = "bizType", ignore = true)
    WarehouseDistributeItemPackagePo toPo(WarehouseDistributeItemPackageReq req);

    List<WarehouseDistributeItemPackagePo> toPo(List<WarehouseDistributeItemPackageReq> req);

    @Mapping(target = "standardPackingQty", ignore = true)
    @Mapping(target = "realPackingQty", ignore = true)
    WarehouseDistributeItemPackageDto toDto(WarehouseDistributeItemPackagePo po);

    List<WarehouseDistributeItemPackageDto> toDto(List<WarehouseDistributeItemPackagePo> po);
}
