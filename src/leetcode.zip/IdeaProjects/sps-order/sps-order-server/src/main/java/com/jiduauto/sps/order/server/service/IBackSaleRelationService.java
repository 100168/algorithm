package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.po.BackSaleRelationPo;

/**
 * <p>
 * 缺件订单跟销售订单的关系 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface IBackSaleRelationService extends IService<BackSaleRelationPo> {

}
