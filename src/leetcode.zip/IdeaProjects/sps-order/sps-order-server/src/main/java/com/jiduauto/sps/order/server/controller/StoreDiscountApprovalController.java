package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountApprovalDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalPageReq;
import com.jiduauto.sps.order.server.service.IStoreDiscountApprovalService;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.SpsBaseReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * <p>
 * 门店折扣审批表 前端控制器
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
@RestController
@RequestMapping("/storeDiscountApproval")
public class StoreDiscountApprovalController {

    @Resource
    private IStoreDiscountApprovalService storeDiscountApprovalService;

    /**
     * 创建临时记录
     */
    @PostMapping("/createTempRecord")
    public BaseResult<Long> createTempRecord(@RequestBody @Valid SpsBaseReq request) {
        return BaseResult.OK(storeDiscountApprovalService.createTempRecord(request));
    }

    /**
     * 分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<StoreDiscountApprovalDto>> pageSearch(@RequestBody @Valid BasePageParam<StoreDiscountApprovalPageReq> pageParam) {
        return BaseResult.OK(storeDiscountApprovalService.pageSearch(pageParam));
    }

    /**
     * 删除
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid IdReq req) {
        storeDiscountApprovalService.deleteById(req);
        return BaseResult.OK();
    }

    /**
     * 启用临时记录
     */
    @PostMapping("/enableTempRecord")
    public BaseResult<String> enableTempRecord(@RequestBody @Valid IdReq req) {
        storeDiscountApprovalService.enableTempRecord(req);
        return BaseResult.OK();
    }

    /**
     * 提交
     */
    @PostMapping("/commit")
    public BaseResult<String> commit(@RequestBody @Valid IdReq request) {
        storeDiscountApprovalService.commit(request);
        return BaseResult.OK();
    }
}
