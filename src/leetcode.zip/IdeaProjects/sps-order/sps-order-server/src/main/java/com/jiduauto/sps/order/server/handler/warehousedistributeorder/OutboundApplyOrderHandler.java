package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.convertor.OutboundApplyOrderConvertor;
import com.jiduauto.sps.order.server.convertor.OutboundOrderApplyDetailPoConvertor;
import com.jiduauto.sps.order.server.pojo.vo.req.OutboundApplyOrderCreateReq;
import com.jiduauto.sps.sdk.enums.OutApplyOrderStatus;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;

/*
 * 生成待出库列表*/
@Component
public class OutboundApplyOrderHandler implements WDOrderJobHandler, InitializingBean {

    @Resource
    private WDOrderJobContext wdOrderJobContext;
    @Resource
    private SpsClient spsClient;

    @Resource
    private OutboundApplyOrderConvertor outboundApplyOrderConvertor;

    @Resource
    private OutboundOrderApplyDetailPoConvertor outboundOrderApplyDetailPoConvertor;

    /**
     * 非G59生成待出库列表
     */
    @Override
    public void process(WarehouseDistributeOrderAllPo allPo) {
        WarehouseDistributeLogisticPo logisticPo = allPo.getWarehouseDistributeLogisticPo();
        BaseResult<List<DictItemPo>> specialWarehouse = spsClient.getSpecialWarehouse(logisticPo.getBizType());
        //是G59仓库直接返回
        if (specialWarehouse.getData().stream().anyMatch(dictItemPo -> dictItemPo.getItemCode().equals(logisticPo.getDeliverWarehouseCode()))) {
            return;
        }
        OutboundApplyOrderPo outboundApplyOrderPo = outboundApplyOrderConvertor.toDto(allPo.getWarehouseDistributeOrderPo());
        outboundApplyOrderPo.setOrderStatus(OutApplyOrderStatus.PUT.getCode());
        BigDecimal sumQty = allPo.getItems().stream().map(WarehouseDistributeItemPo::getQty).reduce(BigDecimal.ZERO, BigDecimal::add);
        outboundApplyOrderPo.setExpectQty(sumQty);
        List<OutboundApplyOrderDetailPo> itemList = outboundOrderApplyDetailPoConvertor.toPo(allPo.getItems());
        for (OutboundApplyOrderDetailPo detailPo : itemList) {
            detailPo.setWarehouseCode(logisticPo.getDeliverWarehouseCode());
        }
        BaseResult<String> resp = spsClient.createOutboundApplyOrder(OutboundApplyOrderCreateReq.builder().head(outboundApplyOrderPo).items(itemList).build());
        if (!resp.isSuccess()) {
            throw new BizException(resp.getMessage());
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.GENERATE_OUTBOUND_ORDER.getBitIndex(), this);
    }
}
