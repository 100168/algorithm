package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import com.jiduauto.javakit.common.util.JsonUtil;
import com.jiduauto.sps.order.server.client.WorkOrderClient;
import com.jiduauto.sps.order.server.client.req.WorkOrderAddReq;
import com.jiduauto.sps.order.server.enums.StoreDiscountApprovalStatusEnum;
import com.jiduauto.sps.order.server.mapper.StoreDiscountApprovalMapper;
import com.jiduauto.sps.order.server.pojo.dto.FileDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountApprovalDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreDiscountApprovalFormContentDto;
import com.jiduauto.sps.order.server.pojo.po.BasePo;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalDetailPo;
import com.jiduauto.sps.order.server.pojo.po.StoreDiscountApprovalPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreDiscountApprovalPageReq;
import com.jiduauto.sps.order.server.service.IStoreDiscountApprovalDetailService;
import com.jiduauto.sps.order.server.service.IStoreDiscountApprovalService;
import com.jiduauto.sps.order.server.service.IStoreDiscountService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.order.server.utils.RedisUtil;
import com.jiduauto.sps.order.server.utils.UserUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import com.jiduauto.sps.sdk.enums.WorkOrderStatusEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.dto.WorkOrderCallBackDto;
import com.jiduauto.sps.sdk.pojo.po.CommonFileAttachmentPo;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.SpsBaseReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.service.ICommonFileAttachmentService;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * 门店折扣审批表 服务实现类
 * </p>
 *
 * @author generate
 * @since 2024-05-11
 */
@Slf4j
@Service
public class StoreDiscountApprovalServiceImpl extends ServiceImpl<StoreDiscountApprovalMapper, StoreDiscountApprovalPo> implements IStoreDiscountApprovalService {

    public static final String TABLE_NAME = "store_discount_approval";
    @Resource
    private WorkOrderClient workOrderClient;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Resource
    private StoreDiscountApprovalMapper storeDiscountApprovalMapper;

    @Resource
    private IStoreDiscountApprovalDetailService storeDiscountApprovalDetailService;

    @Resource
    private RedisUtil redisUtil;

    @Resource
    private RedissonClient redissonClient;

    @Resource
    private ICommonFileAttachmentService commonFileAttachmentService;

    @Resource
    private IStoreDiscountService storeDiscountService;

    @Value("${approval.store-discount.formTemplateId:200}")
    private Integer formTemplateId;

    @Value("${work-order.url.detail-page:https://work-order-ground.jidudev.com/ground/detail-page?procInstId=%s}")
    private String detailPageUrl;

    /**
     * 分页查询
     */
    @Override
    public BasePageData<StoreDiscountApprovalDto> pageSearch(BasePageParam<StoreDiscountApprovalPageReq> req) {
        StoreDiscountApprovalPageReq param = req.getParam();
        IPage<StoreDiscountApprovalPo> page = page(new Page<>(req.getPage(), req.getSize()),
                Wrappers.lambdaQuery(StoreDiscountApprovalPo.class)
                        .eq(StoreDiscountApprovalPo::getBizType, param.getBizType())
                        .eq(StrUtil.isNotBlank(param.getApprovalNo()), StoreDiscountApprovalPo::getApprovalNo, param.getApprovalNo())
                        .eq(StrUtil.isNotBlank(param.getApprovalStatus()), StoreDiscountApprovalPo::getApprovalStatus, param.getApprovalStatus())
                        .like(StrUtil.isNotBlank(param.getCreateUser()), StoreDiscountApprovalPo::getCreateUser, param.getCreateUser())
                        .ge(Objects.nonNull(param.getCreateTimeStart()), BasePo::getCreateTime, param.getCreateTimeStart())
                        .le(Objects.nonNull(param.getCreateTimeEnd()), BasePo::getCreateTime, param.getCreateTimeEnd())
                        .orderByDesc(StoreDiscountApprovalPo::getId)
        );
        Map<String, String> codeAndNameMap = baseDataQuery.getCodeAndNameMap(
                DictEnum.StoreDiscountApprovalStatus.getDictCode());
        BasePageData<StoreDiscountApprovalDto> pageData = new BasePageData<>(page);
        pageData.setRecords(page.getRecords().stream().map(item -> {
            StoreDiscountApprovalDto dto = BeanCopierUtil.copy(item, StoreDiscountApprovalDto.class);
            dto.setApprovalStatusName(codeAndNameMap.get(item.getApprovalStatus()));
            if (StrUtil.isNotEmpty(item.getProcInstId())) {
                dto.setProcInstDetailUrl(String.format(detailPageUrl, item.getProcInstId()));
            }

            return dto;
        }).collect(Collectors.toList()));
        return pageData;
    }

    /**
     * 删除
     */
    @Override
    public void deleteById(IdReq req) {
        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_DISCOUNT_APPROVAL_OPERATE_KEY, req.getId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            StoreDiscountApprovalPo po = checkAndGetApprovalPo(req.getId(), req.getBizType());
            if (!StoreDiscountApprovalStatusEnum.canDelete(po.getApprovalStatus())) {
                throw new BizException("该状态审批单不支持删除");
            }
            if (po.getIsDel()) {
                return;
            }
            removeById(po.getId());
            storeDiscountApprovalDetailService.remove(Wrappers.lambdaQuery(StoreDiscountApprovalDetailPo.class).eq(StoreDiscountApprovalDetailPo::getApprovalId, po.getId()));
            commonFileAttachmentService.update(Wrappers.lambdaUpdate(CommonFileAttachmentPo.class)
                    .eq(CommonFileAttachmentPo::getOrderNo, po.getId().toString())
                    .eq(CommonFileAttachmentPo::getBizType, req.getBizType())
                    .eq(CommonFileAttachmentPo::getSourceTable, TABLE_NAME)
                    .set(CommonFileAttachmentPo::getIsDel, true)
                    .set(CommonFileAttachmentPo::getUpdateUser, UserUtil.getUserName())
                    .set(CommonFileAttachmentPo::getUpdateTime, LocalDateTime.now())
            );
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    /**
     * 创建临时记录
     */
    @Override
    public Long createTempRecord(SpsBaseReq req) {
        StoreDiscountApprovalPo crate = new StoreDiscountApprovalPo();
        crate.setBizType(req.getBizType());
        crate.setApprovalStatus(StoreDiscountApprovalStatusEnum.TEMP.getItemCode());
        crate.setIsDel(Boolean.TRUE);
        crate.setCreateUser(UserUtil.getUserName());
        save(crate);
        return crate.getId();
    }

    /**
     * 启用临时记录
     */
    @Override
    public void enableTempRecord(IdReq req) {
        int row = storeDiscountApprovalMapper.enableTempRecord(req.getId(), req.getBizType());
        StoreDiscountApprovalPo po = checkAndGetApprovalPo(req.getId(), req.getBizType());
        checkEffectiveStartTime(req);
        if (row > 0 && StoreDiscountApprovalStatusEnum.TEMP.getItemCode().equals(po.getApprovalStatus())) {
            StoreDiscountApprovalPo update = new StoreDiscountApprovalPo();
            update.setId(po.getId());
            update.setApprovalNo(generateSerialNo(po.getBizType()));
            update.setApprovalStatus(StoreDiscountApprovalStatusEnum.WAIT_COMMIT.getItemCode());
            updateById(update);
        }
    }

    /**
     * 提交
     */
    @Override
    public void commit(IdReq request) {
        ((StoreDiscountApprovalServiceImpl) AopContext.currentProxy()).enableTempRecord(request);

        String redisKey = String.format(BaseConstants.RedisKey.SPS_ORDER_STORE_DISCOUNT_APPROVAL_OPERATE_KEY, request.getId());
        RLock rLock = redissonClient.getLock(redisKey);
        try {
            rLock.lock();

            StoreDiscountApprovalPo po = checkAndGetApprovalPo(request.getId(), request.getBizType());
            checkEffectiveStartTime(request);
            if (StoreDiscountApprovalStatusEnum.WAIT_AUDIT.getItemCode().equals(po.getApprovalStatus())) {
                throw new BizException("请勿重复提交");
            }
            if (!StoreDiscountApprovalStatusEnum.canCommit(po.getApprovalStatus())) {
                throw new BizException("该状态审批单不支持提交");
            }

            String procInstId = addWorkOrder(request, po);

            StoreDiscountApprovalPo update = new StoreDiscountApprovalPo();
            update.setId(po.getId());
            update.setProcInstId(procInstId);
            update.setApprovalStatus(StoreDiscountApprovalStatusEnum.WAIT_AUDIT.getItemCode());
            updateById(update);
        } finally {
            if (rLock.isLocked()) {
                rLock.unlock();
            }
        }
    }

    /**
     * 工单 callback
     */
    @Override
    public void workOrderCallBack(WorkOrderCallBackDto callBackDto) {
        WorkOrderStatusEnum workOrderStatusEnum = WorkOrderStatusEnum.getByStatus(callBackDto.getOrderStatus());
        if (Objects.isNull(workOrderStatusEnum) || !WorkOrderStatusEnum.isEndStatus(workOrderStatusEnum)) {
            return;
        }
        StoreDiscountApprovalPo po = checkAndGetApprovalPo(Long.valueOf(callBackDto.getExtBizNo()));
        updateApprovalStatus(workOrderStatusEnum, po);

        if (WorkOrderStatusEnum.APPROVED.equals(workOrderStatusEnum)) {
            List<StoreDiscountApprovalDetailPo> detailPoList = storeDiscountApprovalDetailService.list(Wrappers.lambdaQuery(StoreDiscountApprovalDetailPo.class)
                    .eq(StoreDiscountApprovalDetailPo::getApprovalId, po.getId())
                    .eq(StoreDiscountApprovalDetailPo::getBizType, po.getBizType()));
            if (CollUtil.isEmpty(detailPoList)) {
                return;
            }
            storeDiscountService.insertOrUpdate(detailPoList);
        }
    }

    private void updateApprovalStatus(WorkOrderStatusEnum workOrderStatusEnum, StoreDiscountApprovalPo po) {
        LambdaUpdateWrapper<StoreDiscountApprovalPo> updateWrapper = Wrappers.lambdaUpdate(StoreDiscountApprovalPo.class);
        switch (workOrderStatusEnum) {
            case APPROVED:
                updateWrapper.set(StoreDiscountApprovalPo::getApprovalStatus, StoreDiscountApprovalStatusEnum.AUDITED.getItemCode());
                break;
            case REFUSED:
                updateWrapper.set(StoreDiscountApprovalPo::getApprovalStatus, StoreDiscountApprovalStatusEnum.REJECTED.getItemCode());
                break;
            case CANCELLED:
                updateWrapper.set(StoreDiscountApprovalPo::getApprovalStatus, StoreDiscountApprovalStatusEnum.WAIT_COMMIT.getItemCode())
                        .set(StoreDiscountApprovalPo::getProcInstId, "");
                break;
            default:
                break;
        }
        updateWrapper.eq(StoreDiscountApprovalPo::getId, po.getId());
        update(null, updateWrapper);
    }

    private String addWorkOrder(IdReq request, StoreDiscountApprovalPo discountApprovalPo) {
        FileDto fileDto = storeDiscountApprovalDetailService.generateExcel(request);
        if (Objects.isNull(fileDto)) {
            throw new BizException("请添加折扣明细");
        }
        List<CommonFileAttachmentPo> attachmentList = commonFileAttachmentService.list(
                Wrappers.lambdaQuery(CommonFileAttachmentPo.class)
                        .eq(CommonFileAttachmentPo::getSourceTable, StoreDiscountApprovalServiceImpl.TABLE_NAME)
                        .eq(CommonFileAttachmentPo::getIsDel, false)
                        .eq(CommonFileAttachmentPo::getBizType, request.getBizType())
                        .eq(CommonFileAttachmentPo::getOrderNo, request.getId())
        );
        WorkOrderAddReq workOrderAddReq = WorkOrderAddReq.builder()
                .extBizNo(request.getId().toString())
                .userName(UserUtil.getLoginUserInfo().getUsername().replace("_uat", ""))
                .formTemplateId(formTemplateId)
                .formContent(StoreDiscountApprovalFormContentDto.builder()
                        .approvalNo(discountApprovalPo.getApprovalNo())
                        .createUser(discountApprovalPo.getCreateUser())
                        .createTime(DateUtils.format(discountApprovalPo.getCreateTime(), DateUtils.STANDARD_TIME_FORMAT))
                        .detail(Lists.newArrayList(StoreDiscountApprovalFormContentDto.FileInfo.builder()
                                .name(fileDto.getName())
                                .size(fileDto.getLength())
                                .url(fileDto.getUrl())
                                .build()))
                        .attachments(attachmentList.stream().map(item -> StoreDiscountApprovalFormContentDto.FileInfo.builder()
                                .name(item.getFileName())
                                .size(item.getFileLength())
                                .url(item.getFileUrl())
                                .build()).collect(Collectors.toList()))
                        .build())
                .build();
        BaseResult<List<String>> baseResult = workOrderClient.addOrder(workOrderAddReq);
        log.info("StoreDiscountApprovalServiceImpl#s, param: {}, result: {}", JsonUtil.ObjectToJson(workOrderAddReq), JsonUtil.ObjectToJson(baseResult));
        if (!baseResult.isSuccess() || CollUtil.isEmpty(baseResult.getData())) {
            throw new BizException("创建工单失败");
        }
        return baseResult.getData().get(0);
    }

    /**
     * 校验有效开始日期
     */
    private void checkEffectiveStartTime(IdReq request) {
        List<StoreDiscountApprovalDetailPo> detailList = storeDiscountApprovalDetailService.list(
                Wrappers.lambdaQuery(StoreDiscountApprovalDetailPo.class)
                        .eq(StoreDiscountApprovalDetailPo::getApprovalId, request.getId()));
        for (StoreDiscountApprovalDetailPo detailPo : detailList) {
            if (Objects.isNull(detailPo.getEffectiveStartTime())) {
                throw new BizException("有效开始日期不能为空");
            }
            if (detailPo.getEffectiveStartTime().toLocalDate().isBefore(LocalDate.now())) {
                throw new BizException("有效开始日期必须大于或等于当前日期");
            }
        }
    }

    private StoreDiscountApprovalPo checkAndGetApprovalPo(Long approvalId, String bizType) {
        StoreDiscountApprovalPo po = storeDiscountApprovalMapper.getById(approvalId, bizType);
        if (Objects.isNull(po)) {
            throw new BizException("门店折扣审批单号不存在");
        }
        return po;
    }

    private StoreDiscountApprovalPo checkAndGetApprovalPo(Long id) {
        StoreDiscountApprovalPo po = storeDiscountApprovalMapper.selectOne(Wrappers.lambdaQuery(StoreDiscountApprovalPo.class)
                .eq(StoreDiscountApprovalPo::getId, id));
        if (Objects.isNull(po)) {
            throw new BizException(SpsResponseCodeEnum.RECORD_NOT_EXIST);
        }
        return po;
    }

    private String generateSerialNo(String bizType) {
        String dateFormat = DateUtils.format(LocalDateTime.now(), BaseConstants.DatePattern.NO_DATE);
        String redisKey = String.format(BaseConstants.RedisKey.STORE_DISCOUNT_APPROVAL_SERIAL_NO_KEY, bizType, dateFormat);
        Long serialNo = redisUtil.incrAndExpire(redisKey, BaseConstants.RedisConstants.STORE_DISCOUNT_APPROVAL_SERIAL_NO_DELTA, 24 * 60 * 60);
        return dateFormat.concat(String.format("%03d", serialNo));
    }

}
