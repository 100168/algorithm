package com.jiduauto.sps.order.server.client.resp;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.jiduauto.javakit.common.util.JsonUtil;
import lombok.Data;

import java.util.Objects;

@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class StockPutOutSyncResp {

    private ClassMessageBody MessageBody;

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBody {
        private ClassMessageBodyHeader Header;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyHeader {
        private String Receiver;
        private String Header_Key;
        private String requestNo;
        private String Message_Status;
        private String Message_Text;
    }

    public static boolean success(StockPutOutSyncResp resp) {
        if (Objects.isNull(resp)) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody())) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody().getHeader())) {
            return false;
        } else {
            return "S".equals(resp.getMessageBody().getHeader().getMessage_Status());
        }
    }

    public static StockPutOutSyncResp failedResp(String message) {
        StockPutOutSyncResp resp = new StockPutOutSyncResp();
        resp.setMessageBody(new ClassMessageBody());
        resp.getMessageBody().setHeader(new ClassMessageBodyHeader());
        resp.getMessageBody().getHeader().setMessage_Status("fallback");
        resp.getMessageBody().getHeader().setMessage_Text(message);
        return resp;
    }

    public static String errorMessage(String desc) {
        if (desc == null || !desc.startsWith("{\"MessageBody\"")) {
            return desc;
        }
        try {
            StockPutOutSyncResp resp = JsonUtil.fromJsonStr(desc, StockPutOutSyncResp.class);
            return resp.getMessageBody().getHeader().getMessage_Text();
        } catch (Exception e) {
            return desc;
        }
    }
}
