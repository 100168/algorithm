package com.jiduauto.sps.order.server.pojo;

import com.jiduauto.sps.order.server.pojo.dto.PurchaseOrderTransferContextDto;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.PurchaseOrderStatusEnum;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PurchaseOrderStatusChangeDto {

    /**
     * 采购订单
     */
    private PurchaseOrderPo purchaseOrderPo;

    private PurchaseOrderTransferContextDto transferContextDto;

    /**
     * 新的订单状态
     */
    private PurchaseOrderStatusEnum newOrderStatus;

    /**
     * 变更备注
     */
    private String remark;

    /**
     * 操作行为
     */
    private OperateEnum operateEnum;

    /**
     * 操作用户
     */
    private String operateUser;
}
