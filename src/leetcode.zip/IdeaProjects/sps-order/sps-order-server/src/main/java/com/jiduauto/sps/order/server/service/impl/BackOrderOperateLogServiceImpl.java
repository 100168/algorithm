package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.convertor.BackOrderOperateLogConvertor;
import com.jiduauto.sps.order.server.mapper.BackOrderOperateLogMapper;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderOperateLogDto;
import com.jiduauto.sps.order.server.pojo.dto.BackOrderStatusChangeDto;
import com.jiduauto.sps.order.server.service.IBackOrderOperateLogService;
import com.jiduauto.sps.sdk.enums.ColumnEnum;
import com.jiduauto.sps.sdk.pojo.po.BackOrderOperateLogPo;
import com.jiduauto.sps.sdk.pojo.req.BackOrderOperateSearchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 缺件订单操作记录 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Service
public class BackOrderOperateLogServiceImpl extends ServiceImpl<BackOrderOperateLogMapper, BackOrderOperateLogPo> implements IBackOrderOperateLogService {

    @Resource
    private BackOrderOperateLogConvertor backOrderOperateLogConvertor;

    @Override
    public BasePageData<BackOrderOperateLogDto> pageSearch(
            BasePageParam<BackOrderOperateSearchReq> pageSearchReq) {
        BackOrderOperateSearchReq param = pageSearchReq.getParam();
        Page<BackOrderOperateLogPo> orderOperateLogPoPage = page(
                new Page<>(pageSearchReq.getPage(), pageSearchReq.getSize()),
                Wrappers.<BackOrderOperateLogPo>lambdaQuery()
                        .eq(BackOrderOperateLogPo::getBizType, param.getBizType())
                        .eq(BackOrderOperateLogPo::getBackOrderNo, param.getBackOrderNo())
                        .orderByDesc(BackOrderOperateLogPo::getId)
        );
        BasePageData<BackOrderOperateLogDto> res = new BasePageData<>(orderOperateLogPoPage);

        res.setRecords(backOrderOperateLogConvertor.toDtoList(orderOperateLogPoPage.getRecords()));
        return res;
    }

    @Override
    public void saveStatusChangeLog(BackOrderStatusChangeDto changeDto) {
        BackOrderOperateLogPo backOrderOperateLogPo = new BackOrderOperateLogPo();
        backOrderOperateLogPo.setBizType(changeDto.getBackOrderPo().getBizType());
        backOrderOperateLogPo.setBackOrderNo(changeDto.getBackOrderPo().getBackOrderNo());
        backOrderOperateLogPo.setActionDesc(changeDto.getOperateEnum().getDesc());
        backOrderOperateLogPo.setModifyColumn(ColumnEnum.STATUS.getDesc());
        backOrderOperateLogPo.setOldValue(changeDto.getBackOrderPo().getBackOrderStatus());
        backOrderOperateLogPo.setNewValue(changeDto.getNewStatusEnum().getCode());
        backOrderOperateLogPo.setCreateUser(changeDto.getOperateUser());
        backOrderOperateLogPo.setRemark(changeDto.getRemark());
        baseMapper.insert(backOrderOperateLogPo);
    }
}
