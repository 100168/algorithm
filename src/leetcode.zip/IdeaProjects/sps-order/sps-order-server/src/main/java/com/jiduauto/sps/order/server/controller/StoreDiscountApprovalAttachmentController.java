package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.service.impl.StoreDiscountApprovalAttachmentService;
import com.jiduauto.sps.sdk.pojo.dto.CommonFileAttachmentDto;
import com.jiduauto.sps.sdk.pojo.req.IdReq;
import com.jiduauto.sps.sdk.pojo.req.ItemIdReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 折扣单附件
 */
@RestController
@RequestMapping("/storeDiscountApproval/attachment")
public class StoreDiscountApprovalAttachmentController {

    @Resource
    private StoreDiscountApprovalAttachmentService storeDiscountApprovalAttachmentService;

    /**
     * 上传
     */
    @PostMapping("/upload")
    public BaseResult<String> upload(@RequestHeader("bizType") String bizType,
                             @RequestParam("approvalId") Long approvalId,
                             @RequestPart("files") MultipartFile[] files) {
        storeDiscountApprovalAttachmentService.upload(bizType, approvalId, files);
        return BaseResult.OK();
    }

    /**
     * 删除
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid ItemIdReq request) {
        storeDiscountApprovalAttachmentService.delete(request);
        return BaseResult.OK();
    }

    /**
     * 分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<CommonFileAttachmentDto>> pageSearch(@RequestBody @Valid BasePageParam<IdReq> pageSearchReq) {
        return BaseResult.OK(storeDiscountApprovalAttachmentService.pageSearch(pageSearchReq));
    }
}
