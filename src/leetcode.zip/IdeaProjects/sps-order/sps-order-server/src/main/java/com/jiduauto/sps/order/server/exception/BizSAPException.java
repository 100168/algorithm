package com.jiduauto.sps.order.server.exception;
import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.enums.SpsResponseCodeEnum;
import lombok.Data;

/**
 * @Author xKun
 * @Date 2021/12/7 19:18
 * @Version 1.0
 * @Desc 自定义业务异常
 */
@Data
public class BizSAPException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    //日志关联id
    private Object logRelId;
    //错误码
    private Integer errCode;
    //错误内容
    private String errMessage;

    //私有无参构造
    private BizSAPException(){
        super();
    }

    //构造器1：错误内容
    public BizSAPException(String errMessage){
        super(errMessage);
        this.errCode = GlobalCodeEnum.GL_FAIL_9994.getCode();
        this.errMessage = errMessage;
    }

    public BizSAPException(String errMessage, Object logRelId){
        super(errMessage);
        this.errCode = GlobalCodeEnum.GL_FAIL_9994.getCode();
        this.errMessage = errMessage;
        this.logRelId = logRelId;
    }

    //构造器2：code，message
    public BizSAPException(Integer errCode, String errMessage){
        super(errMessage);
        this.errMessage = errMessage;
        this.errCode = errCode;
    }

    public BizSAPException(Integer errCode, String errMessage, Object logRelId){
        super(errMessage);
        this.errMessage = errMessage;
        this.errCode = errCode;
        this.logRelId = logRelId;
    }

    //构造器3：通过GlobalCodeEnum
    public BizSAPException(GlobalCodeEnum codeEnum){
        super(codeEnum.getDesc());
        this.errMessage = codeEnum.getDesc();
        this.errCode = codeEnum.getCode();
    }

    public BizSAPException(GlobalCodeEnum codeEnum, Object logRelId){
        super(codeEnum.getDesc());
        this.errMessage = codeEnum.getDesc();
        this.errCode = codeEnum.getCode();
        this.logRelId = logRelId;
    }

    //构造器4：通过GlobalCodeEnum
    public BizSAPException(GlobalCodeEnum codeEnum, String errMessage){
        super(errMessage);
        this.errMessage = errMessage;
        this.errCode = codeEnum.getCode();
    }

    public BizSAPException(GlobalCodeEnum codeEnum, String errMessage, Object logRelId){
        super(errMessage);
        this.errMessage = errMessage;
        this.errCode = codeEnum.getCode();
        this.logRelId = logRelId;
    }



    public BizSAPException(SpsResponseCodeEnum codeEnum){
        super(codeEnum.getDesc());
        this.errMessage = codeEnum.getDesc();
        this.errCode = codeEnum.getCode();
    }
}
