package com.jiduauto.sps.order.server.client.resp;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import lombok.Data;

import java.util.Objects;

@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class DfsOrderPlanSyncResp {

    private ClassMessageBody[] MessageBody;

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBody {
        private ClassMessageBodyHeader Header;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyHeader {
        private String Receiver;
        private String Header_Key;
        private String ZSRMPO;
        private String EBELN;
        private String Message_Status;
        private String Message_Text;
    }

    public static boolean success(DfsOrderPlanSyncResp resp) {
        if (Objects.isNull(resp)) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody()) || resp.getMessageBody().length == 0) {
            return false;
        } else if (Objects.isNull(resp.getMessageBody()[0].getHeader())) {
            return false;
        } else {
            return "S".equals(resp.getMessageBody()[0].getHeader().getMessage_Status());
        }
    }

    public static DfsOrderPlanSyncResp failedResp(String message) {
        DfsOrderPlanSyncResp resp = new DfsOrderPlanSyncResp();
        resp.setMessageBody(new ClassMessageBody[]{new ClassMessageBody()});
        resp.getMessageBody()[0].setHeader(new ClassMessageBodyHeader());
        resp.getMessageBody()[0].getHeader().setMessage_Status("fallback");
        resp.getMessageBody()[0].getHeader().setMessage_Text(message);
        return resp;
    }

    public static String errorMessage(String desc) {
        if (desc == null || !desc.startsWith("{\"MessageBody\"")) {
            return desc;
        }
        try {
            DfsOrderPlanSyncResp resp = JsonUtil.toObject(desc, DfsOrderPlanSyncResp.class);
            return resp.getMessageBody()[0].getHeader().getMessage_Text();
        } catch (Exception e) {
            return desc;
        }
    }
}
