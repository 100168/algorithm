package com.jiduauto.sps.order.server.facade;


import com.jiduauto.sps.order.server.pojo.vo.req.WarehouseDistributeOrderAddReq;
import com.jiduauto.sps.order.server.pojo.vo.resp.WarehouseDistributeOrderAddResp;
import com.jiduauto.sps.sdk.pojo.req.IdReq;

import javax.validation.Valid;

public interface WarehouseDistributeOrderFacadeService {
    WarehouseDistributeOrderAddResp add(WarehouseDistributeOrderAddReq req);

    void create(WarehouseDistributeOrderAddReq req);

    /**拆单*/
    void fork(@Valid WarehouseDistributeOrderAddReq req);
}
