package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.pojo.fileexport.PurchaseOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.PurchaseOrderSearchReq;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 采购订单 Mapper 接口
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
@Mapper
public interface PurchaseOrderMapper extends BaseMapper<PurchaseOrderPo> {

    /**采购订单列表查询
     * @param searchReq
     * @param page
     * @return */
    IPage<PurchaseOrderPo> pageSearch(Page<PurchaseOrderPo> page, PurchaseOrderSearchReq searchReq);

    /**
     * 采购订单附带收货,取消,发货数量查询
     */
    IPage<PurchaseOrderExportDto> qtySearch(Page<PurchaseOrderPo> page, PurchaseOrderSearchReq searchReq);
}
