package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class InternalEmergencyTransferStoreDto implements Serializable {

    /**
     * 业务类型
     */
    private String bizType;

    /**
     * 门店code
     */
    private String storeCode;

    /**
     * 门店名称
     */
    private String storeName;
}
