package com.jiduauto.sps.order.server.handler.backorder;


import com.jiduauto.sps.sdk.enums.PartSaleFieldEnum;
import com.jiduauto.sps.sdk.enums.ShippingMethodEnum;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.utils.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class RoBackOrderOccupy extends BackOrderOccupy{

    @Override
    public String getShippingMethod(MaterialPo materialPo) {
        if (StringUtils.isEmpty(materialPo.getPartSaleField())) {
            return ShippingMethodEnum.EXPRESS.getCode();
        }

        PartSaleFieldEnum partSaleField = PartSaleFieldEnum.getByName(materialPo.getPartSaleField());
        switch (partSaleField) {
            case AIR_PROHIBITION:
                return ShippingMethodEnum.EXPRESS.getCode();
            case EXPRESS_PROHIBITION:
            case AIR_AND_EXPRESS_PROHIBITION:
                return ShippingMethodEnum.LTL_LAND.getCode();
            default:
                return ShippingMethodEnum.EXPRESS.getCode();
        }
    }
}
