package com.jiduauto.sps.order.server.pojo.dto;

import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.SaleOrderStatusEnum;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SaleOrderStatusChangeDto {

    /**
     * 销售订单
     */
    private SaleOrderPo saleOrderPo;

    /**
     * 新的状态
     */
    private SaleOrderStatusEnum newStatusEnum;

    /**
     * 变更备注
     */
    private String remark;

    /**
     * 操作行为
     */
    private OperateEnum operateEnum;

    /**
     * 操作用户
     */
    private String operateUser;
}
