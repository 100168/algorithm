package com.jiduauto.sps.order.server.client.resp;

import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import lombok.Data;

/**
 * @param <T>
 */
@Data
public class ResultResp<T> {
    private int code;
    private String msg;
    private T data;
    /**
     * pdp 报错信息
     */
    private String message;

    public static <T> ResultResp<T> error(Integer code, String msg) {
        ResultResp<T> BaseResult = new ResultResp<>();
        BaseResult.setCode(code);
        BaseResult.setMsg(msg);
        BaseResult.setData(null);
        return BaseResult;
    }

    public boolean isSuccess(){
        return GlobalCodeEnum.GL_SUCC_0.getCode().equals(getCode());
    }
}
