package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.service.ICommonLogService;
import com.jiduauto.sps.sdk.pojo.dto.CommonLogDto;
import com.jiduauto.sps.sdk.pojo.req.CommonLogReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 通用日志记录 前端控制器
 */
@RestController
@RequestMapping("/commonLogSpsOrder")
public class CommonLogController {
    @Resource
    private ICommonLogService commonLogService;
    /**
     * 调拨单日志分页查询
     */
    @PostMapping("/pageSearchStoreTransferLog")
    public BaseResult<BasePageData<CommonLogDto>> pageSearchStoreTransferLog(@RequestBody @Valid BasePageParam<CommonLogReq> req) {
        return BaseResult.OK(commonLogService.pageSearchStoreTransferLog(req));
    }

}
