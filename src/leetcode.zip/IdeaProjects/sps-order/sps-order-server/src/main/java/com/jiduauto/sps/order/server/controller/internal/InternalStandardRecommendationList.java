package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.sps.order.server.pojo.dto.InternalStandardRecommendationListDto;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStandardRecommendationListPage;
import com.jiduauto.sps.order.server.service.impl.StoreRecommendationListFacadeService;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 智子 标准推荐清单接口
 */
@RestController
@RequestMapping("/internal/standardRecommendationList")
public class InternalStandardRecommendationList {

    @Resource
    private StoreRecommendationListFacadeService storeRecommendationListFacadeService;

    /**
     * 标准推荐清单分页查询
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<InternalStandardRecommendationListDto>> pageSearch(@RequestBody @Valid BasePageParam<InternalStandardRecommendationListPage> pageParam) {
        return BaseResult.OK(storeRecommendationListFacadeService.standardRecommendationListPageSearch(pageParam));
    }

}
