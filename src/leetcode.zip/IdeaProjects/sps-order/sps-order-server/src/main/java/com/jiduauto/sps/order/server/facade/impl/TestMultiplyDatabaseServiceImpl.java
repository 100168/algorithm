package com.jiduauto.sps.order.server.facade.impl;

import com.alibaba.fastjson.JSON;
import com.jiduauto.sps.order.server.facade.TestMultiplyDatabaseService;
import com.jiduauto.sps.order.server.facade.proxy.TestSpsMaterialMapperProxy;
import com.jiduauto.sps.order.server.mapper.SaleOrderMapper;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class TestMultiplyDatabaseServiceImpl implements TestMultiplyDatabaseService {
    private static final Logger log = LoggerFactory.getLogger(TestMultiplyDatabaseServiceImpl.class);
    @Resource
    TestSpsMaterialMapperProxy testSpsMaterialMapperProxy;

    @Resource
    SaleOrderMapper saleOrderMapper;

    @Override
    public void testMultiplyDatabase() {
        log.info("testMultiplyDatabase");
        int result = testSpsMaterialMapperProxy.countMaterial();

        SaleOrderPo saleOrderPo =  saleOrderMapper.selectById(1);

        log.info(JSON.toJSONString(saleOrderPo));
        log.info(JSON.toJSONString(result));
    }
}
