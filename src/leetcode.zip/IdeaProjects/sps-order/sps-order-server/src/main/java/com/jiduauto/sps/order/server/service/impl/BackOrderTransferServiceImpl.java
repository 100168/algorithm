package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.google.common.collect.Maps;
import com.jiduauto.sps.order.server.mapper.BackOrderMapper;
import com.jiduauto.sps.order.server.mapper.PurchaseOrderMapper;
import com.jiduauto.sps.order.server.pojo.BackOrderTransferDto;
import com.jiduauto.sps.order.server.pojo.param.StoreCodeParam;
import com.jiduauto.sps.order.server.service.IBackOrderService;
import com.jiduauto.sps.order.server.service.IBackOrderTransferService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.PurchaseOrderTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.OrderCalendarPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class BackOrderTransferServiceImpl implements IBackOrderTransferService {

    @Value("${bo.transfer.ro-process-hour:8}")
    private Integer roProcessHour;

    //第二个bo ro 转单时间
    @Value("${bo.transfer.second-ro-process-hour:14}")
    private Integer secondRoProcessHour;

    @Value("${bo.transfer.co-process-hour:8}")
    private Integer coProcessHour;

    @Resource
    private BackOrderMapper backOrderMapper;
    @Resource
    private PurchaseOrderMapper purchaseOrderMapper;

    @Resource
    private IBackOrderService backOrderService;

    @Resource
    private BaseDataQuery baseDataQuery;

    @Override
    public void batchAutoTransferOrder() {
        List<BackOrderTransferDto> backOrderTransferDtoList = queryBackOrderTransferDto(getLastHalfOrFullHour());
        if (CollectionUtils.isNotEmpty(backOrderTransferDtoList)) {
            for (BackOrderTransferDto backOrderTransferDto : backOrderTransferDtoList) {
                backOrderService.autoTransferOrder(backOrderTransferDto);
            }
        }
    }

    /**
     * 获取VOR、RO订单待转单集合
     *
     * @return
     */
    private List<BackOrderTransferDto> queryBackOrderTransferDto(LocalDateTime processTime) {
        List<BackOrderTransferDto> backOrderTransferDtoList = new ArrayList<>();

        if (processTime.getMinute() == 0 && processTime.getSecond() == 0) { // 整点 处理VOR订单
            List<BackOrderTransferDto> vorBackOrderTransferDtoList = backOrderMapper.listPendingTransferPurchaseOrderNo(PurchaseOrderTypeEnum.VOR.getValue());
            for (BackOrderTransferDto backOrderTransferDto : vorBackOrderTransferDtoList) {
                backOrderTransferDto.setTransferTime(processTime);
            }
            backOrderTransferDtoList.addAll(vorBackOrderTransferDtoList);

            if (processTime.getHour() == roProcessHour) {   // 8点 处理RO订单
                List<BackOrderTransferDto> roBackOrderTransferDtoList = backOrderMapper.listPendingTransferPurchaseOrderNo(PurchaseOrderTypeEnum.RO.getValue());
                for (BackOrderTransferDto backOrderTransferDto : roBackOrderTransferDtoList) {
                    backOrderTransferDto.setTransferTime(processTime);
                }
                backOrderTransferDtoList.addAll(roBackOrderTransferDtoList);
            }

            if (processTime.getHour() == coProcessHour) {   // 8点 处理CO订单
                List<BackOrderTransferDto> roBackOrderTransferDtoList = backOrderMapper.listPendingTransferPurchaseOrderNo(PurchaseOrderTypeEnum.CO.getValue());
                for (BackOrderTransferDto backOrderTransferDto : roBackOrderTransferDtoList) {
                    backOrderTransferDto.setTransferTime(processTime);
                }
                backOrderTransferDtoList.addAll(roBackOrderTransferDtoList);
            }
        }

        //RO 订单 14:30 单独处理
        if (processTime.getHour() == secondRoProcessHour && processTime.getMinute() == 30) {
            List<BackOrderTransferDto> roBackOrderTransferDtoList = backOrderMapper.listPendingTransferPurchaseOrderNo(PurchaseOrderTypeEnum.RO.getValue());
            for (BackOrderTransferDto backOrderTransferDto : roBackOrderTransferDtoList) {
                backOrderTransferDto.setTransferTime(processTime);
            }
            backOrderTransferDtoList.addAll(roBackOrderTransferDtoList);
        }

        // 处理 过去半小时的STK订单
        List<BackOrderTransferDto> stkBackOrderTransferDtoList = backOrderMapper.listPendingTransferPurchaseOrderNo(PurchaseOrderTypeEnum.STK.getValue());
        Map<String, LocalDateTime> storeTransferTimeMap = getStoreTransferTimeMap(processTime.plusMinutes(-30), processTime, stkBackOrderTransferDtoList);
        for (BackOrderTransferDto backOrderTransferDto : stkBackOrderTransferDtoList) {
            backOrderTransferDto.setTransferTime(storeTransferTimeMap.get(backOrderTransferDto.getBizType().concat(backOrderTransferDto.getStoreCode())));
        }
        backOrderTransferDtoList.addAll(stkBackOrderTransferDtoList.stream().filter(item -> Objects.nonNull(item.getTransferTime())).collect(Collectors.toList()));

        fillPurchaseOrderPo(backOrderTransferDtoList);

        return backOrderTransferDtoList.stream().sorted((o1, o2) -> {
            if (o1.getTransferTime().isEqual(o2.getTransferTime())) {
                PurchaseOrderPo po1 = o1.getPurchaseOrderPo(), po2 = o2.getPurchaseOrderPo();
                if (po1.getPurchaseOrderType().equals(po2.getPurchaseOrderType())) {
                    return po1.getSapOrderCreateTime().compareTo(po2.getSapOrderCreateTime());
                } else {
                    return Integer.compare(PurchaseOrderTypeEnum.covetPriority(po1.getPurchaseOrderType()), PurchaseOrderTypeEnum.covetPriority(po2.getPurchaseOrderType()));
                }
            } else {
                return o1.getTransferTime().compareTo(o2.getTransferTime());
            }
        }).collect(Collectors.toList());
    }

    /**
     * 获取时间范围内门店转单时间Map，key=(bizType+storeCode)
     *
     * @param startTime
     * @param endTime
     * @param backOrderTransferDtoList
     * @return
     */
    private Map<String, LocalDateTime> getStoreTransferTimeMap(LocalDateTime startTime, LocalDateTime endTime, List<BackOrderTransferDto> backOrderTransferDtoList) {
        Map<String, LocalDateTime> storeTransferTimeMap = Maps.newHashMap();
        List<StoreCodeParam> storeCodeParams = backOrderTransferDtoList.stream().map(item -> BeanCopierUtil.copy(item, StoreCodeParam.class)).distinct().collect(Collectors.toList());
        if (CollectionUtils.isNotEmpty(storeCodeParams)) {
            List<OrderCalendarPo> orderCalendarPos = baseDataQuery.listOrderCalendarPo(storeCodeParams.get(0).getBizType(),storeCodeParams.stream()
                    .map(StoreCodeParam::getStoreCode)
                            .distinct()
                    .collect(Collectors.toList()));
            for (OrderCalendarPo orderCalendarPo : orderCalendarPos) {
                LocalDateTime transferTime = getStoreTransferTime(startTime, endTime, orderCalendarPo);
                if (Objects.nonNull(transferTime)) {
                    storeTransferTimeMap.put(orderCalendarPo.getBizType().concat(orderCalendarPo.getStoreCode()), transferTime);
                }
            }
        }
        return storeTransferTimeMap;
    }

    /**
     * 填充采购订单的创建时间
     *
     * @param backOrderTransferDtoList
     */
    private void fillPurchaseOrderPo(List<BackOrderTransferDto> backOrderTransferDtoList) {
        List<String> purchaseOrderNoList = backOrderTransferDtoList.stream().map(BackOrderTransferDto::getPurchaseOrderNo).collect(Collectors.toList());
        Map<String, PurchaseOrderPo> purchaseOrderPoMap = purchaseOrderMapper.selectList(Wrappers.lambdaQuery(PurchaseOrderPo.class)
                        .in(PurchaseOrderPo::getPurchaseOrderNo, purchaseOrderNoList))
                .stream().collect(Collectors.toMap(PurchaseOrderPo::getPurchaseOrderNo, Function.identity(), (p, n) -> n));
        Iterator<BackOrderTransferDto> iterator = backOrderTransferDtoList.listIterator();
        while (iterator.hasNext()) {
            BackOrderTransferDto backOrderTransferDto = iterator.next();
            if (purchaseOrderPoMap.containsKey(backOrderTransferDto.getPurchaseOrderNo())) {
                backOrderTransferDto.setPurchaseOrderPo(purchaseOrderPoMap.get(backOrderTransferDto.getPurchaseOrderNo()));
            } else {
                iterator.remove();
            }
        }
    }

    /**
     * 获取时间范围内门店的转单时间
     *
     * @param startTime
     * @param endTime
     * @param orderCalendarPo
     * @return
     */
    public static LocalDateTime getStoreTransferTime(LocalDateTime startTime, LocalDateTime endTime, OrderCalendarPo orderCalendarPo) {
        List<LocalDateTime> transferTimeCandidateList = new ArrayList<>();
        LocalDate currentDate = LocalDate.now();
        if (Objects.nonNull(orderCalendarPo.getTransferTime())) {
            transferTimeCandidateList.add(currentDate.atTime(orderCalendarPo.getTransferTime().toLocalTime()));
        }
        if (Objects.nonNull(orderCalendarPo.getTransferTime2())) {
            transferTimeCandidateList.add(currentDate.atTime(orderCalendarPo.getTransferTime2().toLocalTime()));
        }
        return transferTimeCandidateList.stream()
                .filter(item -> item.isAfter(startTime))
                .filter(item -> !item.isAfter(endTime))
                .sorted().findFirst().orElse(null);
    }

    private LocalDateTime getLastHalfOrFullHour() {
        LocalDateTime now = LocalDateTime.now();
        int minute = now.getMinute();
        if (minute >= 30) {
            return now.truncatedTo(ChronoUnit.HOURS).plusMinutes(30);
        } else {
            return now.truncatedTo(ChronoUnit.HOURS);
        }
    }
}
