package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.dit.outbox.OutboxMessageService;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.enums.LogKey;
import com.jiduauto.sps.order.server.enums.StoreTransferOrderDetailModifyColum;
import com.jiduauto.sps.order.server.enums.StoreTransferOrderModifyColum;
import com.jiduauto.sps.order.server.mapper.StoreTransferOrderMapper;
import com.jiduauto.sps.order.server.pojo.dto.StoreTransferOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreTransferOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreTransferOrderOperateReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreTransferOrderReq;
import com.jiduauto.sps.order.server.service.ICommonLogService;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderDetailService;
import com.jiduauto.sps.order.server.service.IStoreTransferOrderService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.*;
import com.jiduauto.sps.sdk.pojo.dto.InAndOutStockParam;
import com.jiduauto.sps.sdk.pojo.po.*;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import com.jiduauto.sps.sdk.utils.CollectionUtils;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import com.jiduauto.sps.sdk.utils.log.CommonFieldLogService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.jiduauto.sps.sdk.consts.BaseConstants.ImportExport.PAGE_START_AT;
import static com.jiduauto.sps.sdk.consts.OutboxConst.MessageType.STORE_TRANSFER_ORDER_CANCEL_TO_SAP;

/**
 * <p>
 * 门店调拨单 服务实现类
 * </p>
 */
@Service
public class StoreTransferOrderServiceImpl extends ServiceImpl<StoreTransferOrderMapper, StoreTransferOrderPo> implements IStoreTransferOrderService {

    @Resource
    private StoreTransferOrderMapper storeTransferOrderMapper;
    @Resource
    private IStoreTransferOrderDetailService storeTransferOrderDetailService;

    @Resource
    private SpsClient spsClient;

    @Resource
    private ICommonLogService commonLogService;

    @Resource
    private OutboxMessageService outboxMessageService;
    @Resource
    private BaseDataQuery baseDataQuery;

    @Value("${MAX_SIZE_10000:10000}")
    private Integer maxSize;

    public static final CommonFieldLogService<StoreTransferOrderPo, StoreTransferOrderModifyColum> LOG_SERVICE = new CommonFieldLogService<>();
    public static final CommonFieldLogService<StoreTransferOrderDetailPo, StoreTransferOrderDetailModifyColum> DETAIL_LOG_SERVICE = new CommonFieldLogService<>();

    @Override
    public BasePageData<StoreTransferOrderDto> pageSearch(BasePageParam<StoreTransferOrderReq> pageParam) {
        StoreTransferOrderReq req = pageParam.getParam();
        IPage<StoreTransferOrderDto> page =
                storeTransferOrderMapper.pageSearch(new Page<>(pageParam.getPage(), pageParam.getSize()), req);
        if (CollectionUtils.isEmpty(page.getRecords())){
            return new BasePageData<>(page);
        }
        List<StoreTransferOrderDto> dtoList = getStoreTransferOrderDtos(page.getRecords(),
                req);
        page.setRecords(dtoList);
        return new BasePageData<>(page);
    }

    private List<StoreTransferOrderDto> getStoreTransferOrderDtos(List<StoreTransferOrderDto> list,
                                                                  StoreTransferOrderReq req) {
        List<String> organizationCodeList = new ArrayList<>();
        List<String> warehouseCodeList = new ArrayList<>();
        List<String> dictCodeList = new ArrayList<>();
        for (StoreTransferOrderDto record : list) {
            organizationCodeList.add(record.getTransferInOrganizationCode());
            organizationCodeList.add(record.getTransferOutOrganizationCode());
            warehouseCodeList.add(record.getTransferInWarehouseCode());
            warehouseCodeList.add(record.getTransferOutWarehouseCode());
        }
        BaseResult<BaseDataResp> resp = getBaseDataRespBaseResult(
                req, dictCodeList, warehouseCodeList);
        Map<String, StorePo> storePoMap = getStringStorePoMap(req, organizationCodeList);
        Map<String, WarehousePo> warehousePoMap =
                CollectionUtils.isEmpty(resp.getData().getWarehouses()) ? new HashMap<>()
                        : resp.getData().getWarehouses().stream()
                        .collect(Collectors.toMap(WarehousePo::getCode, Function.identity(), (k,
                                                                                              v) -> v));
        Map<String, Map<String, String>> map = baseDataQuery.getDictItemName(
                resp.getData().getDictItemClientDtos());
        return list.stream().peek(item -> {
                    StorePo outStore = storePoMap.getOrDefault(item.getTransferOutOrganizationCode(), new StorePo());
                    StorePo inStore = storePoMap.getOrDefault(item.getTransferInOrganizationCode(), new StorePo());
                    WarehousePo outWarehouse = warehousePoMap.getOrDefault(item.getTransferOutWarehouseCode(),
                            new WarehousePo());
                    WarehousePo inWarehouse = warehousePoMap.getOrDefault(item.getTransferInWarehouseCode(),
                            new WarehousePo());
                    item.setTransferOutOrganizationName(outStore.getStoreName());
                    item.setTransferInOrganizationName((inStore.getStoreName()));
                    item.setTransferOutWarehouseName((outWarehouse.getName()));
                    item.setTransferInWarehouseName((inWarehouse.getName()));
                    item.setOrderAttrName(map.getOrDefault(DictEnum.StoreType.getDictCode(), new HashMap<>())
                            .getOrDefault(item.getOrderAttr(), item.getOrderAttr()));
                    item.setOrderStatusName(map.getOrDefault(DictEnum.STO_STATUS.getDictCode(), new HashMap<>())
                            .getOrDefault(item.getOrderStatus(), item.getOrderStatus()));
                }
        ).collect(Collectors.toList());
    }

    private Map<String, StorePo> getStringStorePoMap(StoreTransferOrderReq req, List<String> organizationCodeList) {
        return baseDataQuery.mapStorePo(BizTypeEnum.getParentBizType(req.getBizType()), organizationCodeList, false);
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void savePoAndDetail(StoreTransferOrderPo orderPo, List<StoreTransferOrderDetailPo> detailList) {
        save(orderPo);
        storeTransferOrderDetailService.saveBatch(detailList);
    }

    /**
     * 字段变更日志记录
     */
    @Override
    public void statusLog(StoreTransferOrderStatus status,
                          StoreTransferOrderOperate opt,
                          String no,
                          String bizType,
                          String user
    ) {
        commonLogService.saveStatusLog(
                status.getValue(),
                opt.getDesc(),
                no,
                bizType,
                LogKey.store_transfer_order.getValue(),
                user,
                StoreTransferOrderModifyColum.orderStatus.getValue(),
                null
        );
    }

    /**
     * 字段变更日志记
     */
    @Override
    public void fieldLog(StoreTransferOrderPo oldData, StoreTransferOrderPo newData, String user) {
        List<CommonLogPo> detailLogPos = LOG_SERVICE.buildOperateLogs(oldData, newData, StoreTransferOrderModifyColum.class, user);
        commonLogService.saveBatch(detailLogPos);
    }

    /**
     * 详情字段变更日志记
     */
    @Override
    public void detailFieldLog(StoreTransferOrderDetailPo oldData, StoreTransferOrderDetailPo newData, String user) {
        List<CommonLogPo> detailLogPos = DETAIL_LOG_SERVICE.buildOperateLogs(oldData, newData, StoreTransferOrderDetailModifyColum.class, user);
        detailLogPos.forEach(o -> o.setRemark(String.format("零件号[%s]", oldData.getMaterialCode())));
        commonLogService.saveBatch(detailLogPos);
    }

    /**
     * 取消
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancelOrder(InternalStoreTransferOrderOperateReq req) {
        // 状态为 待提交时， 不用同步SAP
        StoreTransferOrderPo po = getOne(Wrappers.lambdaQuery(StoreTransferOrderPo.class)
                .eq(StoreTransferOrderPo::getOrderNo, req.getOrderNo()));
        if (StoreTransferOrderStatus.WAIT_COMMIT.getValue().equals(po.getOrderStatus())) {
            updateStatusAndLog(req.getOrderNo(), StoreTransferOrderStatus.CANCELED, req.getOperateUser(), StoreTransferOrderOperate.CANCEL);
            return;
        }

        // 102 不同步sap
        if (!StoreTransferOrderAttrEnum.Z2.getCode().equals(po.getOrderAttr())) {
            outboxMessageService.saveMessage(STORE_TRANSFER_ORDER_CANCEL_TO_SAP, JsonUtil.toJsonString(req));
            return;
        }

        //非直营门店，直接更新状态
        updateStatusAndLog(req.getOrderNo(), StoreTransferOrderStatus.CANCELED, req.getOperateUser(), StoreTransferOrderOperate.CANCEL);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStatusAndLog(String no, StoreTransferOrderStatus status, String user, StoreTransferOrderOperate opt) {
        update(Wrappers.lambdaUpdate(StoreTransferOrderPo.class)
                .eq(StoreTransferOrderPo::getOrderNo, no)
                .set(StoreTransferOrderPo::getOrderStatus, status.getValue())
                .set(StoreTransferOrderPo::getUpdateUser, user)
                .set(StoreTransferOrderStatus.CONFIRM == status, StoreTransferOrderPo::getConfirmUser, user)
        );
        statusLog(status, opt, no, BizTypeEnum.SS.getBizType(), user);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateTransferOutQty(InAndOutStockRequest request) {

        List<InAndOutStockParam> params = request.getParams();
        StoreTransferOrderPo transferOrderPo = getOne(Wrappers.<StoreTransferOrderPo>lambdaQuery().eq(StoreTransferOrderPo::getOrderNo, request.getTradeNo()));
        //已经出过库不做处理
        if (StoreTransferOrderStatus.ALL_OUT.getValue().equals(transferOrderPo.getOrderStatus())) {
            return;
        }
        //只能出一次
        transferOrderPo.setOrderStatus(StoreTransferOrderStatus.ALL_OUT.getValue());
        List<StoreTransferOrderDetailPo> detailPos = storeTransferOrderDetailService.listByOrderNo(request.getTradeNo());
        Map<String, BigDecimal> paramMap = params.stream().collect(Collectors.toMap(InAndOutStockParam::getMaterialCode, InAndOutStockParam::getSumQuantity, BigDecimal::add));
        for (StoreTransferOrderDetailPo detailPo : detailPos) {
            StoreTransferOrderDetailPo oldDetailPo = BeanCopierUtil.copy(detailPo, StoreTransferOrderDetailPo.class);
            detailPo.setTransferOutQty(paramMap.getOrDefault(detailPo.getMaterialCode(), BigDecimal.ZERO));
            //记录数量变更日志
            detailFieldLog(oldDetailPo, detailPo, request.getOperateUser());
        }
        transferOrderPo.setUpdateTime(LocalDateTime.now());
        //记录状态变更日志
        statusLog(StoreTransferOrderStatus.ALL_OUT,
                StoreTransferOrderOperate.DELIVERED,
                transferOrderPo.getOrderNo(),
                transferOrderPo.getBizType(),
                request.getOperateUser());
        updateById(transferOrderPo);
        storeTransferOrderDetailService.updateBatchById(detailPos);
    }

    @Override
    public void updateTransferInQty(InAndOutStockRequest request) {

        List<InAndOutStockParam> params = request.getParams();
        StoreTransferOrderPo transferOrderPo = getOne(Wrappers.<StoreTransferOrderPo>lambdaQuery().eq(StoreTransferOrderPo::getOrderNo, request.getTradeNo()));
        //已经入过库不做处理
        if (StoreTransferOrderStatus.ALL_IN.getValue().equals(transferOrderPo.getOrderStatus())) {
            return;
        }
        List<StoreTransferOrderDetailPo> detailPos = storeTransferOrderDetailService.listByOrderNo(request.getTradeNo());
        Map<String, BigDecimal> paramMap = params.stream().collect(Collectors.toMap(InAndOutStockParam::getMaterialCode, InAndOutStockParam::getSumQuantity, BigDecimal::add));
        for (StoreTransferOrderDetailPo detailPo : detailPos) {
            StoreTransferOrderDetailPo oldDetailPo = BeanCopierUtil.copy(detailPo, StoreTransferOrderDetailPo.class);
            detailPo.setTransferInQty(paramMap.getOrDefault(detailPo.getMaterialCode(), BigDecimal.ZERO));
            //记录数量变更日志
            detailFieldLog(oldDetailPo, detailPo, request.getOperateUser());
        }
        //只能入一次
        transferOrderPo.setOrderStatus(StoreTransferOrderStatus.ALL_IN.getValue());
        transferOrderPo.setUpdateTime(LocalDateTime.now());
        statusLog(StoreTransferOrderStatus.ALL_IN,
                StoreTransferOrderOperate.RECEIVED,
                transferOrderPo.getOrderNo(),
                transferOrderPo.getBizType(),
                request.getOperateUser());
        updateById(transferOrderPo);
        storeTransferOrderDetailService.updateBatchById(detailPos);
    }

    /**
     * 调拨单导出
     */
    @Override
    public Collection<StoreTransferOrderExportDto> export(BasePageParam<StoreTransferOrderReq> pageParam) {
        List<StoreTransferOrderExportDto> cur;
        List<StoreTransferOrderExportDto> all = new ArrayList<>();
        pageParam.setSize(2000);
        //限制导出最大1万条
        int count = PAGE_START_AT;
        while (all.size() < maxSize && !(cur = storeTransferOrderMapper.export(
                new Page<>(pageParam.getPage(), pageParam.getSize()), pageParam.getParam()).getRecords()).isEmpty()) {
            pageParam.setPage(++count);
            all.addAll(cur);
        }
        if (CollectionUtils.isEmpty(all)){
            return new ArrayList<>();
        }
        return getStoreTransferOrderExportDtos(all,
                pageParam.getParam());
    }

    private List<StoreTransferOrderExportDto> getStoreTransferOrderExportDtos(List<StoreTransferOrderExportDto> list,
                                                                              StoreTransferOrderReq req) {
        List<String> organizationCodeList = new ArrayList<>();
        List<String> warehouseCodeList = new ArrayList<>();
        List<String> dictCodeList = new ArrayList<>();
        List<String> materialCodes = new ArrayList<>();
        for (StoreTransferOrderExportDto record : list) {
            organizationCodeList.add(record.getTransferInOrganizationCode());
            organizationCodeList.add(record.getTransferOutOrganizationCode());
            warehouseCodeList.add(record.getTransferInWarehouseCode());
            warehouseCodeList.add(record.getTransferOutWarehouseCode());
            materialCodes.add(record.getMaterialCode());
        }
        dictCodeList.add(DictEnum.StoreType.getDictCode());
        dictCodeList.add(DictEnum.STO_STATUS.getDictCode());
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(req.getBizType());
        baseDataReq.setWarehouseCodes(warehouseCodeList);
        baseDataReq.setDictCodes(dictCodeList);
        baseDataReq.setMaterialCodes(materialCodes);
        Map<String, StorePo> storePoMap = getStringStorePoMap(req, organizationCodeList);
        BaseResult<BaseDataResp> resp = spsClient.searchBaseData(baseDataReq);
        Map<String, Map<String, String>> map = baseDataQuery.getDictItemName(
                resp.getData().getDictItemClientDtos());
        Map<String, WarehousePo> warehousePoMap =
                CollectionUtils.isEmpty(resp.getData().getWarehouses()) ? new HashMap<>()
                        : resp.getData().getWarehouses().stream()
                        .collect(Collectors.toMap(WarehousePo::getCode, Function.identity(), (k,
                                                                                              v) -> v));
        Map<String, MaterialPo> materialPoMap =
                CollectionUtils.isEmpty(resp.getData().getMaterials()) ? new HashMap<>()
                        : resp.getData().getMaterials().stream()
                        .collect(Collectors.toMap(MaterialPo::getSalePartNum, Function.identity(), (k,
                                                                                                    v) -> v));
        return list.stream().peek(item -> {
                    StorePo inStore = storePoMap.getOrDefault(item.getTransferInOrganizationCode(), new StorePo());
                    StorePo outStore = storePoMap.getOrDefault(item.getTransferOutOrganizationCode(), new StorePo());
                    WarehousePo inWarehouse = warehousePoMap.getOrDefault(item.getTransferInWarehouseCode(),
                            new WarehousePo());
                    WarehousePo outWarehouse = warehousePoMap.getOrDefault(item.getTransferOutWarehouseCode(),
                            new WarehousePo());
                    MaterialPo orDefault = materialPoMap.getOrDefault(item.getMaterialCode(), new MaterialPo());
                    item.setMaterialName(orDefault.getMaterialName());
                    item.setTransferInOrganizationName((inStore.getStoreName()));
                    item.setTransferOutOrganizationName(outStore.getStoreName());
                    item.setTransferOutWarehouseName((outWarehouse.getName()));
                    item.setTransferInWarehouseName((inWarehouse.getName()));
                    item.setOrderAttr(map.getOrDefault(DictEnum.StoreType.getDictCode(), new HashMap<>())
                            .getOrDefault(item.getOrderAttr(), item.getOrderAttr()));
                    item.setOrderStatus(map.getOrDefault(DictEnum.STO_STATUS.getDictCode(), new HashMap<>())
                            .getOrDefault(item.getOrderStatus(), item.getOrderStatus()));
                }
        ).collect(Collectors.toList());
    }

    private BaseResult<BaseDataResp> getBaseDataRespBaseResult(StoreTransferOrderReq req, List<String> dictCodeList,
                                                               List<String> warehouseCodeList) {
        dictCodeList.add(DictEnum.StoreType.getDictCode());
        dictCodeList.add(DictEnum.STO_STATUS.getDictCode());
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(req.getBizType());
        baseDataReq.setWarehouseCodes(warehouseCodeList);
        baseDataReq.setDictCodes(dictCodeList);
        return spsClient.searchBaseData(baseDataReq);
    }

}
