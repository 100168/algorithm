package com.jiduauto.sps.order.server.client.req;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.google.common.collect.Lists;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.SapPurchaseOrderAttrEnum;
import com.jiduauto.sps.sdk.enums.SapPurchaseOrderTypeEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.pojo.po.WarehousePo;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Data
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
public class PurchaseOrderSyncReq {

    private final static DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern(
            BaseConstants.DatePattern.DATETIME);
    private final static DateTimeFormatter NONE_DATE_FORMATTER = DateTimeFormatter.ofPattern(
            BaseConstants.DatePattern.NONE_DATE);
    private final static DateTimeFormatter NONE_TIME_FORMATTER = DateTimeFormatter.ofPattern(
            BaseConstants.DatePattern.NONE_TIME);

    private ClassMessageHeader MessageHeader;
    private ClassMessageBody MessageBody;


    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageHeader {

        private String Sender;
        private Long SerialNum;
        private String InterfaceID;
        private String SendDate;
        private String SendTime;
        private String Reserve1;
        private String Reserve2;
        private String Reserve3;
        private String Reserve4;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBody {

        private ClassMessageBodyHeader Header;
        private List<ClassMessageBodyItem> Item1;
    }


    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyHeader {

        private String Receiver;
        private String Header_Key;
        private String ZTYPE;
        private String AUART;
        private String KUNNR;
        private String BSTNK;
        private String BSTDK;
        private String ZRETURN;
        private String WERKS;
        private String Reserve1;
        private String Reserve2;
        private String Reserve3;
        private String Reserve4;
        private String Reserve5;
    }

    @Data
    @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility = JsonAutoDetect.Visibility.NONE)
    public static class ClassMessageBodyItem {

        private String Item_Key;
        private String POSNR;
        private String MATNR;
        private String WERKS;
        private String LGORT;
        private String RESLO;
        private String KWMENG;
        private String NETWR;

        private String zreserve6;
        private String zreserve7;
        private String zreserve8;
        private String zreserve9;
        private String zreserve10;

    }


    public static PurchaseOrderSyncReq newInstance() {
        PurchaseOrderSyncReq asnReceiveSyncReq = new PurchaseOrderSyncReq();
        asnReceiveSyncReq.setMessageHeader(new ClassMessageHeader());
        ClassMessageBody messageBody = new ClassMessageBody();
        messageBody.setHeader(new ClassMessageBodyHeader());
        messageBody.setItem1(Lists.newArrayList());
        asnReceiveSyncReq.setMessageBody(messageBody);

        asnReceiveSyncReq.messageHeader();
        return asnReceiveSyncReq;
    }

    public void messageHeader() {
        LocalDateTime now = LocalDateTime.now();

        MessageHeader.Sender = "SPS";
        MessageHeader.InterfaceID = "SD013";
        MessageHeader.SendDate = now.format(NONE_DATE_FORMATTER);
        MessageHeader.SendTime = now.format(NONE_TIME_FORMATTER);
        MessageBody.Header.Receiver = "SAP";
    }

    public void setPurchaseOrder(PurchaseOrderPo purchaseOrderPo) {
        String purchaseOrderNo = purchaseOrderPo.getPurchaseOrderNo();
        MessageBody.Header.Header_Key = purchaseOrderNo;
        MessageBody.Header.ZTYPE = SapPurchaseOrderAttrEnum.getValue(purchaseOrderPo.getPurchaseOrderAttr());
        MessageBody.Header.AUART = SapPurchaseOrderTypeEnum.getValue(purchaseOrderPo.getPurchaseOrderAttr());
        MessageBody.Header.KUNNR = purchaseOrderPo.getStoreCode();
        MessageBody.Header.BSTNK = purchaseOrderNo;
        MessageBody.Header.BSTDK = purchaseOrderPo.getCommitTime().format(NONE_DATE_FORMATTER);
//        MessageBody.Header.ZRETURN =
//                purchaseOrderPo.getPurchaseOrderAttr().equals(PurchaseOrderAttrEnum.SELF.getCode()) ? "X" : "";
        int length = purchaseOrderNo.length();
        int bizTypeLength = purchaseOrderPo.getBizType().length();
        MessageHeader.SerialNum = Long.valueOf(purchaseOrderNo.substring(2, length - bizTypeLength));
    }

    public PurchaseOrderSyncReq setPurchaseOrder(String purchaseOrderNo) {
        MessageBody.Header.Header_Key = purchaseOrderNo;
        return this;
    }

    public PurchaseOrderSyncReq setDetail(List<PurchaseOrderDetailPo> purchaseOrderDetailPos) throws BizException {
        purchaseOrderDetailPos.forEach(item -> {
            ClassMessageBodyItem bodyItem = new ClassMessageBodyItem();
            bodyItem.setItem_Key(item.getSalePartNum());
            bodyItem.setMATNR(item.getSalePartNum());
            bodyItem.setKWMENG(item.getQty().toString());
            bodyItem.setNETWR(item.getDiscountUnitPrice().toString());
            getMessageBody().getItem1().add(bodyItem);
        });
        return this;
    }

    public PurchaseOrderSyncReq setWarehouse(WarehousePo warehouse) {
        getMessageBody().getItem1().forEach(item -> {
            item.setLGORT(warehouse.getStockLocation());
        });
        return this;
    }
}
