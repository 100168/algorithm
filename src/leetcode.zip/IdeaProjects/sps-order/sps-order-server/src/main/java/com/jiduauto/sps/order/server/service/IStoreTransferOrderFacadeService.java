package com.jiduauto.sps.order.server.service;

import com.jiduauto.sps.order.server.pojo.dto.InternalStoreTransferOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalStoreTransferOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.sdk.pojo.po.StoreTransferOrderPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;

public interface IStoreTransferOrderFacadeService {

    /**
     * 门店创建调拨单
     */
    BaseResult<String> add(InternalStoreTransferOrderAddReq req);

    /**
     * 更新调拨单信息
     */
    BaseResult<String> updateOrder(InternalStoreTransferOrderUpdateReq req);

    /**
     * 更新订单信息
     */
    void updateOrderInfo(InternalStoreTransferOrderUpdateReq req, StoreTransferOrderPo orderPo);

    /**
     * 调拨单取消
     */
    BaseResult<String> cancelOrder(InternalStoreTransferOrderOperateReq req);

    /**
     * 调拨单提交
     */
    BaseResult<String> internalCommit(InternalStoreTransferOrderOperateReq request);

    /**
     * 调拨单确认
     */
    BaseResult<String> internalConfirm(InternalStoreTransferOrderOperateReq req);

    /**
     * 调拨单分页查询
     */
    BasePageData<InternalStoreTransferOrderDto> pageSearch(BasePageParam<InternalStoreTransferOrderReq> pageParam);

    /**
     * 调拨单详情分页查询
     */
    BasePageData<InternalStoreTransferOrderDetailDto> internalDetailPageSearch(BasePageParam<InternalStoreTransferOrderDetailSearchReq> pageSearchReq);
}
