package com.jiduauto.sps.order.server.service;

import cn.hutool.core.collection.CollUtil;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderInvoiceRelationPo;
import com.jiduauto.sps.sdk.pojo.po.SapInvoiceInfoPo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * <p>
 * 销售订单发票关联表 服务类
 * </p>
 *
 * @author generate
 * @since 2024-03-25
 */
public interface ISaleOrderInvoiceRelationService extends IService<SaleOrderInvoiceRelationPo> {


    /**
     * 获取销售订单对应发票信息
     * key 销售订单  value 该销售订单所有的发票信息
     */
    Map<String, List<SapInvoiceInfoPo>> mapSapInvoiceInfoPoList(List<String> saleOrderNos);

    /**
     * 获取正常发票信息
     */
   static SapInvoiceInfoPo getInvoiceInfo(String saleOrder, Map<String, List<SapInvoiceInfoPo>> map) {
        List<SapInvoiceInfoPo> sapInvoiceInfoPos = map.get(saleOrder);
        if (CollUtil.isEmpty(sapInvoiceInfoPos)) {
            return new SapInvoiceInfoPo();
        }
        return sapInvoiceInfoPos.stream().filter(e -> e.getInvoiceAmount().compareTo(BigDecimal.ZERO) > 0).findFirst().orElse(new SapInvoiceInfoPo());
    }

    /**
     * 获取红票
     */
    static List<SapInvoiceInfoPo> getRedInvoiceInfoList(String saleOrder, Map<String, List<SapInvoiceInfoPo>> map) {
        List<SapInvoiceInfoPo> sapInvoiceInfoPos = map.get(saleOrder);
        if (CollUtil.isEmpty(sapInvoiceInfoPos)) {
            return new ArrayList<>();
        }
        return sapInvoiceInfoPos.stream().filter(e -> e.getInvoiceAmount().compareTo(BigDecimal.ZERO) < 0).collect(Collectors.toList());
    }
    /**
     * 获取红票单号
     */
    static List<String> getRedInvoiceNoList(String saleOrder, Map<String, List<SapInvoiceInfoPo>> map) {
        List<SapInvoiceInfoPo> sapInvoiceInfoPos = map.get(saleOrder);
        if (CollUtil.isEmpty(sapInvoiceInfoPos)) {
            return new ArrayList<>();
        }
        return sapInvoiceInfoPos.stream().filter(e -> e.getInvoiceAmount().compareTo(BigDecimal.ZERO) < 0).map(SapInvoiceInfoPo::getInvoiceNo).collect(Collectors.toList());
    }
}
