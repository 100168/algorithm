package com.jiduauto.sps.order.server.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.mapper.StoreRecommendationListMapper;
import com.jiduauto.sps.order.server.pojo.dto.StoreRecommendationListDto;
import com.jiduauto.sps.order.server.pojo.po.StoreRecommendationListPo;
import com.jiduauto.sps.order.server.pojo.vo.req.StandardRecommendationListPageReq;
import com.jiduauto.sps.order.server.service.IStoreRecommendationListService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.pojo.po.MaterialPo;
import com.jiduauto.sps.sdk.pojo.po.StorePo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 门店推荐清单 服务实现类
 */
@Service
public class StoreRecommendationListServiceImpl extends ServiceImpl<StoreRecommendationListMapper, StoreRecommendationListPo> implements IStoreRecommendationListService {

    @Resource
    private BaseDataQuery baseDataQuery;

    /**
     * 分页查询
     */
    @Override
    public BasePageData<StoreRecommendationListDto> pageSearch(BasePageParam<StandardRecommendationListPageReq> req) {
        StandardRecommendationListPageReq param = req.getParam();
        IPage<StoreRecommendationListPo> page = page(new Page<>(req.getPage(), req.getSize()),
                Wrappers.lambdaQuery(StoreRecommendationListPo.class)
                        .eq(StoreRecommendationListPo::getBizType, param.getBizType())
                        .eq(StrUtil.isNotBlank(param.getStoreCode()), StoreRecommendationListPo::getStoreCode, param.getStoreCode())
                        .eq(StrUtil.isNotBlank(param.getMaterialCode()), StoreRecommendationListPo::getMaterialCode, param.getMaterialCode())
                        .orderByDesc(StoreRecommendationListPo::getId)
        );

        BasePageData<StoreRecommendationListDto> pageData = new BasePageData<>(page);

        Map<String, StorePo> storePoMap = baseDataQuery.mapStorePo(req.getParam().getBizType(), page.getRecords().stream()
                .map(StoreRecommendationListPo::getStoreCode).distinct().collect(Collectors.toList()), false);

        Map<String, MaterialPo> materialPoMap = baseDataQuery.mapMaterialPo(param.getBizType(), page.getRecords().stream()
                .map(StoreRecommendationListPo::getMaterialCode).distinct().collect(Collectors.toList()));

        pageData.setRecords(page.getRecords().stream().map(item -> {
            StoreRecommendationListDto dto = BeanCopierUtil.copy(item, StoreRecommendationListDto.class);
            dto.setStoreName(storePoMap.getOrDefault(item.getStoreCode(), new StorePo()).getStoreName());
            dto.setMaterialName(materialPoMap.getOrDefault(item.getMaterialCode(), new MaterialPo()).getMaterialName());
            return dto;
        }).collect(Collectors.toList()));
        return pageData;
    }


    private void updateRecommend(StoreRecommendationListPo po) {
        update(po, Wrappers.lambdaQuery(StoreRecommendationListPo.class)
                .eq(StoreRecommendationListPo::getBizType, po.getBizType())
                .eq(StoreRecommendationListPo::getMaterialCode, po.getMaterialCode())
                .eq(StoreRecommendationListPo::getStoreCode, po.getStoreCode()));
    }

    @Override
    public StoreRecommendationListPo getOne(String bizType,
                                             String storeCode,
                                             String materialCode) {
        return getOne(Wrappers.lambdaQuery(StoreRecommendationListPo.class)
                .eq(StoreRecommendationListPo::getBizType, bizType)
                .eq(StoreRecommendationListPo::getStoreCode, storeCode)
                .eq(StoreRecommendationListPo::getMaterialCode, materialCode)
        );
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void insertOrUpdate(StoreRecommendationListPo po, String operateUser) {
        StoreRecommendationListPo old = getOne(po.getBizType(), po.getStoreCode(), po.getMaterialCode());
        po.setUpdateUser(operateUser);
        po.setUpdateTime(LocalDateTime.now());
        if (Objects.nonNull(old)) {
            updateRecommend(po);
        } else {
            try {
                po.setCreateUser(operateUser);
                save(po);
            } catch (DuplicateKeyException e) {
                po.setCreateUser(null);
                po.setUpdateUser(operateUser);
                updateRecommend(po);
            }
        }
    }
}
