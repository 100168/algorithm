package com.jiduauto.sps.order.server.mq.consumer;

import com.jiduauto.sps.order.server.pojo.dto.SaleOrderMessageDto;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.OperateEnum;
import com.jiduauto.sps.sdk.enums.SaleOrderStatusEnum;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * 采购订单创建成功
 */
@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_4,
        topic = BaseConstants.RocketMqTopic.SALE_ORDER,
        consumeThreadMax = 10)
public class SaleOrderConsumer implements RocketMQListener<MessageExt> {

    @Resource
    private ISaleOrderService saleOrderService;

    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("SaleOrderConsumer#onMessage messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
        SaleOrderMessageDto saleOrderMessageDto = JsonUtil.toObject(body, SaleOrderMessageDto.class);
        if (Objects.equals(message.getTags(), SaleOrderStatusEnum.WAIT_ISSUED.getMsgTag())) {
            //区分不同类型订单，区分处理
            saleOrderService.issueOrder(saleOrderMessageDto.getId());

        } else if (Objects.equals(message.getTags(), SaleOrderStatusEnum.PENDING_DELIVERY.getMsgTag())) {
            if (saleOrderMessageDto.getIsDfs()) {
                try {
                    saleOrderService.transferOrder(OperateEnum.AUTO_TRANSFER, saleOrderMessageDto.getId());
                } catch (BizException e) {
                    log.warn("SaleOrderConsumer#onMessage auto_transfer messageId: {}, tag: {}, body: {}", message.getMsgId(), message.getTags(), body);
                }
            } else {
                saleOrderService.dhlOutBound(saleOrderMessageDto.getId());
            }
        }
    }
}
