package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderDfsStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderOperateLogDto;
import com.jiduauto.sps.order.server.pojo.dto.SaleOrderStatusChangeDto;
import com.jiduauto.sps.order.server.pojo.vo.req.SaleOrderDetailByIdReq;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderOperateLogPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;

/**
 * <p>
 * 销售订单操作记录 服务类
 * </p>
 *
 * @author generate
 * @since 2023-04-12
 */
public interface ISaleOrderOperateLogService extends IService<SaleOrderOperateLogPo> {

    /**
     * 销售订单状态跟踪明细
     *
     * @author dong.li
     * @date 4/17/23 4:14 PM
     */
    BasePageData<SaleOrderOperateLogDto> pageSearch(BasePageParam<SaleOrderDetailByIdReq> pageParam);

    /**
     * 保存状态变更记录
     *
     * @param changeDto
     */
    void saveStatusChangeLog(SaleOrderDfsStatusChangeDto changeDto);

    /**
     * 保存状态变更记录
     *
     * @param changeDto
     */
    void saveStatusChangeLog(SaleOrderStatusChangeDto changeDto);
}
