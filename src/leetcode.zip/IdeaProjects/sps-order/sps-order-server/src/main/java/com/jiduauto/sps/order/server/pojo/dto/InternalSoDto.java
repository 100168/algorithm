package com.jiduauto.sps.order.server.pojo.dto;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * 销售订单返回字段
 *
 * @author dong.li01
 * @since 4/14/23 2:16 PM
 */
@Data
public class InternalSoDto {

    /**
     * 销售单号
     */
    private String saleOrderNo;


    /**
     * 是否DFS
     */
    private Boolean isDfs;

    /**
     * 运输建议
     */
    private String transferAdvice;



    /**
     * 状态
     */
    private String saleOrderStatus;


    /**
     * 仓库代码
     */
    private String deliverWarehouseCode;

    /**
     * 仓库名称
     */
    private String warehouseName;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;





}
