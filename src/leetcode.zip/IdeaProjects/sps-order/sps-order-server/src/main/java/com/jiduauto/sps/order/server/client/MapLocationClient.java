package com.jiduauto.sps.order.server.client;

import com.jiduauto.sps.sdk.enums.GlobalCodeEnum;
import com.jiduauto.sps.sdk.pojo.resp.DistrictResp;
import com.jiduauto.sps.sdk.pojo.resp.ResultResp;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * SAP RESTAdapter 接口
 */

@FeignClient(name = "cn.pe.vi.map-location.mixed",fallbackFactory = MapLocationClient.WorkOrderClientFallbackFactory.class)
public interface MapLocationClient {
    /**
     * 根据code获取下级数据
     * @Author O_chaopeng.huang
     * @Date 17:40 2023/5/5
     **/
    @GetMapping({"/client/v1/district/listChild"})
    ResultResp<List<DistrictResp>> listChild(@RequestParam("code") String code);

    @GetMapping({"/client/v1/district/list"})
    ResultResp<List<DistrictResp>> listDistrict();

    /**
     * 获取政区域-省市二级数据
     * @author dong.li
     * @date 5/4/23 2:11 PM
     */
    @GetMapping({"/client/v1/district/listProvinceCity"})
    ResultResp<List<DistrictResp>> listProvinces();

    @Slf4j
    @Component
    class WorkOrderClientFallbackFactory implements FallbackFactory<MapLocationClient> {

        @Override
        public MapLocationClient create(Throwable throwable) {
            return new MapLocationClient() {
                /**
                  * 根据code获取下级数据
                  * @author O_chaopeng.huang
                  * @return MapLocationClient
                  */
                @Override
                public ResultResp<List<DistrictResp>> listChild(String code) {
                    log.warn("MapLocationClient#listDistrict error", throwable);
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public ResultResp<List<DistrictResp>> listDistrict() {
                    log.warn("MapLocationClient#listDistrict error", throwable);
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }

                @Override
                public ResultResp<List<DistrictResp>> listProvinces() {
                    log.warn("MapLocationClient#listProvinces error", throwable);
                    return ResultResp.error(GlobalCodeEnum.GL_FAIL_DEFAULT.getCode(), "fallback");
                }
            };
        }
    }
}
