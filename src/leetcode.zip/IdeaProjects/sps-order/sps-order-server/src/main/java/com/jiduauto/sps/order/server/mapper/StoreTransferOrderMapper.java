package com.jiduauto.sps.order.server.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jiduauto.sps.order.server.pojo.dto.StoreTransferOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreTransferOrderExportDto;
import com.jiduauto.sps.order.server.pojo.dto.VirtualQtyDto;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreTransferOrderReq;
import com.jiduauto.sps.sdk.pojo.po.StoreTransferOrderPo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * 门店调拨单 Mapper 接口
 * </p>
 */
public interface StoreTransferOrderMapper extends BaseMapper<StoreTransferOrderPo> {

    IPage<StoreTransferOrderDto> pageSearch(Page<StoreTransferOrderDto> objectPage, @Param("req") StoreTransferOrderReq req);

    IPage<StoreTransferOrderExportDto> export(Page<StoreTransferOrderExportDto> objectPage, @Param("req") StoreTransferOrderReq req);

    /**
     * 根据门店查询在途数量
     */
    List<VirtualQtyDto> queryVirtualQty(@Param("bizType") String bizType, @Param("storeCode") String storeCode);
}
