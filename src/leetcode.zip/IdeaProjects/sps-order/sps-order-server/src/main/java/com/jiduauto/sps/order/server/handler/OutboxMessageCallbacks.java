package com.jiduauto.sps.order.server.handler;

import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import com.jiduauto.dit.outbox.anno.ResultCallback;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.pojo.Result;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.client.req.IndirectWDApplyOrderPutOutReq;
import com.jiduauto.sps.order.server.convertor.NoticedDtoConvertor;
import com.jiduauto.sps.order.server.handler.warehousedistributeorder.WarehouseDistributeOrderAllPo;
import com.jiduauto.sps.order.server.pojo.BackOrderBatchCancelResp;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreTransferOrderOperateReq;
import com.jiduauto.sps.order.server.pojo.vo.req.PoOccupyStockReq;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.BizTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import com.jiduauto.sps.sdk.utils.JsonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.text.StrSubstitutor;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

import static com.jiduauto.sps.sdk.consts.OutboxConst.MessageType.*;


/**
 * @author panjian
 */
@Component
@Slf4j
public class OutboxMessageCallbacks {

    @Resource
    private WebhookUtil webhookUtil;
    @Resource
    private NoticedDtoConvertor noticedDtoConvertor;

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private SpsClient spsClient;

    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    @ResultCallback(msgType = SM_ORDER_RECEIVE_TO_SAP)
    public void smReceiveToSapHandle(OutboxMessage outboxMessage, Result result) {
        WarehouseDistributeOrderPo po = JSONUtil.toBean(outboxMessage.getContent(), WarehouseDistributeOrderPo.class);
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            Map<String, String> msgMap = webhookUtil.buildMsgMap(noticedDtoConvertor.buildNoticedDto(po,
                    result.getMessage(),
                    BaseConstants.MessageTitle.SM_RECEIVE_TO_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap),
                    BaseConstants.MessageTitle.SM_RECEIVE_TO_SAP);
        }
    }

    @ResultCallback(msgType = SM30_RECEIVE_TO_SAP)
    public void sm30ReceiveToSapHandle(OutboxMessage outboxMessage, Result result) {
        WarehouseDistributeOrderPo po = JSONUtil.toBean(outboxMessage.getContent(), WarehouseDistributeOrderPo.class);
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            Map<String, String> msgMap = webhookUtil.buildMsgMap(noticedDtoConvertor.buildNoticedDto(po,
                    result.getMessage(),
                    BaseConstants.MessageTitle.SM30_RECEIVE_TO_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap),
                    BaseConstants.MessageTitle.SM30_RECEIVE_TO_SAP);
        }
    }

    @ResultCallback(msgType = WD_ORDER_TO_DHL)
    public void wdDhlInBoundNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            WarehouseDistributeOrderAllPo allPo = JSONUtil.toBean(outboxMessage.getContent(), WarehouseDistributeOrderAllPo.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(allPo.getWarehouseDistributeOrderPo(), result.getMessage(), BaseConstants.MessageTitle.WD_PUSH_DHL_FAILED));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), BaseConstants.MessageTitle.WD_PUSH_DHL_FAILED);
        }
    }

    /**
     * 销售订单同步成功取消库存占用
     */
    @ResultCallback(msgType = SALE_ORDER_CANCEL)
    public void soDhlOutBoundNotice(OutboxMessage outboxMessage, Result result) {
        SaleOrderPo orderPo = JsonUtil.toObject(outboxMessage.getContent(), SaleOrderPo.class);
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildNoticedDto(orderPo, result.getMessage(), BaseConstants.MessageTitle.SALE_ORDER_CANCEL_PUSH_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap), BaseConstants.MessageTitle.SALE_ORDER_CANCEL_PUSH_SAP);
            return;
        }
        // dfs 没有占库存
        if (orderPo.getIsDfs()) {
            return;
        }
        PoOccupyStockReq poOccupyStockReq = saleOrderService.buildPoOccupyStockReq(orderPo);
        spsClient.cancelPoOccupy(poOccupyStockReq).check();
    }


    @ResultCallback(msgType = BACK_ORDER_CANCEL)
    public void backOrderCancelNotice(OutboxMessage outboxMessage, Result result) {
        log.info("backOrderCancelNotice result:{}", JSON.toJSONString(result));
        //同步失败企微提醒
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
//            BackOrderBatchCancelResp resp = JsonUtil.toObject(result.getMessage(),
//                    BackOrderBatchCancelResp.class);
            Map<String, String> msgMap = webhookUtil.buildMsgMap(
                    noticedDtoConvertor.buildBoCacelNoticedDto(result.getMessage(), BizTypeEnum.SP.getBizType(), outboxMessage.getMsgId(),
                            BaseConstants.MessageTitle.BACK_ORDER_CANCEL_PUSH_SAP));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap),
                    BaseConstants.MessageTitle.BACK_ORDER_CANCEL_PUSH_SAP);

        }

    }

    @ResultCallback(STORE_TRANSFER_ORDER_CANCEL_TO_SAP)
    public void storeTransferOrderCancelToSap(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess()  && sendFlag(outboxMessage)) {
            InternalStoreTransferOrderOperateReq req = JsonUtil.toObject(outboxMessage.getContent(), InternalStoreTransferOrderOperateReq.class);
            Map<String, String> contentMap = new HashMap<>();
            contentMap.put("bizType", req.getBizType());
            contentMap.put("orderNo", req.getOrderNo());
            contentMap.put("errorMessage", result.getMessage());
            String content = "**调拨单取消同步SAP失败**\n" +
                    "**业务类型: <font color='comment'>${bizType}</font>**\n" +
                    "**调拨单号: <font color='comment'>${orderNo}</font>**\n" +
                    "**详细结果: <font color='comment'>${errorMessage}</font>**";
            webhookUtil.sendMarkdownMessage(null, new StrSubstitutor(contentMap).replace(content), "调拨单取消同步SAP失败通知");
        }
    }



    @ResultCallback(SALE_ORDER_DHL_OUT_BOUND)
    public void dhlOutBoundNotice(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess() && sendFlag(outboxMessage)) {
            SaleOrderPo saleOrderPo = JsonUtil.toObject(outboxMessage.getContent(), SaleOrderPo.class);
            Map<String, String> contentMap = new HashMap<>();
            contentMap.put("bizType", saleOrderPo.getBizType());
            contentMap.put("saleOrderNo", saleOrderPo.getSaleOrderNo());
            contentMap.put("errorMessage", result.getMessage());
            String content = "**SO推送DHL失败通知**\n" +
                    "**业务类型: <font color='comment'>${bizType}</font>**\n" +
                    "**销售单号: <font color='comment'>${saleOrderNo}</font>**\n" +
                    "**详细结果: <font color='comment'>${errorMessage}</font>**";
            webhookUtil.sendMarkdownMessage(null, new StrSubstitutor(contentMap).replace(content), "SO推送DHL失败通知");
        }
    }

    /**
     * 仓配订单-领料订单-出库结果同步SRM
     * @param outboxMessage
     * @param result
     */
    @ResultCallback(WD_APPLY_ORDER_PUT_OUT_TO_SRM)
    public void syncWDApplyOrderPutOutToSRM(OutboxMessage outboxMessage, Result result) {
        if (!result.isSuccess() && sendFlag(outboxMessage)) {
            InAndOutStockRequest msg = JSONUtil.toBean(outboxMessage.getContent(), InAndOutStockRequest.class);
            IndirectWDApplyOrderPutOutReq putOutReq = new IndirectWDApplyOrderPutOutReq();

            WarehouseDistributeOrderPo po = warehouseDistributeOrderService.getByOrderNo(msg.getBizType(), msg.getTradeNo());
            Map<String, String> msgMap = webhookUtil.buildMsgMap(noticedDtoConvertor.buildNoticedDto(po,
                    result.getMessage(),
                    BaseConstants.MessageTitle.WD_APPLY_ORDER_PUT_OUT_TO_SRM));
            webhookUtil.sendMarkdownMessage(null, webhookUtil.fillNoticed(msgMap),
                    BaseConstants.MessageTitle.WD_APPLY_ORDER_PUT_OUT_TO_SRM);
        }
    }

    /**
     * 重试次数 等于 提醒次数的时候 才发送 飞书告警， 提高告警敏捷性
     * @param outboxMessage
     * @return
     */
    private boolean sendFlag(OutboxMessage outboxMessage){
        return outboxMessage.getNoticeCount() == (outboxMessage.getRetryCount() + 1);
    }
}
