package com.jiduauto.sps.order.server.handler.warehousedistributeorder;

import com.jiduauto.sps.order.server.client.ChargePartnerClient;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.order.server.convertor.AsnConvertor;
import com.jiduauto.sps.sdk.client.req.AsnPushReq;
import com.jiduauto.sps.sdk.exception.BizException;
import com.jiduauto.sps.sdk.pojo.po.DictItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/*
 * 下发dhl入库指令*/
@Component
public class InboundToESHandler implements WDOrderJobHandler, InitializingBean {
    @Resource
    private WDOrderJobContext wdOrderJobContext;

    @Resource
    private ChargePartnerClient chargePartnerClient;

    @Resource
    private AsnConvertor asnConvertor;

    @Resource
    private SpsClient spsClient;

    /*同步能源*/
    @Override
    public void process(WarehouseDistributeOrderAllPo warehouseDistributeOrderAllPo) {

        WarehouseDistributeLogisticPo logisticPo = warehouseDistributeOrderAllPo.getWarehouseDistributeLogisticPo();
        //判断是否是G59仓库
        BaseResult<List<DictItemPo>> specialWarehouse = spsClient.getSpecialWarehouse(logisticPo.getBizType());
        if (specialWarehouse.getData().stream().anyMatch(dictItemPo -> dictItemPo.getItemCode().equals(logisticPo.getReceiveWarehouseCode()))) {
            return;
        }
        AsnPushReq asnPushReq = asnConvertor.toAsnPushReq(warehouseDistributeOrderAllPo);
        BaseResult<Object> result = chargePartnerClient.receiveAsn(asnPushReq);
        if (!result.isSuccess()) {
            throw new BizException("ES11同步能源失败");
        }

    }

    /*
     * 注册单前handler*/
    @Override
    public void afterPropertiesSet() throws Exception {
        wdOrderJobContext.register(WDJobIndexEnum.INBOUND_TO_ES.getBitIndex(), this);
    }
}
