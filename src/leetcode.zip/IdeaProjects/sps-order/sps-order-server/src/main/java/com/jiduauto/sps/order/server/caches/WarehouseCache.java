package com.jiduauto.sps.order.server.caches;

import cn.hutool.core.util.StrUtil;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.jiduauto.sps.order.server.client.SpsClient;
import com.jiduauto.sps.sdk.pojo.po.WarehousePo;
import com.jiduauto.sps.sdk.pojo.req.BaseDataReq;
import com.jiduauto.sps.sdk.pojo.resp.BaseDataResp;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * 仓库信息缓存
 */
@Component
@Slf4j
public class WarehouseCache {
    @Resource
    private SpsClient spsClient;

    private final LoadingCache<String, Optional<WarehousePo>> loadingCache =
            CacheBuilder.newBuilder().expireAfterAccess(30, TimeUnit.MINUTES)
                    .build(new CacheLoader<String, Optional<WarehousePo>>() {
                        @Override
                        public Optional<WarehousePo> load(String s) {
                            String[] ss = s.split(",");
                            return Optional.ofNullable(getWarehouse(ss[0], ss[1]));
                        }
                    });

    public WarehousePo getByBizAndCode(String bizType, String warehouseCode) {
        try {
            if (StrUtil.isEmpty(warehouseCode)) {
                return new WarehousePo();
            }
            return loadingCache.get(bizType + "," + warehouseCode).orElse(new WarehousePo());
        } catch (Exception e) {
            log.error("查询仓库缓存信息异常", e);
            return getWarehouse(bizType,warehouseCode);
        }
    }

    public WarehousePo getWarehouse(String bizType, String warehouseCode) {
        BaseDataReq baseDataReq = new BaseDataReq();
        baseDataReq.setBizType(bizType);
        baseDataReq.setWarehouseCodes(Collections.singletonList(warehouseCode));
        BaseResult<BaseDataResp> resp = spsClient.searchBaseData(baseDataReq);
        if (resp.isSuccess() && resp.getData() != null) {
            return resp.getData().getWarehouses().get(0);
        }
        return new WarehousePo();
    }
    /**
     * 删除本地缓存
     *
     * @author dong.li
     * @date 4/23/23 3:19 PM
     */
    public void remove(String bizType, String warehouseCode) {
        loadingCache.invalidate(bizType+","+warehouseCode);
    }
}
