package com.jiduauto.sps.order.server.service.impl;

import com.jiduauto.sps.order.server.service.IBackOrderOperateLogService;
import com.jiduauto.sps.order.server.service.IBackOrderService;
import com.jiduauto.sps.order.server.service.IBackSaleRelationService;
import com.jiduauto.sps.order.server.service.IPurchaseOrderDetailService;
import com.jiduauto.sps.order.server.service.IPurchaseOrderOperateLogService;
import com.jiduauto.sps.order.server.service.IPurchaseOrderService;
import com.jiduauto.sps.order.server.service.ISaleOrderDetailService;
import com.jiduauto.sps.order.server.service.ISaleOrderOperateLogService;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.service.ITestService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeAttachService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeItemAttachService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeItemPackageService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeItemService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeLogisticService;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.pojo.po.BackOrderOperateLogPo;
import com.jiduauto.sps.sdk.pojo.po.BackOrderPo;
import com.jiduauto.sps.sdk.pojo.po.BackSaleRelationPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderOperateLogPo;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderOperateLogPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeAttachPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemAttachPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPackagePo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeLogisticPo;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.utils.DateUtils;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;

/**
 * @ClassName TestServiceImpl
 * @Description 临时后续删除
 * @Author O_chaopeng.huang
 * @Date 2023/11/21 17:06
 */
@Service
public class TestServiceImpl implements ITestService {
    @Resource
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;
    @Resource
    private IWarehouseDistributeLogisticService warehouseDistributeLogisticService;
    @Resource
    private IWarehouseDistributeItemPackageService warehouseDistributeItemPackageService;
    @Resource
    private IWarehouseDistributeItemAttachService warehouseDistributeItemAttachService;
    @Resource
    private IWarehouseDistributeItemService warehouseDistributeItemService;
    @Resource
    private IWarehouseDistributeAttachService warehouseDistributeAttachService;
    @Resource
    private IPurchaseOrderService purchaseOrderService;
    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;
    @Resource
    private IPurchaseOrderOperateLogService purchaseOrderOperateLogService;
    @Resource
    private ISaleOrderService saleOrderService;
    @Resource
    private ISaleOrderDetailService saleOrderDetailService;
    @Resource
    private ISaleOrderOperateLogService saleOrderOperateLogService;
    @Resource
    private IBackOrderService backOrderService;
    @Resource
    private IBackOrderOperateLogService backOrderOperateLogService;
    @Resource
    private IBackSaleRelationService backSaleRelationService;
    @Override
    public void insertBOOL(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from back_sale_relation;");
        while (list.next()) {
            BackSaleRelationPo po = new BackSaleRelationPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String back_order_no = list.getString("back_order_no");
            String sale_order_no = list.getString("sale_order_no");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setBackOrderNo(back_order_no);
            po.setSaleOrderNo(sale_order_no);
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            backSaleRelationService.save(po);
        }
    }
    @Override
    public void insertBOD(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from back_order_operate_log;");
        while (list.next()) {
            BackOrderOperateLogPo po = new BackOrderOperateLogPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String back_order_no = list.getString("back_order_no");
            String action_desc = list.getString("action_desc");
            String modify_column = list.getString("modify_column");
            String old_value = list.getString("old_value");
            String new_value = list.getString("new_value");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setBackOrderNo(back_order_no);
            po.setActionDesc(action_desc);
            po.setModifyColumn(modify_column);
            po.setOldValue(old_value);
            po.setNewValue(new_value);
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            backOrderOperateLogService.save(po);
        }
    }
    @Override
    public void insertBO(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from back_order;");
        while (list.next()) {
            BackOrderPo po = new BackOrderPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String back_order_no = list.getString("back_order_no");
            String back_order_type = list.getString("back_order_type");
            String purchase_order_no = list.getString("purchase_order_no");
            String sale_part_num = list.getString("sale_part_num");
            String back_qty = list.getString("back_qty");
            String rest_back_qty = list.getString("rest_back_qty");
            String back_order_status = list.getString("back_order_status");
            String est_arrival_time = list.getString("est_arrival_time");
            String delay_explanation = list.getString("delay_explanation");
            String store_code = list.getString("store_code");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setBackOrderNo(back_order_no);
            po.setBackOrderType(back_order_type);
            po.setPurchaseOrderNo(purchase_order_no);
            po.setSalePartNum(sale_part_num);
            po.setBackQty(new BigDecimal(back_qty));
            po.setRestBackQty(new BigDecimal(rest_back_qty));
            po.setBackOrderStatus(back_order_status);
            po.setEstArrivalTime(est_arrival_time);
            po.setDelayExplanation(delay_explanation);
            po.setStoreCode(store_code);
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            backOrderService.save(po);
        }
    }
    @Override
    public void insertSOOL(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from sale_order_operate_log;");
        while (list.next()) {
            SaleOrderOperateLogPo po = new SaleOrderOperateLogPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String sale_order_no = list.getString("sale_order_no");
            String action_desc = list.getString("action_desc");
            String modify_column = list.getString("modify_column");
            String old_value = list.getString("old_value");
            String new_value = list.getString("new_value");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setSaleOrderNo(sale_order_no);
            po.setActionDesc(action_desc);
            po.setModifyColumn(modify_column);
            po.setOldValue(old_value);
            po.setNewValue(new_value);
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            saleOrderOperateLogService.save(po);
        }
    }
    @Override
    public void insertSOD(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from sale_order_detail;");
        while (list.next()) {
            SaleOrderDetailPo po = new SaleOrderDetailPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String sale_order_no = list.getString("sale_order_no");
            String sale_part_num = list.getString("sale_part_num");
            String deliver_qty = list.getString("deliver_qty");
            String qty = list.getString("qty");
            String receive_qty = list.getString("receive_qty");
            String cancel_qty = list.getString("cancel_qty");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setSaleOrderNo(sale_order_no);
            po.setSalePartNum(sale_part_num);
            po.setDeliverQty(new BigDecimal(deliver_qty));
            po.setQty(new BigDecimal(qty));
            po.setReceiveQty(new BigDecimal(receive_qty));
            po.setCancelQty(new BigDecimal(cancel_qty));
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            saleOrderDetailService.save(po);
        }
    }
    @Override
    public void insertSO(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from sale_order;");
        while (list.next()) {
            SaleOrderPo po = new SaleOrderPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String sale_order_no = list.getString("sale_order_no");
            String sap_order_no = list.getString("sap_order_no");
            String is_dfs = list.getString("is_dfs");
            String purchase_order_no = list.getString("purchase_order_no");
            String deliver_warehouse_code = list.getString("deliver_warehouse_code");
            String dfs_status = list.getString("dfs_status");
            String sale_order_status = list.getString("sale_order_status");
            String sale_order_type = list.getString("sale_order_type");
            String transfer_advice = list.getString("transfer_advice");
            String sale_order_attr = list.getString("sale_order_attr");
            String stock_out_time = list.getString("stock_out_time");
            String est_arrival_time = list.getString("est_arrival_time");
            String logistics_no = list.getString("logistics_no");
            String transport_type = list.getString("transport_type");
            String store_code = list.getString("store_code");
            String plan_issue_time = list.getString("plan_issue_time");
            String issued_time = list.getString("issued_time");
            String receive_warehouse_code = list.getString("receive_warehouse_code");
            String receiver_province = list.getString("receiver_province");
            String receiver_city = list.getString("receiver_city");
            String receiver_district = list.getString("receiver_district");
            String receiver = list.getString("receiver");
            String receiver_phone = list.getString("receiver_phone");
            String receiver_address = list.getString("receiver_address");
            String is_claim_whitelist = list.getString("is_claim_whitelist");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setSaleOrderNo(sale_order_no);
            po.setSapOrderNo(sap_order_no);
            po.setIsDfs(is_dfs.isEmpty());
            po.setPurchaseOrderNo(purchase_order_no);
            po.setDeliverWarehouseCode(deliver_warehouse_code);
            po.setDfsStatus(dfs_status);
            po.setSaleOrderStatus(sale_order_status);
            po.setSaleOrderType(sale_order_type);
            po.setTransferAdvice(transfer_advice);
            po.setSaleOrderAttr(sale_order_attr);
            po.setStockOutTime(stock_out_time);
            po.setEstArrivalTime(est_arrival_time);
            po.setLogisticsNo(logistics_no);
            po.setTransportType(transport_type);
            po.setStoreCode(store_code);
            po.setPlanIssueTime(plan_issue_time);
            po.setIssuedTime(issued_time);
            po.setReceiveWarehouseCode(receive_warehouse_code);
            po.setReceiverProvince(receiver_province);
            po.setReceiverCity(receiver_city);
            po.setReceiverDistrict(receiver_district);
            po.setReceiver(receiver);
            po.setReceiverPhone(receiver_phone);
            po.setReceiverAddress(receiver_address);
            po.setIsClaimWhitelist(is_claim_whitelist.isEmpty());
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            saleOrderService.save(po);
        }
    }
    @Override
    public void insertPOOL(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from purchase_order_operate_log;");
        while (list.next()) {
            PurchaseOrderOperateLogPo po = new PurchaseOrderOperateLogPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String purchase_order_no = list.getString("purchase_order_no");
            String action_desc = list.getString("action_desc");
            String modify_column = list.getString("modify_column");
            String old_value = list.getString("old_value");
            String new_value = list.getString("new_value");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setPurchaseOrderNo(purchase_order_no);
            po.setActionDesc(action_desc);
            po.setModifyColumn(modify_column);
            po.setOldValue(old_value);
            po.setNewValue(new_value);
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            purchaseOrderOperateLogService.save(po);
        }
    }
    @Override
    public void insertPOD(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from purchase_order_detail;");
        while (list.next()) {
            PurchaseOrderDetailPo po = new PurchaseOrderDetailPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String purchase_order_no = list.getString("purchase_order_no");
            String sale_part_num = list.getString("sale_part_num");
            String discount_unit_price = list.getString("discount_unit_price");
            String qty = list.getString("qty");
            String line_amount = list.getString("line_amount");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            String vin = list.getString("vin");
            String store_remark = list.getString("store_remark");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setPurchaseOrderNo(purchase_order_no);
            po.setSalePartNum(sale_part_num);
            po.setDiscountUnitPrice(new BigDecimal(discount_unit_price));
            po.setQty(new BigDecimal(qty));
            po.setLineAmount(new BigDecimal(line_amount));
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            po.setVin(vin);
            po.setStoreRemark(store_remark);
            purchaseOrderDetailService.save(po);
        }
    }
    @Override
    public void insertPO(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from purchase_order;");
        while (list.next()) {
            PurchaseOrderPo po = new PurchaseOrderPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String trade_no = list.getString("trade_no");
            String purchase_order_no = list.getString("purchase_order_no");
            String sap_order_no = list.getString("sap_order_no");
            String purchase_order_attr = list.getString("purchase_order_attr");
            String purchase_order_type = list.getString("purchase_order_type");
            String store_code = list.getString("store_code");
            String commit_time = list.getString("commit_time");
            String receive_warehouse_code = list.getString("receive_warehouse_code");
            String purchase_order_amount = list.getString("purchase_order_amount");
            String purchase_order_status = list.getString("purchase_order_status");
            String receiver = list.getString("receiver");
            String receiver_phone = list.getString("receiver_phone");
            String receiver_province = list.getString("receiver_province");
            String receiver_city = list.getString("receiver_city");
            String receiver_district = list.getString("receiver_district");
            String receiver_address = list.getString("receiver_address");
            String vin = list.getString("vin");
            String remark = list.getString("remark");
            String sap_order_create_time = list.getString("sap_order_create_time");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            String turn_purchase_order_status = list.getString("turn_purchase_order_status");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setTradeNo(trade_no);
            po.setPurchaseOrderNo(purchase_order_no);
            po.setSapOrderNo(sap_order_no);
            po.setPurchaseOrderAttr(purchase_order_attr);
            po.setPurchaseOrderType(purchase_order_type);
            po.setStoreCode(store_code);
            po.setCommitTime(DateUtils.dateToLocalDateTime(commit_time));
            po.setReceiveWarehouseCode(receive_warehouse_code);
            po.setPurchaseOrderAmount(new BigDecimal(purchase_order_amount));
            po.setPurchaseOrderStatus(purchase_order_status);
            po.setReceiver(receiver);
            po.setReceiverPhone(receiver_phone);
            po.setReceiverProvince(receiver_province);
            po.setReceiverCity(receiver_city);
            po.setReceiverDistrict(receiver_district);
            po.setReceiverAddress(receiver_address);
            po.setVin(vin);
            po.setRemark(remark);
            po.setSapOrderCreateTime(DateUtils.dateToLocalDateTime(sap_order_create_time));
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            po.setTurnPurchaseOrderStatus(turn_purchase_order_status);
            purchaseOrderService.save(po);
        }
    }
    @Override
    public void insertA(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from warehouse_distribute_attach;");
        while (list.next()) {
            WarehouseDistributeAttachPo po = new WarehouseDistributeAttachPo();
            String biz_type = list.getString("biz_type");
            String is_del = list.getString("is_del");
            String warehouse_distribute_order_no = list.getString("warehouse_distribute_order_no");
            String applier = list.getString("applier");
            String applier_contact = list.getString("applier_contact");
            String apply_company = list.getString("apply_company");
            String be_applied_company = list.getString("be_applied_company");
            String apply_aim = list.getString("apply_aim");
            String apply_purpose = list.getString("apply_purpose");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setWarehouseDistributeOrderNo(warehouse_distribute_order_no);
            po.setApplier(applier);
            po.setApplierContact(applier_contact);
            po.setApplyCompany(apply_company);
            po.setBeAppliedCompany(be_applied_company);
            po.setApplyAim(apply_aim);
            po.setApplyPurpose(apply_purpose);
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            warehouseDistributeAttachService.save(po);
        }
    }
    @Override
    public void insertIP(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from warehouse_distribute_item;");
        while (list.next()) {
            WarehouseDistributeItemPo po = new WarehouseDistributeItemPo();
            String biz_type = list.getString("biz_type");
            String warehouse_distribute_order_no = list.getString("warehouse_distribute_order_no");
            String material_line_no = list.getString("material_line_no");
            String material_code = list.getString("material_code");
            String qty = list.getString("qty");
            String real_in_qty = list.getString("real_in_qty");
            String real_out_qty = list.getString("real_out_qty");
            String packing_code = list.getString("packing_code");
            String volume = list.getString("volume");
            String weight = list.getString("weight");
            String material_status = list.getString("material_status");
            String stock_status = list.getString("stock_status");
            String material_sort = list.getString("material_sort");
            String sample_part_status = list.getString("sample_part_status");
            String car_code = list.getString("car_code");
            String batch_no = list.getString("batch_no");
            String material_bar_code = list.getString("material_bar_code");
            String sequence_no = list.getString("sequence_no");
            String add_date = list.getString("add_date");
            String product_date = list.getString("product_date");
            String expire_date = list.getString("expire_date");
            String supplier_code = list.getString("supplier_code");
            String project_code = list.getString("project_code");
            String stage_code = list.getString("stage_code");
            String wbs_code = list.getString("wbs_code");
            String purchase_order_no = list.getString("purchase_order_no");
            String column_project_no = list.getString("column_project_no");
            String warehouse_code = list.getString("warehouse_code");
            String area_code = list.getString("area_code");
            String location_code = list.getString("location_code");
            String pallet_no = list.getString("pallet_no");
            String case_no = list.getString("case_no");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            String is_del = list.getString("is_del");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setWarehouseDistributeOrderNo(warehouse_distribute_order_no);
            po.setMaterialLineNo(material_line_no);
            po.setMaterialCode(material_code);
            po.setQty(new BigDecimal(qty));
            po.setRealInQty(new BigDecimal(real_in_qty));
            po.setRealOutQty(new BigDecimal(real_out_qty));
            po.setPackingCode(packing_code);
            po.setVolume(new BigDecimal(volume));
            po.setWeight(new BigDecimal(weight));
            po.setMaterialStatus(Integer.valueOf(material_status));
            po.setStockStatus(Integer.valueOf(stock_status));
            po.setMaterialSort(material_sort);
            po.setSamplePartStatus(sample_part_status);
            po.setCarCode(car_code);
            po.setBatchNo(batch_no);
            po.setMaterialBarCode(material_bar_code);
            po.setSequenceNo(sequence_no);
            po.setAddDate(add_date);
            po.setProductDate(product_date);
            po.setExpireDate(expire_date);
            po.setSupplierCode(supplier_code);
            po.setPackingCode(project_code);
            po.setStageCode(stage_code);
            po.setWbsCode(wbs_code);
            po.setPurchaseOrderNo(purchase_order_no);
            po.setColumnProjectNo(column_project_no);
            po.setWbsCode(warehouse_code);
            po.setAreaCode(area_code);
            po.setLocationCode(location_code);
            po.setPalletNo(pallet_no);
            po.setCaseNo(case_no);
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            warehouseDistributeItemService.save(po);
        }
    }
    @Override
    public void insertIA(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery(
                "select * from warehouse_distribute_item_attach;");
        while (list.next()) {
            WarehouseDistributeItemAttachPo po = new WarehouseDistributeItemAttachPo();
            String biz_type = list.getString("biz_type");
            String warehouse_distribute_order_no = list.getString("warehouse_distribute_order_no");
            String material_line_no = list.getString("material_line_no");
            String apply_purpose = list.getString("apply_purpose");
            String plan_apply_flag = list.getString("plan_apply_flag");
            String sap_card_no = list.getString("sap_card_no");
            String cost_center = list.getString("cost_center");
            String responsible_party = list.getString("responsible_party");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            String is_del = list.getString("is_del");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setWarehouseDistributeOrderNo(warehouse_distribute_order_no);
            po.setMaterialLineNo(material_line_no);
            po.setApplyPurpose(apply_purpose);
            po.setPlanApplyFlag((plan_apply_flag).isEmpty());
            po.setSapCardNo(sap_card_no);
            po.setCostCenter(cost_center);
            po.setResponsibleParty(responsible_party);
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            warehouseDistributeItemAttachService.save(po);
        }
    }
    @Override
    public void insertP(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from warehouse_distribute_item_package;");
        while (list.next()) {
            WarehouseDistributeItemPackagePo po = new WarehouseDistributeItemPackagePo();
            String biz_type = list.getString("biz_type");
            String warehouse_distribute_order_no = list.getString("warehouse_distribute_order_no");
            String packing_code = list.getString("packing_code");
            String packing_unit = list.getString("packing_unit");
            String packing_length = list.getString("packing_length");
            String packing_width = list.getString("packing_width");
            String packing_height = list.getString("packing_height");
            String packing_volume = list.getString("packing_volume");
            String packing_weight = list.getString("packing_weight");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            String is_del = list.getString("is_del");
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setWarehouseDistributeOrderNo(warehouse_distribute_order_no);
            po.setPackingCode(packing_code);
            po.setPackingUnit(packing_unit);
            po.setPackingLength(Integer.valueOf(packing_length));
            po.setPackingWidth(Integer.valueOf(packing_width));
            po.setPackingHeight(Integer.valueOf(packing_height));
            po.setPackingVolume(new BigDecimal(packing_volume));
            po.setPackingWeight(new BigDecimal(packing_weight));
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            warehouseDistributeItemPackageService.save(po);
        }


    }
    @Override
    public void insertLP(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from warehouse_distribute_logistic;");
        while (list.next()) {
            String biz_type = list.getString("biz_type");
            String warehouse_distribute_order_no = list.getString("warehouse_distribute_order_no");
            String est_pick_time = list.getString("est_pick_time");
            String est_arrival_time = list.getString("est_arrival_time");
            String shipping_method = list.getString("shipping_method");
            String deliver_warehouse_code = list.getString("deliver_warehouse_code");
            String shipper = list.getString("shipper");
            String shipper_contact = list.getString("shipper_contact");
            String deliver_province_code = list.getString("deliver_province_code");
            String deliver_city_code = list.getString("deliver_city_code");
            String deliver_district_code = list.getString("deliver_district_code");
            String deliver_address = list.getString("deliver_address");
            String receive_warehouse_code = list.getString("receive_warehouse_code");
            String receiver = list.getString("receiver");
            String receiver_contact = list.getString("receiver_contact");
            String receive_province_code = list.getString("receive_province_code");
            String receive_city_code = list.getString("receive_city_code");
            String receive_district_code = list.getString("receive_district_code");
            String receive_province_name = list.getString("receive_province_name");
            String receive_city_name = list.getString("receive_city_name");
            String receive_district_name = list.getString("receive_district_name");
            String receive_address = list.getString("receive_address");
            String iv = list.getString("iv");
            String remark = list.getString("remark");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            String is_del = list.getString("is_del");
            WarehouseDistributeLogisticPo po = new WarehouseDistributeLogisticPo();
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setWarehouseDistributeOrderNo(warehouse_distribute_order_no);
            po.setEstPickTime(est_pick_time);
            po.setEstArrivalTime(est_arrival_time);
            po.setShippingMethod(shipping_method);
            po.setDeliverWarehouseCode(deliver_warehouse_code);
            po.setShipper(shipper);
            po.setShipperContact(shipper_contact);
            po.setDeliverProvinceCode(deliver_province_code);
            po.setDeliverCityCode(deliver_city_code);
            po.setDeliverDistrictCode(deliver_district_code);
            po.setDeliverAddress(deliver_address);
            po.setReceiveWarehouseCode(receive_warehouse_code);
            po.setReceiver(receiver);
            po.setReceiverContact(receiver_contact);
            po.setReceiveProvinceCode(receive_province_code);
            po.setReceiveCityCode(receive_city_code);
            po.setReceiveDistrictCode(receive_district_code);
            po.setReceiveProvinceName(receive_province_name);
            po.setReceiveCityName(receive_city_name);
            po.setReceiveDistrictName(receive_district_name);
            po.setReceiveAddress(receive_address);
            po.setIv(iv);
            po.setRemark(remark);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            warehouseDistributeLogisticService.save(po);
        }
        ;

    }
    @Override
    public void insertWDO(Statement sourceStatement) throws SQLException {
        ResultSet list = sourceStatement.executeQuery("select * from warehouse_distribute_order;");
        while (list.next()) {
            String biz_type = list.getString("biz_type");
            String order_no = list.getString("order_no");
            String order_time = list.getString("order_time");
            String business_bill_no = list.getString("business_bill_no");
            String logistic_no = list.getString("logistic_no");
            String order_status = list.getString("order_status");
            String order_type = list.getString("order_type");
            String logistic_type = list.getString("logistic_type");
            String source_system = list.getString("source_system");
            String remark = list.getString("remark");
            String reason = list.getString("reason");
            String create_user = list.getString("create_user");
            String update_user = list.getString("update_user");
            String actual_arrival_time = list.getString("actual_arrival_time");
            String is_del = list.getString("is_del");
            WarehouseDistributeOrderPo po = new WarehouseDistributeOrderPo();
            po.setBizType(biz_type);
            po.setIsDel(is_del.isEmpty());
            po.setOrderNo(order_no);
            po.setOrderTime(DateUtils.dateToLocalDateTime(order_time));
            po.setBusinessBillNo(business_bill_no);
            po.setLogisticNo(logistic_no);
            po.setOrderStatus(order_status);
            po.setOrderType(order_type);
            po.setLogisticType(logistic_type);
            po.setSourceSystem(source_system);
            po.setRemark(remark);
            po.setReason(reason);
            po.setCreateUser(create_user);
            po.setUpdateUser(update_user);
            po.setActualArrivalTime(actual_arrival_time);
            warehouseDistributeOrderService.save(po);
        }
    }

}
