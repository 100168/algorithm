package com.jiduauto.sps.order.server.mq.consumer;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeOrderService;
import com.jiduauto.sps.sdk.consts.BaseConstants;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderStatusEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderTypeEnum;
import com.jiduauto.sps.sdk.enums.WarehouseDistributeOrderlogisticTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeOrderPo;
import com.jiduauto.sps.sdk.pojo.req.WmsBillInfoRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

@Slf4j
@Component
@RocketMQMessageListener(consumerGroup = BaseConstants.ConsumerGroup.CG_DIT_SPS_ORDER_WMS_LOGISTICS,
        topic = BaseConstants.RocketMqTopic.TC_DIT_TRACK_BILL_INTO,
        consumeThreadMax = 10)
public class WmsLogisticsConsumer implements RocketMQListener<MessageExt> {

    @Autowired
    private IWarehouseDistributeOrderService warehouseDistributeOrderService;

    //todo 更换consumer
    @Override
    public void onMessage(MessageExt message) {
        String body = new String(message.getBody(), StandardCharsets.UTF_8);
        log.info("入库异步处理业务订单:" + body);
        WmsBillInfoRequest request = JSON.parseObject(body, WmsBillInfoRequest.class);
        if (StringUtils.isNotBlank(request.getBusinessOrderType()) && WarehouseDistributeOrderTypeEnum.isExist(request.getBusinessOrderType())) {
            //仓配订单更新物流单号
            WarehouseDistributeOrderPo orderPo = null;
            if (WarehouseDistributeOrderTypeEnum.SM20.getValue().equals(request.getBusinessOrderType()) || WarehouseDistributeOrderTypeEnum.isApplyOrder(request.getBusinessOrderType())) {
                orderPo = warehouseDistributeOrderService.getOne(Wrappers.lambdaQuery(WarehouseDistributeOrderPo.class).eq(WarehouseDistributeOrderPo::getOrderNo, request.getBusinessNo()));
            } else {
                orderPo = warehouseDistributeOrderService.getOne(Wrappers.lambdaQuery(WarehouseDistributeOrderPo.class)
                        .ne(WarehouseDistributeOrderPo::getOrderStatus, WarehouseDistributeOrderStatusEnum.CANCELED.getCode())
                        .eq(WarehouseDistributeOrderPo::getBusinessBillNo, request.getBusinessNo()));
            }
            if (orderPo == null) {
                return;
            }
            if (WarehouseDistributeOrderlogisticTypeEnum.needTransport(Integer.valueOf(orderPo.getLogisticType()))) {
                warehouseDistributeOrderService.updateLogisticsNoAndStatus(orderPo.getId(), request.getBillNo());
            }
        }
    }
}
