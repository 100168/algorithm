package com.jiduauto.sps.order.server.service;

import com.jiduauto.sps.order.server.pojo.dto.SynchoResultDto;


public interface ISynchroOrderService {

    void batchInsert(SynchoResultDto poMap);
}
