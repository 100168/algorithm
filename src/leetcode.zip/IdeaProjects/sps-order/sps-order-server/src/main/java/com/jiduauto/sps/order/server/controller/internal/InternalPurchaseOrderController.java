package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.sps.order.server.facade.PurchaseOrderFacadeService;
import com.jiduauto.sps.order.server.pojo.dto.InternalPurchaseOrderDetailDto;
import com.jiduauto.sps.order.server.pojo.dto.InternalPurchaseOrderDto;
import com.jiduauto.sps.order.server.pojo.vo.req.*;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * @author panjian
 */
@RestController
@RequestMapping("/internal/purchaseOrder")
@Slf4j
public class InternalPurchaseOrderController {

    @Resource
    private PurchaseOrderFacadeService purchaseOrderFacadeService;

    /**
     * 智子采购订单创建
     * @param request request
     * @return BaseResult
     */
    @PostMapping("/add")
    public BaseResult<String> add(@RequestBody @Valid InternalPurchaseOrderAddReq request) {
        return purchaseOrderFacadeService.internalAdd(request);

    }
    /**
     * 智子采购订单提交
     * @param request request
     * @return BaseResult
     */
    @PostMapping("/commit")
    public BaseResult<String> commit(@RequestBody @Valid InternalPoCommitReq request) {
        return purchaseOrderFacadeService.internalCommit(request);
    }
    /**
     * 智子采购订单删除
     * @param request request
     * @return BaseResult
     */
    @PostMapping("/delete")
    public BaseResult<String> delete(@RequestBody @Valid InternalPoDeleteReq request) {
        return purchaseOrderFacadeService.internalDelete(request);
    }
    /**
     * 智子采购订单列表查询
     * @param pageParam pageParam
     * @return BaseResult
     */
    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<InternalPurchaseOrderDto>> internalPageSearch(@RequestBody @Valid BasePageParam<InternalPoSearchReq> pageParam) {
        return BaseResult.OK(purchaseOrderFacadeService.internalPageSearch(pageParam));
    }

    /**智子采购订单明细分页查询接口*/
    @PostMapping("/detail/pageSearch")
    public BaseResult<BasePageData<InternalPurchaseOrderDetailDto>> internalDetailPageSearch(@RequestBody @Valid BasePageParam<PurchaseOrderDetailSearchReq> pageSearchReq) {
        return BaseResult.OK(purchaseOrderFacadeService.internalDetailPageSearch(pageSearchReq));
    }

    /**智子采购订单列表批量查询接口*/
    @PostMapping("/list")
    public BaseResult<List<InternalPurchaseOrderDto>> internalPageSearch(@RequestBody @Valid PurchaseOrderListSearchReq listSearchReq) {
        return BaseResult.OK(purchaseOrderFacadeService.list(listSearchReq));
    }

}
