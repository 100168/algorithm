package com.jiduauto.sps.order.server.controller.internal;

import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreRecommendationListDelReq;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreRecommendationListOperateReq;
import com.jiduauto.sps.order.server.service.impl.StoreRecommendationListFacadeService;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 智子 门店推荐清单接口
 */
@RestController
@RequestMapping("/internal/storeRecommendationList")
public class InternalStoreRecommendationList {

    @Resource
    private StoreRecommendationListFacadeService storeRecommendationListFacadeService;

    /**
     * 新增门店推荐清单,存在则更新
     */
    @PostMapping("/operate")
    public BaseResult<String> operate(@RequestBody @Valid InternalStoreRecommendationListOperateReq req) {
        storeRecommendationListFacadeService.operate(req);
        return BaseResult.OK();
    }

    /**
     * 根据门店+零件编码删除
     */
    @PostMapping("/delete")
    public BaseResult<String> operate(@RequestBody @Valid InternalStoreRecommendationListDelReq req) {
        storeRecommendationListFacadeService.delete(req);
        return BaseResult.OK();
    }
}
