package com.jiduauto.sps.order.server.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jiduauto.sps.order.server.mapper.WarehouseDistributeItemAttachMapper;
import com.jiduauto.sps.order.server.pojo.vo.req.warehousedistributeorder.NumberNoReq;
import com.jiduauto.sps.order.server.service.IWarehouseDistributeItemAttachService;
import com.jiduauto.sps.order.server.utils.BaseDataQuery;
import com.jiduauto.sps.sdk.enums.DictEnum;
import com.jiduauto.sps.sdk.pojo.dto.warehousedistributeorder.WarehouseDistributeAttachItemDto;
import com.jiduauto.sps.sdk.pojo.po.WarehouseDistributeItemAttachPo;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import com.jiduauto.sps.sdk.utils.BeanCopierUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * <p>
 * 仓配订单零件附属信息 服务实现类
 * </p>
 *
 * @author generate
 * @since 2023-07-12
 */
@Service
public class WarehouseDistributeItemAttachServiceImpl extends ServiceImpl<WarehouseDistributeItemAttachMapper, WarehouseDistributeItemAttachPo> implements IWarehouseDistributeItemAttachService {

    @Resource
    private BaseDataQuery baseDataQuery;

    @Override
    public BaseResult<BasePageData<WarehouseDistributeAttachItemDto>> pageSearch(BasePageParam<NumberNoReq> req) {
        NumberNoReq param = req.getParam();
        String numberNo = param.getNumberNo();
        IPage<WarehouseDistributeItemAttachPo> iPage = new Page<>(req.getPage(), req.getSize());
        //领用用途
        iPage = baseMapper.selectPage(iPage,
                Wrappers.lambdaQuery(WarehouseDistributeItemAttachPo.class)
                        .eq(WarehouseDistributeItemAttachPo::getWarehouseDistributeOrderNo, numberNo)
                        .orderByDesc(WarehouseDistributeItemAttachPo::getId));
        List<WarehouseDistributeAttachItemDto> collect = getDtoList(iPage.getRecords());
        BasePageData<WarehouseDistributeAttachItemDto> pageData = new BasePageData<>(iPage);
        pageData.setRecords(collect);
        return BaseResult.OK(pageData);
    }

    @Override
    public List<WarehouseDistributeAttachItemDto> getDtoList(List<WarehouseDistributeItemAttachPo> pos) {
        Map<String, String> sakeMap = baseDataQuery.getCodeAndNameMap(DictEnum.ApplySake.getDictCode());
        return pos.stream()
                .map(e -> {
                    WarehouseDistributeAttachItemDto itemDto = BeanCopierUtil.copy(e, WarehouseDistributeAttachItemDto.class);
                    itemDto.setApplyPurposeName(sakeMap.get(e.getApplyPurpose()));
                    return itemDto;
                }).collect(Collectors.toList());
    }

    @Override
    public List<WarehouseDistributeItemAttachPo> getByOrderNo(String orderNo) {
        return list(Wrappers.<WarehouseDistributeItemAttachPo>lambdaQuery().eq(WarehouseDistributeItemAttachPo::getWarehouseDistributeOrderNo, orderNo));
    }
}
