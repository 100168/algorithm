package com.jiduauto.sps.order.server.controller;


import com.jiduauto.sps.order.server.pojo.dto.EmergencyTransferStoreDto;
import com.jiduauto.sps.order.server.pojo.vo.req.EmergencyTransferStoreSearchReq;
import com.jiduauto.sps.order.server.service.IEmergencyTransferStoreService;
import com.jiduauto.sps.sdk.pojo.fileImport.ImportResultResp;
import com.jiduauto.sps.sdk.pojo.req.IdBatchReq;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import com.jiduauto.sps.sdk.pojo.vo.BaseResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;

/**
 * 应急调拨门店
 */
@RestController
@RequestMapping("/emergencyTransferStore")
public class EmergencyTransferStoreController {

    @Resource
    private IEmergencyTransferStoreService emergencyTransferStoreService;

    @PostMapping("/pageSearch")
    public BaseResult<BasePageData<EmergencyTransferStoreDto>> pageSearch(@RequestBody @Valid BasePageParam<EmergencyTransferStoreSearchReq> pageParam) {
        return BaseResult.OK(emergencyTransferStoreService.pageSearch(pageParam));
    }

    /**
     * 根据 id 批量删除
     */
    @PostMapping("/delete")
    public BaseResult<String> pageSearch(@RequestBody @Valid IdBatchReq idList) {
        emergencyTransferStoreService.removeByIds(idList.getIdList());
        return BaseResult.OK();
    }

    /**
     * 导入
     */
    @PostMapping("/import")
    public BaseResult<ImportResultResp> importExcel(@RequestHeader("bizType") String bizType,
                                                    @RequestPart("file") MultipartFile file) {
        return BaseResult.OK(emergencyTransferStoreService.importExcel(bizType, file));
    }

}
