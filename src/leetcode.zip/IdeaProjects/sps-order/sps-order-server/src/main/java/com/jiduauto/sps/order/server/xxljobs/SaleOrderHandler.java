package com.jiduauto.sps.order.server.xxljobs;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jiduauto.sps.order.server.service.IPurchaseOrderDetailService;
import com.jiduauto.sps.order.server.service.ISaleOrderDetailService;
import com.jiduauto.sps.order.server.service.ISaleOrderService;
import com.jiduauto.sps.order.server.utils.WebhookUtil;
import com.jiduauto.sps.sdk.enums.BizTypeEnum;
import com.jiduauto.sps.sdk.pojo.po.PurchaseOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.SaleOrderPo;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@Slf4j
public class SaleOrderHandler {

    @Resource
    private ISaleOrderService saleOrderService;

    @Resource
    private WebhookUtil webhookUtil;

    @Resource
    private ISaleOrderDetailService saleOrderDetailService;

    @Resource
    private IPurchaseOrderDetailService purchaseOrderDetailService;

    @XxlJob("updateEstArrivalTimeHandler")
    public ReturnT<String> updateEstArrivalTimeHandler(String param) {
        try {
            log.info("updateEstArrivalTimeHandler start, param: {}", param);
            saleOrderService.batchUpdateEstArrivalTime();
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("updateEstArrivalTimeHandler");
            log.error("updateEstArrivalTimeHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 根据下发时间下发待下发的STK订单
     */
    @XxlJob("stkSaleOrderIssueHandler")
    public ReturnT<String> stkSaleOrderIssueHandler(String param) {
        try {
            log.info("stkSaleOrderIssueHandler start, param: {}", param);
            saleOrderService.stkSaleOrderIssue();
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("stkSaleOrderIssueHandler");
            log.error("stkSaleOrderIssueHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * 根据门店OrderCalendar配置的下发金额  下发待下发的STK订单
     * <a href="https://jiduauto.feishu.cn/wiki/SjqXw1GVVi2gK7kg7o2c94QonDd"/>
     */
    @XxlJob("stkSaleOrderIssueByAmountHandler")
    public ReturnT<String> stkSaleOrderIssueByAmountHandler(String param) {
        try {
            log.info("stkSaleOrderIssueByAmountHandler start, param: {}", param);
            saleOrderService.stkSaleOrderIssueByAmountHandler();
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("stkSaleOrderIssueByAmountHandler");
            log.error("stkSaleOrderIssueByAmountHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    /**
     * RO且非DFS的销售订单、CO定制件订单定时下发
     */
    @XxlJob("roAndCoSaleOrderIssueHandler")
    public ReturnT<String> roAndCoSaleOrderIssueHandler(String param) {
        try {
            log.info("roAndCoSaleOrderIssueHandler start, param: {}", param);
            saleOrderService.roAndCoSaleOrderIssueHandler();
        } catch (Exception e) {
            webhookUtil.sendXXlJobFailMessage("roAndCoSaleOrderIssueHandler");
            log.error("roAndCoSaleOrderIssueHandler error", e);
            throw e;
        }
        return ReturnT.SUCCESS;
    }

    @XxlJob("saleOrderTotalAmountFix")
    public ReturnT<String> saleOrderTotalAmountFix(String param) {
        try {
            String num = "1000";
            if (StrUtil.isNotBlank(param)) {
                num = param;
            }
            List<SaleOrderPo> list = saleOrderService.list(
                    Wrappers.<SaleOrderPo>lambdaQuery()
                            .eq(SaleOrderPo::getSaleOrderAmount, BigDecimal.ZERO)
                            .eq(SaleOrderPo::getBizType, BizTypeEnum.SP.getBizType())
                            .orderByAsc(SaleOrderPo::getCreateTime)
                            .last("limit " + num)
            );
            List<String> saleOrderNoList = list.stream().map(SaleOrderPo::getSaleOrderNo).distinct().collect(Collectors.toList());
            List<String> purchaseOrderNoList = list.stream().map(SaleOrderPo::getPurchaseOrderNo).distinct().collect(Collectors.toList());
            if (CollUtil.isEmpty(saleOrderNoList)) {
                return ReturnT.SUCCESS;
            }
            List<SaleOrderDetailPo> detail = saleOrderDetailService.list(
                    Wrappers.<SaleOrderDetailPo>lambdaQuery()
                            .in(SaleOrderDetailPo::getSaleOrderNo, saleOrderNoList)
            );
            if (CollUtil.isEmpty(detail)) {
                return ReturnT.SUCCESS;
            }
            List<PurchaseOrderDetailPo> poDetailList = purchaseOrderDetailService.list(
                    Wrappers.<PurchaseOrderDetailPo>lambdaQuery()
                            .in(PurchaseOrderDetailPo::getPurchaseOrderNo, purchaseOrderNoList)
            );

            Map<String, PurchaseOrderDetailPo> poDetailMap = poDetailList.stream().collect(Collectors.toMap(
                    o -> o.getPurchaseOrderNo() + o.getSalePartNum(), Function.identity(), (p, n) -> n
            ));
            Map<String, String> soNoAndPoMap = list.stream().collect(Collectors.toMap(SaleOrderPo::getSaleOrderNo, SaleOrderPo::getPurchaseOrderNo, (p, n) -> n));

            for (String saleOrderNo : saleOrderNoList) {

                BigDecimal totalAmount = detail.stream().filter(e -> e.getSaleOrderNo().equals(saleOrderNo))
                        .map(i -> {
                            PurchaseOrderDetailPo poDetail = poDetailMap.get(soNoAndPoMap.get(saleOrderNo) + i.getSalePartNum());
                            return poDetail.getDiscountUnitPrice().multiply(i.getQty());
                        })
                        .reduce(BigDecimal.ZERO, BigDecimal::add);

                saleOrderService.update(
                        Wrappers.<SaleOrderPo>lambdaUpdate()
                                .set(SaleOrderPo::getSaleOrderAmount, totalAmount)
                                .eq(SaleOrderPo::getSaleOrderNo, saleOrderNo)
                );
            }
            return ReturnT.SUCCESS;
        } catch (Exception e) {
            log.error("saleOrderTotalAmountFix error", e);
            throw e;
        }
    }

}
