package com.jiduauto.sps.order.server.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jiduauto.sps.order.server.pojo.dto.StoreTransferOrderDto;
import com.jiduauto.sps.order.server.pojo.dto.StoreTransferOrderExportDto;
import com.jiduauto.sps.order.server.pojo.vo.req.InternalStoreTransferOrderOperateReq;
import com.jiduauto.sps.order.server.pojo.vo.req.StoreTransferOrderReq;
import com.jiduauto.sps.sdk.enums.StoreTransferOrderOperate;
import com.jiduauto.sps.sdk.enums.StoreTransferOrderStatus;
import com.jiduauto.sps.sdk.pojo.po.StoreTransferOrderDetailPo;
import com.jiduauto.sps.sdk.pojo.po.StoreTransferOrderPo;
import com.jiduauto.sps.sdk.pojo.req.InAndOutStockRequest;
import com.jiduauto.sps.sdk.pojo.vo.BasePageData;
import com.jiduauto.sps.sdk.pojo.vo.BasePageParam;
import java.util.Collection;
import java.util.List;

/**
 * <p>
 * 门店调拨单 服务类
 * </p>
 */
public interface IStoreTransferOrderService extends IService<StoreTransferOrderPo> {
    /**
     * 门店调拨单条件查询
     */
    BasePageData<StoreTransferOrderDto> pageSearch(BasePageParam<StoreTransferOrderReq> pageParam);

    /**
     * 保存订单 & 明细
     */
    void savePoAndDetail(StoreTransferOrderPo orderPo, List<StoreTransferOrderDetailPo> detailList);

    /**
     * 状态变更日志记录
     */
    void statusLog(StoreTransferOrderStatus status,
                   StoreTransferOrderOperate opt,
                   String no,
                   String bizType,
                   String user
    );

    /**
     * 主数据字段变更日志记
     */
    void fieldLog(StoreTransferOrderPo oldData, StoreTransferOrderPo newData, String user);

    /**
     * 详情字段变更日志记
     */
    void detailFieldLog(StoreTransferOrderDetailPo oldData, StoreTransferOrderDetailPo newData, String user);

    /**
     * 取消
     */
    void cancelOrder(InternalStoreTransferOrderOperateReq req);

    /**
     * 更新状态并记录日志
     */
    void updateStatusAndLog(String no, StoreTransferOrderStatus status, String user, StoreTransferOrderOperate opt);

    /**
     *出库数量反写
     */
    void updateTransferOutQty(InAndOutStockRequest request);

    /**
     *入库数量反写
     */
    void updateTransferInQty(InAndOutStockRequest request);
    /**
     * 调拨单导出
     *
     **/
    Collection<StoreTransferOrderExportDto> export(BasePageParam<StoreTransferOrderReq> pageParam);
}
