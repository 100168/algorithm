alter table warehouse_distribute_item
    add standard_packing_qty decimal(20, 3) default 0 not null comment '标准装箱数量' after warehouse_distribute_order_no;

alter table warehouse_distribute_item_package
    add standard_packing_qty decimal(20, 3) default 0 not null comment '标准装箱数量' after warehouse_distribute_order_no;

alter table warehouse_distribute_item_package
    add real_packing_qty decimal(20, 3) default 0 not null comment '实际装箱数量' after warehouse_distribute_order_no;