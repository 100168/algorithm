drop index idx_idempotent_log on idempotent_log;

# 清除表中所有数据 or 检查是否有唯一索引重复数据
delete from idempotent_log where is_del = false;

create unique index uk_idx_idempotent_api_url
    on idempotent_log (idempotent_no, api_url);

