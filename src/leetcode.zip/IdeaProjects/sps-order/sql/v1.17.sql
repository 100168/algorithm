alter table warehouse_distribute_logistic
    add logistic_company varchar(32) default '' not null comment '物流公司' after warehouse_distribute_order_no;

alter table warehouse_distribute_logistic
    add deliver_province_name varchar(32) default '' not null comment '发货省名字' after deliver_province_code;
alter table warehouse_distribute_logistic
    add deliver_city_name varchar(32) default '' not null comment '发货市名字' after deliver_city_code;
alter table warehouse_distribute_logistic
    add deliver_district_name varchar(32) default '' not null comment '发货县名字' after deliver_district_code;

alter table warehouse_distribute_order
    add associate_bill_no varchar(32) default '' not null comment '关联单号' after order_no;