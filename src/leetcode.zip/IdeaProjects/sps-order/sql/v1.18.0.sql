create table sap_invoice_info
(
    id             bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type       varchar(16)    default ''                not null comment '业务类型',
    invoice_no     varchar(100)   default ''                not null comment '发票单号',
    invoice_url    varchar(500)   default ''                not null comment '文件链接',
    invoice_date   varchar(10)    default ''                not null comment '开票日期',
    invoice_amount decimal(20, 2) default 0.00              not null comment '发票金额',
    remark         varchar(1024)  default ''                not null comment '备注',
    is_del         bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user    char(32)       default ''                not null comment '创建者',
    create_time    datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user    char(32)       default ''                not null comment '更新者',
    update_time    datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment 'sap发票信息表';

#销售订单发票关联表
create table sale_order_invoice_relation
(
    id            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type      varchar(16)   default ''                not null comment '业务类型',
    sale_order_no varchar(30)   default ''                not null comment '销售单号',
    sps_order_no  varchar(30)   default ''                not null comment 'sps 单号(销售单号 or 仓配单号)',
    invoice_no    varchar(100)  default ''                not null comment '发票号',
    item_key      varchar(20)   default ''                not null comment 'sap 行信息Key值',
    invoice_type  varchar(10)   default ''                not null comment '关联发票类型 RED 红票  NORMAL 普票',
    remark        varchar(1024) default ''                not null comment '备注',
    is_del        bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user   char(32)      default ''                not null comment '创建者',
    create_time   datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user   char(32)      default ''                not null comment '更新者',
    update_time   datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '销售订单发票关联表';

create index idx_invoice_no
    on sap_invoice_info (invoice_no);

create index idx_sale_order_no
    on sale_order_invoice_relation (sale_order_no);

alter table sale_order_invoice_relation
    add sap_order_no varchar(30) default '' not null comment 'sap 单号' after invoice_no;

