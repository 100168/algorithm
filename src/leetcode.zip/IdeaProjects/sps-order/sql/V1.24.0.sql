
alter table t_outbox_message
    add max_retry_count int default 20 not null comment '最大重试次数';

alter table t_outbox_message
    add notice_count int default 2 not null comment '重试多少次之后，发送失败告警';