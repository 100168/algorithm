drop index idx_idempotent_log on idempotent_log;

# 清除表中所有数据 or 检查是否有唯一索引重复数据
delete from idempotent_log where is_del = false;

create unique index uk_idx_idempotent_api_url
    on idempotent_log (idempotent_no, api_url);

alter table purchase_order_detail
    add is_control varchar(2) default '' not null comment '管控件(Y是,N否)' after line_amount;

alter table purchase_order
    add turn_control_status varchar(32) default '' not null comment '管控件转单状态' after receiver_address;

alter table back_order
    add is_control varchar(2) default '' not null comment '冗余字段 取自purchase_order_detail管控件(Y是,N否)' after store_code;

alter table purchase_order_detail
    add turned_control_qty decimal(20, 3) default 0.000 not null comment '管控件已转单数量' after line_amount;

create table purchase_order_part_transfer_operate
(
    id                       bigint unsigned auto_increment comment '主键'
        primary key,
    purchase_order_detail_id bigint         default 0                 not null comment '采购订单明细ID',
    qty                      decimal(20, 3) default 0.000             not null comment '转单数量',
    turn_status              varchar(32)    default ''                not null comment '转单状态',
    turn_type                varchar(10)    default ''                not null comment '转单模式 SO BO',
    sale_order_no            varchar(32)    default ''                not null comment '此次转单生成的销售订单号',
    back_order_no            varchar(32)    default ''                not null comment '此次转单生成的缺件订单号',
    remark                   varchar(1024)  default ''                not null comment '备注',
    is_del                   bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user              char(32)       default ''                not null comment '创建者',
    create_time              datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user              char(32)       default ''                not null comment '更新者',
    update_time              datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '采购订单部分转单操作表';


alter table warehouse_distribute_order
    add is_special bit default b'0' not null comment '是否需要特殊处理' after id;

alter table purchase_order_detail
    add is_dfs varchar(2) default '' not null comment '零件是否 DFS Y是 N否' after is_control;