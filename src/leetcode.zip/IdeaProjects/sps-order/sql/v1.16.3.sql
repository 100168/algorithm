alter table purchase_order
    add head_remark varchar(100) default '' not null comment '订单主数据备注' after receiver_address;
