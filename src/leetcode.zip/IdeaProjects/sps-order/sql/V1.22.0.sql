alter table purchase_order_detail
    add discount_rate decimal(20, 2) default 0.00 not null comment '折扣率' after is_dfs;


