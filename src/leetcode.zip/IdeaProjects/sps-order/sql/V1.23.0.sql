alter table warehouse_distribute_order
    add responsible_party varchar(64) default '' not null comment '责任方' after is_api;

create table standard_recommendation_list
(
    id             bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type       varchar(10)     default ''                not null comment '业务类型',
    store_code     varchar(50)     default ''                not null comment '门店code',
    material_code  varchar(64)     default ''                not null comment '备件号码',
    min_qty        int             default 0                 not null comment '最小推荐值',
    max_qty        int             default 0                 not null comment '最大推荐值',
    del_unique_key bigint unsigned default 0                 not null comment '唯一索引，删除后用Id赋值',
    remark         varchar(1024)   default ''                not null comment '备注',
    is_del         bit             default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user    char(32)        default ''                not null comment '创建者',
    create_time    datetime        default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user    char(32)        default ''                not null comment '更新者',
    update_time    datetime        default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint uk_sc_mc_duk_bt
        unique (store_code, material_code, del_unique_key, biz_type)
) DEFAULT CHARSET = utf8mb4 comment '标准推荐清单';

create table store_recommendation_list
(
    id             bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type       varchar(10)     default ''                not null comment '业务类型',
    store_code     varchar(50)     default ''                not null comment '门店code',
    material_code  varchar(64)     default ''                not null comment '备件号码',
    min_qty        int             default 0                 not null comment '最小推荐值',
    max_qty        int             default 0                 not null comment '最大推荐值',
    del_unique_key bigint unsigned default 0                 not null comment '唯一索引，删除后用Id赋值',
    remark         varchar(1024)   default ''                not null comment '备注',
    is_del         bit             default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user    char(32)        default ''                not null comment '创建者',
    create_time    datetime        default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user    char(32)        default ''                not null comment '更新者',
    update_time    datetime        default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint uk_sc_mc_duk_bt
        unique (store_code, material_code, del_unique_key, biz_type)
) DEFAULT CHARSET = utf8mb4 comment '门店推荐清单';
