alter table warehouse_distribute_attach
    add product_line_and_rate varchar(100) default '' not null comment '产品线及比例' after apply_purpose;

alter table warehouse_distribute_item_attach
    add subject_code varchar(100) default '' not null comment '管报科目' after apply_purpose;