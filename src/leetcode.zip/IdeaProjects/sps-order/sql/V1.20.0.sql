alter table purchase_order_detail
    add standard_price_include_tax decimal(20, 2) default 0.00 not null comment '标准价格 含税' after qty;

alter table purchase_order_detail
    add standard_price_exclude_tax decimal(20, 2) default 0.00 not null comment '标准价格 不含税' after qty;

alter table sale_order
    add sale_order_amount decimal(20, 2) default 0.00 not null comment '销售订单总金额' after purchase_order_no;

