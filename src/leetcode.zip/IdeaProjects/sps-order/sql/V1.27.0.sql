alter table warehouse_distribute_order
    add in_process_code varchar(10) default '' not null comment '入库流程code';

alter table warehouse_distribute_order
    add out_process_code varchar(10) default '' not null comment '出库流程code';