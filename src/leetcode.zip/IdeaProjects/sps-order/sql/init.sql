CREATE TABLE `t_outbox_message` (
                                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
                                    `msg_id` varchar(64) NOT NULL DEFAULT '' COMMENT '消息id',
                                    `msg_type` varchar(64) NOT NULL DEFAULT '' COMMENT '消息类型',
                                    `content` longtext NOT NULL COMMENT '消息内容',
                                    `retry_count` int(11) NOT NULL DEFAULT '0' COMMENT '重试次数',
                                    `bit_status` int(11) NOT NULL DEFAULT '0' COMMENT '状态',
                                    `remark` varchar(1023) NOT NULL DEFAULT '' COMMENT '备注',
                                    `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                                    `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
                                    PRIMARY KEY (`id`),
                                    KEY `idx_msg_id` (`msg_id`),
                                    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='发件箱消息';

CREATE TABLE `invoke_log` (
                              `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT  '主键',
                              `class_name` varchar(45)  NOT NULL DEFAULT '' COMMENT  '类名',
                              `method_name` varchar(45)  NOT NULL DEFAULT '' COMMENT  '方法名',
                              `request` text  NOT NULL COMMENT '请求参数字符串',
                              `response` varchar(1024)  NOT NULL DEFAULT '' COMMENT '接口返回值',
                              `import_file_url` varchar(200) NOT NULL DEFAULT '' COMMENT '上传导入接口的文件路径',
                              `remark` varchar(1024)  NOT NULL DEFAULT '' COMMENT '备注',
                              `is_del` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否删除 1是 0否 默认0',
                              `create_user` char(32)  NOT NULL DEFAULT '' COMMENT '创建者',
                              `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                              `update_user` char(32)  NOT NULL DEFAULT '' COMMENT '更新者',
                              `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
                              PRIMARY KEY (`id`),
                              KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='接口调用log，参数快照';

create table back_order
(
    id                bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type          varchar(16)    default ''                not null comment '业务类型',
    back_order_no     varchar(32)    default ''                not null comment '缺件单号',
    back_order_type   varchar(32)    default ''                not null comment '缺件订单类型 STK 门店订单 ；RO  紧急 ； VOR 超紧急',
    purchase_order_no varchar(32)    default ''                not null comment '采购订单号',
    sale_part_num     varchar(64)    default ''                not null comment '售后件号',
    back_qty          decimal(20, 3) default 0.000             not null comment '缺件总数',
    rest_back_qty     decimal(20, 3) default 0.000             not null comment '剩余缺件总数',
    back_order_status varchar(32)    default ''                not null comment '缺件订单状态 PENDING 待处理；CLOSED 关闭；TRANSFER_FAILED 转单失败；PROCESSING 处理中；CANCEL_PENDING 取消审批中；CANCELED 取消',
    est_arrival_time  varchar(18)    default ''                not null comment '预计到货时间',
    delay_explanation varchar(1024)  default ''                not null comment '延期说明',
    store_code        varchar(50)    default ''                not null comment '门店编码',
    remark            varchar(1024)  default ''                not null comment '备注',
    is_del            bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user       char(32)       default ''                not null comment '创建者',
    create_time       datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user       char(32)       default ''                not null comment '更新者',
    update_time       datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint uk_back_order_no
        unique (back_order_no)
)
    comment '缺件订单 ';

create index idx_purchase_order_no
    on back_order (purchase_order_no);


create table if not exists back_order_operate_log
(
    id            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type      varchar(16)   default ''                not null comment '业务类型',
    back_order_no varchar(32)   default ''                not null comment '缺件单号',
    action_desc   varchar(32)   default ''                not null comment '操作描述',
    modify_column varchar(32)   default ''                not null comment '修改字段',
    old_value     varchar(32)   default ''                not null comment '原始值',
    new_value     varchar(32)   default ''                not null comment '修改值',
    remark        varchar(1024) default ''                not null comment '备注',
    is_del        bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user   char(32)      default ''                not null comment '创建者',
    create_time   datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user   char(32)      default ''                not null comment '更新者',
    update_time   datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '缺件订单操作记录';

create index idx_back_order_no_index
    on back_order_operate_log (back_order_no);

create table back_sale_relation
(
    id            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type      varchar(16)   default ''                not null comment '业务类型',
    back_order_no varchar(32)   default ''                not null comment '缺件单号',
    sale_order_no varchar(32)   default ''                not null comment '销售单号',
    remark        varchar(1024) default ''                not null comment '备注',
    is_del        bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user   char(32)      default ''                not null comment '创建者',
    create_time   datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user   char(32)      default ''                not null comment '更新者',
    update_time   datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '缺件订单跟销售订单的关系';

create index idx_bo_and_so_no_index
    on back_sale_relation (back_order_no, sale_order_no);

create table purchase_order
(
    id                         bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type                   varchar(16)    default ''                not null comment '业务类型',
    trade_no                   varchar(32)    default ''                not null comment '订单交易流水号',
    purchase_order_no          varchar(32)    default ''                not null comment '采购订单号',
    sap_order_no               varchar(32)    default ''                not null comment 'SAP单号',
    purchase_order_attr        varchar(32)    default ''                not null comment '采购订单归属 101 售后自营；102 售后授权',
    purchase_order_type        varchar(32)    default ''                not null comment '采购订单类型 STK 门店订单 ； CO 定制件 ；RO  紧急 ； VOR 超紧急',
    store_code                 varchar(50)    default ''                not null comment '门店编码',
    commit_time                datetime       default CURRENT_TIMESTAMP not null comment '订单提交时间',
    receive_warehouse_code     varchar(200)   default ''                not null comment '收货仓库编码',
    purchase_order_amount      decimal(20, 2) default 0.00              not null comment '订单总金额',
    purchase_order_status      varchar(32)    default ''                not null comment '订单状态 PENDING_REVIEW 待审核；APPROVED 已审核；TRANSFER_FAILED 转单失败；TRANSFER_SUCCESSFUL 处理中； COMPLETED 已完成；CANCELED 已取消； PROCESSED 已处理；',
    receiver                   varchar(100)   default ''                not null comment '收件人',
    receiver_phone             varchar(32)    default ''                not null comment '收件人电话',
    receiver_province          varchar(50)    default ''                not null comment '收货省',
    receiver_city              varchar(50)    default ''                not null comment '收货城市',
    receiver_district          varchar(50)    default ''                not null comment '收货区',
    receiver_address           varchar(500)   default ''                not null comment '收货详细地址',
    vin                        varchar(32)    default ''                not null comment 'vin',
    remark                     varchar(1024)  default ''                not null comment '备注',
    sap_order_create_time      datetime       default CURRENT_TIMESTAMP not null comment 'sap创建时间',
    is_del                     bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user                char(32)       default ''                not null comment '创建者',
    create_time                datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user                char(32)       default ''                not null comment '更新者',
    update_time                datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    turn_purchase_order_status varchar(50)    default ''                not null comment '转采购申请订单状态 TREAT_HANDLE 待处理 ；APPROVED 已处理；TRANSFER_FAILED 转单失败；',
    constraint uk_purchase_order_no
        unique (purchase_order_no)
)
    comment '采购订单';


create table purchase_order_detail
(
    id                  bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type            varchar(16)    default ''                not null comment '业务类型',
    purchase_order_no   varchar(32)    default ''                not null comment '采购订单号',
    sale_part_num       varchar(64)    default ''                not null comment '售后件号',
    discount_unit_price decimal(20, 2) default 0.00              not null comment '折后单价',
    qty                 decimal(20, 3) default 0.000             not null comment '数量',
    line_amount         decimal(20, 2) default 0.00              not null comment '行金额',
    remark              varchar(1024)  default ''                not null comment '备注',
    is_del              bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user         char(32)       default ''                not null comment '创建者',
    create_time         datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user         char(32)       default ''                not null comment '更新者',
    update_time         datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    vin                 varchar(50)    default ''                not null comment 'vin号',
    store_remark        varchar(100)   default ''                not null comment '门店备注'
)
    comment '采购订单明细';

create index idx_purchase_order_no_index
    on purchase_order_detail (purchase_order_no);

create index idx_sale_part_num
    on purchase_order_detail (sale_part_num);




create table purchase_order_operate_log
(
    id                bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type          varchar(16)   default ''                not null comment '业务类型',
    purchase_order_no varchar(32)   default ''                not null comment '采购订单号',
    action_desc       varchar(32)   default ''                not null comment '操作描述',
    modify_column     varchar(32)   default ''                not null comment '修改字段',
    old_value         varchar(32)   default ''                not null comment '原始值',
    new_value         varchar(32)   default ''                not null comment '修改值',
    remark            varchar(1024) default ''                not null comment '备注',
    is_del            bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user       char(32)      default ''                not null comment '创建者',
    create_time       datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user       char(32)      default ''                not null comment '更新者',
    update_time       datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '采购订单操作记录';

create index idx_purchase_order_no_index
    on purchase_order_operate_log (purchase_order_no);

create table sale_order
(
    id                     bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type               varchar(16)   default ''                not null comment '业务类型',
    sale_order_no          varchar(32)   default ''                not null comment '销售单号',
    sap_order_no           varchar(32)   default ''                not null comment 'SAP单号',
    is_dfs                 bit           default b'0'              not null comment '是否dfs',
    purchase_order_no      varchar(32)   default ''                not null comment '采购订单号',
    deliver_warehouse_code varchar(200)  default ''                not null comment '发货仓库编码',
    dfs_status             varchar(32)   default ''                not null comment 'DFS状态 PENDING 待处理；TRANSFER_FAILED 转单失败；TRANSFER_SUCCESSFUL 转单成功；',
    sale_order_status      varchar(32)   default ''                not null comment '销售订单状态 WAIT_ISSUED 待处理；PENDING_DELIVERY 待发货；DELIVERED 已发货； PARTIALLY_RECEIVED 部分收货；FULLY_RECEIVED 全部收货；CANCELED 已取消；',
    sale_order_type        varchar(32)   default ''                not null comment '销售订单类型  STK 门店订单 ； CO 定制件 ；RO  紧急 ； VOR 超紧急',
    transfer_advice        varchar(32)   default ''                not null comment '运输建议',
    sale_order_attr        varchar(32)   default ''                not null comment '销售订单归属 101 售后自营；102 售后授权',
    stock_out_time         varchar(32)   default ''                not null comment '出库时间',
    est_arrival_time       varchar(32)   default ''                not null comment '预计到货时间',
    logistics_no           varchar(64)   default ''                not null comment '物流单号',
    transport_type         varchar(50)   default ''                not null comment 'WMS实际运输方式',
    store_code             varchar(50)   default ''                not null comment '门店编码',
    plan_issue_time        varchar(32)   default ''                not null comment '预计下发时间',
    issued_time            varchar(32)   default ''                not null comment '下发成功时间',
    receive_warehouse_code varchar(200)  default ''                not null comment '收货仓库编码',
    receiver_province      varchar(50)   default ''                not null comment '收货省',
    receiver_city          varchar(50)   default ''                not null comment '收货城市',
    receiver_district      varchar(50)   default ''                not null comment '收货区',
    receiver               varchar(100)  default ''                not null comment '收件人',
    receiver_phone         varchar(32)   default ''                not null comment '收件人电话',
    receiver_address       varchar(500)  default ''                not null comment '收货地址',
    is_claim_whitelist     bit           default b'0'              not null comment '是否 索赔白名单',
    remark                 varchar(1024) default ''                not null comment '备注',
    is_del                 bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user            char(32)      default ''                not null comment '创建者',
    create_time            datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user            char(32)      default ''                not null comment '更新者',
    update_time            datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint uk_sale_order_no
        unique (sale_order_no)
)
    comment '销售订单';

create index idx_purchase_order_no
    on sale_order (purchase_order_no);

create table sale_order_detail
(
    id            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type      varchar(16)    default ''                not null comment '业务类型',
    sale_order_no varchar(32)    default ''                not null comment '销售单号',
    sale_part_num varchar(64)    default ''                not null comment '售后件号',
    deliver_qty   decimal(20, 3) default 0.000             not null comment '发货数量',
    qty           decimal(20, 3) default 0.000             not null comment '数量',
    receive_qty   decimal(20, 3) default 0.000             not null comment '收货数量',
    cancel_qty    decimal(20, 3) default 0.000             not null comment '取消数量',
    remark        varchar(1024)  default ''                not null comment '备注',
    is_del        bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user   char(32)       default ''                not null comment '创建者',
    create_time   datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user   char(32)       default ''                not null comment '更新者',
    update_time   datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '采购订单明细';

create index idx_sale_order_no
    on sale_order_detail (sale_order_no);

create index idx_sale_order_no_index
    on sale_order_detail (sale_order_no);

create index idx_sale_part_num
    on sale_order_detail (sale_part_num);

create table sale_order_operate_log
(
    id            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type      varchar(16)   default ''                not null comment '业务类型',
    sale_order_no varchar(32)   default ''                not null comment '销售单号',
    action_desc   varchar(32)   default ''                not null comment '操作描述',
    modify_column varchar(32)   default ''                not null comment '修改字段',
    old_value     varchar(32)   default ''                not null comment '原始值',
    new_value     varchar(32)   default ''                not null comment '修改值',
    remark        varchar(1024) default ''                not null comment '备注',
    is_del        bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user   char(32)      default ''                not null comment '创建者',
    create_time   datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user   char(32)      default ''                not null comment '更新者',
    update_time   datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '销售订单操作记录';

create index idx_sale_order_no_index
    on sale_order_operate_log (sale_order_no);


create table warehouse_distribute_order
(
    id               bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type         varchar(16)   default ''                not null comment '业务类型',
    order_no         varchar(64)   default ''                not null comment '订单号',
    order_time       datetime      default CURRENT_TIMESTAMP not null comment '订单时间',
    business_bill_no varchar(64)   default ''                not null comment '业务单号',
    logistic_no      varchar(64)   default ''                not null comment '运单号',
    order_status     varchar(32)   default ''                not null comment '订单状态',
    order_type       varchar(32)   default ''                not null comment '订单类型',
    logistic_type    varchar(32)   default ''                not null comment '仓配类型',
    source_system    varchar(10)   default ''                not null comment '请求系统',
    remark           varchar(1024) default ''                not null comment '备注',
    reason           varchar(1024) default ''                not null comment '取消原因',
    is_del           bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user      char(32)      default ''                not null comment '创建者',
    create_time      datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user      char(32)      default ''                not null comment '更新者',
    update_time      datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '仓配订单';

create table warehouse_distribute_attach
(
    id                            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type                      varchar(16)   default ''                not null comment '业务类型',
    warehouse_distribute_order_no varchar(32)   default ''                not null comment '仓配订单号',
    applier                       varchar(200)  default ''                not null comment '领用人',
    applier_contact               varchar(32)   default ''                not null comment '领用人联系方式',
    apply_company                 varchar(32)   default ''                not null comment '领用公司',
    be_applied_company            varchar(32)   default ''                not null comment '被领用公司',
    apply_aim                     varchar(32)   default ''                not null comment '领用目的',
    apply_purpose                 varchar(32)   default ''                not null comment '领用用途',
    remark                        varchar(1024) default ''                not null comment '备注',
    is_del                        bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user                   char(32)      default ''                not null comment '创建者',
    create_time                   datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user                   char(32)      default ''                not null comment '更新者',
    update_time                   datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '仓配订单附属信息';

create table warehouse_distribute_logistic
(
    id                            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type                      varchar(16)   default ''                not null comment '业务类型',
    warehouse_distribute_order_no varchar(32)   default ''                not null comment '仓配订单号',
    est_pick_time                 varchar(32)   default ''                not null comment '预计提货时间',
    est_arrival_time              varchar(32)   default ''                not null comment '预计到货时间',
    shipping_method               varchar(16)   default ''                not null comment '运输方式',
    deliver_warehouse_code        varchar(200)  default ''                not null comment '发货仓库代码',
    shipper                       varchar(200)  default ''                not null comment '发货人',
    shipper_contact               varchar(500)  default ''                not null comment '发货人联系方式',
    deliver_province_code         varchar(32)   default ''                not null comment '发货省份代码',
    deliver_city_code             varchar(32)   default ''                not null comment '发货城市代码	',
    deliver_district_code         varchar(32)   default ''                not null comment '发货区县代码',
    deliver_address               varchar(500)  default ''                not null comment '发货地址',
    receive_warehouse_code        varchar(32)   default ''                not null comment '收货仓库代码',
    receiver                      varchar(500)  default ''                not null comment '收货人',
    receiver_contact              varchar(500)  default ''                not null comment '收货人联系方式',
    receive_province_code         varchar(32)   default ''                not null comment '收货省份代码',
    receive_city_code             varchar(32)   default ''                not null comment '收货城市代码',
    receive_district_code         varchar(32)   default ''                not null comment '收货区县代码',
    receive_province_name         varchar(32)   default ''                not null comment '收货省份名字',
    receive_city_name             varchar(32)   default ''                not null comment '收货城市名字',
    receive_district_name         varchar(32)   default ''                not null comment '收货区县名字',
    receive_address               varchar(500)  default ''                not null comment '收货地址',
    iv                            varchar(200)  default ''                not null comment '加密向量',
    remark                        varchar(1024) default ''                not null comment '备注',
    is_del                        bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user                   char(32)      default ''                not null comment '创建者',
    create_time                   datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user                   char(32)      default ''                not null comment '更新者',
    update_time                   datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '仓配订单物流信息';

create table warehouse_distribute_item
(
    id                            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type                      varchar(16)    default ''                not null comment '业务类型',
    warehouse_distribute_order_no varchar(32)    default ''                not null comment '仓配订单号',
    material_line_no              varchar(64)    default ''                not null comment '零件行号',
    material_code                 varchar(200)   default ''                not null comment '零件编码',
    qty                           decimal(20, 3) default 0                 not null comment '数量',
    real_in_qty                   decimal(20, 3) default 0                 not null comment '数量',
    real_out_qty                  decimal(20, 3) default 0                 not null comment '实际出库数量',
    packing_code                  varchar(64)    default ''                not null comment '包装编码',
    volume                        varchar(32)    default ''                not null comment '体积',
    weight                        varchar(32)    default ''                not null comment '重量',
    material_status               tinyint        default 1                 not null comment '零件状态',
    stock_status                  tinyint        default 1                 not null comment '库存状态',
    material_sort                 varchar(20)    default ''                not null comment '零件种类',
    sample_part_status            varchar(50)    default ''                not null comment '样件状态',
    car_code                      varchar(200)   default ''                not null comment '车辆编码',
    batch_no                      varchar(32)    default ''                not null comment '批次号',
    material_bar_code             varchar(32)    default ''                not null comment '零件条码',
    sequence_no                   varchar(50)    default ''                not null comment '序列号',
    add_date                      varchar(32)    default ''                not null comment '入库日期',
    product_date                  varchar(32)    default ''                not null comment '生产日期',
    expire_date                   varchar(32)    default ''                not null comment '失效日期',
    supplier_code                 varchar(200)   default ''                not null comment '供应商编码',
    project_code                  varchar(50)    default ''                not null comment '项目号',
    stage_code                    varchar(50)    default ''                not null comment '阶段',
    wbs_code                      varchar(50)    default ''                not null comment 'wbs编号',
    purchase_order_no             varchar(50)    default ''                not null comment '业务单号',
    column_project_no             varchar(50)    default ''                not null comment '业务行号',
    warehouse_code                varchar(200)   default ''                not null comment '仓库代码',
    area_code                     varchar(200)   default ''                not null comment '区域代码',
    location_code                 varchar(200)   default ''                not null comment '库位代码',
    pallet_no                     varchar(100)   default ''                not null comment '托盘号',
    case_no                       varchar(100)   default ''                not null comment '箱号',
    remark                        varchar(1024)  default ''                not null comment '备注',
    is_del                        bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user                   char(32)       default ''                not null comment '创建者',
    create_time                   datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user                   char(32)       default ''                not null comment '更新者',
    update_time                   datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '仓配订单零件信息';

create table warehouse_distribute_item_attach
(
    id                            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type                      varchar(16)   default ''                not null comment '业务类型',
    warehouse_distribute_order_no varchar(32)   default ''                not null comment '仓配订单号',
    material_line_no              varchar(64)   default ''                not null comment '零件行号',
    apply_purpose                 varchar(64)   default ''                not null comment '领用用途',
    plan_apply_flag               bit           default b'1'              not null comment '是否计划内领料,1是0不是',
    sap_card_no                   varchar(200)  default ''                not null comment 'SAP卡片号',
    cost_center                   varchar(100)  default ''                not null comment '成本中心',
    remark                        varchar(1024) default ''                not null comment '备注',
    is_del                        bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user                   char(32)      default ''                not null comment '创建者',
    create_time                   datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user                   char(32)      default ''                not null comment '更新者',
    update_time                   datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '仓配订单零件附属信息';

create table warehouse_distribute_item_package
(
    id                            bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type                      varchar(16)    default ''                not null comment '业务类型',
    warehouse_distribute_order_no varchar(32)    default ''                not null comment '仓配订单号',
    packing_code                  varchar(64)    default ''                not null comment '包装编码',
    packing_unit                  varchar(64)    default ''                not null comment '包装单位',
    packing_length                int            default 0                 not null comment '包装长(mm)',
    packing_width                 int            default 0                 not null comment '包装宽(mm)',
    packing_height                int            default 0                 not null comment '包装高(mm)',
    packing_volume                decimal(20, 3) default 0                 not null comment '包装体积(m³)',
    packing_weight                decimal(20, 3) default 0                 not null comment '包装重量(kg)',
    remark                        varchar(1024)  default ''                not null comment '备注',
    is_del                        bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user                   char(32)       default ''                not null comment '创建者',
    create_time                   datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user                   char(32)       default ''                not null comment '更新者',
    update_time                   datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '仓配订单零件包装信息';
create index idx_order_no
    on warehouse_distribute_order (order_no);
create index idx_business_bill_no
    on warehouse_distribute_order (business_bill_no);
create index idx_warehouse_distribute_order_no
    on warehouse_distribute_attach (warehouse_distribute_order_no);
create index idx_warehouse_distribute_order_no
    on warehouse_distribute_logistic (warehouse_distribute_order_no);
create index idx_warehouse_distribute_order_no
    on warehouse_distribute_item (warehouse_distribute_order_no);
create index idx_warehouse_distribute_order_no
    on warehouse_distribute_item_attach (warehouse_distribute_order_no);
create index idx_warehouse_distribute_order_no
    on warehouse_distribute_item_package (warehouse_distribute_order_no);
alter table warehouse_distribute_item_attach
    add responsible_party varchar(100) default '' not null comment '责任方' after cost_center;
alter table warehouse_distribute_order
    add actual_arrival_time varchar(32) default '' not null comment '实际到货时间';

alter table warehouse_distribute_item
    modify volume decimal(20, 3) default 0 not null comment '体积';

alter table warehouse_distribute_item
    modify weight decimal(20, 3) default 0 not null comment '重量';


create table idempotent_log
(
    id            bigint unsigned auto_increment comment '主键'
        primary key,
    idempotent_no varchar(32)   default ''                not null comment '幂等号',
    api_url       varchar(200)  default ''                not null comment '接口路径',
    remark        varchar(1024) default ''                not null comment '备注',
    is_del        bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user   char(32)      default ''                not null comment '创建者',
    create_time   datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user   char(32)      default ''                not null comment '更新者',
    update_time   datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '接口幂等记录表';

create index idx_idempotent_log
    on idempotent_log (idempotent_no);