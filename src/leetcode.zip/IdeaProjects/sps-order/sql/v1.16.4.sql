create table store_transfer_order
(
    id                             bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type                       varchar(10)    default ''                not null comment '业务类型',
    order_no                       varchar(32)    default ''                not null comment '调拨单号',
    idempotent_no                  varchar(32)    default ''                not null comment '操作幂等号',
    sap_order_no                   varchar(50)    default ''                not null comment 'sap单号',
    order_attr                     varchar(20)    default ''                not null comment '订单归属(售后自营101 售后授权102)',
    order_amount                   decimal(20, 3) default 0.000             not null comment '订单总金额',
    transfer_in_organization_code  varchar(100)   default ''                not null comment '调入组织编码',
    transfer_in_warehouse_code     varchar(200)   default ''                not null comment '调入仓库编码',
    transfer_in_address            varchar(200)   default ''                not null comment '调入地址',
    transfer_in_contact_name       varchar(50)    default ''                not null comment '调入联系人',
    transfer_in_contact_mobile     varchar(30)    default ''                not null comment '调入联系人电话',
    transfer_out_organization_code varchar(100)   default ''                not null comment '调出组织编码',
    transfer_out_warehouse_code    varchar(200)   default ''                not null comment '调出仓库编码',
    transfer_out_address           varchar(200)   default ''                not null comment '调出地址',
    transfer_out_contact_name      varchar(50)    default ''                not null comment '调出联系人',
    transfer_out_contact_mobile    varchar(30)    default ''                not null comment '调出联系人电话',
    commit_time                    datetime       default CURRENT_TIMESTAMP not null comment '订单提交日期 yyyy-MM-dd HH:mm:ss',
    sap_order_create_time          datetime       default CURRENT_TIMESTAMP not null comment 'sap创建时间',
    order_status                   varchar(20)    default ''                not null comment '订单状态 字典key STO_STATUS',
    logistics_no                   varchar(50)    default ''                not null comment '物流单号',
    logistics_company              varchar(50)    default ''                not null comment '物流公司',
    remark                         varchar(1024)  default ''                not null comment '备注',
    is_del                         bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user                    char(32)       default ''                not null comment '创建者',
    create_time                    datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user                    char(32)       default ''                not null comment '更新者',
    update_time                    datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '门店调拨单';

create table store_transfer_order_detail
(
    id                  bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type            varchar(10)    default ''                not null comment '业务类型',
    order_no            varchar(32)    default ''                not null comment '调拨单号',
    material_code       varchar(50)    default ''                not null comment '零件售后件号',
    qty                 decimal(20, 3) default 0.000             not null comment '数量',
    discount_unit_price decimal(20, 3) default 0.000             not null comment '折后单价',
    line_amount         decimal(20, 3) default 0.000             not null comment '行金额',
    transfer_in_qty     decimal(20, 3) default 0.000             not null comment '调入数量',
    transfer_out_qty    decimal(20, 3) default 0.000             not null comment '调出数量',
    remark              varchar(1024)  default ''                not null comment '备注',
    is_del              bit            default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user         char(32)       default ''                not null comment '创建者',
    create_time         datetime       default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user         char(32)       default ''                not null comment '更新者',
    update_time         datetime       default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 comment '门店调拨单明细';

create index idx_order_no_bt
    on store_transfer_order (order_no, biz_type);

create index idx_order_no_bt
    on store_transfer_order_detail (order_no, biz_type);


CREATE TABLE `common_log`
(
    `id`            bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `biz_type`      varchar(16)         NOT NULL DEFAULT '' COMMENT '业务类型',
    `log_key`       varchar(40)         NOT NULL DEFAULT '' COMMENT '对应记录业务日志的表名',
    `log_type`      int(11)             NOT NULL DEFAULT '1' COMMENT '日志类型 1: 状态变更   2：属性变更',
    `order_no`      varchar(50)         NOT NULL DEFAULT '' COMMENT '业务单号 or 表主键',
    `action_desc`   varchar(32)         NOT NULL DEFAULT '' COMMENT '操作描述',
    `modify_column` varchar(50)         NOT NULL DEFAULT '' COMMENT '修改字段',
    `old_value`     varchar(100)        NOT NULL DEFAULT '' COMMENT '原始值',
    `new_value`     varchar(100)        NOT NULL DEFAULT '' COMMENT '修改值',
    `remark`        varchar(1024)       NOT NULL DEFAULT '' COMMENT '备注',
    `is_del`        bit(1)              NOT NULL DEFAULT b'0' COMMENT '是否删除 1是 0否 默认0',
    `create_user`   char(32)            NOT NULL DEFAULT '' COMMENT '创建者',
    `create_time`   datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_user`   char(32)            NOT NULL DEFAULT '' COMMENT '更新者',
    `update_time`   datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  AUTO_INCREMENT = 0
  DEFAULT CHARSET = utf8mb4 COMMENT ='通用日志记录';

create index idx_order_no_bt
    on common_log (order_no, biz_type);

alter table store_transfer_order
    add confirm_user varchar(32) default '' not null comment '确认人' after transfer_out_contact_mobile;
