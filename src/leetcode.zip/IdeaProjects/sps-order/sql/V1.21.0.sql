create table store_free_times
(
    id          bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type    varchar(10)   default ''                not null comment '业务类型',
    store_code  varchar(50)   default ''                not null comment '门店code',
    order_type  varchar(32)   default ''                not null comment '订单类型',
    free_times  int           default 0                 not null comment '免费次数',
    del_unique_key            bigint unsigned default 0 not null comment '唯一索引，删除后用Id赋值',
    remark      varchar(1024) default ''                not null comment '备注',
    is_del      bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user char(32)      default ''                not null comment '创建者',
    create_time datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user char(32)      default ''                not null comment '更新者',
    update_time datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint uk_sc_ot_duk_bt
        unique (store_code, order_type, del_unique_key, biz_type)
) DEFAULT CHARSET = utf8mb4 comment '门店免费次数配置';

create table store_discount
(
    id                   bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type             varchar(16)     default ''                not null comment '业务类型',
    store_code           varchar(50)     default ''                not null comment '门店code',
    material_code        varchar(64)     default ''                not null comment '备件号码',
    order_type           varchar(32)     default ''                not null comment '订单类型',
    discount_rate        decimal(20, 2)  default 0.00              not null comment '折扣率',
    effective_start_time datetime        default CURRENT_TIMESTAMP not null comment '有效开始日期',
    del_unique_key       bigint unsigned default 0                 not null comment '唯一索引，删除后用Id赋值',
    remark               varchar(1024)                             not null comment '备注',
    is_del               bit             default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user          char(32)        default ''                not null comment '创建者',
    create_time          datetime        default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user          char(32)        default ''                not null comment '更新者',
    update_time          datetime        default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint uk_sc_mc_est_pt_bt_duk
        unique (store_code, material_code, effective_start_time, order_type, biz_type, del_unique_key)
) DEFAULT CHARSET = utf8mb4 comment '门店折扣表';

create table store_discount_approval
(
    id                  bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type            varchar(16)   default ''                not null comment '业务类型',
    approval_no         varchar(32)   default ''                not null comment '审批单号',
    proc_inst_id        varchar(64)   default ''                not null comment '当前流程实例id',
    detail_quantity     int           default 0                 not null comment '明细数量',
    attachment_quantity int           default 0                 not null comment '附件数量',
    approval_status     varchar(32)   default ''                not null comment '审核状态',
    remark              varchar(1024) default ''                not null comment '备注',
    is_del              bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user         char(32)      default ''                not null comment '创建者',
    create_time         datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user         char(32)      default ''                not null comment '更新者',
    update_time         datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
) DEFAULT CHARSET = utf8mb4 comment '门店折扣审批表';

create table store_discount_approval_detail
(
    id                   bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type             varchar(16)     default ''                not null comment '业务类型',
    approval_id          bigint unsigned default 0                 not null comment '审批id',
    store_code           varchar(50)     default ''                not null comment '门店code',
    material_code        varchar(64)     default ''                not null comment '零件号',
    order_type           varchar(32)     default ''                not null comment '订单类型',
    discount_rate        decimal(20, 2)  default 0.00              not null comment '折扣率',
    effective_start_time datetime        default CURRENT_TIMESTAMP not null comment '有效开始日期',
    del_unique_key       bigint unsigned default 0                 not null comment '唯一索引，删除后用Id赋值',
    remark               varchar(1024)   default ''                not null comment '备注',
    is_del               bit             default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user          char(32)        default ''                not null comment '创建者',
    create_time          datetime        default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user          char(32)        default ''                not null comment '更新者',
    update_time          datetime        default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    constraint uk_aid_sc_mc_est_ot_bt_duk
        unique (approval_id, store_code, material_code, effective_start_time, order_type, biz_type, del_unique_key)
) DEFAULT CHARSET = utf8mb4 comment '门店折扣审批明细';
