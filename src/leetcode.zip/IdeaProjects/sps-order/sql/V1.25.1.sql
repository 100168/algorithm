alter table warehouse_distribute_attach
    add apply_date varchar(32) default '' not null comment '领用日期' after apply_purpose;

alter table warehouse_distribute_attach
    add process_code varchar(32) default '' not null comment '流程code' after apply_purpose;

alter table warehouse_distribute_order
    add is_child tinyint(1) default 0 not null comment '是否子单' after order_type;


alter table warehouse_distribute_item
    add forked_qty decimal(19,2) default 0 not null comment '已拆单数量' after qty;


alter table jidu_sps_order.warehouse_distribute_item_attach
    add wbs_code varchar(64) default '' not null comment 'wbs编号' after apply_purpose;
