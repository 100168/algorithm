alter table warehouse_distribute_order
    add is_api bit default b'1' not null comment '是否api创建' after source_system;

create table common_file_attachment
(
    id           bigint unsigned auto_increment comment '主键'
        primary key,
    biz_type     varchar(16)   default ''                not null comment '业务类型',
    source_table varchar(30)   default ''                not null comment '对应附件所属业务表名',
    order_no     varchar(40)   default ''                not null comment '来源单号',
    file_name    varchar(200)  default ''                not null comment '文件名',
    file_key     varchar(200)  default ''                not null comment '文件key',
    file_url     varchar(300)  default ''                not null comment '文件链接',
    file_length  bigint        default 0                 not null comment '文件大小',
    remark       varchar(1024) default ''                not null comment '备注',
    is_del       bit           default b'0'              not null comment '是否删除 1是 0否 默认0',
    create_user  char(32)      default ''                not null comment '创建者',
    create_time  datetime      default CURRENT_TIMESTAMP not null comment '创建时间',
    update_user  char(32)      default ''                not null comment '更新者',
    update_time  datetime      default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间'
)
    comment '通用附件表';

create index idx_order_no_bt
    on common_file_attachment (order_no, biz_type);
