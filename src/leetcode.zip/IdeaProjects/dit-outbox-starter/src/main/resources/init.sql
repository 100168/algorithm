CREATE TABLE `t_outbox_message`
(
    `id`          bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
    `msg_id`      varchar(64)         NOT NULL DEFAULT '' COMMENT '消息id',
    `msg_type`    varchar(64)         NOT NULL DEFAULT '' COMMENT '消息类型',
    `content`     longtext            NOT NULL COMMENT '消息内容',
    `retry_count` int(11)             NOT NULL DEFAULT '0' COMMENT '重试次数',
    `bit_status`      int(11)             NOT NULL DEFAULT '0' COMMENT '状态',
    `remark`      varchar(1023)       NOT NULL DEFAULT '' COMMENT '备注',
    `create_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    KEY `idx_msg_id` (`msg_id`),
    KEY `idx_create_time` (`create_time`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='发件箱消息';