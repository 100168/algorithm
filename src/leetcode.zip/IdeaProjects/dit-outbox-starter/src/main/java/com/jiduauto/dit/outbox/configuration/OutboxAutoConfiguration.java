package com.jiduauto.dit.outbox.configuration;

import com.jiduauto.dit.outbox.OutboxMessageHandler;
import com.jiduauto.dit.outbox.OutboxMessageService;
import com.jiduauto.dit.outbox.handle.OutboxBeanPostProcessor;
import com.jiduauto.dit.outbox.storage.MysqlOutboxMessageRepository;
import com.jiduauto.dit.outbox.storage.OutboxMessageRepository;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnSingleCandidate;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

/**
 * @author chongfeng.zhong
 */
@Configuration
@ConditionalOnProperty(prefix = "dit.outbox", name = "enabled", havingValue = "true", matchIfMissing = true)
@ConditionalOnClass({DataSource.class, JdbcTemplate.class})
@ConditionalOnSingleCandidate(DataSource.class)
@AutoConfigureAfter({JdbcTemplateAutoConfiguration.class})
public class OutboxAutoConfiguration {

    @Bean
    public OutboxMessageRepository outboxRepository(JdbcTemplate jdbcTemplate) {
        return new MysqlOutboxMessageRepository(jdbcTemplate);
    }

    @Bean
    public OutboxMessageHandler outboxMessageHandler() {
        return new OutboxMessageHandler();
    }

    @Bean
    public OutboxMessageService outboxMessageService(OutboxMessageRepository outboxMessageRepository, OutboxMessageHandler outboxMessageHandler) {
        return new OutboxMessageService(outboxMessageRepository, outboxMessageHandler);
    }

    @Bean
    public OutboxBeanPostProcessor outboxBeanPostProcessor(OutboxMessageHandler outboxMessageHandler) {
        return new OutboxBeanPostProcessor(outboxMessageHandler);
    }
}
