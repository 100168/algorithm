package com.jiduauto.dit.outbox.storage;


import com.jiduauto.dit.outbox.pojo.HandleResult;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author chongfeng.zhong
 */
public interface OutboxMessageRepository {

    void saveMessage(OutboxMessage outboxMessage);

    OutboxMessage getMessage(String msgId);

    List<OutboxMessage> listMessages(LocalDateTime startTime, LocalDateTime endTime);

    void updateStatus(String msgId, HandleResult handleResult);
}
