package com.jiduauto.dit.outbox;


import com.jiduauto.dit.outbox.handle.IMessageHandle;
import com.jiduauto.dit.outbox.handle.IResultCallback;
import com.jiduauto.dit.outbox.pojo.BitStatus;
import com.jiduauto.dit.outbox.pojo.HandleResult;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.pojo.Result;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;

/**
 * @author chongfeng.zhong
 */
@Slf4j
public class OutboxMessageHandler {

    private final HashMap<String, IMessageHandle> messageHandleMap = new HashMap<>();

    private final HashMap<String, IResultCallback> resultCallbackMap = new HashMap<>();

    public boolean containsMessageHandle(String msgType, int bitIndex) {
        return messageHandleMap.containsKey(generateHandleKey(msgType, bitIndex));
    }

    public void registerMessageHandle(String msgType, int bitIndex, IMessageHandle messageHandle) {
        messageHandleMap.put(generateHandleKey(msgType, bitIndex), messageHandle);
    }

    public boolean containsResultCallback(String msgType, int bitIndex) {
        return resultCallbackMap.containsKey(generateHandleKey(msgType, bitIndex));
    }

    public void registerResultCallback(String msgType, int bitIndex, IResultCallback resultCallback) {
        resultCallbackMap.put(generateHandleKey(msgType, bitIndex), resultCallback);
    }

    public HandleResult handleMessage(OutboxMessage outboxMessage) {
        BitStatus bitStatus = new BitStatus(outboxMessage.getBitStatus().bitIndexes());
        StringBuilder remarkBuilder = new StringBuilder();
        int[] bitIndexes = bitStatus.bitIndexes();
        for (int bitIndex : bitIndexes) {
            Result result;
            try {
                IMessageHandle messageHandle = messageHandleMap.get(generateHandleKey(outboxMessage.getMsgType(), bitIndex));
                if (messageHandle == null) {
                    throw new RuntimeException(String.format("MessageHandle#%s#%d is undefined", outboxMessage.getMsgType(), bitIndex));
                }
                result = messageHandle.handle(outboxMessage);
            } catch (Exception e) {
                result = Result.error(e.toString());
            }

            resultCallback(outboxMessage, bitIndex, result);

            if (result.isSuccess()) {
                bitStatus.clearStatus(bitIndex);
            } else {
                remarkBuilder.append(bitIndex).append(":").append(cutString(result.getMessage(), 100)).append(";");
            }
        }
        return new HandleResult(bitStatus, remarkBuilder.toString());
    }

    private void resultCallback(OutboxMessage outboxMessage, int bitIndex, Result result) {
        try {
            IResultCallback resultCallback = resultCallbackMap.get(generateHandleKey(outboxMessage.getMsgType(), bitIndex));
            if (resultCallback != null) {
                resultCallback.callback(outboxMessage, result);
            }
        } catch (Exception e) {
            log.warn(String.format("resultCallback error, messageId: %s, bitIndex: %d", outboxMessage.getMsgId(), bitIndex), e);
        }
    }

    private String generateHandleKey(String msgType, int index) {
        return msgType.concat("#").concat(String.valueOf(index));
    }

    private String cutString(String s, int len) {
        if (s == null || s.length() <= len) {
            return s;
        }
        return s.substring(0, len);
    }
}
