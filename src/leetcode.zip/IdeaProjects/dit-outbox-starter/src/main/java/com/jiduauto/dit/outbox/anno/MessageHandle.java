package com.jiduauto.dit.outbox.anno;

import org.springframework.core.annotation.AliasFor;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author chongfeng.zhong
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface MessageHandle {

    @AliasFor("msgType")
    String value() default "";

    String msgType() default "";

    int bitIndex() default 0;
}
