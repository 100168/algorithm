package com.jiduauto.dit.outbox.pojo;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author chongfeng.zhong
 */
@Data
public class OutboxMessage {

    /**
     * 消息Id
     */
    private String msgId;

    /**
     * 消息类型
     */
    private String msgType;

    /**
     * 消息内容
     */
    private String content;

    /**
     * 重试次数
     */
    private Integer retryCount;

    /**
     * 数据状态
     */
    private BitStatus bitStatus;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;
}