package com.jiduauto.dit.outbox;

import com.jiduauto.dit.outbox.pojo.BitStatus;
import com.jiduauto.dit.outbox.pojo.HandleResult;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.storage.OutboxMessageRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author chongfeng.zhong
 */
@Slf4j
public class OutboxMessageService {

    private final OutboxMessageRepository outboxMessageRepository;

    private final OutboxMessageHandler outboxMessageHandler;

    private final ExecutorService executorService;

    public OutboxMessageService(OutboxMessageRepository outboxMessageRepository, OutboxMessageHandler outboxMessageHandler) {
        this.outboxMessageRepository = outboxMessageRepository;
        this.outboxMessageHandler = outboxMessageHandler;
        this.executorService = new ThreadPoolExecutor(Runtime.getRuntime().availableProcessors() * 2
                , Runtime.getRuntime().availableProcessors() * 2
                , 60, TimeUnit.SECONDS
                , new LinkedBlockingQueue<Runnable>(100000)
                , new ThreadPoolExecutor.CallerRunsPolicy());
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public void saveMessage(String msgType, String content) {
        saveMessage(msgType, content, new BitStatus(0));
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public void saveMessage(String msgType, String content, BitStatus status) {
        final OutboxMessage outboxMessage = new OutboxMessage();
        outboxMessage.setMsgId(UUID.randomUUID().toString().replace("-", ""));
        outboxMessage.setMsgType(msgType);
        outboxMessage.setContent(content);
        outboxMessage.setBitStatus(status);
        outboxMessageRepository.saveMessage(outboxMessage);

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                OutboxMessage dbMessage = outboxMessageRepository.getMessage(outboxMessage.getMsgId());
                if (dbMessage != null) {
                    executorService.submit(() -> doHandleMessage(dbMessage));
                }
            }
        });
    }

    public void handleMessages(LocalDateTime startTime, LocalDateTime endTime) {
        List<OutboxMessage> outboxMessages = outboxMessageRepository.listMessages(startTime, endTime);
        for (OutboxMessage outboxMessage : outboxMessages) {
            doHandleMessage(outboxMessage);
        }
    }

    private void doHandleMessage(OutboxMessage outboxMessage) {
        HandleResult handleResult;
        try {
            handleResult = outboxMessageHandler.handleMessage(outboxMessage);
        } catch (Exception e) {
            handleResult = new HandleResult(outboxMessage.getBitStatus(), e.toString());
        }
        log.info("doHandleMessage message: {}, result: {}", outboxMessage, handleResult);
        outboxMessageRepository.updateStatus(outboxMessage.getMsgId(), handleResult);
    }
}
