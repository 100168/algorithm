package com.jiduauto.dit.outbox.pojo;

import java.util.BitSet;

/**
 * @author chongfeng.zhong
 */
public class BitStatus {

    private static final int MAX_LENGTH = 31;

    private final BitSet bitValue;

    public BitStatus() {
        this.bitValue = new BitSet();
    }

    public BitStatus(int... bitIndexes) {
        this.bitValue = new BitSet();
        for (int bitIndex : bitIndexes) {
            setStatus(bitIndex);
        }
    }

    private BitStatus(BitSet bitSet) {
        this.bitValue = bitSet;
    }

    public void setStatus(int index) {
        if (index > MAX_LENGTH) {
            throw new IndexOutOfBoundsException();
        }
        bitValue.set(index);
    }

    public boolean getStatus(int index) {
        return bitValue.get(index);
    }

    public void clearStatus(int index) {
        if (index > MAX_LENGTH) {
            throw new IndexOutOfBoundsException();
        }
        bitValue.clear(index);
    }

    public int[] bitIndexes() {
        int[] indexes = new int[bitValue.cardinality()];
        if (indexes.length > 0) {
            indexes[0] = bitValue.nextSetBit(0);
            for (int i = 1; i < indexes.length; i++) {
                indexes[i] = bitValue.nextSetBit(indexes[i - 1] + 1);
            }
        }
        return indexes;
    }

    public int intValue() {
        long[] longArray = bitValue.toLongArray();
        return longArray.length == 0 ? 0 : Math.toIntExact(longArray[0]);
    }

    @Override
    public String toString() {
        return "BitStatus{" +
                "bitValue=" + bitValue +
                '}';
    }

    public static BitStatus valueOf(int value) {
        return new BitStatus(BitSet.valueOf(new long[]{value}));
    }
}
