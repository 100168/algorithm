package com.jiduauto.dit.outbox.storage;

import com.jiduauto.dit.outbox.pojo.BitStatus;
import com.jiduauto.dit.outbox.pojo.HandleResult;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author chongfeng.zhong
 */
public class MysqlOutboxMessageRepository implements OutboxMessageRepository {

    private static final String INSERT_SQL = "insert into t_outbox_message (msg_id, msg_type, content, bit_status) values (?, ?, ?, ?)";

    private static final String SELECT_ONE_SQL = "select * from t_outbox_message where msg_id = ? limit 1";

    private static final String SELECT_LIST_SQL = "select * from t_outbox_message where create_time >= ? and create_time < ? order by id asc limit ?";

    private static final String UPDATE_STATUS_SQL = "update t_outbox_message set retry_count = (retry_count + 1), bit_status = ?, remark = ? where msg_id = ?";

    private static final String DELETE_SQL = "delete from t_outbox_message where msg_id = ?";

    private final static int BATCH_SIZE = 100000;

    private final JdbcTemplate jdbcTemplate;

    public MysqlOutboxMessageRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void saveMessage(OutboxMessage outboxMessage) {
        jdbcTemplate.update(INSERT_SQL, outboxMessage.getMsgId(), outboxMessage.getMsgType(), outboxMessage.getContent(), outboxMessage.getBitStatus().intValue());
    }

    @Override
    public OutboxMessage getMessage(String msgId) {
        return jdbcTemplate.queryForObject(SELECT_ONE_SQL, new Object[]{msgId}, new OutboxMessageRowMapper());
    }

    @Override
    public List<OutboxMessage> listMessages(LocalDateTime startTime, LocalDateTime endTime) {
        return jdbcTemplate.query(SELECT_LIST_SQL, new Object[]{startTime, endTime, BATCH_SIZE}, new OutboxMessageRowMapper());
    }

    @Override
    public void updateStatus(String msgId, HandleResult handleResult) {
        int value = handleResult.getBitStatus().intValue();
        if (value == 0) {
            jdbcTemplate.update(DELETE_SQL, msgId);
        } else {
            jdbcTemplate.update(UPDATE_STATUS_SQL, value, handleResult.getRemark(), msgId);
        }
    }

    public static class OutboxMessageRowMapper implements RowMapper<OutboxMessage> {
        @Override
        public OutboxMessage mapRow(ResultSet resultSet, int rowNum) throws SQLException {
            OutboxMessage outboxMessage = new OutboxMessage();
            outboxMessage.setMsgId(resultSet.getString("msg_id"));
            outboxMessage.setMsgType(resultSet.getString("msg_type"));
            outboxMessage.setContent(resultSet.getString("content"));
            outboxMessage.setRetryCount(resultSet.getInt("retry_count"));
            outboxMessage.setBitStatus(BitStatus.valueOf(resultSet.getInt("bit_status")));
            outboxMessage.setCreateTime(resultSet.getTimestamp("create_time").toLocalDateTime());
            return outboxMessage;
        }
    }
}
