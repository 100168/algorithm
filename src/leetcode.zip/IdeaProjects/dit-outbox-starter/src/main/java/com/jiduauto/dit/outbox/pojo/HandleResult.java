package com.jiduauto.dit.outbox.pojo;

import lombok.Data;

/**
 * @author chongfeng.zhong
 */
@Data
public class HandleResult {

    private BitStatus bitStatus;

    private String remark;

    public HandleResult(BitStatus bitStatus, String remark) {
        this.bitStatus = bitStatus;
        this.remark = cutString(remark, 1000);
    }

    private String cutString(String s, int len) {
        if (s == null || s.length() <= len) {
            return s;
        }
        return s.substring(0, len);
    }
}
