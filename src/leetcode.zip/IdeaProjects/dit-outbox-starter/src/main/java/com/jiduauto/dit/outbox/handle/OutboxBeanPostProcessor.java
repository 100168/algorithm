package com.jiduauto.dit.outbox.handle;

import com.jiduauto.dit.outbox.OutboxMessageHandler;
import com.jiduauto.dit.outbox.anno.MessageHandle;
import com.jiduauto.dit.outbox.anno.ResultCallback;
import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.pojo.Result;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;

/**
 * @author chongfeng.zhong
 */
public class OutboxBeanPostProcessor implements BeanPostProcessor, Ordered {

    private final OutboxMessageHandler outboxMessageHandler;

    public OutboxBeanPostProcessor(OutboxMessageHandler outboxMessageHandler) {
        this.outboxMessageHandler = outboxMessageHandler;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        try {
            registerMessage(bean);
            return bean;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }

    private void registerMessage(Object bean) throws Exception {
        Class<?> clazz = bean.getClass();
        for (Method method : clazz.getDeclaredMethods()) {
            MessageHandle messageHandleAnno = AnnotationUtils.findAnnotation(method, MessageHandle.class);
            if (messageHandleAnno != null) {
                if (method.getParameterTypes().length != 1) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " parameter count must be 1");
                }
                if (!OutboxMessage.class.isAssignableFrom(method.getParameterTypes()[0])) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " parameter type must be OutboxMessage");
                }
                if (!Result.class.isAssignableFrom(method.getReturnType())) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " return type must be Result");
                }
                if (messageHandleAnno.msgType() == null || messageHandleAnno.msgType().length() == 0) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " MessageHandle#msgType() is null or empty");
                }
                if (outboxMessageHandler.containsMessageHandle(messageHandleAnno.msgType(), messageHandleAnno.bitIndex())) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " MessageHandle is repeated");
                }
                ReflectionUtils.makeAccessible(method);
                outboxMessageHandler.registerMessageHandle(messageHandleAnno.msgType(), messageHandleAnno.bitIndex(), message -> (Result) ReflectionUtils.invokeMethod(method, bean, message));
            }

            ResultCallback resultCallbackAnno = AnnotationUtils.findAnnotation(method, ResultCallback.class);
            if (resultCallbackAnno != null) {
                if (method.getParameterTypes().length != 2) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " parameter count must be 2");
                }
                if (!OutboxMessage.class.isAssignableFrom(method.getParameterTypes()[0])) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " parameter[0] type must be OutboxMessage");
                }
                if (!Result.class.isAssignableFrom(method.getParameterTypes()[1])) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " parameter[1] type must be Result");
                }
                if (!Void.TYPE.equals(method.getReturnType())) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " return type must be void");
                }
                if (resultCallbackAnno.msgType() == null || resultCallbackAnno.msgType().length() == 0) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " ResultCallback#msgType() is null or empty");
                }
                if (outboxMessageHandler.containsResultCallback(resultCallbackAnno.msgType(), resultCallbackAnno.bitIndex())) {
                    throw new IllegalArgumentException(bean.getClass().getSimpleName() + "." + method.getName() + " ResultCallback is repeated");
                }
                ReflectionUtils.makeAccessible(method);
                outboxMessageHandler.registerResultCallback(resultCallbackAnno.msgType(), resultCallbackAnno.bitIndex(), (message, result) -> ReflectionUtils.invokeMethod(method, bean, message, result));
            }
        }
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE;
    }
}
