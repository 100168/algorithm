package com.jiduauto.dit.outbox.handle;

import com.jiduauto.dit.outbox.pojo.OutboxMessage;
import com.jiduauto.dit.outbox.pojo.Result;

/**
 * @author chongfeng.zhong
 */
public interface IResultCallback {
    void callback(OutboxMessage message, Result result);
}
