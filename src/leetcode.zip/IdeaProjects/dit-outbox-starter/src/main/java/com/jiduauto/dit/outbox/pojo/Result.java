package com.jiduauto.dit.outbox.pojo;

import lombok.Data;

/**
 * @author chongfeng.zhong
 */
@Data
public class Result {

    private final static String SUCCESS = "0";

    private final static String ERROR = "-1";

    private String code;

    private String message;

    public Result(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public static Result create(String code, String message) {
        return new Result(code, message);
    }

    public static Result success() {
        return create(SUCCESS, "成功");
    }

    public static Result error(String message) {
        return create(ERROR, message);
    }

    public boolean isSuccess() {
        return SUCCESS.equals(getCode());
    }
}
