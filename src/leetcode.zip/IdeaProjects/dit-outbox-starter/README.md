# Quick start

## 引入依赖

```pom
<dependency>
    <groupId>com.jiduauto.dit</groupId>
    <artifactId>dit-outbox-starter</artifactId>
    <version>0.0.2-SNAPSHOT</version>
</dependency>
```



## 使用方式

### 1.保存OutboxMessage

```java
@Transactional(rollbackFor = Exception.class)
public void saveMessage() {

    // 具体业务操作（更新数据库）

    outboxMessageService.saveMessage(MSG_TYPE, "消息内容");	// 单任务处理
    outboxMessageService.saveMessage(MSG_TYPE, "消息内容", new BitStatus(0, 1));	// 多任务处理，最多支持31个bit位
}
```



### 2.处理OutboxMessage

```java
/**
 * 处理 bitIndex = 0 的任务
 * @param outboxMessage
 * @return
 */
@MessageHandle(MSG_TYPE)
public Result messageHandle0(OutboxMessage outboxMessage) {
    log.info("messageHandle0 message: {}", outboxMessage);
    return Result.success();
}

/**
 * 处理 bitIndex = 1 的任务
 * @param outboxMessage
 * @return
 */
@MessageHandle(msgType = MSG_TYPE, bitIndex = 1)
public Result messageHandle1(OutboxMessage outboxMessage) {
    log.info("messageHandle1 message: {}", outboxMessage);
    return Result.error("处理失败");
}
```



### 3.任务处理结果回调（可选）

```java
/**
 * bitIndex = 0 的任务回调
 * @param outboxMessage
 * @param result
 */
@ResultCallback(MSG_TYPE)
public void resultCallback0(OutboxMessage outboxMessage, Result result) {
    log.info("resultCallback0 message: {}, result: {}", outboxMessage, result);
}

/**
 * bitIndex = 1 的任务回调
 * @param outboxMessage
 * @param result
 */
@ResultCallback(msgType = MSG_TYPE, bitIndex = 1)
public void resultCallback1(OutboxMessage outboxMessage, Result result) {
    log.info("resultCallback1 message: {}, result: {}", outboxMessage, result);
}
```



### 4.定时重试（参考）

```java
@Component
public class OutboxMessageXxlJob {

    @Resource
    private OutboxMessageService outboxMessageService;

    /**
     * 过去一小时的消息重试（5分钟执行一次）
     *
     * @param param
     * @return
     * @throws Exception
     */
    @XxlJob("handleLastHourOutboxMessage")
    public ReturnT<String> handleLastHourOutboxMessage(String param) throws Exception {
        LocalDateTime endTime = LocalDateTime.now().plusMinutes(-1);
        outboxMessageService.handleMessages(endTime.plusHours(-1), endTime);
        return ReturnT.SUCCESS;
    }

    /**
     * 过去一天的消息重试（30分钟执行一次）
     *
     * @param param
     * @return
     * @throws Exception
     */
    @XxlJob("handleLastDayOutboxMessage")
    public ReturnT<String> handleLastDayOutboxMessage(String param) throws Exception {
        LocalDateTime endTime = LocalDateTime.now().plusHours(-1).plusMinutes(-1);
        outboxMessageService.handleMessages(endTime.plusDays(-1), endTime);
        return ReturnT.SUCCESS;
    }

    /**
     * 过去一周的消息重试（60分钟执行一次）
     *
     * @param param
     * @return
     * @throws Exception
     */
    @XxlJob("handleLastWeekOutboxMessage")
    public ReturnT<String> handleLastWeekOutboxMessage(String param) throws Exception {
        LocalDateTime endTime = LocalDateTime.now().plusDays(-1).plusHours(-1).plusMinutes(-1);
        outboxMessageService.handleMessages(endTime.plusDays(-6), endTime);
        return ReturnT.SUCCESS;
    }
}
```
